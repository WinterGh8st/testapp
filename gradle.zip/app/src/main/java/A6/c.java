package A6;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f72a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f73b;

    public c(Set set, d dVar) {
        this.f72a = b(set);
        this.f73b = dVar;
    }

    public static String b(Set set) {
        StringBuilder sb2 = new StringBuilder();
        Iterator it = set.iterator();
        while (it.hasNext()) {
            a aVar = (a) it.next();
            sb2.append(aVar.f69a);
            sb2.append('/');
            sb2.append(aVar.f70b);
            if (it.hasNext()) {
                sb2.append(' ');
            }
        }
        return sb2.toString();
    }

    public final String a() {
        Set setUnmodifiableSet;
        Set setUnmodifiableSet2;
        d dVar = this.f73b;
        synchronized (((HashSet) dVar.f77b)) {
            setUnmodifiableSet = Collections.unmodifiableSet((HashSet) dVar.f77b);
        }
        boolean zIsEmpty = setUnmodifiableSet.isEmpty();
        String str = this.f72a;
        if (zIsEmpty) {
            return str;
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(' ');
        synchronized (((HashSet) dVar.f77b)) {
            setUnmodifiableSet2 = Collections.unmodifiableSet((HashSet) dVar.f77b);
        }
        sb2.append(b(setUnmodifiableSet2));
        return sb2.toString();
    }
}
