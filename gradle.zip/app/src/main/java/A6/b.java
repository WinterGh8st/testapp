package A6;

import C3.g;
import G6.F0;
import G6.y0;
import R5.r;
import S5.j;
import Z2.f;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Base64;
import com.google.android.gms.common.internal.L;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.android.material.carousel.MaskableFrameLayout;
import com.google.firebase.concurrent.ExecutorsRegistrar;
import com.google.firebase.datatransport.TransportRegistrar;
import com.google.firebase.firestore.FirestoreRegistrar;
import com.google.firebase.storage.p;
import com.google.firebase.storage.q;
import d6.x;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ScheduledExecutorService;
import p019b6.s;
import p019b6.t;
import p019b6.u;
import p067f5.C1095a;
import p067f5.m;
import p080g6.k;
import p129k6.n;
import p243v3.i;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements R5.e, g, m, Continuation, SuccessContinuation, q6.a, p, n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f71a;

    public /* synthetic */ b(int i10) {
        this.f71a = i10;
    }

    @Override // com.google.firebase.storage.p
    public void a(Object obj, q qVar) {
        obj.getClass();
        throw new ClassCastException();
    }

    @Override // C3.g
    public Object apply(Object obj) {
        switch (this.f71a) {
            case 1:
                Cursor cursorRawQuery = ((SQLiteDatabase) obj).rawQuery("SELECT distinct t._id, t.backend_name, t.priority, t.extras FROM transport_contexts AS t, events AS e WHERE e.context_id = t._id", new String[0]);
                try {
                    ArrayList arrayList = new ArrayList();
                    while (cursorRawQuery.moveToNext()) {
                        f fVarA = i.a();
                        fVarA.T(cursorRawQuery.getString(1));
                        fVarA.f14489c = F3.a.b(cursorRawQuery.getInt(2));
                        String string = cursorRawQuery.getString(3);
                        fVarA.f14488b = string == null ? null : Base64.decode(string, 0);
                        arrayList.add(fVarA.o());
                        break;
                    }
                    return arrayList;
                } finally {
                    cursorRawQuery.close();
                }
            default:
                u uVar = (u) obj;
                uVar.getClass();
                return new x(uVar);
        }
    }

    @Override // p067f5.m
    public p067f5.d b(p067f5.d dVar) {
        int i10 = MaskableFrameLayout.f19329f;
        return dVar instanceof C1095a ? new p067f5.c(((C1095a) dVar).f22387a) : dVar;
    }

    @Override // p129k6.n
    public void c(Object obj) {
    }

    @Override // R5.e
    public Object d(D8.x xVar) {
        switch (this.f71a) {
            case 0:
                Set setD = xVar.d(r.a(a.class));
                d dVar = d.f74c;
                if (dVar == null) {
                    synchronized (d.class) {
                        try {
                            dVar = d.f74c;
                            if (dVar == null) {
                                dVar = new d(0);
                                d.f74c = dVar;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                }
                return new c(setD, dVar);
            case 11:
                return (ScheduledExecutorService) ExecutorsRegistrar.f20103a.get();
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                return (ScheduledExecutorService) ExecutorsRegistrar.f20105c.get();
            case 13:
                return (ScheduledExecutorService) ExecutorsRegistrar.f20104b.get();
            case 14:
                R5.n nVar = ExecutorsRegistrar.f20103a;
                return j.f11352a;
            case 15:
                return TransportRegistrar.lambda$getComponents$0(xVar);
            case 16:
                return TransportRegistrar.lambda$getComponents$1(xVar);
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                return TransportRegistrar.lambda$getComponents$2(xVar);
            default:
                return FirestoreRegistrar.lambda$getComponents$0(xVar);
        }
    }

    @Override // com.google.android.gms.tasks.SuccessContinuation
    public Task then(Object obj) {
        long jC;
        K5.a aVar = (K5.a) obj;
        L.j(aVar);
        try {
            jC = (long) (Double.parseDouble(aVar.f6881b.replace("s", "")) * 1000.0d);
        } catch (NumberFormatException unused) {
            Map mapS = Ua.d.S(aVar.f6880a);
            jC = 1000 * (K5.b.c("exp", mapS) - K5.b.c("iat", mapS));
        }
        return Tasks.forResult(new K5.b(aVar.f6880a, jC, System.currentTimeMillis()));
    }

    @Override // com.google.android.gms.tasks.Continuation
    public Object then(Task task) throws t {
        switch (this.f71a) {
            case 7:
                if (task.isSuccessful()) {
                    return Tasks.forResult(K5.c.a((K5.b) task.getResult()));
                }
                return Tasks.forResult(new K5.c("eyJlcnJvciI6IlVOS05PV05fRVJST1IifQ==", new E5.j(task.getException().getMessage(), task.getException())));
            case 25:
                if (task.isSuccessful()) {
                    return Tasks.forResult(((K5.c) task.getResult()).f6886a);
                }
                return Tasks.forException(task.getException());
            case 27:
                k kVar = (k) task.getResult();
                if (kVar.d()) {
                    return kVar;
                }
                if (kVar.e()) {
                    return null;
                }
                throw new t("Failed to get document from cache. (However, this document may exist on the server. Run again without setting source to CACHE to attempt to retrieve the document from the server.)", s.UNAVAILABLE);
            default:
                if (task.isSuccessful()) {
                    return Tasks.forResult(null);
                }
                return Tasks.forException(task.getException());
        }
    }

    @Override // q6.a
    public void f(q6.b bVar) {
    }
}
