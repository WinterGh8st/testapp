package A6;

import B.P;
import B0.l;
import B3.m;
import C3.g;
import C3.h;
import C3.i;
import C9.p1;
import C9.q1;
import D2.d;
import D8.x;
import F9.C0242d;
import F9.C0243e;
import F9.T;
import F9.g0;
import G6.F0;
import G6.O;
import G6.y0;
import L.AbstractC0492c;
import N1.AbstractComponentCallbacksC0583t;
import U9.B;
import Y1.C0794i;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Trace;
import android.text.TextUtils;
import android.util.SparseArray;
import android.view.View;
import android.widget.Toast;
import com.android.billingclient.api.Purchase;
import com.flamingotools.ws.MainActivity;
import com.flamingotools.ws.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.FirebaseCommonRegistrar;
import com.google.protobuf.AbstractC1018l;
import d6.u;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import org.json.JSONObject;
import p016b3.C0853c;
import p016b3.l0;
import p019b6.C0877b;
import p019b6.C0878c;
import p028c3.n;
import p054e4.e;
import p068f6.t;
import p080g6.k;
import p093h6.j;
import p129k6.o;
import p136l3.f;
import p183p8.R0;
import p211s1.s;
import p260x.AbstractC1876h;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class e implements R5.e, D3.b, g, s, q6.a, f, n, Continuation, o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f78a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f79b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f80c;

    public /* synthetic */ e(int i10, Object obj, Object obj2) {
        this.f78a = i10;
        this.f79b = obj;
        this.f80c = obj2;
    }

    @Override // p136l3.f
    public void a(int i10) {
        Object obj = this.f80c;
        Object obj2 = this.f79b;
        switch (this.f78a) {
            case 7:
                int i11 = MainActivity.f18446Z;
                MainActivity mainActivity = (MainActivity) obj2;
                mainActivity.getSharedPreferences("settings", 0).edit().putString("app_language", ((String[]) obj)[i10]).apply();
                mainActivity.recreate();
                break;
            default:
                p041d3.c cVar = (p041d3.c) obj2;
                cVar.getClass();
                BluetoothDevice bluetoothDevice = (BluetoothDevice) ((ArrayList) obj).get(i10);
                bluetoothDevice.getName();
                bluetoothDevice.getAddress();
                p041d3.a aVar = new p041d3.a(cVar, 8);
                cVar.f21430j0 = aVar;
                cVar.f21429i0.postDelayed(aVar, 5000L);
                cVar.e0(bluetoothDevice.getAddress(), bluetoothDevice.getName());
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0020  */
    /* JADX WARN: Code duplicated, block: B:30:0x008e  */
    /* JADX WARN: Code duplicated, block: B:32:0x00a0  */
    /* JADX WARN: Code duplicated, block: B:37:0x00cb A[Catch: all -> 0x0153, TryCatch #0 {all -> 0x0153, blocks: (B:35:0x00c5, B:37:0x00cb, B:39:0x00db, B:40:0x00e7), top: B:57:0x00c5 }] */
    /* JADX WARN: Code duplicated, block: B:39:0x00db A[Catch: all -> 0x0153, TryCatch #0 {all -> 0x0153, blocks: (B:35:0x00c5, B:37:0x00cb, B:39:0x00db, B:40:0x00e7), top: B:57:0x00c5 }] */
    /* JADX WARN: Code duplicated, block: B:45:0x0106  */
    /* JADX WARN: Code duplicated, block: B:51:0x0135 A[LOOP:4: B:49:0x012f->B:51:0x0135, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:66:0x00a5 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:69:0x00e7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:71:0x0119 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:73:0x0100 A[SYNTHETIC] */
    @Override // C3.g
    public Object apply(Object obj) {
        HashMap map;
        StringBuilder sb2;
        int i10;
        Cursor cursorQuery;
        ListIterator listIterator;
        C3.b bVar;
        x xVarC;
        long j10;
        Set hashSet;
        boolean z3;
        switch (this.f78a) {
            case 3:
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                i iVar = (i) this.f79b;
                C3.a aVar = iVar.f1689d;
                int i11 = aVar.f1672b;
                p243v3.i iVar2 = (p243v3.i) this.f80c;
                ArrayList arrayListE = iVar.e(sQLiteDatabase, iVar2, i11);
                for (p213s3.d dVar : p213s3.d.values()) {
                    if (dVar != iVar2.f30375c) {
                        int size = aVar.f1672b - arrayListE.size();
                        if (size <= 0) {
                            map = new HashMap();
                            sb2 = new StringBuilder("event_id IN (");
                            for (i10 = 0; i10 < arrayListE.size(); i10++) {
                                sb2.append(((C3.b) arrayListE.get(i10)).f1676a);
                                if (i10 < arrayListE.size() - 1) {
                                    sb2.append(',');
                                }
                            }
                            sb2.append(')');
                            cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb2.toString(), null, null, null, null);
                            while (cursorQuery.moveToNext()) {
                                try {
                                    j10 = cursorQuery.getLong(0);
                                    hashSet = (Set) map.get(Long.valueOf(j10));
                                    if (hashSet == null) {
                                        hashSet = new HashSet();
                                        map.put(Long.valueOf(j10), hashSet);
                                    }
                                    hashSet.add(new h(cursorQuery.getString(1), cursorQuery.getString(2)));
                                } catch (Throwable th) {
                                    cursorQuery.close();
                                    throw th;
                                }
                            }
                            cursorQuery.close();
                            listIterator = arrayListE.listIterator();
                            while (listIterator.hasNext()) {
                                bVar = (C3.b) listIterator.next();
                                if (!map.containsKey(Long.valueOf(bVar.f1676a))) {
                                    xVarC = bVar.f1678c.c();
                                    long j11 = bVar.f1676a;
                                    for (h hVar : (Set) map.get(Long.valueOf(j11))) {
                                        xVarC.m(hVar.f1683a, hVar.f1684b);
                                    }
                                    listIterator.set(new C3.b(j11, bVar.f1677b, xVarC.p()));
                                }
                            }
                            return arrayListE;
                        }
                        Z2.f fVarA = p243v3.i.a();
                        fVarA.T(iVar2.f30373a);
                        if (dVar == null) {
                            throw new NullPointerException("Null priority");
                        }
                        fVarA.f14489c = dVar;
                        fVarA.f14488b = iVar2.f30374b;
                        arrayListE.addAll(iVar.e(sQLiteDatabase, fVarA.o(), size));
                    }
                }
                map = new HashMap();
                sb2 = new StringBuilder("event_id IN (");
                while (i10 < arrayListE.size()) {
                    sb2.append(((C3.b) arrayListE.get(i10)).f1676a);
                    if (i10 < arrayListE.size() - 1) {
                        sb2.append(',');
                    }
                }
                sb2.append(')');
                cursorQuery = sQLiteDatabase.query("event_metadata", new String[]{"event_id", "name", "value"}, sb2.toString(), null, null, null, null);
                while (cursorQuery.moveToNext()) {
                    j10 = cursorQuery.getLong(0);
                    hashSet = (Set) map.get(Long.valueOf(j10));
                    if (hashSet == null) {
                        hashSet = new HashSet();
                        map.put(Long.valueOf(j10), hashSet);
                    }
                    hashSet.add(new h(cursorQuery.getString(1), cursorQuery.getString(2)));
                }
                cursorQuery.close();
                listIterator = arrayListE.listIterator();
                while (listIterator.hasNext()) {
                    bVar = (C3.b) listIterator.next();
                    if (!map.containsKey(Long.valueOf(bVar.f1676a))) {
                        xVarC = bVar.f1678c.c();
                        long j12 = bVar.f1676a;
                        while (r5.hasNext()) {
                            xVarC.m(hVar.f1683a, hVar.f1684b);
                        }
                        listIterator.set(new C3.b(j12, bVar.f1677b, xVarC.p()));
                    }
                }
                return arrayListE;
            default:
                k kVar = (k) obj;
                if (((u) this.f79b).f(kVar)) {
                    z3 = true;
                } else {
                    if (((Set) this.f80c).contains(kVar.f22821a)) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                }
                return Boolean.valueOf(z3);
        }
    }

    @Override // D3.b
    public Object b() {
        switch (this.f78a) {
            case 1:
                i iVar = (i) ((m) this.f79b).f1091c;
                iVar.getClass();
                Iterable iterable = (Iterable) this.f80c;
                if (iterable.iterator().hasNext()) {
                    iVar.b().compileStatement("DELETE FROM events WHERE _id in " + i.i(iterable)).execute();
                    break;
                }
                break;
            default:
                m mVar = (m) this.f79b;
                mVar.getClass();
                for (Map.Entry entry : ((HashMap) this.f80c).entrySet()) {
                    ((i) mVar.f1097i).g(((Integer) entry.getValue()).intValue(), p275y3.c.INVALID_PAYLOD, (String) entry.getKey());
                }
                break;
        }
        return null;
    }

    @Override // p028c3.n
    public void c(int i10, String str) {
        int i11 = 4;
        int i12 = 2;
        Object obj = this.f79b;
        Object obj2 = this.f80c;
        switch (this.f78a) {
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                C0853c c0853c = (C0853c) obj2;
                if (c0853c.y()) {
                    switch (AbstractC1876h.c(i10)) {
                        case 0:
                        case 5:
                        case 6:
                            c0853c.f0((String) obj);
                            break;
                        case 1:
                            break;
                        case 2:
                            Toast.makeText(c0853c.W(), R.string.barrido_correo_no_verificado, 1).show();
                            break;
                        case 3:
                            Toast.makeText(c0853c.W(), R.string.toast_por_favor_espera_a_que_se_apruebe_tu_acceso, 1).show();
                            break;
                        case 4:
                            Toast.makeText(c0853c.W(), R.string.barrido_servicio_vencido, 1).show();
                            break;
                        default:
                            if (!TextUtils.isEmpty(str)) {
                                Toast.makeText(c0853c.W(), str, 1).show();
                            }
                            break;
                    }
                }
                break;
            case 11:
                AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t = (AbstractComponentCallbacksC0583t) obj;
                if (abstractComponentCallbacksC0583t.y()) {
                    int iC = AbstractC1876h.c(i10);
                    l0 l0Var = (l0) obj2;
                    if (iC == 1 || iC == 7) {
                        if (!TextUtils.isEmpty(str)) {
                            Toast.makeText(abstractComponentCallbacksC0583t.W(), str, 0).show();
                        }
                        B.i0(abstractComponentCallbacksC0583t, l0Var);
                    } else {
                        l0Var.l();
                    }
                    break;
                }
                break;
            default:
                ArrayList arrayList = p090h3.i.f23078A0;
                p090h3.i iVar = (p090h3.i) obj2;
                iVar.getClass();
                int iC2 = AbstractC1876h.c(i10);
                String str2 = (String) obj;
                if (iC2 == 0) {
                    iVar.l0(str2);
                    break;
                } else if (iC2 != 2) {
                    if (iC2 == 3) {
                        Toast.makeText(iVar.p(), R.string.toast_por_favor_espera_a_que_se_apruebe_tu_acceso, 1).show();
                        break;
                    } else if (iC2 == 4) {
                        if (iVar.p() != null) {
                            iVar.f23084i0.U(iVar.t(R.string.titulo_servicio_vencido), iVar.t(R.string.mensaje_servicio_vencido), iVar.t(R.string.boton_renovar_ahora), iVar.t(R.string.boton_mas_tarde), new p090h3.c(iVar, i11), null);
                            break;
                        }
                    } else if (iC2 == 5) {
                        iVar.h0();
                        break;
                    } else if (iC2 == 6) {
                        int i13 = Integer.parseInt(str);
                        iVar.f23084i0.X(iVar.t(R.string.titulo_renovar_servicio), i13 > 1 ? iVar.u(R.string.msg_renovar_servicio_dias, Integer.valueOf(i13)) : i13 == 1 ? iVar.t(R.string.msg_renovar_servicio_manana) : iVar.t(R.string.msg_renovar_servicio_hoy), new p090h3.d(iVar, str2, i12));
                        break;
                    } else if (str != null && !str.isEmpty()) {
                        Toast.makeText(iVar.p(), str, 0).show();
                        break;
                    }
                }
                break;
        }
    }

    @Override // R5.e
    public Object d(x xVar) {
        String strValueOf;
        switch (this.f78a) {
            case 0:
                Context context = (Context) xVar.a(Context.class);
                switch (((b) this.f80c).f71a) {
                    case 2:
                        ApplicationInfo applicationInfo = context.getApplicationInfo();
                        strValueOf = applicationInfo == null ? "" : String.valueOf(applicationInfo.targetSdkVersion);
                        break;
                    case 3:
                        ApplicationInfo applicationInfo2 = context.getApplicationInfo();
                        strValueOf = applicationInfo2 == null ? "" : String.valueOf(applicationInfo2.minSdkVersion);
                        break;
                    case 4:
                        int i10 = Build.VERSION.SDK_INT;
                        if (context.getPackageManager().hasSystemFeature("android.hardware.type.television")) {
                            strValueOf = "tv";
                        } else if (context.getPackageManager().hasSystemFeature("android.hardware.type.watch")) {
                            strValueOf = "watch";
                        } else if (!context.getPackageManager().hasSystemFeature("android.hardware.type.automotive")) {
                            strValueOf = (i10 >= 26 && context.getPackageManager().hasSystemFeature("android.hardware.type.embedded")) ? "embedded" : "";
                        } else {
                            strValueOf = "auto";
                        }
                        break;
                    default:
                        String installerPackageName = context.getPackageManager().getInstallerPackageName(context.getPackageName());
                        strValueOf = installerPackageName == null ? "" : FirebaseCommonRegistrar.a(installerPackageName);
                        break;
                }
                return new a((String) this.f79b, strValueOf);
            default:
                String str = (String) this.f79b;
                R5.b bVar = (R5.b) this.f80c;
                try {
                    Trace.beginSection(str);
                    return bVar.f11108f.d(xVar);
                } finally {
                    Trace.endSection();
                }
        }
    }

    @Override // p211s1.s
    public boolean e(View view) {
        q1 q1Var = (q1) this.f79b;
        p097ha.k.f(q1Var, "this$0");
        p1 p1Var = (p1) this.f80c;
        p097ha.k.f(view, "<anonymous parameter 0>");
        p169o6.h hVar = q1Var.f2164g;
        if (hVar == null) {
            return true;
        }
        R0 r0A = q1Var.a(p1Var.getBindingAdapterPosition());
        p097ha.k.f(r0A, "paymentMethod");
        ((l) hVar.f26364c).g(r0A).show();
        return true;
    }

    @Override // q6.a
    public void f(q6.b bVar) {
        ((q6.a) this.f79b).f(bVar);
        ((q6.a) this.f80c).f(bVar);
    }

    public void g(p253w2.e eVar, List list) {
        switch (this.f78a) {
            case 8:
                p278y6.s sVar = (p278y6.s) this.f79b;
                sVar.getClass();
                Purchase purchase = null;
                if (eVar.f31058a == 0 && list != null) {
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        Purchase purchase2 = (Purchase) it.next();
                        JSONObject jSONObject = purchase2.f18330c;
                        String strOptString = jSONObject.optString("obfuscatedAccountId");
                        C0242d c0242d = (strOptString == null && jSONObject.optString("obfuscatedProfileId") == null) ? null : new C0242d(strOptString, 3);
                        String str = c0242d != null ? c0242d.f3910b : null;
                        if (purchase2.a().contains("membresia_anual")) {
                            purchase2.f18330c.optInt("purchaseState", 1);
                            if (str == null || ((String) sVar.f32576b).equals(str)) {
                                purchase = purchase2;
                            }
                        }
                    }
                }
                if (purchase != null) {
                    sVar.s(new B3.e(11, sVar, purchase));
                } else {
                    sVar.s((Runnable) this.f80c);
                }
                break;
            default:
                p278y6.s sVar2 = (p278y6.s) this.f80c;
                sVar2.getClass();
                if (eVar.f31058a == 0) {
                    Iterator it2 = list.iterator();
                    while (it2.hasNext()) {
                        Purchase purchase3 = (Purchase) it2.next();
                        if (!"subs".equals((String) this.f79b) || !purchase3.f18330c.optBoolean("acknowledged", true)) {
                            sVar2.V(purchase3, false);
                        }
                    }
                    break;
                }
                break;
        }
    }

    @Override // p129k6.o
    public Object get() {
        Long lValueOf;
        Long lValueOf2;
        long jLongValue;
        switch (this.f78a) {
            case 15:
                p068f6.g gVar = (p068f6.g) this.f79b;
                l lVar = (l) this.f80c;
                p093h6.i iVar = (p093h6.i) lVar.f736b;
                P p10 = gVar.f22531c;
                AbstractC1018l abstractC1018l = (AbstractC1018l) lVar.f738d;
                p10.getClass();
                abstractC1018l.getClass();
                p10.f540f = abstractC1018l;
                p10.E();
                Iterator it = iVar.b().iterator();
                while (true) {
                    boolean zHasNext = it.hasNext();
                    ArrayList arrayList = (ArrayList) lVar.f740f;
                    List list = iVar.f23166d;
                    int i10 = 0;
                    if (!zHasNext) {
                        gVar.f22531c.y(iVar);
                        gVar.f22531c.t();
                        gVar.f22532d.R(iVar.f23163a);
                        p278y6.s sVar = gVar.f22534f;
                        HashSet hashSet = new HashSet();
                        while (i10 < arrayList.size()) {
                            if (!((j) arrayList.get(i10)).f23168b.isEmpty()) {
                                hashSet.add(((p093h6.h) list.get(i10)).f23160a);
                            }
                            i10++;
                        }
                        sVar.X(((Z2.f) sVar.f32576b).A(hashSet));
                        return gVar.f22534f.y(iVar.b());
                    }
                    p080g6.h hVar = (p080g6.h) it.next();
                    Z2.f fVar = gVar.f22533e;
                    k kVarZ = fVar.z(hVar);
                    p080g6.n nVar = (p080g6.n) ((T5.b) lVar.f739e).b(hVar);
                    Ua.d.D(nVar != null, "docVersions should contain every doc in the write.", new Object[0]);
                    if (kVarZ.f22823c.compareTo(nVar) < 0) {
                        int size = list.size();
                        Ua.d.D(arrayList.size() == size, "Mismatch between mutations length (%d) and results length (%d)", Integer.valueOf(size), Integer.valueOf(arrayList.size()));
                        while (i10 < size) {
                            p093h6.h hVar2 = (p093h6.h) list.get(i10);
                            if (hVar2.f23160a.equals(kVarZ.f22821a)) {
                                hVar2.b(kVarZ, (j) arrayList.get(i10));
                            }
                            i10++;
                        }
                        if (!AbstractC1876h.b(kVarZ.f22822b, 1)) {
                            fVar.l(kVarZ, (p080g6.n) lVar.f737c);
                        }
                    }
                }
                break;
            default:
                SparseArray sparseArray = ((p068f6.g) this.f79b).f22538j;
                p068f6.l lVar2 = (p068f6.l) this.f80c;
                C0794i c0794i = lVar2.f22552b;
                Object obj = lVar2.f22551a;
                p068f6.x xVar = (p068f6.x) ((D2.d) obj).f2407b;
                Cursor cursorC0 = xVar.g("PRAGMA page_count").c0();
                try {
                    if (cursorC0.moveToFirst()) {
                        lValueOf = Long.valueOf(cursorC0.getLong(0));
                        cursorC0.close();
                    } else {
                        cursorC0.close();
                        lValueOf = null;
                    }
                    long jLongValue2 = lValueOf.longValue();
                    Cursor cursorC1 = xVar.g("PRAGMA page_size").c0();
                    try {
                        Long lValueOf3 = cursorC1.moveToFirst() ? Long.valueOf(cursorC1.getLong(0)) : null;
                        cursorC1.close();
                        long jLongValue3 = lValueOf3.longValue() * jLongValue2;
                        if (jLongValue3 < 104857600) {
                            Ua.l.A(1, "LruGarbageCollector", "Garbage collection skipped; Cache size " + jLongValue3 + " is lower than threshold 104857600", new Object[0]);
                            return new p068f6.j();
                        }
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        p068f6.x xVar2 = (p068f6.x) ((D2.d) obj).f2407b;
                        long j10 = xVar2.f22596c.f22499f;
                        Cursor cursorC2 = xVar2.g("SELECT COUNT(*) FROM (SELECT sequence_number FROM target_documents GROUP BY path HAVING COUNT(*) = 1 AND target_id = 0)").c0();
                        try {
                            if (cursorC2.moveToFirst()) {
                                lValueOf2 = Long.valueOf(cursorC2.getLong(0));
                                cursorC2.close();
                            } else {
                                cursorC2.close();
                                lValueOf2 = null;
                            }
                            int iLongValue = (int) ((10 / 100.0f) * (lValueOf2.longValue() + j10));
                            if (iLongValue > 1000) {
                                Ua.l.A(1, "LruGarbageCollector", p096h9.i.i(iLongValue, "Capping sequence numbers to collect down to the maximum of 1000 from "), new Object[0]);
                                iLongValue = 1000;
                            }
                            long jCurrentTimeMillis2 = System.currentTimeMillis();
                            if (iLongValue == 0) {
                                jLongValue = -1;
                            } else {
                                final p068f6.k kVar = new p068f6.k();
                                kVar.f22547a = iLongValue;
                                kVar.f22548b = new PriorityQueue(iLongValue, p068f6.k.f22546c);
                                final int i11 = 0;
                                p129k6.h hVar3 = new p129k6.h() { // from class: f6.i
                                    @Override // p129k6.h
                                    public final void a(Object obj2) {
                                        switch (i11) {
                                            case 0:
                                                kVar.a(Long.valueOf(((D) obj2).f22502c));
                                                break;
                                            default:
                                                kVar.a((Long) obj2);
                                                break;
                                        }
                                    }
                                };
                                p068f6.B b10 = ((p068f6.x) ((D2.d) obj).f2407b).f22596c;
                                Cursor cursorC3 = b10.f22494a.g("SELECT target_proto FROM targets").c0();
                                while (cursorC3.moveToNext()) {
                                    try {
                                        hVar3.a(b10.a(cursorC3.getBlob(0)));
                                    } catch (Throwable th) {
                                        if (cursorC3 == null) {
                                            throw th;
                                        }
                                        try {
                                            cursorC3.close();
                                            throw th;
                                        } catch (Throwable th2) {
                                            th.addSuppressed(th2);
                                            throw th;
                                        }
                                    }
                                }
                                cursorC3.close();
                                final int i12 = 1;
                                p129k6.h hVar4 = new p129k6.h() { // from class: f6.i
                                    @Override // p129k6.h
                                    public final void a(Object obj2) {
                                        switch (i12) {
                                            case 0:
                                                kVar.a(Long.valueOf(((D) obj2).f22502c));
                                                break;
                                            default:
                                                kVar.a((Long) obj2);
                                                break;
                                        }
                                    }
                                };
                                Cursor cursorC4 = ((p068f6.x) ((D2.d) obj).f2407b).g("select sequence_number from target_documents group by path having COUNT(*) = 1 AND target_id = 0").c0();
                                while (cursorC4.moveToNext()) {
                                    try {
                                        hVar4.a(Long.valueOf(cursorC4.getLong(0)));
                                    } catch (Throwable th3) {
                                        if (cursorC4 == null) {
                                            throw th3;
                                        }
                                        try {
                                            cursorC4.close();
                                            throw th3;
                                        } catch (Throwable th4) {
                                            th3.addSuppressed(th4);
                                            throw th3;
                                        }
                                    }
                                }
                                cursorC4.close();
                                jLongValue = ((Long) ((PriorityQueue) kVar.f22548b).peek()).longValue();
                            }
                            long jCurrentTimeMillis3 = System.currentTimeMillis();
                            p068f6.B b11 = ((p068f6.x) ((D2.d) obj).f2407b).f22596c;
                            int[] iArr = new int[1];
                            Z2.f fVarG = b11.f22494a.g("SELECT target_id FROM targets WHERE last_listen_sequence_number <= ?");
                            fVarG.n(Long.valueOf(jLongValue));
                            fVarG.y(new t(b11, sparseArray, iArr, 1));
                            b11.f();
                            int i13 = iArr[0];
                            long jCurrentTimeMillis4 = System.currentTimeMillis();
                            final D2.d dVar = (D2.d) obj;
                            dVar.getClass();
                            final int[] iArr2 = new int[1];
                            final ArrayList arrayList2 = new ArrayList();
                            final p080g6.m[] mVarArr = {p080g6.m.f22829b};
                            while (true) {
                                p068f6.x xVar3 = (p068f6.x) dVar.f2407b;
                                Z2.f fVarG2 = xVar3.g("select path from target_documents group by path having COUNT(*) = 1 AND target_id = 0 AND sequence_number <= ? AND path > ? LIMIT ?");
                                long j11 = jCurrentTimeMillis2;
                                long j12 = jLongValue;
                                fVarG2.n(Long.valueOf(jLongValue), p054e4.e.W(mVarArr[0]), 100);
                                if (fVarG2.y(new p129k6.h() { // from class: f6.s
                                    @Override // p129k6.h
                                    public final void a(Object obj2) {
                                        boolean zMoveToFirst;
                                        d dVar2 = dVar;
                                        dVar2.getClass();
                                        p080g6.m mVarT = e.T(((Cursor) obj2).getString(0));
                                        p080g6.h hVar5 = new p080g6.h(mVarT);
                                        boolean zD = ((p056e7.n) dVar2.f2410e).d(hVar5);
                                        x xVar4 = (x) dVar2.f2407b;
                                        p080g6.m mVar = hVar5.f22816a;
                                        if (zD) {
                                            zMoveToFirst = true;
                                        } else {
                                            Z2.f fVarG3 = xVar4.g("SELECT 1 FROM document_mutations WHERE path = ?");
                                            fVarG3.n(e.W(mVar));
                                            Cursor cursorC5 = fVarG3.c0();
                                            try {
                                                zMoveToFirst = cursorC5.moveToFirst();
                                                cursorC5.close();
                                            } catch (Throwable th5) {
                                                if (cursorC5 != null) {
                                                    try {
                                                        cursorC5.close();
                                                    } catch (Throwable th6) {
                                                        th5.addSuppressed(th6);
                                                    }
                                                }
                                                throw th5;
                                            }
                                        }
                                        if (!zMoveToFirst) {
                                            int[] iArr3 = iArr2;
                                            iArr3[0] = iArr3[0] + 1;
                                            arrayList2.add(hVar5);
                                            xVar4.b("DELETE FROM target_documents WHERE path = ? AND target_id = 0", e.W(mVar));
                                        }
                                        mVarArr[0] = mVarT;
                                    }
                                }) != 100) {
                                    xVar3.f22597d.Q(arrayList2);
                                    int i14 = iArr2[0];
                                    long jCurrentTimeMillis5 = System.currentTimeMillis();
                                    StringBuilder sbF = p015b2.a.f(AbstractC0492c.n(new StringBuilder("LRU Garbage Collection:\n\tCounted targets in "), j11 - jCurrentTimeMillis, "ms\n"));
                                    Locale locale = Locale.ROOT;
                                    sbF.append("\tDetermined least recently used " + iLongValue + " sequence numbers in " + (jCurrentTimeMillis3 - j11) + "ms\n");
                                    StringBuilder sbF2 = p015b2.a.f(sbF.toString());
                                    sbF2.append("\tRemoved " + i13 + " targets in " + (jCurrentTimeMillis4 - jCurrentTimeMillis3) + "ms\n");
                                    StringBuilder sbF3 = p015b2.a.f(sbF2.toString());
                                    sbF3.append("\tRemoved " + i14 + " documents in " + (jCurrentTimeMillis5 - jCurrentTimeMillis4) + "ms\n");
                                    StringBuilder sbF4 = p015b2.a.f(sbF3.toString());
                                    StringBuilder sb2 = new StringBuilder("Total Duration: ");
                                    sb2.append(jCurrentTimeMillis5 - jCurrentTimeMillis);
                                    sb2.append("ms");
                                    sbF4.append(sb2.toString());
                                    Ua.l.A(1, "LruGarbageCollector", sbF4.toString(), new Object[0]);
                                    return new p068f6.j();
                                }
                                jCurrentTimeMillis2 = j11;
                                jLongValue = j12;
                            }
                        } catch (Throwable th5) {
                            if (cursorC2 == null) {
                                throw th5;
                            }
                            try {
                                cursorC2.close();
                                throw th5;
                            } catch (Throwable th6) {
                                th5.addSuppressed(th6);
                                throw th5;
                            }
                        }
                        break;
                    } catch (Throwable th7) {
                        if (cursorC1 == null) {
                            throw th7;
                        }
                        try {
                            cursorC1.close();
                            throw th7;
                        } catch (Throwable th8) {
                            th7.addSuppressed(th8);
                            throw th7;
                        }
                    }
                } catch (Throwable th9) {
                    if (cursorC0 == null) {
                        throw th9;
                    }
                    try {
                        cursorC0.close();
                        throw th9;
                    } catch (Throwable th10) {
                        th9.addSuppressed(th10);
                        throw th9;
                    }
                }
                break;
        }
    }

    @Override // com.google.android.gms.tasks.Continuation
    public Object then(Task task) throws Exception {
        switch (this.f78a) {
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                C0877b c0877b = (C0877b) this.f79b;
                boolean zIsSuccessful = task.isSuccessful();
                TaskCompletionSource taskCompletionSource = (TaskCompletionSource) this.f80c;
                if (zIsSuccessful) {
                    taskCompletionSource.setResult(new C0878c(c0877b, (Map) task.getResult()));
                    return null;
                }
                taskCompletionSource.setException(task.getException());
                return null;
            case 19:
                p119j6.h hVar = (p119j6.h) this.f79b;
                hVar.getClass();
                if (!task.isSuccessful()) {
                    if ((task.getException() instanceof p019b6.t) && ((p019b6.t) task.getException()).f17669a == p019b6.s.UNAUTHENTICATED) {
                        p119j6.n nVar = hVar.f24079c;
                        nVar.f24104b.U();
                        nVar.f24105c.T();
                    }
                    throw task.getException();
                }
                HashMap map = new HashMap();
                for (Map.Entry entry : ((O) task.getResult()).u().t().entrySet()) {
                    Object key = entry.getKey();
                    HashMap map2 = (HashMap) this.f80c;
                    Ua.d.D(map2.containsKey(key), "%s not present in aliasMap", entry.getKey());
                    map.put((String) map2.get(entry.getKey()), (F0) entry.getValue());
                }
                return map;
            case 20:
                x xVar = (x) this.f79b;
                xVar.getClass();
                return Tasks.forResult(((T) task.getResult()).o((g0) this.f80c, (C0243e) xVar.f2613d));
            default:
                p278y6.i iVar = (p278y6.i) this.f80c;
                String str = (String) this.f79b;
                synchronized (iVar) {
                    ((p240v.b) iVar.f32555b).remove(str);
                    break;
                }
                return task;
        }
    }

    public /* synthetic */ e(String str, int i10, Object obj) {
        this.f78a = i10;
        this.f80c = obj;
        this.f79b = str;
    }
}
