package A6;

import B2.C0057h;
import B2.r;
import B2.v;
import C.x;
import C9.C;
import C9.D1;
import C9.E1;
import F2.C0213d;
import F2.D;
import F2.G;
import F2.H;
import F2.t;
import F2.u;
import F2.z;
import G6.F0;
import G6.y0;
import H9.InterfaceC0324a1;
import H9.T0;
import I.AbstractC0404c0;
import I.N;
import I.O;
import Ka.n;
import M4.h;
import N1.C0587x;
import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.Editable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.behavior.SwipeDismissBehavior;
import com.stripe.android.view.CardInputWidget;
import com.stripe.android.view.CardMultilineWidget;
import com.stripe.android.view.CardNumberEditText;
import com.stripe.android.view.StripeEditText;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.AEADBadTagException;
import p088h1.g;
import p097ha.k;
import p175p.S0;
import p183p8.C1376c;
import p183p8.EnumC1394i;
import p200r1.U;
import p211s1.s;

/* JADX INFO: loaded from: classes.dex */
public final class d implements W2.a, E1, D1, p056e7.b, s, u, p286z2.b, G, InterfaceC0324a1, N, I4.a, p082g8.a, h {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static volatile d f74c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Method f75d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f76a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f77b;

    public /* synthetic */ d(Object obj, int i10) {
        this.f76a = i10;
        this.f77b = obj;
    }

    @Override // p082g8.a
    public p070f8.c a() {
        return new p070f8.c((p070f8.b) ((S9.a) this.f77b).get());
    }

    @Override // F2.G
    public com.bumptech.glide.load.data.e b(Uri uri) {
        return new com.bumptech.glide.load.data.a((ContentResolver) this.f77b, uri, 1);
    }

    @Override // W2.a
    public Object c() {
        S0 s5 = (S0) this.f77b;
        return new v((E2.e) s5.f26475a, (E2.e) s5.f26476b, (E2.e) s5.f26477c, (E2.e) s5.f26478d, (r) s5.f26479e, (r) s5.f26480f, (C0057h) s5.f26481g);
    }

    @Override // p211s1.s
    public boolean e(View view) {
        switch (this.f76a) {
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                SwipeDismissBehavior swipeDismissBehavior = (SwipeDismissBehavior) this.f77b;
                if (!swipeDismissBehavior.w(view)) {
                    return false;
                }
                WeakHashMap weakHashMap = U.f27683a;
                boolean z3 = view.getLayoutDirection() == 1;
                int i10 = swipeDismissBehavior.f19182e;
                view.offsetLeftAndRight((!(i10 == 0 && z3) && (i10 != 1 || z3)) ? view.getWidth() : -view.getWidth());
                view.setAlpha(0.0f);
                g gVar = swipeDismissBehavior.f19179b;
                if (gVar != null) {
                    gVar.t(view);
                }
                return true;
            default:
                DrawerLayout drawerLayout = (DrawerLayout) this.f77b;
                if (!DrawerLayout.k(view) || drawerLayout.g(view) == 2) {
                    return false;
                }
                drawerLayout.b(view, true);
                return true;
        }
    }

    @Override // p056e7.b
    public void f(C1376c c1376c) {
        EnumC1394i enumC1394i;
        CardNumberEditText cardNumberEditText = (CardNumberEditText) this.f77b;
        CardNumberEditText.f(cardNumberEditText);
        if (c1376c == null || (enumC1394i = c1376c.f27008c.f26992b) == null) {
            enumC1394i = EnumC1394i.Unknown;
        }
        cardNumberEditText.setCardBrand$payments_core_release(enumC1394i);
    }

    @Override // C9.D1
    public void g(String str) {
        switch (this.f76a) {
            case 5:
                CardInputWidget cardInputWidget = (CardInputWidget) this.f77b;
                if (cardInputWidget.getPostalCodeEditText$payments_core_release().isEnabled()) {
                    cardInputWidget.getPostalCodeEditText$payments_core_release().d();
                }
                break;
            default:
                CardMultilineWidget cardMultilineWidget = (CardMultilineWidget) this.f77b;
                if (cardMultilineWidget.f21232z.c(str)) {
                    cardMultilineWidget.c();
                    if (cardMultilineWidget.f21217a) {
                        cardMultilineWidget.getPostalCodeEditText$payments_core_release().requestFocus();
                    }
                } else if (!cardMultilineWidget.f21211E) {
                    cardMultilineWidget.b();
                }
                cardMultilineWidget.getCvcEditText().setShouldShowError(false);
                break;
        }
    }

    @Override // F2.u
    public t h(z zVar) {
        switch (this.f76a) {
            case 11:
                return new C0213d((D) this.f77b, 1);
            default:
                return new H(this);
        }
    }

    @Override // I.N
    public int i(KeyEvent keyEvent) {
        int i10 = 0;
        if (keyEvent.isShiftPressed() && keyEvent.isCtrlPressed()) {
            long jC = p168o5.b.c(keyEvent.getKeyCode());
            if (p143m0.a.a(jC, AbstractC0404c0.f5421i)) {
                i10 = 35;
            } else if (p143m0.a.a(jC, AbstractC0404c0.f5422j)) {
                i10 = 36;
            } else if (p143m0.a.a(jC, AbstractC0404c0.k)) {
                i10 = 38;
            } else if (p143m0.a.a(jC, AbstractC0404c0.f5423l)) {
                i10 = 37;
            }
        } else if (keyEvent.isCtrlPressed()) {
            long jC2 = p168o5.b.c(keyEvent.getKeyCode());
            if (p143m0.a.a(jC2, AbstractC0404c0.f5421i)) {
                i10 = 4;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5422j)) {
                i10 = 3;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.k)) {
                i10 = 6;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5423l)) {
                i10 = 5;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5415c)) {
                i10 = 20;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5431t)) {
                i10 = 23;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5430s)) {
                i10 = 22;
            } else if (p143m0.a.a(jC2, AbstractC0404c0.f5420h)) {
                i10 = 43;
            }
        } else if (keyEvent.isShiftPressed()) {
            long jC3 = p168o5.b.c(keyEvent.getKeyCode());
            if (p143m0.a.a(jC3, AbstractC0404c0.f5426o)) {
                i10 = 41;
            } else if (p143m0.a.a(jC3, AbstractC0404c0.f5427p)) {
                i10 = 42;
            }
        } else if (keyEvent.isAltPressed()) {
            long jC4 = p168o5.b.c(keyEvent.getKeyCode());
            if (p143m0.a.a(jC4, AbstractC0404c0.f5430s)) {
                i10 = 24;
            } else if (p143m0.a.a(jC4, AbstractC0404c0.f5431t)) {
                i10 = 25;
            }
        }
        return i10 == 0 ? ((O) this.f77b).i(keyEvent) : i10;
    }

    public byte[] j(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        if (bArr.length < 40) {
            throw new GeneralSecurityException("ciphertext too short");
        }
        byte[] bArrCopyOf = Arrays.copyOf(bArr, 24);
        ByteBuffer byteBufferWrap = ByteBuffer.wrap(bArr, 24, bArr.length - 24);
        p169o6.h hVar = (p169o6.h) this.f77b;
        hVar.getClass();
        if (byteBufferWrap.remaining() < 16) {
            throw new GeneralSecurityException("ciphertext too short");
        }
        int iPosition = byteBufferWrap.position();
        byte[] bArr3 = new byte[16];
        byteBufferWrap.position(byteBufferWrap.limit() - 16);
        byteBufferWrap.get(bArr3);
        byteBufferWrap.position(iPosition);
        byteBufferWrap.limit(byteBufferWrap.limit() - 16);
        if (bArr2 == null) {
            bArr2 = new byte[0];
        }
        try {
            byte[] bArr4 = new byte[32];
            ((B5.b) hVar.f26364c).a(bArrCopyOf, 0).get(bArr4);
            byte[] bArrX = Ua.d.x(bArr4, p169o6.h.R(bArr2, byteBufferWrap));
            int i10 = 0;
            for (int i11 = 0; i11 < 16; i11++) {
                i10 |= bArrX[i11] ^ bArr3[i11];
            }
            if (i10 != 0) {
                throw new GeneralSecurityException("invalid MAC");
            }
            byteBufferWrap.position(iPosition);
            B5.b bVar = (B5.b) hVar.f26363b;
            bVar.getClass();
            ByteBuffer byteBufferAllocate = ByteBuffer.allocate(byteBufferWrap.remaining());
            bVar.d(bArrCopyOf, byteBufferAllocate, byteBufferWrap);
            return byteBufferAllocate.array();
        } catch (GeneralSecurityException e10) {
            throw new AEADBadTagException(e10.toString());
        }
    }

    public byte[] k(byte[] bArr, byte[] bArr2) throws GeneralSecurityException {
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(bArr.length + 40);
        byte[] bArr3 = new byte[24];
        ((SecureRandom) D5.b.f2475a.get()).nextBytes(bArr3);
        byteBufferAllocate.put(bArr3);
        p169o6.h hVar = (p169o6.h) this.f77b;
        hVar.getClass();
        if (byteBufferAllocate.remaining() < bArr.length + 16) {
            throw new IllegalArgumentException("Given ByteBuffer output is too small");
        }
        int iPosition = byteBufferAllocate.position();
        B5.b bVar = (B5.b) hVar.f26363b;
        bVar.getClass();
        if (byteBufferAllocate.remaining() < bArr.length) {
            throw new IllegalArgumentException("Given ByteBuffer output is too small");
        }
        bVar.d(bArr3, byteBufferAllocate, ByteBuffer.wrap(bArr));
        byteBufferAllocate.position(iPosition);
        byteBufferAllocate.limit(byteBufferAllocate.limit() - 16);
        if (bArr2 == null) {
            bArr2 = new byte[0];
        }
        ByteBuffer byteBufferA = ((B5.b) hVar.f26364c).a(bArr3, 0);
        byte[] bArr4 = new byte[32];
        byteBufferA.get(bArr4);
        byte[] bArrX = Ua.d.x(bArr4, p169o6.h.R(bArr2, byteBufferAllocate));
        byteBufferAllocate.limit(byteBufferAllocate.limit() + 16);
        byteBufferAllocate.put(bArrX);
        return byteBufferAllocate.array();
    }

    public Object l(Ga.g gVar, n nVar) {
        k.f(gVar, "descriptor");
        Map map = (Map) ((ConcurrentHashMap) this.f77b).get(gVar);
        Object obj = map != null ? map.get(nVar) : null;
        if (obj == null) {
            return null;
        }
        return obj;
    }

    public Integer m(int i10) {
        Object obj;
        List listB = ((C.D) this.f77b).h().b();
        int size = listB.size();
        int i11 = 0;
        while (true) {
            if (i11 >= size) {
                obj = null;
                break;
            }
            obj = listB.get(i11);
            if (((x) obj).f1549a == i10) {
                break;
            }
            i11++;
        }
        x xVar = (x) obj;
        if (xVar != null) {
            return Integer.valueOf(xVar.f1560m);
        }
        return null;
    }

    public void n() {
        ((C0587x) this.f77b).f9273f.P();
    }

    @Override // p286z2.b
    public boolean o(Object obj, File file, p286z2.h hVar) throws Throwable {
        InputStream inputStream = (InputStream) obj;
        C2.g gVar = (C2.g) this.f77b;
        byte[] bArr = (byte[]) gVar.d(65536, byte[].class);
        FileOutputStream fileOutputStream = null;
        try {
            try {
                FileOutputStream fileOutputStream2 = new FileOutputStream(file);
                while (true) {
                    try {
                        int i10 = inputStream.read(bArr);
                        if (i10 == -1) {
                            break;
                        }
                        fileOutputStream2.write(bArr, 0, i10);
                    } catch (IOException e10) {
                        e = e10;
                        fileOutputStream = fileOutputStream2;
                        if (Log.isLoggable("StreamEncoder", 3)) {
                            Log.d("StreamEncoder", "Failed to encode data onto the OutputStream", e);
                        }
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (IOException unused) {
                            }
                        }
                        gVar.i(bArr);
                        return false;
                    } catch (Throwable th) {
                        th = th;
                        fileOutputStream = fileOutputStream2;
                        if (fileOutputStream != null) {
                            try {
                                fileOutputStream.close();
                            } catch (IOException unused2) {
                            }
                        }
                        gVar.i(bArr);
                        throw th;
                    }
                }
                fileOutputStream2.close();
                try {
                    fileOutputStream2.close();
                } catch (IOException unused3) {
                }
                gVar.i(bArr);
                return true;
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (IOException e11) {
            e = e11;
        }
    }

    public void p() {
        String string;
        StripeEditText stripeEditText = (StripeEditText) this.f77b;
        Editable text = stripeEditText.getText();
        if (text == null || (string = text.toString()) == null) {
            string = "";
        }
        if (string.length() > 1) {
            String strSubstring = string.substring(0, string.length() - 1);
            k.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
            stripeEditText.setText(strSubstring);
        }
        stripeEditText.requestFocus();
        stripeEditText.setSelection(stripeEditText.length());
    }

    public void q(boolean z3) {
        T0 t10 = (T0) this.f77b;
        t10.f4870c0.A(t10.f4850H, z3);
    }

    public d(StripeEditText stripeEditText) {
        this.f76a = 4;
        k.f(stripeEditText, "backUpTarget");
        this.f77b = stripeEditText;
    }

    public d(C.D d10) {
        this.f76a = 3;
        k.f(d10, "state");
        this.f77b = d10;
    }

    public d(Context context) {
        this.f76a = 8;
        this.f77b = new C(context, 1);
    }

    public d(Typeface typeface) {
        this.f76a = 22;
        k.f(typeface, "typeface");
        this.f77b = typeface;
    }

    public d(int i10) {
        this.f76a = i10;
        switch (i10) {
            case 11:
                this.f77b = new D(7);
                break;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                this.f77b = new HashMap();
                break;
            case 23:
                this.f77b = new WeakHashMap();
                break;
            case 25:
                break;
            case 26:
                this.f77b = new ConcurrentHashMap(16);
                break;
            case 29:
                this.f77b = new AtomicInteger(0);
                break;
            default:
                this.f77b = new HashSet();
                break;
        }
    }

    public d(byte[] bArr) {
        this.f76a = 9;
        this.f77b = new p169o6.h(bArr);
    }

    public d(EditText editText) {
        this.f76a = 24;
        this.f77b = new p169o6.h(editText);
    }
}
