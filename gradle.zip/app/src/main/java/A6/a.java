package A6;

import p032c7.AbstractC0933i;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f69a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f70b;

    public a(String str, String str2) {
        this.f69a = str;
        if (str2 == null) {
            throw new NullPointerException("Null version");
        }
        this.f70b = str2;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof a) {
            a aVar = (a) obj;
            if (this.f69a.equals(aVar.f69a) && this.f70b.equals(aVar.f70b)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return ((this.f69a.hashCode() ^ 1000003) * 1000003) ^ this.f70b.hashCode();
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("LibraryVersion{libraryName=");
        sb2.append(this.f69a);
        sb2.append(", version=");
        return AbstractC0933i.i(sb2, this.f70b, "}");
    }
}
