package A7;

import B.AbstractC0034p;
import O.AbstractC0630v;
import O.C0629u;

/* JADX INFO: loaded from: classes.dex */
public final class x extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f198a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z.m f199b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ x(Z.m mVar, int i10, int i11) {
        super(2);
        this.f198a = i11;
        this.f199b = mVar;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        int i10 = this.f198a;
        C0629u c0629u = (C0629u) obj;
        ((Number) obj2).intValue();
        switch (i10) {
            case 0:
                p029c4.a.R(this.f199b, c0629u, AbstractC0630v.S(1));
                break;
            default:
                AbstractC0034p.a(this.f199b, c0629u, AbstractC0630v.S(1));
                break;
        }
        return T9.w.f11979a;
    }
}
