package A7;

import B.AbstractC0027i;
import B.AbstractC0037t;
import B.C0022d;
import B.C0038u;
import B.S;
import B.T;
import G6.F0;
import G6.y0;
import L.AbstractC0492c;
import L.J;
import L.f2;
import L.g2;
import L.h2;
import O.AbstractC0630v;
import O.C0617n0;
import O.C0629u;
import O.R0;
import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.view.View;
import android.view.ViewParent;
import android.view.Window;
import p016b3.AbstractC0862l;
import p199r0.AbstractC1464s;
import p220t0.C1593j;
import p220t0.C1598o;
import p220t0.InterfaceC1594k;
import p232u0.B0;
import p232u0.W;

/* JADX INFO: loaded from: classes.dex */
public final class E extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f98a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ V.a f99b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f100c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ E(V.a aVar, int i10, int i11) {
        super(2);
        this.f98a = i11;
        this.f99b = aVar;
        this.f100c = i10;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f98a) {
            case 0:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    float f10 = 24;
                    Z.m mVarK = androidx.compose.foundation.layout.c.k(Z.j.f14412b, f10, 16, f10, f10);
                    int i10 = (this.f100c << 6) & 7168;
                    c0629u.a0(-483455358);
                    p199r0.B bA = AbstractC0037t.a(AbstractC0027i.f621c, Z.a.f14399v, c0629u);
                    c0629u.a0(-1323940314);
                    N0.b bVar = (N0.b) c0629u.l(W.f29758e);
                    N0.j jVar = (N0.j) c0629u.l(W.k);
                    B0 b10 = (B0) c0629u.l(W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o = C1593j.f29148b;
                    V.a aVarI = p195q8.h.i(mVarK);
                    c0629u.d0();
                    if (c0629u.M) {
                        c0629u.n(c1598o);
                    } else {
                        c0629u.o0();
                    }
                    c0629u.f9699x = false;
                    AbstractC0630v.P(c0629u, C1593j.f29152f, bA);
                    AbstractC0630v.P(c0629u, C1593j.f29150d, bVar);
                    AbstractC0630v.P(c0629u, C1593j.f29153g, jVar);
                    AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u, b10, C1593j.f29154h, c0629u), c0629u, 2058660585);
                    this.f99b.I(C0038u.f659a, c0629u, Integer.valueOf(((i10 >> 6) & 112) | 6));
                    AbstractC1464s.n(c0629u, false, true, false, false);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    f2.a(((g2) c0629u2.l(h2.f7898a)).f7883g, this.f99b, c0629u2, (this.f100c >> 3) & 112);
                }
                break;
            case 2:
                C0629u c0629u3 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    AbstractC0630v.b(new C0617n0[]{J.f7416a.b(Float.valueOf(AbstractC0862l.M(6, c0629u3)))}, Ua.l.u(c0629u3, 770166432, new E(this.f99b, this.f100c, 1)), c0629u3, 56);
                }
                break;
            case 3:
                C0629u c0629u4 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    f2.a(((g2) c0629u4.l(h2.f7898a)).f7886j, this.f99b, c0629u4, (this.f100c >> 6) & 112);
                }
                break;
            case 4:
                C0629u c0629u5 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    AbstractC0630v.b(new C0617n0[]{J.f7416a.b(Float.valueOf(AbstractC0862l.N(c0629u5)))}, Ua.l.u(c0629u5, 2115920639, new E(this.f99b, this.f100c, 3)), c0629u5, 56);
                }
                break;
            case 5:
                C0629u c0629u6 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u6.C()) {
                    c0629u6.U();
                } else {
                    AbstractC0630v.b(new C0617n0[]{J.f7416a.b(Float.valueOf(AbstractC0862l.M(6, c0629u6)))}, this.f99b, c0629u6, ((this.f100c << 3) & 112) | 8);
                }
                break;
            case 6:
                C0629u c0629u7 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u7.C()) {
                    c0629u7.U();
                } else {
                    Z.m mVarB = androidx.compose.foundation.layout.d.b(Z.j.f14412b, 1.0f);
                    C0022d c0022d = AbstractC0027i.f620b;
                    Z.c cVar = Z.a.f14397t;
                    int i11 = (this.f100c & 7168) | 438;
                    c0629u7.a0(693286680);
                    p199r0.B bA2 = S.a(c0022d, cVar, c0629u7);
                    c0629u7.a0(-1323940314);
                    N0.b bVar2 = (N0.b) c0629u7.l(W.f29758e);
                    N0.j jVar2 = (N0.j) c0629u7.l(W.k);
                    B0 b11 = (B0) c0629u7.l(W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o2 = C1593j.f29148b;
                    V.a aVarI2 = p195q8.h.i(mVarB);
                    c0629u7.d0();
                    if (c0629u7.M) {
                        c0629u7.n(c1598o2);
                    } else {
                        c0629u7.o0();
                    }
                    c0629u7.f9699x = false;
                    AbstractC0630v.P(c0629u7, C1593j.f29152f, bA2);
                    AbstractC0630v.P(c0629u7, C1593j.f29150d, bVar2);
                    AbstractC0630v.P(c0629u7, C1593j.f29153g, jVar2);
                    aVarI2.I(AbstractC0492c.g(c0629u7, b11, C1593j.f29154h, c0629u7, c0629u7), c0629u7, 0);
                    c0629u7.a0(2058660585);
                    this.f99b.I(T.f545a, c0629u7, Integer.valueOf(((i11 >> 6) & 112) | 6));
                    AbstractC1464s.n(c0629u7, false, true, false, false);
                }
                break;
            case 7:
                C0629u c0629u8 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u8.C()) {
                    c0629u8.U();
                } else {
                    p054e4.e.n(this.f99b, c0629u8, (this.f100c >> 9) & 14);
                }
                break;
            case 8:
                ((Number) obj2).intValue();
                p054e4.e.n(this.f99b, (C0629u) obj, AbstractC0630v.S(this.f100c | 1));
                break;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                C0629u c0629u9 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u9.C()) {
                    c0629u9.U();
                } else {
                    int i12 = (this.f100c << 9) & 7168;
                    c0629u9.a0(-483455358);
                    Z.j jVar3 = Z.j.f14412b;
                    p199r0.B bA3 = AbstractC0037t.a(AbstractC0027i.f621c, Z.a.f14399v, c0629u9);
                    c0629u9.a0(-1323940314);
                    N0.b bVar3 = (N0.b) c0629u9.l(W.f29758e);
                    N0.j jVar4 = (N0.j) c0629u9.l(W.k);
                    B0 b12 = (B0) c0629u9.l(W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o3 = C1593j.f29148b;
                    V.a aVarI3 = p195q8.h.i(jVar3);
                    c0629u9.d0();
                    if (c0629u9.M) {
                        c0629u9.n(c1598o3);
                    } else {
                        c0629u9.o0();
                    }
                    c0629u9.f9699x = false;
                    AbstractC0630v.P(c0629u9, C1593j.f29152f, bA3);
                    AbstractC0630v.P(c0629u9, C1593j.f29150d, bVar3);
                    AbstractC0630v.P(c0629u9, C1593j.f29153g, jVar4);
                    aVarI3.I(AbstractC0492c.g(c0629u9, b12, C1593j.f29154h, c0629u9, c0629u9), c0629u9, 0);
                    c0629u9.a0(2058660585);
                    this.f99b.I(C0038u.f659a, c0629u9, Integer.valueOf(((i12 >> 6) & 112) | 6));
                    AbstractC1464s.n(c0629u9, false, true, false, false);
                }
                break;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                C0629u c0629u10 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u10.C()) {
                    c0629u10.U();
                } else {
                    p097ha.k.c(null);
                    this.f99b.I(null, c0629u10, Integer.valueOf((this.f100c >> 3) & 112));
                }
                break;
            case 11:
                C0629u c0629u11 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u11.C()) {
                    c0629u11.U();
                } else {
                    this.f99b.invoke(c0629u11, Integer.valueOf(this.f100c & 14));
                }
                break;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                C0629u c0629u12 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u12.C()) {
                    c0629u12.U();
                } else {
                    AbstractC0630v.b(new C0617n0[]{K.E.f6673a.b(Z7.g.f14780c), N.v.f8946a.b(Z7.c.f14755a)}, Ua.l.u(c0629u12, -1499577148, new C0010c(this.f99b, this.f100c, 5)), c0629u12, 56);
                }
                break;
            case 13:
                C0629u c0629u13 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u13.C()) {
                    c0629u13.U();
                } else {
                    R0 r7 = p232u0.H.f29682f;
                    View view = (View) c0629u13.l(r7);
                    c0629u13.a0(-1994167690);
                    ViewParent parent = ((View) c0629u13.l(r7)).getParent();
                    Window window = null;
                    Q0.q qVar = parent instanceof Q0.q ? (Q0.q) parent : null;
                    Window window2 = qVar != null ? ((Q0.o) qVar).f10662s : null;
                    if (window2 == null) {
                        Context context = ((View) c0629u13.l(r7)).getContext();
                        p097ha.k.e(context, "LocalView.current.context");
                        while (true) {
                            if (context instanceof Activity) {
                                window = ((Activity) context).getWindow();
                            } else if (context instanceof ContextWrapper) {
                                context = ((ContextWrapper) context).getBaseContext();
                                p097ha.k.e(context, "baseContext");
                            }
                        }
                        window2 = window;
                    }
                    c0629u13.u(false);
                    c0629u13.a0(-2124194779);
                    Z7.b bVar4 = (Z7.b) c0629u13.l(Z7.g.f14782e);
                    c0629u13.u(false);
                    long j10 = bVar4.f14740d;
                    c0629u13.a0(-1654389416);
                    if (!view.isInEditMode()) {
                        AbstractC0630v.g(new Z7.e(window2, view, j10), c0629u13);
                    }
                    c0629u13.u(false);
                    long j11 = p050e0.q.f21750g;
                    com.bumptech.glide.e.d(new L.B(j11, j11, j11, j11, j11, j11, j11, j11, j11, j11, j11, j11, true), null, null, Ua.l.u(c0629u13, -705179260, new E(this.f99b, this.f100c, 12)), c0629u13, 3072, 6);
                }
                break;
            default:
                C0629u c0629u14 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u14.C()) {
                    c0629u14.U();
                } else {
                    c0629u14.a0(-483455358);
                    Z.j jVar5 = Z.j.f14412b;
                    p199r0.B bA4 = AbstractC0037t.a(AbstractC0027i.f621c, Z.a.f14399v, c0629u14);
                    c0629u14.a0(-1323940314);
                    N0.b bVar5 = (N0.b) c0629u14.l(W.f29758e);
                    N0.j jVar6 = (N0.j) c0629u14.l(W.k);
                    B0 b13 = (B0) c0629u14.l(W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o4 = C1593j.f29148b;
                    V.a aVarI4 = p195q8.h.i(jVar5);
                    c0629u14.d0();
                    if (c0629u14.M) {
                        c0629u14.n(c1598o4);
                    } else {
                        c0629u14.o0();
                    }
                    c0629u14.f9699x = false;
                    AbstractC0630v.P(c0629u14, C1593j.f29152f, bA4);
                    AbstractC0630v.P(c0629u14, C1593j.f29150d, bVar5);
                    AbstractC0630v.P(c0629u14, C1593j.f29153g, jVar6);
                    AbstractC1464s.m(0, aVarI4, p015b2.a.c(c0629u14, b13, C1593j.f29154h, c0629u14), c0629u14, 2058660585);
                    this.f99b.invoke(c0629u14, Integer.valueOf((this.f100c >> 12) & 14));
                    c0629u14.u(false);
                    c0629u14.u(true);
                    c0629u14.u(false);
                    c0629u14.u(false);
                }
                break;
        }
        return T9.w.f11979a;
    }
}
