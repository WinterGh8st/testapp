package A7;

import B0.C0049f;
import C9.C0082d;
import C9.C0088f;
import C9.C0091g;
import C9.C0100j;
import C9.C0109n;
import C9.C0122u;
import C9.C0128x;
import E.I;
import F8.C0222d;
import F8.C0238u;
import F8.K;
import G0.C0273j;
import G6.F0;
import G6.y0;
import I.w0;
import O.C0595c0;
import O.L;
import P7.C0658f0;
import Y1.C0790e;
import Y1.C0792g;
import Y1.C0793h;
import android.content.Intent;
import androidx.lifecycle.j0;
import com.stripe.android.financialconnections.features.linkstepupverification.LinkStepUpVerificationState;
import com.stripe.android.financialconnections.features.manualentry.ManualEntryState;
import com.stripe.android.paymentsheet.addresselement.AddressElementActivity;
import com.stripe.android.view.AddPaymentMethodActivity;
import com.stripe.android.view.BecsDebitAccountNumberEditText;
import com.stripe.android.view.BecsDebitWidget;
import com.stripe.android.view.CardFormView;
import com.stripe.android.view.PostalCodeEditText;
import java.util.List;
import java.util.Set;
import p016b3.AbstractC0862l;
import p032c7.AbstractC0928d;
import p183p8.R0;
import p199r0.InterfaceC1459m;
import p232u0.InterfaceC1709y0;
import p234u2.W;

/* JADX INFO: loaded from: classes.dex */
public final class z extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f204a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f205b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ z(Object obj, int i10) {
        super(1);
        this.f204a = i10;
        this.f205b = obj;
    }

    /* JADX WARN: Code duplicated, block: B:182:0x043f  */
    /* JADX WARN: Code duplicated, block: B:190:0x0456  */
    /* JADX WARN: Code duplicated, block: B:196:0x0469  */
    @Override // p084ga.c
    public final Object invoke(Object obj) throws Exception {
        I i10;
        int i11;
        String str;
        int i12;
        int i13;
        int i14;
        int i15;
        InterfaceC1459m interfaceC1459m;
        float f10 = 0.0f;
        int i16 = 2;
        String strR0 = null;
        b = null;
        b = null;
        b = null;
        B0.B b10 = null;
        B0.B b11 = null;
        strR0 = null;
        boolean z3 = false;
        int i17 = 1;
        T9.w wVar = T9.w.f11979a;
        Object obj2 = this.f205b;
        switch (this.f204a) {
            case 0:
                p050e0.G g10 = (p050e0.G) obj;
                p097ha.k.f(g10, "$this$graphicsLayer");
                g10.f21700q = ((Number) ((p260x.D) obj2).f31625d.getValue()).floatValue();
                return wVar;
            case 1:
                p097ha.k.f((String) obj, "it");
                ((InterfaceC1709y0) obj2).a("https://support.link.co/contact/email?skipVerification=true");
                return wVar;
            case 2:
                C0122u c0122u = (C0122u) obj;
                p097ha.k.f(c0122u, "host");
                p073g.d dVar = ((A8.j) obj2).f253f;
                return dVar != null ? new A8.t(dVar) : new A8.t(c0122u);
            case 3:
                B0.B b12 = (B0.B) obj;
                p097ha.k.f(b12, "it");
                ((p097ha.u) obj2).f23278a = b12;
                return wVar;
            case 4:
                C0122u c0122u2 = (C0122u) obj;
                p097ha.k.f(c0122u2, "host");
                p073g.d dVar2 = ((p290z8.a) ((D9.a) obj2).get()).f33368f;
                return dVar2 != null ? new p032c7.B(dVar2) : new p032c7.B(c0122u2);
            case 5:
                float f11 = -((Number) obj).floatValue();
                C.D d10 = (C.D) obj2;
                if ((f11 >= 0.0f || d10.a()) && (f11 <= 0.0f || d10.c())) {
                    if (Math.abs(d10.f1433e) > 0.5f) {
                        throw new IllegalStateException(("entered drag with non-zero pending scroll: " + d10.f1433e).toString());
                    }
                    float f12 = d10.f1433e + f11;
                    d10.f1433e = f12;
                    if (Math.abs(f12) > 0.5f) {
                        float f13 = d10.f1433e;
                        androidx.compose.ui.node.a aVar = d10.f1439l;
                        if (aVar != null) {
                            aVar.k();
                        }
                        boolean z5 = d10.f1436h;
                        if (z5) {
                            float f14 = f13 - d10.f1433e;
                            if (z5) {
                                C.u uVarH = d10.h();
                                if (!uVarH.b().isEmpty()) {
                                    z3 = f14 < 0.0f;
                                    int i18 = z3 ? ((C.x) U9.n.J0(uVarH.b())).f1549a + 1 : ((C.x) U9.n.C0(uVarH.b())).f1549a - 1;
                                    if (i18 != d10.f1437i && i18 >= 0 && i18 < uVarH.e()) {
                                        if (d10.k != z3 && (i10 = d10.f1438j) != null) {
                                            i10.cancel();
                                        }
                                        d10.k = z3;
                                        d10.f1437i = i18;
                                        d10.f1438j = d10.f1448u.j(i18, d10.f1444q);
                                    }
                                }
                            }
                        }
                    }
                    if (Math.abs(d10.f1433e) > 0.5f) {
                        f11 -= d10.f1433e;
                        d10.f1433e = 0.0f;
                    }
                    f10 = f11;
                }
                return Float.valueOf(-f10);
            case 6:
                p025c0.o oVar = (p025c0.o) obj;
                p097ha.k.f(oVar, "it");
                if (oVar.a()) {
                    ((B7.m) obj2).m();
                }
                return wVar;
            case 7:
                C0658f0 c0658f0 = (C0658f0) obj;
                p097ha.k.f(c0658f0, "it");
                ((C7.o) obj2).invoke(c0658f0, Boolean.FALSE);
                return wVar;
            case 8:
                T9.j jVar = (T9.j) obj;
                p097ha.k.e(jVar, "result");
                Object obj3 = jVar.f11960a;
                Throwable thA = T9.j.a(obj3);
                AddPaymentMethodActivity addPaymentMethodActivity = (AddPaymentMethodActivity) obj2;
                if (thA == null) {
                    R0 r7 = (R0) obj3;
                    if (((Boolean) addPaymentMethodActivity.f21141T.getValue()).booleanValue()) {
                        try {
                            int i19 = AbstractC0928d.f18200a;
                            throw new IllegalStateException("Attempted to get instance of CustomerSession without initialization.");
                        } catch (Throwable th) {
                            Throwable thA2 = T9.j.a(AbstractC0862l.A(th));
                            if (thA2 == null) {
                                throw new ClassCastException();
                            }
                            C0088f c0088f = new C0088f(thA2);
                            addPaymentMethodActivity.w(false);
                            addPaymentMethodActivity.setResult(-1, new Intent().putExtras(G6.C.E(new T9.h("extra_activity_result", c0088f))));
                            addPaymentMethodActivity.finish();
                        }
                    } else {
                        C0091g c0091g = new C0091g(r7);
                        addPaymentMethodActivity.w(false);
                        addPaymentMethodActivity.setResult(-1, new Intent().putExtras(G6.C.E(new T9.h("extra_activity_result", c0091g))));
                        addPaymentMethodActivity.finish();
                    }
                } else {
                    addPaymentMethodActivity.w(false);
                    String message = thA.getMessage();
                    if (message == null) {
                        message = "";
                    }
                    addPaymentMethodActivity.x(message);
                }
                return wVar;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                ((C0100j) obj2).getViewModel().f1921e = Integer.valueOf(((Number) obj).intValue());
                return wVar;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                ((C0109n) obj2).f2136a = Integer.valueOf(((Number) obj).intValue());
                return wVar;
            case 11:
                C0128x c0128x = (C0128x) obj;
                BecsDebitWidget becsDebitWidget = (BecsDebitWidget) obj2;
                if (c0128x != null) {
                    becsDebitWidget.getViewBinding$payments_core_release().f27481e.setHelperText(c0128x.f2211b);
                    becsDebitWidget.getViewBinding$payments_core_release().f27481e.setHelperTextEnabled(true);
                } else {
                    becsDebitWidget.getViewBinding$payments_core_release().f27481e.setHelperText(null);
                    becsDebitWidget.getViewBinding$payments_core_release().f27481e.setHelperTextEnabled(false);
                }
                BecsDebitAccountNumberEditText becsDebitAccountNumberEditText = becsDebitWidget.getViewBinding$payments_core_release().f27478b;
                if (c0128x != null && (str = c0128x.f2210a) != null) {
                    strR0 = p197qa.o.r0(2, str);
                }
                if (strR0 == null) {
                    i11 = 5;
                } else {
                    int iHashCode = strR0.hashCode();
                    if (iHashCode != 1536) {
                        if (iHashCode != 1537) {
                            if (iHashCode != 1539) {
                                if (iHashCode != 1542) {
                                    if (iHashCode != 1544) {
                                        if (iHashCode != 1756) {
                                            if (iHashCode == 1784 && strR0.equals("80")) {
                                                i11 = 4;
                                            }
                                        } else if (strR0.equals("73")) {
                                            i11 = 6;
                                        }
                                    } else if (strR0.equals("08")) {
                                        i11 = 9;
                                    }
                                    i11 = 5;
                                } else if (strR0.equals("06")) {
                                    i11 = 8;
                                } else {
                                    i11 = 5;
                                }
                            } else if (strR0.equals("03")) {
                                i11 = 6;
                            } else {
                                i11 = 5;
                            }
                        } else if (strR0.equals("01")) {
                            i11 = 9;
                        } else {
                            i11 = 5;
                        }
                    } else if (strR0.equals("00")) {
                        i11 = 9;
                    } else {
                        i11 = 5;
                    }
                }
                becsDebitAccountNumberEditText.setMinLength(i11);
                return wVar;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p130k7.f fVar = (p130k7.f) obj;
                p097ha.k.f(fVar, "countryCode");
                int i20 = CardFormView.f21167v;
                CardFormView cardFormView = (CardFormView) obj2;
                cardFormView.c(fVar);
                Set set = p130k7.g.f24518a;
                cardFormView.f21172e.setVisibility(p130k7.g.f24519b.contains(fVar.f24517a) ? 0 : 8);
                PostalCodeEditText postalCodeEditText = cardFormView.f21174q;
                postalCodeEditText.setShouldShowError(false);
                postalCodeEditText.setText((CharSequence) null);
                return wVar;
            case 13:
                C0082d c0082d = (C0082d) obj;
                if (c0082d != null) {
                    ((p073g.i) obj2).a(c0082d, null);
                }
                return wVar;
            case 14:
                ((Ca.h) obj2).b();
                return wVar;
            case 15:
                float f15 = -((Number) obj).floatValue();
                D.D d11 = (D.D) obj2;
                if ((f15 >= 0.0f || d11.a()) && (f15 <= 0.0f || d11.c())) {
                    if (Math.abs(d11.f2285d) > 0.5f) {
                        throw new IllegalStateException(("entered drag with non-zero pending scroll: " + d11.f2285d).toString());
                    }
                    float f16 = d11.f2285d + f15;
                    d11.f2285d = f16;
                    if (Math.abs(f16) > 0.5f) {
                        float f17 = d11.f2285d;
                        androidx.compose.ui.node.a aVar2 = d11.f2292l;
                        if (aVar2 != null) {
                            aVar2.k();
                        }
                        boolean z10 = d11.f2289h;
                        if (z10) {
                            float f18 = f17 - d11.f2285d;
                            if (z10) {
                                D.q qVar = (D.q) d11.f2283b.getValue();
                                if (!qVar.b().isEmpty()) {
                                    boolean z11 = f18 < 0.0f;
                                    if (z11) {
                                        D.u uVar = (D.u) U9.n.J0(qVar.b());
                                        i12 = (d11.f2287f ? uVar.f2378p : uVar.f2379q) + 1;
                                        i13 = ((D.u) U9.n.J0(qVar.b())).f2364a + 1;
                                    } else {
                                        D.u uVar2 = (D.u) U9.n.C0(qVar.b());
                                        i12 = (d11.f2287f ? uVar2.f2378p : uVar2.f2379q) - 1;
                                        i13 = ((D.u) U9.n.C0(qVar.b())).f2364a - 1;
                                    }
                                    if (i12 != d11.f2290i && i13 >= 0 && i13 < qVar.e()) {
                                        boolean z12 = d11.k;
                                        P.h hVar = d11.f2291j;
                                        if (z12 != z11 && (i14 = hVar.f10080c) > 0) {
                                            Object[] objArr = hVar.f10078a;
                                            int i21 = 0;
                                            do {
                                                ((I) objArr[i21]).cancel();
                                                i21++;
                                            } while (i21 < i14);
                                        }
                                        d11.k = z11;
                                        d11.f2290i = i12;
                                        hVar.g();
                                        List list = (List) ((p084ga.c) d11.f2295o.getValue()).invoke(Integer.valueOf(i12));
                                        int size = list.size();
                                        for (int i22 = 0; i22 < size; i22++) {
                                            T9.h hVar2 = (T9.h) list.get(i22);
                                            hVar.b(d11.f2301u.j(((Number) hVar2.f11957a).intValue(), ((N0.a) hVar2.f11958b).f8965a));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (Math.abs(d11.f2285d) > 0.5f) {
                        f15 -= d11.f2285d;
                        d11.f2285d = 0.0f;
                    }
                    f10 = f15;
                }
                return Float.valueOf(-f10);
            case 16:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                return new E.x((E.y) obj2, z3 ? 1 : 0);
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                return new E.x((E.G) obj2, i17);
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                p097ha.k.f(obj, "needle");
                E.A a3 = (E.A) ((C.o) obj2).d();
                int iB = a3.b();
                for (int i23 = 0; i23 < iB; i23++) {
                    if (a3.c(i23).equals(obj)) {
                        i15 = i23;
                        return Integer.valueOf(i15);
                    }
                }
                i15 = -1;
                return Integer.valueOf(i15);
            case 19:
                LinkStepUpVerificationState linkStepUpVerificationState = (LinkStepUpVerificationState) obj;
                p097ha.k.f(linkStepUpVerificationState, "$this$setState");
                return LinkStepUpVerificationState.copy$default(linkStepUpVerificationState, new W((E7.h) obj2), null, null, 6, null);
            case 20:
                ManualEntryState manualEntryState = (ManualEntryState) obj;
                p097ha.k.f(manualEntryState, "$this$setState");
                return ManualEntryState.copy$default(manualEntryState, null, null, null, null, null, null, (Integer) obj2, null, 191, null);
            case 21:
                Y1.y yVar = (Y1.y) obj;
                p097ha.k.f(yVar, "$this$AnimatedNavHost");
                p054e4.e.z(yVar, "Loading", null, K.f3732a, 126);
                AddressElementActivity addressElementActivity = (AddressElementActivity) obj2;
                p054e4.e.z(yVar, "InputAddress", null, Ua.l.v(264620068, new C0222d(addressElementActivity, z3 ? 1 : 0), true), 126);
                C0793h c0793h = new C0793h();
                Y1.I i24 = Y1.I.f14011a;
                P.d dVar3 = c0793h.f14029a;
                dVar3.f10071b = i24;
                Y1.I i25 = (Y1.I) dVar3.f10071b;
                if (i25 != null) {
                    i24 = i25;
                }
                p054e4.e.z(yVar, "Autocomplete?country={country}", G6.C.W(new C0790e("country", new C0792g(i24))), Ua.l.v(321433509, new C0222d(addressElementActivity, i17), true), 124);
                return wVar;
            case 22:
                String str2 = (String) obj;
                p097ha.k.f(str2, "it");
                F8.I i26 = (F8.I) obj2;
                p230ta.E.t(j0.j(i26), null, new F8.x(i26, str2, null), 3);
                return wVar;
            case 23:
                ((Number) obj).intValue();
                ((C0238u) obj2).m();
                return wVar;
            case 24:
                p284z0.j jVar2 = (p284z0.j) obj;
                p097ha.k.f(jVar2, "$this$semantics");
                p173oa.d[] dVarArr = p284z0.r.f33265a;
                A0.a aVar3 = (A0.a) obj2;
                p097ha.k.f(aVar3, "<set-?>");
                p284z0.p.f33263z.a(jVar2, p284z0.r.f33265a[18], aVar3);
                return wVar;
            case 25:
                G0.G g11 = (G0.G) obj;
                p097ha.k.f(g11, "it");
                G0.t tVar = g11.f4089b;
                p097ha.k.f(tVar, "fontWeight");
                return ((C0273j) obj2).a(new G0.G(null, tVar, g11.f4090c, g11.f4091d, g11.f4092e)).getValue();
            case 26:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                return new E.x((K.y) obj2, i16);
            case 27:
                float fFloatValue = ((Number) obj).floatValue();
                w0 w0Var = (w0) obj2;
                C0595c0 c0595c0 = w0Var.f5683a;
                float fN = c0595c0.n() + fFloatValue;
                C0595c0 c0595c1 = w0Var.f5684b;
                if (fN > c0595c1.n()) {
                    fFloatValue = c0595c1.n() - c0595c0.n();
                } else if (fN < 0.0f) {
                    fFloatValue = -c0595c0.n();
                }
                c0595c0.r(c0595c0.n() + fFloatValue);
                return Float.valueOf(fFloatValue);
            case 28:
                List list2 = (List) obj;
                p097ha.k.f(list2, "textLayoutResult");
                B0.B b13 = ((J.f) obj2).F0().f6269n;
                if (b13 != null) {
                    list2.add(b13);
                    b11 = b13;
                }
                return Boolean.valueOf(b11 != null);
            default:
                List list3 = (List) obj;
                p097ha.k.f(list3, "textLayoutResult");
                J.e eVarF0 = ((J.g) obj2).F0();
                N0.j jVar3 = eVarF0.f6285o;
                if (jVar3 != null && (interfaceC1459m = eVarF0.f6280i) != null) {
                    C0049f c0049f = new C0049f(6, eVarF0.f6272a, null);
                    if (eVarF0.f6281j != null && eVarF0.f6284n != null) {
                        long jA = N0.a.a(eVarF0.f6286p, 0, 0, 0, 0, 10);
                        B0.D d12 = eVarF0.f6273b;
                        U9.v vVar = U9.v.f12751a;
                        b10 = new B0.B(new B0.A(c0049f, d12, vVar, eVarF0.f6277f, eVarF0.f6276e, eVarF0.f6275d, interfaceC1459m, jVar3, eVarF0.f6274c, jA), new B0.j(new B0.l(c0049f, eVarF0.f6273b, vVar, interfaceC1459m, eVarF0.f6274c), jA, eVarF0.f6277f, eVarF0.f6275d == 2), eVarF0.f6282l);
                    }
                }
                if (b10 != null) {
                    list3.add(b10);
                }
                return Boolean.FALSE;
        }
    }
}
