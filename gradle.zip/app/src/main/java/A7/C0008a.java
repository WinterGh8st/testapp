package A7;

import B.InterfaceC0035q;
import O.AbstractC0590a;
import O.C0596d;
import O.C0629u;
import O.C0634z;
import O.D0;
import P7.C0;
import p234u2.W;

/* JADX INFO: renamed from: A7.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0008a extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f112a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f113b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f114c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f115d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0008a(j jVar, p084ga.a aVar, int i10) {
        super(3);
        this.f114c = jVar;
        this.f115d = (p097ha.i) aVar;
        this.f113b = i10;
    }

    /* JADX WARN: Type inference failed for: r0v3, types: [ga.a, ha.i] */
    /* JADX WARN: Type inference failed for: r4v13, types: [ga.a, ha.l] */
    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        switch (this.f112a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((InterfaceC0035q) obj, "$this$AccessibleDataCalloutBox");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    p003a.a.j((j) this.f114c, (p097ha.i) this.f115d, c0629u, (this.f113b & 112) | 8);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.lazy.a) obj, "$this$item");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else if (p097ha.k.b(((C0) ((W) this.f114c).f30008b).f10276a, Boolean.TRUE)) {
                    c0629u2.a0(1952220165);
                    p143m0.c.t((B7.m) this.f115d, c0629u2, (this.f113b >> 6) & 14);
                    c0629u2.u(false);
                } else {
                    c0629u2.a0(1952220269);
                    p143m0.c.u(0, c0629u2);
                    c0629u2.u(false);
                }
                break;
            default:
                AbstractC0590a abstractC0590a = (AbstractC0590a) obj;
                D0 d10 = (D0) obj2;
                p097ha.k.f(abstractC0590a, "applier");
                p097ha.k.f(d10, "slots");
                p097ha.k.f((C0634z) obj3, "<anonymous parameter 2>");
                Object objM = ((p097ha.l) this.f114c).m();
                d10.I(d10.c((C0596d) this.f115d), objM);
                abstractC0590a.e(this.f113b, objM);
                abstractC0590a.b(objM);
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0008a(p084ga.a aVar, C0596d c0596d, int i10) {
        super(3);
        this.f114c = (p097ha.l) aVar;
        this.f115d = c0596d;
        this.f113b = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0008a(W w9, B7.m mVar, int i10) {
        super(3);
        this.f114c = w9;
        this.f115d = mVar;
        this.f113b = i10;
    }
}
