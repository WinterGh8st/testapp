package A7;

/* JADX INFO: loaded from: classes.dex */
public final class r extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final r f179b = new r(0, 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final r f180c = new r(0, 1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f181a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ r(int i10, int i11) {
        super(i10);
        this.f181a = i11;
    }

    @Override // p084ga.a
    public final /* bridge */ /* synthetic */ Object m() {
        switch (this.f181a) {
            case 0:
                break;
        }
        return T9.w.f11979a;
    }
}
