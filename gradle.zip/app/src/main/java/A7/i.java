package A7;

import com.stripe.android.financialconnections.model.FinancialConnectionsAccount$Permissions;

/* JADX INFO: loaded from: classes.dex */
public abstract /* synthetic */ class i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f146a;

    static {
        int[] iArr = new int[FinancialConnectionsAccount$Permissions.values().length];
        try {
            iArr[FinancialConnectionsAccount$Permissions.BALANCES.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[FinancialConnectionsAccount$Permissions.OWNERSHIP.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[FinancialConnectionsAccount$Permissions.PAYMENT_METHOD.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[FinancialConnectionsAccount$Permissions.ACCOUNT_NUMBERS.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr[FinancialConnectionsAccount$Permissions.TRANSACTIONS.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr[FinancialConnectionsAccount$Permissions.UNKNOWN.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        f146a = iArr;
    }
}
