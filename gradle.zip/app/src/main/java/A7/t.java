package A7;

import E.C0148i;
import X.C0774g;
import android.graphics.PorterDuffColorFilter;
import android.os.Build;
import p050e0.C1051d;
import p050e0.C1058k;

/* JADX INFO: loaded from: classes.dex */
public final class t extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f185a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ long f186b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ t(int i10, long j10) {
        super(1);
        this.f185a = i10;
        this.f186b = j10;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        switch (this.f185a) {
            case 0:
                p074g0.e eVar = (p074g0.e) obj;
                p097ha.k.f(eVar, "$this$Canvas");
                p074g0.e.p0(eVar, this.f186b, 0.0f, 0L, 126);
                return T9.w.f11979a;
            case 1:
                p074g0.e eVar2 = (p074g0.e) obj;
                p097ha.k.f(eVar2, "$this$Canvas");
                p074g0.e.p0(eVar2, this.f186b, 0.0f, 0L, 126);
                return T9.w.f11979a;
            case 2:
                p013b0.c cVar = (p013b0.c) obj;
                p097ha.k.f(cVar, "$this$drawWithCache");
                float fD = p038d0.f.d(cVar.f17233a.e()) / 2.0f;
                C1051d c1051dB = p003a.a.B(cVar, fD);
                int i10 = Build.VERSION.SDK_INT;
                long j10 = this.f186b;
                C0148i c0148i = new C0148i(fD, c1051dB, new p050e0.r(i10 >= 29 ? C1058k.f21741a.a(j10, 5) : new PorterDuffColorFilter(p050e0.E.t(j10), p050e0.E.v(5))), 1);
                C0774g c0774g = new C0774g();
                c0774g.f13393a = c0148i;
                cVar.f17234b = c0774g;
                return c0774g;
            default:
                p284z0.j jVar = (p284z0.j) obj;
                p097ha.k.f(jVar, "$this$semantics");
                jVar.g(K.l.f6717c, new K.k(I.H.f5355a, this.f186b));
                return T9.w.f11979a;
        }
    }
}
