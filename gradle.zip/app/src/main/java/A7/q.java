package A7;

import L.f2;
import O.AbstractC0630v;
import O.C0629u;
import com.flamingotools.ws.R;
import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class q extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final q f176b = new q(2, 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final q f177c = new q(2, 1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f178a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q(int i10, int i11) {
        super(i10);
        this.f178a = i11;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f178a) {
            case 0:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    f2.b(p197qa.a.o(R.string.stripe_close_dialog_title, c0629u), null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u, 0, 0, 131070);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    AbstractC0862l.b(new W7.H(R.string.stripe_close_dialog_desc), r.f179b, r.f180c, c0629u2, 440);
                }
                break;
            case 2:
                ((Number) obj2).intValue();
                com.bumptech.glide.d.M(AbstractC0630v.S(1), (C0629u) obj);
                break;
            default:
                ((Number) obj2).intValue();
                com.bumptech.glide.d.Q(AbstractC0630v.S(1), (C0629u) obj);
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ q(int i10, int i11, boolean z3) {
        super(2);
        this.f178a = i11;
    }
}
