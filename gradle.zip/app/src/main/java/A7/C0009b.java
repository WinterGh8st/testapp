package A7;

import B.InterfaceC0035q;
import B0.C0049f;
import E8.C0178j0;
import E8.f1;
import G6.F0;
import G6.y0;
import I.AbstractC0407e;
import L.AbstractC0497d1;
import L.C0499e0;
import L.C0503f1;
import L.f2;
import L.g2;
import O.AbstractC0630v;
import O.C0617n0;
import O.C0629u;
import P7.C0658f0;
import com.stripe.android.financialconnections.features.partnerauth.PartnerAuthState;
import com.stripe.android.financialconnections.model.LinkAccountSessionPaymentAccount$MicrodepositVerificationMethod;
import java.util.Arrays;
import java.util.List;
import p016b3.AbstractC0862l;
import p199r0.U;
import p271y.x0;

/* JADX INFO: renamed from: A7.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0009b extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f116a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f117b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f118c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f119d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0009b(j jVar, p084ga.a aVar, int i10) {
        super(2);
        this.f116a = 0;
        this.f117b = jVar;
        this.f119d = (p097ha.i) aVar;
        this.f118c = i10;
    }

    /* JADX WARN: Type inference failed for: r0v11, types: [ga.c, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r0v59, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v1, types: [ga.a, ha.i] */
    /* JADX WARN: Type inference failed for: r3v5, types: [ga.a, ha.l] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f116a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(this.f118c | 1);
                p003a.a.a((j) this.f117b, (p097ha.i) this.f119d, (C0629u) obj, iS);
                return T9.w.f11979a;
            case 1:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(this.f118c | 1);
                p003a.a.j((j) this.f117b, (p084ga.a) this.f119d, (C0629u) obj, iS2);
                return T9.w.f11979a;
            case 2:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(this.f118c | 1);
                p029c4.a.J((String) this.f117b, (T9.h) this.f119d, (C0629u) obj, iS3);
                return T9.w.f11979a;
            case 3:
                ((Number) obj2).intValue();
                int iS4 = AbstractC0630v.S(this.f118c | 1);
                p279y7.f fVar = (p279y7.f) this.f119d;
                p029c4.a.b0((p267x7.b) this.f117b, fVar, (C0629u) obj, iS4);
                return T9.w.f11979a;
            case 4:
                ((Number) obj2).intValue();
                int iS5 = AbstractC0630v.S(this.f118c | 1);
                p029c4.a.h0((Throwable) this.f117b, (p084ga.c) this.f119d, (C0629u) obj, iS5);
                return T9.w.f11979a;
            case 5:
                ((Number) obj2).intValue();
                int iS6 = AbstractC0630v.S(this.f118c | 1);
                ?? r7 = this.f119d;
                p054e4.e.b((Y7.a) this.f117b, r7, (C0629u) obj, iS6);
                return T9.w.f11979a;
            case 6:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    ((V.a) this.f117b).I((androidx.compose.foundation.layout.b) this.f119d, c0629u, Integer.valueOf((this.f118c >> 6) & 112));
                }
                return T9.w.f11979a;
            case 7:
                U u5 = (U) obj;
                long j10 = ((N0.a) obj2).f8965a;
                p097ha.k.f(u5, "$this$SubcomposeLayout");
                return ((p199r0.B) this.f117b).b(u5, u5.X(T9.w.f11979a, Ua.l.v(-1945019079, new C0009b((V.a) this.f119d, new androidx.compose.foundation.layout.b(u5, j10), this.f118c, 6), true)), j10);
            case 8:
                ((Number) obj2).intValue();
                int iS7 = AbstractC0630v.S(this.f118c | 1);
                com.stripe.android.financialconnections.features.consent.f.f((Z.m) this.f117b, (List) this.f119d, (C0629u) obj, iS7);
                return T9.w.f11979a;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                ((Number) obj2).intValue();
                int iS8 = AbstractC0630v.S(this.f118c | 1);
                com.bumptech.glide.d.V((C.o) this.f117b, (C.D) this.f119d, (C0629u) obj, iS8);
                return T9.w.f11979a;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                ((Number) obj2).intValue();
                int iS9 = AbstractC0630v.S(this.f118c | 1);
                p143m0.c.o((InterfaceC0035q) this.f117b, (C0658f0) this.f119d, (C0629u) obj, iS9);
                return T9.w.f11979a;
            case 11:
                ((Number) obj2).intValue();
                int iS10 = AbstractC0630v.S(this.f118c | 1);
                p143m0.c.p((p084ga.c) this.f117b, (C0658f0) this.f119d, (C0629u) obj, iS10);
                return T9.w.f11979a;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                ((Number) obj2).intValue();
                int iS11 = AbstractC0630v.S(this.f118c | 1);
                Ua.d.o((C.o) this.f117b, (D.D) this.f119d, (C0629u) obj, iS11);
                return T9.w.f11979a;
            case 13:
                ((Number) obj2).intValue();
                int iS12 = AbstractC0630v.S(this.f118c | 1);
                p054e4.e.t((String) this.f117b, (LinkAccountSessionPaymentAccount$MicrodepositVerificationMethod) this.f119d, (C0629u) obj, iS12);
                return T9.w.f11979a;
            case 14:
                ((Number) obj2).intValue();
                int iS13 = AbstractC0630v.S(this.f118c | 1);
                AbstractC0862l.d((String) this.f117b, (D7.h) this.f119d, (C0629u) obj, iS13);
                return T9.w.f11979a;
            case 15:
                ((Number) obj2).intValue();
                int iS14 = AbstractC0630v.S(this.f118c | 1);
                AbstractC0407e.a((C0049f) this.f117b, (List) this.f119d, (C0629u) obj, iS14);
                return T9.w.f11979a;
            case 16:
                ((Number) obj2).intValue();
                int iS15 = AbstractC0630v.S(this.f118c | 1);
                I7.d dVar = (I7.d) this.f119d;
                com.stripe.android.financialconnections.features.networkinglinksignup.c.d((I7.h) this.f117b, dVar, (C0629u) obj, iS15);
                return T9.w.f11979a;
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                ((Number) obj2).intValue();
                int iS16 = AbstractC0630v.S(this.f118c | 1);
                D7.h hVar = (D7.h) this.f119d;
                com.stripe.android.financialconnections.features.networkinglinksignup.c.f((String) this.f117b, hVar, (C0629u) obj, iS16);
                return T9.w.f11979a;
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    f2.a(((g2) this.f117b).f7885i, Ua.l.u(c0629u2, 181426554, new E((V.a) this.f119d, this.f118c, 7)), c0629u2, 48);
                }
                return T9.w.f11979a;
            case 19:
                C0629u c0629u3 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    ((V.a) this.f117b).I(((C0503f1) this.f119d).f7868a, c0629u3, Integer.valueOf((this.f118c >> 9) & 112));
                }
                return T9.w.f11979a;
            case 20:
                C0629u c0629u4 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    AbstractC0630v.b(new C0617n0[]{AbstractC0497d1.f7816a.b((C0499e0) this.f117b)}, (V.a) this.f119d, c0629u4, ((this.f118c >> 15) & 112) | 8);
                }
                return T9.w.f11979a;
            case 21:
                ((Number) obj2).intValue();
                int iS17 = AbstractC0630v.S(this.f118c | 1);
                f2.a((B0.D) this.f117b, (V.a) this.f119d, (C0629u) obj, iS17);
                return T9.w.f11979a;
            case 22:
                C0629u c0629u5 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    com.bumptech.glide.d.J(false, 0.0f, ((PartnerAuthState) this.f117b).d(), (L7.g) this.f119d, c0629u5, (this.f118c << 6) & 7168, 3);
                }
                return T9.w.f11979a;
            case 23:
                C0629u c0629u6 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u6.C()) {
                    c0629u6.U();
                } else {
                    com.bumptech.glide.d.J(false, com.bumptech.glide.d.u0((x0) this.f117b), false, (p097ha.l) this.f119d, c0629u6, ((this.f118c << 6) & 7168) | 384, 1);
                }
                return T9.w.f11979a;
            case 24:
                ((Number) obj2).intValue();
                C0617n0[] c0617n0Arr = (C0617n0[]) this.f117b;
                C0617n0[] c0617n0Arr2 = (C0617n0[]) Arrays.copyOf(c0617n0Arr, c0617n0Arr.length);
                int iS18 = AbstractC0630v.S(this.f118c | 1);
                AbstractC0630v.b(c0617n0Arr2, (p084ga.e) this.f119d, (C0629u) obj, iS18);
                return T9.w.f11979a;
            case 25:
                ((Number) obj2).intValue();
                int iS19 = AbstractC0630v.S(this.f118c | 1);
                E5.b.f(this.f117b, (Z.m) this.f119d, (C0629u) obj, iS19);
                return T9.w.f11979a;
            case 26:
                ((Number) obj2).intValue();
                int iS20 = AbstractC0630v.S(this.f118c | 1);
                Z.m mVar = (Z.m) this.f119d;
                p168o5.b.a((W8.n) this.f117b, mVar, (C0629u) obj, iS20);
                return T9.w.f11979a;
            case 27:
                ((Number) obj2).intValue();
                int iS21 = AbstractC0630v.S(this.f118c | 1);
                Z.m mVar2 = (Z.m) this.f119d;
                AbstractC0862l.k((C0178j0) this.f117b, mVar2, (C0629u) obj, iS21);
                return T9.w.f11979a;
            case 28:
                ((Number) obj2).intValue();
                int iS22 = AbstractC0630v.S(this.f118c | 1);
                Z.m mVar3 = (Z.m) this.f119d;
                com.bumptech.glide.e.h((f1) this.f117b, mVar3, (C0629u) obj, iS22);
                return T9.w.f11979a;
            default:
                C0629u c0629u7 = (C0629u) obj;
                ((Number) obj2).intValue();
                p097ha.k.f(c0629u7, "nc");
                ((V.a) this.f117b).a(this.f119d, c0629u7, AbstractC0630v.S(this.f118c) | 1);
                return T9.w.f11979a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0009b(Object obj, Object obj2, int i10, int i11) {
        super(2);
        this.f116a = i11;
        this.f117b = obj;
        this.f119d = obj2;
        this.f118c = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0009b(x0 x0Var, p084ga.a aVar, int i10) {
        super(2);
        this.f116a = 23;
        this.f117b = x0Var;
        this.f119d = (p097ha.l) aVar;
        this.f118c = i10;
    }
}
