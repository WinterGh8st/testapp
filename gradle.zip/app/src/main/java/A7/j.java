package A7;

import java.util.List;
import p032c7.AbstractC0933i;

/* JADX INFO: loaded from: classes.dex */
public final class j {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f147a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final List f148b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f149c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f150d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final String f151e;

    public j(String str, List list, boolean z3, boolean z5, String str2) {
        p097ha.k.f(list, "permissions");
        this.f147a = str;
        this.f148b = list;
        this.f149c = z3;
        this.f150d = z5;
        this.f151e = str2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return p097ha.k.b(this.f147a, jVar.f147a) && p097ha.k.b(this.f148b, jVar.f148b) && this.f149c == jVar.f149c && this.f150d == jVar.f150d && p097ha.k.b(this.f151e, jVar.f151e);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4 */
    /* JADX WARN: Type inference failed for: r0v5, types: [int] */
    /* JADX WARN: Type inference failed for: r0v9 */
    /* JADX WARN: Type inference failed for: r1v4, types: [int] */
    /* JADX WARN: Type inference failed for: r1v6, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1, types: [int] */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4 */
    public final int hashCode() {
        String str = this.f147a;
        int iHashCode = (this.f148b.hashCode() + ((str == null ? 0 : str.hashCode()) * 31)) * 31;
        boolean z3 = this.f149c;
        ?? r7 = z3;
        if (z3) {
            r7 = 1;
        }
        int i10 = (iHashCode + r7) * 31;
        boolean z5 = this.f150d;
        return this.f151e.hashCode() + ((i10 + (z5 ? 1 : z5)) * 31);
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("AccessibleDataCalloutModel(businessName=");
        sb2.append(this.f147a);
        sb2.append(", permissions=");
        sb2.append(this.f148b);
        sb2.append(", isStripeDirect=");
        sb2.append(this.f149c);
        sb2.append(", isNetworking=");
        sb2.append(this.f150d);
        sb2.append(", dataPolicyUrl=");
        return AbstractC0933i.i(sb2, this.f151e, ")");
    }
}
