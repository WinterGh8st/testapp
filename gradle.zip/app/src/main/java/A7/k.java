package A7;

import B0.C0049f;
import C7.C0069d;
import E.L;
import E8.AbstractC0201v0;
import E8.C0166d0;
import E8.C0178j0;
import E8.C0190p0;
import E8.C0195s0;
import E8.C0209z0;
import E8.L0;
import F9.U;
import G6.F0;
import G6.y0;
import I.z0;
import O.I;
import O.Z;
import P7.C0658f0;
import P7.f1;
import Y1.C0798m;
import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import androidx.lifecycle.j0;
import com.flamingotools.ws.R;
import com.google.android.material.textfield.TextInputLayout;
import com.stripe.android.financialconnections.features.institutionpicker.InstitutionPickerViewModel;
import com.stripe.android.payments.bankaccount.ui.CollectBankAccountActivity;
import com.stripe.android.paymentsheet.paymentdatacollection.polling.PollingActivity;
import com.stripe.android.view.BecsDebitAccountNumberEditText;
import com.stripe.android.view.BecsDebitBsbEditText;
import com.stripe.android.view.BecsDebitMandateAcceptanceTextView;
import com.stripe.android.view.BecsDebitWidget;
import com.stripe.android.view.CountryTextInputLayout;
import com.stripe.android.view.EmailEditText;
import com.stripe.android.view.ShippingInfoWidget;
import com.stripe.android.view.StripeEditText;
import p183p8.C1430u0;
import p183p8.d2;
import p199r0.InterfaceC1461o;
import p214s4.C1546p1;
import p230ta.l0;
import p232u0.X;

/* JADX INFO: loaded from: classes.dex */
public final class k extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f152a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f153b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f154c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ k(int i10, Object obj, Object obj2) {
        super(0);
        this.f152a = i10;
        this.f153b = obj;
        this.f154c = obj2;
    }

    /* JADX WARN: Code duplicated, block: B:145:0x02ed  */
    /* JADX WARN: Type inference failed for: r8v28, types: [ga.a, ha.a] */
    /* JADX WARN: Type inference failed for: r8v32, types: [ga.a, ha.i] */
    @Override // p084ga.a
    public final Object m() {
        long jK;
        long j10;
        z0 z0VarC;
        C0049f c0049f;
        InterfaceC1461o interfaceC1461o;
        z0 z0VarC2;
        InterfaceC1461o interfaceC1461o2;
        p038d0.c cVar;
        C0209z0 c0209z0;
        L0 l1;
        T9.w wVar = T9.w.f11979a;
        Object obj = this.f153b;
        Object obj2 = this.f154c;
        switch (this.f152a) {
            case 0:
                ((p084ga.c) obj).invoke((f1) obj2);
                return wVar;
            case 1:
                ((p084ga.c) obj).invoke((Throwable) obj2);
                return wVar;
            case 2:
                ((C7.o) obj).invoke((C0658f0) obj2, Boolean.TRUE);
                return wVar;
            case 3:
                ((B7.m) obj).m();
                p025c0.e.a((p025c0.e) obj2);
                return wVar;
            case 4:
                p025c0.e.a((p025c0.e) obj);
                ((InstitutionPickerViewModel) obj2).d(C0069d.f1769c);
                return wVar;
            case 5:
                ((p084ga.c) obj).invoke((C0658f0) obj2);
                return wVar;
            case 6:
                return new C8.a(new C1546p1(new O7.i((CollectBankAccountActivity) obj, new C8.b((l0) obj2))));
            case 7:
                BecsDebitWidget becsDebitWidget = (BecsDebitWidget) obj2;
                LayoutInflater.from((Context) obj).inflate(R.layout.stripe_becs_debit_widget, becsDebitWidget);
                int i10 = R.id.account_number_edit_text;
                BecsDebitAccountNumberEditText becsDebitAccountNumberEditText = (BecsDebitAccountNumberEditText) p029c4.a.v0(becsDebitWidget, R.id.account_number_edit_text);
                if (becsDebitAccountNumberEditText != null) {
                    i10 = R.id.account_number_text_input_layout;
                    TextInputLayout textInputLayout = (TextInputLayout) p029c4.a.v0(becsDebitWidget, R.id.account_number_text_input_layout);
                    if (textInputLayout != null) {
                        i10 = R.id.bsb_edit_text;
                        BecsDebitBsbEditText becsDebitBsbEditText = (BecsDebitBsbEditText) p029c4.a.v0(becsDebitWidget, R.id.bsb_edit_text);
                        if (becsDebitBsbEditText != null) {
                            i10 = R.id.bsb_text_input_layout;
                            TextInputLayout textInputLayout2 = (TextInputLayout) p029c4.a.v0(becsDebitWidget, R.id.bsb_text_input_layout);
                            if (textInputLayout2 != null) {
                                i10 = R.id.email_edit_text;
                                EmailEditText emailEditText = (EmailEditText) p029c4.a.v0(becsDebitWidget, R.id.email_edit_text);
                                if (emailEditText != null) {
                                    i10 = R.id.email_text_input_layout;
                                    TextInputLayout textInputLayout3 = (TextInputLayout) p029c4.a.v0(becsDebitWidget, R.id.email_text_input_layout);
                                    if (textInputLayout3 != null) {
                                        i10 = R.id.mandate_acceptance_text_view;
                                        BecsDebitMandateAcceptanceTextView becsDebitMandateAcceptanceTextView = (BecsDebitMandateAcceptanceTextView) p029c4.a.v0(becsDebitWidget, R.id.mandate_acceptance_text_view);
                                        if (becsDebitMandateAcceptanceTextView != null) {
                                            i10 = R.id.name_edit_text;
                                            StripeEditText stripeEditText = (StripeEditText) p029c4.a.v0(becsDebitWidget, R.id.name_edit_text);
                                            if (stripeEditText != null) {
                                                i10 = R.id.name_text_input_layout;
                                                TextInputLayout textInputLayout4 = (TextInputLayout) p029c4.a.v0(becsDebitWidget, R.id.name_text_input_layout);
                                                if (textInputLayout4 != null) {
                                                    return new p194q7.d(becsDebitWidget, becsDebitAccountNumberEditText, textInputLayout, becsDebitBsbEditText, textInputLayout2, emailEditText, textInputLayout3, becsDebitMandateAcceptanceTextView, stripeEditText, textInputLayout4);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(becsDebitWidget.getResources().getResourceName(i10)));
            case 8:
                ShippingInfoWidget shippingInfoWidget = (ShippingInfoWidget) obj2;
                LayoutInflater.from((Context) obj).inflate(R.layout.stripe_address_widget, shippingInfoWidget);
                int i11 = R.id.country_autocomplete_aaw;
                CountryTextInputLayout countryTextInputLayout = (CountryTextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.country_autocomplete_aaw);
                if (countryTextInputLayout != null) {
                    i11 = R.id.et_address_line_one_aaw;
                    StripeEditText stripeEditText2 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_address_line_one_aaw);
                    if (stripeEditText2 != null) {
                        i11 = R.id.et_address_line_two_aaw;
                        StripeEditText stripeEditText3 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_address_line_two_aaw);
                        if (stripeEditText3 != null) {
                            i11 = R.id.et_city_aaw;
                            StripeEditText stripeEditText4 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_city_aaw);
                            if (stripeEditText4 != null) {
                                i11 = R.id.et_name_aaw;
                                StripeEditText stripeEditText5 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_name_aaw);
                                if (stripeEditText5 != null) {
                                    i11 = R.id.et_phone_number_aaw;
                                    StripeEditText stripeEditText6 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_phone_number_aaw);
                                    if (stripeEditText6 != null) {
                                        i11 = R.id.et_postal_code_aaw;
                                        StripeEditText stripeEditText7 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_postal_code_aaw);
                                        if (stripeEditText7 != null) {
                                            i11 = R.id.et_state_aaw;
                                            StripeEditText stripeEditText8 = (StripeEditText) p029c4.a.v0(shippingInfoWidget, R.id.et_state_aaw);
                                            if (stripeEditText8 != null) {
                                                i11 = R.id.tl_address_line1_aaw;
                                                TextInputLayout textInputLayout5 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_address_line1_aaw);
                                                if (textInputLayout5 != null) {
                                                    i11 = R.id.tl_address_line2_aaw;
                                                    TextInputLayout textInputLayout6 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_address_line2_aaw);
                                                    if (textInputLayout6 != null) {
                                                        i11 = R.id.tl_city_aaw;
                                                        TextInputLayout textInputLayout7 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_city_aaw);
                                                        if (textInputLayout7 != null) {
                                                            i11 = R.id.tl_name_aaw;
                                                            TextInputLayout textInputLayout8 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_name_aaw);
                                                            if (textInputLayout8 != null) {
                                                                i11 = R.id.tl_phone_number_aaw;
                                                                TextInputLayout textInputLayout9 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_phone_number_aaw);
                                                                if (textInputLayout9 != null) {
                                                                    i11 = R.id.tl_postal_code_aaw;
                                                                    TextInputLayout textInputLayout10 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_postal_code_aaw);
                                                                    if (textInputLayout10 != null) {
                                                                        i11 = R.id.tl_state_aaw;
                                                                        TextInputLayout textInputLayout11 = (TextInputLayout) p029c4.a.v0(shippingInfoWidget, R.id.tl_state_aaw);
                                                                        if (textInputLayout11 != null) {
                                                                            return new p194q7.c(shippingInfoWidget, countryTextInputLayout, stripeEditText2, stripeEditText3, stripeEditText4, stripeEditText5, stripeEditText6, stripeEditText7, stripeEditText8, textInputLayout5, textInputLayout6, textInputLayout7, textInputLayout8, textInputLayout9, textInputLayout10, textInputLayout11);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                throw new NullPointerException("Missing required view with ID: ".concat(shippingInfoWidget.getResources().getResourceName(i11)));
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                D.j jVar = (D.j) ((I) obj).getValue();
                D.D d10 = (D.D) obj2;
                return new D.l(d10, jVar, new B2.q((p163na.g) d10.f2282a.f1573f.getValue(), jVar));
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                L l4 = (L) obj2;
                return Float.valueOf(l4.a() ? ((E.A) ((C.o) obj).d()).b() + 1.0f : l4.e());
            case 11:
                p038d0.d dVar = (p038d0.d) obj;
                if (dVar != null) {
                    return dVar;
                }
                InterfaceC1461o interfaceC1461o3 = ((F.g) obj2).f3461y;
                if (interfaceC1461o3 == null || !interfaceC1461o3.E()) {
                    interfaceC1461o3 = null;
                }
                if (interfaceC1461o3 != null) {
                    return com.bumptech.glide.d.U(p038d0.c.f21397b, p168o5.b.b0(interfaceC1461o3.N()));
                }
                return null;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                F8.I i12 = (F8.I) obj;
                p230ta.E.t(j0.j(i12), null, new F8.E(i12, (p184p9.e) obj2, null), 3);
                return wVar;
            case 13:
                p025c0.e.a((p025c0.e) obj);
                ((A8.B) obj2).m();
                return wVar;
            case 14:
                p025c0.e.a((p025c0.e) obj);
                ((C.p) obj2).m();
                return wVar;
            case 15:
                H0.y yVar = (H0.y) obj;
                Z z3 = (Z) obj2;
                if (!B0.C.a(yVar.f4467b, ((H0.y) z3.getValue()).f4467b)) {
                    z3.setValue(yVar);
                } else if (!p097ha.k.b(yVar.f4468c, ((H0.y) z3.getValue()).f4468c)) {
                    z3.setValue(yVar);
                }
                return wVar;
            case 16:
                ((I.y0) obj).f5726s.invoke(new H0.j(((H0.k) obj2).f4437d));
                return Boolean.TRUE;
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                I.y0 y0Var = (I.y0) obj;
                p025c0.l lVar = (p025c0.l) obj2;
                if (y0Var.b()) {
                    H0.E e10 = y0Var.f5712d;
                    if (e10 != null && e10.a()) {
                        e10.f4412b.k(H0.A.f4394c);
                    }
                } else {
                    lVar.a();
                }
                return Boolean.TRUE;
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                long j11 = ((N0.i) ((Z) obj2).getValue()).f8983a;
                K.y yVar2 = (K.y) obj;
                if (yVar2.h().f4466a.f714a.length() == 0) {
                    jK = p038d0.c.f21399d;
                } else {
                    I.H h10 = (I.H) yVar2.f6767n.getValue();
                    int i13 = h10 == null ? -1 : K.A.f6666a[h10.ordinal()];
                    if (i13 != -1) {
                        if (i13 == 1 || i13 == 2) {
                            long j12 = yVar2.h().f4467b;
                            int i14 = B0.C.f685c;
                            j10 = j12 >> 32;
                        } else {
                            if (i13 != 3) {
                                throw new U();
                            }
                            long j13 = yVar2.h().f4467b;
                            int i15 = B0.C.f685c;
                            j10 = j13 & 4294967295L;
                        }
                        int iF = yVar2.f6756b.f((int) j10);
                        I.y0 y0Var2 = yVar2.f6758d;
                        if (y0Var2 == null || (z0VarC = y0Var2.c()) == null) {
                            jK = p038d0.c.f21399d;
                        } else {
                            B0.B b10 = z0VarC.f5730a;
                            I.y0 y0Var3 = yVar2.f6758d;
                            if (y0Var3 == null || (c0049f = (C0049f) y0Var3.f5709a.f5443b) == null) {
                                jK = p038d0.c.f21399d;
                            } else {
                                p163na.g gVar = new p163na.g(0, c0049f.f714a.length() - 1, 1);
                                if (gVar.isEmpty()) {
                                    throw new IllegalArgumentException("Cannot coerce value to an empty range: " + gVar + '.');
                                }
                                Integer num = 0;
                                if (iF < num.intValue()) {
                                    Integer num2 = 0;
                                    iF = num2.intValue();
                                } else {
                                    int i16 = gVar.f25927b;
                                    if (iF > Integer.valueOf(i16).intValue()) {
                                        iF = Integer.valueOf(i16).intValue();
                                    }
                                }
                                long jA = b10.b(iF).a();
                                I.y0 y0Var4 = yVar2.f6758d;
                                if (y0Var4 == null || (interfaceC1461o = y0Var4.f5715g) == null || (z0VarC2 = y0Var4.c()) == null || (interfaceC1461o2 = z0VarC2.f5731b) == null || (cVar = (p038d0.c) yVar2.f6768o.getValue()) == null) {
                                    jK = p038d0.c.f21399d;
                                } else {
                                    float fD = p038d0.c.d(interfaceC1461o2.k(interfaceC1461o, cVar.f21401a));
                                    int iF2 = b10.f(iF);
                                    int iJ = b10.j(iF2);
                                    int iE = b10.e(iF2, true);
                                    boolean z5 = ((int) (yVar2.h().f4467b >> 32)) > ((int) (yVar2.h().f4467b & 4294967295L));
                                    float F10 = com.bumptech.glide.e.F(b10, iJ, true, z5);
                                    float F11 = com.bumptech.glide.e.F(b10, iE, false, z5);
                                    float fR = Ua.l.r(fD, Math.min(F10, F11), Math.max(F10, F11));
                                    jK = Math.abs(fD - fR) > ((float) (((int) (j11 >> 32)) / 2)) ? p038d0.c.f21399d : interfaceC1461o.k(interfaceC1461o2, p029c4.a.c0(fR, p038d0.c.e(jA)));
                                }
                            }
                        }
                    } else {
                        jK = p038d0.c.f21399d;
                    }
                }
                return new p038d0.c(jK);
            case 19:
                P.c cVar2 = (P.c) obj;
                Object[] objArr = cVar2.f10069b;
                int i17 = cVar2.f10068a;
                for (int i18 = 0; i18 < i17; i18++) {
                    Object obj3 = objArr[i18];
                    p097ha.k.d(obj3, "null cannot be cast to non-null type T of androidx.compose.runtime.collection.IdentityArraySet");
                    ((O.A) obj2).x(obj3);
                }
                return wVar;
            case 20:
                ((B7.n) obj).invoke((O8.o) obj2);
                return wVar;
            case 21:
                ((Z) obj).setValue(Boolean.FALSE);
                ((p097ha.a) obj2).m();
                return wVar;
            case 22:
                W8.n nVar = (W8.n) obj;
                E8.f1 f1Var = nVar instanceof E8.f1 ? (E8.f1) nVar : null;
                AbstractC0201v0 abstractC0201v0 = (f1Var == null || (l1 = f1Var.f3285R) == null) ? null : l1.f3151a;
                C0195s0 c0195s0 = abstractC0201v0 instanceof C0195s0 ? (C0195s0) abstractC0201v0 : null;
                String str = (c0195s0 == null || (c0209z0 = c0195s0.f3391a) == null) ? null : c0209z0.f3438c;
                d2 d2Var = (d2) nVar.f13322t.getValue();
                boolean z10 = nVar instanceof E8.f1;
                boolean z11 = d2Var instanceof C1430u0;
                String id = d2Var != null ? d2Var.getId() : null;
                String strB = d2Var != null ? d2Var.b() : null;
                L8.i iVarH = nVar.h();
                L8.h hVar = iVarH instanceof L8.h ? (L8.h) iVarH : null;
                C0190p0 c0190p0 = nVar.f13306c;
                return new O8.q((N8.a) obj2, z10, z11, id, strB, str, hVar, c0190p0 != null ? c0190p0.f3377f : null);
            case 23:
                if (((Q8.m) ((Z) obj2).getValue()).f10856b == Q8.l.f10852c) {
                    ((Q8.y) ((PollingActivity) obj).M.getValue()).f();
                }
                return wVar;
            case 24:
                ((B7.n) obj).invoke(((C0166d0) obj2).f3268b);
                return wVar;
            case 25:
                ((B7.n) obj).invoke(p054e4.e.P0((C0166d0) obj2));
                return wVar;
            case 26:
                X x10 = (X) obj;
                if (x10 != null) {
                    x10.a();
                }
                ((p097ha.i) obj2).m();
                return wVar;
            case 27:
                W8.n nVar2 = (W8.n) obj;
                return new W8.p(nVar2.f13326x, nVar2.f13320r, nVar2.k.f3423h, nVar2.f13293D, new P0.b(6, nVar2, (Application) obj2), nVar2 instanceof C0178j0);
            case 28:
                W8.n nVar3 = (W8.n) obj;
                nVar3.getClass();
                p230ta.E.t(j0.j(nVar3), null, new W8.h(nVar3, (p150m8.x) obj2, null), 3);
                return wVar;
            default:
                ((Y1.p) obj).d((C0798m) obj2);
                return wVar;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public k(Z z3, p084ga.a aVar) {
        super(0);
        this.f152a = 21;
        this.f153b = z3;
        this.f154c = (p097ha.a) aVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(Y1.p pVar, C0798m c0798m, boolean z3) {
        super(0);
        this.f152a = 29;
        this.f153b = pVar;
        this.f154c = c0798m;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public k(X x10, p084ga.a aVar) {
        super(0);
        this.f152a = 26;
        this.f153b = x10;
        this.f154c = (p097ha.i) aVar;
    }
}
