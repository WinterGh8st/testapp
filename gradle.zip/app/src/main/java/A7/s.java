package A7;

/* JADX INFO: loaded from: classes.dex */
public abstract class s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final V.a f182a = Ua.l.v(-371358251, p.f172b, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final V.a f183b = Ua.l.v(1522975635, p.f173c, false);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final V.a f184c = Ua.l.v(1521992335, q.f176b, false);

    static {
        Ua.l.v(-2070284225, q.f177c, false);
    }
}
