package A7;

import E.L;
import E.N;
import O.AbstractC0630v;
import O.C0629u;
import P7.f1;
import p248v9.V;

/* JADX INFO: loaded from: classes.dex */
public final class G extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f105b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f106c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f107d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ G(Object obj, Object obj2, boolean z3, int i10, int i11) {
        super(2);
        this.f104a = i11;
        this.f106c = obj;
        this.f107d = obj2;
        this.f105b = z3;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f104a) {
            case 0:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    p197qa.h.b(this.f105b, (V) this.f106c, (p025c0.l) this.f107d, c0629u, 24640, 12);
                }
                return T9.w.f11979a;
            case 1:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(9);
                A8.p pVar = (A8.p) this.f107d;
                android.support.v4.media.session.a.h((f1) this.f106c, pVar, this.f105b, (C0629u) obj, iS);
                return T9.w.f11979a;
            case 2:
                float fFloatValue = ((Number) obj).floatValue();
                float fFloatValue2 = ((Number) obj2).floatValue();
                if (this.f105b) {
                    fFloatValue = fFloatValue2;
                }
                p230ta.E.t((p282ya.e) this.f106c, null, new N((L) this.f107d, fFloatValue, null), 3);
                return Boolean.TRUE;
            case 3:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(519);
                M0.k kVar = (M0.k) this.f106c;
                K.y yVar = (K.y) this.f107d;
                com.bumptech.glide.d.X(this.f105b, kVar, yVar, (C0629u) obj, iS2);
                return T9.w.f11979a;
            default:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(1);
                p195q8.g.d((String) this.f106c, (Z.j) this.f107d, this.f105b, (C0629u) obj, iS3);
                return T9.w.f11979a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ G(boolean z3, Object obj, Object obj2, int i10, int i11) {
        super(2);
        this.f104a = i11;
        this.f105b = z3;
        this.f106c = obj;
        this.f107d = obj2;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public G(boolean z3, p282ya.e eVar, L l4) {
        super(2);
        this.f104a = 2;
        this.f105b = z3;
        this.f106c = eVar;
        this.f107d = l4;
    }
}
