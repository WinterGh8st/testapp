package A7;

import B.T;
import C7.C0070e;
import E.C0145f;
import G6.F0;
import L.f2;
import O.AbstractC0630v;
import O.C0619o0;
import O.C0629u;
import O.v0;
import W7.J;
import com.flamingotools.ws.R;
import com.stripe.android.financialconnections.FinancialConnectionsSheetActivity;
import p248v9.V0;

/* JADX INFO: loaded from: classes.dex */
public final class n extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f164a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f165b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f166c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(Object obj, int i10, int i11) {
        super(2);
        this.f164a = i11;
        this.f166c = obj;
        this.f165b = i10;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f164a) {
            case 0:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    f2.b(((J) this.f166c).a(this.f165b & 14, c0629u).toString(), null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u, 0, 0, 131070);
                }
                break;
            case 1:
                ((Number) obj2).intValue();
                p029c4.a.T((B7.m) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case 2:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    C.n nVar = (C.n) this.f166c;
                    B2.q qVar = nVar.f1492b.f1472b;
                    int i10 = this.f165b;
                    C0145f c0145fJ = qVar.j(i10);
                    ((C.f) c0145fJ.f2793c).f1467c.f0(nVar.f1493c, Integer.valueOf(i10 - c0145fJ.f2791a), c0629u2, 0);
                }
                break;
            case 3:
                ((Number) obj2).intValue();
                p143m0.c.n((androidx.compose.foundation.layout.b) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case 4:
                ((Number) obj2).intValue();
                p143m0.c.t((B7.m) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case 5:
                C0629u c0629u3 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    B2.q qVar2 = ((D.l) this.f166c).f2324b.f2319c;
                    int i11 = this.f165b;
                    C0145f c0145fJ2 = qVar2.j(i11);
                    ((D.g) c0145fJ2.f2793c).f2314c.f0(D.m.f2326a, Integer.valueOf(i11 - c0145fJ2.f2791a), c0629u3, 6);
                }
                break;
            case 6:
                ((Number) obj2).intValue();
                android.support.v4.media.session.a.k((D7.h) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case 7:
                int iIntValue = ((Number) obj).intValue();
                boolean z3 = obj2 instanceof v0;
                int i12 = this.f165b;
                C0629u c0629u4 = (C0629u) this.f166c;
                if (z3) {
                    c0629u4.f9657E.j(i12);
                    C0070e c0070e = new C0070e((v0) obj2, iIntValue, 3);
                    c0629u4.H(false);
                    c0629u4.L(c0070e);
                } else if (obj2 instanceof C0619o0) {
                    C0619o0 c0619o0 = (C0619o0) obj2;
                    O.A a3 = c0619o0.f9604b;
                    if (a3 != null) {
                        a3.u(c0619o0);
                    }
                    c0619o0.f9604b = null;
                    c0619o0.f9608f = null;
                    c0619o0.f9609g = null;
                    c0629u4.f9657E.j(i12);
                    C0070e c0070e2 = new C0070e((C0619o0) obj2, iIntValue, 4);
                    c0629u4.H(false);
                    c0629u4.L(c0070e2);
                }
                break;
            case 8:
                ((Number) obj2).intValue();
                p139l8.h.e((T) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                ((Number) obj2).intValue();
                FinancialConnectionsSheetActivity.u((FinancialConnectionsSheetActivity) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                ((Number) obj2).intValue();
                p195q8.n.h((Integer) this.f166c, (C0629u) obj, AbstractC0630v.S(this.f165b | 1));
                break;
            default:
                C0629u c0629u5 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    boolean zS = ((V0) this.f166c).s();
                    int i13 = this.f165b;
                    p196q9.a.a(zS ? p197qa.a.p(R.string.stripe_form_label_optional, new Object[]{p197qa.a.o(i13, c0629u5)}, c0629u5) : p197qa.a.o(i13, c0629u5), null, false, c0629u5, 0, 6);
                }
                break;
        }
        return T9.w.f11979a;
    }
}
