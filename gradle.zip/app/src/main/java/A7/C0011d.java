package A7;

import B.AbstractC0027i;
import B.AbstractC0037t;
import B.C0022d;
import B.C0024f;
import B.InterfaceC0035q;
import B.L;
import O.AbstractC0630v;
import O.C0610k;
import O.C0629u;
import O.W;
import O.Z;
import P7.C0658f0;
import P7.C0697z0;
import P7.f1;
import com.flamingotools.ws.R;
import com.stripe.android.financialconnections.features.networkingsavetolinkverification.NetworkingSaveToLinkVerificationState;
import java.util.List;
import p199r0.AbstractC1464s;
import p199r0.T;
import p220t0.C1593j;
import p220t0.C1598o;
import p220t0.InterfaceC1594k;
import p232u0.B0;
import p234u2.AbstractC1712b;
import p234u2.C1717g;
import p234u2.C1722l;
import p234u2.X;
import p250w.C1793g;
import p250w.C1796j;
import p271y.x0;

/* JADX INFO: renamed from: A7.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0011d extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f122a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f123b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f124c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f125d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f126e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f127f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0011d(Object obj, Object obj2, T9.c cVar, int i10, Object obj3, int i11) {
        super(3);
        this.f122a = i11;
        this.f124c = obj;
        this.f125d = obj2;
        this.f126e = cVar;
        this.f123b = i10;
        this.f127f = obj3;
    }

    /* JADX WARN: Type inference failed for: r1v28, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r9v0, types: [ga.c, java.lang.Object] */
    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        C0629u c0629u;
        W w9 = C0610k.f9587a;
        Object obj4 = this.f126e;
        T9.w wVar = T9.w.f11979a;
        ?? r10 = this.f127f;
        int i10 = this.f123b;
        Object obj5 = this.f124c;
        Object obj6 = this.f125d;
        switch (this.f122a) {
            case 0:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((InterfaceC0035q) obj, "$this$AccessibleDataCalloutBox");
                if ((iIntValue & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    C0022d c0022d = AbstractC0027i.f619a;
                    C0024f c0024f = new C0024f(12);
                    c0629u2.a0(-483455358);
                    Z.j jVar = Z.j.f14412b;
                    p199r0.B bA = AbstractC0037t.a(c0024f, Z.a.f14399v, c0629u2);
                    c0629u2.a0(-1323940314);
                    N0.b bVar = (N0.b) c0629u2.l(p232u0.W.f29758e);
                    N0.j jVar2 = (N0.j) c0629u2.l(p232u0.W.k);
                    B0 b10 = (B0) c0629u2.l(p232u0.W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o = C1593j.f29148b;
                    V.a aVarI = p195q8.h.i(jVar);
                    c0629u2.d0();
                    if (c0629u2.M) {
                        c0629u2.n(c1598o);
                    } else {
                        c0629u2.o0();
                    }
                    c0629u2.f9699x = false;
                    AbstractC0630v.P(c0629u2, C1593j.f29152f, bA);
                    AbstractC0630v.P(c0629u2, C1593j.f29150d, bVar);
                    AbstractC0630v.P(c0629u2, C1593j.f29153g, jVar2);
                    AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u2, b10, C1593j.f29154h, c0629u2), c0629u2, 2058660585);
                    List<f1> list = (List) obj5;
                    List list2 = list;
                    C0658f0 c0658f0 = (C0658f0) obj6;
                    if (list2.size() >= 5) {
                        c0629u2.a0(1860759824);
                        C0697z0 c0697z0 = c0658f0.f10368e;
                        p003a.a.k(c0658f0.f10367d, p197qa.a.p(R.string.stripe_success_infobox_accounts, new Object[]{Integer.valueOf(list2.size())}, c0629u2), c0697z0 != null ? c0697z0.f10452a : null, c0629u2, 0, 0);
                        c0629u = c0629u2;
                        c0629u.u(false);
                    } else {
                        c0629u = c0629u2;
                        c0629u.a0(1860760173);
                        for (f1 f1Var : list) {
                            C0697z0 c0697z1 = c0658f0.f10368e;
                            String str = c0697z1 != null ? c0697z1.f10452a : null;
                            p003a.a.k(f1Var.f10375d + " " + f1Var.c(), null, str, c0629u, 0, 2);
                        }
                        c0629u.u(false);
                    }
                    c0629u.a0(-2124194779);
                    Z7.b bVar2 = (Z7.b) c0629u.l(Z7.g.f14782e);
                    c0629u.u(false);
                    p029c4.a.M(null, bVar2.f14739c, 0.0f, 0.0f, c0629u, 0, 13);
                    p003a.a.j((j) obj4, (p084ga.a) r10, c0629u, ((i10 >> 6) & 112) | 8);
                    AbstractC1464s.n(c0629u, false, true, false, false);
                }
                break;
            case 1:
                W.b bVar3 = (W.b) obj;
                C0629u c0629u3 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f(bVar3, "saveableStateHolder");
                c0629u3.a0(-492369756);
                Object objE = c0629u3.E();
                if (objE == w9) {
                    objE = new E.z(bVar3, new A9.h((Z) r10, 4));
                    c0629u3.m0(objE);
                }
                c0629u3.u(false);
                E.z zVar = (E.z) objE;
                c0629u3.a0(-492369756);
                Object objE2 = c0629u3.E();
                if (objE2 == w9) {
                    objE2 = new T(new p169o6.h(zVar));
                    c0629u3.m0(objE2);
                }
                c0629u3.u(false);
                T t10 = (T) objE2;
                c0629u3.a0(-1523808190);
                Q3.i iVar = (Q3.i) obj5;
                if (iVar != null) {
                    U9.B.g(iVar, zVar, t10, c0629u3, ((i10 >> 6) & 14) | 576);
                }
                c0629u3.u(false);
                c0629u3.a0(511388516);
                p084ga.e eVar = (p084ga.e) obj4;
                boolean zF = c0629u3.f(zVar) | c0629u3.f(eVar);
                Object objE3 = c0629u3.E();
                if (zF || objE3 == w9) {
                    objE3 = new C7.i(4, zVar, eVar);
                    c0629u3.m0(objE3);
                }
                c0629u3.u(false);
                p195q8.m.e(t10, (Z.m) obj6, (p084ga.e) objE3, c0629u3, (i10 & 112) | 8);
                break;
            case 2:
                C0629u c0629u4 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((L) obj, "it");
                if ((iIntValue2 & 81) == 16 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    NetworkingSaveToLinkVerificationState networkingSaveToLinkVerificationState = (NetworkingSaveToLinkVerificationState) obj5;
                    AbstractC1712b abstractC1712bC = networkingSaveToLinkVerificationState.c();
                    if (p097ha.k.b(abstractC1712bC, X.f30009b) ? true : abstractC1712bC instanceof C1722l) {
                        c0629u4.a0(-1990075018);
                        com.bumptech.glide.d.M(0, c0629u4);
                        c0629u4.u(false);
                    } else if (abstractC1712bC instanceof p234u2.W) {
                        c0629u4.a0(-1990074965);
                        G6.C.z(networkingSaveToLinkVerificationState.b(), (x0) obj6, (K7.h) ((p234u2.W) abstractC1712bC).f30008b, this.f126e, c0629u4, 520 | ((i10 << 3) & 7168));
                        c0629u4.u(false);
                    } else if (abstractC1712bC instanceof C1717g) {
                        c0629u4.a0(-1990074695);
                        p029c4.a.h0(((C1717g) abstractC1712bC).f30029b, r10, c0629u4, ((i10 >> 6) & 112) | 8);
                        c0629u4.u(false);
                    } else {
                        c0629u4.a0(-1990074545);
                        c0629u4.u(false);
                    }
                }
                break;
            default:
                p250w.o oVar = (p250w.o) obj;
                C0629u c0629u5 = (C0629u) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                p097ha.k.f(oVar, "$this$AnimatedVisibility");
                if ((iIntValue3 & 14) == 0) {
                    iIntValue3 |= c0629u5.f(oVar) ? 4 : 2;
                }
                if ((iIntValue3 & 91) == 18 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    C1796j c1796j = (C1796j) obj5;
                    AbstractC0630v.c(oVar, new C0013f((X.u) obj4, obj6, c1796j, 23), c0629u5);
                    c1796j.f30971d.put(obj6, ((p250w.p) oVar).f30987a);
                    c0629u5.a0(-492369756);
                    Object objE4 = c0629u5.E();
                    if (objE4 == w9) {
                        objE4 = new C1793g();
                        c0629u5.m0(objE4);
                    }
                    c0629u5.u(false);
                    ((V.a) r10).f0((C1793g) objE4, obj6, c0629u5, Integer.valueOf((i10 >> 9) & 896));
                }
                break;
        }
        return wVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0011d(Object obj, Object obj2, Object obj3, T9.c cVar, int i10, int i11) {
        super(3);
        this.f122a = i11;
        this.f124c = obj;
        this.f125d = obj2;
        this.f126e = obj3;
        this.f127f = cVar;
        this.f123b = i10;
    }
}
