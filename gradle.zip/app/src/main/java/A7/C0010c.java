package A7;

import O.AbstractC0630v;
import O.C0629u;

/* JADX INFO: renamed from: A7.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0010c extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f120a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ V.a f121b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0010c(V.a aVar, int i10, int i11) {
        super(2);
        this.f120a = i11;
        this.f121b = aVar;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f120a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(7);
                p003a.a.b(this.f121b, (C0629u) obj, iS);
                break;
            case 1:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(7);
                com.bumptech.glide.d.P(this.f121b, (C0629u) obj, iS2);
                break;
            case 2:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(7);
                Ua.l.d(this.f121b, (C0629u) obj, iS3);
                break;
            case 3:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    this.f121b.invoke(c0629u, 6);
                }
                break;
            case 4:
                ((Number) obj2).intValue();
                int iS4 = AbstractC0630v.S(7);
                com.bumptech.glide.d.W(this.f121b, (C0629u) obj, iS4);
                break;
            case 5:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    this.f121b.invoke(c0629u2, 6);
                }
                break;
            default:
                ((Number) obj2).intValue();
                int iS5 = AbstractC0630v.S(7);
                Z7.g.a(this.f121b, (C0629u) obj, iS5);
                break;
        }
        return T9.w.f11979a;
    }
}
