package A7;

import F9.U;
import L.L0;
import L.M0;
import O.AbstractC0630v;
import O.C0629u;

/* JADX INFO: loaded from: classes.dex */
public final class F extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f101a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ float f102b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f103c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public F(float f10, L0 l1) {
        super(2);
        this.f102b = f10;
        this.f103c = l1;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f101a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(49);
                p123ja.a.g(this.f102b, (V.a) this.f103c, (C0629u) obj, iS);
                return T9.w.f11979a;
            default:
                M0 m2 = (M0) obj;
                long j10 = ((N0.i) obj2).f8983a;
                p097ha.k.f(m2, "state");
                int iOrdinal = m2.ordinal();
                float f10 = this.f102b;
                if (iOrdinal == 0) {
                    return Float.valueOf(f10);
                }
                if (iOrdinal == 1) {
                    int i10 = (int) (j10 & 4294967295L);
                    if (i10 != 0) {
                        return Float.valueOf(Math.max(0.0f, f10 - i10));
                    }
                } else {
                    if (iOrdinal != 2) {
                        throw new U();
                    }
                    float f11 = f10 / 2.0f;
                    if (((int) (j10 & 4294967295L)) >= f11 && !((L0) this.f103c).f7439a) {
                        return Float.valueOf(f11);
                    }
                }
                return null;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public F(float f10, V.a aVar, int i10) {
        super(2);
        this.f102b = f10;
        this.f103c = aVar;
    }
}
