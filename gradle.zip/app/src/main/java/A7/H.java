package A7;

import O.AbstractC0630v;
import O.C0629u;
import p248v9.V;

/* JADX INFO: loaded from: classes.dex */
public final class H extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ p025c0.l f108a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ V f109b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f110c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Throwable f111d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public H(p025c0.l lVar, V v10, boolean z3, Throwable th, int i10) {
        super(2);
        this.f108a = lVar;
        this.f109b = v10;
        this.f110c = z3;
        this.f111d = th;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        ((Number) obj2).intValue();
        int iS = AbstractC0630v.S(4167);
        V v10 = this.f109b;
        p168o5.b.l(this.f108a, v10, this.f110c, this.f111d, (C0629u) obj, iS);
        return T9.w.f11979a;
    }
}
