package A7;

import B.T;
import L.f2;
import O.C0629u;

/* JADX INFO: loaded from: classes.dex */
public final class C extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f85a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f86b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f87c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C(String str, int i10, int i11) {
        super(3);
        this.f85a = i11;
        this.f86b = str;
        this.f87c = i10;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        switch (this.f85a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$FinancialConnectionsButton");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    f2.b(this.f86b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u, (this.f87c >> 15) & 14, 0, 131070);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$FinancialConnectionsButton");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    f2.b(this.f86b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u2, (this.f87c >> 3) & 14, 0, 131070);
                }
                break;
            case 2:
                C0629u c0629u3 = (C0629u) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$FinancialConnectionsButton");
                if ((iIntValue3 & 81) == 16 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    f2.b(this.f86b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u3, this.f87c & 14, 0, 131070);
                }
                break;
            case 3:
                C0629u c0629u4 = (C0629u) obj2;
                int iIntValue4 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$TextButton");
                if ((iIntValue4 & 81) == 16 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    f2.b(this.f86b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u4, (this.f87c >> 9) & 14, 0, 131070);
                }
                break;
            default:
                C0629u c0629u5 = (C0629u) obj2;
                int iIntValue5 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$TextButton");
                if ((iIntValue5 & 81) == 16 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    f2.b(this.f86b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u5, (this.f87c >> 12) & 14, 0, 131070);
                }
                break;
        }
        return T9.w.f11979a;
    }
}
