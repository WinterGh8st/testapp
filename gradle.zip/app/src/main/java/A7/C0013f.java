package A7;

import B.I;
import B.J;
import B.M;
import B.O;
import B.P;
import B.Q;
import B0.C0044a;
import B0.C0047d;
import B0.C0049f;
import C9.C0099i1;
import F8.AbstractC0235q;
import F8.C0221c;
import G6.F0;
import I.C0423v;
import I.y0;
import I.z0;
import J8.C0469j;
import L.AbstractC0548v;
import O.Q0;
import O.Z;
import Y1.C0794i;
import Y1.C0798m;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import com.airbnb.mvrx.MavericksState;
import com.stripe.android.paymentsheet.addresselement.AddressElementActivity;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import p050e0.AbstractC1060m;
import p050e0.C1053f;
import p050e0.InterfaceC1062o;
import p183p8.C1387f1;
import p183p8.EnumC1394i;
import p183p8.d2;
import p199r0.K;
import p199r0.L;
import p230ta.InterfaceC1640h0;
import p232u0.InterfaceC1709y0;
import p234u2.AbstractC1723m;
import p250w.C1796j;
import p260x.a0;
import p283z.C1945e;
import p283z.InterfaceC1948f0;

/* JADX INFO: renamed from: A7.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0013f extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f134a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f135b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f136c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f137d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0013f(Z z3, C0049f c0049f, InterfaceC1709y0 interfaceC1709y0) {
        super(1);
        this.f134a = 21;
        this.f136c = z3;
        this.f137d = c0049f;
        this.f135b = interfaceC1709y0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v106, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v40, types: [ga.c, java.lang.Object] */
    @Override // p084ga.c
    public final Object invoke(Object obj) {
        Ua.l lVar;
        int iF;
        int iF2;
        p050e0.B bF;
        CharSequence charSequence;
        switch (this.f134a) {
            case 0:
                p097ha.k.f((String) obj, "it");
                ((InterfaceC1709y0) this.f135b).a(((j) this.f136c).f151e);
                ((p084ga.a) this.f137d).m();
                return T9.w.f11979a;
            case 1:
                K k = (K) obj;
                p097ha.k.f(k, "$this$layout");
                I i10 = (I) this.f135b;
                boolean z3 = i10.f515z;
                p199r0.E e10 = (p199r0.E) this.f137d;
                L l4 = (L) this.f136c;
                if (z3) {
                    K.d(k, l4, e10.S(i10.f513x), e10.S(i10.f514y));
                } else {
                    K.b(l4, e10.S(i10.f513x), e10.S(i10.f514y), 0.0f);
                }
                return T9.w.f11979a;
            case 2:
                K k3 = (K) obj;
                p097ha.k.f(k3, "$this$layout");
                J j10 = (J) this.f135b;
                long j11 = ((N0.g) j10.f516x.invoke((p199r0.E) this.f136c)).f8978a;
                boolean z5 = j10.f517y;
                L l10 = (L) this.f137d;
                if (z5) {
                    K.e(k3, l10, (int) (j11 >> 32), (int) (j11 & 4294967295L));
                } else {
                    K.f(k3, l10, (int) (j11 >> 32), (int) (j11 & 4294967295L), null, 12);
                }
                return T9.w.f11979a;
            case 3:
                K k4 = (K) obj;
                p097ha.k.f(k4, "$this$layout");
                B.K k10 = (B.K) this.f135b;
                boolean z10 = k10.f519B;
                p199r0.E e11 = (p199r0.E) this.f137d;
                L l11 = (L) this.f136c;
                if (z10) {
                    K.d(k4, l11, e11.S(k10.f520x), e11.S(k10.f521y));
                } else {
                    K.b(l11, e11.S(k10.f520x), e11.S(k10.f521y), 0.0f);
                }
                return T9.w.f11979a;
            case 4:
                p097ha.k.f((K) obj, "$this$layout");
                M m2 = (M) this.f137d;
                B.L l12 = m2.f527x;
                p199r0.E e12 = (p199r0.E) this.f136c;
                K.b((L) this.f135b, e12.S(l12.a(e12.getLayoutDirection())), e12.S(m2.f527x.f524b), 0.0f);
                return T9.w.f11979a;
            case 5:
                p097ha.k.f((K) obj, "$this$layout");
                N0.j layoutDirection = ((p199r0.E) this.f137d).getLayoutDirection();
                P p10 = (P) this.f135b;
                O o4 = (O) this.f136c;
                p097ha.k.f(layoutDirection, "layoutDirection");
                for (int i11 = 0; i11 < o4.f533b; i11++) {
                    L l13 = ((L[]) p10.f539e)[i11];
                    p097ha.k.c(l13);
                    Object objI = ((p199r0.A) ((List) p10.f538d).get(i11)).i();
                    Q q10 = objI instanceof Q ? (Q) objI : null;
                    if (q10 == null || (lVar = q10.f543c) == null) {
                        lVar = (Ua.l) p10.f537c;
                    }
                    int iE = o4.f532a - p10.e(l13);
                    int i12 = p10.f535a;
                    int iM = lVar.m(iE, i12 == 1 ? N0.j.f8984a : layoutDirection, l13);
                    int[] iArr = (int[]) o4.f534c;
                    if (i12 == 1) {
                        K.b(l13, iArr[i11], iM, 0.0f);
                    } else {
                        K.b(l13, iM, iArr[i11], 0.0f);
                    }
                }
                return T9.w.f11979a;
            case 6:
                int iIntValue = ((Number) obj).intValue();
                E.A a3 = (E.A) ((C.o) this.f135b).d();
                if (iIntValue >= 0 && iIntValue < a3.b()) {
                    p230ta.E.t((p282ya.e) this.f136c, null, new E.O((E.L) this.f137d, iIntValue, null), 3);
                    return Boolean.TRUE;
                }
                StringBuilder sbK = p096h9.i.k(iIntValue, "Can't scroll to index ", ", it is out of bounds [0, ");
                sbK.append(a3.b());
                sbK.append(')');
                throw new IllegalArgumentException(sbK.toString().toString());
            case 7:
                AbstractC0235q abstractC0235q = (AbstractC0235q) obj;
                p097ha.k.f(abstractC0235q, "result");
                p230ta.E.t((p282ya.e) this.f135b, null, new C0221c((p069f7.m) this.f136c, (AddressElementActivity) this.f137d, abstractC0235q, null), 3);
                return T9.w.f11979a;
            case 8:
                H0.y yVar = (H0.y) obj;
                p097ha.k.f(yVar, "newTextFieldValueState");
                ((Z) this.f136c).setValue(yVar);
                Z z11 = (Z) this.f137d;
                String str = (String) z11.getValue();
                C0049f c0049f = yVar.f4466a;
                boolean zB = p097ha.k.b(str, c0049f.f714a);
                String str2 = c0049f.f714a;
                z11.setValue(str2);
                if (!zB) {
                    this.f135b.invoke(str2);
                }
                return T9.w.f11979a;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p074g0.e eVar = (p074g0.e) obj;
                p097ha.k.f(eVar, "$this$drawBehind");
                y0 y0Var = (y0) this.f135b;
                z0 z0VarC = y0Var.c();
                if (z0VarC != null) {
                    InterfaceC1062o interfaceC1062oN = eVar.H().n();
                    p097ha.k.f(interfaceC1062oN, "canvas");
                    H0.y yVar2 = (H0.y) this.f136c;
                    p097ha.k.f(yVar2, "value");
                    H0.n nVar = (H0.n) this.f137d;
                    B0.B b10 = z0VarC.f5730a;
                    S3.o oVar = y0Var.f5727t;
                    p097ha.k.f(oVar, "selectionPaint");
                    long j12 = yVar2.f4467b;
                    boolean zB2 = B0.C.b(j12);
                    B0.j jVar = b10.f679b;
                    if (!zB2 && (iF = nVar.f(B0.C.d(j12))) != (iF2 = nVar.f(B0.C.c(j12)))) {
                        C0049f c0049f2 = (C0049f) jVar.f725a.f736b;
                        if (iF < 0 || iF > iF2 || iF2 > c0049f2.f714a.length()) {
                            StringBuilder sbG = p015b2.a.g("Start(", iF, ") or End(", iF2, ") is out of range [0..");
                            sbG.append(c0049f2.f714a.length());
                            sbG.append("), or start > end!");
                            throw new IllegalArgumentException(sbG.toString().toString());
                        }
                        if (iF == iF2) {
                            bF = p050e0.E.f();
                        } else {
                            ArrayList arrayList = jVar.f732h;
                            int iX = p123ja.a.x(iF, arrayList);
                            C1053f c1053fF = p050e0.E.f();
                            int size = arrayList.size();
                            while (iX < size) {
                                B0.m mVar = (B0.m) arrayList.get(iX);
                                int i13 = mVar.f742b;
                                if (i13 < iF2) {
                                    ArrayList arrayList2 = arrayList;
                                    if (i13 != mVar.f743c) {
                                        int iA = mVar.a(iF);
                                        int iA2 = mVar.a(iF2);
                                        C0044a c0044a = mVar.f741a;
                                        CharSequence charSequence2 = c0044a.f697e;
                                        if (iA < 0 || iA > iA2) {
                                            charSequence = charSequence2;
                                        } else {
                                            charSequence = charSequence2;
                                            if (iA2 <= charSequence.length()) {
                                                Path path = new Path();
                                                C0.y yVar3 = c0044a.f696d;
                                                yVar3.getClass();
                                                yVar3.f1617d.getSelectionPath(iA, iA2, path);
                                                int i14 = yVar3.f1619f;
                                                if (i14 != 0 && !path.isEmpty()) {
                                                    path.offset(0.0f, i14);
                                                }
                                                new RectF();
                                                Matrix matrix = new Matrix();
                                                long jC0 = p029c4.a.c0(0.0f, mVar.f746f);
                                                matrix.reset();
                                                matrix.setTranslate(p038d0.c.d(jC0), p038d0.c.e(jC0));
                                                path.transform(matrix);
                                                long j13 = p038d0.c.f21397b;
                                                c1053fF.f21736a.addPath(path, p038d0.c.d(j13), p038d0.c.e(j13));
                                            }
                                        }
                                        StringBuilder sbG2 = p015b2.a.g("Start(", iA, ") or End(", iA2, ") is out of Range(0..");
                                        sbG2.append(charSequence.length());
                                        sbG2.append("), or start > end!");
                                        throw new AssertionError(sbG2.toString());
                                    }
                                    iX++;
                                    size = size;
                                    arrayList = arrayList2;
                                } else {
                                    bF = c1053fF;
                                }
                            }
                            bF = c1053fF;
                        }
                        interfaceC1062oN.b(bF, oVar);
                    }
                    long j14 = b10.f680c;
                    byte b11 = ((float) ((int) (j14 >> 32))) < jVar.f728d || jVar.f727c || ((float) ((int) (j14 & 4294967295L))) < jVar.f729e;
                    B0.A a9 = b10.f678a;
                    byte b12 = b11 == true && a9.f673f != 3;
                    if (b12 != false) {
                        p038d0.d dVarU = com.bumptech.glide.d.U(p038d0.c.f21397b, p054e4.e.o((int) (j14 >> 32), (int) (j14 & 4294967295L)));
                        interfaceC1062oN.m();
                        InterfaceC1062o.s(interfaceC1062oN, dVarU);
                    }
                    B0.y yVar4 = a9.f669b.f688a;
                    M0.m mVar2 = yVar4.f841m;
                    M0.r rVar = yVar4.f830a;
                    if (mVar2 == null) {
                        mVar2 = M0.m.f8459b;
                    }
                    M0.m mVar3 = mVar2;
                    p050e0.I i15 = yVar4.f842n;
                    if (i15 == null) {
                        i15 = p050e0.I.f21708d;
                    }
                    p050e0.I i16 = i15;
                    p074g0.f fVar = yVar4.f844p;
                    if (fVar == null) {
                        fVar = p074g0.h.f22729a;
                    }
                    p074g0.f fVar2 = fVar;
                    try {
                        AbstractC1060m abstractC1060mG = rVar.g();
                        M0.p pVar = M0.p.f8464a;
                        if (abstractC1060mG != null) {
                            B0.j.b(jVar, interfaceC1062oN, abstractC1060mG, rVar != pVar ? rVar.e() : 1.0f, i16, mVar3, fVar2);
                        } else {
                            B0.j.a(jVar, interfaceC1062oN, rVar != pVar ? rVar.f() : p050e0.q.f21745b, i16, mVar3, fVar2);
                        }
                    } finally {
                        if (b12 != false) {
                            interfaceC1062oN.k();
                        }
                    }
                }
                return T9.w.f11979a;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                List list = (List) obj;
                p097ha.k.f(list, "it");
                H0.E e13 = (H0.E) ((p097ha.u) this.f137d).f23278a;
                p169o6.h hVar = (p169o6.h) this.f135b;
                p097ha.k.f(hVar, "editProcessor");
                C0423v c0423v = (C0423v) this.f136c;
                p097ha.k.f(c0423v, "onValueChange");
                H0.y yVarJ = hVar.j(list);
                if (e13 != null) {
                    e13.b(null, yVarJ);
                }
                c0423v.invoke(yVarJ);
                return T9.w.f11979a;
            case 11:
                K k11 = (K) obj;
                p097ha.k.f(k11, "$this$layout");
                L l14 = (L) this.f135b;
                int i17 = l14.f27576a;
                float f10 = AbstractC0548v.f8064a;
                p199r0.E e14 = (p199r0.E) this.f136c;
                float f11 = i17 > e14.S(f10) * 2 ? AbstractC0548v.f8065b : AbstractC0548v.f8066c;
                L l15 = (L) this.f137d;
                K.d(k11, l15, 0, 0);
                K.d(k11, l14, e14.S(f11) + l15.f27576a, (-l14.f27577b) / 2);
                return T9.w.f11979a;
            case G6.y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p050e0.G g10 = (p050e0.G) obj;
                p097ha.k.f(g10, "$this$graphicsLayer");
                a0 a0Var = (a0) this.f136c;
                g10.f21694a = ((Number) a0Var.f31722r.getValue()).floatValue();
                g10.f21695b = ((Number) a0Var.f31722r.getValue()).floatValue();
                g10.f21696c = ((Number) ((a0) this.f137d).f31722r.getValue()).floatValue();
                g10.f21702s = ((p050e0.O) ((Z) this.f135b).getValue()).f21727a;
                return T9.w.f11979a;
            case 13:
                p097ha.k.f((String) obj, "it");
                this.f136c.m();
                ((InterfaceC1709y0) this.f135b).a((String) this.f137d);
                return T9.w.f11979a;
            case 14:
                p097ha.k.f((O.L) obj, "$this$DisposableEffect");
                p073g.j jVar2 = (p073g.j) this.f136c;
                p097ha.k.c(jVar2);
                O8.E e15 = (O8.E) this.f135b;
                e15.f9859w = new p088h1.g(jVar2.f().d("CollectBankAccountLauncher", new A8.s(17), new C0099i1(new B7.n(1, e15, O8.E.class, "handleCollectBankAccountResult", "handleCollectBankAccountResult(Lcom/stripe/android/payments/bankaccount/navigation/CollectBankAccountResultInternal;)V", 0, 28), 3)), 29);
                return new B.a0(3, (W8.n) this.f137d, e15);
            case 15:
                p207r9.e eVar2 = (p207r9.e) obj;
                p097ha.k.f(eVar2, "selectedLpm");
                if (!p097ha.k.b((p207r9.e) this.f135b, eVar2)) {
                    Z z12 = (Z) this.f137d;
                    String str3 = eVar2.f27877a;
                    z12.setValue(str3);
                    W8.n nVar2 = (W8.n) this.f136c;
                    nVar2.getClass();
                    p259wa.a0 a0Var2 = nVar2.f13322t;
                    d2 d2Var = (d2) a0Var2.getValue();
                    boolean z13 = (d2Var != null ? d2Var.b() : null) == null;
                    d2 d2Var2 = (d2) a0Var2.getValue();
                    String strI = d2Var2 != null ? Ua.l.I(d2Var2) : null;
                    H8.b bVar = nVar2.f13307d;
                    bVar.getClass();
                    bVar.a(new H8.f(str3, strI, z13));
                }
                return T9.w.f11979a;
            case 16:
                C0469j c0469j = (C0469j) obj;
                L8.l fVar3 = null;
                if (c0469j != null) {
                    Resources resources = ((Context) this.f135b).getResources();
                    p097ha.k.e(resources, "context.resources");
                    p207r9.e eVar3 = (p207r9.e) this.f136c;
                    p097ha.k.f(eVar3, "paymentMethod");
                    LinkedHashMap linkedHashMap = new LinkedHashMap();
                    LinkedHashMap linkedHashMap2 = c0469j.f6484a;
                    for (Map.Entry entry : linkedHashMap2.entrySet()) {
                        Object key = entry.getKey();
                        p248v9.O.Companion.getClass();
                        if (!p097ha.k.b(key, p248v9.O.f30499C) && !p097ha.k.b(entry.getKey(), p248v9.O.f30505d)) {
                            linkedHashMap.put(entry.getKey(), entry.getValue());
                        }
                    }
                    String str4 = eVar3.f27877a;
                    LinkedHashMap linkedHashMap3 = new LinkedHashMap();
                    LinkedHashMap linkedHashMap4 = new LinkedHashMap();
                    for (Map.Entry entry2 : linkedHashMap.entrySet()) {
                        if (!((p248v9.O) entry2.getKey()).f30519b) {
                            linkedHashMap4.put(entry2.getKey(), entry2.getValue());
                        }
                    }
                    LinkedHashMap linkedHashMap5 = new LinkedHashMap(U9.B.U(linkedHashMap4.size()));
                    for (Map.Entry entry3 : linkedHashMap4.entrySet()) {
                        linkedHashMap5.put(entry3.getKey(), ((p281y9.a) entry3.getValue()).f32755a);
                    }
                    LinkedHashMap linkedHashMap6 = new LinkedHashMap(U9.B.U(linkedHashMap5.size()));
                    for (Map.Entry entry4 : linkedHashMap5.entrySet()) {
                        linkedHashMap6.put(((p248v9.O) entry4.getKey()).f30518a, entry4.getValue());
                    }
                    p029c4.a.o0(linkedHashMap3, G6.C.W("type"), str4);
                    for (Map.Entry entry5 : linkedHashMap6.entrySet()) {
                        String str5 = (String) entry5.getKey();
                        p097ha.k.f(str5, "string");
                        p029c4.a.o0(linkedHashMap3, p185pa.k.e0(new p185pa.g(new p185pa.g(p197qa.l.a(new p197qa.l("[*([A-Za-z_0-9]+)]*"), str5), p132k9.e.f24589b, 1), p132k9.e.f24590c, 0)), (String) entry5.getValue());
                    }
                    LinkedHashMap linkedHashMap7 = new LinkedHashMap();
                    for (Map.Entry entry6 : linkedHashMap3.entrySet()) {
                        if (entry6.getValue() != null) {
                            linkedHashMap7.put(entry6.getKey(), entry6.getValue());
                        }
                    }
                    C1387f1 c1387f1 = new C1387f1(str4, eVar3.f27878b, null, null, null, null, null, null, null, null, null, null, null, null, null, null, Ua.d.a0("PaymentSheet"), U9.B.l0(linkedHashMap7));
                    if (str4.equals("card")) {
                        C0794i c0794i = EnumC1394i.f27120w;
                        p248v9.O.Companion.getClass();
                        p281y9.a aVar = (p281y9.a) linkedHashMap2.get(p248v9.O.f30505d);
                        String str6 = aVar != null ? aVar.f32755a : null;
                        c0794i.getClass();
                        fVar3 = new L8.e(c1387f1, C0794i.m(str6), c0469j.f6486c);
                    } else {
                        String string = resources.getString(eVar3.f27880d);
                        p097ha.k.e(string, "resources.getString(paym…thod.displayNameResource)");
                        fVar3 = new L8.f(string, eVar3.f27881e, eVar3.f27882f, eVar3.f27883g, c1387f1, c0469j.f6486c);
                    }
                }
                ((W8.n) this.f137d).w(fVar3);
                return T9.w.f11979a;
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                p097ha.k.f((O.L) obj, "$this$DisposableEffect");
                W.g gVar = (W.g) this.f135b;
                LinkedHashMap linkedHashMap8 = gVar.f13129b;
                Object obj2 = this.f136c;
                if (linkedHashMap8.containsKey(obj2)) {
                    throw new IllegalArgumentException(("Key " + obj2 + " was used multiple times ").toString());
                }
                gVar.f13128a.remove(obj2);
                LinkedHashMap linkedHashMap9 = gVar.f13129b;
                W.e eVar4 = (W.e) this.f137d;
                linkedHashMap9.put(obj2, eVar4);
                return new W.f(eVar4, gVar, obj2);
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                long j15 = ((p038d0.c) obj).f21401a;
                B0.B b13 = (B0.B) ((Z) this.f136c).getValue();
                if (b13 != null) {
                    C0049f c0049f3 = (C0049f) this.f135b;
                    int iL = b13.l(j15);
                    C0047d c0047d = (C0047d) U9.n.D0(c0049f3.b(iL, iL, "clickable"));
                    if (c0047d != null) {
                        ((p084ga.c) this.f137d).invoke(c0047d.f709a);
                    }
                }
                return T9.w.f11979a;
            case 19:
                p097ha.k.f((O.L) obj, "$this$DisposableEffect");
                Z z14 = (Z) this.f135b;
                boolean zBooleanValue = ((Boolean) z14.getValue()).booleanValue();
                Z1.f fVar4 = (Z1.f) this.f137d;
                Z z15 = (Z) this.f136c;
                if (zBooleanValue) {
                    for (C0798m c0798m : (List) z15.getValue()) {
                        p097ha.k.f(c0798m, "entry");
                        fVar4.b().b(c0798m);
                    }
                    z14.setValue(Boolean.FALSE);
                }
                return new B.a0(7, z15, fVar4);
            case 20:
                p037d.u uVar = (p037d.u) this.f135b;
                androidx.lifecycle.D d10 = (androidx.lifecycle.D) this.f136c;
                p049e.c cVar = (p049e.c) this.f137d;
                uVar.a(d10, cVar);
                return new E.x(cVar, 8);
            case 21:
                long j16 = ((p038d0.c) obj).f21401a;
                B0.B b14 = (B0.B) ((Z) this.f136c).getValue();
                if (b14 != null) {
                    int iL2 = b14.l(j16);
                    C0047d c0047d2 = (C0047d) U9.n.D0(((C0049f) this.f137d).a(iL2, iL2));
                    if (c0047d2 != null && p097ha.k.b(c0047d2.f712d, "URL")) {
                        ((InterfaceC1709y0) this.f135b).a((String) c0047d2.f709a);
                    }
                }
                return T9.w.f11979a;
            case 22:
                MavericksState mavericksState = (MavericksState) obj;
                p097ha.k.f(mavericksState, "state");
                Bundle bundle = new Bundle();
                bundle.putBundle("mvrx:saved_instance_state", AbstractC1723m.i(mavericksState, false));
                bundle.putSerializable("mvrx:saved_viewmodel_class", (Class) this.f135b);
                bundle.putSerializable("mvrx:saved_state_class", (Class) this.f136c);
                Object obj3 = this.f137d;
                if (obj3 != null) {
                    if (obj3 instanceof Parcelable) {
                        bundle.putParcelable("mvrx:saved_args", (Parcelable) obj3);
                    } else {
                        if (!(obj3 instanceof Serializable)) {
                            throw new IllegalStateException("Args must be parcelable or serializable");
                        }
                        bundle.putSerializable("mvrx:saved_args", (Serializable) obj3);
                    }
                }
                return bundle;
            case 23:
                p097ha.k.f((O.L) obj, "$this$DisposableEffect");
                return new W.f((X.u) this.f135b, this.f136c, (C1796j) this.f137d);
            case 24:
                p050e0.G g11 = (p050e0.G) obj;
                p097ha.k.f(g11, "$this$graphicsLayer");
                g11.f21696c = ((Number) ((Q0) this.f135b).getValue()).floatValue();
                a0 a0Var3 = (a0) this.f136c;
                g11.f21694a = ((Number) a0Var3.f31722r.getValue()).floatValue();
                g11.f21695b = ((Number) a0Var3.f31722r.getValue()).floatValue();
                g11.f21702s = ((p050e0.O) ((a0) this.f137d).f31722r.getValue()).f21727a;
                return T9.w.f11979a;
            default:
                float fFloatValue = ((Number) obj).floatValue();
                float f12 = ((C1945e) this.f135b).f33027e ? 1.0f : -1.0f;
                float fA = ((InterfaceC1948f0) this.f136c).a(f12 * fFloatValue) * f12;
                if (fA < fFloatValue) {
                    InterfaceC1640h0 interfaceC1640h0 = (InterfaceC1640h0) this.f137d;
                    CancellationException cancellationException = new CancellationException("Scroll animation cancelled because scroll was not consumed (" + fA + " < " + fFloatValue + ')');
                    cancellationException.initCause(null);
                    interfaceC1640h0.c(cancellationException);
                }
                return T9.w.f11979a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0013f(p084ga.a aVar, InterfaceC1709y0 interfaceC1709y0, String str) {
        super(1);
        this.f134a = 13;
        this.f136c = aVar;
        this.f135b = interfaceC1709y0;
        this.f137d = str;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0013f(Object obj, Object obj2, Object obj3, int i10) {
        super(1);
        this.f134a = i10;
        this.f135b = obj;
        this.f136c = obj2;
        this.f137d = obj3;
    }
}
