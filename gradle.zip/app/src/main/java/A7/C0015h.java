package A7;

import O.AbstractC0630v;
import O.C0629u;

/* JADX INFO: renamed from: A7.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0015h extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f140a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f141b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f142c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f143d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f144e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f145f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0015h(E.A a3, Object obj, int i10, Object obj2, int i11) {
        super(2);
        this.f140a = 2;
        this.f143d = a3;
        this.f144e = obj;
        this.f141b = i10;
        this.f145f = obj2;
        this.f142c = i11;
    }

    /* JADX WARN: Type inference failed for: r0v9, types: [ga.c, ha.l] */
    /* JADX WARN: Type inference failed for: r2v8, types: [ga.c, ha.l] */
    /* JADX WARN: Type inference failed for: r2v9, types: [ga.a, java.lang.Object] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f140a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(this.f141b | 1);
                String str = (String) this.f143d;
                p003a.a.k(str, (String) this.f144e, (String) this.f145f, (C0629u) obj, iS, this.f142c);
                break;
            case 1:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(this.f141b | 1);
                V.a aVar = (V.a) this.f145f;
                Z.d dVar = (Z.d) this.f144e;
                Ua.d.d((Z.m) this.f143d, dVar, aVar, (C0629u) obj, iS2, this.f142c);
                break;
            case 2:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(this.f142c | 1);
                int i10 = this.f141b;
                Object obj3 = this.f145f;
                p143m0.c.v((E.A) this.f143d, this.f144e, i10, obj3, (C0629u) obj, iS3);
                break;
            case 3:
                ((Number) obj2).intValue();
                int iS4 = AbstractC0630v.S(this.f142c | 1);
                V.a aVar2 = (V.a) this.f145f;
                G6.C.i(this.f143d, this.f141b, (E.H) this.f144e, aVar2, (C0629u) obj, iS4);
                break;
            case 4:
                ((Number) obj2).intValue();
                int iS5 = AbstractC0630v.S(this.f141b | 1);
                ?? r7 = (p097ha.l) this.f145f;
                ?? r10 = (p097ha.l) this.f143d;
                P0.m.a(r10, (Z.m) this.f144e, r7, (C0629u) obj, iS5, this.f142c);
                break;
            default:
                ((Number) obj2).intValue();
                int iS6 = AbstractC0630v.S(this.f141b | 1);
                ?? r11 = this.f144e;
                E5.b.i((Q8.m) this.f143d, r11, (Z.m) this.f145f, (C0629u) obj, iS6, this.f142c);
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0015h(p084ga.c cVar, Z.m mVar, p084ga.c cVar2, int i10, int i11) {
        super(2);
        this.f140a = 4;
        this.f143d = (p097ha.l) cVar;
        this.f144e = mVar;
        this.f145f = (p097ha.l) cVar2;
        this.f141b = i10;
        this.f142c = i11;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0015h(Object obj, int i10, E.H h10, V.a aVar, int i11) {
        super(2);
        this.f140a = 3;
        this.f143d = obj;
        this.f141b = i10;
        this.f144e = h10;
        this.f145f = aVar;
        this.f142c = i11;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0015h(Object obj, Object obj2, Object obj3, int i10, int i11, int i12) {
        super(2);
        this.f140a = i12;
        this.f143d = obj;
        this.f144e = obj2;
        this.f145f = obj3;
        this.f141b = i10;
        this.f142c = i11;
    }
}
