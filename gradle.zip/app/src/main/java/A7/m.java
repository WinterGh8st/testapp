package A7;

import L.AbstractC0511i0;
import L.AbstractC0545u;
import L.AbstractC0551w;
import O.C0629u;

/* JADX INFO: loaded from: classes.dex */
public final class m extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f161a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f162b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f163c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ m(p084ga.a aVar, int i10, int i11) {
        super(2);
        this.f161a = i11;
        this.f162b = aVar;
        this.f163c = i10;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v5, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r4v1, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v1, types: [ga.a, java.lang.Object] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        T9.w wVar = T9.w.f11979a;
        int i10 = this.f163c;
        int i11 = 2;
        switch (this.f161a) {
            case 0:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    float f10 = AbstractC0551w.f8072a;
                    c0629u.a0(-2124194779);
                    Z7.b bVar = (Z7.b) c0629u.l(Z7.g.f14782e);
                    c0629u.u(false);
                    Ua.l.i(this.f162b, null, false, null, null, AbstractC0551w.c(bVar.f14750o, c0629u, 5), s.f182a, c0629u, ((i10 >> 3) & 14) | 805306368, 382);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    float f11 = AbstractC0551w.f8072a;
                    c0629u2.a0(-2124194779);
                    Z7.b bVar2 = (Z7.b) c0629u2.l(Z7.g.f14782e);
                    c0629u2.u(false);
                    Ua.l.i(this.f162b, null, false, null, null, AbstractC0551w.c(bVar2.f14743g, c0629u2, 5), s.f183b, c0629u2, ((i10 >> 6) & 14) | 805306368, 382);
                }
                break;
            case 2:
                C0629u c0629u3 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    AbstractC0511i0.a(this.f162b, null, false, null, Q8.d.f10829c, c0629u3, (i10 & 14) | 24576, 14);
                }
                break;
            default:
                C0629u c0629u4 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    AbstractC0545u.c(Q8.d.f10828b, null, Ua.l.u(c0629u4, -1411609844, new m(this.f162b, i10, i11)), null, ((L.B) c0629u4.l(L.D.f7296a)).g(), 0L, 0, c0629u4, 1573254, 42);
                }
                break;
        }
        return wVar;
    }
}
