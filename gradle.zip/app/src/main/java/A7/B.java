package A7;

import java.util.List;
import javax.net.ssl.SSLPeerUnverifiedException;

/* JADX INFO: loaded from: classes.dex */
public final class B extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f83a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ p097ha.l f84b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public B(p084ga.a aVar, int i10) {
        super(0);
        this.f83a = i10;
        switch (i10) {
            case 1:
                this.f84b = (p097ha.l) aVar;
                super(0);
                break;
            case 2:
                this.f84b = (p097ha.l) aVar;
                super(0);
                break;
            default:
                this.f84b = (p097ha.l) aVar;
                break;
        }
    }

    /* JADX WARN: Type inference failed for: r0v2, types: [ga.a, ha.l] */
    /* JADX WARN: Type inference failed for: r0v5, types: [ga.a, ha.l] */
    /* JADX WARN: Type inference failed for: r0v7, types: [ga.a, ha.l] */
    @Override // p084ga.a
    public final Object m() {
        switch (this.f83a) {
            case 0:
                this.f84b.m();
                return T9.w.f11979a;
            case 1:
                try {
                    return (List) this.f84b.m();
                } catch (SSLPeerUnverifiedException unused) {
                    return U9.v.f12751a;
                }
            default:
                this.f84b.m();
                return T9.w.f11979a;
        }
    }
}
