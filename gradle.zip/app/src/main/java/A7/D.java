package A7;

import O.AbstractC0630v;
import O.C0629u;
import W7.I;
import java.util.List;
import p234u2.AbstractC1712b;
import p271y.x0;

/* JADX INFO: loaded from: classes.dex */
public final class D extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f88a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f89b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f90c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f91d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f92e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f93f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ Object f94q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ Object f95r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ Object f96s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Object f97t;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public D(I i10, I i11, p084ga.c cVar, List list, I i12, String str, I i13, p084ga.a aVar, int i14) {
        super(2);
        this.f91d = i10;
        this.f92e = i11;
        this.f95r = (p097ha.i) cVar;
        this.f96s = list;
        this.f93f = i12;
        this.f89b = str;
        this.f94q = i13;
        this.f97t = (p097ha.l) aVar;
        this.f90c = i14;
    }

    /* JADX WARN: Type inference failed for: r2v1, types: [ga.c, ha.i] */
    /* JADX WARN: Type inference failed for: r7v1, types: [ga.a, ha.l] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f88a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(this.f90c | 1);
                ?? r7 = (p097ha.l) this.f97t;
                ?? r10 = (p097ha.i) this.f95r;
                I i10 = (I) this.f93f;
                String str = this.f89b;
                p054e4.e.k((I) this.f91d, (I) this.f92e, r10, (List) this.f96s, i10, str, (I) this.f94q, r7, (C0629u) obj, iS);
                break;
            default:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(this.f90c | 1);
                B7.n nVar = (B7.n) this.f96s;
                B7.m mVar = (B7.m) this.f93f;
                D7.h hVar = (D7.h) this.f94q;
                D7.h hVar2 = (D7.h) this.f95r;
                android.support.v4.media.session.a.p(this.f89b, (AbstractC1712b) this.f91d, (D7.k) this.f92e, mVar, hVar, hVar2, nVar, (x0) this.f97t, (C0629u) obj, iS2);
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public D(String str, AbstractC1712b abstractC1712b, D7.k kVar, B7.m mVar, D7.h hVar, D7.h hVar2, B7.n nVar, x0 x0Var, int i10) {
        super(2);
        this.f89b = str;
        this.f91d = abstractC1712b;
        this.f92e = kVar;
        this.f93f = mVar;
        this.f94q = hVar;
        this.f95r = hVar2;
        this.f96s = nVar;
        this.f97t = x0Var;
        this.f90c = i10;
    }
}
