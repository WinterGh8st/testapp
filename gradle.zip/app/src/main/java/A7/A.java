package A7;

import D.C0136c;
import E8.C0178j0;
import E8.f1;
import F8.AbstractC0227i;
import F8.C0220b;
import F8.C0223e;
import F8.C0229k;
import F8.C0238u;
import G6.F0;
import G6.y0;
import I.AbstractC0406d0;
import I.e0;
import L.AbstractC0511i0;
import O.AbstractC0630v;
import O.C0591a0;
import O.C0610k;
import O.C0629u;
import O.EnumC0621p0;
import O.W;
import O.u0;
import U8.Z;
import U8.g0;
import X.AbstractC0775h;
import Y1.K;
import com.stripe.android.financialconnections.ui.FinancialConnectionsSheetNativeActivity;
import com.stripe.android.paymentsheet.addresselement.AddressElementActivity;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import p016b3.AbstractC0862l;
import p230ta.C1647l;
import p230ta.InterfaceC1645k;
import p257w7.C1822l;

/* JADX INFO: loaded from: classes.dex */
public final class A extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f81a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f82b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public A(Q8.y yVar, Z.m mVar, int i10) {
        super(2);
        this.f81a = 20;
        this.f82b = yVar;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v88, types: [ga.c, ha.l] */
    /* JADX WARN: Type inference failed for: r10v93, types: [ga.f, ha.l, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v17, types: [ga.e, ha.l] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        Collection collectionN0;
        InterfaceC1645k interfaceC1645kR = null;
        int i10 = 2;
        int i11 = 0;
        switch (this.f81a) {
            case 0:
                ((Number) obj2).intValue();
                p054e4.e.a((W7.F) this.f82b, (C0629u) obj, AbstractC0630v.S(1));
                return T9.w.f11979a;
            case 1:
                ((Number) obj2).intValue();
                p168o5.b.k((C1822l) this.f82b, (C0629u) obj, AbstractC0630v.S(1));
                return T9.w.f11979a;
            case 2:
                long j10 = ((N0.i) obj).f8983a;
                p097ha.k.f((N0.j) obj2, "<anonymous parameter 1>");
                return new N0.g(p143m0.c.g(0, ((Z.c) this.f82b).a(0, (int) (4294967295L & j10))));
            case 3:
                long j11 = ((N0.i) obj).f8983a;
                N0.j jVar = (N0.j) obj2;
                p097ha.k.f(jVar, "layoutDirection");
                return new N0.g(((Z.d) this.f82b).a(0L, j11, jVar));
            case 4:
                long j12 = ((N0.i) obj).f8983a;
                N0.j jVar2 = (N0.j) obj2;
                p097ha.k.f(jVar2, "layoutDirection");
                return new N0.g(p143m0.c.g(((Z.b) this.f82b).a(0, (int) (j12 >> 32), jVar2), 0));
            case 5:
                D.y yVar = (D.y) obj;
                ((Number) obj2).intValue();
                p097ha.k.f(yVar, "$this$null");
                return new C0136c(((C0136c) ((p084ga.c) this.f82b).invoke(yVar)).f2304a);
            case 6:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    com.bumptech.glide.d.J(false, 0.0f, false, (E7.g) this.f82b, c0629u, 384, 3);
                }
                return T9.w.f11979a;
            case 7:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    c0629u2.a0(773894976);
                    c0629u2.a0(-492369756);
                    Object objE = c0629u2.E();
                    W w9 = C0610k.f9587a;
                    if (objE == w9) {
                        O.D d10 = new O.D(AbstractC0630v.z(c0629u2));
                        c0629u2.m0(d10);
                        objE = d10;
                    }
                    c0629u2.u(false);
                    p282ya.e eVar = ((O.D) objE).f9451a;
                    c0629u2.u(false);
                    K[] kArr = new K[0];
                    c0629u2.a0(-514773754);
                    c0629u2.a0(-492369756);
                    Object objE2 = c0629u2.E();
                    if (objE2 == w9) {
                        objE2 = new p178p3.b();
                        c0629u2.m0(objE2);
                    }
                    c0629u2.u(false);
                    ArrayList arrayList = new ArrayList(2);
                    arrayList.add((p178p3.b) objE2);
                    if (kArr.length > 0) {
                        arrayList.ensureCapacity(arrayList.size() + kArr.length);
                        Collections.addAll(arrayList, kArr);
                    }
                    Y1.A aZ = android.support.v4.media.session.a.Z((K[]) arrayList.toArray(new K[arrayList.size()]), c0629u2);
                    c0629u2.u(false);
                    AddressElementActivity addressElementActivity = (AddressElementActivity) this.f82b;
                    B0.l lVar = addressElementActivity.f21052F;
                    ((C0229k) lVar.getValue()).f3800b.f3798a = aZ;
                    p069f7.m mVarU = p123ja.a.U(new C0223e(aZ, i11), c0629u2, 0, 0);
                    p143m0.c.a(false, new C0220b(addressElementActivity, i11), c0629u2, 0, 1);
                    ((C0229k) lVar.getValue()).f3800b.f3799b = new C0013f(eVar, mVarU, addressElementActivity, 7);
                    p229t9.l.a(null, null, null, Ua.l.u(c0629u2, 1044576262, new y(aZ, addressElementActivity, mVarU)), c0629u2, 3072, 7);
                }
                return T9.w.f11979a;
            case 8:
                ((Number) obj2).intValue();
                AbstractC0227i.c((C0238u) this.f82b, (C0629u) obj, AbstractC0630v.S(1));
                return T9.w.f11979a;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                ((Number) obj2).intValue();
                AbstractC0227i.d((K8.d) this.f82b, (C0629u) obj, AbstractC0630v.S(9));
                return T9.w.f11979a;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                C0629u c0629u3 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    com.bumptech.glide.d.J(false, 0.0f, true, (com.stripe.android.financialconnections.features.networkinglinkloginwarmup.a) this.f82b, c0629u3, 384, 3);
                }
                return T9.w.f11979a;
            case 11:
                ((Number) obj2).intValue();
                AbstractC0406d0.j((K.y) this.f82b, (C0629u) obj, AbstractC0630v.S(9));
                return T9.w.f11979a;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                C0629u c0629u4 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    I7.h hVar = (I7.h) this.f82b;
                    p195q8.d.c(true, hVar.f5919c, hVar.f5919c.f30612a.length() == 0, 1, c0629u4, 24646);
                }
                return T9.w.f11979a;
            case 13:
                C0629u c0629u5 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    com.bumptech.glide.d.J(false, 0.0f, false, (J7.d) this.f82b, c0629u5, 0, 7);
                }
                return T9.w.f11979a;
            case 14:
                C0629u c0629u6 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u6.C()) {
                    c0629u6.U();
                } else {
                    com.bumptech.glide.d.J(false, 0.0f, false, (M7.b) this.f82b, c0629u6, 0, 7);
                }
                return T9.w.f11979a;
            case 15:
                ((Number) obj2).intValue();
                android.support.v4.media.session.a.b((W7.G) this.f82b, (C0629u) obj, AbstractC0630v.S(1));
                return T9.w.f11979a;
            case 16:
                Set set = (Set) obj;
                p097ha.k.f(set, "changed");
                p097ha.k.f((AbstractC0775h) obj2, "<anonymous parameter 1>");
                u0 u0Var = (u0) this.f82b;
                synchronized (u0Var.f9705b) {
                    if (((EnumC0621p0) u0Var.f9719q.getValue()).compareTo(EnumC0621p0.f9622e) >= 0) {
                        u0Var.f9709f.c(set);
                        interfaceC1645kR = u0Var.r();
                    }
                    break;
                }
                if (interfaceC1645kR != null) {
                    ((C1647l) interfaceC1645kR).resumeWith(T9.w.f11979a);
                }
                return T9.w.f11979a;
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                Set set2 = (Set) obj;
                p097ha.k.f(set2, "changed");
                p097ha.k.f((AbstractC0775h) obj2, "<anonymous parameter 1>");
                ((p249va.j) this.f82b).p(set2);
                return T9.w.f11979a;
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                ((Number) obj2).intValue();
                ((Q0.o) this.f82b).a(AbstractC0630v.S(9), (C0629u) obj);
                return T9.w.f11979a;
            case 19:
                ((Number) obj2).intValue();
                ((Q0.t) this.f82b).a(AbstractC0630v.S(9), (C0629u) obj);
                return T9.w.f11979a;
            case 20:
                ((Number) obj2).intValue();
                E5.b.j((Q8.y) this.f82b, (C0629u) obj, AbstractC0630v.S(9));
                return T9.w.f11979a;
            case 21:
                ((Number) obj2).intValue();
                AbstractC0862l.j((C0178j0) this.f82b, (C0629u) obj, AbstractC0630v.S(9));
                return T9.w.f11979a;
            case 22:
                ((Number) obj2).intValue();
                com.bumptech.glide.e.g((f1) this.f82b, (C0629u) obj, AbstractC0630v.S(9));
                return T9.w.f11979a;
            case 23:
                C0629u c0629u7 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u7.C()) {
                    c0629u7.U();
                } else {
                    C0591a0 c0591a0 = AbstractC0630v.f9723a;
                    if (((Z) this.f82b).f12590c) {
                        p054e4.e.r(0, c0629u7);
                    }
                }
                return T9.w.f11979a;
            case 24:
                W.a aVar = (W.a) obj;
                p097ha.k.f(aVar, "$this$Saver");
                List list = (List) ((p097ha.l) this.f82b).invoke(aVar, obj2);
                int size = list.size();
                while (i11 < size) {
                    Object obj3 = list.get(i11);
                    if (obj3 != null && !aVar.f13113a.a(obj3)) {
                        throw new IllegalArgumentException("Failed requirement.");
                    }
                    i11++;
                }
                List list2 = list;
                if (list2.isEmpty()) {
                    return null;
                }
                return new ArrayList(list2);
            case 25:
                C0629u c0629u8 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u8.C()) {
                    c0629u8.U();
                } else {
                    Z7.g.a(Ua.l.u(c0629u8, -1473290515, new W7.C((FinancialConnectionsSheetNativeActivity) this.f82b)), c0629u8, 6);
                }
                return T9.w.f11979a;
            case 26:
                Collection collection = (Set) obj;
                p097ha.k.f(collection, "applied");
                p097ha.k.f((AbstractC0775h) obj2, "<anonymous parameter 1>");
                while (true) {
                    e0 e0Var = (e0) this.f82b;
                    AtomicReference atomicReference = (AtomicReference) e0Var.f5444c;
                    Object obj4 = atomicReference.get();
                    if (obj4 == null) {
                        collectionN0 = collection;
                    } else if (obj4 instanceof Set) {
                        collectionN0 = U9.o.k0(obj4, collection);
                    } else {
                        if (!(obj4 instanceof List)) {
                            AbstractC0630v.x("Unexpected notification");
                            throw null;
                        }
                        collectionN0 = U9.n.N0((Collection) obj4, G6.C.W(collection));
                    }
                    do {
                        if (atomicReference.compareAndSet(obj4, collectionN0)) {
                            if (e0.a(e0Var)) {
                                ((p097ha.l) e0Var.f5443b).invoke(new g0(e0Var, i10));
                            }
                            return T9.w.f11979a;
                        }
                    } while (atomicReference.get() == obj4);
                }
                break;
            case 27:
                C0629u c0629u9 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u9.C()) {
                    c0629u9.U();
                } else {
                    AbstractC0511i0.a(new X7.p((p037d.u) this.f82b, 0), null, false, null, X7.e.f13590c, c0629u9, 24576, 14);
                }
                return T9.w.f11979a;
            case 28:
                Z.m mVar = (Z.m) obj;
                Z.m mVarX = (Z.k) obj2;
                p097ha.k.f(mVar, "acc");
                p097ha.k.f(mVarX, "element");
                if (mVarX instanceof Z.g) {
                    ?? r10 = ((Z.g) mVarX).f14409c;
                    p097ha.x.c(3, r10);
                    Z.j jVar3 = Z.j.f14412b;
                    C0629u c0629u10 = (C0629u) this.f82b;
                    mVarX = G6.C.X(c0629u10, (Z.m) r10.I(jVar3, c0629u10, 0));
                }
                return mVar.k(mVarX);
            default:
                ((Number) obj2).intValue();
                Ua.d.e((Z1.j) this.f82b, (C0629u) obj, 1);
                return T9.w.f11979a;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public A(p084ga.e eVar) {
        super(2);
        this.f81a = 24;
        this.f82b = (p097ha.l) eVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ A(Object obj, int i10) {
        super(2);
        this.f81a = i10;
        this.f82b = obj;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ A(Object obj, int i10, int i11) {
        super(2);
        this.f81a = i11;
        this.f82b = obj;
    }
}
