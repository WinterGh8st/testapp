package A7;

import F8.AbstractC0227i;
import F8.C0228j;
import F8.C0229k;
import G6.F0;
import I.AbstractC0406d0;
import L.AbstractC0548v;
import O.AbstractC0630v;
import O.C0629u;
import Y1.C0798m;
import com.stripe.android.financialconnections.features.networkinglinkverification.NetworkingLinkVerificationState;
import com.stripe.android.paymentsheet.addresselement.AddressElementActivity;
import p016b3.AbstractC0862l;
import p232u0.C1691p;
import p232u0.M;
import p232u0.W;
import p234u2.AbstractC1712b;

/* JADX INFO: loaded from: classes.dex */
public final class y extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f200a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f201b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f202c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f203d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y(int i10, int i11, Object obj, Object obj2, Object obj3) {
        super(2);
        this.f200a = i11;
        this.f201b = obj;
        this.f202c = obj2;
        this.f203d = obj3;
    }

    /* JADX WARN: Type inference failed for: r0v16, types: [ga.f, ha.i] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f200a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(1);
                String str = (String) this.f203d;
                com.bumptech.glide.d.O((Z.m) this.f201b, (String) this.f202c, str, (C0629u) obj, iS);
                break;
            case 1:
                C0629u c0629u = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u.C()) {
                    c0629u.U();
                } else {
                    B7.m mVar = new B7.m(0, (Y1.A) this.f201b, AbstractC0227i.class, "navigateToContent", "navigateToContent(Landroidx/navigation/NavHostController;)V", 1, 6);
                    AddressElementActivity addressElementActivity = (AddressElementActivity) this.f202c;
                    p123ja.a.b((p069f7.m) this.f203d, new D7.h(0, ((C0229k) addressElementActivity.f21052F.getValue()).f3800b, C0228j.class, "dismiss", "dismiss(Lcom/stripe/android/paymentsheet/addresselement/AddressLauncherResult;)V", 0, 2), mVar, Ua.l.u(c0629u, 2011987697, new A9.i(1, (Y1.A) this.f201b, addressElementActivity)), c0629u, 24584, 2);
                }
                break;
            case 2:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(449);
                K.y yVar = (K.y) this.f202c;
                V.a aVar = (V.a) this.f203d;
                AbstractC0406d0.i((Z.m) this.f201b, yVar, aVar, (C0629u) obj, iS2);
                break;
            case 3:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(9);
                J7.d dVar = (J7.d) this.f202c;
                B7.n nVar = (B7.n) this.f203d;
                U9.B.i((NetworkingLinkVerificationState) this.f201b, dVar, nVar, (C0629u) obj, iS3);
                break;
            case 4:
                ((Number) obj2).intValue();
                AbstractC0548v.a(AbstractC0630v.S(391), (C0629u) obj, (V.a) this.f202c, (V.a) this.f203d, (Z.m) this.f201b);
                break;
            case 5:
                ((Number) obj2).intValue();
                int iS4 = AbstractC0630v.S(9);
                M7.b bVar = (M7.b) this.f202c;
                B7.n nVar2 = (B7.n) this.f203d;
                p168o5.b.g((AbstractC1712b) this.f201b, bVar, nVar2, (C0629u) obj, iS4);
                break;
            case 6:
                ((Number) obj2).intValue();
                int iS5 = AbstractC0630v.S(49);
                P0.m.c((p097ha.i) this.f202c, (Z.m) this.f201b, (P0.a) this.f203d, (C0629u) obj, iS5);
                break;
            case 7:
                ((Number) obj2).intValue();
                V.a aVar2 = (V.a) this.f203d;
                Ua.l.g((C0798m) this.f201b, (W.g) this.f202c, aVar2, (C0629u) obj, 457);
                break;
            case 8:
                ((Number) obj2).intValue();
                P0.b bVar2 = (P0.b) this.f203d;
                AbstractC0862l.g((Y1.A) this.f201b, (String) this.f202c, bVar2, (C0629u) obj, 9);
                break;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                ((Number) obj2).intValue();
                int iS6 = AbstractC0630v.S(49);
                p054e4.e.g((String) this.f202c, (Z.m) this.f201b, (p123ja.a) this.f203d, (C0629u) obj, iS6);
                break;
            default:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    W.a((C1691p) this.f201b, (M) this.f202c, (V.a) this.f203d, c0629u2, 72);
                }
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(Y1.A a3, AddressElementActivity addressElementActivity, p069f7.m mVar) {
        super(2);
        this.f200a = 1;
        this.f201b = a3;
        this.f202c = addressElementActivity;
        this.f203d = mVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public y(p084ga.f fVar, Z.m mVar, P0.a aVar, int i10) {
        super(2);
        this.f200a = 6;
        this.f202c = (p097ha.i) fVar;
        this.f201b = mVar;
        this.f203d = aVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y(Object obj, Z.m mVar, Object obj2, int i10, int i11) {
        super(2);
        this.f200a = i11;
        this.f202c = obj;
        this.f201b = mVar;
        this.f203d = obj2;
    }
}
