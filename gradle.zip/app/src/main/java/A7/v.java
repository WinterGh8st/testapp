package A7;

import B.T;
import L.f2;
import O.C0629u;

/* JADX INFO: loaded from: classes.dex */
public final class v extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f188a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f189b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ v(String str, int i10) {
        super(3);
        this.f188a = i10;
        this.f189b = str;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        switch (this.f188a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$FinancialConnectionsButton");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    f2.b(this.f189b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u, 0, 0, 131070);
                }
                break;
            default:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$FinancialConnectionsButton");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    f2.b(this.f189b, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u2, 0, 0, 131070);
                }
                break;
        }
        return T9.w.f11979a;
    }
}
