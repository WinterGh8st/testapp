package A7;

import O.AbstractC0630v;
import O.C0591a0;
import O.C0629u;
import O.y0;
import androidx.compose.ui.CompositionLocalMapInjectionElement;
import p199r0.AbstractC1464s;
import p220t0.C1592i;
import p220t0.C1593j;
import p220t0.InterfaceC1594k;

/* JADX INFO: renamed from: A7.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0014g extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f138a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z.m f139b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0014g(Z.m mVar, int i10) {
        super(3);
        this.f138a = i10;
        this.f139b = mVar;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        T9.w wVar = T9.w.f11979a;
        Z.m mVarX = this.f139b;
        switch (this.f138a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.layout.b) obj, "$this$StripeImage");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    C0591a0 c0591a0 = AbstractC0630v.f9723a;
                    p029c4.a.R(mVarX, c0629u, 0);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.layout.b) obj, "$this$StripeImage");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    C0591a0 c0591a1 = AbstractC0630v.f9723a;
                    p029c4.a.R(mVarX, c0629u2, 0);
                }
                break;
            case 2:
                C0629u c0629u3 = (C0629u) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.layout.b) obj, "$this$StripeImage");
                if ((iIntValue3 & 81) == 16 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    C0591a0 c0591a2 = AbstractC0630v.f9723a;
                    p029c4.a.R(mVarX, c0629u3, 0);
                }
                break;
            case 3:
                C0629u c0629u4 = (C0629u) obj2;
                int iIntValue4 = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.layout.b) obj, "$this$StripeImage");
                if ((iIntValue4 & 81) == 16 && c0629u4.C()) {
                    c0629u4.U();
                } else {
                    C0591a0 c0591a3 = AbstractC0630v.f9723a;
                    p029c4.a.R(mVarX, c0629u4, 0);
                }
                break;
            case 4:
                C0629u c0629u5 = (C0629u) obj2;
                int iIntValue5 = ((Number) obj3).intValue();
                p097ha.k.f((androidx.compose.foundation.layout.b) obj, "$this$StripeImage");
                if ((iIntValue5 & 81) == 16 && c0629u5.C()) {
                    c0629u5.U();
                } else {
                    C0591a0 c0591a4 = AbstractC0630v.f9723a;
                    p029c4.a.R(mVarX, c0629u5, 0);
                }
                break;
            case 5:
                C0629u c0629u6 = ((y0) obj).f9735a;
                C0629u c0629u7 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f(c0629u6, "$this$null");
                int i10 = c0629u7.f9665N;
                Z.m mVarX2 = G6.C.X(c0629u7, mVarX);
                c0629u6.a0(509942095);
                InterfaceC1594k.f29156n.getClass();
                AbstractC0630v.P(c0629u6, C1593j.f29149c, mVarX2);
                C1592i c1592i = C1593j.f29155i;
                if (c0629u6.M || !p097ha.k.b(c0629u6.E(), Integer.valueOf(i10))) {
                    AbstractC1464s.l(i10, c0629u6, i10, c1592i);
                }
                c0629u6.u(false);
                break;
            default:
                C0629u c0629u8 = ((y0) obj).f9735a;
                C0629u c0629u9 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f(c0629u8, "$this$null");
                int i11 = c0629u9.f9665N;
                p097ha.k.f(mVarX, "modifier");
                if (mVarX != Z.j.f14412b) {
                    mVarX = G6.C.X(c0629u9, new CompositionLocalMapInjectionElement(c0629u9.o()).k(mVarX));
                }
                c0629u8.a0(509942095);
                InterfaceC1594k.f29156n.getClass();
                AbstractC0630v.P(c0629u8, C1593j.f29149c, mVarX);
                C1592i c1592i2 = C1593j.f29155i;
                if (c0629u8.M || !p097ha.k.b(c0629u8.E(), Integer.valueOf(i11))) {
                    AbstractC1464s.l(i11, c0629u8, i11, c1592i2);
                }
                c0629u8.u(false);
                break;
        }
        return wVar;
    }
}
