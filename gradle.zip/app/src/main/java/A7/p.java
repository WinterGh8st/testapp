package A7;

import B.T;
import L.f2;
import O.C0610k;
import O.C0629u;
import com.flamingotools.ws.R;

/* JADX INFO: loaded from: classes.dex */
public final class p extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final p f172b = new p(3, 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final p f173c = new p(3, 1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final p f174d = new p(3, 2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f175a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ p(int i10, int i11) {
        super(i10);
        this.f175a = i11;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        switch (this.f175a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$TextButton");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    f2.b(p197qa.a.o(R.string.stripe_close_dialog_confirm, c0629u), null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u, 0, 0, 131070);
                }
                break;
            case 1:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((T) obj, "$this$TextButton");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    f2.b(p197qa.a.o(R.string.stripe_close_dialog_back, c0629u2), null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, null, c0629u2, 0, 0, 131070);
                }
                break;
            default:
                androidx.compose.foundation.layout.b bVar = (androidx.compose.foundation.layout.b) obj;
                C0629u c0629u3 = (C0629u) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                p097ha.k.f(bVar, "$this$StripeImage");
                if ((iIntValue3 & 14) == 0) {
                    iIntValue3 |= c0629u3.f(bVar) ? 4 : 2;
                }
                if ((iIntValue3 & 91) == 18 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    c0629u3.a0(-2124194779);
                    Z7.b bVar2 = (Z7.b) c0629u3.l(Z7.g.f14782e);
                    c0629u3.u(false);
                    long j10 = bVar2.f14744h;
                    Z.m mVarA = bVar.a(androidx.compose.foundation.layout.d.k(Z.j.f14412b, 6), Z.a.f14392e);
                    p050e0.q qVar = new p050e0.q(j10);
                    c0629u3.a0(1157296644);
                    boolean zF = c0629u3.f(qVar);
                    Object objE = c0629u3.E();
                    if (zF || objE == C0610k.f9587a) {
                        objE = new t(0, j10);
                        c0629u3.m0(objE);
                    }
                    c0629u3.u(false);
                    p195q8.g.c(mVarA, (p084ga.c) objE, c0629u3, 0);
                }
                break;
        }
        return T9.w.f11979a;
    }
}
