package A7;

/* JADX INFO: loaded from: classes.dex */
public abstract class u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final V.a f187a = Ua.l.v(1887923751, p.f174d, false);
}
