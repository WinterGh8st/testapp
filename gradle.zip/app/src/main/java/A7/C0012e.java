package A7;

import B.AbstractC0034p;
import G6.F0;
import O.AbstractC0630v;
import O.C0610k;
import O.C0629u;
import O.InterfaceC0611k0;
import O.y0;
import P7.C0658f0;
import P7.C0690w;
import com.stripe.android.financialconnections.features.networkingsavetolinkverification.NetworkingSaveToLinkVerificationState;
import java.util.List;
import p016b3.AbstractC0862l;
import p199r0.AbstractC1464s;
import p220t0.C1592i;
import p220t0.C1593j;
import p220t0.C1598o;
import p220t0.InterfaceC1594k;
import p230ta.l0;
import p232u0.C1710z;
import p234u2.AbstractC1712b;
import p260x.InterfaceC1892y;
import p260x.a0;
import p260x.d0;
import p260x.f0;
import p260x.g0;
import p260x.i0;
import p271y.x0;

/* JADX INFO: renamed from: A7.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0012e extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f128a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f129b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f130c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f131d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f132e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Object f133f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0012e(NetworkingSaveToLinkVerificationState networkingSaveToLinkVerificationState, p084ga.a aVar, p084ga.a aVar2, p084ga.c cVar, int i10) {
        super(2);
        this.f128a = 4;
        this.f130c = networkingSaveToLinkVerificationState;
        this.f131d = (p097ha.l) aVar;
        this.f132e = aVar2;
        this.f133f = cVar;
        this.f129b = i10;
    }

    /* JADX WARN: Type inference failed for: r0v16, types: [ga.f, ha.i] */
    /* JADX WARN: Type inference failed for: r1v12, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r1v9, types: [ga.a, ha.l] */
    /* JADX WARN: Type inference failed for: r2v11, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v8, types: [ga.a, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v10, types: [ga.c, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v8, types: [ga.c, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r3v9, types: [ga.a, java.lang.Object] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        switch (this.f128a) {
            case 0:
                ((Number) obj2).intValue();
                int iS = AbstractC0630v.S(this.f129b | 1);
                p003a.a.c((j) this.f130c, (C0658f0) this.f131d, (List) this.f132e, (p084ga.a) this.f133f, (C0629u) obj, iS);
                break;
            case 1:
                ((Number) obj2).intValue();
                int iS2 = AbstractC0630v.S(this.f129b | 1);
                p279y7.f fVar = (p279y7.f) this.f132e;
                p279y7.f fVar2 = (p279y7.f) this.f133f;
                p029c4.a.a0((p267x7.a) this.f130c, (p279y7.f) this.f131d, fVar, fVar2, (C0629u) obj, iS2);
                break;
            case 2:
                ((Number) obj2).intValue();
                int iS3 = AbstractC0630v.S(this.f129b | 1);
                com.stripe.android.financialconnections.features.consent.f.e((AbstractC1712b) this.f130c, (C0690w) this.f131d, (B7.n) this.f132e, (B7.m) this.f133f, (C0629u) obj, iS3);
                break;
            case 3:
                ((Number) obj2).intValue();
                int iS4 = AbstractC0630v.S(this.f129b | 1);
                AbstractC0862l.o((x0) this.f130c, (H7.d) this.f131d, (B7.n) this.f132e, (D7.h) this.f133f, (C0629u) obj, iS4);
                break;
            case 4:
                ((Number) obj2).intValue();
                int iS5 = AbstractC0630v.S(this.f129b | 1);
                ?? r7 = this.f132e;
                ?? r10 = this.f133f;
                G6.C.o((NetworkingSaveToLinkVerificationState) this.f130c, (p097ha.l) this.f131d, r7, r10, (C0629u) obj, iS5);
                break;
            case 5:
                ((Number) obj2).intValue();
                int iS6 = AbstractC0630v.S(this.f129b | 1);
                G6.C.z((AbstractC1712b) this.f130c, (x0) this.f131d, (K7.h) this.f132e, this.f133f, (C0629u) obj, iS6);
                break;
            case 6:
                ((Number) obj2).intValue();
                int iS7 = AbstractC0630v.S(this.f129b | 1);
                ?? r11 = this.f132e;
                ?? r12 = this.f133f;
                com.stripe.android.financialconnections.features.partnerauth.b.a((Throwable) this.f130c, this.f131d, r11, r12, (C0629u) obj, iS7);
                break;
            case 7:
                ((Number) obj2).intValue();
                int iS8 = AbstractC0630v.S(this.f129b | 1);
                P0.m.d((p097ha.i) this.f130c, (Z.m) this.f131d, (P0.a) this.f132e, (p084ga.c) this.f133f, (C0629u) obj, iS8);
                break;
            case 8:
                C0629u c0629u = (C0629u) obj;
                ((Number) obj2).intValue();
                p097ha.k.f(c0629u, "nc");
                ((V.a) this.f130c).c(this.f131d, this.f132e, this.f133f, c0629u, AbstractC0630v.S(this.f129b) | 1);
                break;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                C0629u c0629u2 = (C0629u) obj;
                if ((((Number) obj2).intValue() & 11) == 2 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    B7.f fVar3 = new B7.f((f0) this.f131d, 14);
                    c0629u2.a0(-1338768149);
                    g0 g0Var = i0.f31805a;
                    c0629u2.a0(-142660079);
                    d0 d0Var = (d0) this.f130c;
                    Object objB = d0Var.b();
                    c0629u2.a0(-438678252);
                    Object obj3 = this.f132e;
                    float f10 = p097ha.k.b(objB, obj3) ? 1.0f : 0.0f;
                    c0629u2.u(false);
                    Float fValueOf = Float.valueOf(f10);
                    Object value = d0Var.f31752c.getValue();
                    c0629u2.a0(-438678252);
                    float f11 = p097ha.k.b(value, obj3) ? 1.0f : 0.0f;
                    c0629u2.u(false);
                    a0 a0VarI = p197qa.h.i(d0Var, fValueOf, Float.valueOf(f11), (InterfaceC1892y) fVar3.I(d0Var.c(), c0629u2, 0), g0Var, "FloatAnimation", c0629u2);
                    c0629u2.u(false);
                    c0629u2.u(false);
                    Z.j jVar = Z.j.f14412b;
                    c0629u2.a0(1157296644);
                    boolean zF = c0629u2.f(a0VarI);
                    Object objE = c0629u2.E();
                    if (zF || objE == C0610k.f9587a) {
                        objE = new C1710z(a0VarI, 10);
                        c0629u2.m0(objE);
                    }
                    c0629u2.u(false);
                    Z.m mVarA = androidx.compose.ui.graphics.a.a(jVar, (p084ga.c) objE);
                    c0629u2.a0(733328855);
                    p199r0.B bC = AbstractC0034p.c(Z.a.f14388a, false, c0629u2);
                    c0629u2.a0(-1323940314);
                    int i10 = c0629u2.f9665N;
                    InterfaceC0611k0 interfaceC0611k0O = c0629u2.o();
                    InterfaceC1594k.f29156n.getClass();
                    C1598o c1598o = C1593j.f29148b;
                    V.a aVarJ = p195q8.h.j(mVarA);
                    c0629u2.d0();
                    if (c0629u2.M) {
                        c0629u2.n(c1598o);
                    } else {
                        c0629u2.o0();
                    }
                    AbstractC0630v.P(c0629u2, C1593j.f29152f, bC);
                    AbstractC0630v.P(c0629u2, C1593j.f29151e, interfaceC0611k0O);
                    C1592i c1592i = C1593j.f29155i;
                    if (c0629u2.M || !p097ha.k.b(c0629u2.E(), Integer.valueOf(i10))) {
                        AbstractC1464s.l(i10, c0629u2, i10, c1592i);
                    }
                    aVarJ.I(new y0(c0629u2), c0629u2, 0);
                    c0629u2.a0(2058660585);
                    ((V.a) this.f133f).I(obj3, c0629u2, Integer.valueOf((this.f129b >> 9) & 112));
                    AbstractC1464s.n(c0629u2, false, true, false, false);
                }
                break;
            default:
                ((Number) obj2).intValue();
                int iS9 = AbstractC0630v.S(this.f129b | 1);
                p279y7.f fVar4 = (p279y7.f) this.f132e;
                l0 l0Var = (l0) this.f133f;
                p195q8.g.e((Throwable) this.f130c, (p279y7.f) this.f131d, fVar4, l0Var, (C0629u) obj, iS9);
                break;
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public C0012e(p084ga.f fVar, Z.m mVar, P0.a aVar, p084ga.c cVar, int i10) {
        super(2);
        this.f128a = 7;
        this.f130c = (p097ha.i) fVar;
        this.f131d = mVar;
        this.f132e = aVar;
        this.f133f = cVar;
        this.f129b = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C0012e(Object obj, Object obj2, Object obj3, Object obj4, int i10, int i11) {
        super(2);
        this.f128a = i11;
        this.f130c = obj;
        this.f131d = obj2;
        this.f132e = obj3;
        this.f133f = obj4;
        this.f129b = i10;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0012e(d0 d0Var, int i10, f0 f0Var, Object obj, V.a aVar) {
        super(2);
        this.f128a = 9;
        this.f130c = d0Var;
        this.f129b = i10;
        this.f131d = f0Var;
        this.f132e = obj;
        this.f133f = aVar;
    }
}
