package A8;

import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;
import p016b3.AbstractC0862l;
import p230ta.E;

/* JADX INFO: loaded from: classes.dex */
public final class o extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Stripe3ds2TransactionActivity f271a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f272b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Stripe3ds2TransactionActivity f273c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ p083g9.B f274d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ B0.l f275e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(Stripe3ds2TransactionActivity stripe3ds2TransactionActivity, p083g9.B b10, B0.l lVar, X9.d dVar) {
        super(2, dVar);
        this.f273c = stripe3ds2TransactionActivity;
        this.f274d = b10;
        this.f275e = lVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new o(this.f273c, this.f274d, this.f275e, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((o) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Stripe3ds2TransactionActivity stripe3ds2TransactionActivity;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f272b;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            int i11 = Stripe3ds2TransactionActivity.f21030N;
            z zVar = (z) this.f275e.getValue();
            Stripe3ds2TransactionActivity stripe3ds2TransactionActivity2 = this.f273c;
            this.f271a = stripe3ds2TransactionActivity2;
            this.f272b = 1;
            d dVar = zVar.f325h;
            dVar.getClass();
            obj = E.C(dVar.f237f, new C0018c(this.f274d, dVar, null), this);
            if (obj == aVar) {
                return aVar;
            }
            stripe3ds2TransactionActivity = stripe3ds2TransactionActivity2;
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            stripe3ds2TransactionActivity = this.f271a;
            AbstractC0862l.m0(obj);
        }
        int i12 = Stripe3ds2TransactionActivity.f21030N;
        stripe3ds2TransactionActivity.u((p228t8.b) obj);
        return T9.w.f11979a;
    }
}
