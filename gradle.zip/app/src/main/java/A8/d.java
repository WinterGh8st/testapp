package A8;

import p016b3.AbstractC0862l;
import p217s8.C1570d;
import p217s8.P;
import p230ta.E;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f232a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p160n7.n f233b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1570d f234c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p160n7.y f235d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p081g7.f f236e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final X9.i f237f;

    public d(P p10, p160n7.n nVar, C1570d c1570d, p160n7.y yVar, p081g7.f fVar, X9.i iVar) {
        p097ha.k.f(p10, "stripeRepository");
        p097ha.k.f(nVar, "analyticsRequestExecutor");
        p097ha.k.f(c1570d, "paymentAnalyticsRequestFactory");
        p097ha.k.f(yVar, "retryDelaySupplier");
        p097ha.k.f(fVar, "logger");
        p097ha.k.f(iVar, "workContext");
        this.f232a = p10;
        this.f233b = nVar;
        this.f234c = c1570d;
        this.f235d = yVar;
        this.f236e = fVar;
        this.f237f = iVar;
    }

    /* JADX WARN: Code duplicated, block: B:8:0x0014  */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0098, code lost:
    
        if (r11 == r0) goto L28;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object a(p083g9.B r8, p160n7.i r9, int r10, Z9.c r11) {
        /*
            r7 = this;
            boolean r0 = r11 instanceof A8.C0016a
            if (r0 == 0) goto L14
            r0 = r11
            A8.a r0 = (A8.C0016a) r0
            int r1 = r0.f220q
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L14
            int r1 = r1 - r2
            r0.f220q = r1
        L12:
            r6 = r0
            goto L1a
        L14:
            A8.a r0 = new A8.a
            r0.<init>(r7, r11)
            goto L12
        L1a:
            java.lang.Object r11 = r6.f218e
            Y9.a r0 = Y9.a.f14375a
            int r1 = r6.f220q
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L47
            if (r1 == r3) goto L35
            if (r1 != r2) goto L2d
            p016b3.AbstractC0862l.m0(r11)
            goto L9b
        L2d:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r9)
            throw r8
        L35:
            int r10 = r6.f217d
            n7.i r9 = r6.f216c
            g9.B r8 = r6.f215b
            A8.d r1 = r6.f214a
            p016b3.AbstractC0862l.m0(r11)
            T9.j r11 = (T9.j) r11
            java.lang.Object r11 = r11.f11960a
        L44:
            r3 = r9
            r4 = r10
            goto L65
        L47:
            p016b3.AbstractC0862l.m0(r11)
            g9.M r11 = r8.f()
            java.lang.String r11 = r11.f22909b
            r6.f214a = r7
            r6.f215b = r8
            r6.f216c = r9
            r6.f217d = r10
            r6.f220q = r3
            s8.P r1 = r7.f232a
            java.lang.Object r11 = r1.f(r11, r9, r6)
            if (r11 != r0) goto L63
            goto L9a
        L63:
            r1 = r7
            goto L44
        L65:
            java.lang.Throwable r5 = T9.j.a(r11)
            if (r5 != 0) goto L8a
            p8.N1 r11 = (p183p8.N1) r11
            int r8 = 3 - r4
            g7.f r9 = r1.f236e
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            java.lang.String r11 = "3DS2 challenge completion request was successful. "
            r10.<init>(r11)
            r10.append(r8)
            java.lang.String r8 = " retries attempted."
            r10.append(r8)
            java.lang.String r8 = r10.toString()
            r9.d(r8)
            java.lang.Boolean r8 = java.lang.Boolean.TRUE
            return r8
        L8a:
            r9 = 0
            r6.f214a = r9
            r6.f215b = r9
            r6.f216c = r9
            r6.f220q = r2
            r2 = r8
            java.lang.Object r11 = r1.b(r2, r3, r4, r5, r6)
            if (r11 != r0) goto L9b
        L9a:
            return r0
        L9b:
            java.lang.Boolean r11 = (java.lang.Boolean) r11
            r11.getClass()
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: A8.d.a(g9.B, n7.i, int, Z9.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object b(p083g9.B b10, p160n7.i iVar, int i10, Throwable th, Z9.c cVar) {
        C0017b c0017b;
        d dVar;
        if (cVar instanceof C0017b) {
            c0017b = (C0017b) cVar;
            int i11 = c0017b.f227q;
            if ((i11 & Integer.MIN_VALUE) != 0) {
                c0017b.f227q = i11 - Integer.MIN_VALUE;
            } else {
                c0017b = new C0017b(this, cVar);
            }
        } else {
            c0017b = new C0017b(this, cVar);
        }
        Object obj = c0017b.f225e;
        Y9.a aVar = Y9.a.f14375a;
        int i12 = c0017b.f227q;
        if (i12 == 0) {
            AbstractC0862l.m0(obj);
            p081g7.f fVar = this.f236e;
            fVar.b("3DS2 challenge completion request failed. Remaining retries: " + i10, th);
            boolean z3 = th instanceof p107i7.c ? ((p107i7.c) th).f23693d : false;
            if (i10 <= 0 || !z3) {
                fVar.d("Did not make a successful 3DS2 challenge completion request after retrying.");
                return Boolean.FALSE;
            }
            long jA = this.f235d.a(i10);
            c0017b.f221a = this;
            c0017b.f222b = b10;
            c0017b.f223c = iVar;
            c0017b.f224d = i10;
            c0017b.f227q = 1;
            if (E.g(jA, c0017b) != aVar) {
                dVar = this;
            }
        }
        if (i12 != 1) {
            if (i12 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
            return obj;
        }
        i10 = c0017b.f224d;
        iVar = c0017b.f223c;
        b10 = c0017b.f222b;
        dVar = c0017b.f221a;
        AbstractC0862l.m0(obj);
        c0017b.f221a = null;
        c0017b.f222b = null;
        c0017b.f223c = null;
        c0017b.f227q = 2;
        Object objA = dVar.a(b10, iVar, i10 - 1, c0017b);
        return objA == aVar ? aVar : objA;
    }
}
