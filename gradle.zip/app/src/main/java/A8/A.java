package A8;

import L.AbstractC0492c;
import android.app.Application;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Application f206a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f207b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f208c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Set f209d;

    public A(Application application, boolean z3, String str, Set set) {
        p097ha.k.f(str, "publishableKey");
        p097ha.k.f(set, "productUsage");
        this.f206a = application;
        this.f207b = z3;
        this.f208c = str;
        this.f209d = set;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof A)) {
            return false;
        }
        A a3 = (A) obj;
        return p097ha.k.b(this.f206a, a3.f206a) && this.f207b == a3.f207b && p097ha.k.b(this.f208c, a3.f208c) && p097ha.k.b(this.f209d, a3.f209d);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v3, types: [int] */
    /* JADX WARN: Type inference failed for: r2v1, types: [int] */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4 */
    public final int hashCode() {
        int iHashCode = this.f206a.hashCode() * 31;
        boolean z3 = this.f207b;
        ?? r7 = z3;
        if (z3) {
            r7 = 1;
        }
        return this.f209d.hashCode() + AbstractC0492c.f((iHashCode + r7) * 31, 31, this.f208c);
    }

    public final String toString() {
        return "FallbackInitializeParam(application=" + this.f206a + ", enableLogging=" + this.f207b + ", publishableKey=" + this.f208c + ", productUsage=" + this.f209d + ")";
    }
}
