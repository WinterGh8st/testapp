package A8;

import E8.C0180k0;
import E8.C0182l0;
import F8.AbstractC0235q;
import F8.C0219a;
import F8.C0224f;
import F8.C0225g;
import F8.C0231m;
import F8.C0232n;
import F8.C0233o;
import F8.C0234p;
import F8.EnumC0230l;
import G6.F0;
import G6.y0;
import android.accounts.Account;
import android.app.PendingIntent;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.CredentialPickerConfig;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.auth.api.credentials.IdToken;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import p032c7.C0938n;
import p083g9.P;
import p183p8.InterfaceC1415p;
import p183p8.X1;
import p183p8.d2;

/* JADX INFO: loaded from: classes.dex */
public final class q implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f279a;

    public /* synthetic */ q(int i10) {
        this.f279a = i10;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        int i10;
        switch (this.f279a) {
            case 0:
                p097ha.k.f(parcel, "parcel");
                P p10 = (P) parcel.readParcelable(r.class.getClassLoader());
                C0938n c0938nCreateFromParcel = C0938n.CREATOR.createFromParcel(parcel);
                d2 d2Var = (d2) parcel.readParcelable(r.class.getClassLoader());
                X1 x1CreateFromParcel = X1.CREATOR.createFromParcel(parcel);
                p160n7.i iVar = (p160n7.i) parcel.readParcelable(r.class.getClassLoader());
                boolean z3 = parcel.readInt() != 0;
                Integer numValueOf = parcel.readInt() == 0 ? null : Integer.valueOf(parcel.readInt());
                String string = parcel.readString();
                String string2 = parcel.readString();
                int i11 = parcel.readInt();
                LinkedHashSet linkedHashSet = new LinkedHashSet(i11);
                for (int i12 = 0; i12 != i11; i12++) {
                    linkedHashSet.add(parcel.readString());
                }
                return new r(p10, c0938nCreateFromParcel, d2Var, x1CreateFromParcel, iVar, z3, numValueOf, string, string2, linkedHashSet);
            case 1:
                D4.b bVar = new D4.b();
                bVar.f2456s = 255;
                bVar.f2458u = -2;
                bVar.f2459v = -2;
                bVar.f2460w = -2;
                bVar.f2438D = Boolean.TRUE;
                bVar.f2448a = parcel.readInt();
                bVar.f2449b = (Integer) parcel.readSerializable();
                bVar.f2450c = (Integer) parcel.readSerializable();
                bVar.f2451d = (Integer) parcel.readSerializable();
                bVar.f2452e = (Integer) parcel.readSerializable();
                bVar.f2453f = (Integer) parcel.readSerializable();
                bVar.f2454q = (Integer) parcel.readSerializable();
                bVar.f2455r = (Integer) parcel.readSerializable();
                bVar.f2456s = parcel.readInt();
                bVar.f2457t = parcel.readString();
                bVar.f2458u = parcel.readInt();
                bVar.f2459v = parcel.readInt();
                bVar.f2460w = parcel.readInt();
                bVar.f2462y = parcel.readString();
                bVar.f2463z = parcel.readString();
                bVar.f2435A = parcel.readInt();
                bVar.f2437C = (Integer) parcel.readSerializable();
                bVar.f2439E = (Integer) parcel.readSerializable();
                bVar.f2440F = (Integer) parcel.readSerializable();
                bVar.f2441G = (Integer) parcel.readSerializable();
                bVar.f2442H = (Integer) parcel.readSerializable();
                bVar.f2443I = (Integer) parcel.readSerializable();
                bVar.f2444J = (Integer) parcel.readSerializable();
                bVar.M = (Integer) parcel.readSerializable();
                bVar.f2445K = (Integer) parcel.readSerializable();
                bVar.f2446L = (Integer) parcel.readSerializable();
                bVar.f2438D = (Boolean) parcel.readSerializable();
                bVar.f2461x = (Locale) parcel.readSerializable();
                bVar.f2447N = (Boolean) parcel.readSerializable();
                return bVar;
            case 2:
                p097ha.k.f(parcel, "parcel");
                String string3 = parcel.readString();
                String string4 = parcel.readString();
                String string5 = parcel.readString();
                boolean z5 = parcel.readInt() != 0;
                int i13 = parcel.readInt();
                LinkedHashSet linkedHashSet2 = new LinkedHashSet(i13);
                for (int i14 = 0; i14 != i13; i14++) {
                    linkedHashSet2.add(parcel.readString());
                }
                return new D8.c(string3, string4, string5, z5, linkedHashSet2, (InterfaceC1415p) parcel.readParcelable(D8.c.class.getClassLoader()), parcel.readInt() == 0 ? null : Integer.valueOf(parcel.readInt()));
            case 3:
                p097ha.k.f(parcel, "parcel");
                String string6 = parcel.readString();
                String string7 = parcel.readString();
                String string8 = parcel.readString();
                int i15 = 0;
                boolean z10 = parcel.readInt() != 0;
                int i16 = parcel.readInt();
                LinkedHashSet linkedHashSet3 = new LinkedHashSet(i16);
                while (true) {
                    String string9 = parcel.readString();
                    if (i15 == i16) {
                        return new D8.d(string6, string7, string8, z10, linkedHashSet3, string9, parcel.readInt() == 0 ? null : Integer.valueOf(parcel.readInt()));
                    }
                    linkedHashSet3.add(string9);
                    i15++;
                }
                break;
            case 4:
                p097ha.k.f(parcel, "parcel");
                String string10 = parcel.readString();
                String string11 = parcel.readString();
                String string12 = parcel.readString();
                int i17 = 0;
                boolean z11 = parcel.readInt() != 0;
                int i18 = parcel.readInt();
                LinkedHashSet linkedHashSet4 = new LinkedHashSet(i18);
                while (true) {
                    String string13 = parcel.readString();
                    if (i17 == i18) {
                        return new D8.e(string10, string11, string12, z11, linkedHashSet4, string13, parcel.readInt() == 0 ? null : Integer.valueOf(parcel.readInt()));
                    }
                    linkedHashSet4.add(string13);
                    i17++;
                }
                break;
            case 5:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return D8.r.f2597a;
            case 6:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return D8.s.f2598a;
            case 7:
                p097ha.k.f(parcel, "parcel");
                return new D8.t((Throwable) parcel.readSerializable());
            case 8:
                p097ha.k.f(parcel, "parcel");
                return new C0219a(parcel.readString(), parcel.readInt() == 0 ? null : C0180k0.CREATOR.createFromParcel(parcel), parcel.readString(), parcel.readInt() != 0 ? Boolean.valueOf(parcel.readInt() != 0) : null);
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p097ha.k.f(parcel, "parcel");
                return new C0224f(parcel.readString(), parcel.readInt() == 0 ? null : C0232n.CREATOR.createFromParcel(parcel));
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p097ha.k.f(parcel, "parcel");
                return new C0225g((AbstractC0235q) parcel.readParcelable(C0225g.class.getClassLoader()));
            case 11:
                p097ha.k.f(parcel, "parcel");
                return new C0231m(EnumC0230l.CREATOR.createFromParcel(parcel), parcel.readString());
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p097ha.k.f(parcel, "parcel");
                return EnumC0230l.valueOf(parcel.readString());
            case 13:
                p097ha.k.f(parcel, "parcel");
                C0182l0 c0182l0CreateFromParcel = C0182l0.CREATOR.createFromParcel(parcel);
                C0219a c0219aCreateFromParcel = parcel.readInt() == 0 ? null : C0219a.CREATOR.createFromParcel(parcel);
                int i19 = parcel.readInt();
                LinkedHashSet linkedHashSet5 = new LinkedHashSet(i19);
                for (int i20 = 0; i20 != i19; i20++) {
                    linkedHashSet5.add(parcel.readString());
                }
                String string14 = parcel.readString();
                C0231m c0231mCreateFromParcel = parcel.readInt() != 0 ? C0231m.CREATOR.createFromParcel(parcel) : null;
                String string15 = parcel.readString();
                String string16 = parcel.readString();
                int i21 = parcel.readInt();
                LinkedHashSet linkedHashSet6 = new LinkedHashSet(i21);
                for (int i22 = 0; i22 != i21; i22++) {
                    linkedHashSet6.add(parcel.readString());
                }
                return new C0232n(c0182l0CreateFromParcel, c0219aCreateFromParcel, linkedHashSet5, string14, c0231mCreateFromParcel, string15, string16, linkedHashSet6);
            case 14:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return C0233o.f3814a;
            case 15:
                p097ha.k.f(parcel, "parcel");
                return new C0234p(C0219a.CREATOR.createFromParcel(parcel));
            case 16:
                int iR0 = p054e4.e.R0(parcel);
                int iB0 = 0;
                int iB1 = 0;
                int iB2 = 0;
                long jD0 = 0;
                String strO = null;
                String strO2 = null;
                while (parcel.dataPosition() < iR0) {
                    int i23 = parcel.readInt();
                    switch ((char) i23) {
                        case 1:
                            iB0 = p054e4.e.B0(i23, parcel);
                            break;
                        case 2:
                            jD0 = p054e4.e.D0(i23, parcel);
                            break;
                        case 3:
                            strO = p054e4.e.O(i23, parcel);
                            break;
                        case 4:
                            iB1 = p054e4.e.B0(i23, parcel);
                            break;
                        case 5:
                            iB2 = p054e4.e.B0(i23, parcel);
                            break;
                        case 6:
                            strO2 = p054e4.e.O(i23, parcel);
                            break;
                        default:
                            p054e4.e.N0(i23, parcel);
                            break;
                    }
                }
                p054e4.e.X(iR0, parcel);
                return new H3.a(iB0, jD0, strO, iB1, iB2, strO2);
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                int iR1 = p054e4.e.R0(parcel);
                int iB3 = 0;
                String strO3 = null;
                Account account = null;
                int iB4 = 0;
                while (parcel.dataPosition() < iR1) {
                    int i24 = parcel.readInt();
                    char c10 = (char) i24;
                    if (c10 == 1) {
                        iB3 = p054e4.e.B0(i24, parcel);
                    } else if (c10 == 2) {
                        iB4 = p054e4.e.B0(i24, parcel);
                    } else if (c10 == 3) {
                        strO3 = p054e4.e.O(i24, parcel);
                    } else if (c10 != 4) {
                        p054e4.e.N0(i24, parcel);
                    } else {
                        account = (Account) p054e4.e.M(parcel, i24, Account.CREATOR);
                    }
                }
                p054e4.e.X(iR1, parcel);
                return new H3.b(iB3, iB4, strO3, account);
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                int iR2 = p054e4.e.R0(parcel);
                int iB5 = 0;
                ArrayList arrayListS = null;
                while (parcel.dataPosition() < iR2) {
                    int i25 = parcel.readInt();
                    char c11 = (char) i25;
                    if (c11 == 1) {
                        iB5 = p054e4.e.B0(i25, parcel);
                    } else if (c11 != 2) {
                        p054e4.e.N0(i25, parcel);
                    } else {
                        arrayListS = p054e4.e.S(parcel, i25, H3.a.CREATOR);
                    }
                }
                p054e4.e.X(iR2, parcel);
                return new H3.c(iB5, arrayListS);
            case 19:
                int iR3 = p054e4.e.R0(parcel);
                HashSet hashSet = new HashSet();
                int i26 = 0;
                ArrayList arrayList = null;
                K3.d dVar = null;
                int i27 = 0;
                while (parcel.dataPosition() < iR3) {
                    int i28 = parcel.readInt();
                    char c12 = (char) i28;
                    if (c12 == 1) {
                        int iB6 = p054e4.e.B0(i28, parcel);
                        hashSet.add(1);
                        i27 = iB6;
                    } else if (c12 == 2) {
                        ArrayList arrayListS2 = p054e4.e.S(parcel, i28, K3.e.CREATOR);
                        hashSet.add(2);
                        arrayList = arrayListS2;
                    } else if (c12 == 3) {
                        int iB7 = p054e4.e.B0(i28, parcel);
                        hashSet.add(3);
                        i26 = iB7;
                    } else if (c12 != 4) {
                        p054e4.e.N0(i28, parcel);
                    } else {
                        K3.d dVar2 = (K3.d) p054e4.e.M(parcel, i28, K3.d.CREATOR);
                        hashSet.add(4);
                        dVar = dVar2;
                    }
                }
                if (parcel.dataPosition() == iR3) {
                    return new K3.b(hashSet, i27, arrayList, i26, dVar);
                }
                throw new U3.b(p096h9.i.i(iR3, "Overread allowed size end="), parcel);
            case 20:
                int iR4 = p054e4.e.R0(parcel);
                int iB8 = 0;
                ArrayList arrayListQ = null;
                ArrayList arrayListQ2 = null;
                ArrayList arrayListQ3 = null;
                ArrayList arrayListQ4 = null;
                ArrayList arrayListQ5 = null;
                while (parcel.dataPosition() < iR4) {
                    int i29 = parcel.readInt();
                    switch ((char) i29) {
                        case 1:
                            iB8 = p054e4.e.B0(i29, parcel);
                            break;
                        case 2:
                            arrayListQ = p054e4.e.Q(i29, parcel);
                            break;
                        case 3:
                            arrayListQ2 = p054e4.e.Q(i29, parcel);
                            break;
                        case 4:
                            arrayListQ3 = p054e4.e.Q(i29, parcel);
                            break;
                        case 5:
                            arrayListQ4 = p054e4.e.Q(i29, parcel);
                            break;
                        case 6:
                            arrayListQ5 = p054e4.e.Q(i29, parcel);
                            break;
                        default:
                            p054e4.e.N0(i29, parcel);
                            break;
                    }
                }
                p054e4.e.X(iR4, parcel);
                return new K3.d(iB8, arrayListQ, arrayListQ2, arrayListQ3, arrayListQ4, arrayListQ5);
            case 21:
                int iR5 = p054e4.e.R0(parcel);
                HashSet hashSet2 = new HashSet();
                int iB9 = 0;
                K3.f fVar = null;
                String str = null;
                String str2 = null;
                String str3 = null;
                while (true) {
                    int i30 = iB9;
                    while (true) {
                        if (parcel.dataPosition() >= iR5) {
                            if (parcel.dataPosition() == iR5) {
                                return new K3.e(hashSet2, i30, fVar, str, str2, str3);
                            }
                            throw new U3.b(p096h9.i.i(iR5, "Overread allowed size end="), parcel);
                        }
                        i10 = parcel.readInt();
                        char c13 = (char) i10;
                        if (c13 != 1) {
                            if (c13 == 2) {
                                K3.f fVar2 = (K3.f) p054e4.e.M(parcel, i10, K3.f.CREATOR);
                                hashSet2.add(2);
                                fVar = fVar2;
                            } else if (c13 == 3) {
                                String strO4 = p054e4.e.O(i10, parcel);
                                hashSet2.add(3);
                                str = strO4;
                            } else if (c13 == 4) {
                                String strO5 = p054e4.e.O(i10, parcel);
                                hashSet2.add(4);
                                str2 = strO5;
                            } else if (c13 != 5) {
                                p054e4.e.N0(i10, parcel);
                            } else {
                                String strO6 = p054e4.e.O(i10, parcel);
                                hashSet2.add(5);
                                str3 = strO6;
                            }
                        }
                    }
                    iB9 = p054e4.e.B0(i10, parcel);
                    hashSet2.add(1);
                }
                break;
            case 22:
                int iR6 = p054e4.e.R0(parcel);
                HashSet hashSet3 = new HashSet();
                int i31 = 0;
                String str4 = null;
                byte[] bArr = null;
                PendingIntent pendingIntent = null;
                K3.a aVar = null;
                int i32 = 0;
                while (parcel.dataPosition() < iR6) {
                    int i33 = parcel.readInt();
                    switch ((char) i33) {
                        case 1:
                            int iB10 = p054e4.e.B0(i33, parcel);
                            hashSet3.add(1);
                            i32 = iB10;
                            break;
                        case 2:
                            String strO7 = p054e4.e.O(i33, parcel);
                            hashSet3.add(2);
                            str4 = strO7;
                            break;
                        case 3:
                            int iB11 = p054e4.e.B0(i33, parcel);
                            hashSet3.add(3);
                            i31 = iB11;
                            break;
                        case 4:
                            byte[] bArrI = p054e4.e.I(i33, parcel);
                            hashSet3.add(4);
                            bArr = bArrI;
                            break;
                        case 5:
                            PendingIntent pendingIntent2 = (PendingIntent) p054e4.e.M(parcel, i33, PendingIntent.CREATOR);
                            hashSet3.add(5);
                            pendingIntent = pendingIntent2;
                            break;
                        case 6:
                            K3.a aVar2 = (K3.a) p054e4.e.M(parcel, i33, K3.a.CREATOR);
                            hashSet3.add(6);
                            aVar = aVar2;
                            break;
                        default:
                            p054e4.e.N0(i33, parcel);
                            break;
                    }
                }
                if (parcel.dataPosition() == iR6) {
                    return new K3.f(hashSet3, i32, str4, i31, bArr, pendingIntent, aVar);
                }
                throw new U3.b(p096h9.i.i(iR6, "Overread allowed size end="), parcel);
            case 23:
                int iR7 = p054e4.e.R0(parcel);
                int iB12 = 0;
                boolean zT0 = false;
                boolean zT1 = false;
                long jD1 = 0;
                while (parcel.dataPosition() < iR7) {
                    int i34 = parcel.readInt();
                    char c14 = (char) i34;
                    if (c14 == 1) {
                        iB12 = p054e4.e.B0(i34, parcel);
                    } else if (c14 == 2) {
                        zT0 = p054e4.e.t0(i34, parcel);
                    } else if (c14 == 3) {
                        jD1 = p054e4.e.D0(i34, parcel);
                    } else if (c14 != 4) {
                        p054e4.e.N0(i34, parcel);
                    } else {
                        zT1 = p054e4.e.t0(i34, parcel);
                    }
                }
                p054e4.e.X(iR7, parcel);
                return new K3.a(iB12, zT0, jD1, zT1);
            case 24:
                int iR8 = p054e4.e.R0(parcel);
                String strO8 = null;
                String strO9 = null;
                Uri uri = null;
                ArrayList arrayListS3 = null;
                String strO10 = null;
                String strO11 = null;
                String strO12 = null;
                String strO13 = null;
                while (parcel.dataPosition() < iR8) {
                    int i35 = parcel.readInt();
                    switch ((char) i35) {
                        case 1:
                            strO8 = p054e4.e.O(i35, parcel);
                            break;
                        case 2:
                            strO9 = p054e4.e.O(i35, parcel);
                            break;
                        case 3:
                            uri = (Uri) p054e4.e.M(parcel, i35, Uri.CREATOR);
                            break;
                        case 4:
                            arrayListS3 = p054e4.e.S(parcel, i35, IdToken.CREATOR);
                            break;
                        case 5:
                            strO10 = p054e4.e.O(i35, parcel);
                            break;
                        case 6:
                            strO11 = p054e4.e.O(i35, parcel);
                            break;
                        case 7:
                        case '\b':
                        default:
                            p054e4.e.N0(i35, parcel);
                            break;
                        case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                            strO12 = p054e4.e.O(i35, parcel);
                            break;
                        case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                            strO13 = p054e4.e.O(i35, parcel);
                            break;
                    }
                }
                p054e4.e.X(iR8, parcel);
                return new Credential(strO8, strO9, uri, arrayListS3, strO10, strO11, strO12, strO13);
            case 25:
                int iR9 = p054e4.e.R0(parcel);
                int iB13 = 0;
                boolean zT2 = false;
                boolean zT3 = false;
                boolean zT4 = false;
                int iB14 = 0;
                while (parcel.dataPosition() < iR9) {
                    int i36 = parcel.readInt();
                    char c15 = (char) i36;
                    if (c15 == 1) {
                        zT2 = p054e4.e.t0(i36, parcel);
                    } else if (c15 == 2) {
                        zT3 = p054e4.e.t0(i36, parcel);
                    } else if (c15 == 3) {
                        zT4 = p054e4.e.t0(i36, parcel);
                    } else if (c15 == 4) {
                        iB14 = p054e4.e.B0(i36, parcel);
                    } else if (c15 != 1000) {
                        p054e4.e.N0(i36, parcel);
                    } else {
                        iB13 = p054e4.e.B0(i36, parcel);
                    }
                }
                p054e4.e.X(iR9, parcel);
                return new CredentialPickerConfig(iB13, zT2, zT3, zT4, iB14);
            case 26:
                int iR10 = p054e4.e.R0(parcel);
                int iB15 = 0;
                boolean zT5 = false;
                boolean zT6 = false;
                boolean zT7 = false;
                String[] strArrP = null;
                CredentialPickerConfig credentialPickerConfig = null;
                CredentialPickerConfig credentialPickerConfig2 = null;
                String strO14 = null;
                String strO15 = null;
                while (parcel.dataPosition() < iR10) {
                    int i37 = parcel.readInt();
                    char c16 = (char) i37;
                    if (c16 != 1000) {
                        switch (c16) {
                            case 1:
                                zT5 = p054e4.e.t0(i37, parcel);
                                break;
                            case 2:
                                strArrP = p054e4.e.P(i37, parcel);
                                break;
                            case 3:
                                credentialPickerConfig = (CredentialPickerConfig) p054e4.e.M(parcel, i37, CredentialPickerConfig.CREATOR);
                                break;
                            case 4:
                                credentialPickerConfig2 = (CredentialPickerConfig) p054e4.e.M(parcel, i37, CredentialPickerConfig.CREATOR);
                                break;
                            case 5:
                                zT6 = p054e4.e.t0(i37, parcel);
                                break;
                            case 6:
                                strO14 = p054e4.e.O(i37, parcel);
                                break;
                            case 7:
                                strO15 = p054e4.e.O(i37, parcel);
                                break;
                            case '\b':
                                zT7 = p054e4.e.t0(i37, parcel);
                                break;
                            default:
                                p054e4.e.N0(i37, parcel);
                                break;
                        }
                    } else {
                        iB15 = p054e4.e.B0(i37, parcel);
                    }
                }
                p054e4.e.X(iR10, parcel);
                return new L3.a(iB15, zT5, strArrP, credentialPickerConfig, credentialPickerConfig2, zT6, strO14, strO15, zT7);
            case 27:
                int iR11 = p054e4.e.R0(parcel);
                CredentialPickerConfig credentialPickerConfig3 = null;
                String[] strArrP2 = null;
                String strO16 = null;
                String strO17 = null;
                int iB16 = 0;
                boolean zT8 = false;
                boolean zT9 = false;
                boolean zT10 = false;
                while (parcel.dataPosition() < iR11) {
                    int i38 = parcel.readInt();
                    char c17 = (char) i38;
                    if (c17 != 1000) {
                        switch (c17) {
                            case 1:
                                credentialPickerConfig3 = (CredentialPickerConfig) p054e4.e.M(parcel, i38, CredentialPickerConfig.CREATOR);
                                break;
                            case 2:
                                zT8 = p054e4.e.t0(i38, parcel);
                                break;
                            case 3:
                                zT9 = p054e4.e.t0(i38, parcel);
                                break;
                            case 4:
                                strArrP2 = p054e4.e.P(i38, parcel);
                                break;
                            case 5:
                                zT10 = p054e4.e.t0(i38, parcel);
                                break;
                            case 6:
                                strO16 = p054e4.e.O(i38, parcel);
                                break;
                            case 7:
                                strO17 = p054e4.e.O(i38, parcel);
                                break;
                            default:
                                p054e4.e.N0(i38, parcel);
                                break;
                        }
                    } else {
                        iB16 = p054e4.e.B0(i38, parcel);
                    }
                }
                p054e4.e.X(iR11, parcel);
                return new HintRequest(iB16, credentialPickerConfig3, zT8, zT9, strArrP2, zT10, strO16, strO17);
            case 28:
                int iR12 = p054e4.e.R0(parcel);
                String strO18 = null;
                String strO19 = null;
                while (parcel.dataPosition() < iR12) {
                    int i39 = parcel.readInt();
                    char c18 = (char) i39;
                    if (c18 == 1) {
                        strO18 = p054e4.e.O(i39, parcel);
                    } else if (c18 != 2) {
                        p054e4.e.N0(i39, parcel);
                    } else {
                        strO19 = p054e4.e.O(i39, parcel);
                    }
                }
                p054e4.e.X(iR12, parcel);
                return new IdToken(strO18, strO19);
            default:
                L4.a aVar3 = new L4.a(parcel);
                aVar3.f8189a = ((Integer) parcel.readValue(L4.a.class.getClassLoader())).intValue();
                return aVar3;
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i10) {
        switch (this.f279a) {
            case 0:
                return new r[i10];
            case 1:
                return new D4.b[i10];
            case 2:
                return new D8.c[i10];
            case 3:
                return new D8.d[i10];
            case 4:
                return new D8.e[i10];
            case 5:
                return new D8.r[i10];
            case 6:
                return new D8.s[i10];
            case 7:
                return new D8.t[i10];
            case 8:
                return new C0219a[i10];
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                return new C0224f[i10];
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                return new C0225g[i10];
            case 11:
                return new C0231m[i10];
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                return new EnumC0230l[i10];
            case 13:
                return new C0232n[i10];
            case 14:
                return new C0233o[i10];
            case 15:
                return new C0234p[i10];
            case 16:
                return new H3.a[i10];
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                return new H3.b[i10];
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                return new H3.c[i10];
            case 19:
                return new K3.b[i10];
            case 20:
                return new K3.d[i10];
            case 21:
                return new K3.e[i10];
            case 22:
                return new K3.f[i10];
            case 23:
                return new K3.a[i10];
            case 24:
                return new Credential[i10];
            case 25:
                return new CredentialPickerConfig[i10];
            case 26:
                return new L3.a[i10];
            case 27:
                return new HintRequest[i10];
            case 28:
                return new IdToken[i10];
            default:
                return new L4.a[i10];
        }
    }
}
