package A8;

/* JADX INFO: renamed from: A8.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0016a extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public d f214a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p083g9.B f215b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public p160n7.i f216c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f217d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ Object f218e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ d f219f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f220q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0016a(d dVar, Z9.c cVar) {
        super(cVar);
        this.f219f = dVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f218e = obj;
        this.f220q |= Integer.MIN_VALUE;
        return this.f219f.a(null, null, 0, this);
    }
}
