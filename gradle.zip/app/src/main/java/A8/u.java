package A8;

import p183p8.P1;

/* JADX INFO: loaded from: classes.dex */
public final class u extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public z f293a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public P1 f294b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public D8.x f295c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f296d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ Object f297e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ z f298f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f299q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public u(z zVar, Z9.c cVar) {
        super(cVar);
        this.f298f = zVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f297e = obj;
        this.f299q |= Integer.MIN_VALUE;
        return this.f298f.e(null, this);
    }
}
