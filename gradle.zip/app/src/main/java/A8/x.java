package A8;

/* JADX INFO: loaded from: classes.dex */
public final class x extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public z f309a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f310b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ z f311c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f312d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x(z zVar, Z9.c cVar) {
        super(cVar);
        this.f311c = zVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f310b = obj;
        this.f312d |= Integer.MIN_VALUE;
        return this.f311c.g(this);
    }
}
