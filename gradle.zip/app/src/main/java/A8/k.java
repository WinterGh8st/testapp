package A8;

import java.util.Locale;
import java.util.Set;
import p032c7.C0940p;
import p217s8.P;
import p217s8.Q;

/* JADX INFO: loaded from: classes.dex */
public final class k implements E9.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f255a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final S9.a f256b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final S9.a f257c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final S9.a f258d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final S9.a f259e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final S9.a f260f;

    public /* synthetic */ k(S9.a aVar, S9.a aVar2, E9.d dVar, S9.a aVar3, S9.a aVar4, int i10) {
        this.f255a = i10;
        this.f256b = aVar;
        this.f257c = aVar2;
        this.f258d = dVar;
        this.f259e = aVar3;
        this.f260f = aVar4;
    }

    @Override // S9.a
    public final Object get() {
        switch (this.f255a) {
            case 0:
                return new j((C0940p) this.f256b.get(), ((Boolean) ((E9.e) this.f257c).f3445a).booleanValue(), (String) ((E9.e) this.f258d).f3445a, (p084ga.a) ((E9.e) this.f259e).f3445a, (Set) ((E9.e) this.f260f).f3445a);
            case 1:
                return new S8.f((P) ((Q) this.f257c).get(), (B8.a) this.f258d, (p081g7.f) this.f256b.get(), (X9.i) this.f259e.get(), (Set) this.f260f.get());
            case 2:
                S7.b bVar = (S7.b) ((S7.c) this.f257c).get();
                p160n7.g gVar = (p160n7.g) this.f256b.get();
                p160n7.i iVar = (p160n7.i) this.f258d.get();
                Locale locale = (Locale) this.f259e.get();
                p081g7.f fVar = (p081g7.f) this.f260f.get();
                p097ha.k.f(gVar, "apiRequestFactory");
                p097ha.k.f(iVar, "apiOptions");
                p097ha.k.f(fVar, "logger");
                if (locale == null) {
                    locale = Locale.getDefault();
                }
                Locale locale2 = locale;
                p097ha.k.e(locale2, "locale ?: Locale.getDefault()");
                return new U7.z(bVar, gVar, iVar, locale2, fVar, null);
            default:
                Y8.a aVar = (Y8.a) this.f256b.get();
                p160n7.i iVar2 = (p160n7.i) this.f257c.get();
                V7.a aVar2 = (V7.a) ((U7.B) this.f258d).get();
                Locale locale3 = (Locale) this.f259e.get();
                p081g7.f fVar2 = (p081g7.f) this.f260f.get();
                p097ha.k.f(aVar, "consumersApiService");
                p097ha.k.f(iVar2, "apiOptions");
                p097ha.k.f(fVar2, "logger");
                if (locale3 == null) {
                    locale3 = Locale.getDefault();
                }
                return new U7.k(aVar2, aVar, iVar2, locale3, fVar2);
        }
    }

    public k(S7.c cVar, S9.a aVar, S9.a aVar2, S9.a aVar3, S9.a aVar4) {
        this.f255a = 2;
        this.f257c = cVar;
        this.f256b = aVar;
        this.f258d = aVar2;
        this.f259e = aVar3;
        this.f260f = aVar4;
    }

    public k(Q q10, B8.a aVar, S9.a aVar2, S9.a aVar3, S9.a aVar4) {
        this.f255a = 1;
        this.f257c = q10;
        this.f258d = aVar;
        this.f256b = aVar2;
        this.f259e = aVar3;
        this.f260f = aVar4;
    }
}
