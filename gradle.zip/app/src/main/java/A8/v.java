package A8;

/* JADX INFO: loaded from: classes.dex */
public final class v extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f300a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z f301b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f302c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public v(z zVar, Z9.c cVar) {
        super(cVar);
        this.f301b = zVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f300a = obj;
        this.f302c |= Integer.MIN_VALUE;
        Object objF = this.f301b.f(null, null, null, 0, this);
        return objF == Y9.a.f14375a ? objF : new T9.j(objF);
    }
}
