package A8;

/* JADX INFO: loaded from: classes.dex */
public final class h extends i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p044d7.b f247a;

    public h(p044d7.b bVar) {
        this.f247a = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof h) && p097ha.k.b(this.f247a, ((h) obj).f247a);
    }

    public final int hashCode() {
        return this.f247a.hashCode();
    }

    public final String toString() {
        return "StartFallback(args=" + this.f247a + ")";
    }
}
