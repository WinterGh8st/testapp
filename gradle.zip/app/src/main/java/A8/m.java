package A8;

import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;

/* JADX INFO: loaded from: classes.dex */
public final class m extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f263a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Stripe3ds2TransactionActivity f264b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p073g.i f265c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ p f266d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ p073g.i f267e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ B0.l f268f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public m(Stripe3ds2TransactionActivity stripe3ds2TransactionActivity, p073g.i iVar, p pVar, p073g.i iVar2, B0.l lVar, X9.d dVar) {
        super(2, dVar);
        this.f264b = stripe3ds2TransactionActivity;
        this.f265c = iVar;
        this.f266d = pVar;
        this.f267e = iVar2;
        this.f268f = lVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new m(this.f264b, this.f265c, this.f266d, this.f267e, this.f268f, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((m) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0053, code lost:
    
        if (r8 == r0) goto L19;
     */
    @Override // Z9.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r8) throws java.lang.Exception {
        /*
            r7 = this;
            Y9.a r0 = Y9.a.f14375a
            int r1 = r7.f263a
            B0.l r2 = r7.f268f
            com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity r3 = r7.f264b
            r4 = 0
            r5 = 2
            r6 = 1
            if (r1 == 0) goto L21
            if (r1 == r6) goto L1d
            if (r1 != r5) goto L15
            p016b3.AbstractC0862l.m0(r8)
            goto L56
        L15:
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r8.<init>(r0)
            throw r8
        L1d:
            p016b3.AbstractC0862l.m0(r8)
            goto L39
        L21:
            p016b3.AbstractC0862l.m0(r8)
            boolean r8 = r3.isFinishing()
            if (r8 != 0) goto L8f
            java.lang.Object r8 = r2.getValue()
            A8.z r8 = (A8.z) r8
            r7.f263a = r6
            java.lang.Object r8 = r8.g(r7)
            if (r8 != r0) goto L39
            goto L55
        L39:
            A8.i r8 = (A8.i) r8
            boolean r1 = r8 instanceof A8.g
            if (r1 == 0) goto L74
            int r1 = com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity.f21030N
            java.lang.Object r1 = r2.getValue()
            A8.z r1 = (A8.z) r1
            A8.g r8 = (A8.g) r8
            g9.I r8 = r8.f246a
            r7.f263a = r5
            T0.f r1 = r1.f326i
            java.lang.Object r8 = r1.b(r8, r7)
            if (r8 != r0) goto L56
        L55:
            return r0
        L56:
            g9.L r8 = (p083g9.L) r8
            boolean r0 = r8 instanceof p083g9.K
            if (r0 == 0) goto L66
            g9.K r8 = (p083g9.K) r8
            j9.w r8 = r8.f22906a
            g.i r0 = r7.f265c
            r0.a(r8, r4)
            goto L8f
        L66:
            boolean r0 = r8 instanceof p083g9.J
            if (r0 == 0) goto L8f
            g9.J r8 = (p083g9.J) r8
            g9.B r8 = r8.f22905a
            A8.p r0 = r7.f266d
            r0.invoke(r8)
            goto L8f
        L74:
            boolean r0 = r8 instanceof A8.h
            if (r0 == 0) goto L82
            A8.h r8 = (A8.h) r8
            d7.b r8 = r8.f247a
            g.i r0 = r7.f267e
            r0.a(r8, r4)
            goto L8f
        L82:
            boolean r0 = r8 instanceof A8.f
            if (r0 == 0) goto L8f
            A8.f r8 = (A8.f) r8
            t8.b r8 = r8.f245a
            int r0 = com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity.f21030N
            r3.u(r8)
        L8f:
            T9.w r8 = T9.w.f11979a
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: A8.m.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
