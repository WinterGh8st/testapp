package A8;

import java.security.KeyPair;
import p016b3.AbstractC0862l;
import p032c7.V;
import p083g9.C1113m;
import p083g9.I;
import p083g9.M;
import p183p8.K1;
import p230ta.E;

/* JADX INFO: loaded from: classes.dex */
public final class y extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f313a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ K1 f314b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ D8.x f315c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f316d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ z f317e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ String f318f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(K1 k3, D8.x xVar, int i10, z zVar, String str, X9.d dVar) {
        super(2, dVar);
        this.f314b = k3;
        this.f315c = xVar;
        this.f316d = i10;
        this.f317e = zVar;
        this.f318f = str;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new y(this.f314b, this.f315c, this.f316d, this.f317e, this.f318f, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((y) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f313a;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            long j10 = V.f18185m;
            this.f313a = 1;
            if (E.g(j10, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        K1 k3 = this.f314b;
        C1113m c1113m = new C1113m(k3.f26840a, k3.f26843d, null, k3.f26842c, null);
        z zVar = this.f317e;
        String strB = zVar.f319b.f282c.b();
        if (strB == null) {
            strB = "";
        }
        p160n7.i iVar = zVar.f330n;
        M m2 = new M(strB, this.f318f, iVar.f25430a, iVar.f25431b);
        D8.x xVar = this.f315c;
        xVar.getClass();
        int i11 = this.f316d;
        return new g(new I("3DS_LOA_SDK_STIN_020100_00142", (KeyPair) xVar.f2616q, c1113m, i11 < 5 ? 5 : i11, m2));
    }
}
