package A8;

import F9.U;
import com.stripe.android.networking.PaymentAnalyticsEvent;
import p016b3.AbstractC0862l;
import p083g9.C1121v;
import p083g9.C1122w;
import p083g9.C1123x;
import p083g9.C1124y;
import p217s8.C1570d;

/* JADX INFO: renamed from: A8.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0018c extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public p160n7.i f228a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f229b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p083g9.B f230c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ d f231d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0018c(p083g9.B b10, d dVar, X9.d dVar2) {
        super(2, dVar2);
        this.f230c = b10;
        this.f231d = dVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new C0018c(this.f230c, this.f231d, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((C0018c) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Code duplicated, block: B:43:0x00f4  */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        p160n7.i iVar;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f229b;
        int i11 = 4;
        p083g9.B b10 = this.f230c;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            boolean z3 = b10 instanceof p083g9.z;
            PaymentAnalyticsEvent paymentAnalyticsEvent = PaymentAnalyticsEvent.Auth3ds2ChallengeCompleted;
            d dVar = this.f231d;
            if (z3) {
                dVar.f233b.a(dVar.f234c.b(paymentAnalyticsEvent, ((p083g9.z) b10).f23003a));
            } else if (b10 instanceof C1122w) {
                dVar.f233b.a(dVar.f234c.b(paymentAnalyticsEvent, ((C1122w) b10).f22994a));
            } else if (b10 instanceof C1121v) {
                dVar.f233b.a(dVar.f234c.b(PaymentAnalyticsEvent.Auth3ds2ChallengeCanceled, ((C1121v) b10).f22991a));
            } else {
                boolean z5 = b10 instanceof C1123x;
                PaymentAnalyticsEvent paymentAnalyticsEvent2 = PaymentAnalyticsEvent.Auth3ds2ChallengeErrored;
                if (z5 || (b10 instanceof C1124y)) {
                    dVar.f233b.a(C1570d.c(dVar.f234c, paymentAnalyticsEvent2, null, null, null, 30));
                } else if (b10 instanceof p083g9.A) {
                    dVar.f233b.a(dVar.f234c.b(PaymentAnalyticsEvent.Auth3ds2ChallengeTimedOut, ((p083g9.A) b10).f22866a));
                }
            }
            p160n7.n nVar = dVar.f233b;
            PaymentAnalyticsEvent paymentAnalyticsEvent3 = PaymentAnalyticsEvent.Auth3ds2ChallengePresented;
            int iC = b10.c();
            String strA = iC != 0 ? p096h9.i.a(iC) : null;
            if (strA == null) {
                strA = "";
            }
            nVar.a(dVar.f234c.b(paymentAnalyticsEvent3, strA));
            p160n7.i iVar2 = new p160n7.i(4, b10.f().f22910c, b10.f().f22911d);
            this.f228a = iVar2;
            this.f229b = 1;
            Object objA = dVar.a(b10, iVar2, 3, this);
            if (objA == aVar) {
                return aVar;
            }
            iVar = iVar2;
            obj = objA;
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            iVar = this.f228a;
            AbstractC0862l.m0(obj);
        }
        if (!((Boolean) obj).booleanValue()) {
            i11 = 2;
        } else if (b10 instanceof p083g9.z) {
            i11 = 1;
        } else if (b10 instanceof C1122w) {
            i11 = 2;
        } else if (b10 instanceof C1121v) {
            i11 = 3;
        } else if ((b10 instanceof C1123x) || (b10 instanceof C1124y)) {
            i11 = 2;
        } else if (!(b10 instanceof p083g9.A)) {
            throw new U();
        }
        return new p228t8.b(b10.f().f22908a, i11, null, false, null, null, iVar.f25431b, 60);
    }
}
