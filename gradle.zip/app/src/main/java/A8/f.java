package A8;

/* JADX INFO: loaded from: classes.dex */
public final class f extends i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p228t8.b f245a;

    public f(p228t8.b bVar) {
        this.f245a = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof f) && p097ha.k.b(this.f245a, ((f) obj).f245a);
    }

    public final int hashCode() {
        return this.f245a.hashCode();
    }

    public final String toString() {
        return "Complete(result=" + this.f245a + ")";
    }
}
