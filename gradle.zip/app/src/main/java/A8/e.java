package A8;

import P7.o1;
import android.app.Application;
import java.util.Locale;
import p217s8.C1570d;
import p217s8.P;
import p217s8.Q;
import p227t7.C1623o;

/* JADX INFO: loaded from: classes.dex */
public final class e implements E9.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f238a = 3;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final E9.d f239b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final S9.a f240c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final S9.a f241d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final S9.a f242e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final S9.a f243f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final E9.d f244g;

    public e(Q q10, S7.c cVar, E9.d dVar, S9.a aVar, S9.a aVar2, S9.a aVar3) {
        this.f239b = q10;
        this.f243f = cVar;
        this.f244g = dVar;
        this.f240c = aVar;
        this.f241d = aVar2;
        this.f242e = aVar3;
    }

    @Override // S9.a
    public final Object get() {
        switch (this.f238a) {
            case 0:
                return new d((P) ((Q) this.f239b).get(), (p160n7.n) ((S7.c) this.f243f).get(), (C1570d) this.f244g.get(), (p160n7.y) this.f240c.get(), (p081g7.f) this.f241d.get(), (X9.i) this.f242e.get());
            case 1:
                return new p108i8.g((p084ga.a) ((K8.q) this.f243f).get(), (p084ga.a) ((K8.q) this.f244g).get(), (P) ((Q) this.f239b).get(), (Y8.a) this.f240c.get(), (X9.i) this.f241d.get(), (Locale) this.f242e.get());
            case 2:
                S7.b bVar = (S7.b) ((S7.c) this.f239b).get();
                p160n7.g gVar = (p160n7.g) this.f240c.get();
                p160n7.i iVar = (p160n7.i) this.f241d.get();
                Locale locale = (Locale) this.f242e.get();
                p081g7.f fVar = (p081g7.f) this.f243f.get();
                o1 o1Var = (o1) ((E9.e) this.f244g).f3445a;
                p097ha.k.f(gVar, "apiRequestFactory");
                p097ha.k.f(iVar, "apiOptions");
                p097ha.k.f(fVar, "logger");
                if (locale == null) {
                    locale = Locale.getDefault();
                }
                Locale locale2 = locale;
                p097ha.k.e(locale2, "locale ?: Locale.getDefault()");
                return new U7.z(bVar, gVar, iVar, locale2, fVar, o1Var);
            default:
                Application application = (Application) ((E9.e) this.f239b).f3445a;
                p081g7.f fVar2 = (p081g7.f) this.f240c.get();
                p257w7.P p10 = (p257w7.P) ((p057e8.h) this.f243f).get();
                Locale locale3 = (Locale) this.f241d.get();
                p216s7.c cVar = (p216s7.c) ((E9.e) this.f244g).f3445a;
                p160n7.p pVar = (p160n7.p) this.f242e.get();
                p097ha.k.f(application, "context");
                p097ha.k.f(fVar2, "logger");
                p097ha.k.f(cVar, "configuration");
                p097ha.k.f(pVar, "stripeNetworkClient");
                if (locale3 == null) {
                    locale3 = Locale.getDefault();
                }
                Locale locale4 = locale3;
                p097ha.k.e(locale4, "locale ?: Locale.getDefault()");
                return new C1623o(pVar, p10, cVar, fVar2, locale4, application);
        }
    }

    public e(E9.e eVar, S9.a aVar, p057e8.h hVar, S9.a aVar2, E9.e eVar2, S9.a aVar3) {
        this.f239b = eVar;
        this.f240c = aVar;
        this.f243f = hVar;
        this.f241d = aVar2;
        this.f244g = eVar2;
        this.f242e = aVar3;
    }

    public e(K8.q qVar, K8.q qVar2, Q q10, S9.a aVar, S9.a aVar2, S9.a aVar3) {
        this.f243f = qVar;
        this.f244g = qVar2;
        this.f239b = q10;
        this.f240c = aVar;
        this.f241d = aVar2;
        this.f242e = aVar3;
    }

    public e(S7.c cVar, S9.a aVar, S9.a aVar2, S9.a aVar3, S9.a aVar4, E9.e eVar) {
        this.f239b = cVar;
        this.f240c = aVar;
        this.f241d = aVar2;
        this.f242e = aVar3;
        this.f243f = aVar4;
        this.f244g = eVar;
    }
}
