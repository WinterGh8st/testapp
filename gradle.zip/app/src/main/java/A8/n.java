package A8;

import E8.O0;
import E8.P0;
import E8.Q0;
import android.util.Log;
import com.flamingotools.ws.R;
import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;
import p053e3.P;
import p053e3.V;
import p053e3.a0;

/* JADX INFO: loaded from: classes.dex */
public final class n implements p073g.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f269a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f270b;

    public /* synthetic */ n(Object obj, int i10) {
        this.f269a = i10;
        this.f270b = obj;
    }

    @Override // p073g.b
    public final void a(Object obj) {
        int i10 = 0;
        Object obj2 = this.f270b;
        switch (this.f269a) {
            case 0:
                p228t8.b bVar = (p228t8.b) obj;
                p097ha.k.e(bVar, "it");
                int i11 = Stripe3ds2TransactionActivity.f21030N;
                ((Stripe3ds2TransactionActivity) obj2).u(bVar);
                break;
            case 1:
                p083g9.B b10 = (p083g9.B) obj;
                p097ha.k.e(b10, "it");
                ((p) obj2).invoke(b10);
                break;
            case 2:
                Q0 q10 = (Q0) obj;
                p097ha.k.e(q10, "it");
                a0 a0Var = ((P) obj2).f21935a;
                if (a0Var.y()) {
                    if (q10 instanceof O0) {
                        Z2.f fVar = new Z2.f(a0Var.W());
                        a0Var.f21972F0 = fVar;
                        fVar.a0(a0Var.t(R.string.tokens_acreditando));
                        a0Var.c0(new V(a0Var, i10, i10));
                    } else if (!(q10 instanceof P0)) {
                        a0Var.f21971E0 = false;
                    } else {
                        Log.e("Tokens", "Pago fallido", ((P0) q10).f3181a);
                        a0Var.o0(R.string.tokens_error_rechazado, null);
                    }
                    break;
                }
                break;
            default:
                p216s7.j jVar = (p216s7.j) obj;
                p097ha.k.e(jVar, "it");
                ((C8.b) obj2).f1858a.invoke(jVar);
                break;
        }
    }
}
