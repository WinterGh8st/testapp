package A8;

import C9.C0122u;
import androidx.activity.ComponentActivity;
import java.util.Set;
import java.util.UUID;
import p032c7.C0938n;
import p032c7.C0940p;
import p083g9.P;
import p183p8.X1;
import p183p8.c2;
import p183p8.d2;

/* JADX INFO: loaded from: classes.dex */
public final class j extends p290z8.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0940p f248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f249b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final String f250c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p084ga.a f251d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Set f252e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public p073g.d f253f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final A7.z f254g;

    public j(C0940p c0940p, boolean z3, String str, p084ga.a aVar, Set set) {
        p097ha.k.f(c0940p, "config");
        p097ha.k.f(str, "injectorKey");
        p097ha.k.f(aVar, "publishableKeyProvider");
        p097ha.k.f(set, "productUsage");
        this.f248a = c0940p;
        this.f249b = z3;
        this.f250c = str;
        this.f251d = aVar;
        this.f252e = set;
        this.f254g = new A7.z(this, 2);
    }

    @Override // p290z8.f
    public final void b() {
        p073g.d dVar = this.f253f;
        if (dVar != null) {
            dVar.b();
        }
        this.f253f = null;
    }

    @Override // p290z8.f
    public final void c(p073g.c cVar, p073g.b bVar) {
        this.f253f = ((ComponentActivity) cVar).n(new s(0), bVar);
    }

    @Override // p290z8.f
    public final Object d(C0122u c0122u, d2 d2Var, p160n7.i iVar, p290z8.d dVar) {
        t tVar = (t) this.f254g.invoke(c0122u);
        UUID uuidRandomUUID = UUID.randomUUID();
        p097ha.k.e(uuidRandomUUID, "randomUUID()");
        P p10 = new P(uuidRandomUUID);
        C0938n c0938n = this.f248a.f18228a;
        c2 c2VarD = d2Var.d();
        p097ha.k.d(c2VarD, "null cannot be cast to non-null type com.stripe.android.model.StripeIntent.NextActionData.SdkData.Use3DS2");
        Integer num = c0122u.f2188b;
        String str = (String) this.f251d.m();
        tVar.a(new r(p10, c0938n, d2Var, (X1) c2VarD, iVar, this.f249b, num, this.f250c, str, this.f252e));
        return T9.w.f11979a;
    }
}
