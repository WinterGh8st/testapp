package A8;

import p083g9.I;

/* JADX INFO: loaded from: classes.dex */
public final class g extends i {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final I f246a;

    public g(I i10) {
        this.f246a = i10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof g) && p097ha.k.b(this.f246a, ((g) obj).f246a);
    }

    public final int hashCode() {
        return this.f246a.hashCode();
    }

    public final String toString() {
        return "StartChallenge(args=" + this.f246a + ")";
    }
}
