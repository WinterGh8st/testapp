package A8;

import A7.C0013f;
import B.b0;
import B0.C0049f;
import B2.C0057h;
import C9.C0122u;
import D.C0136c;
import E.S;
import E8.C0175i;
import E8.C0192q0;
import F2.C0215f;
import G0.AbstractC0272i;
import G0.C0266c;
import G0.C0267d;
import G0.C0268e;
import G0.C0269f;
import G0.C0273j;
import G0.G;
import G0.I;
import G0.J;
import G6.F0;
import G6.y0;
import H0.C0315c;
import H0.C0316d;
import H0.C0317e;
import H0.C0318f;
import H0.C0321i;
import H0.InterfaceC0319g;
import I.AbstractC0406d0;
import N1.AbstractComponentCallbacksC0583t;
import O.C0598e;
import O.C0600f;
import O.EnumC0621p0;
import O.L;
import O.Z;
import O.u0;
import P7.f1;
import android.content.Context;
import android.graphics.Typeface;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.lifecycle.j0;
import com.flamingotools.ws.R;
import com.stripe.android.financialconnections.features.manualentry.ManualEntryState;
import com.stripe.android.financialconnections.features.manualentry.ManualEntryViewModel;
import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;
import com.stripe.android.view.CountryTextInputLayout;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.CancellationException;
import p016b3.AbstractC0862l;
import p032c7.AbstractC0933i;
import p032c7.C0941q;
import p199r0.K;
import p200r1.H;
import p200r1.U;
import p230ta.C1647l;
import p230ta.D;
import p230ta.E;
import p234u2.AbstractC1712b;
import p234u2.C1722l;
import p259wa.a0;

/* JADX INFO: loaded from: classes.dex */
public final class p extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f276a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f277b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f278c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ p(int i10, Object obj, Object obj2) {
        super(1);
        this.f276a = i10;
        this.f277b = obj;
        this.f278c = obj2;
    }

    private final Object a(Object obj) {
        K6.d dVar = (K6.d) this.f277b;
        Object obj2 = dVar.f6932c;
        C1647l c1647l = (C1647l) this.f278c;
        synchronized (obj2) {
            ((ArrayList) dVar.f6933d).remove(c1647l);
        }
        return T9.w.f11979a;
    }

    private final Object b(Object obj) {
        Throwable th = (Throwable) obj;
        u0 u0Var = (u0) this.f277b;
        Object obj2 = u0Var.f9705b;
        Throwable th2 = (Throwable) this.f278c;
        synchronized (obj2) {
            if (th2 == null) {
                th2 = null;
            } else if (th != null) {
                try {
                    if (th instanceof CancellationException) {
                        th = null;
                    }
                    if (th != null) {
                        p003a.a.m(th2, th);
                    }
                } catch (Throwable th3) {
                    throw th3;
                }
            }
            u0Var.f9707d = th2;
            a0 a0Var = u0Var.f9719q;
            EnumC0621p0 enumC0621p0 = EnumC0621p0.f9618a;
            a0Var.getClass();
            a0Var.k(null, enumC0621p0);
        }
        return T9.w.f11979a;
    }

    /* JADX WARN: Code duplicated, block: B:10:0x002d  */
    /* JADX WARN: Code duplicated, block: B:186:0x0398  */
    /* JADX WARN: Code duplicated, block: B:189:0x03a9  */
    /* JADX WARN: Code duplicated, block: B:191:0x03b8  */
    /* JADX WARN: Code duplicated, block: B:214:0x0401  */
    /* JADX WARN: Code duplicated, block: B:217:0x0412  */
    /* JADX WARN: Code duplicated, block: B:219:0x0421  */
    /* JADX WARN: Code duplicated, block: B:241:0x0467  */
    /* JADX WARN: Code duplicated, block: B:244:0x0478  */
    /* JADX WARN: Code duplicated, block: B:246:0x0487  */
    /* JADX WARN: Code duplicated, block: B:250:0x0493  */
    /* JADX WARN: Code duplicated, block: B:252:0x049e  */
    /* JADX WARN: Code duplicated, block: B:256:0x04ae  */
    /* JADX WARN: Code duplicated, block: B:258:0x04b4  */
    /* JADX WARN: Code duplicated, block: B:259:0x04b6  */
    /* JADX WARN: Code duplicated, block: B:261:0x04bc  */
    /* JADX WARN: Code duplicated, block: B:262:0x04be  */
    /* JADX WARN: Code duplicated, block: B:264:0x04c4  */
    /* JADX WARN: Code duplicated, block: B:265:0x04c6  */
    /* JADX WARN: Code duplicated, block: B:267:0x04cc  */
    /* JADX WARN: Code duplicated, block: B:272:0x04d5  */
    /* JADX WARN: Code duplicated, block: B:275:0x04e6  */
    /* JADX WARN: Code duplicated, block: B:277:0x04f5  */
    /* JADX WARN: Code duplicated, block: B:335:0x0642  */
    /* JADX WARN: Code duplicated, block: B:336:0x0644  */
    /* JADX WARN: Code duplicated, block: B:433:0x091e  */
    /* JADX WARN: Code duplicated, block: B:464:0x03bb A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:473:0x0424 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:483:0x048a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:484:0x04d0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:493:0x04f8 A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r2v57, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r2v65, types: [ga.c, ha.i] */
    /* JADX WARN: Type inference failed for: r3v13, types: [java.lang.Object, java.util.List] */
    /* JADX WARN: Type inference failed for: r4v32, types: [ga.f, ha.i] */
    @Override // p084ga.c
    public final Object invoke(Object obj) {
        ArrayList arrayList;
        p038d0.d dVar;
        T9.h hVar;
        Object h10;
        Object obj2;
        int size;
        int i10;
        G0.t tVar;
        int size2;
        int i11;
        G0.t tVar2;
        G0.t tVar3;
        int size3;
        int i12;
        Object obj3;
        G0.t tVar4;
        Object obj4;
        ArrayList arrayList2;
        int size4;
        int i13;
        Object obj5;
        int size5;
        int i14;
        Object obj6;
        Typeface typefaceB;
        String strConcat;
        LayoutInflater layoutInflaterFrom;
        int i15 = 20;
        int i16 = 22;
        int i17 = 2;
        int i18 = 0;
        zC = false;
        zC = false;
        zC = false;
        zC = false;
        boolean zC = false;
        z = false;
        z = false;
        boolean z3 = false;
        int i19 = 0;
        Object obj7 = null;
        I i20 = null;
        numValueOf = null;
        Integer numValueOf = null;
        boolean z5 = true;
        switch (this.f276a) {
            case 0:
                p083g9.B b10 = (p083g9.B) obj;
                p097ha.k.f(b10, "challengeResult");
                Stripe3ds2TransactionActivity stripe3ds2TransactionActivity = (Stripe3ds2TransactionActivity) this.f277b;
                return E.t(j0.h(stripe3ds2TransactionActivity), null, new o(stripe3ds2TransactionActivity, b10, (B0.l) this.f278c, null), 3);
            case 1:
                long jA = ((p038d0.c) obj).f21401a;
                Z z10 = (Z) this.f277b;
                B0.B b11 = (B0.B) z10.getValue();
                if (b11 != null && (arrayList = b11.f683f) != null) {
                    ArrayList arrayListA0 = U9.n.A0(arrayList);
                    int size6 = arrayListA0.size();
                    while (i18 < size6) {
                        Object obj8 = arrayListA0.get(i18);
                        i18++;
                        p038d0.d dVar2 = (p038d0.d) obj8;
                        float fD = p038d0.c.d(jA);
                        float f10 = dVar2.f21403a;
                        float f11 = dVar2.f21404b;
                        if (fD > p038d0.c.d(p029c4.a.c0(f10, f11)) && p038d0.c.d(jA) < p038d0.c.d(p029c4.a.c0(dVar2.f21405c, f11))) {
                            obj7 = obj8;
                            dVar = (p038d0.d) obj7;
                            if (dVar != null) {
                                float f12 = dVar.f21405c;
                                float f13 = dVar.f21404b;
                                jA = p038d0.c.a(p029c4.a.c0(f12, f13), p038d0.c.d(p029c4.a.c0(f12, f13)) + 0.1f, 2);
                            }
                        }
                    }
                    dVar = (p038d0.d) obj7;
                    if (dVar != null) {
                        float f14 = dVar.f21405c;
                        float f15 = dVar.f21404b;
                        jA = p038d0.c.a(p029c4.a.c0(f14, f15), p038d0.c.d(p029c4.a.c0(f14, f15)) + 0.1f, 2);
                    }
                }
                B0.B b12 = (B0.B) z10.getValue();
                if (b12 != null) {
                    ((A9.g) this.f278c).invoke(Integer.valueOf(b12.l(jA) - 1));
                }
                return T9.w.f11979a;
            case 2:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                b0 b0Var = (b0) this.f277b;
                View view = (View) this.f278c;
                p097ha.k.f(view, "view");
                if (b0Var.f584s == 0) {
                    WeakHashMap weakHashMap = U.f27683a;
                    B.B b13 = b0Var.f585t;
                    H.u(view, b13);
                    if (view.isAttachedToWindow()) {
                        view.requestApplyInsets();
                    }
                    view.addOnAttachStateChangeListener(b13);
                    U.s(view, b13);
                }
                b0Var.f584s++;
                return new B.a0(i18, b0Var, view);
            case 3:
                C0122u c0122u = (C0122u) obj;
                p097ha.k.f(c0122u, "host");
                p073g.d dVar3 = ((p290z8.a) ((D9.a) this.f277b).get()).f33369g;
                return dVar3 != null ? new p032c7.r(dVar3) : new C0941q(c0122u, (p228t8.a) this.f278c);
            case 4:
                K k = (K) obj;
                p097ha.k.f(k, "$this$invoke");
                ArrayList arrayList3 = (ArrayList) this.f277b;
                int size7 = arrayList3.size();
                while (true) {
                    C.x xVar = (C.x) this.f278c;
                    if (i19 >= size7) {
                        if (xVar != null) {
                            xVar.d(k);
                        }
                        return T9.w.f11979a;
                    }
                    C.x xVar2 = (C.x) arrayList3.get(i19);
                    if (xVar2 != xVar) {
                        xVar2.d(k);
                    }
                    i19++;
                }
                break;
            case 5:
                H0.y yVar = (H0.y) obj;
                p097ha.k.f(yVar, "it");
                Z z11 = (Z) this.f278c;
                z11.setValue(yVar);
                ((B7.n) this.f277b).invoke(((H0.y) z11.getValue()).f4466a.f714a);
                return T9.w.f11979a;
            case 6:
                ViewGroup viewGroup = (ViewGroup) obj;
                p097ha.k.f(viewGroup, "it");
                View viewInflate = LayoutInflater.from((Context) this.f277b).inflate(((CountryTextInputLayout) this.f278c).f21250N0, viewGroup, false);
                p097ha.k.d(viewInflate, "null cannot be cast to non-null type android.widget.TextView");
                return (TextView) viewInflate;
            case 7:
                p130k7.c cVar = (p130k7.c) obj;
                p130k7.f fVar = cVar != null ? cVar.f24513a : null;
                CountryTextInputLayout countryTextInputLayout = (CountryTextInputLayout) this.f277b;
                countryTextInputLayout.setSelectedCountryCode$payments_core_release(fVar);
                if (cVar != null) {
                    countryTextInputLayout.setError(null);
                    countryTextInputLayout.setErrorEnabled(false);
                } else {
                    countryTextInputLayout.setError((String) this.f278c);
                    countryTextInputLayout.setErrorEnabled(true);
                }
                return T9.w.f11979a;
            case 8:
                B2.l lVarC = ((D.A) this.f277b).c(((Number) obj).intValue());
                ?? r7 = lVarC.f943c;
                ArrayList arrayList4 = new ArrayList(r7.size());
                int size8 = r7.size();
                int i21 = lVarC.f942b;
                int i22 = 0;
                for (int i23 = 0; i23 < size8; i23++) {
                    int i24 = (int) ((C0136c) r7.get(i23)).f2304a;
                    arrayList4.add(new T9.h(Integer.valueOf(i21), new N0.a(((C2.g) this.f278c).a(i22, i24))));
                    i21++;
                    i22 += i24;
                }
                return arrayList4;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                f1 f1Var = (f1) obj;
                p097ha.k.f(f1Var, "selected");
                if (!(((AbstractC1712b) this.f277b) instanceof C1722l)) {
                    ((B7.n) this.f278c).invoke(f1Var);
                }
                return T9.w.f11979a;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                S s5 = (S) this.f277b;
                LinkedHashSet linkedHashSet = s5.f2777c;
                Object obj9 = this.f278c;
                linkedHashSet.remove(obj9);
                return new B.a0(1, s5, obj9);
            case 11:
                ((C0013f) this.f277b).invoke(this.f278c.get(((Number) obj).intValue()));
                return T9.w.f11979a;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                H0.y yVar2 = (H0.y) obj;
                p097ha.k.f(yVar2, "text");
                C0049f c0049f = yVar2.f4466a;
                String str = c0049f.f714a;
                StringBuilder sb2 = new StringBuilder();
                int length = str.length();
                for (int i25 = 0; i25 < length; i25++) {
                    char cCharAt = str.charAt(i25);
                    if (Character.isDigit(cCharAt)) {
                        sb2.append(cCharAt);
                    }
                }
                String string = sb2.toString();
                p097ha.k.e(string, "filterTo(StringBuilder(), predicate).toString()");
                long j10 = yVar2.f4467b;
                String str2 = c0049f.f714a;
                long jR = AbstractC0862l.r(str2, j10);
                B0.C c10 = yVar2.f4468c;
                H0.y yVar3 = new H0.y(new C0049f(6, string, null), jR, c10 != null ? new B0.C(AbstractC0862l.r(str2, c10.f686a)) : null);
                Z z12 = (Z) this.f278c;
                z12.setValue(yVar3);
                ((p097ha.i) this.f277b).invoke(((H0.y) z12.getValue()).f4466a.f714a);
                return T9.w.f11979a;
            case 13:
                ManualEntryState manualEntryState = (ManualEntryState) obj;
                p097ha.k.f(manualEntryState, "it");
                String strB = manualEntryState.b();
                if (strB == null) {
                    strB = "";
                }
                String str3 = (String) this.f277b;
                p097ha.k.f(str3, "accountConfirmInput");
                if ((strB.length() == 0 ? Integer.valueOf(R.string.stripe_validation_account_required) : strB.length() > 17 ? Integer.valueOf(R.string.stripe_validation_account_too_long) : null) == null && !strB.equals(str3)) {
                    numValueOf = Integer.valueOf(R.string.stripe_validation_account_confirm_mismatch);
                }
                A7.z zVar = new A7.z(numValueOf, i15);
                ManualEntryViewModel.Companion companion = ManualEntryViewModel.Companion;
                ((ManualEntryViewModel) this.f278c).d(zVar);
                return T9.w.f11979a;
            case 14:
                ((Boolean) obj).getClass();
                boolean z13 = !((Boolean) ((Z) this.f278c).getValue()).booleanValue();
                F8.U u5 = (F8.U) this.f277b;
                Boolean boolValueOf = Boolean.valueOf(z13);
                a0 a0Var = u5.k;
                a0Var.getClass();
                a0Var.k(null, boolValueOf);
                return T9.w.f11979a;
            case 15:
                p084ga.c cVar2 = (p084ga.c) obj;
                p097ha.k.f(cVar2, "onAsyncCompletion");
                C0273j c0273j = (C0273j) this.f277b;
                G0.o oVar = c0273j.f4116d;
                G g10 = (G) this.f278c;
                C0215f c0215f = c0273j.f4113a;
                A7.z zVar2 = c0273j.f4118f;
                oVar.getClass();
                p097ha.k.f(c0215f, "platformFontLoader");
                p097ha.k.f(zVar2, "createDefaultTypeface");
                AbstractC0272i abstractC0272i = g10.f4088a;
                if (abstractC0272i instanceof G0.l) {
                    ArrayList arrayList5 = ((G0.l) abstractC0272i).f4122c;
                    G0.t tVar5 = g10.f4089b;
                    int i26 = g10.f4090c;
                    p097ha.k.f(arrayList5, "fontList");
                    p097ha.k.f(tVar5, "fontWeight");
                    ArrayList arrayList6 = new ArrayList(arrayList5.size());
                    int size9 = arrayList5.size();
                    int i27 = 0;
                    while (i27 < size9) {
                        Object obj10 = arrayList5.get(i27);
                        boolean z14 = z5;
                        if (((G0.A) obj10).f4083b.equals(tVar5) && i26 == 0) {
                            arrayList6.add(obj10);
                        }
                        i27++;
                        z5 = z14;
                    }
                    boolean z15 = z5;
                    if (arrayList6.isEmpty()) {
                        ArrayList arrayList7 = new ArrayList(arrayList5.size());
                        int size10 = arrayList5.size();
                        for (int i28 = 0; i28 < size10; i28++) {
                            Object obj11 = arrayList5.get(i28);
                            ((G0.A) obj11).getClass();
                            if (i26 == 0) {
                                arrayList7.add(obj11);
                            }
                        }
                        if (!arrayList7.isEmpty()) {
                            arrayList5 = arrayList7;
                        }
                        if (tVar5.compareTo(G0.t.f4131b) < 0) {
                            int size11 = arrayList5.size();
                            G0.t tVar6 = null;
                            G0.t tVar7 = null;
                            for (int i29 = 0; i29 < size11; i29++) {
                                G0.t tVar8 = ((G0.A) arrayList5.get(i29)).f4083b;
                                if (tVar8.compareTo(tVar5) < 0) {
                                    if (tVar6 == null || tVar8.compareTo(tVar6) > 0) {
                                        tVar6 = tVar8;
                                    }
                                } else if (tVar8.compareTo(tVar5) <= 0) {
                                    tVar6 = tVar8;
                                    tVar7 = tVar6;
                                    if (tVar6 == null) {
                                        tVar6 = tVar7;
                                    }
                                    arrayList2 = new ArrayList(arrayList5.size());
                                    size5 = arrayList5.size();
                                    for (i14 = 0; i14 < size5; i14++) {
                                        obj6 = arrayList5.get(i14);
                                        if (((G0.A) obj6).f4083b.equals(tVar6)) {
                                            arrayList2.add(obj6);
                                        }
                                    }
                                } else if (tVar7 == null || tVar8.compareTo(tVar7) < 0) {
                                    tVar7 = tVar8;
                                }
                            }
                            if (tVar6 == null) {
                                tVar6 = tVar7;
                            }
                            arrayList2 = new ArrayList(arrayList5.size());
                            size5 = arrayList5.size();
                            while (i14 < size5) {
                                obj6 = arrayList5.get(i14);
                                if (((G0.A) obj6).f4083b.equals(tVar6)) {
                                    arrayList2.add(obj6);
                                }
                            }
                        } else {
                            G0.t tVar9 = G0.t.f4132c;
                            if (tVar5.compareTo(tVar9) > 0) {
                                int size12 = arrayList5.size();
                                G0.t tVar10 = null;
                                G0.t tVar11 = null;
                                for (int i30 = 0; i30 < size12; i30++) {
                                    G0.t tVar12 = ((G0.A) arrayList5.get(i30)).f4083b;
                                    if (tVar12.compareTo(tVar5) < 0) {
                                        if (tVar10 == null || tVar12.compareTo(tVar10) > 0) {
                                            tVar10 = tVar12;
                                        }
                                    } else if (tVar12.compareTo(tVar5) <= 0) {
                                        tVar10 = tVar12;
                                        tVar11 = tVar10;
                                        if (tVar11 != null) {
                                            tVar10 = tVar11;
                                        }
                                        arrayList2 = new ArrayList(arrayList5.size());
                                        size4 = arrayList5.size();
                                        for (i13 = 0; i13 < size4; i13++) {
                                            obj5 = arrayList5.get(i13);
                                            if (((G0.A) obj5).f4083b.equals(tVar10)) {
                                                arrayList2.add(obj5);
                                            }
                                        }
                                    } else if (tVar11 == null || tVar12.compareTo(tVar11) < 0) {
                                        tVar11 = tVar12;
                                    }
                                }
                                if (tVar11 != null) {
                                    tVar10 = tVar11;
                                }
                                arrayList2 = new ArrayList(arrayList5.size());
                                size4 = arrayList5.size();
                                while (i13 < size4) {
                                    obj5 = arrayList5.get(i13);
                                    if (((G0.A) obj5).f4083b.equals(tVar10)) {
                                        arrayList2.add(obj5);
                                    }
                                }
                            } else {
                                int size13 = arrayList5.size();
                                G0.t tVar13 = null;
                                G0.t tVar14 = null;
                                for (int i31 = 0; i31 < size13; i31++) {
                                    G0.t tVar15 = ((G0.A) arrayList5.get(i31)).f4083b;
                                    if (tVar15.compareTo(tVar9) <= 0) {
                                        if (tVar15.compareTo(tVar5) < 0) {
                                            if (tVar13 == null || tVar15.compareTo(tVar13) > 0) {
                                                tVar13 = tVar15;
                                            }
                                        } else if (tVar15.compareTo(tVar5) <= 0) {
                                            tVar13 = tVar15;
                                            tVar14 = tVar13;
                                            if (tVar14 != null) {
                                                tVar13 = tVar14;
                                            }
                                            arrayList6 = new ArrayList(arrayList5.size());
                                            size = arrayList5.size();
                                            for (i10 = 0; i10 < size; i10++) {
                                                obj4 = arrayList5.get(i10);
                                                if (((G0.A) obj4).f4083b.equals(tVar13)) {
                                                    arrayList6.add(obj4);
                                                }
                                            }
                                            if (arrayList6.isEmpty()) {
                                                tVar = G0.t.f4132c;
                                                size2 = arrayList5.size();
                                                tVar2 = null;
                                                tVar3 = null;
                                                for (i11 = 0; i11 < size2; i11++) {
                                                    tVar4 = ((G0.A) arrayList5.get(i11)).f4083b;
                                                    if (tVar != null || tVar4.compareTo(tVar) >= 0) {
                                                        if (tVar4.compareTo(tVar5) < 0) {
                                                            if (tVar2 != null || tVar4.compareTo(tVar2) > 0) {
                                                                tVar2 = tVar4;
                                                            }
                                                        } else if (tVar4.compareTo(tVar5) <= 0) {
                                                            tVar2 = tVar4;
                                                            tVar3 = tVar2;
                                                            if (tVar3 != null) {
                                                                tVar2 = tVar3;
                                                            }
                                                            arrayList6 = new ArrayList(arrayList5.size());
                                                            size3 = arrayList5.size();
                                                            for (i12 = 0; i12 < size3; i12++) {
                                                                obj3 = arrayList5.get(i12);
                                                                if (((G0.A) obj3).f4083b.equals(tVar2)) {
                                                                    arrayList6.add(obj3);
                                                                }
                                                            }
                                                        } else if (tVar3 != null || tVar4.compareTo(tVar3) < 0) {
                                                            tVar3 = tVar4;
                                                        }
                                                    }
                                                }
                                                if (tVar3 != null) {
                                                    tVar2 = tVar3;
                                                }
                                                arrayList6 = new ArrayList(arrayList5.size());
                                                size3 = arrayList5.size();
                                                while (i12 < size3) {
                                                    obj3 = arrayList5.get(i12);
                                                    if (((G0.A) obj3).f4083b.equals(tVar2)) {
                                                        arrayList6.add(obj3);
                                                    }
                                                }
                                            }
                                        } else if (tVar14 == null || tVar15.compareTo(tVar14) < 0) {
                                            tVar14 = tVar15;
                                        }
                                    }
                                }
                                if (tVar14 != null) {
                                    tVar13 = tVar14;
                                }
                                arrayList6 = new ArrayList(arrayList5.size());
                                size = arrayList5.size();
                                while (i10 < size) {
                                    obj4 = arrayList5.get(i10);
                                    if (((G0.A) obj4).f4083b.equals(tVar13)) {
                                        arrayList6.add(obj4);
                                    }
                                }
                                if (arrayList6.isEmpty()) {
                                    tVar = G0.t.f4132c;
                                    size2 = arrayList5.size();
                                    tVar2 = null;
                                    tVar3 = null;
                                    while (i11 < size2) {
                                        tVar4 = ((G0.A) arrayList5.get(i11)).f4083b;
                                        if (tVar != null) {
                                            if (tVar4.compareTo(tVar5) < 0) {
                                                if (tVar2 != null) {
                                                    tVar2 = tVar4;
                                                } else {
                                                    tVar2 = tVar4;
                                                }
                                            } else if (tVar4.compareTo(tVar5) <= 0) {
                                                tVar2 = tVar4;
                                                tVar3 = tVar2;
                                                if (tVar3 != null) {
                                                    tVar2 = tVar3;
                                                }
                                                arrayList6 = new ArrayList(arrayList5.size());
                                                size3 = arrayList5.size();
                                                while (i12 < size3) {
                                                    obj3 = arrayList5.get(i12);
                                                    if (((G0.A) obj3).f4083b.equals(tVar2)) {
                                                        arrayList6.add(obj3);
                                                    }
                                                }
                                            } else if (tVar3 != null) {
                                                tVar3 = tVar4;
                                            } else {
                                                tVar3 = tVar4;
                                            }
                                        } else if (tVar4.compareTo(tVar5) < 0) {
                                            if (tVar2 != null) {
                                                tVar2 = tVar4;
                                            } else {
                                                tVar2 = tVar4;
                                            }
                                        } else if (tVar4.compareTo(tVar5) <= 0) {
                                            tVar2 = tVar4;
                                            tVar3 = tVar2;
                                            if (tVar3 != null) {
                                                tVar2 = tVar3;
                                            }
                                            arrayList6 = new ArrayList(arrayList5.size());
                                            size3 = arrayList5.size();
                                            while (i12 < size3) {
                                                obj3 = arrayList5.get(i12);
                                                if (((G0.A) obj3).f4083b.equals(tVar2)) {
                                                    arrayList6.add(obj3);
                                                }
                                            }
                                        } else if (tVar3 != null) {
                                            tVar3 = tVar4;
                                        } else {
                                            tVar3 = tVar4;
                                        }
                                    }
                                    if (tVar3 != null) {
                                        tVar2 = tVar3;
                                    }
                                    arrayList6 = new ArrayList(arrayList5.size());
                                    size3 = arrayList5.size();
                                    while (i12 < size3) {
                                        obj3 = arrayList5.get(i12);
                                        if (((G0.A) obj3).f4083b.equals(tVar2)) {
                                            arrayList6.add(obj3);
                                        }
                                    }
                                }
                            }
                        }
                        arrayList6 = arrayList2;
                    }
                    C0057h c0057h = oVar.f4126a;
                    if (arrayList6.size() > 0) {
                        G0.A a3 = (G0.A) arrayList6.get(0);
                        a3.getClass();
                        synchronized (((n6.e) c0057h.f923d)) {
                            try {
                                C0268e c0268e = new C0268e(a3);
                                C0267d c0267d = (C0267d) ((F0.b) c0057h.f921b).a(c0268e);
                                if (c0267d == null) {
                                    c0267d = (C0267d) ((F0.c) c0057h.f922c).a(c0268e);
                                }
                                if (c0267d != null) {
                                    obj2 = c0267d.f4110a;
                                } else {
                                    try {
                                        Typeface typefaceJ = c0215f.j(a3);
                                        c0057h.getClass();
                                        p097ha.k.f(c0215f, "platformFontLoader");
                                        C0268e c0268e2 = new C0268e(a3);
                                        synchronized (((n6.e) c0057h.f923d)) {
                                            try {
                                                if (typefaceJ == null) {
                                                }
                                            } catch (Throwable th) {
                                                throw th;
                                            }
                                            break;
                                        }
                                        obj2 = typefaceJ;
                                    } catch (Exception e10) {
                                        throw new IllegalStateException("Unable to load font " + a3, e10);
                                    }
                                }
                            } catch (Throwable th2) {
                                throw th2;
                            }
                        }
                        if (obj2 == null) {
                            throw new IllegalStateException("Unable to load font " + a3);
                        }
                        hVar = new T9.h(null, com.bumptech.glide.d.K0(g10.f4091d, obj2, a3, g10.f4089b, g10.f4090c));
                    } else {
                        hVar = new T9.h(null, zVar2.invoke(g10));
                    }
                    List list = (List) hVar.f11957a;
                    Object obj12 = hVar.f11958b;
                    if (list == null) {
                        h10 = new I(obj12, z15);
                    } else {
                        C0266c c0266c = new C0266c(list, obj12, g10, oVar.f4126a, cVar2, c0215f);
                        p282ya.e eVar = oVar.f4127b;
                        D d10 = D.f29457a;
                        E.t(eVar, null, new G0.m(c0266c, null), z15 ? 1 : 0);
                        h10 = new G0.H(c0266c);
                    }
                } else {
                    h10 = null;
                }
                if (h10 != null) {
                    return h10;
                }
                C0273j c0273j2 = (C0273j) this.f277b;
                Q3.i iVar = c0273j2.f4117e;
                G g11 = (G) this.f278c;
                C0215f c0215f2 = c0273j2.f4113a;
                A7.z zVar3 = c0273j2.f4118f;
                iVar.getClass();
                p097ha.k.f(c0215f2, "platformFontLoader");
                p097ha.k.f(zVar3, "createDefaultTypeface");
                AbstractC0272i abstractC0272i2 = g11.f4088a;
                boolean z16 = abstractC0272i2 == null ? true : abstractC0272i2 instanceof C0269f;
                G0.z zVar4 = (G0.z) iVar.f10735b;
                int i32 = g11.f4090c;
                G0.t tVar16 = g11.f4089b;
                if (z16) {
                    typefaceB = zVar4.f(tVar16, i32);
                } else {
                    if (!(abstractC0272i2 instanceof G0.u)) {
                        if (abstractC0272i2 instanceof G0.v) {
                            A6.d dVar4 = ((G0.v) abstractC0272i2).f4142b;
                            p097ha.k.f(tVar16, "fontWeight");
                            typefaceB = (Typeface) dVar4.f77b;
                        }
                        if (i20 != null) {
                            return i20;
                        }
                        throw new IllegalStateException("Could not load font");
                    }
                    typefaceB = zVar4.b((G0.u) abstractC0272i2, tVar16, i32);
                }
                i20 = new I(typefaceB, true);
                if (i20 != null) {
                    return i20;
                }
                throw new IllegalStateException("Could not load font");
            case 16:
                J j11 = (J) obj;
                p097ha.k.f(j11, "finalResult");
                p169o6.h hVar2 = (p169o6.h) this.f277b;
                n6.e eVar2 = (n6.e) hVar2.f26363b;
                G g12 = (G) this.f278c;
                synchronized (eVar2) {
                    try {
                        if (j11.f()) {
                            ((F0.b) hVar2.f26364c).b(g12, j11);
                        } else {
                            ((F0.b) hVar2.f26364c).c(g12);
                        }
                    } catch (Throwable th3) {
                        throw th3;
                    }
                }
                return T9.w.f11979a;
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                InterfaceC0319g interfaceC0319g = (InterfaceC0319g) obj;
                p097ha.k.f(interfaceC0319g, "it");
                StringBuilder sbF = p015b2.a.f(((InterfaceC0319g) this.f277b) == interfaceC0319g ? " > " : "   ");
                ((p169o6.h) this.f278c).getClass();
                if (interfaceC0319g instanceof C0315c) {
                    StringBuilder sb3 = new StringBuilder("CommitTextCommand(text.length=");
                    C0315c c0315c = (C0315c) interfaceC0319g;
                    sb3.append(c0315c.f4421a.f714a.length());
                    sb3.append(", newCursorPosition=");
                    strConcat = AbstractC0933i.h(sb3, c0315c.f4422b, ')');
                } else if (interfaceC0319g instanceof H0.u) {
                    StringBuilder sb4 = new StringBuilder("SetComposingTextCommand(text.length=");
                    H0.u uVar = (H0.u) interfaceC0319g;
                    sb4.append(uVar.f4455a.f714a.length());
                    sb4.append(", newCursorPosition=");
                    strConcat = AbstractC0933i.h(sb4, uVar.f4456b, ')');
                } else if ((interfaceC0319g instanceof H0.t) || (interfaceC0319g instanceof C0317e) || (interfaceC0319g instanceof C0318f) || (interfaceC0319g instanceof H0.v)) {
                    strConcat = interfaceC0319g.toString();
                } else if (interfaceC0319g instanceof C0321i) {
                    strConcat = "FinishComposingTextCommand()";
                } else if (interfaceC0319g instanceof C0316d) {
                    strConcat = "DeleteAllCommand()";
                } else {
                    String strC = p097ha.v.a(interfaceC0319g.getClass()).c();
                    if (strC == null) {
                        strC = "{anonymous EditCommand}";
                    }
                    strConcat = "Unknown EditCommand: ".concat(strC);
                }
                sbF.append(strConcat);
                return sbF.toString();
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                H0.y yVar4 = (H0.y) obj;
                p097ha.k.f(yVar4, "it");
                if (!p097ha.k.b((H0.y) this.f277b, yVar4)) {
                    ((p084ga.c) this.f278c).invoke(yVar4);
                }
                return T9.w.f11979a;
            case 19:
                long j12 = ((p038d0.c) obj).f21401a;
                B0.B b14 = (B0.B) ((Z) this.f277b).getValue();
                if (b14 != null) {
                    ((p084ga.c) this.f278c).invoke(Integer.valueOf(b14.l(j12)));
                }
                return T9.w.f11979a;
            case 20:
                KeyEvent keyEvent = ((p143m0.b) obj).f24822a;
                if (((I.y0) this.f277b).a() == I.I.f5360b && keyEvent.getKeyCode() == 4 && p143m0.c.S(keyEvent) == 1) {
                    ((K.y) this.f278c).e(null);
                    z3 = true;
                }
                return Boolean.valueOf(z3);
            case 21:
                KeyEvent keyEvent2 = ((p143m0.b) obj).f24822a;
                InputDevice device = keyEvent2.getDevice();
                if (device != null && device.supportsSource(513) && !device.isVirtual() && p143m0.c.S(keyEvent2) == 2) {
                    boolean zN = AbstractC0406d0.n(19, keyEvent2);
                    p025c0.e eVar3 = (p025c0.e) this.f277b;
                    if (zN) {
                        zC = ((p025c0.f) eVar3).c(5);
                    } else if (AbstractC0406d0.n(20, keyEvent2)) {
                        zC = ((p025c0.f) eVar3).c(6);
                    } else if (AbstractC0406d0.n(21, keyEvent2)) {
                        zC = ((p025c0.f) eVar3).c(3);
                    } else if (AbstractC0406d0.n(22, keyEvent2)) {
                        zC = ((p025c0.f) eVar3).c(4);
                    } else if (AbstractC0406d0.n(23, keyEvent2)) {
                        H0.E e11 = ((I.y0) this.f278c).f5712d;
                        if (e11 != null && e11.a()) {
                            e11.f4412b.k(H0.A.f4394c);
                        }
                        zC = true;
                    }
                }
                return Boolean.valueOf(zC);
            case 22:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                return new B.a0(i17, (Z) this.f277b, (A.l) this.f278c);
            case 23:
                C0192q0 c0192q0 = (C0192q0) obj;
                return new C0175i((Context) this.f277b, c0192q0 != null ? c0192q0.f3384a : null, (X9.i) this.f278c);
            case 24:
                p284z0.j jVar = (p284z0.j) obj;
                p097ha.k.f(jVar, "$this$semantics");
                p284z0.r.c(jVar, (String) this.f277b);
                jVar.g(p284z0.i.f33190b, new p284z0.a(null, new B((B7.l) this.f278c, i16)));
                return T9.w.f11979a;
            case 25:
                C0600f c0600f = (C0600f) this.f277b;
                Object obj13 = c0600f.f9561b;
                p097ha.u uVar2 = (p097ha.u) this.f278c;
                synchronized (obj13) {
                    ArrayList arrayList8 = c0600f.f9563d;
                    Object obj14 = uVar2.f23278a;
                    if (obj14 == null) {
                        p097ha.k.l("awaiter");
                        throw null;
                    }
                    arrayList8.remove((C0598e) obj14);
                }
                return T9.w.f11979a;
            case 26:
                return a(obj);
            case 27:
                return b(obj);
            case 28:
                p097ha.k.f(obj, "value");
                ((O.A) this.f277b).x(obj);
                P.c cVar3 = (P.c) this.f278c;
                if (cVar3 != null) {
                    cVar3.add(obj);
                }
                return T9.w.f11979a;
            default:
                Context context = (Context) obj;
                p097ha.k.f(context, "context");
                AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t = (AbstractComponentCallbacksC0583t) this.f277b;
                if (abstractComponentCallbacksC0583t == null) {
                    layoutInflaterFrom = LayoutInflater.from(context);
                } else {
                    layoutInflaterFrom = abstractComponentCallbacksC0583t.f9235U;
                    if (layoutInflaterFrom == null) {
                        layoutInflaterFrom = abstractComponentCallbacksC0583t.K(null);
                        abstractComponentCallbacksC0583t.f9235U = layoutInflaterFrom;
                    }
                    if (layoutInflaterFrom == null) {
                        layoutInflaterFrom = LayoutInflater.from(context);
                    }
                }
                p097ha.k.e(layoutInflaterFrom, "inflater");
                p190q2.a aVar = (p190q2.a) ((p097ha.i) this.f278c).I(layoutInflaterFrom, new FrameLayout(context), Boolean.FALSE);
                View viewB = aVar.b();
                p097ha.k.e(viewB, "invoke$lambda$0");
                viewB.setTag(R.id.binding_reference, aVar);
                return viewB;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public p(AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t, p084ga.f fVar) {
        super(1);
        this.f276a = 29;
        this.f277b = abstractComponentCallbacksC0583t;
        this.f278c = (p097ha.i) fVar;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public p(p084ga.c cVar, Z z3) {
        super(1);
        this.f276a = 12;
        this.f277b = (p097ha.i) cVar;
        this.f278c = z3;
    }
}
