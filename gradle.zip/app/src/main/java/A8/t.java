package A8;

import C9.C0122u;
import C9.InterfaceC0120t;
import android.os.Bundle;
import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;
import java.util.List;
import p032c7.AbstractC0932h;
import p032c7.V;

/* JADX INFO: loaded from: classes.dex */
public final class t implements InterfaceC0120t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f291a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f292b;

    public t(C0122u c0122u) {
        p097ha.k.f(c0122u, "host");
        this.f292b = c0122u;
    }

    @Override // C9.InterfaceC0120t
    public final void a(Object obj) {
        Object obj2 = this.f292b;
        switch (this.f291a) {
            case 0:
                r rVar = (r) obj;
                Bundle bundleE = G6.C.E(new T9.h("extra_args", rVar));
                List list = V.f18184l;
                ((C0122u) obj2).a(Stripe3ds2TransactionActivity.class, bundleE, AbstractC0932h.c(rVar.f282c));
                break;
            default:
                ((p073g.d) obj2).a((r) obj, null);
                break;
        }
    }

    public t(p073g.d dVar) {
        p097ha.k.f(dVar, "launcher");
        this.f292b = dVar;
    }
}
