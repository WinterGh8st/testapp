package A8;

import L.AbstractC0492c;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.Iterator;
import java.util.Set;
import p032c7.AbstractC0933i;
import p032c7.C0938n;
import p083g9.P;
import p183p8.X1;
import p183p8.d2;

/* JADX INFO: loaded from: classes.dex */
public final class r implements Parcelable {
    public static final Parcelable.Creator<r> CREATOR = new q(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f280a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0938n f281b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d2 f282c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final X1 f283d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p160n7.i f284e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f285f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Integer f286q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final String f287r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final String f288s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Set f289t;

    public r(P p10, C0938n c0938n, d2 d2Var, X1 x1, p160n7.i iVar, boolean z3, Integer num, String str, String str2, Set set) {
        p097ha.k.f(p10, "sdkTransactionId");
        p097ha.k.f(c0938n, "config");
        p097ha.k.f(d2Var, "stripeIntent");
        p097ha.k.f(x1, "nextActionData");
        p097ha.k.f(iVar, "requestOptions");
        p097ha.k.f(str, "injectorKey");
        p097ha.k.f(str2, "publishableKey");
        p097ha.k.f(set, "productUsage");
        this.f280a = p10;
        this.f281b = c0938n;
        this.f282c = d2Var;
        this.f283d = x1;
        this.f284e = iVar;
        this.f285f = z3;
        this.f286q = num;
        this.f287r = str;
        this.f288s = str2;
        this.f289t = set;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof r)) {
            return false;
        }
        r rVar = (r) obj;
        return p097ha.k.b(this.f280a, rVar.f280a) && p097ha.k.b(this.f281b, rVar.f281b) && p097ha.k.b(this.f282c, rVar.f282c) && p097ha.k.b(this.f283d, rVar.f283d) && p097ha.k.b(this.f284e, rVar.f284e) && this.f285f == rVar.f285f && p097ha.k.b(this.f286q, rVar.f286q) && p097ha.k.b(this.f287r, rVar.f287r) && p097ha.k.b(this.f288s, rVar.f288s) && p097ha.k.b(this.f289t, rVar.f289t);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v12, types: [int] */
    /* JADX WARN: Type inference failed for: r2v16 */
    /* JADX WARN: Type inference failed for: r2v17 */
    /* JADX WARN: Type inference failed for: r2v9, types: [int] */
    public final int hashCode() {
        int iHashCode = (this.f284e.hashCode() + ((this.f283d.hashCode() + ((this.f282c.hashCode() + ((this.f281b.hashCode() + (this.f280a.f22916a.hashCode() * 31)) * 31)) * 31)) * 31)) * 31;
        boolean z3 = this.f285f;
        ?? r7 = z3;
        if (z3) {
            r7 = 1;
        }
        int i10 = (iHashCode + r7) * 31;
        Integer num = this.f286q;
        return this.f289t.hashCode() + AbstractC0492c.f(AbstractC0492c.f((i10 + (num == null ? 0 : num.hashCode())) * 31, 31, this.f287r), 31, this.f288s);
    }

    public final String toString() {
        return "Args(sdkTransactionId=" + this.f280a + ", config=" + this.f281b + ", stripeIntent=" + this.f282c + ", nextActionData=" + this.f283d + ", requestOptions=" + this.f284e + ", enableLogging=" + this.f285f + ", statusBarColor=" + this.f286q + ", injectorKey=" + this.f287r + ", publishableKey=" + this.f288s + ", productUsage=" + this.f289t + ")";
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        p097ha.k.f(parcel, "out");
        parcel.writeParcelable(this.f280a, i10);
        this.f281b.writeToParcel(parcel, i10);
        parcel.writeParcelable(this.f282c, i10);
        this.f283d.writeToParcel(parcel, i10);
        parcel.writeParcelable(this.f284e, i10);
        parcel.writeInt(this.f285f ? 1 : 0);
        Integer num = this.f286q;
        if (num == null) {
            parcel.writeInt(0);
        } else {
            AbstractC0933i.o(parcel, 1, num);
        }
        parcel.writeString(this.f287r);
        parcel.writeString(this.f288s);
        Set set = this.f289t;
        parcel.writeInt(set.size());
        Iterator it = set.iterator();
        while (it.hasNext()) {
            parcel.writeString((String) it.next());
        }
    }
}
