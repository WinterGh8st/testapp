package A8;

import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.FragmentContainerView;
import com.flamingotools.ws.R;
import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;

/* JADX INFO: loaded from: classes.dex */
public final class l extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f261a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Stripe3ds2TransactionActivity f262b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ l(Stripe3ds2TransactionActivity stripe3ds2TransactionActivity, int i10) {
        super(0);
        this.f261a = i10;
        this.f262b = stripe3ds2TransactionActivity;
    }

    @Override // p084ga.a
    public final Object m() {
        switch (this.f261a) {
            case 0:
                return this.f262b.g();
            case 1:
                return this.f262b.e();
            case 2:
                return this.f262b.M;
            case 3:
                View viewInflate = this.f262b.getLayoutInflater().inflate(R.layout.stripe_3ds2_transaction_layout, (ViewGroup) null, false);
                if (viewInflate != null) {
                    return new p194q7.a((FragmentContainerView) viewInflate);
                }
                throw new NullPointerException("rootView");
            default:
                r rVar = this.f262b.f21032L;
                if (rVar != null) {
                    return rVar;
                }
                p097ha.k.l("args");
                throw null;
        }
    }
}
