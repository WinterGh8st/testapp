package A8;

import androidx.lifecycle.g0;
import androidx.lifecycle.q0;
import com.stripe.android.networking.PaymentAnalyticsEvent;
import java.util.LinkedHashMap;
import p016b3.AbstractC0862l;
import p083g9.O;
import p183p8.P1;
import p217s8.C1570d;
import p217s8.P;
import p230ta.E;

/* JADX INFO: loaded from: classes.dex */
public final class z extends q0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r f319b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final P f320c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p160n7.n f321d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C1570d f322e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final p071f9.a f323f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final O f324g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final d f325h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final T0.f f326i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final X9.i f327j;
    public final g0 k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final boolean f328l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f329m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final p160n7.i f330n;

    /* JADX WARN: Code duplicated, block: B:10:0x0060  */
    public z(r rVar, P p10, p160n7.n nVar, C1570d c1570d, p071f9.a aVar, O o4, d dVar, T0.f fVar, X9.i iVar, g0 g0Var, boolean z3) {
        p160n7.i iVar2;
        p097ha.k.f(rVar, "args");
        p097ha.k.f(aVar, "threeDs2Service");
        p097ha.k.f(o4, "messageVersionRegistry");
        p097ha.k.f(dVar, "challengeResultProcessor");
        p097ha.k.f(iVar, "workContext");
        p097ha.k.f(g0Var, "savedStateHandle");
        this.f319b = rVar;
        this.f320c = p10;
        this.f321d = nVar;
        this.f322e = c1570d;
        this.f323f = aVar;
        this.f324g = o4;
        this.f325h = dVar;
        this.f326i = fVar;
        this.f327j = iVar;
        this.k = g0Var;
        this.f328l = z3;
        B0.l lVar = g0Var.f16488b;
        lVar.getClass();
        this.f329m = ((LinkedHashMap) lVar.f736b).containsKey("key_next_step");
        String str = rVar.f283d.f26973f;
        if (str == null) {
            iVar2 = rVar.f284e;
        } else {
            str = str.length() <= 0 ? null : str;
            if (str != null) {
                iVar2 = new p160n7.i(6, str, (String) null);
            } else {
                iVar2 = rVar.f284e;
            }
        }
        this.f330n = iVar2;
    }

    /* JADX WARN: Code duplicated, block: B:8:0x001a  */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0229, code lost:
    
        if (r1 == r6) goto L51;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object e(p183p8.P1 r24, Z9.c r25) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 601
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A8.z.e(p8.P1, Z9.c):java.lang.Object");
    }

    /* JADX WARN: Code duplicated, block: B:8:0x0014  */
    public final Object f(D8.x xVar, P1 p10, p160n7.i iVar, int i10, Z9.c cVar) {
        v vVar;
        if (cVar instanceof v) {
            vVar = (v) cVar;
            int i11 = vVar.f302c;
            if ((i11 & Integer.MIN_VALUE) != 0) {
                vVar.f302c = i11 - Integer.MIN_VALUE;
            } else {
                vVar = new v(this, cVar);
            }
        } else {
            vVar = new v(this, cVar);
        }
        v vVar2 = vVar;
        Object objC = vVar2.f300a;
        Y9.a aVar = Y9.a.f14375a;
        int i12 = vVar2.f302c;
        if (i12 == 0) {
            AbstractC0862l.m0(objC);
            w wVar = new w(xVar, p10, i10, this, iVar, null);
            vVar2.f302c = 1;
            objC = E.C(this.f327j, wVar, vVar2);
            if (objC == aVar) {
                return aVar;
            }
        } else {
            if (i12 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(objC);
        }
        return ((T9.j) objC).f11960a;
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final Object g(Z9.c cVar) {
        x xVar;
        Throwable th;
        z zVar;
        Object objA;
        if (cVar instanceof x) {
            xVar = (x) cVar;
            int i10 = xVar.f312d;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                xVar.f312d = i10 - Integer.MIN_VALUE;
            } else {
                xVar = new x(this, cVar);
            }
        } else {
            xVar = new x(this, cVar);
        }
        Object objE = xVar.f310b;
        Y9.a aVar = Y9.a.f14375a;
        int i11 = xVar.f312d;
        if (i11 == 0) {
            AbstractC0862l.m0(objE);
            this.f321d.a(C1570d.c(this.f322e, PaymentAnalyticsEvent.Auth3ds2Fingerprint, null, null, null, 30));
            try {
                P1 p10 = new P1(this.f319b.f283d);
                xVar.f309a = this;
                xVar.f312d = 1;
                objE = e(p10, xVar);
                if (objE == aVar) {
                    return aVar;
                }
                zVar = this;
            } catch (Throwable th2) {
                th = th2;
                zVar = this;
                objA = AbstractC0862l.A(th);
            }
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            zVar = xVar.f309a;
            try {
                AbstractC0862l.m0(objE);
            } catch (Throwable th3) {
                th = th3;
                objA = AbstractC0862l.A(th);
            }
        }
        objA = (i) objE;
        Throwable thA = T9.j.a(objA);
        if (thA != null) {
            zVar.f321d.a(C1570d.c(zVar.f322e, PaymentAnalyticsEvent.Auth3ds2RequestParamsFailed, null, null, null, 30));
            int i12 = p107i7.c.f23689e;
            objA = new f(new p228t8.b(null, 0, p003a.a.A(thA), false, null, null, null, 123));
        }
        zVar.k.c(Boolean.TRUE, "key_next_step");
        zVar.f329m = true;
        return objA;
    }
}
