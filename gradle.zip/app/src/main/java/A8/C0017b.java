package A8;

/* JADX INFO: renamed from: A8.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0017b extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public d f221a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p083g9.B f222b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public p160n7.i f223c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f224d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public /* synthetic */ Object f225e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ d f226f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f227q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0017b(d dVar, Z9.c cVar) {
        super(cVar);
        this.f226f = dVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f225e = obj;
        this.f227q |= Integer.MIN_VALUE;
        return this.f226f.b(null, null, 0, null, this);
    }
}
