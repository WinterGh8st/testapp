package A8;

/* JADX INFO: loaded from: classes.dex */
public abstract class i {
}
