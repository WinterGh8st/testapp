package A8;

import Y1.C0794i;
import android.app.Application;
import android.content.Context;
import androidx.lifecycle.g0;
import androidx.lifecycle.j0;
import androidx.lifecycle.q0;
import androidx.lifecycle.s0;
import java.security.cert.CertificateException;
import java.util.Set;
import p016b3.AbstractC0862l;
import p083g9.O;
import p217s8.C1570d;
import p217s8.P;

/* JADX INFO: loaded from: classes.dex */
public final class C implements s0, p120j7.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final l f212a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p278y6.s f213b;

    public C(l lVar) {
        this.f212a = lVar;
    }

    @Override // androidx.lifecycle.s0
    public final q0 b(Class cls, S1.d dVar) throws CertificateException {
        B0.l lVar;
        r rVar = (r) this.f212a.m();
        Application applicationK0 = AbstractC0862l.k0(dVar);
        g0 g0VarC = j0.c(dVar);
        p054e4.e.j0(this, rVar.f287r, new A(applicationK0, rVar.f285f, rVar.f288s, rVar.f289t));
        p278y6.s sVar = this.f213b;
        if (sVar == null) {
            p097ha.k.l("subComponentBuilder");
            throw null;
        }
        switch (sVar.f32575a) {
            case 2:
                sVar.f32577c = rVar;
                break;
            default:
                sVar.f32577c = rVar;
                break;
        }
        switch (sVar.f32575a) {
            case 2:
                sVar.f32578d = g0VarC;
                break;
            default:
                sVar.f32578d = g0VarC;
                break;
        }
        switch (sVar.f32575a) {
            case 2:
                sVar.f32579e = applicationK0;
                break;
            default:
                sVar.f32579e = applicationK0;
                break;
        }
        switch (sVar.f32575a) {
            case 2:
                p168o5.b.v((r) sVar.f32577c, r.class);
                p168o5.b.v((g0) sVar.f32578d, g0.class);
                p168o5.b.v((Application) sVar.f32579e, Application.class);
                lVar = new B0.l(sVar.f32576b, new R9.c(3), (r) sVar.f32577c, (g0) sVar.f32578d, (Application) sVar.f32579e, 1);
                break;
            default:
                p168o5.b.v((r) sVar.f32577c, r.class);
                p168o5.b.v((g0) sVar.f32578d, g0.class);
                p168o5.b.v((Application) sVar.f32579e, Application.class);
                lVar = new B0.l(sVar.f32576b, new R9.c(3), (r) sVar.f32577c, (g0) sVar.f32578d, (Application) sVar.f32579e, 2);
                break;
        }
        switch (lVar.f735a) {
            case 1:
                B8.d dVar2 = (B8.d) lVar.f740f;
                p081g7.f fVar = (p081g7.f) dVar2.f1294o.get();
                X9.i iVar = dVar2.f1283c;
                p160n7.n nVar = new p160n7.n(fVar, iVar);
                p081g7.f fVar2 = (p081g7.f) dVar2.f1294o.get();
                p084ga.a aVar = dVar2.f1282b;
                Context context = dVar2.f1281a;
                Set set = dVar2.f1284d;
                C1570d c1570d = dVar2.f1285e;
                return new z((r) lVar.f736b, new P(context, aVar, iVar, set, c1570d, nVar, fVar2), new p160n7.n((p081g7.f) dVar2.f1294o.get(), iVar), c1570d, (p071f9.a) dVar2.f1277D.get(), (O) dVar2.f1278E.get(), (d) dVar2.f1280G.get(), B8.n.a((R9.c) lVar.f737c, (Application) lVar.f738d, (r) lVar.f736b, iVar), iVar, (g0) lVar.f739e, dVar2.f1286f.booleanValue());
            default:
                B8.i iVar2 = (B8.i) lVar.f740f;
                X9.i iVar3 = (X9.i) ((S9.a) iVar2.f1353a).get();
                B b10 = (B) iVar2.f1362j;
                Application application = (Application) iVar2.f1361i;
                Set set2 = (Set) iVar2.k;
                return new z((r) lVar.f736b, new P(application, b10, iVar3, (Set) iVar2.k, new C1570d(application, b10, set2), new p160n7.n((p081g7.f) ((S9.a) iVar2.f1354b).get(), (X9.i) ((S9.a) iVar2.f1353a).get()), (p081g7.f) ((S9.a) iVar2.f1354b).get()), new p160n7.n((p081g7.f) ((S9.a) iVar2.f1354b).get(), (X9.i) ((S9.a) iVar2.f1353a).get()), new C1570d(application, b10, set2), (p071f9.a) ((S9.a) iVar2.f1355c).get(), (O) ((S9.a) iVar2.f1359g).get(), (d) ((S9.a) iVar2.f1360h).get(), B8.n.a((R9.c) lVar.f737c, (Application) lVar.f738d, (r) lVar.f736b, (X9.i) ((S9.a) iVar2.f1353a).get()), (X9.i) ((S9.a) iVar2.f1353a).get(), (g0) lVar.f739e, ((Boolean) iVar2.f1363l).booleanValue());
        }
    }

    @Override // p120j7.a
    public final void c(Object obj) {
        A a3 = (A) obj;
        Application application = a3.f206a;
        Boolean boolValueOf = Boolean.valueOf(a3.f207b);
        B b10 = new B(a3, 0);
        Set set = a3.f209d;
        set.getClass();
        this.f213b = new p278y6.s(new B8.i(new Xa.a(13), new C0794i(12), application, boolValueOf, b10, set, Boolean.valueOf(U9.B.S(application))), 5);
    }
}
