package A8;

import C9.AbstractC0094h;
import C9.C0082d;
import C9.C0085e;
import E8.L0;
import E8.M0;
import E8.P0;
import E8.Q0;
import F9.U;
import G6.F0;
import G6.y0;
import N1.O;
import P7.C0683s0;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ext.SdkExtensions;
import android.util.Log;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.measurement.dynamite.ModuleDescriptor;
import com.stripe.android.financialconnections.FinancialConnectionsSheetActivity;
import com.stripe.android.googlepaylauncher.GooglePayPaymentMethodLauncherActivity;
import com.stripe.android.payments.StripeBrowserLauncherActivity;
import com.stripe.android.payments.bankaccount.ui.CollectBankAccountActivity;
import com.stripe.android.payments.core.authentication.threeds2.Stripe3ds2TransactionActivity;
import com.stripe.android.payments.paymentlauncher.PaymentLauncherConfirmationActivity;
import com.stripe.android.paymentsheet.PaymentSheetActivity;
import com.stripe.android.paymentsheet.paymentdatacollection.polling.PollingActivity;
import com.stripe.android.stripe3ds2.views.ChallengeActivity;
import com.stripe.android.view.AddPaymentMethodActivity;
import com.stripe.android.view.PaymentAuthWebViewActivity;
import com.stripe.android.view.PaymentRelayActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import p021b8.I;
import p083g9.C1124y;
import p083g9.M;

/* JADX INFO: loaded from: classes.dex */
public final class s extends com.bumptech.glide.d {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f290t;

    public /* synthetic */ s(int i10) {
        this.f290t = i10;
    }

    @Override // com.bumptech.glide.d
    public final Object E0(Intent intent, int i10) {
        M0 m2;
        O7.h hVar;
        Object hVar2;
        List arrayList;
        p268x8.f fVar;
        switch (this.f290t) {
            case 0:
                p228t8.b bVar = intent != null ? (p228t8.b) intent.getParcelableExtra("extra_args") : null;
                return bVar == null ? new p228t8.b(null, 0, null, false, null, null, null, ModuleDescriptor.MODULE_VERSION) : bVar;
            case 1:
                AbstractC0094h abstractC0094h = intent != null ? (AbstractC0094h) intent.getParcelableExtra("extra_activity_result") : null;
                return abstractC0094h == null ? C0085e.f2064a : abstractC0094h;
            case 2:
                D8.u uVar = intent != null ? (D8.u) intent.getParcelableExtra("extra_args") : null;
                return uVar == null ? new D8.t(new IllegalStateException("Failed to get PaymentResult from Intent")) : uVar;
            case 3:
                Q0 q10 = (intent == null || (m2 = (M0) intent.getParcelableExtra("com.stripe.android.paymentsheet.PaymentSheetContract.extra_result")) == null) ? null : m2.f3161a;
                return q10 == null ? new P0(new IllegalArgumentException("Failed to retrieve a PaymentSheetResult.")) : q10;
            case 4:
                return new p073g.a(intent, i10);
            case 5:
                if (intent == null || (hVar = (O7.h) intent.getParcelableExtra("com.stripe.android.financialconnections.ConnectionsSheetContract.extra_result")) == null) {
                    return new p216s7.i(new IllegalArgumentException("Failed to retrieve a ConnectionsSheetResult."));
                }
                if (hVar instanceof O7.e) {
                    return p216s7.g.f28775a;
                }
                if (hVar instanceof O7.g) {
                    hVar2 = new p216s7.i(((O7.g) hVar).f9822a);
                } else {
                    if (!(hVar instanceof O7.f)) {
                        throw new U();
                    }
                    C0683s0 c0683s0 = ((O7.f) hVar).f9820b;
                    if (c0683s0 == null) {
                        return new p216s7.i(new IllegalArgumentException("financialConnectionsSession not set."));
                    }
                    hVar2 = new p216s7.h(c0683s0);
                }
                return hVar2;
            case 6:
                p228t8.b bVar2 = intent != null ? (p228t8.b) intent.getParcelableExtra("extra_args") : null;
                return bVar2 == null ? new p228t8.b(null, 0, null, false, null, null, null, ModuleDescriptor.MODULE_VERSION) : bVar2;
            case 7:
                p021b8.B b10 = intent != null ? (p021b8.B) intent.getParcelableExtra("extra_result") : null;
                return b10 == null ? new p021b8.A(1, new IllegalArgumentException("Could not parse a valid result.")) : b10;
            case 8:
                p228t8.b bVar3 = intent != null ? (p228t8.b) intent.getParcelableExtra("extra_args") : null;
                return bVar3 == null ? new p228t8.b(null, 0, null, false, null, null, null, ModuleDescriptor.MODULE_VERSION) : bVar3;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p228t8.b bVar4 = intent != null ? (p228t8.b) intent.getParcelableExtra("extra_args") : null;
                return bVar4 == null ? new p228t8.b(null, 0, null, false, null, null, null, ModuleDescriptor.MODULE_VERSION) : bVar4;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p083g9.B b11 = intent != null ? (p083g9.B) intent.getParcelableExtra("extra_result") : null;
                return b11 == null ? new C1124y(new IllegalStateException("Intent extras did not contain a valid ChallengeResult."), 0, M.f22907e) : b11;
            case 11:
                if (i10 != -1) {
                    intent = null;
                }
                U9.v vVar = U9.v.f12751a;
                if (intent == null) {
                    return vVar;
                }
                LinkedHashSet linkedHashSet = new LinkedHashSet();
                Uri data = intent.getData();
                if (data != null) {
                    linkedHashSet.add(data);
                }
                ClipData clipData = intent.getClipData();
                if (clipData == null && linkedHashSet.isEmpty()) {
                    return vVar;
                }
                if (clipData != null) {
                    int itemCount = clipData.getItemCount();
                    for (int i11 = 0; i11 < itemCount; i11++) {
                        Uri uri = clipData.getItemAt(i11).getUri();
                        if (uri != null) {
                            linkedHashSet.add(uri);
                        }
                    }
                }
                return new ArrayList(linkedHashSet);
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                if (i10 != -1) {
                    intent = null;
                }
                if (intent == null) {
                    return null;
                }
                Uri data2 = intent.getData();
                if (data2 != null) {
                    return data2;
                }
                LinkedHashSet linkedHashSet2 = new LinkedHashSet();
                Uri data3 = intent.getData();
                if (data3 != null) {
                    linkedHashSet2.add(data3);
                }
                ClipData clipData2 = intent.getClipData();
                if (clipData2 == null && linkedHashSet2.isEmpty()) {
                    arrayList = U9.v.f12751a;
                } else {
                    if (clipData2 != null) {
                        int itemCount2 = clipData2.getItemCount();
                        for (int i12 = 0; i12 < itemCount2; i12++) {
                            Uri uri2 = clipData2.getItemAt(i12).getUri();
                            if (uri2 != null) {
                                linkedHashSet2.add(uri2);
                            }
                        }
                    }
                    arrayList = new ArrayList(linkedHashSet2);
                }
                return (Uri) U9.n.D0(arrayList);
            case 13:
                U9.w wVar = U9.w.f12752a;
                if (i10 != -1 || intent == null) {
                    return wVar;
                }
                String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                if (intArrayExtra == null || stringArrayExtra == null) {
                    return wVar;
                }
                ArrayList arrayList2 = new ArrayList(intArrayExtra.length);
                for (int i13 : intArrayExtra) {
                    arrayList2.add(Boolean.valueOf(i13 == 0));
                }
                ArrayList arrayListD0 = U9.l.d0(stringArrayExtra);
                Iterator it = arrayListD0.iterator();
                Iterator it2 = arrayList2.iterator();
                ArrayList arrayList3 = new ArrayList(Math.min(U9.p.p0(arrayListD0, 10), U9.p.p0(arrayList2, 10)));
                while (it.hasNext() && it2.hasNext()) {
                    arrayList3.add(new T9.h(it.next(), it2.next()));
                }
                return U9.B.k0(arrayList3);
            case 14:
                if (intent == null || i10 != -1) {
                    return Boolean.FALSE;
                }
                int[] intArrayExtra2 = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                boolean z3 = false;
                if (intArrayExtra2 != null) {
                    for (int i14 : intArrayExtra2) {
                        if (i14 == 0) {
                            z3 = true;
                        }
                    }
                }
                return Boolean.valueOf(z3);
            case 15:
                return new p073g.a(intent, i10);
            case 16:
                return new p073g.a(intent, i10);
            default:
                p268x8.k kVar = (intent == null || (fVar = (p268x8.f) intent.getParcelableExtra("com.stripe.android.payments.bankaccount.navigation.CollectBankAccountContract.extra_result")) == null) ? null : fVar.f32055a;
                return kVar == null ? new p268x8.j(new IllegalArgumentException("Failed to retrieve a CollectBankAccountResult.")) : kVar;
        }
    }

    @Override // com.bumptech.glide.d
    public final Intent i0(Context context, Object obj) {
        Bundle bundleExtra;
        Class cls;
        Intent intent;
        switch (this.f290t) {
            case 0:
                r rVar = (r) obj;
                p097ha.k.f(rVar, "input");
                Intent intentPutExtras = new Intent(context, (Class<?>) Stripe3ds2TransactionActivity.class).putExtras(G6.C.E(new T9.h("extra_args", rVar)));
                p097ha.k.e(intentPutExtras, "Intent(context, Stripe3d…tExtras(input.toBundle())");
                return intentPutExtras;
            case 1:
                C0082d c0082d = (C0082d) obj;
                p097ha.k.f(c0082d, "input");
                Intent intentPutExtra = new Intent(context, (Class<?>) AddPaymentMethodActivity.class).putExtra("extra_activity_args", c0082d);
                p097ha.k.e(intentPutExtra, "Intent(context, AddPayme…tarter.Args.EXTRA, input)");
                return intentPutExtra;
            case 2:
                D8.f fVar = (D8.f) obj;
                p097ha.k.f(fVar, "input");
                Intent intentPutExtras2 = new Intent(context, (Class<?>) PaymentLauncherConfirmationActivity.class).putExtras(G6.C.E(new T9.h("extra_args", fVar)));
                p097ha.k.e(intentPutExtras2, "Intent(\n            cont…tExtras(input.toBundle())");
                return intentPutExtras2;
            case 3:
                L0 l1 = (L0) obj;
                p097ha.k.f(l1, "input");
                Intent intentPutExtra2 = new Intent(context, (Class<?>) PaymentSheetActivity.class).putExtra("com.stripe.android.paymentsheet.PaymentSheetContract.extra_args", l1);
                p097ha.k.e(intentPutExtra2, "Intent(context, PaymentS…tExtra(EXTRA_ARGS, input)");
                return intentPutExtra2;
            case 4:
                p073g.l lVar = (p073g.l) obj;
                Intent intent2 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
                Intent intent3 = lVar.f22709b;
                if (intent3 != null && (bundleExtra = intent3.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                    intent2.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                    intent3.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                    if (intent3.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                        IntentSender intentSender = lVar.f22708a;
                        p097ha.k.f(intentSender, "intentSender");
                        lVar = new p073g.l(intentSender, null, lVar.f22710c, lVar.f22711d);
                    }
                }
                intent2.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", lVar);
                if (O.I(2)) {
                    Log.v("FragmentManager", "CreateIntent created the following intent: " + intent2);
                }
                return intent2;
            case 5:
                O7.a aVar = (O7.a) obj;
                p097ha.k.f(aVar, "input");
                Intent intentPutExtra3 = new Intent(context, (Class<?>) FinancialConnectionsSheetActivity.class).putExtra("mavericks:arg", aVar);
                p097ha.k.e(intentPutExtra3, "Intent(context, Financia…Mavericks.KEY_ARG, input)");
                return intentPutExtra3;
            case 6:
                Q8.j jVar = (Q8.j) obj;
                p097ha.k.f(jVar, "input");
                Intent intentPutExtras3 = new Intent(context, (Class<?>) PollingActivity.class).putExtras(G6.C.E(new T9.h("extra_args", jVar)));
                p097ha.k.e(intentPutExtras3, "Intent(context, PollingA…ass.java).putExtras(args)");
                return intentPutExtras3;
            case 7:
                I i10 = (I) obj;
                p097ha.k.f(i10, "input");
                Intent intentPutExtras4 = new Intent(context, (Class<?>) GooglePayPaymentMethodLauncherActivity.class).putExtras(G6.C.E(new T9.h("extra_args", i10)));
                p097ha.k.e(intentPutExtras4, "Intent(context, GooglePa…tExtras(input.toBundle())");
                return intentPutExtras4;
            case 8:
                p032c7.A a3 = (p032c7.A) obj;
                p097ha.k.f(a3, "input");
                Intent intentPutExtras5 = new Intent(context, (Class<?>) PaymentRelayActivity.class).putExtras(a3.f().f());
                p097ha.k.e(intentPutExtras5, "Intent(context, PaymentR…entFlowResult.toBundle())");
                return intentPutExtras5;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p044d7.b bVar = (p044d7.b) obj;
                p097ha.k.f(bVar, "input");
                String packageName = context.getPackageName();
                p097ha.k.e(packageName, "context.packageName");
                StringBuilder sb2 = new StringBuilder("stripesdk://payment_return_url/");
                sb2.append(packageName);
                boolean z3 = p097ha.k.b(bVar.f21615e, sb2.toString()) || bVar.f21623w;
                Bundle bundleE = G6.C.E(new T9.h("extra_args", bVar));
                if (z3) {
                    cls = StripeBrowserLauncherActivity.class;
                } else {
                    if (z3) {
                        throw new U();
                    }
                    cls = PaymentAuthWebViewActivity.class;
                }
                Intent intent4 = new Intent(context, (Class<?>) cls);
                intent4.putExtras(bundleE);
                return intent4;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p122j9.w wVar = (p122j9.w) obj;
                p097ha.k.f(wVar, "input");
                Intent intentPutExtras6 = new Intent(context, (Class<?>) ChallengeActivity.class).putExtras(G6.C.E(new T9.h("extra_args", wVar)));
                p097ha.k.e(intentPutExtras6, "Intent(context, Challeng…tExtras(input.toBundle())");
                return intentPutExtras6;
            case 11:
                String str = (String) obj;
                p097ha.k.f(str, "input");
                Intent intentPutExtra4 = new Intent("android.intent.action.GET_CONTENT").addCategory("android.intent.category.OPENABLE").setType(str).putExtra("android.intent.extra.ALLOW_MULTIPLE", true);
                p097ha.k.e(intentPutExtra4, "Intent(Intent.ACTION_GET…TRA_ALLOW_MULTIPLE, true)");
                return intentPutExtra4;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p073g.m mVar = (p073g.m) obj;
                p097ha.k.f(mVar, "input");
                int i11 = Build.VERSION.SDK_INT;
                if (i11 >= 33 || (i11 >= 30 && SdkExtensions.getExtensionVersion(30) >= 2)) {
                    Intent intent5 = new Intent("android.provider.action.PICK_IMAGES");
                    intent5.setType(com.bumptech.glide.e.G(mVar.f22712a));
                    return intent5;
                }
                if (context.getPackageManager().resolveActivity(new Intent("androidx.activity.result.contract.action.PICK_IMAGES"), 1114112) != null) {
                    ResolveInfo resolveInfoResolveActivity = context.getPackageManager().resolveActivity(new Intent("androidx.activity.result.contract.action.PICK_IMAGES"), 1114112);
                    if (resolveInfoResolveActivity == null) {
                        throw new IllegalStateException("Required value was null.");
                    }
                    ActivityInfo activityInfo = resolveInfoResolveActivity.activityInfo;
                    intent = new Intent("androidx.activity.result.contract.action.PICK_IMAGES");
                    intent.setClassName(activityInfo.applicationInfo.packageName, activityInfo.name);
                    intent.setType(com.bumptech.glide.e.G(mVar.f22712a));
                } else {
                    if (context.getPackageManager().resolveActivity(new Intent("com.google.android.gms.provider.action.PICK_IMAGES"), 1114112) == null) {
                        Intent intent6 = new Intent("android.intent.action.OPEN_DOCUMENT");
                        intent6.setType(com.bumptech.glide.e.G(mVar.f22712a));
                        if (intent6.getType() != null) {
                            return intent6;
                        }
                        intent6.setType("*/*");
                        intent6.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*"});
                        return intent6;
                    }
                    ResolveInfo resolveInfoResolveActivity2 = context.getPackageManager().resolveActivity(new Intent("com.google.android.gms.provider.action.PICK_IMAGES"), 1114112);
                    if (resolveInfoResolveActivity2 == null) {
                        throw new IllegalStateException("Required value was null.");
                    }
                    ActivityInfo activityInfo2 = resolveInfoResolveActivity2.activityInfo;
                    intent = new Intent("com.google.android.gms.provider.action.PICK_IMAGES");
                    intent.setClassName(activityInfo2.applicationInfo.packageName, activityInfo2.name);
                    intent.setType(com.bumptech.glide.e.G(mVar.f22712a));
                }
                return intent;
            case 13:
                String[] strArr = (String[]) obj;
                p097ha.k.f(strArr, "input");
                Intent intentPutExtra5 = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
                p097ha.k.e(intentPutExtra5, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
                return intentPutExtra5;
            case 14:
                String str2 = (String) obj;
                p097ha.k.f(str2, "input");
                Intent intentPutExtra6 = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", new String[]{str2});
                p097ha.k.e(intentPutExtra6, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
                return intentPutExtra6;
            case 15:
                Intent intent7 = (Intent) obj;
                p097ha.k.f(intent7, "input");
                return intent7;
            case 16:
                p073g.l lVar2 = (p073g.l) obj;
                p097ha.k.f(lVar2, "input");
                Intent intentPutExtra7 = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", lVar2);
                p097ha.k.e(intentPutExtra7, "Intent(ACTION_INTENT_SEN…NT_SENDER_REQUEST, input)");
                return intentPutExtra7;
            default:
                p268x8.e eVar = (p268x8.e) obj;
                p097ha.k.f(eVar, "input");
                Intent intentPutExtra8 = new Intent(context, (Class<?>) CollectBankAccountActivity.class).putExtra("com.stripe.android.payments.bankaccount.navigation.CollectBankAccountContract.extra_args", eVar);
                p097ha.k.e(intentPutExtra8, "Intent(context, CollectB…tExtra(EXTRA_ARGS, input)");
                return intentPutExtra8;
        }
    }

    @Override // com.bumptech.glide.d
    public p074g0.c v0(Context context, Object obj) {
        switch (this.f290t) {
            case 11:
                p097ha.k.f((String) obj, "input");
                return null;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p097ha.k.f((p073g.m) obj, "input");
                return null;
            case 13:
                String[] strArr = (String[]) obj;
                p097ha.k.f(strArr, "input");
                if (strArr.length == 0) {
                    return new p074g0.c(U9.w.f12752a);
                }
                for (String str : strArr) {
                    if (p063f1.h.checkSelfPermission(context, str) != 0) {
                        return null;
                    }
                }
                int iU = U9.B.U(strArr.length);
                if (iU < 16) {
                    iU = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(iU);
                for (String str2 : strArr) {
                    linkedHashMap.put(str2, Boolean.TRUE);
                }
                return new p074g0.c(linkedHashMap);
            case 14:
                String str3 = (String) obj;
                p097ha.k.f(str3, "input");
                if (p063f1.h.checkSelfPermission(context, str3) == 0) {
                    return new p074g0.c(Boolean.TRUE);
                }
                return null;
            default:
                return super.v0(context, obj);
        }
    }
}
