package A8;

import p183p8.P1;

/* JADX INFO: loaded from: classes.dex */
public final class w extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f303a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ D8.x f304b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ P1 f305c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f306d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ z f307e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ p160n7.i f308f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public w(D8.x xVar, P1 p10, int i10, z zVar, p160n7.i iVar, X9.d dVar) {
        super(2, dVar);
        this.f304b = xVar;
        this.f305c = p10;
        this.f306d = i10;
        this.f307e = zVar;
        this.f308f = iVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new w(this.f304b, this.f305c, this.f306d, this.f307e, this.f308f, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((w) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0086, code lost:
    
        if (r14 == r0) goto L15;
     */
    @Override // Z9.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r14) throws java.lang.Throwable {
        /*
            r13 = this;
            Y9.a r0 = Y9.a.f14375a
            int r1 = r13.f303a
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L20
            if (r1 == r3) goto L1c
            if (r1 != r2) goto L14
            p016b3.AbstractC0862l.m0(r14)
            T9.j r14 = (T9.j) r14
            java.lang.Object r14 = r14.f11960a
            goto L89
        L14:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r14.<init>(r0)
            throw r14
        L1c:
            p016b3.AbstractC0862l.m0(r14)
            goto L5e
        L20:
            p016b3.AbstractC0862l.m0(r14)
            r13.f303a = r3
            D8.x r14 = r13.f304b
            java.lang.Object r1 = r14.f2616q
            java.security.KeyPair r1 = (java.security.KeyPair) r1
            java.security.PublicKey r6 = r1.getPublic()
            java.lang.String r1 = "sdkKeyPair.public"
            p097ha.k.e(r6, r1)
            java.lang.Object r1 = r14.f2611b
            r5 = r1
            T0.f r5 = (T0.f) r5
            g9.C r3 = new g9.C
            java.lang.Object r1 = r14.f2614e
            r7 = r1
            java.lang.String r7 = (java.lang.String) r7
            r10 = 0
            java.lang.Object r1 = r14.f2615f
            r4 = r1
            g9.P r4 = (p083g9.P) r4
            java.lang.Object r1 = r14.f2612c
            r8 = r1
            java.lang.String r8 = (java.lang.String) r8
            java.lang.Object r14 = r14.f2613d
            r9 = r14
            java.security.PublicKey r9 = (java.security.PublicKey) r9
            r3.<init>(r4, r5, r6, r7, r8, r9, r10)
            java.lang.Object r14 = r5.f11537i
            X9.i r14 = (X9.i) r14
            java.lang.Object r14 = p230ta.E.C(r14, r3, r13)
            if (r14 != r0) goto L5e
            goto L88
        L5e:
            g9.b r14 = (p083g9.C1102b) r14
            p8.J1 r3 = new p8.J1
            p8.P1 r1 = r13.f305c
            java.lang.String r4 = r1.f26904a
            java.lang.String r5 = r14.f22951c
            g9.P r1 = r14.f22950b
            java.lang.String r7 = r1.f22916a
            java.lang.String r9 = r14.f22953e
            java.lang.String r10 = r14.f22954f
            java.lang.String r6 = r14.f22952d
            java.lang.String r8 = r14.f22949a
            int r11 = r13.f306d
            r12 = 0
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11, r12)
            A8.z r14 = r13.f307e
            s8.P r14 = r14.f320c
            r13.f303a = r2
            n7.i r1 = r13.f308f
            java.lang.Object r14 = r14.H(r3, r1, r13)
            if (r14 != r0) goto L89
        L88:
            return r0
        L89:
            T9.j r0 = new T9.j
            r0.<init>(r14)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: A8.w.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
