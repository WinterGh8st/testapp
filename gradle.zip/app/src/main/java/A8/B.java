package A8;

import A7.C0013f;
import B0.C0044a;
import B2.C0057h;
import C9.F0;
import C9.H0;
import C9.R0;
import E.L;
import E.S;
import E8.C0175i;
import E8.C0178j0;
import F8.C0233o;
import F8.U;
import G6.y0;
import I.w0;
import L.C0508h0;
import L.C0554x;
import N1.AbstractActivityC0588y;
import O.C0609j0;
import O.C0619o0;
import O.EnumC0621p0;
import O.Q;
import O.u0;
import android.app.Application;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.InputMethodManager;
import com.stripe.android.view.BecsDebitWidget;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CancellationException;
import p032c7.C0944u;
import p230ta.C1647l;
import p230ta.InterfaceC1645k;
import p283z.X;

/* JADX INFO: loaded from: classes.dex */
public final class B extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f210a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f211b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ B(Object obj, int i10) {
        super(0);
        this.f210a = i10;
        this.f211b = obj;
    }

    @Override // p084ga.a
    public final Object m() {
        O.A a3;
        InterfaceC1645k interfaceC1645kR;
        switch (this.f210a) {
            case 0:
                return ((A) this.f211b).f208c;
            case 1:
                C0044a c0044a = (C0044a) this.f211b;
                Locale textLocale = c0044a.f693a.f6321q.getTextLocale();
                p097ha.k.e(textLocale, "paragraphIntrinsics.textPaint.textLocale");
                return new D0.a(textLocale, c0044a.f696d.h());
            case 2:
                return new C0.g(((C0.y) this.f211b).f1617d);
            case 3:
                AbstractActivityC0588y abstractActivityC0588y = (AbstractActivityC0588y) this.f211b;
                Application application = abstractActivityC0588y.getApplication();
                p097ha.k.e(application, "activity.application");
                p278y6.s sVar = new p278y6.s(abstractActivityC0588y.g(), new F0(application, 0), abstractActivityC0588y.e());
                p097ha.e eVarA = p097ha.v.a(H0.class);
                String strB = eVarA.b();
                if (strB != null) {
                    return (H0) sVar.H(eVarA, "androidx.lifecycle.ViewModelProvider.DefaultKey:".concat(strB));
                }
                throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
            case 4:
                ((BecsDebitWidget) this.f211b).getViewBinding$payments_core_release().f27479c.requestFocus();
                return T9.w.f11979a;
            case 5:
                ((R0) this.f211b).f1982g = true;
                return T9.w.f11979a;
            case 6:
                ((D7.h) this.f211b).m();
                return T9.w.f11979a;
            case 7:
                return (p290z8.a) ((D8.v) this.f211b).f2606g.f1309b.get();
            case 8:
                return Float.valueOf(((L) this.f211b).e());
            case G6.F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                return new S((W.j) this.f211b, U9.w.f12752a);
            case G6.F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                return ((C0175i) this.f211b).f3316a.getSharedPreferences("DefaultPrefsRepository", 0);
            case 11:
                return ((K8.i) this.f211b).a().a();
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                C0178j0 c0178j0 = (C0178j0) this.f211b;
                c0178j0.p();
                c0178j0.x();
                return T9.w.f11979a;
            case 13:
                return (Application) this.f211b;
            case 14:
                U u5 = (U) this.f211b;
                C0233o c0233o = C0233o.f3814a;
                C0013f c0013f = u5.f3768c.f3799b;
                if (c0013f != null) {
                    c0013f.invoke(c0233o);
                }
                return T9.w.f11979a;
            case 15:
                Object systemService = ((View) ((C0057h) this.f211b).f921b).getContext().getSystemService("input_method");
                p097ha.k.d(systemService, "null cannot be cast to non-null type android.view.inputmethod.InputMethodManager");
                return (InputMethodManager) systemService;
            case 16:
                return new BaseInputConnection((View) ((H0.B) this.f211b).f4397a, false);
            case G6.F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                ((D7.h) this.f211b).m();
                return T9.w.f11979a;
            case G6.F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                return ((I.y0) this.f211b).c();
            case 19:
                return new w0((X) this.f211b, 0.0f);
            case 20:
                return ((C0944u) ((S9.a) this.f211b).get()).f18235a;
            case 21:
                return ((C0944u) ((B8.a) this.f211b).get()).f18236b;
            case 22:
                ((B7.l) this.f211b).m();
                return Boolean.TRUE;
            case 23:
                C0508h0 c0508h0 = (C0508h0) this.f211b;
                if (!p097ha.k.b(null, c0508h0.f7894a)) {
                    U9.t.v0(c0508h0.f7895b, new C0554x(1, 7));
                    C0619o0 c0619o0 = c0508h0.f7896c;
                    if (c0619o0 != null && (a3 = c0619o0.f9604b) != null) {
                        a3.q(c0619o0, null);
                    }
                }
                return T9.w.f11979a;
            case 24:
                return (List) this.f211b;
            case 25:
                N.a aVar = (N.a) this.f211b;
                aVar.f8879s.setValue(Boolean.valueOf(!((Boolean) aVar.f8879s.getValue()).booleanValue()));
                return T9.w.f11979a;
            case 26:
                HashMap map = new HashMap();
                C0609j0 c0609j0 = (C0609j0) this.f211b;
                int size = c0609j0.f9581a.size();
                for (int i10 = 0; i10 < size; i10++) {
                    O.S s5 = (O.S) c0609j0.f9581a.get(i10);
                    Object obj = s5.f9533b;
                    int i11 = s5.f9532a;
                    Object q10 = obj != null ? new Q(Integer.valueOf(i11), s5.f9533b) : Integer.valueOf(i11);
                    Object linkedHashSet = map.get(q10);
                    if (linkedHashSet == null) {
                        linkedHashSet = new LinkedHashSet();
                        map.put(q10, linkedHashSet);
                    }
                    ((LinkedHashSet) linkedHashSet).add(s5);
                }
                return map;
            case 27:
                u0 u0Var = (u0) this.f211b;
                synchronized (u0Var.f9705b) {
                    interfaceC1645kR = u0Var.r();
                    if (((EnumC0621p0) u0Var.f9719q.getValue()).compareTo(EnumC0621p0.f9619b) <= 0) {
                        Throwable th = u0Var.f9707d;
                        CancellationException cancellationException = new CancellationException("Recomposer shutdown; frame clock awaiter will never resume");
                        cancellationException.initCause(th);
                        throw cancellationException;
                    }
                }
                if (interfaceC1645kR != null) {
                    ((C1647l) interfaceC1645kR).resumeWith(T9.w.f11979a);
                }
                return T9.w.f11979a;
            case 28:
                Q0.t tVar = (Q0.t) this.f211b;
                return Boolean.valueOf((tVar.getParentLayoutCoordinates() == null || tVar.m1getPopupContentSizebOM6tXw() == null) ? false : true);
            default:
                Ma.i iVar = ((Qa.k) this.f211b).f10949e;
                p097ha.k.c(iVar);
                List listA = iVar.a();
                ArrayList arrayList = new ArrayList(U9.p.p0(listA, 10));
                Iterator it = listA.iterator();
                while (it.hasNext()) {
                    arrayList.add((X509Certificate) ((Certificate) it.next()));
                }
                return arrayList;
        }
    }
}
