package A9;

import E.A;
import G6.F0;
import G6.y0;
import O.Z;
import T9.w;
import android.webkit.WebView;
import com.flamingotools.ws.R;
import com.stripe.android.financialconnections.features.institutionpicker.InstitutionPickerState;
import java.util.List;
import p271y.o0;
import p283z.C1979v0;

/* JADX INFO: loaded from: classes2.dex */
public final class h extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f362a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z f363b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(Z z3, int i10) {
        super(0);
        this.f362a = i10;
        this.f363b = z3;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0030  */
    @Override // p084ga.a
    public final Object m() {
        boolean z3;
        switch (this.f362a) {
            case 0:
                this.f363b.setValue(Boolean.TRUE);
                return w.f11979a;
            case 1:
                return new C.i((p084ga.c) this.f363b.getValue());
            case 2:
                return ((InstitutionPickerState) this.f363b.getValue()).d();
            case 3:
                return new D.j((p084ga.c) this.f363b.getValue());
            case 4:
                return (A) ((p084ga.a) this.f363b.getValue()).m();
            case 5:
                this.f363b.setValue(Boolean.TRUE);
                return w.f11979a;
            case 6:
                this.f363b.setValue(Integer.valueOf(R.drawable.stripe_check_routing));
                return w.f11979a;
            case 7:
                this.f363b.setValue(Integer.valueOf(R.drawable.stripe_check_account));
                return w.f11979a;
            case 8:
                this.f363b.setValue(Integer.valueOf(R.drawable.stripe_check_account));
                return w.f11979a;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                return (List) this.f363b.getValue();
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                Boolean bool = (Boolean) this.f363b.getValue();
                bool.getClass();
                return bool;
            case 11:
                this.f363b.setValue(Boolean.FALSE);
                return w.f11979a;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                this.f363b.setValue(Boolean.FALSE);
                return w.f11979a;
            case 13:
                WebView webView = (WebView) this.f363b.getValue();
                if (webView != null) {
                    webView.goBack();
                }
                return w.f11979a;
            case 14:
                this.f363b.setValue(Boolean.TRUE);
                return w.f11979a;
            case 15:
                this.f363b.setValue(Boolean.FALSE);
                return w.f11979a;
            default:
                C1979v0 c1979v0 = (C1979v0) this.f363b.getValue();
                if (!c1979v0.f33147d.d() && !((Boolean) c1979v0.f33150g.getValue()).booleanValue()) {
                    o0 o0Var = c1979v0.f33149f;
                    z3 = o0Var != null ? o0Var.a() : false;
                }
                return Boolean.valueOf(z3);
        }
    }
}
