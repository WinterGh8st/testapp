package A9;

import B0.C0047d;
import T9.w;
import p016b3.AbstractC0862l;
import p230ta.C;
import p291z9.r;

/* JADX INFO: loaded from: classes2.dex */
public final class k extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Object f370a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f371b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0047d f372c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ r f373d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(C0047d c0047d, r rVar, X9.d dVar) {
        super(2, dVar);
        this.f372c = c0047d;
        this.f373d = rVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new k(this.f372c, this.f373d, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((k) create((C) obj, (X9.d) obj2)).invokeSuspend(w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Object obj2;
        Object obj3;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f371b;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            Object obj4 = this.f372c.f709a;
            this.f370a = obj4;
            this.f371b = 1;
            Object objH = this.f373d.h((String) obj4, this);
            if (objH == aVar) {
                return aVar;
            }
            obj2 = obj4;
            obj3 = objH;
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            obj2 = this.f370a;
            AbstractC0862l.m0(obj);
            obj3 = ((T9.j) obj).f11960a;
        }
        if (obj3 instanceof T9.i) {
            obj3 = null;
        }
        return new T9.h(obj2, obj3);
    }
}
