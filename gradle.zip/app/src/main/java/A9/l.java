package A9;

import B0.C0047d;
import I.M;
import T9.w;
import U9.B;
import U9.v;
import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import p016b3.AbstractC0862l;
import p230ta.C;
import p230ta.C1633e;
import p230ta.E;
import p230ta.H;
import p259wa.F;
import p259wa.a0;
import p291z9.r;

/* JADX INFO: loaded from: classes2.dex */
public final class l extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f374a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f375b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ArrayList f376c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ F f377d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ p084ga.a f378e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ r f379f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ N0.b f380q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f381r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public l(ArrayList arrayList, F f10, p084ga.a aVar, r rVar, N0.b bVar, int i10, X9.d dVar) {
        super(2, dVar);
        this.f376c = arrayList;
        this.f377d = f10;
        this.f378e = aVar;
        this.f379f = rVar;
        this.f380q = bVar;
        this.f381r = i10;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        l lVar = new l(this.f376c, this.f377d, this.f378e, this.f379f, this.f380q, this.f381r, dVar);
        lVar.f375b = obj;
        return lVar;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((l) create((C) obj, (X9.d) obj2)).invokeSuspend(w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Object objA;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f374a;
        r rVar = this.f379f;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            C c10 = (C) this.f375b;
            ArrayList arrayList = this.f376c;
            ArrayList arrayList2 = new ArrayList(U9.p.p0(arrayList, 10));
            int size = arrayList.size();
            int i11 = 0;
            while (i11 < size) {
                Object obj2 = arrayList.get(i11);
                i11++;
                arrayList2.add(E.c(c10, new k((C0047d) obj2, rVar, null)));
            }
            this.f374a = 1;
            objA = arrayList2.isEmpty() ? v.f12751a : new C1633e((H[]) arrayList2.toArray(new H[0])).a(this);
            if (objA == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
            objA = obj;
        }
        ArrayList arrayList3 = new ArrayList();
        for (T9.h hVar : (Iterable) objA) {
            Bitmap bitmap = (Bitmap) hVar.f11958b;
            T9.h hVar2 = bitmap != null ? new T9.h(hVar.f11957a, bitmap) : null;
            if (hVar2 != null) {
                arrayList3.add(hVar2);
            }
        }
        Map mapK0 = B.k0(arrayList3);
        LinkedHashMap linkedHashMap = new LinkedHashMap(B.U(mapK0.size()));
        for (Map.Entry entry : mapK0.entrySet()) {
            Object key = entry.getKey();
            long jO = p054e4.e.o(((Bitmap) entry.getValue()).getWidth(), ((Bitmap) entry.getValue()).getHeight());
            float fB = 1 / this.f380q.b();
            long jO2 = p054e4.e.o(p038d0.f.d(jO) * fB, p038d0.f.b(jO) * fB);
            linkedHashMap.put(key, new M(new B0.r(this.f381r, E5.b.L(4294967296L, p038d0.f.d(jO2)), E5.b.L(4294967296L, p038d0.f.b(jO2))), Ua.l.v(858918421, new j(entry, rVar, jO2), true)));
        }
        a0 a0Var = (a0) this.f377d;
        a0Var.getClass();
        a0Var.k(null, linkedHashMap);
        this.f378e.m();
        return w.f11979a;
    }
}
