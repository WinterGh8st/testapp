package A9;

import A8.B;
import B.AbstractC0034p;
import B.C0020b;
import B.C0038u;
import B.L;
import B.b0;
import B0.y;
import B2.C0057h;
import E8.f1;
import F8.U;
import G0.C0273j;
import G0.I;
import G0.J;
import G0.t;
import G6.F0;
import I.C0419q;
import I.r0;
import K.r;
import L.AbstractC0492c;
import L.C0508h0;
import L.C0515j1;
import L.C0518k1;
import L.C0554x;
import O.A0;
import O.AbstractC0590a;
import O.AbstractC0630v;
import O.C0596d;
import O.C0610k;
import O.C0629u;
import O.C0634z;
import O.D;
import O.D0;
import O.Q0;
import O.W;
import O.Z;
import T9.w;
import Y1.A;
import android.graphics.Typeface;
import android.text.Spannable;
import com.stripe.android.paymentsheet.addresselement.AddressElementActivity;
import java.util.ArrayList;
import java.util.WeakHashMap;
import o0.E;
import p016b3.AbstractC0862l;
import p132k9.s;
import p220t0.C1593j;
import p220t0.InterfaceC1594k;
import p232u0.B0;
import p234u2.AbstractC1712b;
import p234u2.C1717g;
import p234u2.C1722l;
import p234u2.X;
import p260x.AbstractC1891x;
import p260x.C1871c;
import p260x.C1879k;
import p260x.C1890w;
import p260x.f0;
import p271y.C;
import p271y.Y;
import p271y.a0;

/* JADX INFO: loaded from: classes2.dex */
public final class i extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f364a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f365b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f366c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ i(int i10, Object obj, Object obj2) {
        super(3);
        this.f364a = i10;
        this.f365b = obj;
        this.f366c = obj2;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        Typeface typeface;
        Z.j jVar = Z.j.f14412b;
        int i10 = 8;
        Object obj4 = C0610k.f9587a;
        w wVar = w.f11979a;
        Object obj5 = this.f365b;
        Object obj6 = this.f366c;
        switch (this.f364a) {
            case 0:
                C0629u c0629u = (C0629u) obj2;
                int iIntValue = ((Number) obj3).intValue();
                p097ha.k.f((String) obj, "it");
                if ((iIntValue & 81) == 16 && c0629u.C()) {
                    c0629u.U();
                } else {
                    a aVar = (a) obj5;
                    p195q8.l.c((p087h0.b) obj6, p197qa.a.o(aVar.f332b, c0629u), androidx.compose.foundation.layout.d.b(androidx.compose.foundation.layout.d.d(jVar, 1.0f), 1.0f), null, null, 0.0f, aVar.f333c, c0629u, 392, 56);
                }
                return wVar;
            case 1:
                C0629u c0629u2 = (C0629u) obj2;
                int iIntValue2 = ((Number) obj3).intValue();
                p097ha.k.f((C0038u) obj, "$this$BottomSheet");
                if ((iIntValue2 & 81) == 16 && c0629u2.C()) {
                    c0629u2.U();
                } else {
                    p168o5.b.i(androidx.compose.foundation.layout.d.c(jVar), null, 0L, 0L, null, 0.0f, Ua.l.u(c0629u2, -2118308051, new C7.i(7, (A) obj5, (AddressElementActivity) obj6)), c0629u2, 1572870, 62);
                }
                return wVar;
            case 2:
                C0629u c0629u3 = (C0629u) obj2;
                int iIntValue3 = ((Number) obj3).intValue();
                p097ha.k.f((C0038u) obj, "$this$InputAddressScreen");
                if ((iIntValue3 & 81) == 16 && c0629u3.C()) {
                    c0629u3.U();
                } else {
                    s sVar = (s) obj5;
                    com.bumptech.glide.d.K(sVar.f24627b, ((U) obj6).f3775j, sVar.f24626a, sVar.f24630e, c0629u3, 4680);
                }
                return wVar;
            case 3:
                C0629u c0629u4 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f((Z.m) obj, "$this$composed");
                c0629u4.a0(-102778667);
                c0629u4.a0(773894976);
                c0629u4.a0(-492369756);
                Object objE = c0629u4.E();
                if (objE == obj4) {
                    Object d10 = new D(AbstractC0630v.z(c0629u4));
                    c0629u4.m0(d10);
                    objE = d10;
                }
                c0629u4.u(false);
                p282ya.e eVar = ((D) objE).f9451a;
                c0629u4.u(false);
                c0629u4.a0(-492369756);
                Object objE2 = c0629u4.E();
                if (objE2 == obj4) {
                    objE2 = AbstractC0630v.I(null, W.f9545e);
                    c0629u4.m0(objE2);
                }
                c0629u4.u(false);
                Z z3 = (Z) objE2;
                Z zL = AbstractC0630v.L((C0419q) obj5, c0629u4);
                c0629u4.a0(511388516);
                A.l lVar = (A.l) obj6;
                boolean zF = c0629u4.f(z3) | c0629u4.f(lVar);
                Object objE3 = c0629u4.E();
                if (zF || objE3 == obj4) {
                    objE3 = new A8.p(22, z3, lVar);
                    c0629u4.m0(objE3);
                }
                c0629u4.u(false);
                AbstractC0630v.c(lVar, (p084ga.c) objE3, c0629u4);
                A.l lVar2 = (A.l) obj6;
                Z.m mVarA = E.a(jVar, lVar2, new r0(eVar, z3, lVar2, zL, null));
                c0629u4.u(false);
                return mVarA;
            case 4:
                C0629u c0629u5 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f((Z.m) obj, "$this$composed");
                c0629u5.a0(759876635);
                c0629u5.a0(-1589795249);
                c0629u5.a0(-492369756);
                Object objE4 = c0629u5.E();
                if (objE4 == obj4) {
                    objE4 = AbstractC0630v.B((A7.k) obj5);
                    c0629u5.m0(objE4);
                }
                c0629u5.u(false);
                Q0 q10 = (Q0) objE4;
                c0629u5.a0(-492369756);
                Object objE5 = c0629u5.E();
                if (objE5 == obj4) {
                    objE5 = new C1871c(new p038d0.c(((p038d0.c) q10.getValue()).f21401a), r.f6734b, new p038d0.c(r.f6735c), i10);
                    c0629u5.m0(objE5);
                }
                c0629u5.u(false);
                C1871c c1871c = (C1871c) objE5;
                AbstractC0630v.e(c0629u5, new K.q(q10, c1871c, null), wVar);
                C1879k c1879k = c1871c.f31733c;
                c0629u5.u(false);
                c0629u5.a0(1157296644);
                boolean zF2 = c0629u5.f(c1879k);
                Object objE6 = c0629u5.E();
                if (zF2 || objE6 == obj4) {
                    objE6 = new K.n(0, c1879k);
                    c0629u5.m0(objE6);
                }
                c0629u5.u(false);
                Z.m mVar = (Z.m) ((p084ga.c) obj6).invoke(objE6);
                c0629u5.u(false);
                return mVar;
            case 5:
                y yVar = (y) obj;
                int iIntValue4 = ((Number) obj2).intValue();
                int iIntValue5 = ((Number) obj3).intValue();
                p097ha.k.f(yVar, "spanStyle");
                t tVar = yVar.f832c;
                if (tVar == null) {
                    tVar = t.f4136q;
                }
                G0.p pVar = yVar.f833d;
                int i11 = pVar != null ? pVar.f4128a : 0;
                G0.q qVar = yVar.f834e;
                int i12 = qVar != null ? qVar.f4129a : 1;
                p097ha.k.f(tVar, "fontWeight");
                J0.d dVar = (J0.d) ((J0.c) obj6).f6314b;
                J jB = ((C0273j) dVar.f6319e).b(yVar.f835f, tVar, i11, i12);
                if (jB instanceof I) {
                    Object obj7 = ((I) jB).f4094a;
                    p097ha.k.d(obj7, "null cannot be cast to non-null type android.graphics.Typeface");
                    typeface = (Typeface) obj7;
                } else {
                    C0057h c0057h = new C0057h(jB, dVar.f6324t);
                    dVar.f6324t = c0057h;
                    Object obj8 = c0057h.f922c;
                    p097ha.k.d(obj8, "null cannot be cast to non-null type android.graphics.Typeface");
                    typeface = (Typeface) obj8;
                }
                ((Spannable) obj5).setSpan(new E0.b(typeface), iIntValue4, iIntValue5, 33);
                return wVar;
            case 6:
                p084ga.e eVar2 = (p084ga.e) obj;
                C0629u c0629u6 = (C0629u) obj2;
                int iIntValue6 = ((Number) obj3).intValue();
                p097ha.k.f(eVar2, "children");
                if ((iIntValue6 & 14) == 0) {
                    iIntValue6 |= c0629u6.h(eVar2) ? 4 : 2;
                }
                if ((iIntValue6 & 91) == 18 && c0629u6.C()) {
                    c0629u6.U();
                } else {
                    int i13 = U9.n.A0((ArrayList) obj5).size() != 1 ? 75 : 0;
                    C1890w c1890w = AbstractC1891x.f31849d;
                    p097ha.k.f(c1890w, "easing");
                    f0 f0Var = new f0(150, i13, c1890w);
                    B b10 = new B((C0508h0) obj6, 23);
                    c0629u6.a0(1016418159);
                    c0629u6.a0(-492369756);
                    Object objE7 = c0629u6.E();
                    if (objE7 == obj4) {
                        objE7 = p195q8.m.b(0.0f);
                        c0629u6.m0(objE7);
                    }
                    c0629u6.u(false);
                    C1871c c1871c2 = (C1871c) objE7;
                    Boolean bool = Boolean.TRUE;
                    AbstractC0630v.e(c0629u6, new C0515j1(c1871c2, f0Var, b10, null), bool);
                    C1879k c1879k2 = c1871c2.f31733c;
                    c0629u6.u(false);
                    p260x.r rVar = AbstractC1891x.f31846a;
                    p097ha.k.f(rVar, "easing");
                    f0 f0Var2 = new f0(150, i13, rVar);
                    c0629u6.a0(2003504988);
                    c0629u6.a0(-492369756);
                    Object objE8 = c0629u6.E();
                    if (objE8 == obj4) {
                        objE8 = p195q8.m.b(0.8f);
                        c0629u6.m0(objE8);
                    }
                    c0629u6.u(false);
                    C1871c c1871c3 = (C1871c) objE8;
                    AbstractC0630v.e(c0629u6, new C0518k1(c1871c3, f0Var2, null), bool);
                    C1879k c1879k3 = c1871c3.f31733c;
                    c0629u6.u(false);
                    Z.m mVarA2 = p284z0.k.a(androidx.compose.ui.graphics.a.b(Z.j.f14412b, ((Number) c1879k3.f31815b.getValue()).floatValue(), ((Number) c1879k3.f31815b.getValue()).floatValue(), ((Number) c1879k2.f31815b.getValue()).floatValue(), null, 131064), false, new C0554x(1, 6));
                    c0629u6.a0(733328855);
                    p199r0.B bC = AbstractC0034p.c(Z.a.f14388a, false, c0629u6);
                    c0629u6.a0(-1323940314);
                    N0.b bVar = (N0.b) c0629u6.l(p232u0.W.f29758e);
                    N0.j jVar2 = (N0.j) c0629u6.l(p232u0.W.k);
                    B0 b11 = (B0) c0629u6.l(p232u0.W.f29768p);
                    InterfaceC1594k.f29156n.getClass();
                    p084ga.a aVar2 = C1593j.f29148b;
                    V.a aVarI = p195q8.h.i(mVarA2);
                    c0629u6.d0();
                    if (c0629u6.M) {
                        c0629u6.n(aVar2);
                    } else {
                        c0629u6.o0();
                    }
                    c0629u6.f9699x = false;
                    AbstractC0630v.P(c0629u6, C1593j.f29152f, bC);
                    AbstractC0630v.P(c0629u6, C1593j.f29150d, bVar);
                    AbstractC0630v.P(c0629u6, C1593j.f29153g, jVar2);
                    aVarI.I(AbstractC0492c.g(c0629u6, b11, C1593j.f29154h, c0629u6, c0629u6), c0629u6, 0);
                    c0629u6.a0(2058660585);
                    eVar2.invoke(c0629u6, Integer.valueOf(iIntValue6 & 14));
                    c0629u6.u(false);
                    c0629u6.u(true);
                    c0629u6.u(false);
                    c0629u6.u(false);
                }
                return wVar;
            case 7:
                C0629u c0629u7 = (C0629u) obj2;
                int iIntValue7 = ((Number) obj3).intValue();
                p097ha.k.f((L) obj, "it");
                if ((iIntValue7 & 81) == 16 && c0629u7.C()) {
                    c0629u7.U();
                } else {
                    AbstractC1712b abstractC1712b = (AbstractC1712b) obj5;
                    if (p097ha.k.b(abstractC1712b, X.f30009b) ? true : abstractC1712b instanceof C1722l ? true : abstractC1712b instanceof p234u2.W) {
                        c0629u7.a0(856289703);
                        com.bumptech.glide.d.M(0, c0629u7);
                        c0629u7.u(false);
                    } else if (abstractC1712b instanceof C1717g) {
                        c0629u7.a0(856289753);
                        p029c4.a.h0(((C1717g) abstractC1712b).f30029b, (B7.n) obj6, c0629u7, 8);
                        c0629u7.u(false);
                    } else {
                        c0629u7.a0(856289903);
                        c0629u7.u(false);
                    }
                }
                return wVar;
            case 8:
                AbstractC0590a abstractC0590a = (AbstractC0590a) obj;
                p097ha.k.f(abstractC0590a, "applier");
                p097ha.k.f((D0) obj2, "<anonymous parameter 1>");
                p097ha.k.f((C0634z) obj3, "<anonymous parameter 2>");
                ((p084ga.e) obj5).invoke(abstractC0590a.c(), obj6);
                return wVar;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p097ha.k.f((AbstractC0590a) obj, "<anonymous parameter 0>");
                p097ha.k.f((D0) obj2, "<anonymous parameter 1>");
                p097ha.k.f((C0634z) obj3, "<anonymous parameter 2>");
                ((C7.h) obj5).invoke(((C0629u) obj6).f9683g);
                return wVar;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                D0 d11 = (D0) obj2;
                p097ha.k.f((AbstractC0590a) obj, "<anonymous parameter 0>");
                p097ha.k.f(d11, "slots");
                p097ha.k.f((C0634z) obj3, "<anonymous parameter 2>");
                d11.e();
                C0596d c0596d = (C0596d) obj6;
                c0596d.getClass();
                A0 a3 = (A0) obj5;
                p097ha.k.f(a3, "slots");
                if (a3.f9439f) {
                    AbstractC0630v.x("Use active SlotWriter to determine anchor location instead");
                    throw null;
                }
                int i14 = c0596d.f9555a;
                if (i14 == Integer.MIN_VALUE) {
                    throw new IllegalArgumentException("Anchor refers to a group that was removed");
                }
                d11.s(a3, i14);
                d11.j();
                return wVar;
            case 11:
                Z.m mVar2 = (Z.m) obj;
                C0629u c0629u8 = (C0629u) obj2;
                int iIntValue8 = ((Number) obj3).intValue();
                p097ha.k.f(mVar2, "scrollModifier");
                if ((iIntValue8 & 14) == 0) {
                    iIntValue8 |= c0629u8.f(mVar2) ? 4 : 2;
                }
                if ((iIntValue8 & 91) == 18 && c0629u8.C()) {
                    c0629u8.U();
                } else if (((Boolean) ((Z) obj6).getValue()).booleanValue()) {
                    c0629u8.a0(-866664396);
                    com.bumptech.glide.e.h((f1) obj5, mVar2, c0629u8, ((iIntValue8 << 3) & 112) | 8);
                    c0629u8.u(false);
                } else {
                    c0629u8.a0(-866664224);
                    c0629u8.a0(1596175702);
                    WeakHashMap weakHashMap = b0.f566u;
                    b0 b0VarE = C0020b.e(c0629u8);
                    c0629u8.u(false);
                    AbstractC0862l.m(c0629u8, com.bumptech.glide.e.U(b0VarE.f571e));
                    c0629u8.u(false);
                }
                return wVar;
            default:
                C0629u c0629u9 = (C0629u) obj2;
                ((Number) obj3).intValue();
                p097ha.k.f((Z.m) obj, "$this$composed");
                c0629u9.a0(-353972293);
                p271y.X x10 = (p271y.X) obj5;
                if (x10 == null) {
                    x10 = C.f32156c;
                }
                Y yA = x10.a((A.l) obj6, c0629u9);
                c0629u9.a0(1157296644);
                boolean zF3 = c0629u9.f(yA);
                Object objE9 = c0629u9.E();
                if (zF3 || objE9 == obj4) {
                    objE9 = new a0(yA);
                    c0629u9.m0(objE9);
                }
                c0629u9.u(false);
                a0 a0Var = (a0) objE9;
                c0629u9.u(false);
                return a0Var;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public i(AbstractC1712b abstractC1712b, B7.n nVar, int i10) {
        super(3);
        this.f364a = 7;
        this.f365b = abstractC1712b;
        this.f366c = nVar;
    }
}
