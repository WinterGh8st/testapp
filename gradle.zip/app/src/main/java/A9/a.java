package A9;

import p050e0.r;

/* JADX INFO: loaded from: classes2.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f331a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f332b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final r f333c;

    public a(int i10, int i11, r rVar) {
        this.f331a = i10;
        this.f332b = i11;
        this.f333c = rVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f331a == aVar.f331a && this.f332b == aVar.f332b && p097ha.k.b(this.f333c, aVar.f333c);
    }

    public final int hashCode() {
        int iA = p015b2.a.a(this.f332b, Integer.hashCode(this.f331a) * 31, 31);
        r rVar = this.f333c;
        return iA + (rVar == null ? 0 : rVar.hashCode());
    }

    public final String toString() {
        return "Drawable(id=" + this.f331a + ", contentDescription=" + this.f332b + ", colorFilter=" + this.f333c + ")";
    }
}
