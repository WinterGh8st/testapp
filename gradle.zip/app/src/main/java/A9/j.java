package A9;

import O.C0629u;
import T9.w;
import java.util.Map;
import p291z9.r;

/* JADX INFO: loaded from: classes2.dex */
public final class j extends p097ha.l implements p084ga.f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ Map.Entry f367a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ r f368b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ long f369c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(Map.Entry entry, r rVar, long j10) {
        super(3);
        this.f367a = entry;
        this.f368b = rVar;
        this.f369c = j10;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        C0629u c0629u = (C0629u) obj2;
        int iIntValue = ((Number) obj3).intValue();
        p097ha.k.f((String) obj, "it");
        if ((iIntValue & 81) == 16 && c0629u.C()) {
            c0629u.U();
        } else {
            String str = (String) this.f367a.getKey();
            Z.j jVar = Z.j.f14412b;
            long j10 = this.f369c;
            p195q8.i.b(str, this.f368b, null, androidx.compose.foundation.layout.d.e(androidx.compose.foundation.layout.d.m(jVar, p038d0.f.d(j10)), p038d0.f.b(j10)), null, null, null, null, c0629u, 448, 496);
        }
        return w.f11979a;
    }
}
