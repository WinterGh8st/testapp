package A9;

import B0.C0047d;
import B0.C0049f;
import T9.w;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/* JADX INFO: loaded from: classes2.dex */
public final class g extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ boolean f358a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ f f359b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0049f f360c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Context f361d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public g(boolean z3, f fVar, C0049f c0049f, Context context) {
        super(1);
        this.f358a = z3;
        this.f359b = fVar;
        this.f360c = c0049f;
        this.f361d = context;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        int iIntValue = ((Number) obj).intValue();
        if (this.f358a) {
            this.f359b.getClass();
            C0047d c0047d = (C0047d) U9.n.D0(this.f360c.b(iIntValue, iIntValue, "URL"));
            if (c0047d != null) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse((String) c0047d.f709a));
                this.f361d.startActivity(intent);
            }
        }
        return w.f11979a;
    }
}
