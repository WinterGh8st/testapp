package A9;

import B0.C0049f;
import B0.D;
import B0.y;
import O.AbstractC0630v;
import O.C0629u;
import T9.w;
import java.util.Map;

/* JADX INFO: loaded from: classes2.dex */
public final class d extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f341a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z.m f342b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ long f343c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ D f344d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ boolean f345e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ int f346f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ int f347q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ int f348r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ CharSequence f349s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ Object f350t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ Object f351u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ p097ha.l f352v;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(C0049f c0049f, long j10, D d10, Z.m mVar, Map map, boolean z3, int i10, int i11, b bVar, g gVar, int i12) {
        super(2);
        this.f349s = c0049f;
        this.f343c = j10;
        this.f344d = d10;
        this.f342b = mVar;
        this.f350t = map;
        this.f345e = z3;
        this.f346f = i10;
        this.f347q = i11;
        this.f351u = bVar;
        this.f352v = gVar;
        this.f348r = i12;
    }

    /* JADX WARN: Type inference failed for: r5v0, types: [java.lang.Object, java.util.Map] */
    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        int i10 = this.f341a;
        C0629u c0629u = (C0629u) obj;
        ((Number) obj2).intValue();
        switch (i10) {
            case 0:
                int iS = AbstractC0630v.S(this.f348r | 1);
                g gVar = (g) this.f352v;
                E5.b.d((C0049f) this.f349s, this.f343c, this.f344d, this.f342b, this.f350t, this.f345e, this.f346f, this.f347q, (b) this.f351u, gVar, c0629u, iS);
                break;
            default:
                int iS2 = AbstractC0630v.S(this.f347q | 1);
                E5.b.g((String) this.f349s, this.f342b, (Map) this.f350t, this.f343c, this.f344d, this.f345e, (y) this.f351u, this.f346f, (f) this.f352v, c0629u, iS2, this.f348r);
                break;
        }
        return w.f11979a;
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(String str, Z.m mVar, Map map, long j10, D d10, boolean z3, y yVar, int i10, f fVar, int i11, int i12) {
        super(2);
        this.f349s = str;
        this.f342b = mVar;
        this.f350t = map;
        this.f343c = j10;
        this.f344d = d10;
        this.f345e = z3;
        this.f351u = yVar;
        this.f346f = i10;
        this.f352v = fVar;
        this.f347q = i11;
        this.f348r = i12;
    }
}
