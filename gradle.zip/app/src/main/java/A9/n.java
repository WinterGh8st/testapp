package A9;

import G6.F0;
import T9.w;
import p199r0.K;
import p199r0.L;

/* JADX INFO: loaded from: classes2.dex */
public final class n extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f393a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ L f394b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n(L l4, int i10) {
        super(1);
        this.f393a = i10;
        this.f394b = l4;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        int i10;
        switch (this.f393a) {
            case 0:
                p097ha.k.f((K) obj, "$this$layout");
                K.b(this.f394b, 0, 0, 0.0f);
                break;
            case 1:
                K k = (K) obj;
                p097ha.k.f(k, "$this$layout");
                K.d(k, this.f394b, 0, 0);
                break;
            case 2:
                K k3 = (K) obj;
                p097ha.k.f(k3, "$this$layout");
                K.d(k3, this.f394b, 0, 0);
                break;
            case 3:
                p097ha.k.f((K) obj, "$this$layout");
                long j10 = N0.g.f8976b;
                L l4 = this.f394b;
                p097ha.k.f(l4, "$this$placeRelative");
                if (K.f27574b == N0.j.f8984a || (i10 = K.f27575c) == 0) {
                    long j11 = l4.f27580e;
                    l4.g0(p143m0.c.g(((int) (j10 >> 32)) + ((int) (j11 >> 32)), ((int) (j10 & 4294967295L)) + ((int) (j11 & 4294967295L))), 0.0f, null);
                } else {
                    long jG = p143m0.c.g((i10 - l4.f27576a) - ((int) (j10 >> 32)), (int) (j10 & 4294967295L));
                    long j12 = l4.f27580e;
                    l4.g0(p143m0.c.g(((int) (jG >> 32)) + ((int) (j12 >> 32)), ((int) (jG & 4294967295L)) + ((int) (j12 & 4294967295L))), 0.0f, null);
                }
                break;
            case 4:
                K k4 = (K) obj;
                p097ha.k.f(k4, "$this$layout");
                K.d(k4, this.f394b, 0, 0);
                break;
            case 5:
                K k10 = (K) obj;
                p097ha.k.f(k10, "$this$layout");
                K.d(k10, this.f394b, 0, 0);
                break;
            case 6:
                K k11 = (K) obj;
                p097ha.k.f(k11, "$this$layout");
                K.d(k11, this.f394b, 0, 0);
                break;
            case 7:
                p097ha.k.f((K) obj, "$this$layout");
                K.b(this.f394b, 0, 0, 0.0f);
                break;
            case 8:
                p097ha.k.f((K) obj, "$this$layout");
                K.b(this.f394b, 0, 0, 0.0f);
                break;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p097ha.k.f((K) obj, "$this$layout");
                K.b(this.f394b, 0, 0, 0.0f);
                break;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                K k12 = (K) obj;
                p097ha.k.f(k12, "$this$layout");
                K.d(k12, this.f394b, 0, 0);
                break;
            case 11:
                K k13 = (K) obj;
                p097ha.k.f(k13, "$this$layout");
                K.d(k13, this.f394b, 0, 0);
                break;
            default:
                K k14 = (K) obj;
                p097ha.k.f(k14, "$this$layout");
                K.e(k14, this.f394b, 0, 0);
                break;
        }
        return w.f11979a;
    }
}
