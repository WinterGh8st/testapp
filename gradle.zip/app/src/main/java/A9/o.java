package A9;

import B0.B;
import B0.D;
import L.AbstractC0492c;
import L.f2;
import O.C0610k;
import O.C0629u;
import T9.w;
import java.util.ArrayList;
import p016b3.AbstractC0862l;
import p097ha.u;

/* JADX INFO: loaded from: classes2.dex */
public final class o extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f395a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f396b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ u f397c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f398d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ long f399e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ long f400f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ long f401q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ long f402r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ boolean f403s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ b f404t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ D f405u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ int f406v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ long f407w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ int f408x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final /* synthetic */ ArrayList f409y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public o(String str, String str2, u uVar, int i10, long j10, long j11, long j12, long j13, boolean z3, b bVar, D d10, int i11, long j14, int i12, ArrayList arrayList) {
        super(2);
        this.f395a = str;
        this.f396b = str2;
        this.f397c = uVar;
        this.f398d = i10;
        this.f399e = j10;
        this.f400f = j11;
        this.f401q = j12;
        this.f402r = j13;
        this.f403s = z3;
        this.f404t = bVar;
        this.f405u = d10;
        this.f406v = i11;
        this.f407w = j14;
        this.f408x = i12;
        this.f409y = arrayList;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        String str;
        String str2;
        Object objA;
        Object objA2;
        C0629u c0629u = (C0629u) obj;
        int iIntValue = ((Number) obj2).intValue() & 11;
        w wVar = w.f11979a;
        if (iIntValue == 2 && c0629u.C()) {
            c0629u.U();
            return wVar;
        }
        u uVar = this.f397c;
        Object obj3 = uVar.f23278a;
        c0629u.a0(1618982084);
        String strT = this.f395a;
        boolean zF = c0629u.f(strT);
        String str3 = this.f396b;
        boolean zF2 = c0629u.f(obj3) | zF | c0629u.f(str3);
        Object objE = c0629u.E();
        if (zF2 || objE == C0610k.f9587a) {
            Object obj4 = uVar.f23278a;
            p097ha.k.c(obj4);
            p038d0.d dVarB = ((B) obj4).b(p197qa.o.U(strT));
            long j10 = this.f407w;
            if (dVarB.f21405c > N0.a.h(j10)) {
                Object obj5 = uVar.f23278a;
                p097ha.k.c(obj5);
                float fH = N0.a.h(j10) - (((B) obj5).b(p197qa.o.U(strT) + 1).c() * this.f408x);
                int iU = p197qa.o.U(strT);
                ArrayList arrayList = this.f409y;
                int iJ0 = U9.o.j0(arrayList);
                ArrayList arrayList2 = new ArrayList();
                ArrayList arrayList3 = new ArrayList();
                int size = arrayList.size();
                float f10 = 0.0f;
                float fC = 0.0f;
                int i10 = 0;
                int i11 = 0;
                int i12 = 0;
                int i13 = iJ0;
                int i14 = iU;
                loop0: while (i11 < size && i10 < i14) {
                    Object obj6 = uVar.f23278a;
                    p097ha.k.c(obj6);
                    p038d0.d dVarB2 = ((B) obj6).b(i10);
                    Object obj7 = uVar.f23278a;
                    p097ha.k.c(obj7);
                    p038d0.d dVarB3 = ((B) obj7).b(i14);
                    if (fC > f10 || dVarB2.c() + fC + f10 > fH) {
                        int i15 = i10;
                        int i16 = i14;
                        if (fC < f10) {
                            break;
                        }
                        if (dVarB3.c() + fC + f10 > fH) {
                            break;
                        }
                        int i17 = i13 - 1;
                        int iIntValue2 = ((Number) arrayList.get(i13)).intValue() - ((Number) arrayList.get(i17)).intValue();
                        ArrayList arrayList4 = new ArrayList();
                        float fC2 = f10;
                        int i18 = i16;
                        int i19 = 0;
                        while (i19 < iIntValue2) {
                            try {
                                str2 = strT;
                                try {
                                    arrayList4.add(0, Character.valueOf(strT.charAt(i18)));
                                    Object obj8 = uVar.f23278a;
                                    p097ha.k.c(obj8);
                                    fC2 += ((B) obj8).b(i18).c();
                                    i18--;
                                    objA = wVar;
                                } catch (Throwable th) {
                                    th = th;
                                    objA = AbstractC0862l.A(th);
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                str2 = strT;
                            }
                            if (T9.j.a(objA) != null) {
                                break loop0;
                            }
                            i19++;
                            strT = str2;
                        }
                        str = strT;
                        if (fC + fC2 <= fH) {
                            arrayList3.addAll(0, arrayList4);
                            i13 = i17;
                        }
                        i14 = i18;
                        i10 = i15;
                        f10 = fC2;
                        i11++;
                        size = size;
                        strT = str;
                    } else {
                        int i20 = i10;
                        int iIntValue3 = i12 == 0 ? ((Number) arrayList.get(i12)).intValue() : ((Number) arrayList.get(i12)).intValue() - ((Number) arrayList.get(i12 - 1)).intValue();
                        ArrayList arrayList5 = new ArrayList();
                        int i21 = i14;
                        int i22 = i20;
                        for (int i23 = 0; i23 < iIntValue3; i23++) {
                            try {
                                arrayList5.add(Character.valueOf(strT.charAt(i22)));
                                Object obj9 = uVar.f23278a;
                                p097ha.k.c(obj9);
                                fC += ((B) obj9).b(i22).c();
                                i22++;
                                objA2 = wVar;
                            } catch (Throwable th3) {
                                objA2 = AbstractC0862l.A(th3);
                            }
                            if (T9.j.a(objA2) != null) {
                                break loop0;
                            }
                        }
                        if (fC + f10 <= fH) {
                            arrayList2.addAll(arrayList5);
                            i12++;
                        }
                        str = strT;
                        i10 = i22;
                        i14 = i21;
                        i11++;
                        size = size;
                        strT = str;
                    }
                }
                strT = AbstractC0492c.t(U9.n.I0(arrayList2, "", null, null, null, 62), str3, U9.n.I0(arrayList3, "", null, null, null, 62));
            }
            c0629u.m0(strT);
            objE = strT;
        }
        c0629u.u(false);
        int i24 = this.f398d & 2147483520;
        int i25 = this.f406v;
        int i26 = (i25 & 14) | 3072 | ((i25 << 3) & 896);
        int i27 = i25 << 9;
        f2.b((String) objE, null, this.f399e, this.f400f, null, null, this.f401q, null, this.f402r, 0, this.f403s, 1, 0, this.f404t, this.f405u, c0629u, i24, i26 | (458752 & i27) | (i27 & 3670016), 18434);
        return wVar;
    }
}
