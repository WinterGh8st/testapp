package A9;

import B0.B;
import B0.C0049f;
import E.x;
import G6.F0;
import O.L;
import O.Z;
import T9.w;
import android.content.res.Configuration;
import android.content.res.Resources;
import com.airbnb.mvrx.MavericksState;
import java.util.List;
import p199r0.InterfaceC1461o;
import p284z0.r;

/* JADX INFO: loaded from: classes2.dex */
public final class c extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f339a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Z f340b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ c(Z z3, int i10) {
        super(1);
        this.f339a = i10;
        this.f340b = z3;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        switch (this.f339a) {
            case 0:
                B b10 = (B) obj;
                p097ha.k.f(b10, "it");
                this.f340b.setValue(b10);
                return w.f11979a;
            case 1:
                List list = (List) obj;
                p097ha.k.f(list, "it");
                this.f340b.setValue(list);
                return w.f11979a;
            case 2:
                B b11 = (B) obj;
                p097ha.k.f(b11, "it");
                this.f340b.setValue(b11);
                return w.f11979a;
            case 3:
                ((p084ga.c) this.f340b.getValue()).invoke(new p038d0.c(((p038d0.c) obj).f21401a));
                return w.f11979a;
            case 4:
                B b12 = (B) obj;
                p097ha.k.f(b12, "it");
                this.f340b.setValue(b12);
                return w.f11979a;
            case 5:
                B b13 = (B) obj;
                p097ha.k.f(b13, "it");
                this.f340b.setValue(b13);
                return w.f11979a;
            case 6:
                p097ha.k.f((L) obj, "$this$DisposableEffect");
                return new x(this.f340b, 10);
            case 7:
                Configuration configuration = (Configuration) obj;
                p097ha.k.f(configuration, "it");
                this.f340b.setValue(new Configuration(configuration));
                return w.f11979a;
            case 8:
                MavericksState mavericksState = (MavericksState) obj;
                p097ha.k.f(mavericksState, "it");
                return ((p084ga.c) this.f340b.getValue()).invoke(mavericksState);
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                this.f340b.setValue(new N0.d(((int) (((N0.i) obj).f8983a & 4294967295L)) / Resources.getSystem().getDisplayMetrics().density));
                return w.f11979a;
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p284z0.j jVar = (p284z0.j) obj;
                p097ha.k.f(jVar, "$this$semantics");
                r.c(jVar, (String) this.f340b.getValue());
                p284z0.p.f33259v.a(jVar, r.f33265a[12], new C0049f(6, "", null));
                return w.f11979a;
            case 11:
                InterfaceC1461o interfaceC1461o = (InterfaceC1461o) obj;
                p097ha.k.f(interfaceC1461o, "it");
                this.f340b.setValue(new p038d0.c(p195q8.g.A(interfaceC1461o)));
                return w.f11979a;
            default:
                return (Float) ((p084ga.c) this.f340b.getValue()).invoke(Float.valueOf(((Number) obj).floatValue()));
        }
    }
}
