package A9;

import B0.B;
import T9.w;
import p199r0.K;

/* JADX INFO: loaded from: classes2.dex */
public final class b extends p097ha.l implements p084ga.c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f334b = new b(1, 0);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final b f335c = new b(1, 1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final b f336d = new b(1, 2);

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final b f337e = new b(1, 3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f338a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(int i10, int i11) {
        super(i10);
        this.f338a = i11;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        switch (this.f338a) {
            case 0:
                p097ha.k.f((B) obj, "it");
                break;
            case 1:
                p097ha.k.f((p284z0.j) obj, "$this$semantics");
                break;
            case 2:
                p097ha.k.f((B) obj, "it");
                break;
            default:
                p097ha.k.f((K) obj, "$this$layout");
                break;
        }
        return w.f11979a;
    }
}
