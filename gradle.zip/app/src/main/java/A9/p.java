package A9;

import B0.B;
import B0.D;
import U9.w;
import java.util.ArrayList;
import p097ha.u;
import p199r0.A;
import p199r0.L;
import p199r0.U;

/* JADX INFO: loaded from: classes2.dex */
public final class p extends p097ha.l implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ u f410a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f411b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ char f412c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ long f413d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ long f414e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ long f415f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ long f416q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ boolean f417r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final /* synthetic */ D f418s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final /* synthetic */ int f419t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final /* synthetic */ int f420u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final /* synthetic */ String f421v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final /* synthetic */ b f422w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final /* synthetic */ int f423x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final /* synthetic */ ArrayList f424y;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(u uVar, String str, char c10, long j10, long j11, long j12, long j13, boolean z3, D d10, int i10, int i11, String str2, b bVar, int i12, ArrayList arrayList) {
        super(2);
        this.f410a = uVar;
        this.f411b = str;
        this.f412c = c10;
        this.f413d = j10;
        this.f414e = j11;
        this.f415f = j12;
        this.f416q = j13;
        this.f417r = z3;
        this.f418s = d10;
        this.f419t = i10;
        this.f420u = i11;
        this.f421v = str2;
        this.f422w = bVar;
        this.f423x = i12;
        this.f424y = arrayList;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        U u5 = (U) obj;
        long j10 = ((N0.a) obj2).f8965a;
        p097ha.k.f(u5, "$this$SubcomposeLayout");
        String str = this.f411b;
        int i10 = this.f420u;
        u uVar = this.f410a;
        ((A) u5.X("MiddleEllipsisText_calculate", Ua.l.v(566593623, new m(str, this.f412c, this.f413d, this.f414e, this.f415f, this.f416q, this.f417r, this.f418s, this.f419t, i10, uVar), true)).get(0)).a(p054e4.e.e(0, 0, 15));
        B b10 = (B) uVar.f23278a;
        w wVar = w.f12752a;
        if (b10 == null) {
            return u5.t0(0, 0, wVar, b.f337e);
        }
        L lA = ((A) u5.X("MiddleEllipsisText_apply", Ua.l.v(-1570169603, new o(str, this.f421v, uVar, this.f419t, this.f413d, this.f414e, this.f415f, this.f416q, this.f417r, this.f422w, this.f418s, this.f420u, j10, this.f423x, this.f424y), true)).get(0)).a(j10);
        return u5.t0(lA.f27576a, lA.f27577b, wVar, new n(lA, 0));
    }
}
