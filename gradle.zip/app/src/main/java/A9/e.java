package A9;

import O.Z;
import T9.w;
import o0.J;
import p016b3.AbstractC0862l;
import p283z.T0;

/* JADX INFO: loaded from: classes2.dex */
public final class e extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f353a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f354b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Z f355c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ g f356d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public e(Z z3, g gVar, X9.d dVar) {
        super(2, dVar);
        this.f355c = z3;
        this.f356d = gVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        e eVar = new e(this.f355c, this.f356d, dVar);
        eVar.f354b = obj;
        return eVar;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((e) create((J) obj, (X9.d) obj2)).invokeSuspend(w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f353a;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            J j10 = (J) this.f354b;
            A8.p pVar = new A8.p(1, this.f355c, this.f356d);
            this.f353a = 1;
            if (T0.d(j10, null, pVar, this, 7) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        return w.f11979a;
    }
}
