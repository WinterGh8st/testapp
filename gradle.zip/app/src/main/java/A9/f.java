package A9;

import T9.w;

/* JADX INFO: loaded from: classes2.dex */
public final class f extends p097ha.l implements p084ga.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final f f357a = new f(0);

    @Override // p084ga.a
    public final /* bridge */ /* synthetic */ Object m() {
        return w.f11979a;
    }
}
