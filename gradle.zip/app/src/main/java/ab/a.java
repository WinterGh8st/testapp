package ab;

import Za.e;
import Za.m;
import Za.p;
import java.io.EOFException;
import p097ha.k;

/* JADX INFO: loaded from: classes2.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final byte[] f15208a;

    static {
        byte[] bytes = "0123456789abcdef".getBytes(p197qa.b.f27521a);
        k.e(bytes, "this as java.lang.String).getBytes(charset)");
        f15208a = bytes;
    }

    public static final String a(long j10, e eVar) throws EOFException {
        k.f(eVar, "<this>");
        if (j10 > 0) {
            long j11 = j10 - 1;
            if (eVar.g(j11) == 13) {
                String strQ = eVar.q(j11, p197qa.b.f27521a);
                eVar.t(2L);
                return strQ;
            }
        }
        String strQ2 = eVar.q(j10, p197qa.b.f27521a);
        eVar.t(1L);
        return strQ2;
    }

    /* JADX WARN: Code duplicated, block: B:48:0x00ab A[LOOP:0: B:8:0x0021->B:48:0x00ab, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:54:0x00aa A[SYNTHETIC] */
    public static final int b(e eVar, m mVar, boolean z3) {
        int i10;
        byte[] bArr;
        int i11;
        int i12;
        p pVar;
        byte[] bArr2;
        int i13;
        k.f(eVar, "<this>");
        k.f(mVar, "options");
        p pVar2 = eVar.f14810a;
        if (pVar2 == null) {
            return z3 ? -2 : -1;
        }
        int i14 = pVar2.f14836b;
        int i15 = pVar2.f14837c;
        byte[] bArr3 = pVar2.f14835a;
        p pVar3 = pVar2;
        int i16 = -1;
        int i17 = 0;
        loop0: while (true) {
            int i18 = i17 + 1;
            int[] iArr = mVar.f14828b;
            int i19 = iArr[i17];
            int i20 = i17 + 2;
            int i21 = iArr[i18];
            if (i21 != -1) {
                i16 = i21;
            }
            if (pVar3 == null) {
                break;
            }
            if (i19 >= 0) {
                int i22 = i14 + 1;
                int i23 = bArr3[i14] & 255;
                int i24 = i20 + i19;
                while (i20 != i24) {
                    if (i23 == iArr[i20]) {
                        i10 = iArr[i20 + i19];
                        if (i22 == i15) {
                            pVar3 = pVar3.f14840f;
                            k.c(pVar3);
                            i12 = pVar3.f14836b;
                            i11 = pVar3.f14837c;
                            bArr = pVar3.f14835a;
                            if (pVar3 == pVar2) {
                                pVar3 = null;
                            }
                        } else {
                            bArr = bArr3;
                            i11 = i15;
                            i12 = i22;
                        }
                        if (i10 >= 0) {
                            return i10;
                        }
                        byte[] bArr4 = bArr;
                        i17 = -i10;
                        i14 = i12;
                        i15 = i11;
                        bArr3 = bArr4;
                    } else {
                        i20++;
                    }
                }
                return i16;
            }
            int i25 = (i19 * (-1)) + i20;
            while (true) {
                int i26 = i14 + 1;
                int i27 = i20 + 1;
                if ((bArr3[i14] & 255) == iArr[i20]) {
                    boolean z5 = i27 == i25;
                    if (i26 == i15) {
                        k.c(pVar3);
                        p pVar4 = pVar3.f14840f;
                        k.c(pVar4);
                        i13 = pVar4.f14836b;
                        int i28 = pVar4.f14837c;
                        bArr2 = pVar4.f14835a;
                        if (pVar4 != pVar2) {
                            pVar = pVar4;
                            i15 = i28;
                        } else {
                            if (!z5) {
                                break loop0;
                            }
                            i15 = i28;
                            pVar = null;
                        }
                    } else {
                        pVar = pVar3;
                        bArr2 = bArr3;
                        i13 = i26;
                    }
                    if (z5) {
                        i10 = iArr[i27];
                        int i29 = i13;
                        i11 = i15;
                        i12 = i29;
                        byte[] bArr5 = bArr2;
                        pVar3 = pVar;
                        bArr = bArr5;
                        break;
                    }
                    i14 = i13;
                    bArr3 = bArr2;
                    pVar3 = pVar;
                    i20 = i27;
                }
                return i16;
            }
            if (i10 >= 0) {
                return i10;
            }
            byte[] bArr6 = bArr;
            i17 = -i10;
            i14 = i12;
            i15 = i11;
            bArr3 = bArr6;
        }
        if (z3) {
            return -2;
        }
        return i16;
    }
}
