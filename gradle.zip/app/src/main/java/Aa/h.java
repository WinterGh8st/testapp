package Aa;

import p230ta.Y;

/* JADX INFO: loaded from: classes2.dex */
public abstract class h extends Y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public c f466c;

    @Override // p230ta.AbstractC1659y
    public final void t(X9.i iVar, Runnable runnable) {
        c.d(this.f466c, runnable, 6);
    }

    @Override // p230ta.AbstractC1659y
    public final void u(X9.i iVar, Runnable runnable) {
        c.d(this.f466c, runnable, 2);
    }
}
