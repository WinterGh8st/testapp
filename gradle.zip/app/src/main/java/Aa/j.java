package Aa;

import android.content.Context;
import java.util.Locale;
import p260x.AbstractC1883o;
import p260x.k0;

/* JADX INFO: loaded from: classes2.dex */
public final class j implements p054e4.b, k0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f469a;

    public j() {
        this.f469a = 3;
    }

    public void a(int i10) {
        if (i10 != 0) {
            if (i10 == 0) {
                i10 = 0;
            } else if (i10 != 2 && i10 != 1 && i10 != 23 && i10 != 3) {
                Locale locale = Locale.US;
                throw new IllegalArgumentException(p096h9.i.i(i10, "Invalid environment value "));
            }
        }
        this.f469a = i10;
    }

    @Override // p260x.j0
    public AbstractC1883o e(long j10, AbstractC1883o abstractC1883o, AbstractC1883o abstractC1883o2, AbstractC1883o abstractC1883o3) {
        p097ha.k.f(abstractC1883o, "initialValue");
        p097ha.k.f(abstractC1883o2, "targetValue");
        p097ha.k.f(abstractC1883o3, "initialVelocity");
        return abstractC1883o3;
    }

    @Override // p054e4.b
    public int f(Context context, String str) {
        return this.f469a;
    }

    @Override // p054e4.b
    public int g(Context context, String str, boolean z3) {
        return 0;
    }

    @Override // p260x.k0
    public int j() {
        return this.f469a;
    }

    @Override // p260x.j0
    public AbstractC1883o k(long j10, AbstractC1883o abstractC1883o, AbstractC1883o abstractC1883o2, AbstractC1883o abstractC1883o3) {
        p097ha.k.f(abstractC1883o, "initialValue");
        p097ha.k.f(abstractC1883o2, "targetValue");
        p097ha.k.f(abstractC1883o3, "initialVelocity");
        return j10 < ((long) this.f469a) * 1000000 ? abstractC1883o : abstractC1883o2;
    }

    @Override // p260x.k0
    public int m() {
        return 0;
    }

    public j(int i10, int i11) {
        Ua.d.D((i10 & 1) == i10, "Generator ID %d contains more than %d reserved bits", Integer.valueOf(i10), 1);
        Ua.d.D((i11 & 1) == i10, "Cannot supply target ID from different generator ID", new Object[0]);
        this.f469a = i11;
    }
}
