package Aa;

import F9.C0242d;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import p097ha.u;

/* JADX INFO: loaded from: classes2.dex */
public final class a extends Thread {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f436s = AtomicIntegerFieldUpdater.newUpdater(a.class, "workerCtl$volatile");

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final n f437a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final u f438b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public b f439c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f440d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f441e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f442f;
    private volatile int indexInArray;
    private volatile Object nextParkedWorker;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f443q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final /* synthetic */ c f444r;
    private volatile /* synthetic */ int workerCtl$volatile;

    public a(c cVar, int i10) {
        this.f444r = cVar;
        setDaemon(true);
        setContextClassLoader(cVar.getClass().getClassLoader());
        this.f437a = new n();
        this.f438b = new u();
        this.f439c = b.f448d;
        this.nextParkedWorker = c.f454u;
        int iNanoTime = (int) System.nanoTime();
        this.f442f = iNanoTime == 0 ? 42 : iNanoTime;
        f(i10);
    }

    public final i a(boolean z3) {
        i iVarE;
        i iVarE2;
        c cVar;
        long j10;
        b bVar = this.f439c;
        b bVar2 = b.f445a;
        i iVar = null;
        n nVar = this.f437a;
        c cVar2 = this.f444r;
        if (bVar != bVar2) {
            AtomicLongFieldUpdater atomicLongFieldUpdater = c.f452s;
            do {
                cVar = this.f444r;
                j10 = atomicLongFieldUpdater.get(cVar);
                if (((int) ((9223367638808264704L & j10) >> 42)) == 0) {
                    nVar.getClass();
                    loop1: while (true) {
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = n.f480b;
                        i iVar2 = (i) atomicReferenceFieldUpdater.get(nVar);
                        if (iVar2 == null || iVar2.f468b.f469a != 1) {
                            int i10 = n.f482d.get(nVar);
                            int i11 = n.f481c.get(nVar);
                            while (i10 != i11 && n.f483e.get(nVar) != 0) {
                                i11--;
                                i iVarC = nVar.c(i11, true);
                                if (iVarC != null) {
                                    iVar = iVarC;
                                    break;
                                }
                            }
                            break;
                        }
                        do {
                            if (atomicReferenceFieldUpdater.compareAndSet(nVar, iVar2, null)) {
                                iVar = iVar2;
                                break loop1;
                            }
                        } while (atomicReferenceFieldUpdater.get(nVar) == iVar2);
                    }
                    if (iVar != null) {
                        return iVar;
                    }
                    i iVar3 = (i) cVar2.f460f.d();
                    return iVar3 == null ? i(1) : iVar3;
                }
            } while (!c.f452s.compareAndSet(cVar, j10, j10 - 4398046511104L));
            this.f439c = b.f445a;
        }
        if (z3) {
            boolean z5 = d(cVar2.f455a * 2) == 0;
            if (z5 && (iVarE2 = e()) != null) {
                return iVarE2;
            }
            nVar.getClass();
            i iVarB = (i) n.f480b.getAndSet(nVar, null);
            if (iVarB == null) {
                iVarB = nVar.b();
            }
            if (iVarB != null) {
                return iVarB;
            }
            if (!z5 && (iVarE = e()) != null) {
                return iVarE;
            }
        } else {
            i iVarE3 = e();
            if (iVarE3 != null) {
                return iVarE3;
            }
        }
        return i(3);
    }

    public final int b() {
        return this.indexInArray;
    }

    public final Object c() {
        return this.nextParkedWorker;
    }

    public final int d(int i10) {
        int i11 = this.f442f;
        int i12 = i11 ^ (i11 << 13);
        int i13 = i12 ^ (i12 >> 17);
        int i14 = i13 ^ (i13 << 5);
        this.f442f = i14;
        int i15 = i10 - 1;
        return (i15 & i10) == 0 ? i14 & i15 : (i14 & com.google.android.gms.common.api.f.API_PRIORITY_OTHER) % i10;
    }

    public final i e() {
        int iD = d(2);
        c cVar = this.f444r;
        if (iD == 0) {
            i iVar = (i) cVar.f459e.d();
            return iVar != null ? iVar : (i) cVar.f460f.d();
        }
        i iVar2 = (i) cVar.f460f.d();
        return iVar2 != null ? iVar2 : (i) cVar.f459e.d();
    }

    public final void f(int i10) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(this.f444r.f458d);
        sb2.append("-worker-");
        sb2.append(i10 == 0 ? "TERMINATED" : String.valueOf(i10));
        setName(sb2.toString());
        this.indexInArray = i10;
    }

    public final void g(Object obj) {
        this.nextParkedWorker = obj;
    }

    public final boolean h(b bVar) {
        b bVar2 = this.f439c;
        boolean z3 = bVar2 == b.f445a;
        if (z3) {
            c.f452s.addAndGet(this.f444r, 4398046511104L);
        }
        if (bVar2 != bVar) {
            this.f439c = bVar;
        }
        return z3;
    }

    public final i i(int i10) {
        int i11;
        long j10;
        i iVarC;
        long j11;
        long j12;
        AtomicLongFieldUpdater atomicLongFieldUpdater = c.f452s;
        c cVar = this.f444r;
        int i12 = (int) (atomicLongFieldUpdater.get(cVar) & 2097151);
        i iVar = null;
        if (i12 < 2) {
            return null;
        }
        int iD = d(i12);
        int i13 = 0;
        long jMin = Long.MAX_VALUE;
        while (i13 < i12) {
            int i14 = iD + 1;
            if (i14 > i12) {
                i14 = 1;
            }
            a aVar = (a) cVar.f461q.b(i14);
            if (aVar == null || aVar == this) {
                i11 = i14;
            } else {
                n nVar = aVar.f437a;
                if (i10 != 3) {
                    nVar.getClass();
                    int i15 = n.f482d.get(nVar);
                    int i16 = n.f481c.get(nVar);
                    boolean z3 = i10 == 1;
                    while (true) {
                        if (i15 != i16) {
                            j10 = 0;
                            if (!z3 || n.f483e.get(nVar) != 0) {
                                int i17 = i15 + 1;
                                iVarC = nVar.c(i15, z3);
                                if (iVarC != null) {
                                    break;
                                }
                                i15 = i17;
                            }
                        } else {
                            j10 = 0;
                        }
                        iVarC = iVar;
                        break;
                    }
                } else {
                    iVarC = nVar.b();
                    j10 = 0;
                }
                u uVar = this.f438b;
                if (iVarC == null) {
                    while (true) {
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = n.f480b;
                        i iVar2 = (i) atomicReferenceFieldUpdater.get(nVar);
                        if (iVar2 == null) {
                            j11 = -1;
                        } else {
                            j11 = -1;
                            if (((iVar2.f468b.f469a == 1 ? 1 : 2) & i10) != 0) {
                                l.f476f.getClass();
                                i11 = i14;
                                long jNanoTime = System.nanoTime() - iVar2.f467a;
                                long j13 = l.f472b;
                                if (jNanoTime < j13) {
                                    j12 = j13 - jNanoTime;
                                    iVar = null;
                                    break;
                                }
                                do {
                                    iVar = null;
                                    if (atomicReferenceFieldUpdater.compareAndSet(nVar, iVar2, null)) {
                                        uVar.f23278a = iVar2;
                                        j12 = -1;
                                        break;
                                    }
                                } while (atomicReferenceFieldUpdater.get(nVar) == iVar2);
                                i14 = i11;
                                iVar = null;
                            }
                        }
                        j12 = -2;
                        i11 = i14;
                        break;
                    }
                } else {
                    uVar.f23278a = iVarC;
                    i11 = i14;
                    j12 = -1;
                    j11 = -1;
                }
                if (j12 == j11) {
                    i iVar3 = (i) uVar.f23278a;
                    uVar.f23278a = iVar;
                    return iVar3;
                }
                if (j12 > j10) {
                    jMin = Math.min(jMin, j12);
                }
            }
            i13++;
            iD = i11;
            iVar = null;
        }
        if (jMin == Long.MAX_VALUE) {
            jMin = 0;
        }
        this.f441e = jMin;
        return null;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public final void run() {
        AtomicLongFieldUpdater atomicLongFieldUpdater;
        long j10;
        int i10;
        loop0: while (true) {
            boolean z3 = false;
            while (true) {
                c cVar = this.f444r;
                cVar.getClass();
                if (c.f453t.get(cVar) == 0) {
                    b bVar = this.f439c;
                    b bVar2 = b.f449e;
                    if (bVar == bVar2) {
                        break loop0;
                    }
                    i iVarA = a(this.f443q);
                    if (iVarA == null) {
                        this.f443q = false;
                        if (this.f441e == 0) {
                            Object obj = this.nextParkedWorker;
                            C0242d c0242d = c.f454u;
                            long j11 = 2097151;
                            if (obj != c0242d) {
                                f436s.set(this, -1);
                                while (this.nextParkedWorker != c.f454u) {
                                    AtomicIntegerFieldUpdater atomicIntegerFieldUpdater = f436s;
                                    if (atomicIntegerFieldUpdater.get(this) != -1) {
                                        break;
                                    }
                                    c cVar2 = this.f444r;
                                    cVar2.getClass();
                                    AtomicIntegerFieldUpdater atomicIntegerFieldUpdater2 = c.f453t;
                                    if (atomicIntegerFieldUpdater2.get(cVar2) != 0) {
                                        break;
                                    }
                                    b bVar3 = this.f439c;
                                    b bVar4 = b.f449e;
                                    if (bVar3 == bVar4) {
                                        break;
                                    }
                                    h(b.f447c);
                                    Thread.interrupted();
                                    if (this.f440d == 0) {
                                        this.f440d = System.nanoTime() + this.f444r.f457c;
                                    }
                                    LockSupport.parkNanos(this.f444r.f457c);
                                    if (System.nanoTime() - this.f440d >= 0) {
                                        this.f440d = 0L;
                                        c cVar3 = this.f444r;
                                        synchronized (cVar3.f461q) {
                                            try {
                                                if (!(atomicIntegerFieldUpdater2.get(cVar3) != 0)) {
                                                    AtomicLongFieldUpdater atomicLongFieldUpdater2 = c.f452s;
                                                    if (((int) (atomicLongFieldUpdater2.get(cVar3) & j11)) > cVar3.f455a) {
                                                        if (atomicIntegerFieldUpdater.compareAndSet(this, -1, 1)) {
                                                            int i11 = this.indexInArray;
                                                            f(0);
                                                            cVar3.e(this, i11, 0);
                                                            int andDecrement = (int) (atomicLongFieldUpdater2.getAndDecrement(cVar3) & j11);
                                                            if (andDecrement != i11) {
                                                                Object objB = cVar3.f461q.b(andDecrement);
                                                                p097ha.k.c(objB);
                                                                a aVar = (a) objB;
                                                                cVar3.f461q.c(i11, aVar);
                                                                aVar.f(i11);
                                                                cVar3.e(aVar, andDecrement, i11);
                                                            }
                                                            cVar3.f461q.c(andDecrement, null);
                                                            this.f439c = bVar4;
                                                        }
                                                    }
                                                }
                                            } catch (Throwable th) {
                                                throw th;
                                            }
                                        }
                                    }
                                    j11 = j11;
                                }
                            } else {
                                c cVar4 = this.f444r;
                                cVar4.getClass();
                                if (this.nextParkedWorker == c0242d) {
                                    do {
                                        atomicLongFieldUpdater = c.f451r;
                                        j10 = atomicLongFieldUpdater.get(cVar4);
                                        i10 = this.indexInArray;
                                        this.nextParkedWorker = cVar4.f461q.b((int) (j10 & 2097151));
                                    } while (!atomicLongFieldUpdater.compareAndSet(cVar4, j10, ((2097152 + j10) & (-2097152)) | ((long) i10)));
                                }
                            }
                        } else {
                            if (z3) {
                                h(b.f447c);
                                Thread.interrupted();
                                LockSupport.parkNanos(this.f441e);
                                this.f441e = 0L;
                                break;
                            }
                            z3 = true;
                        }
                    } else {
                        this.f441e = 0L;
                        int i12 = iVarA.f468b.f469a;
                        this.f440d = 0L;
                        if (this.f439c == b.f447c) {
                            this.f439c = b.f446b;
                        }
                        c cVar5 = this.f444r;
                        if (i12 != 0 && h(b.f446b) && !cVar5.h() && !cVar5.g(c.f452s.get(cVar5))) {
                            cVar5.h();
                        }
                        cVar5.getClass();
                        try {
                            iVarA.run();
                        } catch (Throwable th2) {
                            Thread threadCurrentThread = Thread.currentThread();
                            threadCurrentThread.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread, th2);
                        }
                        if (i12 != 0) {
                            c.f452s.addAndGet(cVar5, -2097152L);
                            if (this.f439c == bVar2) {
                                break;
                            }
                            this.f439c = b.f448d;
                            break;
                        }
                        break;
                    }
                } else {
                    break loop0;
                }
            }
        }
        h(b.f449e);
    }
}
