package Aa;

import F9.C0242d;
import L.AbstractC0492c;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import p032c7.AbstractC0933i;
import p230ta.E;
import p282ya.q;

/* JADX INFO: loaded from: classes2.dex */
public final class c implements Executor, Closeable, AutoCloseable {

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f451r = AtomicLongFieldUpdater.newUpdater(c.class, "parkedWorkersStack$volatile");

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final /* synthetic */ AtomicLongFieldUpdater f452s = AtomicLongFieldUpdater.newUpdater(c.class, "controlState$volatile");

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static final /* synthetic */ AtomicIntegerFieldUpdater f453t = AtomicIntegerFieldUpdater.newUpdater(c.class, "_isTerminated$volatile");

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public static final C0242d f454u = new C0242d("NOT_IN_STACK", 4);
    private volatile /* synthetic */ int _isTerminated$volatile;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f455a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f456b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f457c;
    private volatile /* synthetic */ long controlState$volatile;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f458d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f f459e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final f f460f;
    private volatile /* synthetic */ long parkedWorkersStack$volatile;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final q f461q;

    public c(int i10, int i11, long j10, String str) {
        this.f455a = i10;
        this.f456b = i11;
        this.f457c = j10;
        this.f458d = str;
        if (i10 < 1) {
            throw new IllegalArgumentException(AbstractC0492c.h(i10, "Core pool size ", " should be at least 1").toString());
        }
        if (i11 < i10) {
            throw new IllegalArgumentException(p015b2.a.d("Max pool size ", i11, i10, " should be greater than or equals to core pool size ").toString());
        }
        if (i11 > 2097150) {
            throw new IllegalArgumentException(AbstractC0492c.h(i11, "Max pool size ", " should not exceed maximal supported number of threads 2097150").toString());
        }
        if (j10 <= 0) {
            throw new IllegalArgumentException(("Idle worker keep alive time " + j10 + " must be positive").toString());
        }
        this.f459e = new f();
        this.f460f = new f();
        this.f461q = new q((i10 + 1) * 2);
        this.controlState$volatile = ((long) i10) << 42;
        this._isTerminated$volatile = 0;
    }

    public static /* synthetic */ void d(c cVar, Runnable runnable, int i10) {
        cVar.c(runnable, l.f477g, (i10 & 4) == 0);
    }

    public final int b() {
        synchronized (this.f461q) {
            try {
                if (f453t.get(this) != 0) {
                    return -1;
                }
                AtomicLongFieldUpdater atomicLongFieldUpdater = f452s;
                long j10 = atomicLongFieldUpdater.get(this);
                int i10 = (int) (j10 & 2097151);
                int i11 = i10 - ((int) ((j10 & 4398044413952L) >> 21));
                if (i11 < 0) {
                    i11 = 0;
                }
                if (i11 >= this.f455a) {
                    return 0;
                }
                if (i10 >= this.f456b) {
                    return 0;
                }
                int i12 = ((int) (atomicLongFieldUpdater.get(this) & 2097151)) + 1;
                if (i12 <= 0 || this.f461q.b(i12) != null) {
                    throw new IllegalArgumentException("Failed requirement.");
                }
                a aVar = new a(this, i12);
                this.f461q.c(i12, aVar);
                if (i12 != ((int) (2097151 & atomicLongFieldUpdater.incrementAndGet(this)))) {
                    throw new IllegalArgumentException("Failed requirement.");
                }
                int i13 = i11 + 1;
                aVar.start();
                return i13;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void c(Runnable runnable, j jVar, boolean z3) {
        i kVar;
        b bVar;
        l.f476f.getClass();
        long jNanoTime = System.nanoTime();
        if (runnable instanceof i) {
            kVar = (i) runnable;
            kVar.f467a = jNanoTime;
            kVar.f468b = jVar;
        } else {
            kVar = new k(runnable, jNanoTime, jVar);
        }
        boolean z5 = false;
        boolean z10 = kVar.f468b.f469a == 1;
        AtomicLongFieldUpdater atomicLongFieldUpdater = f452s;
        long jAddAndGet = z10 ? atomicLongFieldUpdater.addAndGet(this, 2097152L) : 0L;
        Thread threadCurrentThread = Thread.currentThread();
        a aVar = threadCurrentThread instanceof a ? (a) threadCurrentThread : null;
        if (aVar == null || !p097ha.k.b(aVar.f444r, this)) {
            aVar = null;
        }
        if (aVar != null && (bVar = aVar.f439c) != b.f449e && (kVar.f468b.f469a != 0 || bVar != b.f446b)) {
            aVar.f443q = true;
            n nVar = aVar.f437a;
            if (z3) {
                kVar = nVar.a(kVar);
            } else {
                nVar.getClass();
                i iVar = (i) n.f480b.getAndSet(nVar, kVar);
                kVar = iVar == null ? null : nVar.a(iVar);
            }
        }
        if (kVar != null) {
            if (!(kVar.f468b.f469a == 1 ? this.f460f.a(kVar) : this.f459e.a(kVar))) {
                throw new RejectedExecutionException(AbstractC0933i.i(new StringBuilder(), this.f458d, " was terminated"));
            }
        }
        if (z3 && aVar != null) {
            z5 = true;
        }
        if (z10) {
            if (z5 || h() || g(jAddAndGet)) {
                return;
            }
            h();
            return;
        }
        if (z5 || h() || g(atomicLongFieldUpdater.get(this))) {
            return;
        }
        h();
    }

    /* JADX WARN: Code duplicated, block: B:39:0x008a  */
    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() throws InterruptedException {
        int i10;
        i iVarA;
        if (f453t.compareAndSet(this, 0, 1)) {
            Thread threadCurrentThread = Thread.currentThread();
            a aVar = threadCurrentThread instanceof a ? (a) threadCurrentThread : null;
            if (aVar == null || !p097ha.k.b(aVar.f444r, this)) {
                aVar = null;
            }
            synchronized (this.f461q) {
                i10 = (int) (f452s.get(this) & 2097151);
            }
            if (1 <= i10) {
                int i11 = 1;
                while (true) {
                    Object objB = this.f461q.b(i11);
                    p097ha.k.c(objB);
                    a aVar2 = (a) objB;
                    if (aVar2 != aVar) {
                        while (aVar2.getState() != Thread.State.TERMINATED) {
                            LockSupport.unpark(aVar2);
                            aVar2.join(10000L);
                        }
                        n nVar = aVar2.f437a;
                        f fVar = this.f460f;
                        nVar.getClass();
                        i iVar = (i) n.f480b.getAndSet(nVar, null);
                        if (iVar != null) {
                            fVar.a(iVar);
                        }
                        while (true) {
                            i iVarB = nVar.b();
                            if (iVarB == null) {
                                break;
                            } else {
                                fVar.a(iVarB);
                            }
                        }
                    }
                    if (i11 == i10) {
                        break;
                    } else {
                        i11++;
                    }
                }
            }
            this.f460f.b();
            this.f459e.b();
            while (true) {
                if (aVar != null) {
                    iVarA = aVar.a(true);
                    if (iVarA == null) {
                        iVarA = (i) this.f459e.d();
                        if (iVarA == null) {
                            break;
                            break;
                        }
                    }
                } else {
                    iVarA = (i) this.f459e.d();
                    if (iVarA == null && (iVarA = (i) this.f460f.d()) == null) {
                        break;
                    }
                }
                try {
                    iVarA.run();
                } catch (Throwable th) {
                    Thread threadCurrentThread2 = Thread.currentThread();
                    threadCurrentThread2.getUncaughtExceptionHandler().uncaughtException(threadCurrentThread2, th);
                }
            }
            if (aVar != null) {
                aVar.h(b.f449e);
            }
            f451r.set(this, 0L);
            f452s.set(this, 0L);
        }
    }

    public final void e(a aVar, int i10, int i11) {
        while (true) {
            long j10 = f451r.get(this);
            int i12 = (int) (2097151 & j10);
            long j11 = (2097152 + j10) & (-2097152);
            if (i12 == i10) {
                if (i11 == 0) {
                    Object objC = aVar.c();
                    while (true) {
                        if (objC == f454u) {
                            i12 = -1;
                            break;
                        }
                        if (objC == null) {
                            i12 = 0;
                            break;
                        }
                        a aVar2 = (a) objC;
                        int iB = aVar2.b();
                        if (iB != 0) {
                            i12 = iB;
                            break;
                        }
                        objC = aVar2.c();
                    }
                } else {
                    i12 = i11;
                }
            }
            if (i12 >= 0) {
                if (f451r.compareAndSet(this, j10, ((long) i12) | j11)) {
                    return;
                }
            }
        }
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        d(this, runnable, 6);
    }

    public final boolean g(long j10) {
        int i10 = ((int) (2097151 & j10)) - ((int) ((j10 & 4398044413952L) >> 21));
        if (i10 < 0) {
            i10 = 0;
        }
        int i11 = this.f455a;
        if (i10 < i11) {
            int iB = b();
            if (iB == 1 && i11 > 1) {
                b();
            }
            if (iB > 0) {
                return true;
            }
        }
        return false;
    }

    public final boolean h() {
        C0242d c0242d;
        int iB;
        while (true) {
            AtomicLongFieldUpdater atomicLongFieldUpdater = f451r;
            long j10 = atomicLongFieldUpdater.get(this);
            a aVar = (a) this.f461q.b((int) (2097151 & j10));
            if (aVar == null) {
                aVar = null;
            } else {
                long j11 = (2097152 + j10) & (-2097152);
                Object objC = aVar.c();
                while (true) {
                    c0242d = f454u;
                    if (objC == c0242d) {
                        iB = -1;
                        break;
                    }
                    if (objC == null) {
                        iB = 0;
                        break;
                    }
                    a aVar2 = (a) objC;
                    iB = aVar2.b();
                    if (iB != 0) {
                        break;
                    }
                    objC = aVar2.c();
                }
                if (iB >= 0 && atomicLongFieldUpdater.compareAndSet(this, j10, j11 | ((long) iB))) {
                    aVar.g(c0242d);
                }
            }
            if (aVar == null) {
                return false;
            }
            if (a.f436s.compareAndSet(aVar, -1, 0)) {
                LockSupport.unpark(aVar);
                return true;
            }
        }
    }

    public final String toString() {
        ArrayList arrayList = new ArrayList();
        q qVar = this.f461q;
        int iA = qVar.a();
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        for (int i15 = 1; i15 < iA; i15++) {
            a aVar = (a) qVar.b(i15);
            if (aVar != null) {
                n nVar = aVar.f437a;
                nVar.getClass();
                int i16 = n.f480b.get(nVar) != null ? (n.f481c.get(nVar) - n.f482d.get(nVar)) + 1 : n.f481c.get(nVar) - n.f482d.get(nVar);
                int iOrdinal = aVar.f439c.ordinal();
                if (iOrdinal == 0) {
                    i10++;
                    StringBuilder sb2 = new StringBuilder();
                    sb2.append(i16);
                    sb2.append('c');
                    arrayList.add(sb2.toString());
                } else if (iOrdinal == 1) {
                    i11++;
                    StringBuilder sb3 = new StringBuilder();
                    sb3.append(i16);
                    sb3.append('b');
                    arrayList.add(sb3.toString());
                } else if (iOrdinal == 2) {
                    i12++;
                } else if (iOrdinal == 3) {
                    i13++;
                    if (i16 > 0) {
                        StringBuilder sb4 = new StringBuilder();
                        sb4.append(i16);
                        sb4.append('d');
                        arrayList.add(sb4.toString());
                    }
                } else if (iOrdinal == 4) {
                    i14++;
                }
            }
        }
        long j10 = f452s.get(this);
        StringBuilder sb5 = new StringBuilder();
        sb5.append(this.f458d);
        sb5.append('@');
        sb5.append(E.l(this));
        sb5.append("[Pool Size {core = ");
        int i17 = this.f455a;
        sb5.append(i17);
        sb5.append(", max = ");
        sb5.append(this.f456b);
        sb5.append("}, Worker States {CPU = ");
        sb5.append(i10);
        sb5.append(", blocking = ");
        sb5.append(i11);
        sb5.append(", parked = ");
        sb5.append(i12);
        sb5.append(", dormant = ");
        sb5.append(i13);
        sb5.append(", terminated = ");
        sb5.append(i14);
        sb5.append("}, running workers queues = ");
        sb5.append(arrayList);
        sb5.append(", global CPU queue size = ");
        sb5.append(this.f459e.c());
        sb5.append(", global blocking queue size = ");
        sb5.append(this.f460f.c());
        sb5.append(", Control State {created workers= ");
        sb5.append((int) (2097151 & j10));
        sb5.append(", blocking tasks = ");
        sb5.append((int) ((4398044413952L & j10) >> 21));
        sb5.append(", CPUs acquired = ");
        sb5.append(i17 - ((int) ((j10 & 9223367638808264704L) >> 42)));
        sb5.append("}]");
        return sb5.toString();
    }
}
