package Aa;

import p230ta.AbstractC1659y;

/* JADX INFO: loaded from: classes2.dex */
public final class m extends AbstractC1659y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final m f479c = new m();

    @Override // p230ta.AbstractC1659y
    public final void t(X9.i iVar, Runnable runnable) {
        e eVar = e.f464d;
        eVar.f466c.c(runnable, l.f478h, false);
    }

    @Override // p230ta.AbstractC1659y
    public final void u(X9.i iVar, Runnable runnable) {
        e eVar = e.f464d;
        eVar.f466c.c(runnable, l.f478h, true);
    }
}
