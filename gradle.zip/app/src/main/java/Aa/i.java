package Aa;

/* JADX INFO: loaded from: classes2.dex */
public abstract class i implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public long f467a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public j f468b;

    public i(long j10, j jVar) {
        this.f467a = j10;
        this.f468b = jVar;
    }
}
