package Aa;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: loaded from: classes2.dex */
public final class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final b f445a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final b f446b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final b f447c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final b f448d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final b f449e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ b[] f450f;

    static {
        b bVar = new b("CPU_ACQUIRED", 0);
        f445a = bVar;
        b bVar2 = new b("BLOCKING", 1);
        f446b = bVar2;
        b bVar3 = new b("PARKING", 2);
        f447c = bVar3;
        b bVar4 = new b("DORMANT", 3);
        f448d = bVar4;
        b bVar5 = new b("TERMINATED", 4);
        f449e = bVar5;
        b[] bVarArr = {bVar, bVar2, bVar3, bVar4, bVar5};
        f450f = bVarArr;
        p054e4.e.Y(bVarArr);
    }

    public static b valueOf(String str) {
        return (b) Enum.valueOf(b.class, str);
    }

    public static b[] values() {
        return (b[]) f450f.clone();
    }
}
