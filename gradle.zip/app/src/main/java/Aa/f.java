package Aa;

/* JADX INFO: loaded from: classes2.dex */
public final class f extends p282ya.k {
}
