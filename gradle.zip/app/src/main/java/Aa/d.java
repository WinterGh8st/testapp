package Aa;

import java.util.concurrent.Executor;
import p230ta.AbstractC1659y;
import p230ta.Y;
import p282ya.u;

/* JADX INFO: loaded from: classes2.dex */
public final class d extends Y implements Executor {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final d f462c = new d();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final AbstractC1659y f463d;

    static {
        AbstractC1659y iVar;
        m mVar = m.f479c;
        int i10 = u.f32799a;
        if (64 >= i10) {
            i10 = 64;
        }
        int iJ = p282ya.a.j(i10, 12, "kotlinx.coroutines.io.parallelism");
        mVar.getClass();
        if (iJ < 1) {
            throw new IllegalArgumentException(p096h9.i.i(iJ, "Expected positive parallelism level, but got ").toString());
        }
        if (iJ < l.f474d) {
            if (iJ < 1) {
                throw new IllegalArgumentException(p096h9.i.i(iJ, "Expected positive parallelism level, but got ").toString());
            }
            iVar = new p282ya.i(mVar, iJ);
        }
        iVar = mVar;
        f463d = iVar;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        throw new IllegalStateException("Cannot be invoked on Dispatchers.IO");
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        t(X9.j.f13659a, runnable);
    }

    @Override // p230ta.AbstractC1659y
    public final void t(X9.i iVar, Runnable runnable) {
        f463d.t(iVar, runnable);
    }

    @Override // p230ta.AbstractC1659y
    public final String toString() {
        return "Dispatchers.IO";
    }

    @Override // p230ta.AbstractC1659y
    public final void u(X9.i iVar, Runnable runnable) {
        f463d.u(iVar, runnable);
    }
}
