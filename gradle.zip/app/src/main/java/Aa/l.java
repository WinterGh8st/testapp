package Aa;

import java.util.concurrent.TimeUnit;
import p282ya.u;

/* JADX INFO: loaded from: classes2.dex */
public abstract class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final String f471a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final long f472b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int f473c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int f474d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final long f475e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final g f476f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static final j f477g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final j f478h;

    static {
        String property;
        int i10 = u.f32799a;
        try {
            property = System.getProperty("kotlinx.coroutines.scheduler.default.name");
        } catch (SecurityException unused) {
            property = null;
        }
        if (property == null) {
            property = "DefaultDispatcher";
        }
        f471a = property;
        f472b = p282ya.a.i("kotlinx.coroutines.scheduler.resolution.ns", 100000L, 1L, Long.MAX_VALUE);
        int i11 = u.f32799a;
        if (i11 < 2) {
            i11 = 2;
        }
        f473c = p282ya.a.j(i11, 8, "kotlinx.coroutines.scheduler.core.pool.size");
        f474d = p282ya.a.j(2097150, 4, "kotlinx.coroutines.scheduler.max.pool.size");
        f475e = TimeUnit.SECONDS.toNanos(p282ya.a.i("kotlinx.coroutines.scheduler.keep.alive.sec", 60L, 1L, Long.MAX_VALUE));
        f476f = g.f465a;
        f477g = new j(0);
        f478h = new j(1);
    }
}
