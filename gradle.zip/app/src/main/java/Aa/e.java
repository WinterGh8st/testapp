package Aa;

/* JADX INFO: loaded from: classes2.dex */
public final class e extends h {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final e f464d;

    static {
        int i10 = l.f473c;
        int i11 = l.f474d;
        long j10 = l.f475e;
        String str = l.f471a;
        e eVar = new e();
        eVar.f466c = new c(i10, i11, j10, str);
        f464d = eVar;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        throw new UnsupportedOperationException("Dispatchers.Default cannot be closed");
    }

    @Override // p230ta.AbstractC1659y
    public final String toString() {
        return "Dispatchers.Default";
    }
}
