package Aa;

import p230ta.E;

/* JADX INFO: loaded from: classes2.dex */
public final class k extends i {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Runnable f470c;

    public k(Runnable runnable, long j10, j jVar) {
        super(j10, jVar);
        this.f470c = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            this.f470c.run();
        } finally {
            this.f468b.getClass();
        }
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Task[");
        Runnable runnable = this.f470c;
        sb2.append(runnable.getClass().getSimpleName());
        sb2.append('@');
        sb2.append(E.l(runnable));
        sb2.append(", ");
        sb2.append(this.f467a);
        sb2.append(", ");
        sb2.append(this.f468b);
        sb2.append(']');
        return sb2.toString();
    }
}
