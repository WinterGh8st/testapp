package a4;

import F2.C0215f;
import T3.i;
import T3.j;
import android.app.AppOpsManager;
import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Process;
import android.os.StrictMode;
import android.util.Log;
import com.google.android.gms.common.internal.L;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final char[] f15075a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final char[] f15076b = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static Boolean f15077c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static Boolean f15078d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static Boolean f15079e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static Boolean f15080f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public static String f15081g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static int f15082h;

    public static String a(byte[] bArr) {
        int length = bArr.length;
        StringBuilder sb2 = new StringBuilder(length + length);
        for (int i10 = 0; i10 < length; i10++) {
            char[] cArr = f15075a;
            sb2.append(cArr[(bArr[i10] & 240) >>> 4]);
            sb2.append(cArr[bArr[i10] & 15]);
        }
        return sb2.toString();
    }

    public static String b() throws Throwable {
        BufferedReader bufferedReader;
        if (f15081g == null) {
            if (Build.VERSION.SDK_INT >= 28) {
                f15081g = Application.getProcessName();
            } else {
                int iMyPid = f15082h;
                if (iMyPid == 0) {
                    iMyPid = Process.myPid();
                    f15082h = iMyPid;
                }
                String strTrim = null;
                strTrim = null;
                strTrim = null;
                BufferedReader bufferedReader2 = null;
                strTrim = null;
                try {
                    if (iMyPid > 0) {
                        try {
                            String str = "/proc/" + iMyPid + "/cmdline";
                            StrictMode.ThreadPolicy threadPolicyAllowThreadDiskReads = StrictMode.allowThreadDiskReads();
                            try {
                                bufferedReader = new BufferedReader(new FileReader(str));
                                StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskReads);
                                try {
                                    String line = bufferedReader.readLine();
                                    L.j(line);
                                    strTrim = line.trim();
                                    bufferedReader.close();
                                } catch (IOException unused) {
                                    if (bufferedReader != null) {
                                        bufferedReader.close();
                                    }
                                    f15081g = strTrim;
                                    return f15081g;
                                } catch (Throwable th) {
                                    th = th;
                                    bufferedReader2 = bufferedReader;
                                    if (bufferedReader2 != null) {
                                        try {
                                            bufferedReader2.close();
                                        } catch (IOException unused2) {
                                        }
                                    }
                                    throw th;
                                }
                            } catch (Throwable th2) {
                                StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskReads);
                                throw th2;
                            }
                        } catch (IOException unused3) {
                            bufferedReader = null;
                        } catch (Throwable th3) {
                            th = th3;
                        }
                    }
                } catch (IOException unused4) {
                }
                f15081g = strTrim;
            }
        }
        return f15081g;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0027  */
    public static byte[] c(Context context, String str) {
        MessageDigest messageDigest;
        PackageInfo packageInfoG = p029c4.b.a(context).g(64, str);
        Signature[] signatureArr = packageInfoG.signatures;
        if (signatureArr != null && signatureArr.length == 1) {
            for (int i10 = 0; i10 < 2; i10++) {
                try {
                    messageDigest = MessageDigest.getInstance("SHA1");
                    if (messageDigest != null) {
                        if (messageDigest != null) {
                            return messageDigest.digest(packageInfoG.signatures[0].toByteArray());
                        }
                    }
                } catch (NoSuchAlgorithmException unused) {
                }
            }
            messageDigest = null;
            if (messageDigest != null) {
                return messageDigest.digest(packageInfoG.signatures[0].toByteArray());
            }
        }
        return null;
    }

    public static boolean d() {
        return Build.VERSION.SDK_INT >= 26;
    }

    public static boolean e(Context context, int i10) {
        if (h(context, "com.google.android.gms", i10)) {
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo("com.google.android.gms", 64);
                j jVarB = j.b(context);
                jVarB.getClass();
                if (packageInfo != null) {
                    if (!j.g(packageInfo, false)) {
                        if (j.g(packageInfo, true)) {
                            if (!i.a((Context) jVarB.f11609a)) {
                                Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
                            }
                        }
                    }
                    return true;
                }
                return false;
            } catch (PackageManager.NameNotFoundException unused) {
                if (Log.isLoggable("UidVerifier", 3)) {
                    Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
                }
            }
        }
        return false;
    }

    public static boolean f(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (f15077c == null) {
            f15077c = Boolean.valueOf(packageManager.hasSystemFeature("android.hardware.type.watch"));
        }
        return f15077c.booleanValue();
    }

    public static boolean g(Context context) {
        f(context);
        if (f15078d == null) {
            f15078d = Boolean.valueOf(context.getPackageManager().hasSystemFeature("cn.google"));
        }
        if (f15078d.booleanValue()) {
            return !d() || Build.VERSION.SDK_INT >= 30;
        }
        return false;
    }

    public static boolean h(Context context, String str, int i10) {
        C0215f c0215fA = p029c4.b.a(context);
        c0215fA.getClass();
        try {
            AppOpsManager appOpsManager = (AppOpsManager) c0215fA.f3528b.getSystemService("appops");
            if (appOpsManager == null) {
                throw new NullPointerException("context.getSystemService(Context.APP_OPS_SERVICE) is null");
            }
            appOpsManager.checkPackage(i10, str);
            return true;
        } catch (SecurityException unused) {
            return false;
        }
    }

    public static void i(StringBuilder sb2, HashMap map) {
        sb2.append("{");
        boolean z3 = true;
        for (String str : map.keySet()) {
            if (!z3) {
                sb2.append(",");
            }
            String str2 = (String) map.get(str);
            sb2.append("\"");
            sb2.append(str);
            sb2.append("\":");
            if (str2 == null) {
                sb2.append("null");
            } else {
                sb2.append("\"");
                sb2.append(str2);
                sb2.append("\"");
            }
            z3 = false;
        }
        sb2.append("}");
    }
}
