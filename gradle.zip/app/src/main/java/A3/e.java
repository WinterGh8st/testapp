package A3;

/* JADX INFO: loaded from: classes.dex */
public interface e {
}
