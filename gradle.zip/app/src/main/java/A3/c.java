package A3;

import java.util.concurrent.Executor;
import java.util.logging.Logger;
import p243v3.o;

/* JADX INFO: loaded from: classes.dex */
public final class c implements e {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final Logger f44f = Logger.getLogger(o.class.getName());

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final B3.d f45a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Executor f46b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final p254w3.e f47c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final C3.d f48d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final D3.c f49e;

    public c(Executor executor, p254w3.e eVar, B3.d dVar, C3.d dVar2, D3.c cVar) {
        this.f46b = executor;
        this.f47c = eVar;
        this.f45a = dVar;
        this.f48d = dVar2;
        this.f49e = cVar;
    }
}
