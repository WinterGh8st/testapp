package A3;

import java.util.concurrent.Executor;

/* JADX INFO: loaded from: classes.dex */
public final class d implements p263x3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final S9.a f50a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final S9.a f51b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final g f52c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final S9.a f53d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final S9.a f54e;

    public d(S9.a aVar, S9.a aVar2, g gVar, S9.a aVar3, S9.a aVar4) {
        this.f50a = aVar;
        this.f51b = aVar2;
        this.f52c = gVar;
        this.f53d = aVar3;
        this.f54e = aVar4;
    }

    @Override // S9.a
    public final Object get() {
        return new c((Executor) this.f50a.get(), (p254w3.e) this.f51b.get(), (B3.d) this.f52c.get(), (C3.d) this.f53d.get(), (D3.c) this.f54e.get());
    }
}
