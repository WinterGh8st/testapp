package A3;

import B0.l;
import C3.i;
import D8.x;
import G6.F0;
import L.AbstractC0492c;
import N1.O;
import N1.V;
import Z2.h;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.widget.Toast;
import com.flamingotools.ws.R;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.protobuf.AbstractC1018l;
import com.google.protobuf.C1016k;
import d6.A;
import java.util.AbstractCollection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ThreadPoolExecutor;
import p053e3.U;
import p053e3.a0;
import p068f6.B;
import p068f6.D;
import p080g6.n;
import p119j6.u;
import p129k6.o;
import p214s4.C1546p1;
import p243v3.k;
import p260x.AbstractC1876h;
import p278y6.s;
import p278y6.t;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class b implements D3.b, C3.g, V, o, SuccessContinuation {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f40a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f41b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f42c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f43d;

    public /* synthetic */ b(i iVar, Object obj, p243v3.i iVar2, int i10) {
        this.f40a = i10;
        this.f42c = iVar;
        this.f43d = obj;
        this.f41b = iVar2;
    }

    /* JADX WARN: Type inference failed for: r4v2, types: [java.util.AbstractCollection, java.util.List] */
    public void a(p253w2.e eVar, C1546p1 c1546p1) {
        s sVar = (s) this.f42c;
        sVar.getClass();
        int i10 = eVar.f31058a;
        h hVar = (h) this.f41b;
        if (i10 != 0) {
            sVar.s(new Z2.e(hVar, s.k(eVar), 0));
            return;
        }
        ?? r7 = (AbstractCollection) c1546p1.f28519a;
        if (r7 != 0) {
            r7.size();
        }
        if (r7 != 0 && !r7.isEmpty()) {
            sVar.s(new B3.e(hVar, r7));
            return;
        }
        Log.e("PlayBilling", "Google Play no devolvió productos " + ((List) this.f43d));
        sVar.s(new B3.o(hVar, 11));
    }

    @Override // C3.g
    public Object apply(Object obj) {
        Cursor cursor;
        int i10;
        long jInsert;
        p275y3.c cVar;
        p275y3.c cVar2;
        String str = "bytes";
        int i11 = 5;
        int i12 = 4;
        int i13 = 3;
        p275y3.c cVar3 = p275y3.c.CACHE_FULL;
        int i14 = 2;
        int i15 = 0;
        Object obj2 = this.f41b;
        Object obj3 = this.f43d;
        Object obj4 = this.f42c;
        int i16 = 1;
        switch (this.f40a) {
            case 1:
                Cursor cursor2 = (Cursor) obj;
                i iVar = (i) obj4;
                iVar.getClass();
                while (cursor2.moveToNext()) {
                    long j10 = cursor2.getLong(0);
                    int i17 = cursor2.getInt(7) != 0 ? i16 : 0;
                    x xVar = new x(13);
                    xVar.f2616q = new HashMap();
                    String string = cursor2.getString(i16);
                    if (string == null) {
                        throw new NullPointerException("Null transportName");
                    }
                    xVar.f2611b = string;
                    xVar.f2614e = Long.valueOf(cursor2.getLong(i14));
                    xVar.f2615f = Long.valueOf(cursor2.getLong(3));
                    if (i17 != 0) {
                        String string2 = cursor2.getString(4);
                        xVar.f2613d = new k(string2 == null ? i.f1685f : new p213s3.c(string2), cursor2.getBlob(5));
                        i10 = i16;
                    } else {
                        String string3 = cursor2.getString(4);
                        p213s3.c cVar4 = string3 == null ? i.f1685f : new p213s3.c(string3);
                        Cursor cursorQuery = iVar.b().query("event_payloads", new String[]{str}, "event_id = ?", new String[]{String.valueOf(j10)}, null, null, "sequence_num");
                        try {
                            ArrayList arrayList = new ArrayList();
                            int length = 0;
                            while (cursorQuery.moveToNext()) {
                                int i18 = i16;
                                byte[] blob = cursorQuery.getBlob(0);
                                arrayList.add(blob);
                                length += blob.length;
                                i16 = i18;
                            }
                            i10 = i16;
                            byte[] bArr = new byte[length];
                            int i19 = 0;
                            int length2 = 0;
                            while (i19 < arrayList.size()) {
                                byte[] bArr2 = (byte[]) arrayList.get(i19);
                                cursor = cursorQuery;
                                try {
                                    System.arraycopy(bArr2, 0, bArr, length2, bArr2.length);
                                    length2 += bArr2.length;
                                    i19++;
                                    cursorQuery = cursor;
                                } catch (Throwable th) {
                                    th = th;
                                    cursor.close();
                                    throw th;
                                }
                            }
                            cursorQuery.close();
                            xVar.f2613d = new k(cVar4, bArr);
                        } catch (Throwable th2) {
                            th = th2;
                            cursor = cursorQuery;
                        }
                    }
                    if (!cursor2.isNull(6)) {
                        xVar.f2612c = Integer.valueOf(cursor2.getInt(6));
                    }
                    ((ArrayList) obj3).add(new C3.b(j10, (p243v3.i) obj2, xVar.p()));
                    i16 = i10;
                    str = str;
                    i14 = 2;
                }
                return null;
            case 2:
                SQLiteDatabase sQLiteDatabase = (SQLiteDatabase) obj;
                i iVar2 = (i) obj4;
                long jSimpleQueryForLong = iVar2.b().compileStatement("PRAGMA page_size").simpleQueryForLong() * iVar2.b().compileStatement("PRAGMA page_count").simpleQueryForLong();
                C3.a aVar = iVar2.f1689d;
                long j11 = aVar.f1671a;
                p243v3.h hVar = (p243v3.h) obj3;
                String str2 = hVar.f30367a;
                if (jSimpleQueryForLong >= j11) {
                    iVar2.g(1L, cVar3, str2);
                    return -1L;
                }
                p243v3.i iVar3 = (p243v3.i) obj2;
                Long lC = i.c(sQLiteDatabase, iVar3);
                if (lC != null) {
                    jInsert = lC.longValue();
                } else {
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("backend_name", iVar3.f30373a);
                    contentValues.put("priority", Integer.valueOf(F3.a.a(iVar3.f30375c)));
                    contentValues.put("next_request_ms", (Integer) 0);
                    byte[] bArr3 = iVar3.f30374b;
                    if (bArr3 != null) {
                        contentValues.put("extras", Base64.encodeToString(bArr3, 0));
                    }
                    jInsert = sQLiteDatabase.insert("transport_contexts", null, contentValues);
                }
                k kVar = hVar.f30369c;
                byte[] bArr4 = kVar.f30383b;
                int length3 = bArr4.length;
                int i20 = aVar.f1675e;
                boolean z3 = length3 <= i20;
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("context_id", Long.valueOf(jInsert));
                contentValues2.put("transport_name", str2);
                contentValues2.put("timestamp_ms", Long.valueOf(hVar.f30370d));
                contentValues2.put("uptime_ms", Long.valueOf(hVar.f30371e));
                contentValues2.put("payload_encoding", kVar.f30382a.f27958a);
                contentValues2.put("code", hVar.f30368b);
                contentValues2.put("num_attempts", (Integer) 0);
                contentValues2.put("inline", Boolean.valueOf(z3));
                contentValues2.put("payload", z3 ? bArr4 : new byte[0]);
                long jInsert2 = sQLiteDatabase.insert("events", null, contentValues2);
                if (!z3) {
                    int iCeil = (int) Math.ceil(((double) bArr4.length) / ((double) i20));
                    for (int i21 = 1; i21 <= iCeil; i21++) {
                        byte[] bArrCopyOfRange = Arrays.copyOfRange(bArr4, (i21 - 1) * i20, Math.min(i21 * i20, bArr4.length));
                        ContentValues contentValues3 = new ContentValues();
                        contentValues3.put("event_id", Long.valueOf(jInsert2));
                        contentValues3.put("sequence_num", Integer.valueOf(i21));
                        contentValues3.put("bytes", bArrCopyOfRange);
                        sQLiteDatabase.insert("event_payloads", null, contentValues3);
                    }
                }
                for (Map.Entry entry : Collections.unmodifiableMap(hVar.f30372f).entrySet()) {
                    ContentValues contentValues4 = new ContentValues();
                    contentValues4.put("event_id", Long.valueOf(jInsert2));
                    contentValues4.put("name", (String) entry.getKey());
                    contentValues4.put("value", (String) entry.getValue());
                    sQLiteDatabase.insert("event_metadata", null, contentValues4);
                }
                return Long.valueOf(jInsert2);
            case 3:
                Cursor cursor3 = (Cursor) obj;
                i iVar4 = (i) obj4;
                iVar4.getClass();
                while (true) {
                    HashMap map = (HashMap) obj2;
                    if (cursor3.moveToNext()) {
                        String string4 = cursor3.getString(i15);
                        int i22 = cursor3.getInt(1);
                        p275y3.c cVar5 = p275y3.c.REASON_UNKNOWN;
                        if (i22 != 0) {
                            if (i22 == 1) {
                                cVar5 = p275y3.c.MESSAGE_TOO_OLD;
                            } else if (i22 == 2) {
                                cVar = cVar3;
                                cVar2 = cVar;
                            } else if (i22 == i13) {
                                cVar5 = p275y3.c.PAYLOAD_TOO_BIG;
                            } else if (i22 == i12) {
                                cVar5 = p275y3.c.MAX_RETRIES_REACHED;
                            } else if (i22 == i11) {
                                cVar5 = p275y3.c.INVALID_PAYLOD;
                            } else if (i22 == 6) {
                                cVar5 = p275y3.c.SERVER_ERROR;
                            } else {
                                p195q8.d.g(Integer.valueOf(i22), "SQLiteEventStore", "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN");
                            }
                            cVar2 = cVar3;
                            cVar = cVar5;
                        } else {
                            cVar2 = cVar3;
                            cVar = cVar5;
                        }
                        long j12 = cursor3.getLong(2);
                        if (!map.containsKey(string4)) {
                            map.put(string4, new ArrayList());
                        }
                        ((List) map.get(string4)).add(new p275y3.d(j12, cVar));
                        cVar3 = cVar2;
                        i11 = 5;
                        i12 = 4;
                        i13 = 3;
                        i15 = 0;
                    } else {
                        Iterator it = map.entrySet().iterator();
                        while (true) {
                            p119j6.g gVar = (p119j6.g) obj3;
                            if (!it.hasNext()) {
                                long jI = iVar4.f1687b.i();
                                SQLiteDatabase sQLiteDatabaseB = iVar4.b();
                                sQLiteDatabaseB.beginTransaction();
                                try {
                                    Cursor cursorRawQuery = sQLiteDatabaseB.rawQuery("SELECT last_metrics_upload_ms FROM global_log_event_state LIMIT 1", new String[0]);
                                    try {
                                        cursorRawQuery.moveToNext();
                                        p275y3.g gVar2 = new p275y3.g(cursorRawQuery.getLong(0), jI);
                                        cursorRawQuery.close();
                                        sQLiteDatabaseB.setTransactionSuccessful();
                                        sQLiteDatabaseB.endTransaction();
                                        gVar.f24073c = gVar2;
                                        gVar.f24074d = new p275y3.b(new p275y3.f(iVar4.b().compileStatement("PRAGMA page_size").simpleQueryForLong() * iVar4.b().compileStatement("PRAGMA page_count").simpleQueryForLong(), C3.a.f1670f.f1671a));
                                        gVar.f24075e = (String) iVar4.f1690e.get();
                                        return new p275y3.a((p275y3.g) gVar.f24073c, Collections.unmodifiableList((ArrayList) gVar.f24072b), (p275y3.b) gVar.f24074d, (String) gVar.f24075e);
                                    } catch (Throwable th3) {
                                        cursorRawQuery.close();
                                        throw th3;
                                    }
                                } catch (Throwable th4) {
                                    sQLiteDatabaseB.endTransaction();
                                    throw th4;
                                }
                            }
                            Map.Entry entry2 = (Map.Entry) it.next();
                            int i23 = p275y3.e.f32500c;
                            new ArrayList();
                            ((ArrayList) gVar.f24072b).add(new p275y3.e((String) entry2.getKey(), Collections.unmodifiableList((List) entry2.getValue())));
                        }
                    }
                }
                break;
            default:
                return Tasks.call((ThreadPoolExecutor) obj2, new S5.e((FirebaseFirestore) obj4, (A6.e) obj3, (A) obj, i16));
        }
    }

    @Override // D3.b
    public Object b() {
        c cVar = (c) this.f42c;
        i iVar = (i) cVar.f48d;
        iVar.getClass();
        p243v3.i iVar2 = (p243v3.i) this.f41b;
        p243v3.h hVar = (p243v3.h) this.f43d;
        String strK = p195q8.d.k("SQLiteEventStore");
        if (Log.isLoggable(strK, 3)) {
            Log.d(strK, "Storing event with priority=" + iVar2.f30375c + ", name=" + hVar.f30367a + " for destination " + iVar2.f30373a);
        }
        ((Long) iVar.d(new b(iVar, (Object) hVar, iVar2, 2))).getClass();
        cVar.f45a.a(iVar2, 1, false);
        return null;
    }

    @Override // N1.V
    public void c(Bundle bundle, String str) {
        int iY;
        switch (this.f40a) {
            case 6:
                boolean z3 = bundle.getBoolean("connected", false);
                ((O) this.f42c).e("bt_connect_result");
                if (!z3) {
                    ((Runnable) this.f43d).run();
                } else {
                    ((Runnable) this.f41b).run();
                }
                break;
            case 7:
                boolean z5 = bundle.getBoolean("connected", false);
                ((O) this.f42c).e("bt_connect_result");
                if (!z5) {
                    ((X2.e) this.f43d).run();
                } else {
                    ((X2.e) this.f41b).run();
                }
                break;
            default:
                a0 a0Var = (a0) this.f42c;
                a0Var.getClass();
                ((O) this.f41b).e("AuthenticationResultKey");
                if (a0Var.y()) {
                    String string = bundle.getString("status", "ERROR");
                    String string2 = bundle.getString("message", "");
                    try {
                        iY = AbstractC0492c.y(string);
                    } catch (Exception unused) {
                        iY = 8;
                    }
                    int iC = AbstractC1876h.c(iY);
                    if (iC != 0) {
                        if (iC != 1 && iC != 2) {
                            if (iC == 3) {
                                Toast.makeText(a0Var.W(), R.string.toast_por_favor_espera_a_que_se_apruebe_tu_acceso, 1).show();
                                break;
                            } else if (iC != 6) {
                                if (string2 != null && !string2.isEmpty()) {
                                    Toast.makeText(a0Var.W(), string2, 1).show();
                                    break;
                                }
                            }
                        }
                    }
                    a0Var.c0(null);
                    ((U) this.f43d).run();
                    break;
                }
                break;
        }
    }

    @Override // p129k6.o
    public Object get() {
        B b10;
        Iterator it;
        long j10;
        p068f6.g gVar = (p068f6.g) this.f42c;
        l lVar = (l) this.f41b;
        p068f6.x xVar = gVar.f22529a;
        long jB = xVar.f().b();
        Iterator it2 = ((Map) lVar.f737c).entrySet().iterator();
        while (true) {
            boolean zHasNext = it2.hasNext();
            b10 = gVar.f22537i;
            if (!zHasNext) {
                break;
            }
            Map.Entry entry = (Map.Entry) it2.next();
            Integer num = (Integer) entry.getKey();
            int iIntValue = num.intValue();
            u uVar = (u) entry.getValue();
            SparseArray sparseArray = gVar.f22538j;
            D d10 = (D) sparseArray.get(iIntValue);
            if (d10 != null) {
                T5.d dVar = uVar.f24131e;
                p068f6.x xVar2 = b10.f22494a;
                p068f6.x xVar3 = xVar;
                SQLiteStatement sQLiteStatementCompileStatement = xVar2.f22600g.compileStatement("DELETE FROM target_documents WHERE target_id = ? AND path = ?");
                Iterator it3 = dVar.iterator();
                while (true) {
                    T5.c cVar = (T5.c) it3;
                    it = it2;
                    if (!((Iterator) cVar.f11752b).hasNext()) {
                        break;
                    }
                    p080g6.h hVar = (p080g6.h) cVar.next();
                    Iterator it4 = it3;
                    Object[] objArr = {Integer.valueOf(iIntValue), p054e4.e.W(hVar.f22816a)};
                    sQLiteStatementCompileStatement.clearBindings();
                    p068f6.x.a(sQLiteStatementCompileStatement, objArr);
                    sQLiteStatementCompileStatement.executeUpdateDelete();
                    xVar2.f22598e.e(hVar);
                    it2 = it;
                    it3 = it4;
                }
                T5.d dVar2 = uVar.f24129c;
                p068f6.x xVar4 = b10.f22494a;
                SQLiteStatement sQLiteStatementCompileStatement2 = xVar4.f22600g.compileStatement("INSERT OR IGNORE INTO target_documents (target_id, path) VALUES (?, ?)");
                Iterator it5 = dVar2.iterator();
                while (true) {
                    T5.c cVar2 = (T5.c) it5;
                    if (!((Iterator) cVar2.f11752b).hasNext()) {
                        break;
                    }
                    p080g6.h hVar2 = (p080g6.h) cVar2.next();
                    Iterator it6 = it5;
                    Object[] objArr2 = {Integer.valueOf(iIntValue), p054e4.e.W(hVar2.f22816a)};
                    sQLiteStatementCompileStatement2.clearBindings();
                    p068f6.x.a(sQLiteStatementCompileStatement2, objArr2);
                    sQLiteStatementCompileStatement2.executeUpdateDelete();
                    xVar4.f22598e.e(hVar2);
                    it5 = it6;
                }
                D dB = d10.b(jB);
                if (((Map) lVar.f738d).containsKey(num)) {
                    C1016k c1016k = AbstractC1018l.f20334b;
                    n nVar = n.f22830b;
                    D dA = dB.a(c1016k, nVar);
                    j10 = jB;
                    dB = new D(dA.f22500a, dA.f22501b, dA.f22502c, dA.f22503d, dA.f22504e, nVar, dA.f22506g, null);
                } else {
                    j10 = jB;
                    AbstractC1018l abstractC1018l = uVar.f24127a;
                    if (!abstractC1018l.isEmpty()) {
                        dB = dB.a(abstractC1018l, (n) lVar.f736b);
                    }
                }
                sparseArray.put(iIntValue, dB);
                if (p068f6.g.d(d10, dB, uVar)) {
                    b10.e(dB);
                }
                xVar = xVar3;
                it2 = it;
                jB = j10;
            }
        }
        p068f6.x xVar5 = xVar;
        Map map = (Map) lVar.f739e;
        for (p080g6.h hVar3 : map.keySet()) {
            if (((Set) lVar.f740f).contains(hVar3)) {
                xVar5.f().e(hVar3);
            }
        }
        HashMap map2 = new HashMap();
        ArrayList arrayList = new ArrayList();
        HashSet hashSet = new HashSet();
        Set setKeySet = map.keySet();
        Z2.f fVar = gVar.f22533e;
        HashMap mapA = fVar.A(setKeySet);
        Iterator it7 = map.entrySet().iterator();
        while (true) {
            if (!it7.hasNext()) {
                break;
            }
            Map.Entry entry2 = (Map.Entry) it7.next();
            p080g6.h hVar4 = (p080g6.h) entry2.getKey();
            p080g6.k kVar = (p080g6.k) entry2.getValue();
            p080g6.k kVar2 = (p080g6.k) mapA.get(hVar4);
            if (kVar.d() != kVar2.d()) {
                hashSet.add(hVar4);
            }
            if (kVar.e() && kVar.f22823c.equals(n.f22830b)) {
                arrayList.add(kVar.f22821a);
                map2.put(hVar4, kVar);
            } else if (AbstractC1876h.b(kVar2.f22822b, 1) || kVar.f22823c.compareTo(kVar2.f22823c) > 0 || (kVar.f22823c.compareTo(kVar2.f22823c) == 0 && (kVar2.c() || AbstractC1876h.b(kVar2.f22826f, 2)))) {
                Ua.d.D(true ^ n.f22830b.equals(kVar.f22824d), "Cannot add a document when the remote version is zero", new Object[0]);
                fVar.l(kVar, kVar.f22824d);
                map2.put(hVar4, kVar);
            } else {
                Ua.l.A(1, "LocalStore", "Ignoring outdated watch update for %s.Current version: %s  Watch version: %s", hVar4, kVar2.f22823c, kVar.f22823c);
            }
        }
        fVar.Q(arrayList);
        n nVarB = b10.b();
        n nVar2 = n.f22830b;
        n nVar3 = (n) this.f43d;
        if (!nVar3.equals(nVar2)) {
            Ua.d.D(nVar3.compareTo(nVarB) >= 0, "Watch stream reverted to previous snapshot?? (%s < %s)", nVar3, nVarB);
            b10.f22498e = nVar3;
            b10.f();
        }
        return gVar.f22534f.E(map2, hashSet);
    }

    @Override // com.google.android.gms.tasks.SuccessContinuation
    public Task then(Object obj) {
        switch (this.f40a) {
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p137l6.c cVar = (p137l6.c) this.f42c;
                cVar.getClass();
                return Tasks.forResult(new p137l6.l((String) ((Task) this.f41b).getResult(), ((p169o6.g) ((p181p6.a) cVar.f24725b.get())).f26360a.f(), (String) ((Task) this.f43d).getResult()));
            default:
                FirebaseMessaging firebaseMessaging = (FirebaseMessaging) this.f42c;
                String str = (String) this.f41b;
                t tVar = (t) this.f43d;
                String str2 = (String) obj;
                p077g3.b bVarD = FirebaseMessaging.d(firebaseMessaging.f20136c);
                E5.h hVar = firebaseMessaging.f20134a;
                hVar.a();
                String strF = "[DEFAULT]".equals(hVar.f2969b) ? "" : hVar.f();
                String strA = firebaseMessaging.f20143j.a();
                synchronized (bVarD) {
                    String strA2 = t.a(str2, strA, System.currentTimeMillis());
                    if (strA2 != null) {
                        SharedPreferences.Editor editorEdit = bVarD.f22779a.edit();
                        editorEdit.putString(strF + "|T|" + str + "|*", strA2);
                        editorEdit.commit();
                    }
                }
                if (tVar == null || !str2.equals(tVar.f32581a)) {
                    firebaseMessaging.g(str2);
                }
                return Tasks.forResult(str2);
        }
    }

    public /* synthetic */ b(Object obj, Object obj2, Object obj3, int i10) {
        this.f40a = i10;
        this.f42c = obj;
        this.f41b = obj2;
        this.f43d = obj3;
    }
}
