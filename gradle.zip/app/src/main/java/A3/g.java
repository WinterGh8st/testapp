package A3;

import B3.m;
import B3.n;
import B3.p;
import B3.q;
import android.content.Context;
import p243v3.o;

/* JADX INFO: loaded from: classes.dex */
public final class g implements p263x3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f56a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p263x3.b f57b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final S9.a f58c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final p263x3.b f59d;

    public /* synthetic */ g(p263x3.b bVar, S9.a aVar, p263x3.b bVar2, int i10) {
        this.f56a = i10;
        this.f57b = bVar;
        this.f58c = aVar;
        this.f59d = bVar2;
    }

    @Override // S9.a
    public final Object get() {
        switch (this.f56a) {
            case 0:
                return new B3.d((Context) ((C3.e) this.f57b).f1680b, (C3.d) this.f58c.get(), (B3.b) ((f) this.f59d).get());
            default:
                return new o(new n6.e(6), new p067f5.f(6), (e) ((d) this.f57b).get(), (m) ((n) this.f58c).get(), (p) ((q) this.f59d).get());
        }
    }
}
