package A3;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;

/* JADX INFO: loaded from: classes.dex */
public final class f implements p263x3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f55a;

    @Override // S9.a
    public final Object get() {
        switch (this.f55a) {
            case 0:
                n6.e eVar = new n6.e(6);
                HashMap map = new HashMap();
                p213s3.d dVar = p213s3.d.f27959a;
                Set set = Collections.EMPTY_SET;
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(dVar, new B3.c(30000L, 86400000L, set));
                p213s3.d dVar2 = p213s3.d.f27961c;
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(dVar2, new B3.c(1000L, 86400000L, set));
                p213s3.d dVar3 = p213s3.d.f27960b;
                if (set == null) {
                    throw new NullPointerException("Null flags");
                }
                Set setUnmodifiableSet = Collections.unmodifiableSet(new HashSet(Arrays.asList(B3.f.f1065b)));
                if (setUnmodifiableSet == null) {
                    throw new NullPointerException("Null flags");
                }
                map.put(dVar3, new B3.c(86400000L, 86400000L, setUnmodifiableSet));
                if (map.keySet().size() < p213s3.d.values().length) {
                    throw new IllegalStateException("Not all priorities have been configured");
                }
                new HashMap();
                return new B3.b(eVar, map);
            default:
                return new p017b4.a(Executors.newSingleThreadExecutor(), 4);
        }
    }
}
