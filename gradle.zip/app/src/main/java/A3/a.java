package A3;

import Aa.j;
import F2.C0215f;
import G6.F0;
import G6.y0;
import H0.B;
import H9.C0348i1;
import H9.C1;
import I1.l;
import I1.q;
import I1.r;
import N1.AbstractComponentCallbacksC0583t;
import android.content.Intent;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.flamingotools.ws.R;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import d6.C1045b;
import d6.n;
import d6.z;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.logging.Logger;
import org.json.JSONObject;
import p019b6.t;
import p053e3.C1080k;
import p053e3.a0;
import p068f6.C1100d;
import p068f6.D;
import p068f6.k;
import p243v3.h;
import p243v3.i;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f36a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f37b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f38c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f39d;

    public /* synthetic */ a(c cVar, i iVar, C1080k c1080k, h hVar) {
        this.f36a = 0;
        this.f37b = cVar;
        this.f38c = iVar;
        this.f39d = hVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f36a) {
            case 0:
                i iVar = (i) this.f38c;
                String str = iVar.f30373a;
                h hVar = (h) this.f39d;
                c cVar = (c) this.f37b;
                cVar.getClass();
                Logger logger = c.f44f;
                try {
                    p254w3.f fVarA = cVar.f47c.a(str);
                    if (fVarA == null) {
                        String str2 = "Transport backend '" + str + "' is not registered";
                        logger.warning(str2);
                        new IllegalArgumentException(str2);
                    } else {
                        ((C3.i) cVar.f49e).h(new b(cVar, iVar, ((p223t3.b) fVarA).a(hVar), 0));
                    }
                    return;
                } catch (Exception e10) {
                    logger.warning("Error scheduling event " + e10.getMessage());
                    return;
                }
            case 1:
                C0215f c0215f = (C0215f) this.f37b;
                p123ja.a aVar = (p123ja.a) this.f38c;
                ThreadPoolExecutor threadPoolExecutor = (ThreadPoolExecutor) this.f39d;
                c0215f.getClass();
                try {
                    r rVarF = p054e4.e.F(c0215f.f3528b);
                    if (rVarF == null) {
                        throw new RuntimeException("EmojiCompat font provider not available on this device.");
                    }
                    q qVar = (q) ((I1.i) rVarF.f5745b);
                    synchronized (qVar.f5767d) {
                        qVar.f5769f = threadPoolExecutor;
                        break;
                    }
                    ((I1.i) rVarF.f5745b).a(new l(aVar, threadPoolExecutor));
                    return;
                } catch (Throwable th) {
                    aVar.Q(th);
                    threadPoolExecutor.shutdown();
                    return;
                }
            case 2:
                C1045b c1045b = (C1045b) this.f37b;
                Object obj = this.f38c;
                t tVar = (t) this.f39d;
                if (c1045b.f21513c) {
                    return;
                }
                c1045b.f21512b.a(obj, tVar);
                return;
            case 3:
                B b10 = ((n) this.f37b).f21560f;
                b10.a("writeMutations");
                p068f6.g gVar = (p068f6.g) b10.f4397a;
                E5.q qVarC = E5.q.c();
                HashSet hashSet = new HashSet();
                List list = (List) this.f38c;
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    hashSet.add(((p093h6.h) it.next()).f23160a);
                }
                C1100d c1100d = (C1100d) gVar.f22529a.h("Locally write mutations", new J5.b(gVar, hashSet, list, qVarC));
                int i10 = c1100d.f22521a;
                HashMap map = (HashMap) b10.f4405i;
                Map map2 = (Map) map.get((p031c6.e) b10.f4407l);
                if (map2 == null) {
                    map2 = new HashMap();
                    map.put((p031c6.e) b10.f4407l, map2);
                }
                map2.put(Integer.valueOf(i10), (TaskCompletionSource) this.f39d);
                b10.b(c1100d.f22522b, null);
                ((C0348i1) b10.f4398b).c();
                return;
            case 4:
                a0 a0Var = (a0) this.f37b;
                a0Var.getClass();
                ((C1) this.f38c).b();
                if (a0Var.f9230P == null) {
                    return;
                }
                a0Var.f21985q0.setEnabled(true);
                a0Var.q0(a0Var.t(R.string.ia_error_preparar), ((Exception) this.f39d).getMessage());
                return;
            case 5:
                a0 a0Var2 = (a0) this.f37b;
                a0Var2.getClass();
                ((C1) this.f38c).b();
                a0Var2.m0((String) this.f39d);
                return;
            case 6:
                a0 a0Var3 = (a0) this.f37b;
                a0Var3.getClass();
                ((C1) this.f38c).b();
                a0Var3.d0((List) this.f39d);
                return;
            case 7:
                a0 a0Var4 = (a0) this.f37b;
                a0Var4.getClass();
                RadioGroup radioGroup = (RadioGroup) this.f38c;
                RadioButton radioButton = (RadioButton) radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());
                if (radioButton == null) {
                    return;
                }
                ((C1) this.f39d).b();
                a0Var4.m0((String) radioButton.getTag());
                return;
            case 8:
                a0 a0Var5 = (a0) this.f37b;
                a0Var5.f21971E0 = false;
                ((C1) this.f38c).b();
                a0Var5.d0((ArrayList) this.f39d);
                return;
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p136l3.h hVar2 = (p136l3.h) this.f39d;
                a0 a0Var6 = (a0) this.f37b;
                a0Var6.getClass();
                ((C1) this.f38c).b();
                try {
                    a0Var6.f21986r0 = null;
                    a0Var6.r0((JSONObject) hVar2.f24720c);
                    return;
                } catch (Exception e11) {
                    a0Var6.q0(a0Var6.t(R.string.ia_error_cargar), e11.getMessage());
                    return;
                }
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p068f6.g gVar2 = (p068f6.g) this.f37b;
                j jVar = gVar2.f22539l;
                int i11 = jVar.f469a;
                jVar.f469a = i11 + 2;
                k kVar = (k) this.f38c;
                kVar.f22547a = i11;
                D d10 = new D((z) this.f39d, i11, gVar2.f22529a.f().b(), p068f6.n.f22555a);
                kVar.f22548b = d10;
                p068f6.B b11 = gVar2.f22537i;
                b11.d(d10);
                int i12 = b11.f22496c;
                int i13 = d10.f22501b;
                if (i13 > i12) {
                    b11.f22496c = i13;
                }
                long j10 = b11.f22497d;
                long j11 = d10.f22502c;
                if (j11 > j10) {
                    b11.f22497d = j11;
                }
                b11.f22499f++;
                b11.f();
                return;
            case 11:
                O5.d dVar = (O5.d) this.f37b;
                Executor executor = (Executor) this.f38c;
                TaskCompletionSource taskCompletionSource = (TaskCompletionSource) this.f39d;
                try {
                    ((Task) dVar.call()).continueWith(executor, new B3.h(taskCompletionSource, 26));
                    return;
                } catch (Exception e12) {
                    taskCompletionSource.setException(e12);
                    return;
                } catch (Throwable th2) {
                    taskCompletionSource.setException(new IllegalStateException("Unhandled throwable in callTask.", th2));
                    return;
                }
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                ((Z2.f) this.f37b).u();
                if (((AbstractComponentCallbacksC0583t) this.f38c).y()) {
                    ((p103i3.b) this.f39d).run();
                    return;
                }
                return;
            case 13:
                boolean[] zArr = (boolean[]) this.f37b;
                if (zArr[0]) {
                    return;
                }
                zArr[0] = true;
                ((Z2.f) this.f38c).u();
                AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t = (AbstractComponentCallbacksC0583t) this.f39d;
                if (abstractComponentCallbacksC0583t.p() != null) {
                    Toast.makeText(abstractComponentCallbacksC0583t.p(), R.string.toast_no_se_recibi_respuesta_del_dispositivo, 0).show();
                    return;
                }
                return;
            default:
                Intent intent = (Intent) this.f38c;
                TaskCompletionSource taskCompletionSource2 = (TaskCompletionSource) this.f39d;
                p278y6.g gVar3 = (p278y6.g) this.f37b;
                gVar3.getClass();
                try {
                    gVar3.b(intent);
                    return;
                } finally {
                    taskCompletionSource2.setResult(null);
                }
        }
    }

    public /* synthetic */ a(Object obj, Object obj2, Object obj3, int i10) {
        this.f36a = i10;
        this.f37b = obj;
        this.f38c = obj2;
        this.f39d = obj3;
    }
}
