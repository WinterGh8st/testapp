package A2;

import F2.D;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.TextUtils;
import android.util.Log;
import com.bumptech.glide.h;
import com.bumptech.glide.load.data.e;
import com.bumptech.glide.load.data.i;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes.dex */
public final class b implements e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f28a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Comparable f29b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f30c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Object f31d;

    public /* synthetic */ b(int i10, Comparable comparable, Object obj) {
        this.f28a = i10;
        this.f29b = comparable;
        this.f30c = obj;
    }

    public static b c(Context context, Uri uri, c cVar) {
        return new b(0, uri, new d(com.bumptech.glide.c.a(context).f18339c.a().e(), cVar, com.bumptech.glide.c.a(context).f18340d, context.getContentResolver()));
    }

    @Override // com.bumptech.glide.load.data.e
    public final void a() {
        switch (this.f28a) {
            case 0:
                InputStream inputStream = (InputStream) this.f31d;
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException unused) {
                        return;
                    }
                }
                break;
            case 1:
                try {
                    ((ByteArrayInputStream) this.f31d).close();
                } catch (IOException unused2) {
                    return;
                }
                break;
            default:
                Object obj = this.f31d;
                if (obj != null) {
                    try {
                        switch (((D) this.f30c).f3510a) {
                            case 8:
                                ((ParcelFileDescriptor) obj).close();
                                break;
                            default:
                                ((InputStream) obj).close();
                                break;
                        }
                    } catch (IOException unused3) {
                        return;
                    }
                }
                break;
        }
    }

    @Override // com.bumptech.glide.load.data.e
    public final Class b() {
        switch (this.f28a) {
            case 0:
                return InputStream.class;
            case 1:
                ((D) this.f30c).getClass();
                return InputStream.class;
            default:
                return ((D) this.f30c).b();
        }
    }

    @Override // com.bumptech.glide.load.data.e
    public final void cancel() {
        int i10 = this.f28a;
    }

    @Override // com.bumptech.glide.load.data.e
    public final int d() {
        switch (this.f28a) {
        }
        return 1;
    }

    @Override // com.bumptech.glide.load.data.e
    public final void e(h hVar, com.bumptech.glide.load.data.d dVar) throws Throwable {
        Object objOpen;
        switch (this.f28a) {
            case 0:
                try {
                    InputStream inputStreamI = i();
                    this.f31d = inputStreamI;
                    dVar.f(inputStreamI);
                } catch (FileNotFoundException e10) {
                    if (Log.isLoggable("MediaStoreThumbFetcher", 3)) {
                        Log.d("MediaStoreThumbFetcher", "Failed to find thumbnail file", e10);
                    }
                    dVar.c(e10);
                    return;
                }
                break;
            case 1:
                try {
                    ByteArrayInputStream byteArrayInputStreamA = D.a((String) this.f29b);
                    this.f31d = byteArrayInputStreamA;
                    dVar.f(byteArrayInputStreamA);
                } catch (IllegalArgumentException e11) {
                    dVar.c(e11);
                }
                break;
            default:
                try {
                    D d10 = (D) this.f30c;
                    File file = (File) this.f29b;
                    switch (d10.f3510a) {
                        case 8:
                            objOpen = ParcelFileDescriptor.open(file, 268435456);
                            break;
                        default:
                            objOpen = new FileInputStream(file);
                            break;
                    }
                    this.f31d = objOpen;
                    dVar.f(objOpen);
                } catch (FileNotFoundException e12) {
                    if (Log.isLoggable("FileLoader", 3)) {
                        Log.d("FileLoader", "Failed to open file", e12);
                    }
                    dVar.c(e12);
                    return;
                }
                break;
        }
    }

    /* JADX WARN: Code duplicated, block: B:27:0x0057  */
    /* JADX WARN: Code duplicated, block: B:28:0x0059  */
    /* JADX WARN: Code duplicated, block: B:30:0x0064  */
    /* JADX WARN: Code duplicated, block: B:40:0x009d  */
    /* JADX WARN: Code duplicated, block: B:59:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:61:0x00da  */
    /* JADX WARN: Code duplicated, block: B:64:0x00e3  */
    /* JADX WARN: Code duplicated, block: B:72:0x00ad A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:83:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Not initialized variable reg: 6, insn: 0x0026: MOVE (r5 I:??[OBJECT, ARRAY]) = (r6 I:??[OBJECT, ARRAY]) (LINE:39), block:B:10:0x0026 */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.io.IOException, java.lang.Throwable] */
    /* JADX WARN: Type inference failed for: r5v0, types: [java.io.InputStream] */
    /* JADX WARN: Type inference failed for: r5v1, types: [android.database.Cursor] */
    /* JADX WARN: Type inference failed for: r5v2 */
    /* JADX WARN: Type inference failed for: r6v1 */
    public InputStream i() throws Throwable {
        Cursor cursorA;
        ?? r7;
        String string;
        boolean zIsEmpty;
        ContentResolver contentResolver;
        File file;
        InputStream inputStreamOpenInputStream;
        int iO;
        Uri uri = (Uri) this.f29b;
        d dVar = (d) this.f30c;
        ?? r10 = 0;
        InputStream inputStreamOpenInputStream2 = null;
        try {
            try {
                cursorA = dVar.f32a.a(uri);
                if (cursorA != null) {
                    try {
                        if (cursorA.moveToFirst()) {
                            string = cursorA.getString(0);
                            cursorA.close();
                        }
                    } catch (SecurityException e10) {
                        e = e10;
                        if (Log.isLoggable("ThumbStreamOpener", 3)) {
                            Log.d("ThumbStreamOpener", "Failed to query for thumbnail for Uri: " + uri, e);
                        }
                        if (cursorA != null) {
                        }
                        string = null;
                        zIsEmpty = TextUtils.isEmpty(string);
                        contentResolver = dVar.f34c;
                        if (zIsEmpty) {
                            inputStreamOpenInputStream = null;
                        } else {
                            file = new File(string);
                            if (file.exists()) {
                                inputStreamOpenInputStream = null;
                            } else {
                                inputStreamOpenInputStream = null;
                            }
                        }
                        if (inputStreamOpenInputStream != null) {
                            try {
                                try {
                                    inputStreamOpenInputStream2 = contentResolver.openInputStream(uri);
                                    iO = p195q8.c.o(dVar.f35d, inputStreamOpenInputStream2, dVar.f33b);
                                    if (inputStreamOpenInputStream2 != null) {
                                        try {
                                            inputStreamOpenInputStream2.close();
                                        } catch (IOException unused) {
                                        }
                                    }
                                } catch (IOException | NullPointerException e11) {
                                    if (Log.isLoggable("ThumbStreamOpener", 3)) {
                                        Log.d("ThumbStreamOpener", "Failed to open uri: " + uri, e11);
                                    }
                                    if (inputStreamOpenInputStream2 != null) {
                                        try {
                                            inputStreamOpenInputStream2.close();
                                        } catch (IOException unused2) {
                                        }
                                    }
                                    iO = -1;
                                }
                            } catch (Throwable th) {
                                if (0 != 0) {
                                    try {
                                        r10.close();
                                    } catch (IOException unused3) {
                                    }
                                }
                                throw th;
                            }
                        } else {
                            iO = -1;
                        }
                        if (iO != -1) {
                            return new i(inputStreamOpenInputStream, iO);
                        }
                        return inputStreamOpenInputStream;
                    }
                    zIsEmpty = TextUtils.isEmpty(string);
                    contentResolver = dVar.f34c;
                    if (zIsEmpty) {
                        inputStreamOpenInputStream = null;
                    } else {
                        file = new File(string);
                        if (file.exists() || 0 >= file.length()) {
                            inputStreamOpenInputStream = null;
                        } else {
                            Uri uriFromFile = Uri.fromFile(file);
                            try {
                                inputStreamOpenInputStream = contentResolver.openInputStream(uriFromFile);
                            } catch (NullPointerException e12) {
                                throw ((FileNotFoundException) new FileNotFoundException("NPE opening uri: " + uri + " -> " + uriFromFile).initCause(e12));
                            }
                        }
                    }
                    if (inputStreamOpenInputStream != null) {
                        inputStreamOpenInputStream2 = contentResolver.openInputStream(uri);
                        iO = p195q8.c.o(dVar.f35d, inputStreamOpenInputStream2, dVar.f33b);
                        if (inputStreamOpenInputStream2 != null) {
                            inputStreamOpenInputStream2.close();
                        }
                    } else {
                        iO = -1;
                    }
                    if (iO != -1) {
                        return new i(inputStreamOpenInputStream, iO);
                    }
                    return inputStreamOpenInputStream;
                }
                if (cursorA != null) {
                    cursorA.close();
                }
            } catch (SecurityException e13) {
                e = e13;
                cursorA = null;
            } catch (Throwable th2) {
                th = th2;
                if (r10 != 0) {
                    r10.close();
                }
                throw th;
            }
            string = null;
            zIsEmpty = TextUtils.isEmpty(string);
            contentResolver = dVar.f34c;
            if (zIsEmpty) {
                inputStreamOpenInputStream = null;
            } else {
                file = new File(string);
                if (file.exists()) {
                    inputStreamOpenInputStream = null;
                } else {
                    inputStreamOpenInputStream = null;
                }
            }
            if (inputStreamOpenInputStream != null) {
                inputStreamOpenInputStream2 = contentResolver.openInputStream(uri);
                iO = p195q8.c.o(dVar.f35d, inputStreamOpenInputStream2, dVar.f33b);
                if (inputStreamOpenInputStream2 != null) {
                    inputStreamOpenInputStream2.close();
                }
            } else {
                iO = -1;
            }
            if (iO != -1) {
                return new i(inputStreamOpenInputStream, iO);
            }
            return inputStreamOpenInputStream;
        } catch (Throwable th3) {
            th = th3;
            r10 = r7;
            if (r10 != 0) {
                r10.close();
            }
            throw th;
        }
    }

    private final void f() {
    }

    private final void g() {
    }

    private final void h() {
    }
}
