package A2;

import C2.g;
import android.content.ContentResolver;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final c f32a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g f33b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ContentResolver f34c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f35d;

    public d(ArrayList arrayList, c cVar, g gVar, ContentResolver contentResolver) {
        this.f32a = cVar;
        this.f33b = gVar;
        this.f34c = contentResolver;
        this.f35d = arrayList;
    }
}
