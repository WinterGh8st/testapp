package A2;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

/* JADX INFO: loaded from: classes.dex */
public final class a implements c {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final String[] f24c = {"_data"};

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final String[] f25d = {"_data"};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f26a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ContentResolver f27b;

    public /* synthetic */ a(ContentResolver contentResolver, int i10) {
        this.f26a = i10;
        this.f27b = contentResolver;
    }

    @Override // A2.c
    public final Cursor a(Uri uri) {
        switch (this.f26a) {
            case 0:
                String lastPathSegment = uri.getLastPathSegment();
                return this.f27b.query(MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, f24c, "kind = 1 AND image_id = ?", new String[]{lastPathSegment}, null);
            default:
                String lastPathSegment2 = uri.getLastPathSegment();
                return this.f27b.query(MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, f25d, "kind = 1 AND video_id = ?", new String[]{lastPathSegment2}, null);
        }
    }
}
