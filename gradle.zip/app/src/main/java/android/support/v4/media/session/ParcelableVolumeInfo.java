package android.support.v4.media.session;

import T3.v;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new v(27);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f15228a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f15229b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f15230c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f15231d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f15232e;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f15228a);
        parcel.writeInt(this.f15230c);
        parcel.writeInt(this.f15231d);
        parcel.writeInt(this.f15232e);
        parcel.writeInt(this.f15229b);
    }
}
