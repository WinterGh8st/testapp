package android.support.v4.media.session;

import L.AbstractC0492c;
import T3.v;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new v(28);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f15233a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f15234b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final long f15235c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f15236d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f15237e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f15238f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final CharSequence f15239q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final long f15240r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final ArrayList f15241s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final long f15242t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Bundle f15243u;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new b();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final String f15244a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final CharSequence f15245b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final int f15246c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final Bundle f15247d;

        public CustomAction(Parcel parcel) {
            this.f15244a = parcel.readString();
            this.f15245b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f15246c = parcel.readInt();
            this.f15247d = parcel.readBundle(a.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + ((Object) this.f15245b) + ", mIcon=" + this.f15246c + ", mExtras=" + this.f15247d;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.f15244a);
            TextUtils.writeToParcel(this.f15245b, parcel, i10);
            parcel.writeInt(this.f15246c);
            parcel.writeBundle(this.f15247d);
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f15233a = parcel.readInt();
        this.f15234b = parcel.readLong();
        this.f15236d = parcel.readFloat();
        this.f15240r = parcel.readLong();
        this.f15235c = parcel.readLong();
        this.f15237e = parcel.readLong();
        this.f15239q = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f15241s = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f15242t = parcel.readLong();
        this.f15243u = parcel.readBundle(a.class.getClassLoader());
        this.f15238f = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("PlaybackState {state=");
        sb2.append(this.f15233a);
        sb2.append(", position=");
        sb2.append(this.f15234b);
        sb2.append(", buffered position=");
        sb2.append(this.f15235c);
        sb2.append(", speed=");
        sb2.append(this.f15236d);
        sb2.append(", updated=");
        sb2.append(this.f15240r);
        sb2.append(", actions=");
        sb2.append(this.f15237e);
        sb2.append(", error code=");
        sb2.append(this.f15238f);
        sb2.append(", error message=");
        sb2.append(this.f15239q);
        sb2.append(", custom actions=");
        sb2.append(this.f15241s);
        sb2.append(", active item id=");
        return AbstractC0492c.n(sb2, this.f15242t, "}");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f15233a);
        parcel.writeLong(this.f15234b);
        parcel.writeFloat(this.f15236d);
        parcel.writeLong(this.f15240r);
        parcel.writeLong(this.f15235c);
        parcel.writeLong(this.f15237e);
        TextUtils.writeToParcel(this.f15239q, parcel, i10);
        parcel.writeTypedList(this.f15241s);
        parcel.writeLong(this.f15242t);
        parcel.writeBundle(this.f15243u);
        parcel.writeInt(this.f15238f);
    }
}
