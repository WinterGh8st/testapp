package android.support.v4.media;

import T3.v;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new v(23);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f15222a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15223b;

    public RatingCompat(int i10, float f10) {
        this.f15222a = i10;
        this.f15223b = f10;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return this.f15222a;
    }

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("Rating:style=");
        sb2.append(this.f15222a);
        sb2.append(" rating=");
        float f10 = this.f15223b;
        sb2.append(f10 < 0.0f ? "unrated" : String.valueOf(f10));
        return sb2.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f15222a);
        parcel.writeFloat(this.f15223b);
    }
}
