package android.support.v4.media.session;

import A7.C0009b;
import A7.C0013f;
import B.AbstractC0027i;
import B.AbstractC0034p;
import B.AbstractC0037t;
import B.C0020b;
import B.C0022d;
import B.C0038u;
import B.N;
import B.Q;
import B.S;
import B.T;
import B0.y;
import C7.s;
import C9.C0106l0;
import C9.O0;
import E8.C0190p0;
import F9.U;
import G0.t;
import G6.C;
import G6.F0;
import J8.C0468i;
import J8.E;
import J8.H;
import J8.J;
import L.AbstractC0492c;
import L.AbstractC0497d1;
import L.AbstractC0517k0;
import L.C0489b;
import L.C0529o0;
import L.f2;
import Ma.m;
import N0.d;
import N1.AbstractComponentCallbacksC0583t;
import O.AbstractC0630v;
import O.C0610k;
import O.C0619o0;
import O.C0629u;
import O.R0;
import O.W;
import O.Z;
import P7.C0658f0;
import P7.f1;
import T9.f;
import T9.l;
import T9.x;
import U8.C0739y;
import U8.C0740z;
import U9.p;
import U9.w;
import W.n;
import W7.G;
import W7.I;
import Y1.K;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.TypefaceSpan;
import android.util.TypedValue;
import android.view.View;
import androidx.activity.ComponentActivity;
import androidx.lifecycle.InterfaceC0815o;
import androidx.lifecycle.q0;
import com.flamingotools.ws.R;
import com.google.protobuf.C0;
import com.stripe.android.financialconnections.features.linkaccountpicker.LinkAccountPickerState;
import com.stripe.android.financialconnections.features.linkaccountpicker.LinkAccountPickerViewModel;
import com.stripe.android.financialconnections.features.success.SuccessState;
import com.stripe.android.financialconnections.features.success.SuccessViewModel;
import com.stripe.android.financialconnections.model.FinancialConnectionsAccount$Category;
import com.stripe.android.financialconnections.model.FinancialConnectionsAccount$Subcategory;
import com.stripe.android.financialconnections.presentation.FinancialConnectionsSheetNativeViewModel;
import com.stripe.android.model.StripeIntent$Usage;
import java.io.ByteArrayInputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import org.json.JSONObject;
import p016b3.AbstractC0862l;
import p032c7.AbstractC0933i;
import p034c9.c;
import p050e0.C1049b;
import p050e0.C1051d;
import p050e0.C1058k;
import p050e0.D;
import p050e0.q;
import p050e0.r;
import p051e1.i;
import p051e1.j;
import p097ha.k;
import p100i0.AbstractC1125a;
import p100i0.C1129e;
import p112j.AbstractActivityC1169f;
import p162n9.C1227d;
import p162n9.E1;
import p162n9.F1;
import p183p8.AbstractC1427t0;
import p183p8.C1379d;
import p183p8.C1408m1;
import p183p8.C1424s0;
import p183p8.C1430u0;
import p183p8.d2;
import p195q8.h;
import p195q8.o;
import p197qa.v;
import p199r0.A;
import p199r0.AbstractC1464s;
import p199r0.B;
import p199r0.C1455i;
import p207r9.e;
import p207r9.g;
import p220t0.C1592i;
import p220t0.C1593j;
import p220t0.C1598o;
import p220t0.InterfaceC1594k;
import p232u0.AbstractC1678i0;
import p232u0.B0;
import p232u0.InterfaceC1709y0;
import p234u2.AbstractC1712b;
import p234u2.C1711a;
import p234u2.C1721k;
import p234u2.C1722l;
import p234u2.M;
import p234u2.P;
import p234u2.Y;
import p248v9.O;
import p259wa.InterfaceC1849f;
import p271y.x0;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static C1051d f15248a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static C1049b f15249b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static p074g0.b f15250c;

    public static boolean A(int i10, Rect rect, Rect rect2) {
        if (i10 != 17) {
            if (i10 != 33) {
                if (i10 != 66) {
                    if (i10 != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                }
            }
            return rect2.right >= rect.left && rect2.left <= rect.right;
        }
        return rect2.bottom >= rect.top && rect2.top <= rect.bottom;
    }

    public static void B(Object obj, StringBuilder sb2) {
        int iLastIndexOf;
        if (obj == null) {
            sb2.append("null");
            return;
        }
        String simpleName = obj.getClass().getSimpleName();
        if (simpleName.length() <= 0 && (iLastIndexOf = (simpleName = obj.getClass().getName()).lastIndexOf(46)) > 0) {
            simpleName = simpleName.substring(iLastIndexOf + 1);
        }
        sb2.append(simpleName);
        sb2.append('{');
        sb2.append(Integer.toHexString(System.identityHashCode(obj)));
    }

    public static SpannableString C(AbstractActivityC1169f abstractActivityC1169f, String str, c cVar) {
        k.f(cVar, "customization");
        SpannableString spannableString = new SpannableString(str);
        p034c9.a aVar = (p034c9.a) cVar;
        String str2 = aVar.f18280b;
        if (str2 != null) {
            spannableString.setSpan(new ForegroundColorSpan(Color.parseColor(str2)), 0, spannableString.length(), 0);
        }
        int i10 = aVar.f18281c;
        Integer numValueOf = Integer.valueOf(i10);
        if (i10 <= 0) {
            numValueOf = null;
        }
        if (numValueOf != null) {
            spannableString.setSpan(new AbsoluteSizeSpan((int) TypedValue.applyDimension(2, numValueOf.intValue(), abstractActivityC1169f.getResources().getDisplayMetrics())), 0, spannableString.length(), 0);
        }
        String str3 = aVar.f18279a;
        if (str3 != null) {
            spannableString.setSpan(new TypefaceSpan(str3), 0, spannableString.length(), 0);
        }
        return spannableString;
    }

    public static void D(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0030  */
    /* JADX WARN: Code duplicated, block: B:44:0x0071 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:55:0x0073 A[SYNTHETIC] */
    public static final boolean E(Set set, C1430u0 c1430u0, C0190p0 c0190p0) {
        C1379d c1379d;
        C1379d c1379d2;
        C1379d c1379d3;
        if (set != null) {
            Set set2 = set;
            ArrayList arrayList = new ArrayList(p.p0(set2, 10));
            Iterator it = set2.iterator();
            while (true) {
                boolean z3 = true;
                if (it.hasNext()) {
                    E e10 = (E) it.next();
                    if (k.b(e10, C0468i.f6483a)) {
                        if (c0190p0 == null || !c0190p0.f3378q) {
                            z3 = false;
                        }
                    } else {
                        if (!k.b(e10, J.f6462a)) {
                            throw new U();
                        }
                        boolean z5 = c0190p0 != null && c0190p0.f3379r;
                        C1424s0 c1424s0 = c1430u0.f27308D;
                        String str = null;
                        if ((c1424s0 != null ? c1424s0.f27293c : null) != null) {
                            if (((c1424s0 == null || (c1379d3 = c1424s0.f27291a) == null) ? null : c1379d3.f27015c) != null) {
                                if (((c1424s0 == null || (c1379d2 = c1424s0.f27291a) == null) ? null : c1379d2.f27014b) != null) {
                                    if (c1424s0 != null && (c1379d = c1424s0.f27291a) != null) {
                                        str = c1379d.f27017e;
                                    }
                                    if (str == null) {
                                        if (z5) {
                                            z3 = false;
                                        }
                                    }
                                } else if (z5) {
                                    z3 = false;
                                }
                            } else if (z5) {
                                z3 = false;
                            }
                        } else if (z5) {
                            z3 = false;
                        }
                    }
                    arrayList.add(Boolean.valueOf(z3));
                } else if (!arrayList.contains(Boolean.FALSE)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int F(Context context, String str) {
        int iC;
        int iMyPid = Process.myPid();
        int iMyUid = Process.myUid();
        String packageName = context.getPackageName();
        if (context.checkPermission(str, iMyPid, iMyUid) != -1) {
            String strD = i.d(str);
            if (strD != null) {
                if (packageName == null) {
                    String[] packagesForUid = context.getPackageManager().getPackagesForUid(iMyUid);
                    if (packagesForUid != null && packagesForUid.length > 0) {
                        packageName = packagesForUid[0];
                    }
                }
                int iMyUid2 = Process.myUid();
                String packageName2 = context.getPackageName();
                if (iMyUid2 == iMyUid && Objects.equals(packageName2, packageName) && Build.VERSION.SDK_INT >= 29) {
                    AppOpsManager appOpsManagerC = j.c(context);
                    iC = j.a(appOpsManagerC, strD, Binder.getCallingUid(), packageName);
                    if (iC == 0) {
                        iC = j.a(appOpsManagerC, strD, iMyUid, j.b(context));
                    }
                } else {
                    iC = i.c((AppOpsManager) i.a(context, AppOpsManager.class), strD, packageName);
                }
                if (iC != 0) {
                    return -2;
                }
            }
            return 0;
        }
        return -1;
    }

    public static final boolean G(Set set, C0190p0 c0190p0) {
        if (set != null) {
            Set set2 = set;
            ArrayList arrayList = new ArrayList(p.p0(set2, 10));
            Iterator it = set2.iterator();
            while (true) {
                boolean z3 = true;
                if (it.hasNext()) {
                    if (!k.b((C0468i) it.next(), C0468i.f6483a)) {
                        throw new U();
                    }
                    if (c0190p0 == null || !c0190p0.f3378q) {
                        z3 = false;
                    }
                    arrayList.add(Boolean.valueOf(z3));
                } else if (!arrayList.contains(Boolean.FALSE)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static m H(String str) {
        k.f(str, "<this>");
        Matcher matcher = m.f8760c.matcher(str);
        if (!matcher.lookingAt()) {
            throw new IllegalArgumentException(("No subtype found for: \"" + str + '\"').toString());
        }
        String strGroup = matcher.group(1);
        k.e(strGroup, "typeSubtype.group(1)");
        Locale locale = Locale.US;
        k.e(locale, "US");
        k.e(strGroup.toLowerCase(locale), "this as java.lang.String).toLowerCase(locale)");
        String strGroup2 = matcher.group(2);
        k.e(strGroup2, "typeSubtype.group(2)");
        k.e(strGroup2.toLowerCase(locale), "this as java.lang.String).toLowerCase(locale)");
        ArrayList arrayList = new ArrayList();
        Matcher matcher2 = m.f8761d.matcher(str);
        int iEnd = matcher.end();
        while (iEnd < str.length()) {
            matcher2.region(iEnd, str.length());
            if (!matcher2.lookingAt()) {
                StringBuilder sb2 = new StringBuilder("Parameter is not formatted correctly: \"");
                String strSubstring = str.substring(iEnd);
                k.e(strSubstring, "this as java.lang.String).substring(startIndex)");
                sb2.append(strSubstring);
                sb2.append("\" for: \"");
                throw new IllegalArgumentException(AbstractC0492c.o(sb2, str, '\"').toString());
            }
            String strGroup3 = matcher2.group(1);
            if (strGroup3 == null) {
                iEnd = matcher2.end();
            } else {
                String strGroup4 = matcher2.group(2);
                if (strGroup4 == null) {
                    strGroup4 = matcher2.group(3);
                } else if (v.N(strGroup4, "'") && v.F(strGroup4, "'", false) && strGroup4.length() > 2) {
                    strGroup4 = strGroup4.substring(1, strGroup4.length() - 1);
                    k.e(strGroup4, "this as java.lang.String…ing(startIndex, endIndex)");
                }
                arrayList.add(strGroup3);
                arrayList.add(strGroup4);
                iEnd = matcher2.end();
            }
        }
        Object[] array = arrayList.toArray(new String[0]);
        if (array != null) {
            return new m(str, (String[]) array);
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
    }

    public static final int I(t tVar, int i10) {
        k.f(tVar, "fontWeight");
        boolean z3 = tVar.compareTo(t.f4133d) >= 0;
        boolean z5 = i10 == 1;
        if (z5 && z3) {
            return 3;
        }
        if (z3) {
            return 1;
        }
        return z5 ? 2 : 0;
    }

    public static HashMap J() {
        HashMap map = new HashMap(286);
        ArrayList arrayList = new ArrayList(25);
        arrayList.add("US");
        arrayList.add("AG");
        arrayList.add("AI");
        arrayList.add("AS");
        arrayList.add("BB");
        arrayList.add("BM");
        arrayList.add("BS");
        arrayList.add("CA");
        arrayList.add("DM");
        arrayList.add("DO");
        arrayList.add("GD");
        arrayList.add("GU");
        arrayList.add("JM");
        arrayList.add("KN");
        arrayList.add("KY");
        arrayList.add("LC");
        arrayList.add("MP");
        arrayList.add("MS");
        arrayList.add("PR");
        arrayList.add("SX");
        arrayList.add("TC");
        arrayList.add("TT");
        arrayList.add("VC");
        arrayList.add("VG");
        arrayList.add("VI");
        map.put(1, arrayList);
        ArrayList arrayList2 = new ArrayList(2);
        arrayList2.add("RU");
        arrayList2.add("KZ");
        ArrayList arrayListL = AbstractC0933i.l(36, map, AbstractC0933i.l(34, map, AbstractC0933i.l(33, map, AbstractC0933i.l(32, map, AbstractC0933i.l(31, map, AbstractC0933i.l(30, map, AbstractC0933i.l(27, map, AbstractC0933i.l(20, map, AbstractC0933i.l(7, map, arrayList2, 1, "EG"), 1, "ZA"), 1, "GR"), 1, "NL"), 1, "BE"), 1, "FR"), 1, "ES"), 1, "HU"), 2, "IT");
        arrayListL.add("VA");
        map.put(39, arrayListL);
        ArrayList arrayList3 = new ArrayList(1);
        arrayList3.add("RO");
        ArrayList arrayListL2 = AbstractC0933i.l(43, map, AbstractC0933i.l(41, map, AbstractC0933i.l(40, map, arrayList3, 1, "CH"), 1, "AT"), 4, "GB");
        arrayListL2.add("GG");
        arrayListL2.add("IM");
        arrayListL2.add("JE");
        map.put(44, arrayListL2);
        ArrayList arrayList4 = new ArrayList(1);
        arrayList4.add("DK");
        ArrayList arrayListL3 = AbstractC0933i.l(46, map, AbstractC0933i.l(45, map, arrayList4, 1, "SE"), 2, "NO");
        arrayListL3.add("SJ");
        map.put(47, arrayListL3);
        ArrayList arrayList5 = new ArrayList(1);
        arrayList5.add("PL");
        ArrayList arrayListL4 = AbstractC0933i.l(60, map, AbstractC0933i.l(58, map, AbstractC0933i.l(57, map, AbstractC0933i.l(56, map, AbstractC0933i.l(55, map, AbstractC0933i.l(54, map, AbstractC0933i.l(53, map, AbstractC0933i.l(52, map, AbstractC0933i.l(51, map, AbstractC0933i.l(49, map, AbstractC0933i.l(48, map, arrayList5, 1, "DE"), 1, "PE"), 1, "MX"), 1, "CU"), 1, "AR"), 1, "BR"), 1, "CL"), 1, "CO"), 1, "VE"), 1, "MY"), 3, "AU");
        arrayListL4.add("CC");
        arrayListL4.add("CX");
        map.put(61, arrayListL4);
        ArrayList arrayList6 = new ArrayList(1);
        arrayList6.add("ID");
        ArrayList arrayListL5 = AbstractC0933i.l(211, map, AbstractC0933i.l(98, map, AbstractC0933i.l(95, map, AbstractC0933i.l(94, map, AbstractC0933i.l(93, map, AbstractC0933i.l(92, map, AbstractC0933i.l(91, map, AbstractC0933i.l(90, map, AbstractC0933i.l(86, map, AbstractC0933i.l(84, map, AbstractC0933i.l(82, map, AbstractC0933i.l(81, map, AbstractC0933i.l(66, map, AbstractC0933i.l(65, map, AbstractC0933i.l(64, map, AbstractC0933i.l(63, map, AbstractC0933i.l(62, map, arrayList6, 1, "PH"), 1, "NZ"), 1, "SG"), 1, "TH"), 1, "JP"), 1, "KR"), 1, "VN"), 1, "CN"), 1, "TR"), 1, "IN"), 1, "PK"), 1, "AF"), 1, "LK"), 1, "MM"), 1, "IR"), 1, "SS"), 2, "MA");
        arrayListL5.add("EH");
        map.put(212, arrayListL5);
        ArrayList arrayList7 = new ArrayList(1);
        arrayList7.add("DZ");
        ArrayList arrayListL6 = AbstractC0933i.l(261, map, AbstractC0933i.l(260, map, AbstractC0933i.l(258, map, AbstractC0933i.l(257, map, AbstractC0933i.l(256, map, AbstractC0933i.l(255, map, AbstractC0933i.l(254, map, AbstractC0933i.l(253, map, AbstractC0933i.l(252, map, AbstractC0933i.l(251, map, AbstractC0933i.l(250, map, AbstractC0933i.l(249, map, AbstractC0933i.l(248, map, AbstractC0933i.l(247, map, AbstractC0933i.l(246, map, AbstractC0933i.l(245, map, AbstractC0933i.l(244, map, AbstractC0933i.l(243, map, AbstractC0933i.l(242, map, AbstractC0933i.l(241, map, AbstractC0933i.l(240, map, AbstractC0933i.l(239, map, AbstractC0933i.l(238, map, AbstractC0933i.l(237, map, AbstractC0933i.l(236, map, AbstractC0933i.l(235, map, AbstractC0933i.l(234, map, AbstractC0933i.l(233, map, AbstractC0933i.l(232, map, AbstractC0933i.l(231, map, AbstractC0933i.l(230, map, AbstractC0933i.l(229, map, AbstractC0933i.l(228, map, AbstractC0933i.l(227, map, AbstractC0933i.l(226, map, AbstractC0933i.l(225, map, AbstractC0933i.l(224, map, AbstractC0933i.l(223, map, AbstractC0933i.l(222, map, AbstractC0933i.l(221, map, AbstractC0933i.l(220, map, AbstractC0933i.l(218, map, AbstractC0933i.l(216, map, AbstractC0933i.l(213, map, arrayList7, 1, "TN"), 1, "LY"), 1, "GM"), 1, "SN"), 1, "MR"), 1, "ML"), 1, "GN"), 1, "CI"), 1, "BF"), 1, "NE"), 1, "TG"), 1, "BJ"), 1, "MU"), 1, "LR"), 1, "SL"), 1, "GH"), 1, "NG"), 1, "TD"), 1, "CF"), 1, "CM"), 1, "CV"), 1, "ST"), 1, "GQ"), 1, "GA"), 1, "CG"), 1, "CD"), 1, "AO"), 1, "GW"), 1, "IO"), 1, "AC"), 1, "SC"), 1, "SD"), 1, "RW"), 1, "ET"), 1, "SO"), 1, "DJ"), 1, "KE"), 1, "TZ"), 1, "UG"), 1, "BI"), 1, "MZ"), 1, "ZM"), 1, "MG"), 2, "RE");
        arrayListL6.add("YT");
        map.put(262, arrayListL6);
        ArrayList arrayList8 = new ArrayList(1);
        arrayList8.add("ZW");
        ArrayList arrayListL7 = AbstractC0933i.l(269, map, AbstractC0933i.l(268, map, AbstractC0933i.l(267, map, AbstractC0933i.l(266, map, AbstractC0933i.l(265, map, AbstractC0933i.l(264, map, AbstractC0933i.l(263, map, arrayList8, 1, "NA"), 1, "MW"), 1, "LS"), 1, "BW"), 1, "SZ"), 1, "KM"), 2, "SH");
        arrayListL7.add("TA");
        map.put(290, arrayListL7);
        ArrayList arrayList9 = new ArrayList(1);
        arrayList9.add("ER");
        ArrayList arrayListL8 = AbstractC0933i.l(357, map, AbstractC0933i.l(356, map, AbstractC0933i.l(355, map, AbstractC0933i.l(354, map, AbstractC0933i.l(353, map, AbstractC0933i.l(352, map, AbstractC0933i.l(351, map, AbstractC0933i.l(350, map, AbstractC0933i.l(299, map, AbstractC0933i.l(298, map, AbstractC0933i.l(297, map, AbstractC0933i.l(291, map, arrayList9, 1, "AW"), 1, "FO"), 1, "GL"), 1, "GI"), 1, "PT"), 1, "LU"), 1, "IE"), 1, "IS"), 1, "AL"), 1, "MT"), 1, "CY"), 2, "FI");
        arrayListL8.add("AX");
        map.put(358, arrayListL8);
        ArrayList arrayList10 = new ArrayList(1);
        arrayList10.add("BG");
        ArrayList arrayListL9 = AbstractC0933i.l(509, map, AbstractC0933i.l(508, map, AbstractC0933i.l(507, map, AbstractC0933i.l(506, map, AbstractC0933i.l(505, map, AbstractC0933i.l(504, map, AbstractC0933i.l(503, map, AbstractC0933i.l(502, map, AbstractC0933i.l(501, map, AbstractC0933i.l(500, map, AbstractC0933i.l(423, map, AbstractC0933i.l(421, map, AbstractC0933i.l(420, map, AbstractC0933i.l(389, map, AbstractC0933i.l(387, map, AbstractC0933i.l(386, map, AbstractC0933i.l(385, map, AbstractC0933i.l(383, map, AbstractC0933i.l(382, map, AbstractC0933i.l(381, map, AbstractC0933i.l(380, map, AbstractC0933i.l(378, map, AbstractC0933i.l(377, map, AbstractC0933i.l(376, map, AbstractC0933i.l(375, map, AbstractC0933i.l(374, map, AbstractC0933i.l(373, map, AbstractC0933i.l(372, map, AbstractC0933i.l(371, map, AbstractC0933i.l(370, map, AbstractC0933i.l(359, map, arrayList10, 1, "LT"), 1, "LV"), 1, "EE"), 1, "MD"), 1, "AM"), 1, "BY"), 1, "AD"), 1, "MC"), 1, "SM"), 1, "UA"), 1, "RS"), 1, "ME"), 1, "XK"), 1, "HR"), 1, "SI"), 1, "BA"), 1, "MK"), 1, "CZ"), 1, "SK"), 1, "LI"), 1, "FK"), 1, "BZ"), 1, "GT"), 1, "SV"), 1, "HN"), 1, "NI"), 1, "CR"), 1, "PA"), 1, "PM"), 1, "HT"), 3, "GP");
        arrayListL9.add("BL");
        arrayListL9.add("MF");
        map.put(590, arrayListL9);
        ArrayList arrayList11 = new ArrayList(1);
        arrayList11.add("BO");
        ArrayList arrayListL10 = AbstractC0933i.l(598, map, AbstractC0933i.l(597, map, AbstractC0933i.l(596, map, AbstractC0933i.l(595, map, AbstractC0933i.l(594, map, AbstractC0933i.l(593, map, AbstractC0933i.l(592, map, AbstractC0933i.l(591, map, arrayList11, 1, "GY"), 1, "EC"), 1, "GF"), 1, "PY"), 1, "MQ"), 1, "SR"), 1, "UY"), 2, "CW");
        arrayListL10.add("BQ");
        map.put(599, arrayListL10);
        ArrayList arrayList12 = new ArrayList(1);
        arrayList12.add("TL");
        map.put(998, AbstractC0933i.l(996, map, AbstractC0933i.l(995, map, AbstractC0933i.l(994, map, AbstractC0933i.l(993, map, AbstractC0933i.l(992, map, AbstractC0933i.l(979, map, AbstractC0933i.l(977, map, AbstractC0933i.l(976, map, AbstractC0933i.l(975, map, AbstractC0933i.l(974, map, AbstractC0933i.l(973, map, AbstractC0933i.l(972, map, AbstractC0933i.l(971, map, AbstractC0933i.l(970, map, AbstractC0933i.l(968, map, AbstractC0933i.l(967, map, AbstractC0933i.l(966, map, AbstractC0933i.l(965, map, AbstractC0933i.l(964, map, AbstractC0933i.l(963, map, AbstractC0933i.l(962, map, AbstractC0933i.l(961, map, AbstractC0933i.l(960, map, AbstractC0933i.l(888, map, AbstractC0933i.l(886, map, AbstractC0933i.l(883, map, AbstractC0933i.l(882, map, AbstractC0933i.l(881, map, AbstractC0933i.l(880, map, AbstractC0933i.l(878, map, AbstractC0933i.l(870, map, AbstractC0933i.l(856, map, AbstractC0933i.l(855, map, AbstractC0933i.l(853, map, AbstractC0933i.l(852, map, AbstractC0933i.l(850, map, AbstractC0933i.l(808, map, AbstractC0933i.l(800, map, AbstractC0933i.l(692, map, AbstractC0933i.l(691, map, AbstractC0933i.l(690, map, AbstractC0933i.l(689, map, AbstractC0933i.l(688, map, AbstractC0933i.l(687, map, AbstractC0933i.l(686, map, AbstractC0933i.l(685, map, AbstractC0933i.l(683, map, AbstractC0933i.l(682, map, AbstractC0933i.l(681, map, AbstractC0933i.l(680, map, AbstractC0933i.l(679, map, AbstractC0933i.l(678, map, AbstractC0933i.l(677, map, AbstractC0933i.l(676, map, AbstractC0933i.l(675, map, AbstractC0933i.l(674, map, AbstractC0933i.l(673, map, AbstractC0933i.l(672, map, AbstractC0933i.l(670, map, arrayList12, 1, "NF"), 1, "BN"), 1, "NR"), 1, "PG"), 1, "TO"), 1, "SB"), 1, "VU"), 1, "FJ"), 1, "PW"), 1, "WF"), 1, "CK"), 1, "NU"), 1, "WS"), 1, "KI"), 1, "NC"), 1, "TV"), 1, "PF"), 1, "TK"), 1, "FM"), 1, "MH"), 1, "001"), 1, "001"), 1, "KP"), 1, "HK"), 1, "MO"), 1, "KH"), 1, "LA"), 1, "001"), 1, "001"), 1, "BD"), 1, "001"), 1, "001"), 1, "001"), 1, "TW"), 1, "001"), 1, "MV"), 1, "LB"), 1, "JO"), 1, "SY"), 1, "IQ"), 1, "KW"), 1, "SA"), 1, "YE"), 1, "OM"), 1, "PS"), 1, "AE"), 1, "IL"), 1, "BH"), 1, "QA"), 1, "BT"), 1, "MN"), 1, "NP"), 1, "001"), 1, "TJ"), 1, "TM"), 1, "AZ"), 1, "GE"), 1, "KG"), 1, "UZ"));
        return map;
    }

    public static C0 K(F0 f10) {
        return f10.L().y("__local_write_time__").O();
    }

    public static final List L(d2 d2Var, C0190p0 c0190p0, g gVar) {
        List listJ;
        k.f(gVar, "lpmRepository");
        if (d2Var == null || (listJ = d2Var.j()) == null) {
            return U9.v.f12751a;
        }
        ArrayList arrayList = new ArrayList();
        Iterator it = listJ.iterator();
        while (it.hasNext()) {
            e eVarB = gVar.b((String) it.next());
            if (eVarB != null) {
                arrayList.add(eVarB);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        int size = arrayList.size();
        int i10 = 0;
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList.get(i11);
            i11++;
            if (O((e) obj, d2Var, c0190p0) != null) {
                arrayList2.add(obj);
            }
        }
        ArrayList arrayList3 = new ArrayList();
        int size2 = arrayList2.size();
        while (i10 < size2) {
            Object obj2 = arrayList2.get(i10);
            i10++;
            e eVar = (e) obj2;
            if (!d2Var.v() || !d2Var.x().contains(eVar.f27877a)) {
                arrayList3.add(obj2);
            }
        }
        return arrayList3;
    }

    public static F0 M(F0 f10) {
        F0 f0X = f10.L().x("__previous_value__");
        return R(f0X) ? M(f0X) : f0X;
    }

    public static final Q N(A a3) {
        k.f(a3, "<this>");
        Object objI = a3.i();
        if (objI instanceof Q) {
            return (Q) objI;
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:25:0x006a  */
    /* JADX WARN: Code duplicated, block: B:27:0x006d  */
    /* JADX WARN: Code duplicated, block: B:28:0x006f  */
    /* JADX WARN: Code duplicated, block: B:63:0x00cc A[RETURN] */
    public static final E1 O(e eVar, d2 d2Var, C0190p0 c0190p0) {
        String str;
        boolean zHas;
        boolean z3;
        JSONObject jSONObjectOptJSONObject;
        k.f(eVar, "<this>");
        k.f(d2Var, "stripeIntent");
        F1 f10 = eVar.f27886j;
        boolean z5 = false;
        E1 e10 = new E1(f10, false, false);
        E1 e11 = new E1(f10, false, true);
        E1 e12 = new E1(f10, true, false);
        List listJ = d2Var.j();
        String str2 = eVar.f27877a;
        if (listJ.contains(str2)) {
            boolean z10 = d2Var instanceof C1430u0;
            H h10 = eVar.f27885i;
            if (z10) {
                C1430u0 c1430u0 = (C1430u0) d2Var;
                StripeIntent$Usage stripeIntent$Usage = c1430u0.f27306B;
                int i10 = stripeIntent$Usage == null ? -1 : AbstractC1427t0.f27300a[stripeIntent$Usage.ordinal()];
                if (i10 == -1) {
                    str = c1430u0.f27312H;
                    if (str != null || (jSONObjectOptJSONObject = new JSONObject(str).optJSONObject(str2)) == null) {
                        zHas = false;
                    } else {
                        zHas = jSONObjectOptJSONObject.has("setup_future_usage");
                    }
                    if (zHas) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                } else if (i10 == 1 || i10 == 2) {
                    z3 = true;
                } else {
                    if (i10 != 3) {
                        throw new U();
                    }
                    str = c1430u0.f27312H;
                    if (str != null) {
                        zHas = false;
                    } else {
                        zHas = false;
                    }
                    if (zHas) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                }
                if (z3) {
                    if (h10.a(str2) && G(h10.f6442b, c0190p0) && E(h10.f6441a, c1430u0, c0190p0)) {
                        z5 = true;
                    }
                    if (z5) {
                        return e11;
                    }
                } else {
                    if ((c0190p0 != null ? c0190p0.f3373b : null) != null && h10.a(str2) && E(h10.f6441a, c1430u0, c0190p0) && G(h10.f6442b, c0190p0)) {
                        z5 = true;
                    }
                    if (z5) {
                        return e12;
                    }
                    if (E(h10.f6441a, c1430u0, c0190p0)) {
                        return e10;
                    }
                }
            } else {
                if (!(d2Var instanceof C1408m1)) {
                    throw new U();
                }
                if (h10.a(str2) && G(h10.f6442b, c0190p0)) {
                    z5 = true;
                }
                if (z5) {
                    return e11;
                }
            }
        }
        return null;
    }

    public static final float P(Q q10) {
        if (q10 != null) {
            return q10.f541a;
        }
        return 0.0f;
    }

    public static boolean Q(int i10, Rect rect, Rect rect2) {
        if (i10 == 17) {
            int i11 = rect.right;
            int i12 = rect2.right;
            return (i11 > i12 || rect.left >= i12) && rect.left > rect2.left;
        }
        if (i10 == 33) {
            int i13 = rect.bottom;
            int i14 = rect2.bottom;
            return (i13 > i14 || rect.top >= i14) && rect.top > rect2.top;
        }
        if (i10 == 66) {
            int i15 = rect.left;
            int i16 = rect2.left;
            return (i15 < i16 || rect.right <= i16) && rect.right < rect2.right;
        }
        if (i10 != 130) {
            throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
        }
        int i17 = rect.top;
        int i18 = rect2.top;
        return (i17 < i18 || rect.bottom <= i18) && rect.bottom < rect2.bottom;
    }

    public static boolean R(F0 f10) {
        F0 f0X = f10 == null ? null : f10.L().x("__type__");
        return f0X != null && "server_timestamp".equals(f0X.N());
    }

    public static T9.e S(f fVar, p084ga.a aVar) {
        k.f(aVar, "initializer");
        int iOrdinal = fVar.ordinal();
        if (iOrdinal == 0) {
            return new l(aVar);
        }
        T9.t tVar = T9.t.f11976a;
        if (iOrdinal == 1) {
            T9.k kVar = new T9.k();
            kVar.f11962a = aVar;
            kVar.f11963b = tVar;
            return kVar;
        }
        if (iOrdinal != 2) {
            throw new U();
        }
        x xVar = new x();
        xVar.f11980a = aVar;
        xVar.f11981b = tVar;
        return xVar;
    }

    public static l T(p084ga.a aVar) {
        k.f(aVar, "initializer");
        return new l(aVar);
    }

    public static int U(int i10, Rect rect, Rect rect2) {
        int i11;
        int i12;
        if (i10 == 17) {
            i11 = rect.left;
            i12 = rect2.right;
        } else if (i10 == 33) {
            i11 = rect.top;
            i12 = rect2.bottom;
        } else if (i10 == 66) {
            i11 = rect2.left;
            i12 = rect.right;
        } else {
            if (i10 != 130) {
                throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
            }
            i11 = rect2.top;
            i12 = rect.bottom;
        }
        return Math.max(0, i11 - i12);
    }

    public static Typeface V(Configuration configuration, Typeface typeface) {
        if (Build.VERSION.SDK_INT < 31 || configuration.fontWeightAdjustment == Integer.MAX_VALUE || configuration.fontWeightAdjustment == 0 || typeface == null) {
            return null;
        }
        return Typeface.create(typeface, com.bumptech.glide.e.t(configuration.fontWeightAdjustment + typeface.getWeight(), 1, 1000), typeface.isItalic());
    }

    public static int W(int i10, Rect rect, Rect rect2) {
        if (i10 != 17) {
            if (i10 != 33) {
                if (i10 != 66) {
                    if (i10 != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                }
            }
            return Math.abs(((rect.width() / 2) + rect.left) - ((rect2.width() / 2) + rect2.left));
        }
        return Math.abs(((rect.height() / 2) + rect.top) - ((rect2.height() / 2) + rect2.top));
    }

    public static X509Certificate X(byte[] bArr) throws CertificateException {
        if (bArr == null || bArr.length == 0) {
            return null;
        }
        Certificate certificateGenerateCertificate = CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(bArr));
        if (certificateGenerateCertificate instanceof X509Certificate) {
            return (X509Certificate) certificateGenerateCertificate;
        }
        throw new CertificateException("Not a X.509 certificate: " + certificateGenerateCertificate.getType());
    }

    public static final boolean Y(String str) {
        k.f(str, "method");
        return (str.equals("GET") || str.equals("HEAD")) ? false : true;
    }

    public static final Y1.A Z(K[] kArr, C0629u c0629u) {
        k.f(kArr, "navigators");
        c0629u.a0(-312215566);
        Context context = (Context) c0629u.l(p232u0.H.f29678b);
        Y1.A a3 = (Y1.A) p029c4.a.T0(Arrays.copyOf(kArr, kArr.length), n.a(Z1.l.f14462a, new J7.g(context, 16)), new C0106l0(context, 2), c0629u, 4);
        for (K k : kArr) {
            a3.f13984v.a(k);
        }
        c0629u.u(false);
        return a3;
    }

    public static final void a(boolean z3, p084ga.c cVar, f1 f1Var, V.a aVar, C0629u c0629u, int i10) {
        long j10;
        String strC;
        int i11;
        boolean z5;
        long j11;
        C0629u c0629u2;
        String str;
        int i12 = 0;
        k.f(cVar, "onAccountClicked");
        c0629u.b0(-5909596);
        c0629u.a0(1157296644);
        boolean zF = c0629u.f(f1Var);
        Object objE = c0629u.E();
        W w9 = C0610k.f9587a;
        if (zF || objE == w9) {
            objE = new d(f1Var.f10381j != null ? 10 : 12);
            c0629u.m0(objE);
        }
        c0629u.u(false);
        float f10 = ((d) objE).f8968a;
        c0629u.a0(-492369756);
        Object objE2 = c0629u.E();
        if (objE2 == w9) {
            objE2 = H.f.a(8);
            c0629u.m0(objE2);
        }
        c0629u.u(false);
        H.e eVar = (H.e) objE2;
        Z.j jVar = Z.j.f14412b;
        Z.m mVarY = p168o5.b.y(androidx.compose.foundation.layout.d.d(jVar, 1.0f), eVar);
        float f11 = z3 ? 2 : 1;
        if (z3) {
            c0629u.a0(-2124194779);
            Z7.b bVar = (Z7.b) c0629u.l(Z7.g.f14782e);
            c0629u.u(false);
            j10 = bVar.k;
        } else {
            c0629u.a0(-2124194779);
            Z7.b bVar2 = (Z7.b) c0629u.l(Z7.g.f14782e);
            c0629u.u(false);
            j10 = bVar2.f14740d;
        }
        Z.m mVarW = p003a.a.w(p195q8.e.b(mVarY, f11, j10, eVar), f1Var.b(), new A7.k(i12, cVar, f1Var), 6);
        float f12 = 16;
        Z.m mVarI = androidx.compose.foundation.layout.c.i(mVarW, f12, f10);
        c0629u.a0(733328855);
        B bC = AbstractC0034p.c(Z.a.f14388a, false, c0629u);
        c0629u.a0(-1323940314);
        R0 r7 = p232u0.W.f29758e;
        N0.b bVar3 = (N0.b) c0629u.l(r7);
        R0 r10 = p232u0.W.k;
        N0.j jVar2 = (N0.j) c0629u.l(r10);
        R0 r11 = p232u0.W.f29768p;
        B0 b10 = (B0) c0629u.l(r11);
        InterfaceC1594k.f29156n.getClass();
        C1598o c1598o = C1593j.f29148b;
        V.a aVarI = h.i(mVarI);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        C1592i c1592i = C1593j.f29152f;
        AbstractC0630v.P(c0629u, c1592i, bC);
        C1592i c1592i2 = C1593j.f29150d;
        AbstractC0630v.P(c0629u, c1592i2, bVar3);
        C1592i c1592i3 = C1593j.f29153g;
        AbstractC0630v.P(c0629u, c1592i3, jVar2);
        C1592i c1592i4 = C1593j.f29154h;
        AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u, b10, c1592i4, c0629u), c0629u, 2058660585);
        C0022d c0022d = AbstractC0027i.f619a;
        Z.c cVar2 = Z.a.f14397t;
        c0629u.a0(693286680);
        B bA = S.a(c0022d, cVar2, c0629u);
        c0629u.a0(-1323940314);
        N0.b bVar4 = (N0.b) c0629u.l(r7);
        N0.j jVar3 = (N0.j) c0629u.l(r10);
        B0 b11 = (B0) c0629u.l(r11);
        V.a aVarI2 = h.i(jVar);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        AbstractC0630v.P(c0629u, c1592i, bA);
        AbstractC0630v.P(c0629u, c1592i2, bVar4);
        AbstractC0630v.P(c0629u, c1592i3, jVar3);
        AbstractC1464s.m(0, aVarI2, p015b2.a.c(c0629u, b11, c1592i4, c0629u), c0629u, 2058660585);
        T t10 = T.f545a;
        aVar.I(t10, c0629u, Integer.valueOf(6 | ((i10 >> 6) & 112)));
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, f12));
        c0629u.a0(835035373);
        c0629u.a0(131376579);
        Locale localeB = p144m1.j.d(p144m1.e.a((Configuration) c0629u.l(p232u0.H.f29677a))).b(0);
        if (localeB == null) {
            localeB = Locale.getDefault();
        }
        boolean zBooleanValue = ((Boolean) c0629u.l(AbstractC1678i0.f29802a)).booleanValue();
        Integer num = f1Var.f10378g;
        if (num == null || (str = f1Var.f10379h) == null) {
            c0629u.u(false);
            strC = null;
        } else {
            if (zBooleanValue) {
                strC = str + num;
            } else {
                Map map = p269x9.a.f32061a;
                long jIntValue = num.intValue();
                k.e(localeB, "locale");
                strC = p269x9.a.a(jIntValue, str, localeB);
            }
            c0629u.u(false);
        }
        boolean zB = f1Var.b();
        String strT = f1Var.f10375d;
        if (!zB || strC != null) {
            strT = AbstractC0492c.t(strT, " ", f1Var.c());
        }
        if (!f1Var.b()) {
            strC = f1Var.f10384n;
        } else if (strC == null) {
            strC = f1Var.c().length() > 0 ? f1Var.c() : null;
        }
        c0629u.u(false);
        Z.m mVarA = T.a(t10, jVar, 0.7f);
        c0629u.a0(-483455358);
        B bA2 = AbstractC0037t.a(AbstractC0027i.f621c, Z.a.f14399v, c0629u);
        c0629u.a0(-1323940314);
        N0.b bVar5 = (N0.b) c0629u.l(r7);
        N0.j jVar4 = (N0.j) c0629u.l(r10);
        B0 b12 = (B0) c0629u.l(r11);
        V.a aVarI3 = h.i(mVarA);
        c0629u.d0();
        String str2 = strC;
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        AbstractC0630v.P(c0629u, c1592i, bA2);
        AbstractC0630v.P(c0629u, c1592i2, bVar5);
        AbstractC0630v.P(c0629u, c1592i3, jVar4);
        AbstractC1464s.m(0, aVarI3, p015b2.a.c(c0629u, b12, c1592i4, c0629u), c0629u, 2058660585);
        if (f1Var.b()) {
            c0629u.a0(2038380160);
            c0629u.a0(-2124194779);
            Z7.b bVar6 = (Z7.b) c0629u.l(Z7.g.f14782e);
            c0629u.u(false);
            long j12 = bVar6.f14743g;
            c0629u.u(false);
            j11 = j12;
            i11 = -2124194779;
            z5 = false;
        } else {
            c0629u.a0(2038380258);
            i11 = -2124194779;
            c0629u.a0(-2124194779);
            Z7.b bVar7 = (Z7.b) c0629u.l(Z7.g.f14782e);
            z5 = false;
            c0629u.u(false);
            j11 = bVar7.f14745i;
            c0629u.u(false);
        }
        c0629u.a0(1649734758);
        R0 r12 = Z7.g.f14781d;
        Z7.d dVar = (Z7.d) c0629u.l(r12);
        c0629u.u(z5);
        boolean z10 = z5;
        f2.b(strT, null, j11, 0L, null, null, 0L, null, 0L, 2, false, 1, 0, null, dVar.f14762g, c0629u, 0, 3120, 55290);
        if (str2 == null) {
            c0629u2 = c0629u;
        } else {
            AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, 4));
            c0629u.a0(i11);
            Z7.b bVar8 = (Z7.b) c0629u.l(Z7.g.f14782e);
            c0629u.u(z10);
            long j13 = bVar8.f14745i;
            c0629u.a0(1649734758);
            Z7.d dVar2 = (Z7.d) c0629u.l(r12);
            c0629u.u(z10);
            C.n(str2, null, j13, 0L, 0L, 0L, false, null, dVar2.f14766l, (char) 0, 0, c0629u, 0);
            c0629u2 = c0629u;
        }
        AbstractC1464s.n(c0629u2, z10, true, z10, z10);
        AbstractC1464s.n(c0629u2, z10, true, z10, z10);
        C0619o0 c0619o0E = AbstractC1464s.e(c0629u2, z10, true, z10, z10);
        if (c0619o0E == null) {
            return;
        }
        c0619o0E.f9606d = new A7.l(z3, cVar, f1Var, aVar, i10, 0);
    }

    public static final void a0(Object[] objArr, int i10, int i11) {
        k.f(objArr, "<this>");
        while (i10 < i11) {
            objArr[i10] = null;
            i10++;
        }
    }

    public static final void b(G g10, C0629u c0629u, int i10) {
        C0629u c0629u2 = c0629u;
        c0629u2.b0(-87128655);
        if (((i10 | (c0629u2.f(g10) ? 4 : 2)) & 11) == 2 && c0629u2.C()) {
            c0629u2.U();
        } else {
            Z.j jVar = Z.j.f14412b;
            float f10 = 8;
            Z.m mVarY = p168o5.b.y(androidx.compose.foundation.layout.d.d(jVar, 1.0f), H.f.a(f10));
            long j10 = Z7.a.f14728i;
            D d10 = p050e0.E.f21690a;
            Z.m mVarB = androidx.compose.foundation.a.b(p195q8.e.b(mVarY, 1, j10, d10), Z7.a.f14729j, d10);
            float f11 = 12;
            Z.m mVarH = androidx.compose.foundation.layout.c.h(mVarB, f11);
            c0629u2.a0(733328855);
            B bC = AbstractC0034p.c(Z.a.f14388a, false, c0629u2);
            c0629u2.a0(-1323940314);
            R0 r7 = p232u0.W.f29758e;
            N0.b bVar = (N0.b) c0629u2.l(r7);
            R0 r10 = p232u0.W.k;
            N0.j jVar2 = (N0.j) c0629u2.l(r10);
            R0 r11 = p232u0.W.f29768p;
            B0 b10 = (B0) c0629u2.l(r11);
            InterfaceC1594k.f29156n.getClass();
            C1598o c1598o = C1593j.f29148b;
            V.a aVarI = h.i(mVarH);
            c0629u2.d0();
            if (c0629u2.M) {
                c0629u2.n(c1598o);
            } else {
                c0629u2.o0();
            }
            c0629u2.f9699x = false;
            C1592i c1592i = C1593j.f29152f;
            AbstractC0630v.P(c0629u2, c1592i, bC);
            C1592i c1592i2 = C1593j.f29150d;
            AbstractC0630v.P(c0629u2, c1592i2, bVar);
            C1592i c1592i3 = C1593j.f29153g;
            AbstractC0630v.P(c0629u2, c1592i3, jVar2);
            C1592i c1592i4 = C1593j.f29154h;
            AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u2, b10, c1592i4, c0629u2), c0629u2, 2058660585);
            c0629u2.a0(693286680);
            B bA = S.a(AbstractC0027i.f619a, Z.a.f14396s, c0629u2);
            c0629u2.a0(-1323940314);
            N0.b bVar2 = (N0.b) c0629u2.l(r7);
            N0.j jVar3 = (N0.j) c0629u2.l(r10);
            B0 b11 = (B0) c0629u2.l(r11);
            V.a aVarI2 = h.i(jVar);
            c0629u2.d0();
            if (c0629u2.M) {
                c0629u2.n(c1598o);
            } else {
                c0629u2.o0();
            }
            c0629u2.f9699x = false;
            AbstractC0630v.P(c0629u2, c1592i, bA);
            AbstractC0630v.P(c0629u2, c1592i2, bVar2);
            AbstractC0630v.P(c0629u2, c1592i3, jVar3);
            AbstractC1464s.m(0, aVarI2, p015b2.a.c(c0629u2, b11, c1592i4, c0629u2), c0629u2, 2058660585);
            Z.m mVarF = androidx.compose.foundation.layout.c.f(androidx.compose.foundation.layout.d.k(jVar, f11), 0, 2);
            p087h0.b bVarK = o.k(R.drawable.stripe_ic_warning, c0629u2);
            c0629u2.a0(-2124194779);
            R0 r12 = Z7.g.f14782e;
            Z7.b bVar3 = (Z7.b) c0629u2.l(r12);
            c0629u2.u(false);
            AbstractC0517k0.a(bVarK, null, mVarF, bVar3.f14749n, c0629u2, 440, 0);
            AbstractC0862l.m(c0629u2, androidx.compose.foundation.layout.d.k(jVar, f10));
            g10.getClass();
            String string = p054e4.e.Q0(g10, c0629u).toString();
            c0629u2.a0(1649734758);
            Z7.d dVar = (Z7.d) c0629u2.l(Z7.g.f14781d);
            c0629u2.u(false);
            B0.D d11 = dVar.f14765j;
            c0629u2.a0(-2124194779);
            Z7.b bVar4 = (Z7.b) c0629u2.l(r12);
            c0629u2.u(false);
            f2.b(string, null, 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, B0.D.a(d11, bVar4.f14744h, 0L, null, null, 0L, null, 4194302), c0629u, 0, 0, 65534);
            c0629u2 = c0629u;
            AbstractC1464s.n(c0629u2, false, true, false, false);
            AbstractC1464s.n(c0629u2, false, true, false, false);
        }
        C0619o0 c0619o0W = c0629u2.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new A7.A(g10, i10, 15);
    }

    public static final N b0(int i10, p084ga.h hVar, float f10, Ua.l lVar) {
        p096h9.i.n(i10, "orientation");
        p096h9.i.n(1, "crossAxisSize");
        return new N(i10, hVar, f10, lVar);
    }

    public static final void c(int i10, C0629u c0629u) {
        C0629u c0629u2;
        c0629u.b0(-172812001);
        if (i10 == 0 && c0629u.C()) {
            c0629u.U();
            c0629u2 = c0629u;
        } else {
            c0629u2 = c0629u;
            E5.b.g(p197qa.a.o(R.string.stripe_affirm_buy_now_pay_later, c0629u), androidx.compose.foundation.layout.c.j(Z.j.f14412b, 0.0f, 8, 1), U9.B.V(new T9.h("affirm", new A9.a(R.drawable.stripe_ic_affirm_logo, R.string.stripe_paymentsheet_payment_method_affirm, null))), p229t9.l.f(c0629u).f29408e, C0529o0.c(c0629u).f7882f, false, null, 0, null, c0629u2, 48, 480);
        }
        C0619o0 c0619o0W = c0629u2.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new C1227d(2);
    }

    public static byte c0(Boolean bool) {
        if (bool != null) {
            return !bool.booleanValue() ? (byte) 0 : (byte) 1;
        }
        return (byte) -1;
    }

    public static final long d(float f10, float f11) {
        long jFloatToIntBits = (((long) Float.floatToIntBits(f11)) & 4294967295L) | (Float.floatToIntBits(f10) << 32);
        int i10 = p038d0.a.f21392b;
        return jFloatToIntBits;
    }

    public static Boolean d0(byte b10) {
        if (b10 == 0) {
            return Boolean.FALSE;
        }
        if (b10 != 1) {
            return null;
        }
        return Boolean.TRUE;
    }

    public static final void e(V.a aVar, V.a aVar2, C0629u c0629u, int i10) {
        c0629u.b0(1374211054);
        if ((i10 & 91) == 18 && c0629u.C()) {
            c0629u.U();
        } else {
            c0629u.a0(-2124194779);
            R0 r7 = Z7.g.f14782e;
            Z7.b bVar = (Z7.b) c0629u.l(r7);
            c0629u.u(false);
            long j10 = bVar.f14737a;
            c0629u.a0(-2124194779);
            Z7.b bVar2 = (Z7.b) c0629u.l(r7);
            c0629u.u(false);
            AbstractC0497d1.a(null, null, aVar, null, null, null, 0, false, null, 0.0f, 0L, 0L, 0L, j10, bVar2.f14743g, aVar2, c0629u, 384, 12582912, 32763);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new C0489b(i10, 1, aVar, aVar2);
    }

    public static final void f(LinkAccountPickerState linkAccountPickerState, D7.g gVar, B7.n nVar, B7.m mVar, D7.h hVar, D7.h hVar2, B7.n nVar2, C0629u c0629u, int i10) {
        c0629u.b0(-1230383542);
        x0 x0VarP = p195q8.n.p(c0629u);
        e(Ua.l.u(c0629u, 161319033, new C7.i(x0VarP, gVar, i10, 2)), Ua.l.u(c0629u, -300487107, new D7.c(linkAccountPickerState, mVar, hVar2, hVar, nVar2, x0VarP, i10, nVar)), c0629u, 54);
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new D7.d(linkAccountPickerState, gVar, nVar, mVar, hVar, hVar2, nVar2, i10, 0);
    }

    public static final void g(int i10, C0629u c0629u) {
        c0629u.b0(-85990089);
        if (i10 == 0 && c0629u.C()) {
            c0629u.U();
        } else {
            c0629u.a0(512170640);
            androidx.lifecycle.D d10 = (androidx.lifecycle.D) c0629u.l(p232u0.H.f29680d);
            ComponentActivity componentActivityL = p195q8.c.l((Context) c0629u.l(p232u0.H.f29678b));
            if (componentActivityL == null) {
                throw new IllegalStateException("Composable is not hosted in a ComponentActivity!");
            }
            androidx.lifecycle.x0 x0Var = d10 instanceof androidx.lifecycle.x0 ? (androidx.lifecycle.x0) d10 : null;
            if (x0Var == null) {
                throw new IllegalStateException("LifecycleOwner must be a ViewModelStoreOwner!");
            }
            p076g2.e eVar = d10 instanceof p076g2.e ? (p076g2.e) d10 : null;
            if (eVar == null) {
                throw new IllegalStateException("LifecycleOwner must be a SavedStateRegistryOwner!");
            }
            p056e7.n nVarB = eVar.b();
            p097ha.e eVarA = p097ha.v.a(LinkAccountPickerViewModel.class);
            View view = (View) c0629u.l(p232u0.H.f29682f);
            Object[] objArr = {d10, componentActivityL, x0Var, nVarB};
            c0629u.a0(-568225417);
            boolean zF = false;
            for (int i11 = 0; i11 < 4; i11++) {
                zF |= c0629u.f(objArr[i11]);
            }
            Object objE = c0629u.E();
            Object obj = C0610k.f9587a;
            if (zF || objE == obj) {
                AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583tM = d10 instanceof AbstractComponentCallbacksC0583t ? (AbstractComponentCallbacksC0583t) d10 : null;
                if (abstractComponentCallbacksC0583tM == null) {
                    abstractComponentCallbacksC0583tM = p195q8.c.m(view);
                }
                if (abstractComponentCallbacksC0583tM != null) {
                    Bundle bundle = abstractComponentCallbacksC0583tM.f9251f;
                    objE = new C1721k(componentActivityL, bundle != null ? bundle.get("mavericks:arg") : null, abstractComponentCallbacksC0583tM);
                } else {
                    Bundle extras = componentActivityL.getIntent().getExtras();
                    objE = new C1711a(componentActivityL, extras != null ? extras.get("mavericks:arg") : null, x0Var, nVarB);
                }
                c0629u.m0(objE);
            }
            c0629u.u(false);
            Y y10 = (Y) objE;
            c0629u.a0(511388516);
            boolean zF2 = c0629u.f(eVarA) | c0629u.f(y10);
            Object objE2 = c0629u.E();
            if (zF2 || objE2 == obj) {
                objE2 = P.a(C.R(eVarA), LinkAccountPickerState.class, y10, C.R(eVarA).getName());
                c0629u.m0(objE2);
            }
            c0629u.u(false);
            c0629u.u(false);
            LinkAccountPickerViewModel linkAccountPickerViewModel = (LinkAccountPickerViewModel) ((M) objE2);
            FinancialConnectionsSheetNativeViewModel financialConnectionsSheetNativeViewModelQ = Ua.d.Q(c0629u);
            Z zF3 = p195q8.c.f(linkAccountPickerViewModel, c0629u);
            p143m0.c.a(true, D7.f.f2499a, c0629u, 54, 0);
            f((LinkAccountPickerState) zF3.getValue(), new D7.g(financialConnectionsSheetNativeViewModelQ), new B7.n(1, financialConnectionsSheetNativeViewModelQ, FinancialConnectionsSheetNativeViewModel.class, "onCloseFromErrorClick", "onCloseFromErrorClick(Ljava/lang/Throwable;)V", 0, 5), new B7.m(0, linkAccountPickerViewModel, LinkAccountPickerViewModel.class, "onLearnMoreAboutDataAccessClick", "onLearnMoreAboutDataAccessClick()V", 0, 4), new D7.h(0, linkAccountPickerViewModel, LinkAccountPickerViewModel.class, "onNewBankAccountClick", "onNewBankAccountClick()Lkotlinx/coroutines/Job;", 8, 0), new D7.h(0, linkAccountPickerViewModel, LinkAccountPickerViewModel.class, "onSelectAccountClick", "onSelectAccountClick()Lkotlinx/coroutines/Job;", 8, 1), new B7.n(1, linkAccountPickerViewModel, LinkAccountPickerViewModel.class, "onAccountClick", "onAccountClick(Lcom/stripe/android/financialconnections/model/PartnerAccount;)V", 0, 6), c0629u, 8);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new D7.l(i10);
    }

    public static final void h(f1 f1Var, A8.p pVar, boolean z3, C0629u c0629u, int i10) {
        c0629u.b0(-2106493405);
        a(z3, pVar, f1.a(f1Var, null, p197qa.a.o(R.string.stripe_link_account_picker_disconnected, c0629u), 253951), Ua.l.u(c0629u, -1454273523, new B7.f(f1Var, 1)), c0629u, 3584);
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new A7.G(f1Var, pVar, z3, i10, 1);
    }

    public static final void i(N8.a aVar, boolean z3, C0013f c0013f, InterfaceC1849f interfaceC1849f, S9.a aVar2, Z.m mVar, C0629u c0629u, int i10) {
        k.f(interfaceC1849f, "showCheckboxFlow");
        k.f(aVar2, "formViewModelSubComponentBuilderProvider");
        c0629u.b0(-1225110505);
        O0 o4 = new O0(aVar, interfaceC1849f, aVar2);
        c0629u.a0(1729797275);
        androidx.lifecycle.x0 x0VarA = T1.b.a(c0629u);
        if (x0VarA == null) {
            throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner");
        }
        q0 q0VarC0 = p123ja.a.c0(J8.D.class, x0VarA, aVar.f9386a, o4, x0VarA instanceof InterfaceC0815o ? ((InterfaceC0815o) x0VarA).e() : S1.a.f11265b, c0629u);
        c0629u.u(false);
        J8.D d10 = (J8.D) q0VarC0;
        Z zV = AbstractC0630v.v(d10.f6437f, U9.x.f12753a, null, c0629u, 2);
        Z zV2 = AbstractC0630v.v(d10.f6435d, U9.v.f12751a, null, c0629u, 2);
        Z zV3 = AbstractC0630v.v(d10.f6439h, null, null, c0629u, 2);
        p248v9.M m2 = O.Companion;
        j(aVar.f9386a, z3, c0013f, d10.f6438g, (Set) zV.getValue(), (List) zV2.getValue(), (O) zV3.getValue(), mVar, c0629u, 299008 | (i10 & 896));
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new I7.f(aVar, z3, c0013f, interfaceC1849f, aVar2, mVar, i10);
    }

    public static final void j(String str, boolean z3, C0013f c0013f, V8.d dVar, Set set, List list, O o4, Z.m mVar, C0629u c0629u, int i10) {
        k.f(str, "paymentMethodCode");
        k.f(dVar, "completeFormValues");
        k.f(set, "hiddenIdentifiers");
        k.f(list, "elements");
        c0629u.b0(958947257);
        AbstractC0630v.e(c0629u, new C0739y(dVar, c0013f, null), str);
        p248v9.M m2 = O.Companion;
        com.bumptech.glide.d.L(set, z3, list, o4, mVar, c0629u, ((i10 >> 9) & 57344) | 520);
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new C0740z(str, z3, c0013f, dVar, set, list, o4, mVar, i10);
    }

    public static final void k(D7.h hVar, C0629u c0629u, int i10) {
        int i11;
        C0629u c0629u2 = c0629u;
        c0629u2.b0(-1051002539);
        if ((i10 & 14) == 0) {
            i11 = i10 | (c0629u2.h(hVar) ? 4 : 2);
        } else {
            i11 = i10;
        }
        if ((i11 & 11) == 2 && c0629u2.C()) {
            c0629u2.U();
        } else {
            c0629u2.a0(-492369756);
            Object objE = c0629u2.E();
            W w9 = C0610k.f9587a;
            if (objE == w9) {
                objE = H.f.a(8);
                c0629u2.m0(objE);
            }
            c0629u2.u(false);
            H.e eVar = (H.e) objE;
            Z.j jVar = Z.j.f14412b;
            Z.m mVarB = p195q8.e.b(p168o5.b.y(androidx.compose.foundation.layout.d.d(jVar, 1.0f), eVar), 1, p029c4.a.y0(c0629u2).f14740d, eVar);
            c0629u2.a0(1157296644);
            boolean zF = c0629u2.f(hVar);
            Object objE2 = c0629u2.E();
            if (zF || objE2 == w9) {
                objE2 = new A8.B(hVar, 6);
                c0629u2.m0(objE2);
            }
            c0629u2.u(false);
            float f10 = 16;
            Z.m mVarH = androidx.compose.foundation.layout.c.h(p003a.a.w(mVarB, false, (p084ga.a) objE2, 7), f10);
            c0629u2.a0(733328855);
            B bC = AbstractC0034p.c(Z.a.f14388a, false, c0629u2);
            c0629u2.a0(-1323940314);
            R0 r7 = p232u0.W.f29758e;
            N0.b bVar = (N0.b) c0629u2.l(r7);
            R0 r10 = p232u0.W.k;
            N0.j jVar2 = (N0.j) c0629u2.l(r10);
            R0 r11 = p232u0.W.f29768p;
            B0 b10 = (B0) c0629u2.l(r11);
            InterfaceC1594k.f29156n.getClass();
            C1598o c1598o = C1593j.f29148b;
            V.a aVarI = h.i(mVarH);
            c0629u2.d0();
            if (c0629u2.M) {
                c0629u2.n(c1598o);
            } else {
                c0629u2.o0();
            }
            c0629u2.f9699x = false;
            C1592i c1592i = C1593j.f29152f;
            AbstractC0630v.P(c0629u2, c1592i, bC);
            C1592i c1592i2 = C1593j.f29150d;
            AbstractC0630v.P(c0629u2, c1592i2, bVar);
            C1592i c1592i3 = C1593j.f29153g;
            AbstractC0630v.P(c0629u2, c1592i3, jVar2);
            C1592i c1592i4 = C1593j.f29154h;
            AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u2, b10, c1592i4, c0629u2), c0629u2, 2058660585);
            Z.c cVar = Z.a.f14397t;
            c0629u2.a0(693286680);
            B bA = S.a(AbstractC0027i.f619a, cVar, c0629u2);
            c0629u2.a0(-1323940314);
            N0.b bVar2 = (N0.b) c0629u2.l(r7);
            N0.j jVar3 = (N0.j) c0629u2.l(r10);
            B0 b11 = (B0) c0629u2.l(r11);
            V.a aVarI2 = h.i(jVar);
            c0629u2.d0();
            if (c0629u2.M) {
                c0629u2.n(c1598o);
            } else {
                c0629u2.o0();
            }
            c0629u2.f9699x = false;
            AbstractC0630v.P(c0629u2, c1592i, bA);
            AbstractC0630v.P(c0629u2, c1592i2, bVar2);
            AbstractC0630v.P(c0629u2, c1592i3, jVar3);
            AbstractC1464s.m(0, aVarI2, p015b2.a.c(c0629u2, b11, c1592i4, c0629u2), c0629u2, 2058660585);
            long j10 = p029c4.a.y0(c0629u2).k;
            Z.m mVarK = androidx.compose.foundation.layout.d.k(jVar, 24);
            long jB = q.b(j10, 0.1f);
            H.e eVar2 = H.f.f4391a;
            Z.m mVarY = p168o5.b.y(androidx.compose.foundation.layout.c.h(androidx.compose.foundation.a.b(mVarK, jB, eVar2), 3), eVar2);
            C1129e c1129eX0 = p029c4.a.x0();
            r rVar = new r(Build.VERSION.SDK_INT >= 29 ? C1058k.f21741a.a(j10, 5) : new PorterDuffColorFilter(p050e0.E.t(j10), p050e0.E.v(5)));
            String strO = p197qa.a.o(R.string.stripe_link_account_picker_new_account, c0629u2);
            c0629u2.a0(1595907091);
            p195q8.l.c(AbstractC1125a.e(c1129eX0, c0629u2), strO, mVarY, Z.a.f14392e, C1455i.f27617b, 1.0f, rVar, c0629u2, 8, 0);
            c0629u2.u(false);
            AbstractC0862l.m(c0629u2, androidx.compose.foundation.layout.d.k(jVar, f10));
            f2.b(p197qa.a.o(R.string.stripe_link_account_picker_new_account, c0629u2), null, p029c4.a.y0(c0629u2).k, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, p029c4.a.D0(c0629u2).f14761f, c0629u, 0, 0, 65530);
            c0629u2 = c0629u;
            AbstractC1464s.n(c0629u2, false, true, false, false);
            AbstractC1464s.n(c0629u2, false, true, false, false);
        }
        C0619o0 c0619o0W = c0629u2.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new A7.n(hVar, i10, 6);
    }

    public static final void l(A7.j jVar, String str, List list, C0658f0 c0658f0, W7.J j10, boolean z3, boolean z5, G g10, p084ga.a aVar, p084ga.a aVar2, p084ga.a aVar3, p084ga.a aVar4, C0629u c0629u, int i10, int i11) {
        c0629u.b0(-1144020176);
        x0 x0VarP = p195q8.n.p(c0629u);
        e(Ua.l.u(c0629u, 252787295, new C0009b(x0VarP, aVar4, i11)), Ua.l.u(c0629u, 572689443, new N7.e(z5, x0VarP, list, jVar, str, j10, c0658f0, z3, g10, aVar2, aVar3, aVar, i10, i11)), c0629u, 54);
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new N7.f(jVar, str, list, c0658f0, j10, z3, z5, g10, aVar, aVar2, aVar3, aVar4, i10, i11);
    }

    public static final void m(boolean z3, G g10, p084ga.a aVar, C0629u c0629u, int i10) {
        boolean z5;
        int i11;
        c0629u.b0(-718340852);
        if ((i10 & 14) == 0) {
            z5 = z3;
            i11 = (c0629u.g(z5) ? 4 : 2) | i10;
        } else {
            z5 = z3;
            i11 = i10;
        }
        if ((i10 & 112) == 0) {
            i11 |= c0629u.f(g10) ? 32 : 16;
        }
        if ((i10 & 896) == 0) {
            i11 |= c0629u.h(aVar) ? 256 : 128;
        }
        if ((i11 & 731) == 146 && c0629u.C()) {
            c0629u.U();
        } else {
            Z.j jVar = Z.j.f14412b;
            float f10 = 24;
            Z.m mVarL = androidx.compose.foundation.layout.c.l(jVar, f10, 0.0f, f10, f10, 2);
            c0629u.a0(-483455358);
            B bA = AbstractC0037t.a(AbstractC0027i.f621c, Z.a.f14399v, c0629u);
            c0629u.a0(-1323940314);
            N0.b bVar = (N0.b) c0629u.l(p232u0.W.f29758e);
            N0.j jVar2 = (N0.j) c0629u.l(p232u0.W.k);
            B0 b10 = (B0) c0629u.l(p232u0.W.f29768p);
            InterfaceC1594k.f29156n.getClass();
            C1598o c1598o = C1593j.f29148b;
            V.a aVarI = h.i(mVarL);
            c0629u.d0();
            if (c0629u.M) {
                c0629u.n(c1598o);
            } else {
                c0629u.o0();
            }
            c0629u.f9699x = false;
            AbstractC0630v.P(c0629u, C1593j.f29152f, bA);
            AbstractC0630v.P(c0629u, C1593j.f29150d, bVar);
            AbstractC0630v.P(c0629u, C1593j.f29153g, jVar2);
            AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u, b10, C1593j.f29154h, c0629u), c0629u, 2058660585);
            c0629u.a0(276908162);
            if (g10 != null) {
                b(g10, c0629u, 0);
                AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, 20));
            }
            c0629u.u(false);
            U9.B.e(aVar, androidx.compose.foundation.layout.d.d(jVar, 1.0f), null, null, false, z5, N7.d.f9319a, c0629u, ((i11 >> 6) & 14) | 1572912 | ((i11 << 15) & 458752), 28);
            AbstractC1464s.n(c0629u, false, true, false, false);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new E7.b(z3, g10, aVar, i10, 1);
    }

    public static final void n(int i10, C0629u c0629u) {
        c0629u.b0(-1677297867);
        if (i10 == 0 && c0629u.C()) {
            c0629u.U();
        } else {
            c0629u.a0(512170640);
            androidx.lifecycle.D d10 = (androidx.lifecycle.D) c0629u.l(p232u0.H.f29680d);
            ComponentActivity componentActivityL = p195q8.c.l((Context) c0629u.l(p232u0.H.f29678b));
            if (componentActivityL == null) {
                throw new IllegalStateException("Composable is not hosted in a ComponentActivity!");
            }
            androidx.lifecycle.x0 x0Var = d10 instanceof androidx.lifecycle.x0 ? (androidx.lifecycle.x0) d10 : null;
            if (x0Var == null) {
                throw new IllegalStateException("LifecycleOwner must be a ViewModelStoreOwner!");
            }
            p076g2.e eVar = d10 instanceof p076g2.e ? (p076g2.e) d10 : null;
            if (eVar == null) {
                throw new IllegalStateException("LifecycleOwner must be a SavedStateRegistryOwner!");
            }
            p056e7.n nVarB = eVar.b();
            p097ha.e eVarA = p097ha.v.a(SuccessViewModel.class);
            View view = (View) c0629u.l(p232u0.H.f29682f);
            Object[] objArr = {d10, componentActivityL, x0Var, nVarB};
            c0629u.a0(-568225417);
            boolean zF = false;
            for (int i11 = 0; i11 < 4; i11++) {
                zF |= c0629u.f(objArr[i11]);
            }
            Object objE = c0629u.E();
            Object obj = C0610k.f9587a;
            if (zF || objE == obj) {
                AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583tM = d10 instanceof AbstractComponentCallbacksC0583t ? (AbstractComponentCallbacksC0583t) d10 : null;
                if (abstractComponentCallbacksC0583tM == null) {
                    abstractComponentCallbacksC0583tM = p195q8.c.m(view);
                }
                if (abstractComponentCallbacksC0583tM != null) {
                    Bundle bundle = abstractComponentCallbacksC0583tM.f9251f;
                    objE = new C1721k(componentActivityL, bundle != null ? bundle.get("mavericks:arg") : null, abstractComponentCallbacksC0583tM);
                } else {
                    Bundle extras = componentActivityL.getIntent().getExtras();
                    objE = new C1711a(componentActivityL, extras != null ? extras.get("mavericks:arg") : null, x0Var, nVarB);
                }
                c0629u.m0(objE);
            }
            c0629u.u(false);
            Y y10 = (Y) objE;
            c0629u.a0(511388516);
            boolean zF2 = c0629u.f(eVarA) | c0629u.f(y10);
            Object objE2 = c0629u.E();
            if (zF2 || objE2 == obj) {
                objE2 = P.a(C.R(eVarA), SuccessState.class, y10, C.R(eVarA).getName());
                c0629u.m0(objE2);
            }
            c0629u.u(false);
            c0629u.u(false);
            SuccessViewModel successViewModel = (SuccessViewModel) ((M) objE2);
            FinancialConnectionsSheetNativeViewModel financialConnectionsSheetNativeViewModelQ = Ua.d.Q(c0629u);
            Z zF3 = p195q8.c.f(successViewModel, c0629u);
            p143m0.c.a(true, N7.b.f9312t, c0629u, 54, 0);
            N7.i iVar = (N7.i) ((SuccessState) zF3.getValue()).c().a();
            if (iVar != null) {
                l(iVar.f9351a, iVar.f9354d, iVar.f9353c, iVar.f9352b, iVar.f9357g, ((SuccessState) zF3.getValue()).b() instanceof C1722l, iVar.f9356f, iVar.f9358h, new B7.m(0, successViewModel, SuccessViewModel.class, "onDoneClick", "onDoneClick()V", 0, 15), new B7.m(0, successViewModel, SuccessViewModel.class, "onLearnMoreAboutDataAccessClick", "onLearnMoreAboutDataAccessClick()V", 0, 16), new B7.m(0, successViewModel, SuccessViewModel.class, "onDisconnectLinkClick", "onDisconnectLinkClick()V", 0, 17), new N7.h(financialConnectionsSheetNativeViewModelQ), c0629u, 520, 0);
            }
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new N7.c(i10);
    }

    public static final void o(String str, C0629u c0629u, int i10) {
        String strO;
        C0629u c0629u2;
        c0629u.b0(-690432131);
        if ((((c0629u.f(str) ? 4 : 2) | i10) & 11) == 2 && c0629u.C()) {
            c0629u.U();
            c0629u2 = c0629u;
        } else {
            if (str != null) {
                c0629u.a0(1816712200);
                strO = p197qa.a.p(R.string.stripe_link_account_picker_title, new Object[]{str}, c0629u);
                c0629u.u(false);
            } else {
                c0629u.a0(1816712355);
                strO = p197qa.a.o(R.string.stripe_link_account_picker_title_nobusiness, c0629u);
                c0629u.u(false);
            }
            I i11 = new I(strO);
            c0629u.a0(1649734758);
            Z7.d dVar = (Z7.d) c0629u.l(Z7.g.f14781d);
            c0629u.u(false);
            c0629u2 = c0629u;
            p029c4.a.H(i11, D7.i.f2502a, dVar.f14756a, null, w.f12752a, 0, 0, c0629u2, 24632, 104);
        }
        C0619o0 c0619o0W = c0629u2.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new D7.j(str, i10, 0);
    }

    public static final void p(String str, AbstractC1712b abstractC1712b, D7.k kVar, B7.m mVar, D7.h hVar, D7.h hVar2, B7.n nVar, x0 x0Var, C0629u c0629u, int i10) {
        c0629u.b0(-1696250550);
        Z.j jVar = Z.j.f14412b;
        Z.m mVarC = androidx.compose.foundation.layout.d.c(jVar);
        c0629u.a0(-483455358);
        C0020b c0020b = AbstractC0027i.f621c;
        Z.b bVar = Z.a.f14399v;
        B bA = AbstractC0037t.a(c0020b, bVar, c0629u);
        c0629u.a0(-1323940314);
        R0 r7 = p232u0.W.f29758e;
        N0.b bVar2 = (N0.b) c0629u.l(r7);
        R0 r10 = p232u0.W.k;
        N0.j jVar2 = (N0.j) c0629u.l(r10);
        R0 r11 = p232u0.W.f29768p;
        B0 b10 = (B0) c0629u.l(r11);
        InterfaceC1594k.f29156n.getClass();
        C1598o c1598o = C1593j.f29148b;
        V.a aVarI = h.i(mVarC);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        C1592i c1592i = C1593j.f29152f;
        AbstractC0630v.P(c0629u, c1592i, bA);
        C1592i c1592i2 = C1593j.f29150d;
        AbstractC0630v.P(c0629u, c1592i2, bVar2);
        C1592i c1592i3 = C1593j.f29153g;
        AbstractC0630v.P(c0629u, c1592i3, jVar2);
        C1592i c1592i4 = C1593j.f29154h;
        AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u, b10, c1592i4, c0629u), c0629u, 2058660585);
        float f10 = 24;
        Z.m mVarA = C0038u.a(androidx.compose.foundation.layout.c.j(p195q8.n.u(jVar, x0Var), f10, 0.0f, 2));
        c0629u.a0(-483455358);
        B bA2 = AbstractC0037t.a(c0020b, bVar, c0629u);
        c0629u.a0(-1323940314);
        N0.b bVar3 = (N0.b) c0629u.l(r7);
        N0.j jVar3 = (N0.j) c0629u.l(r10);
        B0 b11 = (B0) c0629u.l(r11);
        V.a aVarI2 = h.i(mVarA);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        AbstractC0630v.P(c0629u, c1592i, bA2);
        AbstractC0630v.P(c0629u, c1592i2, bVar3);
        AbstractC0630v.P(c0629u, c1592i3, jVar3);
        AbstractC1464s.m(0, aVarI2, p015b2.a.c(c0629u, b11, c1592i4, c0629u), c0629u, 2058660585);
        float f11 = 16;
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, f11));
        o(kVar.f2507c, c0629u, 0);
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, f10));
        c0629u.a0(-1538847643);
        for (f1 f1Var : kVar.f2505a) {
            h(f1Var, new A8.p(9, abstractC1712b, nVar), k.b(f1Var.f10374c, str), c0629u, 8);
            AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.e(jVar, 12));
        }
        c0629u.u(false);
        k(hVar2, c0629u, (i10 >> 15) & 14);
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar, f11));
        c0629u.u(false);
        c0629u.u(true);
        c0629u.u(false);
        c0629u.u(false);
        p123ja.a.g(com.bumptech.glide.d.u0(x0Var), Ua.l.u(c0629u, -615692685, new D7.e(kVar, mVar, i10, str, abstractC1712b, hVar)), c0629u, 48);
        C0619o0 c0619o0E = AbstractC1464s.e(c0629u, false, true, false, false);
        if (c0619o0E == null) {
            return;
        }
        c0619o0E.f9606d = new A7.D(str, abstractC1712b, kVar, mVar, hVar, hVar2, nVar, x0Var, i10);
    }

    public static final void q(int i10, C0629u c0629u) {
        c0629u.b0(-433830227);
        if (i10 == 0 && c0629u.C()) {
            c0629u.U();
        } else {
            com.bumptech.glide.d.O(null, p197qa.a.o(R.string.stripe_account_picker_loading_title, c0629u), p197qa.a.o(R.string.stripe_account_picker_loading_desc, c0629u), c0629u, 0);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new s(i10, 1);
    }

    public static final void r(x0 x0Var, List list, A7.j jVar, String str, W7.J j10, C0658f0 c0658f0, boolean z3, G g10, p084ga.a aVar, p084ga.a aVar2, p084ga.a aVar3, C0629u c0629u, int i10, int i11) {
        c0629u.b0(-1739058334);
        InterfaceC1709y0 interfaceC1709y0 = (InterfaceC1709y0) c0629u.l(p232u0.W.f29767o);
        Z.j jVar2 = Z.j.f14412b;
        Z.m mVarC = androidx.compose.foundation.layout.d.c(jVar2);
        c0629u.a0(-483455358);
        C0020b c0020b = AbstractC0027i.f621c;
        Z.b bVar = Z.a.f14399v;
        B bA = AbstractC0037t.a(c0020b, bVar, c0629u);
        c0629u.a0(-1323940314);
        R0 r7 = p232u0.W.f29758e;
        N0.b bVar2 = (N0.b) c0629u.l(r7);
        R0 r10 = p232u0.W.k;
        N0.j jVar3 = (N0.j) c0629u.l(r10);
        R0 r11 = p232u0.W.f29768p;
        B0 b10 = (B0) c0629u.l(r11);
        InterfaceC1594k.f29156n.getClass();
        C1598o c1598o = C1593j.f29148b;
        V.a aVarI = h.i(mVarC);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        C1592i c1592i = C1593j.f29152f;
        AbstractC0630v.P(c0629u, c1592i, bA);
        C1592i c1592i2 = C1593j.f29150d;
        AbstractC0630v.P(c0629u, c1592i2, bVar2);
        C1592i c1592i3 = C1593j.f29153g;
        AbstractC0630v.P(c0629u, c1592i3, jVar3);
        C1592i c1592i4 = C1593j.f29154h;
        AbstractC1464s.m(0, aVarI, p015b2.a.c(c0629u, b10, c1592i4, c0629u), c0629u, 2058660585);
        float f10 = 8;
        float f11 = 24;
        Z.m mVarL = androidx.compose.foundation.layout.c.l(p195q8.n.u(C0038u.a(jVar2), x0Var), f11, f10, f11, 0.0f, 8);
        c0629u.a0(-483455358);
        B bA2 = AbstractC0037t.a(c0020b, bVar, c0629u);
        c0629u.a0(-1323940314);
        N0.b bVar3 = (N0.b) c0629u.l(r7);
        N0.j jVar4 = (N0.j) c0629u.l(r10);
        B0 b11 = (B0) c0629u.l(r11);
        V.a aVarI2 = h.i(mVarL);
        c0629u.d0();
        if (c0629u.M) {
            c0629u.n(c1598o);
        } else {
            c0629u.o0();
        }
        c0629u.f9699x = false;
        AbstractC0630v.P(c0629u, c1592i, bA2);
        AbstractC0630v.P(c0629u, c1592i2, bVar3);
        AbstractC0630v.P(c0629u, c1592i3, jVar4);
        AbstractC1464s.m(0, aVarI2, p015b2.a.c(c0629u, b11, c1592i4, c0629u), c0629u, 2058660585);
        AbstractC0517k0.a(o.k(R.drawable.stripe_ic_check_circle, c0629u), null, androidx.compose.foundation.layout.d.k(jVar2, 40), p029c4.a.y0(c0629u).f14748m, c0629u, 440, 0);
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar2, 16));
        f2.b(p197qa.a.o(R.string.stripe_success_title, c0629u), androidx.compose.foundation.layout.d.d(jVar2, 1.0f), 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, p029c4.a.D0(c0629u).f14756a, c0629u, 48, 0, 65532);
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar2, f10));
        int i12 = i10 >> 12;
        f2.b(j10.a(i12 & 14, c0629u).toString(), androidx.compose.foundation.layout.d.d(jVar2, 1.0f), 0L, 0L, null, null, 0L, null, 0L, 0, false, 0, 0, null, p029c4.a.D0(c0629u).f14761f, c0629u, 48, 0, 65532);
        c0629u.a0(-205352982);
        if (!list.isEmpty()) {
            AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar2, f11));
            c0629u.a0(1157296644);
            boolean zF = c0629u.f(aVar);
            Object objE = c0629u.E();
            if (zF || objE == C0610k.f9587a) {
                objE = new N7.g(aVar, 0);
                c0629u.m0(objE);
            }
            c0629u.u(false);
            p003a.a.c(jVar, c0658f0, list, (p084ga.a) objE, c0629u, (i12 & 112) | 520);
        }
        c0629u.u(false);
        AbstractC0862l.m(c0629u, androidx.compose.foundation.layout.d.k(jVar2, 12));
        p029c4.a.H(new W7.H(R.string.stripe_success_pane_disconnect), new C0013f(aVar2, interfaceC1709y0, str), B0.D.a(p029c4.a.D0(c0629u).f14765j, p029c4.a.y0(c0629u).f14744h, 0L, null, null, 0L, null, 4194302), null, U9.B.V(new T9.h(X7.l.CLICKABLE, y.a(p029c4.a.D0(c0629u).k.f688a, p029c4.a.y0(c0629u).k))), 0, 0, c0629u, 8, 104);
        AbstractC0862l.m(c0629u, C0038u.a(jVar2));
        c0629u.u(false);
        c0629u.u(true);
        c0629u.u(false);
        c0629u.u(false);
        m(z3, g10, aVar3, c0629u, ((i10 >> 18) & 126) | ((i11 << 6) & 896));
        C0619o0 c0619o0E = AbstractC1464s.e(c0629u, false, true, false, false);
        if (c0619o0E == null) {
            return;
        }
        c0619o0E.f9606d = new F7.k(x0Var, list, jVar, str, j10, c0658f0, z3, g10, aVar, aVar2, aVar3, i10, i11);
    }

    public static final void s(int i10, C0629u c0629u) {
        c0629u.b0(-385601937);
        if (i10 == 0 && c0629u.C()) {
            c0629u.U();
        } else {
            com.bumptech.glide.d.O(null, p197qa.a.o(R.string.stripe_success_pane_skip_title, c0629u), p197qa.a.o(R.string.stripe_success_pane_skip_desc, c0629u), c0629u, 0);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new s(i10, 3);
    }

    public static final Y1.A t(Context context) {
        k.f(context, "context");
        Y1.A a3 = new Y1.A(context);
        a3.f13984v.a(new Z1.f());
        a3.f13984v.a(new Z1.j());
        return a3;
    }

    public static final int u(List list, p084ga.e eVar, p084ga.e eVar2, int i10, int i11, int i12, int i13) {
        int i14 = 0;
        if (i12 == i13) {
            int size = list.size();
            float f10 = 0.0f;
            int iMax = 0;
            int i15 = 0;
            while (i14 < size) {
                A a3 = (A) list.get(i14);
                float fP = P(N(a3));
                int iIntValue = ((Number) eVar.invoke(a3, Integer.valueOf(i10))).intValue();
                if (fP == 0.0f) {
                    i15 += iIntValue;
                } else if (fP > 0.0f) {
                    f10 += fP;
                    iMax = Math.max(iMax, p123ja.a.X(iIntValue / fP));
                }
                i14++;
            }
            return ((list.size() - 1) * i11) + p123ja.a.X(iMax * f10) + i15;
        }
        int iMin = Math.min((list.size() - 1) * i11, i10);
        int size2 = list.size();
        float f11 = 0.0f;
        int iMax2 = 0;
        for (int i16 = 0; i16 < size2; i16++) {
            A a9 = (A) list.get(i16);
            float fP2 = P(N(a9));
            if (fP2 == 0.0f) {
                int iMin2 = Math.min(((Number) eVar2.invoke(a9, Integer.valueOf(com.google.android.gms.common.api.f.API_PRIORITY_OTHER))).intValue(), i10 - iMin);
                iMin += iMin2;
                iMax2 = Math.max(iMax2, ((Number) eVar.invoke(a9, Integer.valueOf(iMin2))).intValue());
            } else if (fP2 > 0.0f) {
                f11 += fP2;
            }
        }
        int iX = f11 == 0.0f ? 0 : i10 == Integer.MAX_VALUE ? Integer.MAX_VALUE : p123ja.a.X(Math.max(i10 - iMin, 0) / f11);
        int size3 = list.size();
        while (i14 < size3) {
            A a10 = (A) list.get(i14);
            float fP3 = P(N(a10));
            if (fP3 > 0.0f) {
                iMax2 = Math.max(iMax2, ((Number) eVar.invoke(a10, Integer.valueOf(iX != Integer.MAX_VALUE ? p123ja.a.X(iX * fP3) : Integer.MAX_VALUE))).intValue());
            }
            i14++;
        }
        return iMax2;
    }

    public static final List v(C0629u c0629u) {
        c0629u.a0(-1554459236);
        FinancialConnectionsAccount$Category financialConnectionsAccount$Category = FinancialConnectionsAccount$Category.CASH;
        String str = "Authorization";
        String str2 = "id2";
        f1 f1Var = new f1(str, financialConnectionsAccount$Category, str2, "Account 2 - no acct numbers", FinancialConnectionsAccount$Subcategory.SAVINGS, 249792);
        int i10 = 249280;
        String str3 = "Authorization";
        String str4 = "id3";
        String str5 = "Authorization";
        String str6 = "id4";
        List listK0 = U9.o.k0(f1Var, new f1(str3, financialConnectionsAccount$Category, str4, "Account 3", FinancialConnectionsAccount$Subcategory.CREDIT_CARD, i10), new f1(str5, financialConnectionsAccount$Category, str6, "Account 4", FinancialConnectionsAccount$Subcategory.CHECKING, i10));
        c0629u.u(false);
        return listK0;
    }

    public static final boolean w(Object[] objArr, int i10, int i11, List list) {
        if (i11 == list.size()) {
            for (int i12 = 0; i12 < i11; i12++) {
                if (k.b(objArr[i10 + i12], list.get(i12))) {
                }
            }
            return true;
        }
        return false;
    }

    public static final String x(Object[] objArr, int i10, int i11, U9.g gVar) {
        StringBuilder sb2 = new StringBuilder((i11 * 3) + 2);
        sb2.append("[");
        for (int i12 = 0; i12 < i11; i12++) {
            if (i12 > 0) {
                sb2.append(", ");
            }
            Object obj = objArr[i10 + i12];
            if (obj == gVar) {
                sb2.append("(this Collection)");
            } else {
                sb2.append(obj);
            }
        }
        sb2.append("]");
        String string = sb2.toString();
        k.e(string, "toString(...)");
        return string;
    }

    public static final boolean y(AbstractActivityC1169f abstractActivityC1169f, p084ga.a aVar) {
        try {
            aVar.m();
            return false;
        } catch (IllegalArgumentException unused) {
            abstractActivityC1169f.finish();
            return true;
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0042  */
    /* JADX WARN: Code duplicated, block: B:25:0x0044 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:29:0x004d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x004f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:31:0x0051 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:32:0x0053  */
    /* JADX WARN: Code duplicated, block: B:34:0x0059  */
    /* JADX WARN: Code duplicated, block: B:36:0x005f  */
    /* JADX WARN: Code duplicated, block: B:37:0x0064  */
    /* JADX WARN: Code duplicated, block: B:38:0x0069  */
    /* JADX WARN: Code duplicated, block: B:44:? A[RETURN, SYNTHETIC] */
    public static boolean z(int i10, Rect rect, Rect rect2, Rect rect3) {
        int iU;
        int i11;
        int i12;
        boolean zA = A(i10, rect, rect2);
        if (A(i10, rect, rect3) || !zA) {
            return false;
        }
        if (i10 != 17) {
            if (i10 != 33) {
                if (i10 != 66) {
                    if (i10 != 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    if (rect.bottom <= rect3.top) {
                        if (i10 != 17 && i10 != 66) {
                            iU = U(i10, rect, rect2);
                            if (i10 != 17) {
                                i11 = rect.left;
                                i12 = rect3.left;
                            } else if (i10 != 33) {
                                i11 = rect.top;
                                i12 = rect3.top;
                            } else if (i10 != 66) {
                                i11 = rect3.right;
                                i12 = rect.right;
                            } else {
                                if (i10 == 130) {
                                    throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                                }
                                i11 = rect3.bottom;
                                i12 = rect.bottom;
                            }
                            if (iU < Math.max(1, i11 - i12)) {
                                return false;
                            }
                        }
                    }
                } else if (rect.right <= rect3.left) {
                    if (i10 != 17) {
                        iU = U(i10, rect, rect2);
                        if (i10 != 17) {
                            i11 = rect.left;
                            i12 = rect3.left;
                        } else if (i10 != 33) {
                            i11 = rect.top;
                            i12 = rect3.top;
                        } else if (i10 != 66) {
                            i11 = rect3.right;
                            i12 = rect.right;
                        } else {
                            if (i10 == 130) {
                                throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                            }
                            i11 = rect3.bottom;
                            i12 = rect.bottom;
                        }
                        if (iU < Math.max(1, i11 - i12)) {
                            return false;
                        }
                    }
                }
            } else if (rect.top >= rect3.bottom) {
                if (i10 != 17) {
                    iU = U(i10, rect, rect2);
                    if (i10 != 17) {
                        i11 = rect.left;
                        i12 = rect3.left;
                    } else if (i10 != 33) {
                        i11 = rect.top;
                        i12 = rect3.top;
                    } else if (i10 != 66) {
                        i11 = rect3.right;
                        i12 = rect.right;
                    } else {
                        if (i10 == 130) {
                            throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                        }
                        i11 = rect3.bottom;
                        i12 = rect.bottom;
                    }
                    if (iU < Math.max(1, i11 - i12)) {
                        return false;
                    }
                }
            }
        } else if (rect.left >= rect3.right) {
            if (i10 != 17) {
                iU = U(i10, rect, rect2);
                if (i10 != 17) {
                    i11 = rect.left;
                    i12 = rect3.left;
                } else if (i10 != 33) {
                    i11 = rect.top;
                    i12 = rect3.top;
                } else if (i10 != 66) {
                    i11 = rect3.right;
                    i12 = rect.right;
                } else {
                    if (i10 == 130) {
                        throw new IllegalArgumentException("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
                    }
                    i11 = rect3.bottom;
                    i12 = rect.bottom;
                }
                if (iU < Math.max(1, i11 - i12)) {
                    return false;
                }
            }
        }
        return true;
    }
}
