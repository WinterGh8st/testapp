package android.support.v4.media;

import T3.v;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new v(21);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f15212a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final CharSequence f15213b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final CharSequence f15214c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final CharSequence f15215d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final Bitmap f15216e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Uri f15217f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Bundle f15218q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final Uri f15219r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public Object f15220s;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f15212a = str;
        this.f15213b = charSequence;
        this.f15214c = charSequence2;
        this.f15215d = charSequence3;
        this.f15216e = bitmap;
        this.f15217f = uri;
        this.f15218q = bundle;
        this.f15219r = uri2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return ((Object) this.f15213b) + ", " + ((Object) this.f15214c) + ", " + ((Object) this.f15215d);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        Object objBuild = this.f15220s;
        if (objBuild == null) {
            MediaDescription.Builder builder = new MediaDescription.Builder();
            builder.setMediaId(this.f15212a);
            builder.setTitle(this.f15213b);
            builder.setSubtitle(this.f15214c);
            builder.setDescription(this.f15215d);
            builder.setIconBitmap(this.f15216e);
            builder.setIconUri(this.f15217f);
            builder.setExtras(this.f15218q);
            builder.setMediaUri(this.f15219r);
            objBuild = builder.build();
            this.f15220s = objBuild;
        }
        ((MediaDescription) objBuild).writeToParcel(parcel, i10);
    }
}
