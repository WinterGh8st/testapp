package android.support.v4.media;

import android.os.Bundle;
import p024c.d;

/* JADX INFO: loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends d {
    @Override // p024c.d
    public final void c(int i10, Bundle bundle) {
    }
}
