package A5;

import C6.e;
import C9.C0090f1;
import E5.h;
import G6.F0;
import G6.y0;
import I2.w;
import O2.k;
import P5.l;
import Q5.g;
import S3.m;
import S5.i;
import V2.n;
import Z2.f;
import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import androidx.recyclerview.widget.C0846v;
import androidx.recyclerview.widget.N;
import androidx.recyclerview.widget.l0;
import com.google.android.gms.common.internal.L;
import com.google.android.gms.internal.measurement.zzbz;
import com.google.android.gms.internal.measurement.zzdo;
import com.google.android.gms.internal.measurement.zzdw;
import com.google.android.gms.measurement.internal.AppMeasurementDynamiteService;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.lang.reflect.Method;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import p051e1.C1069f;
import p183p8.R0;
import p199r0.AbstractC1464s;
import p200r1.f0;
import p214s4.A0;
import p214s4.AbstractC1544p;
import p214s4.AbstractC1563y;
import p214s4.BinderC1545p0;
import p214s4.C0;
import p214s4.C1500a0;
import p214s4.C1503b0;
import p214s4.C1504b1;
import p214s4.C1508d;
import p214s4.C1511e;
import p214s4.C1517g;
import p214s4.C1524i0;
import p214s4.C1531k1;
import p214s4.C1533l0;
import p214s4.C1547q;
import p214s4.D1;
import p214s4.EnumC1566z0;
import p214s4.G0;
import p214s4.H;
import p214s4.I0;
import p214s4.InterfaceC1562x0;
import p214s4.J;
import p214s4.K;
import p214s4.L1;
import p214s4.Q;
import p214s4.RunnableC1501a1;
import p214s4.ServiceConnectionC1506c0;
import p214s4.ServiceConnectionC1519g1;
import p214s4.Y0;
import p214s4.Z;
import p214s4.r;
import p214s4.s1;
import p214s4.z1;
import p230ta.C1647l;

/* JADX INFO: loaded from: classes.dex */
public final class b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f62a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f63b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f64c;

    public /* synthetic */ b(int i10) {
        this.f62a = i10;
    }

    /* JADX WARN: Code duplicated, block: B:110:0x02fc  */
    /* JADX WARN: Code duplicated, block: B:113:0x0312  */
    /* JADX WARN: Code duplicated, block: B:114:0x0313 A[Catch: NotFoundException -> 0x0318, TRY_LEAVE, TryCatch #2 {NotFoundException -> 0x0318, blocks: (B:111:0x02fe, B:114:0x0313), top: B:342:0x02fe }] */
    /* JADX WARN: Code duplicated, block: B:119:0x0327  */
    /* JADX WARN: Code duplicated, block: B:121:0x032d  */
    /* JADX WARN: Code duplicated, block: B:122:0x0339  */
    /* JADX WARN: Code duplicated, block: B:125:0x0343  */
    /* JADX WARN: Code duplicated, block: B:128:0x0356  */
    /* JADX WARN: Code duplicated, block: B:130:0x035a  */
    /* JADX WARN: Code duplicated, block: B:131:0x0361  */
    /* JADX WARN: Code duplicated, block: B:134:0x0395  */
    /* JADX WARN: Code duplicated, block: B:136:0x039d  */
    /* JADX WARN: Code duplicated, block: B:137:0x03a6  */
    /* JADX WARN: Code duplicated, block: B:140:0x03ce  */
    /* JADX WARN: Code duplicated, block: B:147:0x0412  */
    /* JADX WARN: Code duplicated, block: B:151:0x0461  */
    /* JADX WARN: Code duplicated, block: B:155:0x047d  */
    /* JADX WARN: Code duplicated, block: B:156:0x0493 A[PHI: r28 r29
  0x0493: PHI (r28v2 java.lang.String) = (r28v0 java.lang.String), (r28v3 java.lang.String) binds: [B:154:0x047b, B:152:0x0464] A[DONT_GENERATE, DONT_INLINE]
  0x0493: PHI (r29v2 s4.l0) = (r29v0 s4.l0), (r29v3 s4.l0) binds: [B:154:0x047b, B:152:0x0464] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:158:0x04a1  */
    /* JADX WARN: Code duplicated, block: B:169:0x04b6  */
    /* JADX WARN: Code duplicated, block: B:173:0x04d5 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:184:0x050c  */
    /* JADX WARN: Code duplicated, block: B:186:0x050f  */
    /* JADX WARN: Code duplicated, block: B:189:0x053c  */
    /* JADX WARN: Code duplicated, block: B:192:0x0552  */
    /* JADX WARN: Code duplicated, block: B:195:0x0571  */
    /* JADX WARN: Code duplicated, block: B:196:0x0576  */
    /* JADX WARN: Code duplicated, block: B:198:0x0584 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:202:0x059a  */
    /* JADX WARN: Code duplicated, block: B:204:0x05a8 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:212:0x05cc  */
    /* JADX WARN: Code duplicated, block: B:217:0x05e9 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:227:0x0626  */
    /* JADX WARN: Code duplicated, block: B:228:0x0628  */
    /* JADX WARN: Code duplicated, block: B:230:0x062e  */
    /* JADX WARN: Code duplicated, block: B:232:0x064d  */
    /* JADX WARN: Code duplicated, block: B:236:0x067d  */
    /* JADX WARN: Code duplicated, block: B:239:0x0699  */
    /* JADX WARN: Code duplicated, block: B:244:0x06b2  */
    /* JADX WARN: Code duplicated, block: B:246:0x06b8  */
    /* JADX WARN: Code duplicated, block: B:248:0x06c3  */
    /* JADX WARN: Code duplicated, block: B:251:0x06d5  */
    /* JADX WARN: Code duplicated, block: B:254:0x06ed  */
    /* JADX WARN: Code duplicated, block: B:258:0x06f9  */
    /* JADX WARN: Code duplicated, block: B:261:0x0709  */
    /* JADX WARN: Code duplicated, block: B:265:0x0721  */
    /* JADX WARN: Code duplicated, block: B:267:0x0733  */
    /* JADX WARN: Code duplicated, block: B:270:0x0743  */
    /* JADX WARN: Code duplicated, block: B:271:0x0749  */
    /* JADX WARN: Code duplicated, block: B:273:0x0782  */
    /* JADX WARN: Code duplicated, block: B:275:0x079e  */
    /* JADX WARN: Code duplicated, block: B:276:0x07ac  */
    /* JADX WARN: Code duplicated, block: B:279:0x07bd  */
    /* JADX WARN: Code duplicated, block: B:284:0x0827  */
    /* JADX WARN: Code duplicated, block: B:290:0x084d  */
    /* JADX WARN: Code duplicated, block: B:292:0x085b  */
    /* JADX WARN: Code duplicated, block: B:293:0x086a  */
    /* JADX WARN: Code duplicated, block: B:296:0x087a  */
    /* JADX WARN: Code duplicated, block: B:299:0x088a  */
    /* JADX WARN: Code duplicated, block: B:302:0x0896  */
    /* JADX WARN: Code duplicated, block: B:303:0x0899  */
    /* JADX WARN: Code duplicated, block: B:305:0x08a1  */
    /* JADX WARN: Code duplicated, block: B:307:0x08ab  */
    /* JADX WARN: Code duplicated, block: B:310:0x08b3  */
    /* JADX WARN: Code duplicated, block: B:312:0x08b6  */
    /* JADX WARN: Code duplicated, block: B:313:0x08bc  */
    /* JADX WARN: Code duplicated, block: B:315:0x08c0  */
    /* JADX WARN: Code duplicated, block: B:319:0x0901  */
    /* JADX WARN: Code duplicated, block: B:323:0x0918  */
    /* JADX WARN: Code duplicated, block: B:324:0x091a  */
    /* JADX WARN: Code duplicated, block: B:326:0x091d  */
    /* JADX WARN: Code duplicated, block: B:33:0x014c A[Catch: NameNotFoundException -> 0x016b, TryCatch #7 {NameNotFoundException -> 0x016b, blocks: (B:31:0x0141, B:33:0x014c, B:35:0x0158), top: B:352:0x0141 }] */
    /* JADX WARN: Code duplicated, block: B:342:0x02fe A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:357:0x05d4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:358:? A[LOOP:0: B:210:0x05c6->B:358:?, LOOP_END, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:35:0x0158 A[Catch: NameNotFoundException -> 0x016b, TRY_LEAVE, TryCatch #7 {NameNotFoundException -> 0x016b, blocks: (B:31:0x0141, B:33:0x014c, B:35:0x0158), top: B:352:0x0141 }] */
    /* JADX WARN: Code duplicated, block: B:362:0x0356 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:37:0x015d  */
    /* JADX WARN: Instruction removed from duplicated block: B:137:0x03a6, please report this as an issue */
    private final void a() {
        K k;
        String string;
        PackageInfo packageInfo;
        CharSequence applicationLabel;
        String str;
        Integer numValueOf;
        String[] stringArray;
        List listAsList;
        Q q10;
        Qa.b bVar;
        String strL;
        boolean zIsEmpty;
        C1517g c1517g;
        int i10;
        AtomicInteger atomicInteger;
        zzdw zzdwVar;
        A0 a0O;
        C0 c0L;
        C0 c0L2;
        C0 c10;
        EnumC1566z0 enumC1566z0;
        long j10;
        I0 i11;
        String str2;
        C1533l0 c1533l0;
        A0 a3;
        C1517g c1517g2;
        C0 c0L3;
        C0 c0L4;
        C1533l0 c1533l1;
        Boolean boolA;
        boolean z3;
        I0 i12;
        C1547q c1547qB;
        Iterator it;
        Boolean boolN;
        boolean zBooleanValue;
        C1500a0 c1500a0;
        C1503b0 c1503b0;
        C1533l0 c1533l2;
        boolean zIsEmpty2;
        K6.d dVar;
        String strM;
        String string2;
        String str3;
        SharedPreferences sharedPreferencesM;
        Z z5;
        String str4;
        Boolean boolValueOf;
        boolean z10;
        Z z11;
        boolean zE;
        SharedPreferences sharedPreferences;
        boolean zContains;
        boolean z12;
        Boolean boolN2;
        boolean z13;
        K kJ;
        K6.d dVar2;
        K kJ2;
        boolean z14;
        Context context;
        int i13;
        Iterator it2;
        String string3;
        String string4;
        C1533l0 c1533l3 = (C1533l0) this.f64c;
        C1524i0 c1524i0 = c1533l3.f28474t;
        C1533l0.d(c1524i0);
        c1524i0.E();
        r rVar = new r(c1533l3);
        rVar.G();
        c1533l3.f28453F = rVar;
        G0 g10 = (G0) this.f63b;
        long j11 = g10.f28088f;
        K k3 = new K(c1533l3);
        k3.f28148z = 0L;
        k3.f28135A = null;
        k3.f28141s = j11;
        k3.J();
        c1533l3.f28454G = k3;
        J j12 = new J(c1533l3);
        j12.J();
        c1533l3.f28451D = j12;
        C1504b1 c1504b1 = new C1504b1(c1533l3);
        c1504b1.J();
        c1533l3.f28452E = c1504b1;
        L1 l1 = c1533l3.f28476v;
        if (l1.f28712c) {
            throw new IllegalStateException("Can't initialize twice");
        }
        l1.E();
        SecureRandom secureRandom = new SecureRandom();
        long jNextLong = secureRandom.nextLong();
        if (jNextLong == 0) {
            jNextLong = secureRandom.nextLong();
            if (jNextLong == 0) {
                l1.zzj().f28218t.b("Utils falling back to Random for random id");
            }
        }
        l1.f28163e.set(jNextLong);
        ((C1533l0) l1.f1632b).f28463Q.incrementAndGet();
        l1.f28712c = true;
        Z z15 = c1533l3.f28472r;
        if (z15.f28712c) {
            throw new IllegalStateException("Can't initialize twice");
        }
        SharedPreferences sharedPreferences2 = ((C1533l0) z15.f1632b).f28465a.getSharedPreferences("com.google.android.gms.measurement.prefs", 0);
        z15.f28289d = sharedPreferences2;
        boolean z16 = sharedPreferences2.getBoolean("has_been_opened", false);
        z15.f28281D = z16;
        if (!z16) {
            SharedPreferences.Editor editorEdit = z15.f28289d.edit();
            editorEdit.putBoolean("has_been_opened", true);
            editorEdit.apply();
        }
        z15.f28292q = new D2.d(z15, Math.max(0L, ((Long) AbstractC1563y.f28660d.a(null)).longValue()));
        ((C1533l0) z15.f1632b).f28463Q.incrementAndGet();
        z15.f28712c = true;
        K k4 = c1533l3.f28454G;
        if (k4.f28270c) {
            throw new IllegalStateException("Can't initialize twice");
        }
        C1533l0 c1533l4 = (C1533l0) k4.f1632b;
        Context context2 = c1533l4.f28465a;
        String str5 = c1533l4.f28450C;
        String packageName = context2.getPackageName();
        Context context3 = c1533l4.f28465a;
        PackageManager packageManager = context3.getPackageManager();
        String str6 = "";
        String installerPackageName = "unknown";
        String str7 = "Unknown";
        int i14 = Integer.MIN_VALUE;
        if (packageManager == null) {
            k = k3;
            k4.zzj().f28215q.c("PackageManager is null, app identity information might be inaccurate. appId", Q.K(packageName));
        } else {
            k = k3;
            try {
                installerPackageName = packageManager.getInstallerPackageName(packageName);
            } catch (IllegalArgumentException unused) {
                k4.zzj().f28215q.c("Error retrieving app installer package name. appId", Q.K(packageName));
            }
            String str8 = installerPackageName;
            try {
                if (str8 == null) {
                    str8 = "manual_install";
                } else {
                    if ("com.android.vending".equals(str8)) {
                        installerPackageName = "";
                    }
                    packageInfo = packageManager.getPackageInfo(context3.getPackageName(), 0);
                    if (packageInfo != null) {
                        applicationLabel = packageManager.getApplicationLabel(packageInfo.applicationInfo);
                        if (TextUtils.isEmpty(applicationLabel)) {
                            string = "Unknown";
                        } else {
                            string = applicationLabel.toString();
                        }
                        try {
                            str = packageInfo.versionName;
                            try {
                                i14 = packageInfo.versionCode;
                                str7 = str;
                            } catch (PackageManager.NameNotFoundException unused2) {
                                str7 = str;
                                k4.zzj().f28215q.d("Error retrieving package info. appId, appName", Q.K(packageName), string);
                            }
                        } catch (PackageManager.NameNotFoundException unused3) {
                        }
                    }
                }
                packageInfo = packageManager.getPackageInfo(context3.getPackageName(), 0);
                if (packageInfo != null) {
                    applicationLabel = packageManager.getApplicationLabel(packageInfo.applicationInfo);
                    if (TextUtils.isEmpty(applicationLabel)) {
                        string = applicationLabel.toString();
                    } else {
                        string = "Unknown";
                    }
                    str = packageInfo.versionName;
                    i14 = packageInfo.versionCode;
                    str7 = str;
                }
            } catch (PackageManager.NameNotFoundException unused4) {
                string = "Unknown";
            }
            installerPackageName = str8;
        }
        String str9 = installerPackageName;
        String str10 = str7;
        int i15 = i14;
        k4.f28136d = packageName;
        k4.f28139q = str9;
        k4.f28137e = str10;
        k4.f28138f = i15;
        k4.f28140r = 0L;
        String str11 = c1533l4.f28466b;
        boolean z17 = !TextUtils.isEmpty(str11) && "am".equals(c1533l4.f28467c);
        int iG = c1533l4.g();
        switch (iG) {
            case 0:
                k4.zzj().f28223y.b("App measurement collection enabled");
                break;
            case 1:
                k4.zzj().f28221w.b("App measurement deactivated via the manifest");
                break;
            case 2:
                k4.zzj().f28223y.b("App measurement deactivated via the init parameters");
                break;
            case 3:
                k4.zzj().f28221w.b("App measurement disabled by setAnalyticsCollectionEnabled(false)");
                break;
            case 4:
                k4.zzj().f28221w.b("App measurement disabled via the manifest");
                break;
            case 5:
                k4.zzj().f28223y.b("App measurement disabled via the init parameters");
                break;
            case 6:
                k4.zzj().f28220v.b("App measurement deactivated via resources. This method is being deprecated. Please refer to https://firebase.google.com/support/guides/disable-analytics");
                break;
            case 7:
                k4.zzj().f28221w.b("App measurement disabled via the global data collection setting");
                break;
            case 8:
                k4.zzj().f28221w.b("App measurement disabled due to denied storage consent");
                break;
            default:
                k4.zzj().f28221w.b("App measurement disabled");
                k4.zzj().f28216r.b("Invalid scion state in identity");
                break;
        }
        boolean z18 = iG == 0;
        k4.f28145w = "";
        k4.f28146x = "";
        if (z17) {
            k4.f28146x = str11;
        }
        try {
            Resources resources = 
            /*  JADX ERROR: Method code generation error
                jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x024f: INVOKE (r11v20 'resources' android.content.res.Resources) = (r1v12 ?? I:??[OBJECT, ARRAY]) VIRTUAL call: android.content.Context.getResources():android.content.res.Resources A[Catch: IllegalStateException -> 0x029c, DECLARE_VAR, MD:():android.content.res.Resources (c)] (LINE:592) in method: A5.b.a():void, file: classes.dex
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                	at jadx.core.codegen.RegionGen.makeTryCatch(RegionGen.java:320)
                	at jadx.core.dex.regions.TryCatchRegion.generate(TryCatchRegion.java:85)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:186)
                	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
                	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                	at java.base/java.util.stream.ReferencePipeline$7$1FlatMap.end(ReferencePipeline.java:284)
                	at java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:571)
                	at java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:560)
                	at java.base/java.util.stream.ForEachOps$ForEachOp.evaluateSequential(ForEachOps.java:153)
                	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.evaluateSequential(ForEachOps.java:176)
                	at java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:265)
                	at java.base/java.util.stream.ReferencePipeline.forEach(ReferencePipeline.java:632)
                	at jadx.core.codegen.ClassGen.addInnerClsAndMethods(ClassGen.java:295)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:284)
                	at jadx.core.codegen.ClassGen.addClassBody(ClassGen.java:268)
                	at jadx.core.codegen.ClassGen.addClassCode(ClassGen.java:160)
                	at jadx.core.codegen.ClassGen.makeClass(ClassGen.java:104)
                	at jadx.core.codegen.CodeGen.wrapCodeGen(CodeGen.java:45)
                	at jadx.core.codegen.CodeGen.generateJavaCode(CodeGen.java:34)
                	at jadx.core.codegen.CodeGen.generate(CodeGen.java:22)
                	at jadx.core.ProcessClass.process(ProcessClass.java:89)
                	at jadx.core.ProcessClass.generateCode(ProcessClass.java:127)
                	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
                	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
                	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:311)
                Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r1v12 ??
                	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                */
            /*
                Method dump skipped, instruction units count: 2400
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: A5.b.a():void");
        }

        /* JADX WARN: Code duplicated, block: B:47:0x003c A[SYNTHETIC] */
        /* JADX WARN: Code restructure failed: missing block: B:19:0x0043, code lost:
        
            if (r1 == false) goto L51;
         */
        /* JADX WARN: Code restructure failed: missing block: B:24:0x004c, code lost:
        
            r1 = r1 | java.lang.Thread.interrupted();
         */
        /* JADX WARN: Code restructure failed: missing block: B:25:0x004e, code lost:
        
            ((java.lang.Runnable) r10.f63b).run();
         */
        /* JADX WARN: Code restructure failed: missing block: B:30:0x005a, code lost:
        
            r0 = move-exception;
         */
        /* JADX WARN: Code restructure failed: missing block: B:32:0x005c, code lost:
        
            r3 = move-exception;
         */
        /* JADX WARN: Code restructure failed: missing block: B:33:0x005d, code lost:
        
            S5.i.f11346f.log(java.util.logging.Level.SEVERE, "Exception while executing runnable " + ((java.lang.Runnable) r10.f63b), (java.lang.Throwable) r3);
         */
        /* JADX WARN: Code restructure failed: missing block: B:35:0x007a, code lost:
        
            r10.f63b = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:36:0x007c, code lost:
        
            throw r0;
         */
        /* JADX WARN: Code restructure failed: missing block: B:51:?, code lost:
        
            return;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public void b() {
            /*
                r10 = this;
                r0 = 0
                r1 = r0
            L2:
                java.lang.Object r2 = r10.f64c     // Catch: java.lang.Throwable -> L58
                S5.i r2 = (S5.i) r2     // Catch: java.lang.Throwable -> L58
                java.util.ArrayDeque r2 = r2.f11348b     // Catch: java.lang.Throwable -> L58
                monitor-enter(r2)     // Catch: java.lang.Throwable -> L58
                r3 = 1
                if (r0 != 0) goto L2c
                java.lang.Object r0 = r10.f64c     // Catch: java.lang.Throwable -> L20
                S5.i r0 = (S5.i) r0     // Catch: java.lang.Throwable -> L20
                int r4 = r0.f11349c     // Catch: java.lang.Throwable -> L20
                r5 = 4
                if (r4 != r5) goto L22
                monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
                if (r1 == 0) goto L46
            L18:
                java.lang.Thread r0 = java.lang.Thread.currentThread()
                r0.interrupt()
                goto L46
            L20:
                r0 = move-exception
                goto L7d
            L22:
                long r6 = r0.f11350d     // Catch: java.lang.Throwable -> L20
                r8 = 1
                long r6 = r6 + r8
                r0.f11350d = r6     // Catch: java.lang.Throwable -> L20
                r0.f11349c = r5     // Catch: java.lang.Throwable -> L20
                r0 = r3
            L2c:
                java.lang.Object r4 = r10.f64c     // Catch: java.lang.Throwable -> L20
                S5.i r4 = (S5.i) r4     // Catch: java.lang.Throwable -> L20
                java.util.ArrayDeque r4 = r4.f11348b     // Catch: java.lang.Throwable -> L20
                java.lang.Object r4 = r4.poll()     // Catch: java.lang.Throwable -> L20
                java.lang.Runnable r4 = (java.lang.Runnable) r4     // Catch: java.lang.Throwable -> L20
                r10.f63b = r4     // Catch: java.lang.Throwable -> L20
                if (r4 != 0) goto L47
                java.lang.Object r0 = r10.f64c     // Catch: java.lang.Throwable -> L20
                S5.i r0 = (S5.i) r0     // Catch: java.lang.Throwable -> L20
                r0.f11349c = r3     // Catch: java.lang.Throwable -> L20
                monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
                if (r1 == 0) goto L46
                goto L18
            L46:
                return
            L47:
                monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
                boolean r2 = java.lang.Thread.interrupted()     // Catch: java.lang.Throwable -> L58
                r1 = r1 | r2
                r2 = 0
                java.lang.Object r3 = r10.f63b     // Catch: java.lang.Throwable -> L5a java.lang.RuntimeException -> L5c
                java.lang.Runnable r3 = (java.lang.Runnable) r3     // Catch: java.lang.Throwable -> L5a java.lang.RuntimeException -> L5c
                r3.run()     // Catch: java.lang.Throwable -> L5a java.lang.RuntimeException -> L5c
            L55:
                r10.f63b = r2     // Catch: java.lang.Throwable -> L58
                goto L2
            L58:
                r0 = move-exception
                goto L7f
            L5a:
                r0 = move-exception
                goto L7a
            L5c:
                r3 = move-exception
                java.util.logging.Logger r4 = S5.i.f11346f     // Catch: java.lang.Throwable -> L5a
                java.util.logging.Level r5 = java.util.logging.Level.SEVERE     // Catch: java.lang.Throwable -> L5a
                java.lang.StringBuilder r6 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L5a
                r6.<init>()     // Catch: java.lang.Throwable -> L5a
                java.lang.String r7 = "Exception while executing runnable "
                r6.append(r7)     // Catch: java.lang.Throwable -> L5a
                java.lang.Object r7 = r10.f63b     // Catch: java.lang.Throwable -> L5a
                java.lang.Runnable r7 = (java.lang.Runnable) r7     // Catch: java.lang.Throwable -> L5a
                r6.append(r7)     // Catch: java.lang.Throwable -> L5a
                java.lang.String r6 = r6.toString()     // Catch: java.lang.Throwable -> L5a
                r4.log(r5, r6, r3)     // Catch: java.lang.Throwable -> L5a
                goto L55
            L7a:
                r10.f63b = r2     // Catch: java.lang.Throwable -> L58
                throw r0     // Catch: java.lang.Throwable -> L58
            L7d:
                monitor-exit(r2)     // Catch: java.lang.Throwable -> L20
                throw r0     // Catch: java.lang.Throwable -> L58
            L7f:
                if (r1 == 0) goto L88
                java.lang.Thread r1 = java.lang.Thread.currentThread()
                r1.interrupt()
            L88:
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: A5.b.b():void");
        }

        /* JADX WARN: Code duplicated, block: B:249:0x01e3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
        /* JADX WARN: Code duplicated, block: B:61:0x01d6  */
        @Override // java.lang.Runnable
        public final void run() {
            Long lValueOf;
            C1533l0 c1533l0;
            zzdo zzdoVar;
            switch (this.f62a) {
                case 0:
                    f0 f0Var = (f0) this.f64c;
                    try {
                        Ua.d.C((c) this.f63b);
                        I0 i10 = (I0) f0Var.f27708c;
                        i10.E();
                        boolean zP = ((C1533l0) i10.f1632b).f28471q.P(null, AbstractC1563y.f28625M0);
                        s1 s1Var = (s1) f0Var.f27707b;
                        String str = s1Var.f28548a;
                        if (!zP) {
                            i10.f28118t = false;
                            i10.e0();
                            i10.zzj().f28222x.c("registerTriggerAsync ran. uri", str);
                            return;
                        }
                        SparseArray sparseArrayN = i10.C().N();
                        sparseArrayN.put(s1Var.f28550c, Long.valueOf(s1Var.f28549b));
                        i10.C().I(sparseArrayN);
                        i10.f28118t = false;
                        i10.f28119u = 1;
                        i10.zzj().f28222x.c("Successfully registered trigger URI", str);
                        i10.e0();
                        return;
                    } catch (Error e10) {
                        e = e10;
                        f0Var.p(e);
                        return;
                    } catch (RuntimeException e11) {
                        e = e11;
                        f0Var.p(e);
                        return;
                    } catch (ExecutionException e12) {
                        f0Var.p(e12.getCause());
                        return;
                    }
                case 1:
                    E2.c cVar = (E2.c) this.f64c;
                    if (cVar.f2941d) {
                        StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().detectNetwork().penaltyDeath().build());
                    }
                    try {
                        ((Runnable) this.f63b).run();
                        return;
                    } catch (Throwable th) {
                        cVar.f2940c.getClass();
                        if (Log.isLoggable("GlideExecutor", 6)) {
                            Log.e("GlideExecutor", "Request threw uncaught throwable", th);
                            return;
                        }
                        return;
                    }
                case 2:
                    ((G9.c) this.f64c).f4332f.unregisterNetworkCallback((G9.a) this.f63b);
                    return;
                case 3:
                    ((G9.c) this.f64c).f4331e.unregisterReceiver((G9.b) this.f63b);
                    return;
                case 4:
                    w wVarA = w.a();
                    wVarA.getClass();
                    n.a();
                    wVarA.f5852d.set(true);
                    ((O2.d) this.f64c).f9764b.f9766b = true;
                    ((O2.d) this.f64c).f9763a.getViewTreeObserver().removeOnDrawListener((O2.d) this.f63b);
                    ((O2.d) this.f64c).f9764b.f9765a.clear();
                    return;
                case 5:
                    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance(h.e((String) this.f63b));
                    l lVar = firebaseAuth.f20082f;
                    if (lVar != null) {
                        Task taskC = firebaseAuth.c(lVar, true);
                        g.f10769f.e("Token refreshing started", new Object[0]);
                        taskC.addOnFailureListener(new Q5.h(this));
                        return;
                    }
                    return;
                case 6:
                    S3.l lVar2 = (S3.l) this.f63b;
                    IBinder iBinder = (IBinder) this.f64c;
                    synchronized (lVar2) {
                        if (iBinder == null) {
                            lVar2.a("Null service connection");
                        } else {
                            try {
                                lVar2.f11307c = new k(iBinder);
                                lVar2.f11305a = 2;
                                ((ScheduledExecutorService) lVar2.f11310f.f11319c).execute(new S3.k(lVar2, 0));
                            } catch (RemoteException e13) {
                                lVar2.a(e13.getMessage());
                            }
                        }
                    }
                    return;
                case 7:
                    S3.l lVar3 = (S3.l) this.f63b;
                    int i11 = ((m) this.f64c).f11311a;
                    synchronized (lVar3) {
                        m mVar = (m) lVar3.f11309e.get(i11);
                        if (mVar != null) {
                            Log.w("MessengerIpcClient", "Timing out request: " + i11);
                            lVar3.f11309e.remove(i11);
                            mVar.b(new S3.n("Timed out waiting for response", null));
                            lVar3.c();
                        }
                        break;
                    }
                    return;
                case 8:
                    try {
                        b();
                        return;
                    } catch (Error e14) {
                        synchronized (((i) this.f64c).f11348b) {
                            ((i) this.f64c).f11349c = 1;
                            throw e14;
                        }
                    }
                case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                    C0846v c0846v = (C0846v) this.f64c;
                    PaymentMethodsRecyclerView paymentMethodsRecyclerView = c0846v.f16956r;
                    if (paymentMethodsRecyclerView == null || !paymentMethodsRecyclerView.f16621C) {
                        return;
                    }
                    androidx.recyclerview.widget.r rVar = (androidx.recyclerview.widget.r) this.f63b;
                    if (rVar.k) {
                        return;
                    }
                    l0 l0Var = rVar.f16903e;
                    if (l0Var.getAbsoluteAdapterPosition() != -1) {
                        N itemAnimator = c0846v.f16956r.getItemAnimator();
                        if (itemAnimator == null || !itemAnimator.f()) {
                            ArrayList arrayList = c0846v.f16954p;
                            int size = arrayList.size();
                            for (int i12 = 0; i12 < size; i12++) {
                                if (((androidx.recyclerview.widget.r) arrayList.get(i12)).f16909l) {
                                }
                            }
                            C0090f1 c0090f1 = c0846v.f16951m;
                            c0090f1.getClass();
                            p097ha.k.f(l0Var, "viewHolder");
                            R0 r0A = c0090f1.f2075e.a(l0Var.getBindingAdapterPosition());
                            Q3.i iVar = c0090f1.f2076f;
                            p097ha.k.f(r0A, "paymentMethod");
                            ((B0.l) iVar.f10735b).g(r0A).show();
                            return;
                        }
                        c0846v.f16956r.post(this);
                        return;
                    }
                    return;
                case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                    com.google.firebase.storage.r rVar2 = (com.google.firebase.storage.r) this.f64c;
                    String strE = p003a.a.E(rVar2.f20200o);
                    String strD = p003a.a.D(rVar2.f20201p);
                    h hVar = rVar2.k.f20158b.f20148a;
                    hVar.a();
                    ((e) this.f63b).m(hVar.f2968a, strE, strD);
                    return;
                case 11:
                    ((C1069f) this.f63b).f21771a = this.f64c;
                    return;
                case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                    ((Application) this.f63b).unregisterActivityLifecycleCallbacks((C1069f) this.f64c);
                    return;
                case 13:
                    try {
                        Method method = p051e1.g.f21780d;
                        Object obj = this.f64c;
                        Object obj2 = this.f63b;
                        if (method != null) {
                            method.invoke(obj2, obj, Boolean.FALSE, "AppCompat recreation");
                        } else {
                            p051e1.g.f21781e.invoke(obj2, obj, Boolean.FALSE);
                        }
                        return;
                    } catch (RuntimeException e15) {
                        if (e15.getClass() == RuntimeException.class && e15.getMessage() != null && e15.getMessage().startsWith("Unable to stop")) {
                            throw e15;
                        }
                        return;
                    } catch (Throwable th2) {
                        Log.e("ActivityRecreator", "Exception while invoking performStopActivity", th2);
                        return;
                    }
                case 14:
                    p075g1.a aVar = (p075g1.a) ((p088h1.g) this.f63b).f23033b;
                    if (aVar != null) {
                        aVar.k((Typeface) this.f64c);
                        return;
                    }
                    return;
                case 15:
                    ((p155n1.c) this.f63b).a(this.f64c);
                    return;
                case 16:
                    ((InterfaceC1562x0) this.f63b).zzd();
                    if (C1508d.a()) {
                        ((InterfaceC1562x0) this.f63b).zzl().N(this);
                        return;
                    }
                    boolean z3 = ((AbstractC1544p) this.f64c).f28515c != 0;
                    ((AbstractC1544p) this.f64c).f28515c = 0L;
                    if (z3) {
                        ((AbstractC1544p) this.f64c).c();
                        return;
                    }
                    return;
                case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                    ServiceConnectionC1506c0 serviceConnectionC1506c0 = (ServiceConnectionC1506c0) this.f64c;
                    C1503b0 c1503b0 = serviceConnectionC1506c0.f28331b;
                    C1533l0 c1533l1 = c1503b0.f28318b;
                    C1524i0 c1524i0 = c1533l1.f28474t;
                    C1533l0.d(c1524i0);
                    c1524i0.E();
                    zzbz zzbzVar = (zzbz) this.f63b;
                    Q q10 = c1533l1.f28473s;
                    Bundle bundle = new Bundle();
                    bundle.putString("package_name", serviceConnectionC1506c0.f28330a);
                    try {
                        if (zzbzVar.zza(bundle) == null) {
                            C1533l0.d(q10);
                            q10.f28215q.b("Install Referrer Service returned a null response");
                        }
                        break;
                    } catch (Exception e16) {
                        C1533l0.d(q10);
                        q10.f28215q.c("Exception occurred while retrieving the Install Referrer", e16.getMessage());
                    }
                    C1524i0 c1524i1 = c1503b0.f28318b.f28474t;
                    C1533l0.d(c1524i1);
                    c1524i1.E();
                    throw new IllegalStateException("Unexpected call on client side");
                case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                    a();
                    return;
                case 19:
                    BinderC1545p0 binderC1545p0 = (BinderC1545p0) this.f64c;
                    binderC1545p0.f28516a.Z();
                    C1511e c1511e = (C1511e) this.f63b;
                    Object objZza = c1511e.f28347c.zza();
                    z1 z1Var = binderC1545p0.f28516a;
                    if (objZza == null) {
                        z1Var.getClass();
                        String str2 = c1511e.f28345a;
                        L.j(str2);
                        D1 d1K = z1Var.K(str2);
                        if (d1K != null) {
                            z1Var.q(c1511e, d1K);
                            return;
                        }
                        return;
                    }
                    z1Var.getClass();
                    String str3 = c1511e.f28345a;
                    L.j(str3);
                    D1 d1K2 = z1Var.K(str3);
                    if (d1K2 != null) {
                        z1Var.G(c1511e, d1K2);
                        return;
                    }
                    return;
                case 20:
                    I0 i13 = (I0) this.f63b;
                    i13.E();
                    if (Build.VERSION.SDK_INT >= 30) {
                        SparseArray sparseArrayN2 = i13.C().N();
                        for (s1 s1Var2 : (List) this.f64c) {
                            if (!sparseArrayN2.contains(s1Var2.f28550c) || ((Long) sparseArrayN2.get(s1Var2.f28550c)).longValue() < s1Var2.f28549b) {
                                i13.Z().add(s1Var2);
                            }
                        }
                        i13.e0();
                        return;
                    }
                    return;
                case 21:
                    C1533l0 c1533l2 = (C1533l0) ((I0) this.f63b).f1632b;
                    K kJ = c1533l2.j();
                    String str4 = kJ.f28135A;
                    String str5 = (String) this.f64c;
                    boolean z5 = (str4 == null || str4.equals(str5)) ? false : true;
                    kJ.f28135A = str5;
                    if (z5) {
                        c1533l2.j().N();
                        return;
                    }
                    return;
                case 22:
                    I0 i14 = (I0) this.f64c;
                    C1531k1 c1531k1H = i14.H();
                    if (c1531k1H.C().O().i(EnumC1566z0.ANALYTICS_STORAGE)) {
                        Z zC = c1531k1H.C();
                        ((C1533l0) c1531k1H.f1632b).f28478x.getClass();
                        if (!zC.J(System.currentTimeMillis()) && c1531k1H.C().f28280C.a() != 0) {
                            lValueOf = Long.valueOf(c1531k1H.C().f28280C.a());
                        }
                        c1533l0 = (C1533l0) i14.f1632b;
                        zzdoVar = (zzdo) this.f63b;
                        if (lValueOf == null) {
                            L1 l1 = c1533l0.f28476v;
                            C1533l0.b(l1);
                            l1.a0(zzdoVar, lValueOf.longValue());
                            return;
                        } else {
                            try {
                                zzdoVar.zza(null);
                                return;
                            } catch (RemoteException e17) {
                                Q q11 = c1533l0.f28473s;
                                C1533l0.d(q11);
                                q11.f28215q.c("getSessionId failed with exception", e17);
                                return;
                            }
                        }
                    }
                    c1531k1H.zzj().f28220v.b("Analytics storage consent denied; will not get session id");
                    lValueOf = null;
                    c1533l0 = (C1533l0) i14.f1632b;
                    zzdoVar = (zzdo) this.f63b;
                    if (lValueOf == null) {
                        zzdoVar.zza(null);
                        return;
                    }
                    L1 l4 = c1533l0.f28476v;
                    C1533l0.b(l4);
                    l4.a0(zzdoVar, lValueOf.longValue());
                    return;
                case 23:
                    ((I0) this.f64c).P((Boolean) this.f63b, true);
                    return;
                case 24:
                    I0 i15 = (I0) this.f64c;
                    Z zC2 = i15.C();
                    zC2.E();
                    zC2.E();
                    C1547q c1547qC = C1547q.c(zC2.M().getString("dma_consent_settings", null));
                    C1547q c1547q = (C1547q) this.f63b;
                    int i16 = c1547qC.f28521a;
                    int i17 = c1547q.f28521a;
                    if (!A0.h(i17, i16)) {
                        i15.zzj().f28221w.c("Lower precedence consent source ignored, proposed source", Integer.valueOf(i17));
                        return;
                    }
                    SharedPreferences.Editor editorEdit = zC2.M().edit();
                    editorEdit.putString("dma_consent_settings", c1547q.f28522b);
                    editorEdit.apply();
                    i15.zzj().f28223y.c("Setting DMA consent(FE)", c1547q);
                    C1533l0 c1533l3 = (C1533l0) i15.f1632b;
                    C1504b1 c1504b1K = AbstractC1464s.k(c1533l3);
                    if (c1504b1K.U() && c1504b1K.D().I0() < 241200) {
                        c1533l3.m().P(false);
                        return;
                    }
                    C1504b1 c1504b1K2 = AbstractC1464s.k(c1533l3);
                    RunnableC1501a1 runnableC1501a1 = new RunnableC1501a1(1);
                    runnableC1501a1.f28312b = c1504b1K2;
                    c1504b1K2.L(runnableC1501a1);
                    return;
                case 25:
                    I0 i18 = ((AppMeasurementDynamiteService) this.f64c).f19007a.f28480z;
                    C1533l0.c(i18);
                    f0 f0Var2 = (f0) this.f63b;
                    i18.E();
                    i18.I();
                    p214s4.F0 f10 = i18.f28113e;
                    if (f0Var2 != f10) {
                        L.l("EventInterceptor already set.", f10 == null);
                    }
                    i18.f28113e = f0Var2;
                    return;
                case 26:
                    C1504b1 c1504b1 = (C1504b1) this.f64c;
                    H h10 = c1504b1.f28320e;
                    if (h10 == null) {
                        c1504b1.zzj().f28215q.b("Failed to send current screen to service");
                        return;
                    }
                    try {
                        Y0 y10 = (Y0) this.f63b;
                        if (y10 == null) {
                            h10.w(0L, null, null, ((C1533l0) c1504b1.f1632b).f28465a.getPackageName());
                        } else {
                            h10.w(y10.f28273c, y10.f28271a, y10.f28272b, ((C1533l0) c1504b1.f1632b).f28465a.getPackageName());
                        }
                        c1504b1.W();
                        return;
                    } catch (RemoteException e18) {
                        c1504b1.zzj().f28215q.c("Failed to send current screen to the service", e18);
                        return;
                    }
                case 27:
                    C1504b1 c1504b2 = ((ServiceConnectionC1519g1) this.f64c).f28383c;
                    c1504b2.E();
                    if (c1504b2.f28320e != null) {
                        c1504b2.f28320e = null;
                        c1504b2.zzj().f28223y.c("Disconnected from device MeasurementService", (ComponentName) this.f63b);
                        c1504b2.E();
                        c1504b2.Q();
                        return;
                    }
                    return;
                case 28:
                    z1 z1Var2 = (z1) this.f63b;
                    z1Var2.Z();
                    z1Var2.zzl().E();
                    if (z1Var2.f28754z == null) {
                        z1Var2.f28754z = new ArrayList();
                    }
                    z1Var2.f28754z.add((Runnable) this.f64c);
                    z1Var2.b0();
                    return;
                default:
                    ((C1647l) this.f64c).z((p230ta.Z) this.f63b, T9.w.f11979a);
                    return;
            }
        }

        public String toString() {
            String str;
            switch (this.f62a) {
                case 0:
                    K6.d dVarM = p195q8.d.m(this);
                    f fVar = new f();
                    ((f) dVarM.f6934e).f14489c = fVar;
                    dVarM.f6934e = fVar;
                    fVar.f14488b = (f0) this.f64c;
                    return dVarM.toString();
                case 8:
                    Runnable runnable = (Runnable) this.f63b;
                    if (runnable != null) {
                        return "SequentialExecutorWorker{running=" + runnable + "}";
                    }
                    StringBuilder sb2 = new StringBuilder("SequentialExecutorWorker{state=");
                    int i10 = ((i) this.f64c).f11349c;
                    if (i10 == 1) {
                        str = "IDLE";
                    } else if (i10 == 2) {
                        str = "QUEUING";
                    } else if (i10 != 3) {
                        str = i10 != 4 ? "null" : "RUNNING";
                    } else {
                        str = "QUEUED";
                    }
                    sb2.append(str);
                    sb2.append("}");
                    return sb2.toString();
                default:
                    return super.toString();
            }
        }

        public /* synthetic */ b(int i10, Object obj, Object obj2) {
            this.f62a = i10;
            this.f63b = obj;
            this.f64c = obj2;
        }

        public /* synthetic */ b(int i10, Object obj, Object obj2, boolean z3) {
            this.f62a = i10;
            this.f64c = obj;
            this.f63b = obj2;
        }

        public b(g gVar, String str) {
            this.f62a = 5;
            this.f64c = gVar;
            L.f(str);
            this.f63b = str;
        }

        public b(ServiceConnectionC1506c0 serviceConnectionC1506c0, zzbz zzbzVar, ServiceConnectionC1506c0 serviceConnectionC1506c1) {
            this.f62a = 17;
            this.f63b = zzbzVar;
            this.f64c = serviceConnectionC1506c0;
        }

        public b(i iVar) {
            this.f62a = 8;
            this.f64c = iVar;
        }

        public b(C0846v c0846v, androidx.recyclerview.widget.r rVar, int i10) {
            this.f62a = 9;
            this.f64c = c0846v;
            this.f63b = rVar;
        }
    }
