package A5;

import java.util.concurrent.Future;

/* JADX INFO: loaded from: classes.dex */
public interface c extends Future {
    void a(b bVar, p017b4.a aVar);
}
