package androidx.activity.result;

import O7.i;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.B;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0818s;
import androidx.lifecycle.EnumC0819t;
import androidx.lifecycle.F;
import com.bumptech.glide.d;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.NoSuchElementException;
import p032c7.AbstractC0933i;
import p073g.a;
import p073g.b;
import p073g.f;
import p073g.g;
import p097ha.k;
import p185pa.h;
import p185pa.m;

/* JADX INFO: loaded from: classes.dex */
public abstract class ActivityResultRegistry {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f15270a = new LinkedHashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f15271b = new LinkedHashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f15272c = new LinkedHashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f15273d = new ArrayList();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final transient LinkedHashMap f15274e = new LinkedHashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final LinkedHashMap f15275f = new LinkedHashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final Bundle f15276g = new Bundle();

    public final boolean a(int i10, int i11, Intent intent) {
        String str = (String) this.f15270a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        f fVar = (f) this.f15274e.get(str);
        if ((fVar != null ? fVar.f22698a : null) != null) {
            ArrayList arrayList = this.f15273d;
            if (arrayList.contains(str)) {
                fVar.f22698a.a(fVar.f22699b.E0(intent, i11));
                arrayList.remove(str);
                return true;
            }
        }
        this.f15275f.remove(str);
        this.f15276g.putParcelable(str, new a(intent, i11));
        return true;
    }

    public abstract void b(int i10, d dVar, Object obj, i iVar);

    public final p073g.i c(final String str, D d10, final d dVar, final b bVar) {
        k.f(str, "key");
        k.f(d10, "lifecycleOwner");
        k.f(dVar, "contract");
        F fJ = d10.j();
        if (fJ.f16395d.compareTo(EnumC0819t.f16527d) >= 0) {
            throw new IllegalStateException(("LifecycleOwner " + d10 + " is attempting to register while current state is " + fJ.f16395d + ". LifecycleOwners must call register before they are STARTED.").toString());
        }
        e(str);
        LinkedHashMap linkedHashMap = this.f15272c;
        g gVar = (g) linkedHashMap.get(str);
        if (gVar == null) {
            gVar = new g(fJ);
        }
        B b10 = new B() { // from class: g.e
            @Override // androidx.lifecycle.B
            public final void d(D d11, EnumC0818s enumC0818s) {
                ActivityResultRegistry activityResultRegistry = this.f22694a;
                k.f(activityResultRegistry, "this$0");
                String str2 = str;
                k.f(str2, "$key");
                b bVar2 = bVar;
                d dVar2 = dVar;
                k.f(dVar2, "$contract");
                EnumC0818s enumC0818s2 = EnumC0818s.ON_START;
                LinkedHashMap linkedHashMap2 = activityResultRegistry.f15274e;
                if (enumC0818s2 != enumC0818s) {
                    if (EnumC0818s.ON_STOP == enumC0818s) {
                        linkedHashMap2.remove(str2);
                        return;
                    } else {
                        if (EnumC0818s.ON_DESTROY == enumC0818s) {
                            activityResultRegistry.f(str2);
                            return;
                        }
                        return;
                    }
                }
                linkedHashMap2.put(str2, new f(dVar2, bVar2));
                LinkedHashMap linkedHashMap3 = activityResultRegistry.f15275f;
                if (linkedHashMap3.containsKey(str2)) {
                    Object obj = linkedHashMap3.get(str2);
                    linkedHashMap3.remove(str2);
                    bVar2.a(obj);
                }
                Bundle bundle = activityResultRegistry.f15276g;
                a aVar = (a) E5.b.D(bundle, str2);
                if (aVar != null) {
                    bundle.remove(str2);
                    bVar2.a(dVar2.E0(aVar.f22693b, aVar.f22692a));
                }
            }
        };
        gVar.f22700a.a(b10);
        gVar.f22701b.add(b10);
        linkedHashMap.put(str, gVar);
        return new p073g.i(this, str, dVar, 0);
    }

    public final p073g.i d(String str, d dVar, b bVar) {
        k.f(str, "key");
        e(str);
        this.f15274e.put(str, new f(dVar, bVar));
        LinkedHashMap linkedHashMap = this.f15275f;
        if (linkedHashMap.containsKey(str)) {
            Object obj = linkedHashMap.get(str);
            linkedHashMap.remove(str);
            bVar.a(obj);
        }
        Bundle bundle = this.f15276g;
        a aVar = (a) E5.b.D(bundle, str);
        if (aVar != null) {
            bundle.remove(str);
            bVar.a(dVar.E0(aVar.f22693b, aVar.f22692a));
        }
        return new p073g.i(this, str, dVar, 1);
    }

    public final void e(String str) {
        LinkedHashMap linkedHashMap = this.f15271b;
        if (((Integer) linkedHashMap.get(str)) != null) {
            return;
        }
        for (Number number : new p185pa.a(new h(p073g.h.f22702a, new m(1, 1)))) {
            int iIntValue = number.intValue();
            LinkedHashMap linkedHashMap2 = this.f15270a;
            if (!linkedHashMap2.containsKey(Integer.valueOf(iIntValue))) {
                int iIntValue2 = number.intValue();
                linkedHashMap2.put(Integer.valueOf(iIntValue2), str);
                linkedHashMap.put(str, Integer.valueOf(iIntValue2));
                return;
            }
        }
        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
    }

    public final void f(String str) {
        Integer num;
        k.f(str, "key");
        if (!this.f15273d.contains(str) && (num = (Integer) this.f15271b.remove(str)) != null) {
            this.f15270a.remove(num);
        }
        this.f15274e.remove(str);
        LinkedHashMap linkedHashMap = this.f15275f;
        if (linkedHashMap.containsKey(str)) {
            StringBuilder sbJ = AbstractC0933i.j("Dropping pending result for request ", str, ": ");
            sbJ.append(linkedHashMap.get(str));
            Log.w("ActivityResultRegistry", sbJ.toString());
            linkedHashMap.remove(str);
        }
        Bundle bundle = this.f15276g;
        if (bundle.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + ((a) E5.b.D(bundle, str)));
            bundle.remove(str);
        }
        LinkedHashMap linkedHashMap2 = this.f15272c;
        g gVar = (g) linkedHashMap2.get(str);
        if (gVar != null) {
            ArrayList arrayList = gVar.f22701b;
            int size = arrayList.size();
            int i10 = 0;
            while (i10 < size) {
                Object obj = arrayList.get(i10);
                i10++;
                gVar.f22700a.f((B) obj);
            }
            arrayList.clear();
            linkedHashMap2.remove(str);
        }
    }
}
