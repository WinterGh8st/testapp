package androidx.activity;

import N1.C0584u;
import N1.C0586w;
import N1.G;
import T9.l;
import Z2.f;
import android.app.Application;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultRegistry;
import androidx.lifecycle.B;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0818s;
import androidx.lifecycle.EnumC0819t;
import androidx.lifecycle.F;
import androidx.lifecycle.InterfaceC0815o;
import androidx.lifecycle.d0;
import androidx.lifecycle.f0;
import androidx.lifecycle.j0;
import androidx.lifecycle.r0;
import androidx.lifecycle.s0;
import androidx.lifecycle.w0;
import androidx.lifecycle.x0;
import com.flamingotools.ws.R;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;
import p037d.d;
import p037d.g;
import p037d.h;
import p037d.u;
import p037d.v;
import p051e1.E;
import p051e1.k;
import p051e1.m;
import p056e7.n;
import p073g.c;
import p073g.j;
import p076g2.b;
import p076g2.e;
import p089h2.a;

/* JADX INFO: loaded from: classes.dex */
public abstract class ComponentActivity extends k implements x0, InterfaceC0815o, e, v, j, c {

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final /* synthetic */ int f15251D = 0;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f15252A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final l f15253B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final l f15254C;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final T3.j f15255b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f f15256c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final n f15257d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public w0 f15258e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final h f15259f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final l f15260q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final AtomicInteger f15261r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final p037d.j f15262s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final CopyOnWriteArrayList f15263t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final CopyOnWriteArrayList f15264u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final CopyOnWriteArrayList f15265v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final CopyOnWriteArrayList f15266w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final CopyOnWriteArrayList f15267x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final CopyOnWriteArrayList f15268y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f15269z;

    public ComponentActivity() {
        T3.j jVar = new T3.j();
        jVar.f11609a = new CopyOnWriteArraySet();
        this.f15255b = jVar;
        this.f15256c = new f((Runnable) new d(this, 0));
        n nVar = new n(new a(this, new Ea.d(this, 4)), 12);
        this.f15257d = nVar;
        this.f15259f = new h(this);
        this.f15260q = android.support.v4.media.session.a.T(new p037d.k(this, 2));
        this.f15261r = new AtomicInteger();
        this.f15262s = new p037d.j(this);
        this.f15263t = new CopyOnWriteArrayList();
        this.f15264u = new CopyOnWriteArrayList();
        this.f15265v = new CopyOnWriteArrayList();
        this.f15266w = new CopyOnWriteArrayList();
        this.f15267x = new CopyOnWriteArrayList();
        this.f15268y = new CopyOnWriteArrayList();
        F f10 = this.f21785a;
        if (f10 == null) {
            throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
        }
        final int i10 = 0;
        f10.a(new B(this) { // from class: d.e

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ ComponentActivity f21343b;

            {
                this.f21343b = this;
            }

            @Override // androidx.lifecycle.B
            public final void d(D d10, EnumC0818s enumC0818s) {
                Window window;
                View viewPeekDecorView;
                switch (i10) {
                    case 0:
                        int i11 = ComponentActivity.f15251D;
                        ComponentActivity componentActivity = this.f21343b;
                        if (enumC0818s == EnumC0818s.ON_STOP && (window = componentActivity.getWindow()) != null && (viewPeekDecorView = window.peekDecorView()) != null) {
                            viewPeekDecorView.cancelPendingInputEvents();
                            break;
                        }
                        break;
                    default:
                        ComponentActivity componentActivity2 = this.f21343b;
                        int i12 = ComponentActivity.f15251D;
                        if (enumC0818s == EnumC0818s.ON_DESTROY) {
                            componentActivity2.f15255b.f11610b = null;
                            if (!componentActivity2.isChangingConfigurations()) {
                                componentActivity2.g().a();
                            }
                            h hVar = componentActivity2.f15259f;
                            ComponentActivity componentActivity3 = hVar.f21349d;
                            componentActivity3.getWindow().getDecorView().removeCallbacks(hVar);
                            componentActivity3.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(hVar);
                        }
                        break;
                }
            }
        });
        final int i11 = 1;
        this.f21785a.a(new B(this) { // from class: d.e

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ ComponentActivity f21343b;

            {
                this.f21343b = this;
            }

            @Override // androidx.lifecycle.B
            public final void d(D d10, EnumC0818s enumC0818s) {
                Window window;
                View viewPeekDecorView;
                switch (i11) {
                    case 0:
                        int i12 = ComponentActivity.f15251D;
                        ComponentActivity componentActivity = this.f21343b;
                        if (enumC0818s == EnumC0818s.ON_STOP && (window = componentActivity.getWindow()) != null && (viewPeekDecorView = window.peekDecorView()) != null) {
                            viewPeekDecorView.cancelPendingInputEvents();
                            break;
                        }
                        break;
                    default:
                        ComponentActivity componentActivity2 = this.f21343b;
                        int i13 = ComponentActivity.f15251D;
                        if (enumC0818s == EnumC0818s.ON_DESTROY) {
                            componentActivity2.f15255b.f11610b = null;
                            if (!componentActivity2.isChangingConfigurations()) {
                                componentActivity2.g().a();
                            }
                            h hVar = componentActivity2.f15259f;
                            ComponentActivity componentActivity3 = hVar.f21349d;
                            componentActivity3.getWindow().getDecorView().removeCallbacks(hVar);
                            componentActivity3.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(hVar);
                        }
                        break;
                }
            }
        });
        this.f21785a.a(new b(this, 2));
        nVar.y();
        j0.e(this);
        ((n) nVar.f22170c).E("android:support:activity-result", new C0584u(this, 3));
        l(new C0586w(this, 1));
        this.f15253B = android.support.v4.media.session.a.T(new p037d.k(this, 0));
        this.f15254C = android.support.v4.media.session.a.T(new p037d.k(this, 3));
    }

    @Override // p037d.v
    public final u a() {
        return (u) this.f15254C.getValue();
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m();
        View decorView = getWindow().getDecorView();
        p097ha.k.e(decorView, "window.decorView");
        this.f15259f.a(decorView);
        super.addContentView(view, layoutParams);
    }

    @Override // p076g2.e
    public final n b() {
        return (n) this.f15257d.f22170c;
    }

    @Override // androidx.lifecycle.InterfaceC0815o
    public final s0 d() {
        return (s0) this.f15253B.getValue();
    }

    @Override // androidx.lifecycle.InterfaceC0815o
    public final S1.d e() {
        S1.d dVar = new S1.d(0);
        Application application = getApplication();
        LinkedHashMap linkedHashMap = dVar.f11266a;
        if (application != null) {
            Y0.F f10 = r0.f16522d;
            Application application2 = getApplication();
            p097ha.k.e(application2, "application");
            linkedHashMap.put(f10, application2);
        }
        linkedHashMap.put(j0.f16496a, this);
        linkedHashMap.put(j0.f16497b, this);
        Intent intent = getIntent();
        Bundle extras = intent != null ? intent.getExtras() : null;
        if (extras != null) {
            linkedHashMap.put(j0.f16498c, extras);
        }
        return dVar;
    }

    @Override // p073g.j
    public final ActivityResultRegistry f() {
        return this.f15262s;
    }

    @Override // androidx.lifecycle.x0
    public final w0 g() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f15258e == null) {
            g gVar = (g) getLastNonConfigurationInstance();
            if (gVar != null) {
                this.f15258e = gVar.f21345a;
            }
            if (this.f15258e == null) {
                this.f15258e = new w0();
            }
        }
        w0 w0Var = this.f15258e;
        p097ha.k.c(w0Var);
        return w0Var;
    }

    @Override // androidx.lifecycle.D
    public final F j() {
        return this.f21785a;
    }

    public final void k(p189q1.a aVar) {
        p097ha.k.f(aVar, "listener");
        this.f15263t.add(aVar);
    }

    public final void l(p061f.a aVar) {
        T3.j jVar = this.f15255b;
        jVar.getClass();
        ComponentActivity componentActivity = (ComponentActivity) jVar.f11610b;
        if (componentActivity != null) {
            aVar.a(componentActivity);
        }
        ((CopyOnWriteArraySet) jVar.f11609a).add(aVar);
    }

    public final void m() {
        View decorView = getWindow().getDecorView();
        p097ha.k.e(decorView, "window.decorView");
        j0.m(decorView, this);
        View decorView2 = getWindow().getDecorView();
        p097ha.k.e(decorView2, "window.decorView");
        j0.n(decorView2, this);
        View decorView3 = getWindow().getDecorView();
        p097ha.k.e(decorView3, "window.decorView");
        Ua.d.Z(decorView3, this);
        View decorView4 = getWindow().getDecorView();
        p097ha.k.e(decorView4, "window.decorView");
        decorView4.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView5 = getWindow().getDecorView();
        p097ha.k.e(decorView5, "window.decorView");
        decorView5.setTag(R.id.report_drawn, this);
    }

    public final p073g.d n(com.bumptech.glide.d dVar, p073g.b bVar) {
        p097ha.k.f(dVar, "contract");
        p037d.j jVar = this.f15262s;
        p097ha.k.f(jVar, "registry");
        return jVar.c("activity_rq#" + this.f15261r.getAndIncrement(), this, dVar, bVar);
    }

    @Override // android.app.Activity
    public void onActivityResult(int i10, int i11, Intent intent) {
        if (this.f15262s.a(i10, i11, intent)) {
            return;
        }
        super.onActivityResult(i10, i11, intent);
    }

    @Override // android.app.Activity
    public final void onBackPressed() {
        a().d();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        p097ha.k.f(configuration, "newConfig");
        super.onConfigurationChanged(configuration);
        Iterator it = this.f15263t.iterator();
        while (it.hasNext()) {
            ((p189q1.a) it.next()).a(configuration);
        }
    }

    @Override // p051e1.k, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f15257d.z(bundle);
        T3.j jVar = this.f15255b;
        jVar.getClass();
        jVar.f11610b = this;
        Iterator it = ((CopyOnWriteArraySet) jVar.f11609a).iterator();
        while (it.hasNext()) {
            ((p061f.a) it.next()).a(this);
        }
        super.onCreate(bundle);
        int i10 = f0.f16483b;
        d0.b(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i10, Menu menu) {
        p097ha.k.f(menu, "menu");
        if (i10 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i10, menu);
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.f15256c.f14488b).iterator();
        while (it.hasNext()) {
            ((G) it.next()).f9005a.k();
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        p097ha.k.f(menuItem, "item");
        if (super.onMenuItemSelected(i10, menuItem)) {
            return true;
        }
        if (i10 == 0) {
            Iterator it = ((CopyOnWriteArrayList) this.f15256c.f14488b).iterator();
            while (it.hasNext()) {
                if (((G) it.next()).f9005a.p()) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z3) {
        if (this.f15269z) {
            return;
        }
        Iterator it = this.f15266w.iterator();
        while (it.hasNext()) {
            ((p189q1.a) it.next()).a(new m(z3));
        }
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        p097ha.k.f(intent, "intent");
        super.onNewIntent(intent);
        Iterator it = this.f15265v.iterator();
        while (it.hasNext()) {
            ((p189q1.a) it.next()).a(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i10, Menu menu) {
        p097ha.k.f(menu, "menu");
        Iterator it = ((CopyOnWriteArrayList) this.f15256c.f14488b).iterator();
        while (it.hasNext()) {
            ((G) it.next()).f9005a.q();
        }
        super.onPanelClosed(i10, menu);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z3) {
        if (this.f15252A) {
            return;
        }
        Iterator it = this.f15267x.iterator();
        while (it.hasNext()) {
            ((p189q1.a) it.next()).a(new E(z3));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i10, View view, Menu menu) {
        p097ha.k.f(menu, "menu");
        if (i10 != 0) {
            return true;
        }
        super.onPreparePanel(i10, view, menu);
        Iterator it = ((CopyOnWriteArrayList) this.f15256c.f14488b).iterator();
        while (it.hasNext()) {
            ((G) it.next()).f9005a.t();
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        p097ha.k.f(strArr, "permissions");
        p097ha.k.f(iArr, "grantResults");
        if (this.f15262s.a(i10, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i10, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        g gVar;
        w0 w0Var = this.f15258e;
        if (w0Var == null && (gVar = (g) getLastNonConfigurationInstance()) != null) {
            w0Var = gVar.f21345a;
        }
        if (w0Var == null) {
            return null;
        }
        g gVar2 = new g();
        gVar2.f21345a = w0Var;
        return gVar2;
    }

    @Override // p051e1.k, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        p097ha.k.f(bundle, "outState");
        F f10 = this.f21785a;
        if (f10 != null) {
            f10.g(EnumC0819t.f16526c);
        }
        super.onSaveInstanceState(bundle);
        this.f15257d.A(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public void onTrimMemory(int i10) {
        super.onTrimMemory(i10);
        Iterator it = this.f15264u.iterator();
        while (it.hasNext()) {
            ((p189q1.a) it.next()).a(Integer.valueOf(i10));
        }
    }

    @Override // android.app.Activity
    public final void onUserLeaveHint() {
        super.onUserLeaveHint();
        Iterator it = this.f15268y.iterator();
        while (it.hasNext()) {
            ((Runnable) it.next()).run();
        }
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (Ua.d.H()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            p037d.m mVar = (p037d.m) this.f15260q.getValue();
            synchronized (mVar.f21361b) {
                try {
                    mVar.f21362c = true;
                    ArrayList arrayList = mVar.f21363d;
                    int size = arrayList.size();
                    int i10 = 0;
                    while (i10 < size) {
                        Object obj = arrayList.get(i10);
                        i10++;
                        ((p084ga.a) obj).m();
                    }
                    mVar.f21363d.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
            Trace.endSection();
        } catch (Throwable th2) {
            Trace.endSection();
            throw th2;
        }
    }

    @Override // android.app.Activity
    public void setContentView(int i10) {
        m();
        View decorView = getWindow().getDecorView();
        p097ha.k.e(decorView, "window.decorView");
        this.f15259f.a(decorView);
        super.setContentView(i10);
    }

    @Override // android.app.Activity
    public final void startActivityForResult(Intent intent, int i10) {
        p097ha.k.f(intent, "intent");
        super.startActivityForResult(intent, i10);
    }

    @Override // android.app.Activity
    public final void startIntentSenderForResult(IntentSender intentSender, int i10, Intent intent, int i11, int i12, int i13) throws IntentSender.SendIntentException {
        p097ha.k.f(intentSender, "intent");
        super.startIntentSenderForResult(intentSender, i10, intent, i11, i12, i13);
    }

    @Override // android.app.Activity
    public final void startActivityForResult(Intent intent, int i10, Bundle bundle) {
        p097ha.k.f(intent, "intent");
        super.startActivityForResult(intent, i10, bundle);
    }

    @Override // android.app.Activity
    public final void startIntentSenderForResult(IntentSender intentSender, int i10, Intent intent, int i11, int i12, int i13, Bundle bundle) throws IntentSender.SendIntentException {
        p097ha.k.f(intentSender, "intent");
        super.startIntentSenderForResult(intentSender, i10, intent, i11, i12, i13, bundle);
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z3, Configuration configuration) {
        p097ha.k.f(configuration, "newConfig");
        this.f15269z = true;
        try {
            super.onMultiWindowModeChanged(z3, configuration);
            this.f15269z = false;
            Iterator it = this.f15266w.iterator();
            while (it.hasNext()) {
                ((p189q1.a) it.next()).a(new m(z3));
            }
        } catch (Throwable th) {
            this.f15269z = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z3, Configuration configuration) {
        p097ha.k.f(configuration, "newConfig");
        this.f15252A = true;
        try {
            super.onPictureInPictureModeChanged(z3, configuration);
            this.f15252A = false;
            Iterator it = this.f15267x.iterator();
            while (it.hasNext()) {
                ((p189q1.a) it.next()).a(new E(z3));
            }
        } catch (Throwable th) {
            this.f15252A = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        m();
        View decorView = getWindow().getDecorView();
        p097ha.k.e(decorView, "window.decorView");
        this.f15259f.a(decorView);
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        m();
        View decorView = getWindow().getDecorView();
        p097ha.k.e(decorView, "window.decorView");
        this.f15259f.a(decorView);
        super.setContentView(view, layoutParams);
    }
}
