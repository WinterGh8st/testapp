package androidx.recyclerview.widget;

import android.os.Trace;
import android.view.View;
import android.view.ViewGroup;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class I {
    private final J mObservable = new J();
    private boolean mHasStableIds = false;
    private H mStateRestorationPolicy = H.f16583a;

    public final void bindViewHolder(l0 l0Var, int i10) {
        boolean z3 = l0Var.mBindingAdapter == null;
        if (z3) {
            l0Var.mPosition = i10;
            if (hasStableIds()) {
                l0Var.mItemId = getItemId(i10);
            }
            l0Var.setFlags(1, 519);
            int i11 = p144m1.l.f24833a;
            Trace.beginSection("RV OnBindView");
        }
        l0Var.mBindingAdapter = this;
        if (RecyclerView.f16608K0) {
            if (l0Var.itemView.getParent() == null) {
                View view = l0Var.itemView;
                WeakHashMap weakHashMap = p200r1.U.f27683a;
                if (view.isAttachedToWindow() != l0Var.isTmpDetached()) {
                    throw new IllegalStateException("Temp-detached state out of sync with reality. holder.isTmpDetached(): " + l0Var.isTmpDetached() + ", attached to window: " + l0Var.itemView.isAttachedToWindow() + ", holder: " + l0Var);
                }
            }
            if (l0Var.itemView.getParent() == null) {
                View view2 = l0Var.itemView;
                WeakHashMap weakHashMap2 = p200r1.U.f27683a;
                if (view2.isAttachedToWindow()) {
                    throw new IllegalStateException("Attempting to bind attached holder with no parent (AKA temp detached): " + l0Var);
                }
            }
        }
        onBindViewHolder(l0Var, i10, l0Var.getUnmodifiedPayloads());
        if (z3) {
            l0Var.clearPayload();
            ViewGroup.LayoutParams layoutParams = l0Var.itemView.getLayoutParams();
            if (layoutParams instanceof RecyclerView.LayoutParams) {
                ((RecyclerView.LayoutParams) layoutParams).f16692c = true;
            }
            int i12 = p144m1.l.f24833a;
            Trace.endSection();
        }
    }

    public boolean canRestoreState() {
        int iOrdinal = this.mStateRestorationPolicy.ordinal();
        if (iOrdinal != 1) {
            if (iOrdinal == 2) {
                return false;
            }
        } else if (getItemCount() <= 0) {
            return false;
        }
        return true;
    }

    public final l0 createViewHolder(ViewGroup viewGroup, int i10) {
        try {
            int i11 = p144m1.l.f24833a;
            Trace.beginSection("RV CreateView");
            l0 l0VarOnCreateViewHolder = onCreateViewHolder(viewGroup, i10);
            if (l0VarOnCreateViewHolder.itemView.getParent() != null) {
                throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
            }
            l0VarOnCreateViewHolder.mItemViewType = i10;
            Trace.endSection();
            return l0VarOnCreateViewHolder;
        } catch (Throwable th) {
            int i12 = p144m1.l.f24833a;
            Trace.endSection();
            throw th;
        }
    }

    public int findRelativeAdapterPositionIn(I i10, l0 l0Var, int i11) {
        if (i10 == this) {
            return i11;
        }
        return -1;
    }

    public abstract int getItemCount();

    public long getItemId(int i10) {
        return -1L;
    }

    public int getItemViewType(int i10) {
        return 0;
    }

    public final H getStateRestorationPolicy() {
        return this.mStateRestorationPolicy;
    }

    public final boolean hasObservers() {
        return this.mObservable.a();
    }

    public final boolean hasStableIds() {
        return this.mHasStableIds;
    }

    public final void notifyDataSetChanged() {
        this.mObservable.b();
    }

    public final void notifyItemChanged(int i10) {
        this.mObservable.d(i10, 1, null);
    }

    public final void notifyItemInserted(int i10) {
        this.mObservable.e(i10, 1);
    }

    public final void notifyItemMoved(int i10, int i11) {
        this.mObservable.c(i10, i11);
    }

    public final void notifyItemRangeChanged(int i10, int i11) {
        this.mObservable.d(i10, i11, null);
    }

    public final void notifyItemRangeInserted(int i10, int i11) {
        this.mObservable.e(i10, i11);
    }

    public final void notifyItemRangeRemoved(int i10, int i11) {
        this.mObservable.f(i10, i11);
    }

    public final void notifyItemRemoved(int i10) {
        this.mObservable.f(i10, 1);
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
    }

    public abstract void onBindViewHolder(l0 l0Var, int i10);

    public void onBindViewHolder(l0 l0Var, int i10, List<Object> list) {
        onBindViewHolder(l0Var, i10);
    }

    public abstract l0 onCreateViewHolder(ViewGroup viewGroup, int i10);

    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
    }

    public boolean onFailedToRecycleView(l0 l0Var) {
        return false;
    }

    public void onViewAttachedToWindow(l0 l0Var) {
    }

    public void onViewDetachedFromWindow(l0 l0Var) {
    }

    public void onViewRecycled(l0 l0Var) {
    }

    public void registerAdapterDataObserver(K k) {
        this.mObservable.registerObserver(k);
    }

    public void setHasStableIds(boolean z3) {
        if (hasObservers()) {
            throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        }
        this.mHasStableIds = z3;
    }

    public void setStateRestorationPolicy(H h10) {
        this.mStateRestorationPolicy = h10;
        this.mObservable.g();
    }

    public void unregisterAdapterDataObserver(K k) {
        this.mObservable.unregisterObserver(k);
    }

    public final void notifyItemChanged(int i10, Object obj) {
        this.mObservable.d(i10, 1, obj);
    }

    public final void notifyItemRangeChanged(int i10, int i11, Object obj) {
        this.mObservable.d(i10, i11, obj);
    }
}
