package androidx.recyclerview.widget;

import android.graphics.PointF;

/* JADX INFO: loaded from: classes.dex */
public interface f0 {
    PointF a(int i10);
}
