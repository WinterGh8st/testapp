package androidx.recyclerview.widget;

import android.view.animation.BaseInterpolator;
import android.view.animation.Interpolator;
import android.widget.OverScroller;
import java.util.Arrays;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class k0 implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16833a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16834b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public OverScroller f16835c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Interpolator f16836d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16837e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f16838f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f16839q;

    public k0(RecyclerView recyclerView) {
        this.f16839q = recyclerView;
        E1.d dVar = RecyclerView.f16615S0;
        this.f16836d = dVar;
        this.f16837e = false;
        this.f16838f = false;
        this.f16835c = new OverScroller(recyclerView.getContext(), dVar);
    }

    public final void a(int i10, int i11) {
        RecyclerView recyclerView = this.f16839q;
        recyclerView.setScrollState(2);
        this.f16834b = 0;
        this.f16833a = 0;
        Interpolator interpolator = this.f16836d;
        E1.d dVar = RecyclerView.f16615S0;
        if (interpolator != dVar) {
            this.f16836d = dVar;
            this.f16835c = new OverScroller(recyclerView.getContext(), dVar);
        }
        this.f16835c.fling(0, 0, i10, i11, Integer.MIN_VALUE, com.google.android.gms.common.api.f.API_PRIORITY_OTHER, Integer.MIN_VALUE, com.google.android.gms.common.api.f.API_PRIORITY_OTHER);
        b();
    }

    public final void b() {
        if (this.f16837e) {
            this.f16838f = true;
            return;
        }
        RecyclerView recyclerView = this.f16839q;
        recyclerView.removeCallbacks(this);
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        recyclerView.postOnAnimation(this);
    }

    public final void c(int i10, int i11, int i12, BaseInterpolator baseInterpolator) {
        RecyclerView recyclerView = this.f16839q;
        if (i12 == Integer.MIN_VALUE) {
            int iAbs = Math.abs(i10);
            int iAbs2 = Math.abs(i11);
            boolean z3 = iAbs > iAbs2;
            int width = z3 ? recyclerView.getWidth() : recyclerView.getHeight();
            if (!z3) {
                iAbs = iAbs2;
            }
            i12 = Math.min((int) (((iAbs / width) + 1.0f) * 300.0f), 2000);
        }
        int i13 = i12;
        Interpolator interpolator = baseInterpolator;
        if (baseInterpolator == null) {
            interpolator = RecyclerView.f16615S0;
        }
        if (this.f16836d != interpolator) {
            this.f16836d = interpolator;
            this.f16835c = new OverScroller(recyclerView.getContext(), interpolator);
        }
        this.f16834b = 0;
        this.f16833a = 0;
        recyclerView.setScrollState(2);
        this.f16835c.startScroll(0, 0, i10, i11, i13);
        b();
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        RecyclerView recyclerView = this.f16839q;
        if (recyclerView.f16684x == null) {
            recyclerView.removeCallbacks(this);
            this.f16835c.abortAnimation();
            return;
        }
        this.f16838f = false;
        this.f16837e = true;
        recyclerView.p();
        OverScroller overScroller = this.f16835c;
        if (overScroller.computeScrollOffset()) {
            int currX = overScroller.getCurrX();
            int currY = overScroller.getCurrY();
            int i15 = currX - this.f16833a;
            int i16 = currY - this.f16834b;
            this.f16833a = currX;
            this.f16834b = currY;
            int iO = RecyclerView.o(i15, recyclerView.f16644S, recyclerView.f16646U, recyclerView.getWidth());
            int iO2 = RecyclerView.o(i16, recyclerView.f16645T, recyclerView.f16647V, recyclerView.getHeight());
            int[] iArr = recyclerView.f16624D0;
            iArr[0] = 0;
            iArr[1] = 0;
            boolean zV = recyclerView.v(iO, iO2, 1, iArr, null);
            int[] iArr2 = recyclerView.f16624D0;
            if (zV) {
                iO -= iArr2[0];
                iO2 -= iArr2[1];
            }
            if (recyclerView.getOverScrollMode() != 2) {
                recyclerView.n(iO, iO2);
            }
            if (recyclerView.f16682w != null) {
                iArr2[0] = 0;
                iArr2[1] = 0;
                recyclerView.g0(iO, iO2, iArr2);
                int i17 = iArr2[0];
                int i18 = iArr2[1];
                int i19 = iO - i17;
                int i20 = iO2 - i18;
                B b10 = recyclerView.f16684x.f16725e;
                if (b10 != null && !b10.f16797d && b10.f16798e) {
                    int iB = recyclerView.f16674r0.b();
                    if (iB == 0) {
                        b10.d();
                    } else if (b10.f16794a >= iB) {
                        b10.f16794a = iB - 1;
                        b10.b(i17, i18);
                    } else {
                        b10.b(i17, i18);
                    }
                }
                i10 = i19;
                i12 = i17;
                i11 = i20;
                i13 = i18;
            } else {
                i10 = iO;
                i11 = iO2;
                i12 = 0;
                i13 = 0;
            }
            if (!recyclerView.f16688z.isEmpty()) {
                recyclerView.invalidate();
            }
            int[] iArr3 = recyclerView.f16624D0;
            iArr3[0] = 0;
            iArr3[1] = 0;
            recyclerView.w(i12, i13, i10, i11, null, 1, iArr3);
            int i21 = i10 - iArr2[0];
            int i22 = i11 - iArr2[1];
            if (i12 != 0 || i13 != 0) {
                recyclerView.x(i12, i13);
            }
            if (!recyclerView.awakenScrollBars()) {
                recyclerView.invalidate();
            }
            boolean z3 = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i21 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i22 != 0));
            B b11 = recyclerView.f16684x.f16725e;
            if ((b11 == null || !b11.f16797d) && z3) {
                if (recyclerView.getOverScrollMode() != 2) {
                    int currVelocity = (int) overScroller.getCurrVelocity();
                    if (i21 < 0) {
                        i14 = -currVelocity;
                    } else {
                        i14 = i21 > 0 ? currVelocity : 0;
                    }
                    if (i22 < 0) {
                        currVelocity = -currVelocity;
                    } else if (i22 <= 0) {
                        currVelocity = 0;
                    }
                    if (i14 < 0) {
                        recyclerView.z();
                        if (recyclerView.f16644S.isFinished()) {
                            recyclerView.f16644S.onAbsorb(-i14);
                        }
                    } else if (i14 > 0) {
                        recyclerView.A();
                        if (recyclerView.f16646U.isFinished()) {
                            recyclerView.f16646U.onAbsorb(i14);
                        }
                    }
                    if (currVelocity < 0) {
                        recyclerView.B();
                        if (recyclerView.f16645T.isFinished()) {
                            recyclerView.f16645T.onAbsorb(-currVelocity);
                        }
                    } else if (currVelocity > 0) {
                        recyclerView.y();
                        if (recyclerView.f16647V.isFinished()) {
                            recyclerView.f16647V.onAbsorb(currVelocity);
                        }
                    }
                    if (i14 != 0 || currVelocity != 0) {
                        WeakHashMap weakHashMap = p200r1.U.f27683a;
                        recyclerView.postInvalidateOnAnimation();
                    }
                }
                if (RecyclerView.f16613Q0) {
                    Db.m mVar = recyclerView.f16672q0;
                    int[] iArr4 = (int[]) mVar.f2664e;
                    if (iArr4 != null) {
                        Arrays.fill(iArr4, -1);
                    }
                    mVar.f2663d = 0;
                }
            } else {
                b();
                RunnableC0840o runnableC0840o = recyclerView.f16670p0;
                if (runnableC0840o != null) {
                    runnableC0840o.a(recyclerView, i12, i13);
                }
            }
        }
        B b12 = recyclerView.f16684x.f16725e;
        if (b12 != null && b12.f16797d) {
            b12.b(0, 0);
        }
        this.f16837e = false;
        if (!this.f16838f) {
            recyclerView.setScrollState(0);
            recyclerView.n0(1);
        } else {
            recyclerView.removeCallbacks(this);
            WeakHashMap weakHashMap2 = p200r1.U.f27683a;
            recyclerView.postOnAnimation(this);
        }
    }
}
