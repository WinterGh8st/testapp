package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public final class n0 extends X {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16878a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ E f16879b;

    public n0(E e10) {
        this.f16879b = e10;
    }

    @Override // androidx.recyclerview.widget.X
    public final void a(RecyclerView recyclerView, int i10) {
        if (i10 == 0 && this.f16878a) {
            this.f16878a = false;
            this.f16879b.h();
        }
    }

    @Override // androidx.recyclerview.widget.X
    public final void b(RecyclerView recyclerView, int i10, int i11) {
        if (i10 == 0 && i11 == 0) {
            return;
        }
        this.f16878a = true;
    }
}
