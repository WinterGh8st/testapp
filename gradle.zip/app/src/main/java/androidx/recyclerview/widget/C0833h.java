package androidx.recyclerview.widget;

import L.C0499e0;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.recyclerview.widget.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public class C0833h extends N {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static TimeInterpolator f16802s;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f16803g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final ArrayList f16804h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ArrayList f16805i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final ArrayList f16806j;
    public final ArrayList k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final ArrayList f16807l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final ArrayList f16808m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final ArrayList f16809n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final ArrayList f16810o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final ArrayList f16811p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final ArrayList f16812q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final ArrayList f16813r;

    public C0833h() {
        this.f16600a = null;
        this.f16601b = new ArrayList();
        this.f16602c = 120L;
        this.f16603d = 120L;
        this.f16604e = 250L;
        this.f16605f = 250L;
        this.f16803g = true;
        this.f16804h = new ArrayList();
        this.f16805i = new ArrayList();
        this.f16806j = new ArrayList();
        this.k = new ArrayList();
        this.f16807l = new ArrayList();
        this.f16808m = new ArrayList();
        this.f16809n = new ArrayList();
        this.f16810o = new ArrayList();
        this.f16811p = new ArrayList();
        this.f16812q = new ArrayList();
        this.f16813r = new ArrayList();
    }

    public static void i(ArrayList arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            ((l0) arrayList.get(size)).itemView.animate().cancel();
        }
    }

    @Override // androidx.recyclerview.widget.N
    public final boolean a(l0 l0Var, l0 l0Var2, C0499e0 c0499e0, C0499e0 c0499e1) {
        int i10;
        int i11;
        int i12 = c0499e0.f7841a;
        int i13 = c0499e0.f7842b;
        if (l0Var2.shouldIgnore()) {
            int i14 = c0499e0.f7841a;
            i11 = c0499e0.f7842b;
            i10 = i14;
        } else {
            i10 = c0499e1.f7841a;
            i11 = c0499e1.f7842b;
        }
        if (l0Var == l0Var2) {
            return h(l0Var, i12, i13, i10, i11);
        }
        float translationX = l0Var.itemView.getTranslationX();
        float translationY = l0Var.itemView.getTranslationY();
        float alpha = l0Var.itemView.getAlpha();
        m(l0Var);
        l0Var.itemView.setTranslationX(translationX);
        l0Var.itemView.setTranslationY(translationY);
        l0Var.itemView.setAlpha(alpha);
        m(l0Var2);
        l0Var2.itemView.setTranslationX(-((int) ((i10 - i12) - translationX)));
        l0Var2.itemView.setTranslationY(-((int) ((i11 - i13) - translationY)));
        l0Var2.itemView.setAlpha(0.0f);
        ArrayList arrayList = this.k;
        C0831f c0831f = new C0831f();
        c0831f.f16783a = l0Var;
        c0831f.f16784b = l0Var2;
        c0831f.f16785c = i12;
        c0831f.f16786d = i13;
        c0831f.f16787e = i10;
        c0831f.f16788f = i11;
        arrayList.add(c0831f);
        return true;
    }

    @Override // androidx.recyclerview.widget.N
    public final void d(l0 l0Var) {
        View view = l0Var.itemView;
        view.animate().cancel();
        ArrayList arrayList = this.f16806j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (((C0832g) arrayList.get(size)).f16789a == l0Var) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                c(l0Var);
                arrayList.remove(size);
            }
        }
        k(this.k, l0Var);
        if (this.f16804h.remove(l0Var)) {
            view.setAlpha(1.0f);
            c(l0Var);
        }
        if (this.f16805i.remove(l0Var)) {
            view.setAlpha(1.0f);
            c(l0Var);
        }
        ArrayList arrayList2 = this.f16809n;
        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
            ArrayList arrayList3 = (ArrayList) arrayList2.get(size2);
            k(arrayList3, l0Var);
            if (arrayList3.isEmpty()) {
                arrayList2.remove(size2);
            }
        }
        ArrayList arrayList4 = this.f16808m;
        for (int size3 = arrayList4.size() - 1; size3 >= 0; size3--) {
            ArrayList arrayList5 = (ArrayList) arrayList4.get(size3);
            for (int size4 = arrayList5.size() - 1; size4 >= 0; size4--) {
                if (((C0832g) arrayList5.get(size4)).f16789a == l0Var) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    c(l0Var);
                    arrayList5.remove(size4);
                    if (!arrayList5.isEmpty()) {
                        break;
                    }
                    arrayList4.remove(size3);
                    break;
                }
            }
        }
        ArrayList arrayList6 = this.f16807l;
        for (int size5 = arrayList6.size() - 1; size5 >= 0; size5--) {
            ArrayList arrayList7 = (ArrayList) arrayList6.get(size5);
            if (arrayList7.remove(l0Var)) {
                view.setAlpha(1.0f);
                c(l0Var);
                if (arrayList7.isEmpty()) {
                    arrayList6.remove(size5);
                }
            }
        }
        this.f16812q.remove(l0Var);
        this.f16810o.remove(l0Var);
        this.f16813r.remove(l0Var);
        this.f16811p.remove(l0Var);
        j();
    }

    @Override // androidx.recyclerview.widget.N
    public final void e() {
        ArrayList arrayList = this.f16806j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            C0832g c0832g = (C0832g) arrayList.get(size);
            View view = c0832g.f16789a.itemView;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            c(c0832g.f16789a);
            arrayList.remove(size);
        }
        ArrayList arrayList2 = this.f16804h;
        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
            c((l0) arrayList2.get(size2));
            arrayList2.remove(size2);
        }
        ArrayList arrayList3 = this.f16805i;
        int size3 = arrayList3.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            l0 l0Var = (l0) arrayList3.get(size3);
            l0Var.itemView.setAlpha(1.0f);
            c(l0Var);
            arrayList3.remove(size3);
        }
        ArrayList arrayList4 = this.k;
        for (int size4 = arrayList4.size() - 1; size4 >= 0; size4--) {
            C0831f c0831f = (C0831f) arrayList4.get(size4);
            l0 l0Var2 = c0831f.f16783a;
            if (l0Var2 != null) {
                l(c0831f, l0Var2);
            }
            l0 l0Var3 = c0831f.f16784b;
            if (l0Var3 != null) {
                l(c0831f, l0Var3);
            }
        }
        arrayList4.clear();
        if (f()) {
            ArrayList arrayList5 = this.f16808m;
            for (int size5 = arrayList5.size() - 1; size5 >= 0; size5--) {
                ArrayList arrayList6 = (ArrayList) arrayList5.get(size5);
                for (int size6 = arrayList6.size() - 1; size6 >= 0; size6--) {
                    C0832g c0832g2 = (C0832g) arrayList6.get(size6);
                    View view2 = c0832g2.f16789a.itemView;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    c(c0832g2.f16789a);
                    arrayList6.remove(size6);
                    if (arrayList6.isEmpty()) {
                        arrayList5.remove(arrayList6);
                    }
                }
            }
            ArrayList arrayList7 = this.f16807l;
            for (int size7 = arrayList7.size() - 1; size7 >= 0; size7--) {
                ArrayList arrayList8 = (ArrayList) arrayList7.get(size7);
                for (int size8 = arrayList8.size() - 1; size8 >= 0; size8--) {
                    l0 l0Var4 = (l0) arrayList8.get(size8);
                    l0Var4.itemView.setAlpha(1.0f);
                    c(l0Var4);
                    arrayList8.remove(size8);
                    if (arrayList8.isEmpty()) {
                        arrayList7.remove(arrayList8);
                    }
                }
            }
            ArrayList arrayList9 = this.f16809n;
            for (int size9 = arrayList9.size() - 1; size9 >= 0; size9--) {
                ArrayList arrayList10 = (ArrayList) arrayList9.get(size9);
                for (int size10 = arrayList10.size() - 1; size10 >= 0; size10--) {
                    C0831f c0831f2 = (C0831f) arrayList10.get(size10);
                    l0 l0Var5 = c0831f2.f16783a;
                    if (l0Var5 != null) {
                        l(c0831f2, l0Var5);
                    }
                    l0 l0Var6 = c0831f2.f16784b;
                    if (l0Var6 != null) {
                        l(c0831f2, l0Var6);
                    }
                    if (arrayList10.isEmpty()) {
                        arrayList9.remove(arrayList10);
                    }
                }
            }
            i(this.f16812q);
            i(this.f16811p);
            i(this.f16810o);
            i(this.f16813r);
            ArrayList arrayList11 = this.f16601b;
            if (arrayList11.size() > 0) {
                arrayList11.get(0).getClass();
                throw new ClassCastException();
            }
            arrayList11.clear();
        }
    }

    @Override // androidx.recyclerview.widget.N
    public final boolean f() {
        return (this.f16805i.isEmpty() && this.k.isEmpty() && this.f16806j.isEmpty() && this.f16804h.isEmpty() && this.f16811p.isEmpty() && this.f16812q.isEmpty() && this.f16810o.isEmpty() && this.f16813r.isEmpty() && this.f16808m.isEmpty() && this.f16807l.isEmpty() && this.f16809n.isEmpty()) ? false : true;
    }

    public final boolean h(l0 l0Var, int i10, int i11, int i12, int i13) {
        View view = l0Var.itemView;
        int translationX = i10 + ((int) view.getTranslationX());
        int translationY = i11 + ((int) l0Var.itemView.getTranslationY());
        m(l0Var);
        int i14 = i12 - translationX;
        int i15 = i13 - translationY;
        if (i14 == 0 && i15 == 0) {
            c(l0Var);
            return false;
        }
        if (i14 != 0) {
            view.setTranslationX(-i14);
        }
        if (i15 != 0) {
            view.setTranslationY(-i15);
        }
        ArrayList arrayList = this.f16806j;
        C0832g c0832g = new C0832g();
        c0832g.f16789a = l0Var;
        c0832g.f16790b = translationX;
        c0832g.f16791c = translationY;
        c0832g.f16792d = i12;
        c0832g.f16793e = i13;
        arrayList.add(c0832g);
        return true;
    }

    public final void j() {
        if (f()) {
            return;
        }
        ArrayList arrayList = this.f16601b;
        if (arrayList.size() <= 0) {
            arrayList.clear();
        } else {
            arrayList.get(0).getClass();
            throw new ClassCastException();
        }
    }

    public final void k(ArrayList arrayList, l0 l0Var) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            C0831f c0831f = (C0831f) arrayList.get(size);
            if (l(c0831f, l0Var) && c0831f.f16783a == null && c0831f.f16784b == null) {
                arrayList.remove(c0831f);
            }
        }
    }

    public final boolean l(C0831f c0831f, l0 l0Var) {
        if (c0831f.f16784b == l0Var) {
            c0831f.f16784b = null;
        } else {
            if (c0831f.f16783a != l0Var) {
                return false;
            }
            c0831f.f16783a = null;
        }
        l0Var.itemView.setAlpha(1.0f);
        l0Var.itemView.setTranslationX(0.0f);
        l0Var.itemView.setTranslationY(0.0f);
        c(l0Var);
        return true;
    }

    public final void m(l0 l0Var) {
        if (f16802s == null) {
            f16802s = new ValueAnimator().getInterpolator();
        }
        l0Var.itemView.animate().setInterpolator(f16802s);
        d(l0Var);
    }
}
