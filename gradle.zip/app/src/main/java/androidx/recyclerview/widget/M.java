package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public abstract class M {
}
