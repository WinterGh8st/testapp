package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class F implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16570a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f16571b;

    public /* synthetic */ F(RecyclerView recyclerView, int i10) {
        this.f16570a = i10;
        this.f16571b = recyclerView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        RecyclerView recyclerView3 = this.f16571b;
        int i10 = 1;
        switch (this.f16570a) {
            case 0:
                if (recyclerView3.f16625E && !recyclerView3.isLayoutRequested()) {
                    if (!recyclerView3.f16621C) {
                        recyclerView3.requestLayout();
                    } else if (!recyclerView3.f16631H) {
                        recyclerView3.p();
                    } else {
                        recyclerView3.f16629G = true;
                    }
                    break;
                }
                break;
            default:
                N n10 = recyclerView3.f16648W;
                if (n10 != null) {
                    C0833h c0833h = (C0833h) n10;
                    ArrayList arrayList = c0833h.f16804h;
                    boolean zIsEmpty = arrayList.isEmpty();
                    ArrayList arrayList2 = c0833h.f16806j;
                    boolean zIsEmpty2 = arrayList2.isEmpty();
                    ArrayList arrayList3 = c0833h.k;
                    boolean zIsEmpty3 = arrayList3.isEmpty();
                    ArrayList arrayList4 = c0833h.f16805i;
                    boolean zIsEmpty4 = arrayList4.isEmpty();
                    if (zIsEmpty && zIsEmpty2 && zIsEmpty4 && zIsEmpty3) {
                        recyclerView2 = recyclerView3;
                    } else {
                        int size = arrayList.size();
                        recyclerView2 = recyclerView3;
                        int i11 = 0;
                        while (true) {
                            long j10 = c0833h.f16603d;
                            if (i11 < size) {
                                Object obj = arrayList.get(i11);
                                i11 += i10;
                                l0 l0Var = (l0) obj;
                                View view = l0Var.itemView;
                                ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
                                c0833h.f16812q.add(l0Var);
                                viewPropertyAnimatorAnimate.setDuration(j10).alpha(0.0f).setListener(new C0828c(c0833h, l0Var, viewPropertyAnimatorAnimate, view)).start();
                                arrayList = arrayList;
                                i10 = 1;
                            } else {
                                arrayList.clear();
                                if (!zIsEmpty2) {
                                    ArrayList arrayList5 = new ArrayList();
                                    arrayList5.addAll(arrayList2);
                                    c0833h.f16808m.add(arrayList5);
                                    arrayList2.clear();
                                    RunnableC0827b runnableC0827b = new RunnableC0827b(c0833h, arrayList5, 0);
                                    if (zIsEmpty) {
                                        runnableC0827b.run();
                                    } else {
                                        View view2 = ((C0832g) arrayList5.get(0)).f16789a.itemView;
                                        WeakHashMap weakHashMap = p200r1.U.f27683a;
                                        view2.postOnAnimationDelayed(runnableC0827b, j10);
                                    }
                                }
                                if (!zIsEmpty3) {
                                    ArrayList arrayList6 = new ArrayList();
                                    arrayList6.addAll(arrayList3);
                                    c0833h.f16809n.add(arrayList6);
                                    arrayList3.clear();
                                    RunnableC0827b runnableC0827b2 = new RunnableC0827b(c0833h, arrayList6, 1);
                                    if (zIsEmpty) {
                                        runnableC0827b2.run();
                                    } else {
                                        View view3 = ((C0831f) arrayList6.get(0)).f16783a.itemView;
                                        WeakHashMap weakHashMap2 = p200r1.U.f27683a;
                                        view3.postOnAnimationDelayed(runnableC0827b2, j10);
                                    }
                                }
                                if (!zIsEmpty4) {
                                    ArrayList arrayList7 = new ArrayList();
                                    arrayList7.addAll(arrayList4);
                                    c0833h.f16807l.add(arrayList7);
                                    arrayList4.clear();
                                    RunnableC0827b runnableC0827b3 = new RunnableC0827b(c0833h, arrayList7, 2);
                                    if (zIsEmpty && zIsEmpty2 && zIsEmpty3) {
                                        runnableC0827b3.run();
                                    } else {
                                        if (zIsEmpty) {
                                            j10 = 0;
                                        }
                                        long jMax = Math.max(!zIsEmpty2 ? c0833h.f16604e : 0L, zIsEmpty3 ? 0L : c0833h.f16605f) + j10;
                                        View view4 = ((l0) arrayList7.get(0)).itemView;
                                        WeakHashMap weakHashMap3 = p200r1.U.f27683a;
                                        view4.postOnAnimationDelayed(runnableC0827b3, jMax);
                                    }
                                }
                            }
                        }
                    }
                    recyclerView = recyclerView2;
                } else {
                    recyclerView = recyclerView3;
                }
                recyclerView.f16685x0 = false;
                break;
        }
    }
}
