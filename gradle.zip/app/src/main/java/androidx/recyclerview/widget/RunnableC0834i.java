package androidx.recyclerview.widget;

import android.animation.ValueAnimator;
import android.graphics.Rect;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: androidx.recyclerview.widget.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0834i implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16827a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f16828b;

    public /* synthetic */ RunnableC0834i(Object obj, int i10) {
        this.f16827a = i10;
        this.f16828b = obj;
    }

    /* JADX WARN: Code duplicated, block: B:27:0x008a  */
    @Override // java.lang.Runnable
    public final void run() {
        int iE;
        int height;
        int iE2 = 0;
        Object obj = this.f16828b;
        switch (this.f16827a) {
            case 0:
                C0838m c0838m = (C0838m) obj;
                int i10 = c0838m.f16844A;
                ValueAnimator valueAnimator = c0838m.f16870z;
                if (i10 == 1) {
                    valueAnimator.cancel();
                } else if (i10 != 2) {
                }
                c0838m.f16844A = 3;
                valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
                valueAnimator.setDuration(500);
                valueAnimator.start();
                break;
            case 1:
                C0846v c0846v = (C0846v) obj;
                if (c0846v.f16942c != null) {
                    long jCurrentTimeMillis = System.currentTimeMillis();
                    long j10 = c0846v.f16939B;
                    long j11 = j10 == Long.MIN_VALUE ? 0L : jCurrentTimeMillis - j10;
                    T layoutManager = c0846v.f16956r.getLayoutManager();
                    if (c0846v.f16938A == null) {
                        c0846v.f16938A = new Rect();
                    }
                    layoutManager.d(c0846v.f16938A, c0846v.f16942c.itemView);
                    if (layoutManager.e()) {
                        int i11 = (int) (c0846v.f16949j + c0846v.f16947h);
                        int paddingLeft = (i11 - c0846v.f16938A.left) - c0846v.f16956r.getPaddingLeft();
                        float f10 = c0846v.f16947h;
                        if ((f10 >= 0.0f || paddingLeft >= 0) && (f10 <= 0.0f || (paddingLeft = ((c0846v.f16942c.itemView.getWidth() + i11) + c0846v.f16938A.right) - (c0846v.f16956r.getWidth() - c0846v.f16956r.getPaddingRight())) <= 0)) {
                            iE = 0;
                        } else {
                            iE = paddingLeft;
                        }
                    } else {
                        iE = 0;
                    }
                    if (layoutManager.f()) {
                        int i12 = (int) (c0846v.k + c0846v.f16948i);
                        int paddingTop = (i12 - c0846v.f16938A.top) - c0846v.f16956r.getPaddingTop();
                        float f11 = c0846v.f16948i;
                        if (f11 < 0.0f && paddingTop < 0) {
                            iE2 = paddingTop;
                        } else if (f11 > 0.0f && (height = ((c0846v.f16942c.itemView.getHeight() + i12) + c0846v.f16938A.bottom) - (c0846v.f16956r.getHeight() - c0846v.f16956r.getPaddingBottom())) > 0) {
                            iE2 = height;
                        }
                    }
                    if (iE != 0) {
                        PaymentMethodsRecyclerView paymentMethodsRecyclerView = c0846v.f16956r;
                        int width = c0846v.f16942c.itemView.getWidth();
                        c0846v.f16956r.getWidth();
                        iE = c0846v.f16951m.e(paymentMethodsRecyclerView, width, iE, j11);
                    }
                    int i13 = iE;
                    if (iE2 != 0) {
                        PaymentMethodsRecyclerView paymentMethodsRecyclerView2 = c0846v.f16956r;
                        int height2 = c0846v.f16942c.itemView.getHeight();
                        c0846v.f16956r.getHeight();
                        iE2 = c0846v.f16951m.e(paymentMethodsRecyclerView2, height2, iE2, j11);
                    }
                    if (i13 == 0 && iE2 == 0) {
                        c0846v.f16939B = Long.MIN_VALUE;
                    } else {
                        if (c0846v.f16939B == Long.MIN_VALUE) {
                            c0846v.f16939B = jCurrentTimeMillis;
                        }
                        c0846v.f16956r.scrollBy(i13, iE2);
                        l0 l0Var = c0846v.f16942c;
                        if (l0Var != null) {
                            c0846v.p(l0Var);
                        }
                        c0846v.f16956r.removeCallbacks(c0846v.f16957s);
                        PaymentMethodsRecyclerView paymentMethodsRecyclerView3 = c0846v.f16956r;
                        WeakHashMap weakHashMap = p200r1.U.f27683a;
                        paymentMethodsRecyclerView3.postOnAnimation(this);
                    }
                }
                break;
            default:
                ((StaggeredGridLayoutManager) obj).I0();
                break;
        }
    }
}
