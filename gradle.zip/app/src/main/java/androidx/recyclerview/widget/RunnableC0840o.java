package androidx.recyclerview.widget;

import B0.C0048e;
import android.os.Trace;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

/* JADX INFO: renamed from: androidx.recyclerview.widget.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0840o implements Runnable {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final ThreadLocal f16880e = new ThreadLocal();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final C0048e f16881f = new C0048e(6);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ArrayList f16882a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f16883b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f16884c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ArrayList f16885d;

    public static l0 c(RecyclerView recyclerView, int i10, long j10) {
        int iH = recyclerView.f16659f.H();
        for (int i11 = 0; i11 < iH; i11++) {
            l0 l0VarM = RecyclerView.M(recyclerView.f16659f.G(i11));
            if (l0VarM.mPosition == i10 && !l0VarM.isInvalid()) {
                return null;
            }
        }
        a0 a0Var = recyclerView.f16653c;
        try {
            recyclerView.T();
            l0 l0VarK = a0Var.k(i10, j10);
            if (l0VarK != null) {
                if (!l0VarK.isBound() || l0VarK.isInvalid()) {
                    a0Var.a(l0VarK, false);
                } else {
                    a0Var.h(l0VarK.itemView);
                }
            }
            return l0VarK;
        } finally {
            recyclerView.U(false);
        }
    }

    public final void a(RecyclerView recyclerView, int i10, int i11) {
        if (recyclerView.f16621C) {
            if (RecyclerView.f16608K0 && !this.f16882a.contains(recyclerView)) {
                throw new IllegalStateException("attempting to post unregistered view!");
            }
            if (this.f16883b == 0) {
                this.f16883b = recyclerView.getNanoTime();
                recyclerView.post(this);
            }
        }
        Db.m mVar = recyclerView.f16672q0;
        mVar.f2661b = i10;
        mVar.f2662c = i11;
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00ca  */
    public final void b(long j10) {
        C0839n c0839n;
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        C0839n c0839n2;
        ArrayList arrayList = this.f16882a;
        int size = arrayList.size();
        int i10 = 0;
        for (int i11 = 0; i11 < size; i11++) {
            RecyclerView recyclerView3 = (RecyclerView) arrayList.get(i11);
            if (recyclerView3.getWindowVisibility() == 0) {
                Db.m mVar = recyclerView3.f16672q0;
                mVar.b(recyclerView3, false);
                i10 += mVar.f2663d;
            }
        }
        ArrayList arrayList2 = this.f16885d;
        arrayList2.ensureCapacity(i10);
        int i12 = 0;
        for (int i13 = 0; i13 < size; i13++) {
            RecyclerView recyclerView4 = (RecyclerView) arrayList.get(i13);
            if (recyclerView4.getWindowVisibility() == 0) {
                Db.m mVar2 = recyclerView4.f16672q0;
                int iAbs = Math.abs(mVar2.f2662c) + Math.abs(mVar2.f2661b);
                for (int i14 = 0; i14 < mVar2.f2663d * 2; i14 += 2) {
                    if (i12 >= arrayList2.size()) {
                        c0839n2 = new C0839n();
                        arrayList2.add(c0839n2);
                    } else {
                        c0839n2 = (C0839n) arrayList2.get(i12);
                    }
                    int[] iArr = (int[]) mVar2.f2664e;
                    int i15 = iArr[i14 + 1];
                    c0839n2.f16873a = i15 <= iAbs;
                    c0839n2.f16874b = iAbs;
                    c0839n2.f16875c = i15;
                    c0839n2.f16876d = recyclerView4;
                    c0839n2.f16877e = iArr[i14];
                    i12++;
                }
            }
        }
        Collections.sort(arrayList2, f16881f);
        for (int i16 = 0; i16 < arrayList2.size() && (recyclerView = (c0839n = (C0839n) arrayList2.get(i16)).f16876d) != null; i16++) {
            l0 l0VarC = c(recyclerView, c0839n.f16877e, c0839n.f16873a ? Long.MAX_VALUE : j10);
            if (l0VarC != null && l0VarC.mNestedRecyclerView != null && l0VarC.isBound() && !l0VarC.isInvalid() && (recyclerView2 = l0VarC.mNestedRecyclerView.get()) != null) {
                if (recyclerView2.f16639N && recyclerView2.f16659f.H() != 0) {
                    N n10 = recyclerView2.f16648W;
                    if (n10 != null) {
                        n10.e();
                    }
                    T t10 = recyclerView2.f16684x;
                    a0 a0Var = recyclerView2.f16653c;
                    if (t10 != null) {
                        t10.o0(a0Var);
                        recyclerView2.f16684x.p0(a0Var);
                    }
                    a0Var.f16746a.clear();
                    a0Var.f();
                }
                Db.m mVar3 = recyclerView2.f16672q0;
                mVar3.b(recyclerView2, true);
                if (mVar3.f2663d != 0) {
                    try {
                        int i17 = p144m1.l.f24833a;
                        Trace.beginSection("RV Nested Prefetch");
                        h0 h0Var = recyclerView2.f16674r0;
                        I i18 = recyclerView2.f16682w;
                        h0Var.f16817d = 1;
                        h0Var.f16818e = i18.getItemCount();
                        h0Var.f16820g = false;
                        h0Var.f16821h = false;
                        h0Var.f16822i = false;
                        for (int i19 = 0; i19 < mVar3.f2663d * 2; i19 += 2) {
                            c(recyclerView2, ((int[]) mVar3.f2664e)[i19], j10);
                        }
                        Trace.endSection();
                    } catch (Throwable th) {
                        int i20 = p144m1.l.f24833a;
                        Trace.endSection();
                        throw th;
                    }
                }
            }
            c0839n.f16873a = false;
            c0839n.f16874b = 0;
            c0839n.f16875c = 0;
            c0839n.f16876d = null;
            c0839n.f16877e = 0;
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i10 = p144m1.l.f24833a;
            Trace.beginSection("RV Prefetch");
            ArrayList arrayList = this.f16882a;
            if (arrayList.isEmpty()) {
                this.f16883b = 0L;
                return;
            }
            int size = arrayList.size();
            long jMax = 0;
            for (int i11 = 0; i11 < size; i11++) {
                RecyclerView recyclerView = (RecyclerView) arrayList.get(i11);
                if (recyclerView.getWindowVisibility() == 0) {
                    jMax = Math.max(recyclerView.getDrawingTime(), jMax);
                }
            }
            if (jMax == 0) {
                this.f16883b = 0L;
            } else {
                b(TimeUnit.MILLISECONDS.toNanos(jMax) + this.f16884c);
                this.f16883b = 0L;
            }
        } finally {
            this.f16883b = 0L;
            int i12 = p144m1.l.f24833a;
            Trace.endSection();
        }
    }
}
