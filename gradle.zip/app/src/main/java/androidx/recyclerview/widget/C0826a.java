package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0826a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16742a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16743b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Object f16744c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16745d;

    public final boolean equals(Object obj) {
        if (this != obj) {
            if (!(obj instanceof C0826a)) {
                return false;
            }
            C0826a c0826a = (C0826a) obj;
            int i10 = this.f16742a;
            if (i10 != c0826a.f16742a) {
                return false;
            }
            if (i10 != 8 || Math.abs(this.f16745d - this.f16743b) != 1 || this.f16745d != c0826a.f16743b || this.f16743b != c0826a.f16745d) {
                if (this.f16745d != c0826a.f16745d || this.f16743b != c0826a.f16743b) {
                    return false;
                }
                Object obj2 = this.f16744c;
                if (obj2 != null) {
                    if (!obj2.equals(c0826a.f16744c)) {
                        return false;
                    }
                } else if (c0826a.f16744c != null) {
                    return false;
                }
            }
        }
        return true;
    }

    public final int hashCode() {
        return (((this.f16742a * 31) + this.f16743b) * 31) + this.f16745d;
    }

    public final String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(Integer.toHexString(System.identityHashCode(this)));
        sb2.append("[");
        int i10 = this.f16742a;
        if (i10 == 1) {
            str = "add";
        } else if (i10 == 2) {
            str = "rm";
        } else if (i10 != 4) {
            str = i10 != 8 ? "??" : "mv";
        } else {
            str = "up";
        }
        sb2.append(str);
        sb2.append(",s:");
        sb2.append(this.f16743b);
        sb2.append("c:");
        sb2.append(this.f16745d);
        sb2.append(",p:");
        sb2.append(this.f16744c);
        sb2.append("]");
        return sb2.toString();
    }
}
