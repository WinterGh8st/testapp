package androidx.recyclerview.widget;

import android.view.View;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class t0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16932a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16933b = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16934c = Integer.MIN_VALUE;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16935d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f16936e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ StaggeredGridLayoutManager f16937f;

    public t0(StaggeredGridLayoutManager staggeredGridLayoutManager, int i10) {
        this.f16937f = staggeredGridLayoutManager;
        this.f16936e = i10;
    }

    public final void a() {
        View view = (View) p096h9.i.h(1, this.f16932a);
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) view.getLayoutParams();
        this.f16934c = this.f16937f.f16711r.b(view);
        layoutParams.getClass();
    }

    public final void b() {
        this.f16932a.clear();
        this.f16933b = Integer.MIN_VALUE;
        this.f16934c = Integer.MIN_VALUE;
        this.f16935d = 0;
    }

    public final int c() {
        boolean z3 = this.f16937f.f16716w;
        ArrayList arrayList = this.f16932a;
        return z3 ? e(arrayList.size() - 1, -1) : e(0, arrayList.size());
    }

    public final int d() {
        boolean z3 = this.f16937f.f16716w;
        ArrayList arrayList = this.f16932a;
        return z3 ? e(0, arrayList.size()) : e(arrayList.size() - 1, -1);
    }

    public final int e(int i10, int i11) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f16937f;
        int iK = staggeredGridLayoutManager.f16711r.k();
        int iG = staggeredGridLayoutManager.f16711r.g();
        int i12 = i11 > i10 ? 1 : -1;
        while (i10 != i11) {
            View view = (View) this.f16932a.get(i10);
            int iE = staggeredGridLayoutManager.f16711r.e(view);
            int iB = staggeredGridLayoutManager.f16711r.b(view);
            boolean z3 = iE <= iG;
            boolean z5 = iB >= iK;
            if (z3 && z5 && (iE < iK || iB > iG)) {
                return T.M(view);
            }
            i10 += i12;
        }
        return -1;
    }

    public final int f(int i10) {
        int i11 = this.f16934c;
        if (i11 != Integer.MIN_VALUE) {
            return i11;
        }
        if (this.f16932a.size() == 0) {
            return i10;
        }
        a();
        return this.f16934c;
    }

    public final View g(int i10, int i11) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f16937f;
        ArrayList arrayList = this.f16932a;
        View view = null;
        if (i11 != -1) {
            int size = arrayList.size() - 1;
            while (size >= 0) {
                View view2 = (View) arrayList.get(size);
                if ((staggeredGridLayoutManager.f16716w && T.M(view2) >= i10) || ((!staggeredGridLayoutManager.f16716w && T.M(view2) <= i10) || !view2.hasFocusable())) {
                    break;
                }
                size--;
                view = view2;
            }
            return view;
        }
        int size2 = arrayList.size();
        int i12 = 0;
        while (i12 < size2) {
            View view3 = (View) arrayList.get(i12);
            if ((staggeredGridLayoutManager.f16716w && T.M(view3) <= i10) || ((!staggeredGridLayoutManager.f16716w && T.M(view3) >= i10) || !view3.hasFocusable())) {
                break;
            }
            i12++;
            view = view3;
        }
        return view;
    }

    public final int h(int i10) {
        int i11 = this.f16933b;
        if (i11 != Integer.MIN_VALUE) {
            return i11;
        }
        if (this.f16932a.size() == 0) {
            return i10;
        }
        View view = (View) this.f16932a.get(0);
        StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) view.getLayoutParams();
        this.f16933b = this.f16937f.f16711r.e(view);
        layoutParams.getClass();
        return this.f16933b;
    }
}
