package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0832g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l0 f16789a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16790b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16791c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16792d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16793e;
}
