package androidx.recyclerview.widget;

import android.R;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: androidx.recyclerview.widget.m, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0838m extends O implements W {

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public static final int[] f16842C = {R.attr.state_pressed};

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final int[] f16843D = new int[0];

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f16844A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final RunnableC0834i f16845B;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f16846a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f16847b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final StateListDrawable f16848c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Drawable f16849d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f16850e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f16851f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final StateListDrawable f16852g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final Drawable f16853h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f16854i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final int f16855j;
    public int k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f16856l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public float f16857m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f16858n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f16859o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public float f16860p;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final RecyclerView f16863s;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final ValueAnimator f16870z;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f16861q = 0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f16862r = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f16864t = false;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f16865u = false;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f16866v = 0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f16867w = 0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int[] f16868x = new int[2];

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int[] f16869y = new int[2];

    public C0838m(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i10, int i11, int i12) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f16870z = valueAnimatorOfFloat;
        this.f16844A = 0;
        RunnableC0834i runnableC0834i = new RunnableC0834i(this, 0);
        this.f16845B = runnableC0834i;
        C0835j c0835j = new C0835j(this);
        this.f16848c = stateListDrawable;
        this.f16849d = drawable;
        this.f16852g = stateListDrawable2;
        this.f16853h = drawable2;
        this.f16850e = Math.max(i10, stateListDrawable.getIntrinsicWidth());
        this.f16851f = Math.max(i10, drawable.getIntrinsicWidth());
        this.f16854i = Math.max(i10, stateListDrawable2.getIntrinsicWidth());
        this.f16855j = Math.max(i10, drawable2.getIntrinsicWidth());
        this.f16846a = i11;
        this.f16847b = i12;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        valueAnimatorOfFloat.addListener(new C0836k(this));
        valueAnimatorOfFloat.addUpdateListener(new C0837l(this, 0));
        RecyclerView recyclerView2 = this.f16863s;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            recyclerView2.c0(this);
            RecyclerView recyclerView3 = this.f16863s;
            recyclerView3.f16617A.remove(this);
            if (recyclerView3.f16619B == this) {
                recyclerView3.f16619B = null;
            }
            ArrayList arrayList = this.f16863s.f16678t0;
            if (arrayList != null) {
                arrayList.remove(c0835j);
            }
            this.f16863s.removeCallbacks(runnableC0834i);
        }
        this.f16863s = recyclerView;
        if (recyclerView != null) {
            recyclerView.i(this);
            this.f16863s.f16617A.add(this);
            this.f16863s.j(c0835j);
        }
    }

    public static int k(float f10, float f11, int[] iArr, int i10, int i11, int i12) {
        int i13 = iArr[1] - iArr[0];
        if (i13 != 0) {
            int i14 = i10 - i12;
            int i15 = (int) (((f11 - f10) / i13) * i14);
            int i16 = i11 + i15;
            if (i16 < i14 && i16 >= 0) {
                return i15;
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.W
    public final void b(MotionEvent motionEvent) {
        if (this.f16866v == 0) {
            return;
        }
        if (motionEvent.getAction() == 0) {
            boolean zJ = j(motionEvent.getX(), motionEvent.getY());
            boolean zI = i(motionEvent.getX(), motionEvent.getY());
            if (zJ || zI) {
                if (zI) {
                    this.f16867w = 1;
                    this.f16860p = (int) motionEvent.getX();
                } else if (zJ) {
                    this.f16867w = 2;
                    this.f16857m = (int) motionEvent.getY();
                }
                l(2);
                return;
            }
            return;
        }
        if (motionEvent.getAction() == 1 && this.f16866v == 2) {
            this.f16857m = 0.0f;
            this.f16860p = 0.0f;
            l(1);
            this.f16867w = 0;
            return;
        }
        if (motionEvent.getAction() == 2 && this.f16866v == 2) {
            m();
            int i10 = this.f16867w;
            int i11 = this.f16847b;
            if (i10 == 1) {
                float x10 = motionEvent.getX();
                int[] iArr = this.f16869y;
                iArr[0] = i11;
                int i12 = this.f16861q - i11;
                iArr[1] = i12;
                float fMax = Math.max(i11, Math.min(i12, x10));
                if (Math.abs(this.f16859o - fMax) >= 2.0f) {
                    int iK = k(this.f16860p, fMax, iArr, this.f16863s.computeHorizontalScrollRange(), this.f16863s.computeHorizontalScrollOffset(), this.f16861q);
                    if (iK != 0) {
                        this.f16863s.scrollBy(iK, 0);
                    }
                    this.f16860p = fMax;
                }
            }
            if (this.f16867w == 2) {
                float y10 = motionEvent.getY();
                int[] iArr2 = this.f16868x;
                iArr2[0] = i11;
                int i13 = this.f16862r - i11;
                iArr2[1] = i13;
                float fMax2 = Math.max(i11, Math.min(i13, y10));
                if (Math.abs(this.f16856l - fMax2) < 2.0f) {
                    return;
                }
                int iK2 = k(this.f16857m, fMax2, iArr2, this.f16863s.computeVerticalScrollRange(), this.f16863s.computeVerticalScrollOffset(), this.f16862r);
                if (iK2 != 0) {
                    this.f16863s.scrollBy(0, iK2);
                }
                this.f16857m = fMax2;
            }
        }
    }

    @Override // androidx.recyclerview.widget.W
    public final boolean c(MotionEvent motionEvent) {
        int i10 = this.f16866v;
        if (i10 != 1) {
            return i10 == 2;
        }
        boolean zJ = j(motionEvent.getX(), motionEvent.getY());
        boolean zI = i(motionEvent.getX(), motionEvent.getY());
        if (motionEvent.getAction() != 0) {
            return false;
        }
        if (!zJ && !zI) {
            return false;
        }
        if (zI) {
            this.f16867w = 1;
            this.f16860p = (int) motionEvent.getX();
        } else if (zJ) {
            this.f16867w = 2;
            this.f16857m = (int) motionEvent.getY();
        }
        l(2);
        return true;
    }

    @Override // androidx.recyclerview.widget.O
    public final void h(Canvas canvas, RecyclerView recyclerView) {
        int i10 = this.f16861q;
        RecyclerView recyclerView2 = this.f16863s;
        if (i10 != recyclerView2.getWidth() || this.f16862r != recyclerView2.getHeight()) {
            this.f16861q = recyclerView2.getWidth();
            this.f16862r = recyclerView2.getHeight();
            l(0);
            return;
        }
        if (this.f16844A != 0) {
            if (this.f16864t) {
                int i11 = this.f16861q;
                int i12 = this.f16850e;
                int i13 = i11 - i12;
                int i14 = this.f16856l;
                int i15 = this.k;
                int i16 = i14 - (i15 / 2);
                StateListDrawable stateListDrawable = this.f16848c;
                stateListDrawable.setBounds(0, 0, i12, i15);
                int i17 = this.f16862r;
                int i18 = this.f16851f;
                Drawable drawable = this.f16849d;
                drawable.setBounds(0, 0, i18, i17);
                WeakHashMap weakHashMap = p200r1.U.f27683a;
                if (recyclerView2.getLayoutDirection() == 1) {
                    drawable.draw(canvas);
                    canvas.translate(i12, i16);
                    canvas.scale(-1.0f, 1.0f);
                    stateListDrawable.draw(canvas);
                    canvas.scale(-1.0f, 1.0f);
                    canvas.translate(-i12, -i16);
                } else {
                    canvas.translate(i13, 0.0f);
                    drawable.draw(canvas);
                    canvas.translate(0.0f, i16);
                    stateListDrawable.draw(canvas);
                    canvas.translate(-i13, -i16);
                }
            }
            if (this.f16865u) {
                int i19 = this.f16862r;
                int i20 = this.f16854i;
                int i21 = i19 - i20;
                int i22 = this.f16859o;
                int i23 = this.f16858n;
                int i24 = i22 - (i23 / 2);
                StateListDrawable stateListDrawable2 = this.f16852g;
                stateListDrawable2.setBounds(0, 0, i23, i20);
                int i25 = this.f16861q;
                int i26 = this.f16855j;
                Drawable drawable2 = this.f16853h;
                drawable2.setBounds(0, 0, i25, i26);
                canvas.translate(0.0f, i21);
                drawable2.draw(canvas);
                canvas.translate(i24, 0.0f);
                stateListDrawable2.draw(canvas);
                canvas.translate(-i24, -i21);
            }
        }
    }

    public final boolean i(float f10, float f11) {
        if (f11 < this.f16862r - this.f16854i) {
            return false;
        }
        int i10 = this.f16859o;
        int i11 = this.f16858n;
        return f10 >= ((float) (i10 - (i11 / 2))) && f10 <= ((float) ((i11 / 2) + i10));
    }

    public final boolean j(float f10, float f11) {
        RecyclerView recyclerView = this.f16863s;
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        boolean z3 = recyclerView.getLayoutDirection() == 1;
        int i10 = this.f16850e;
        if (!z3 ? f10 >= this.f16861q - i10 : f10 <= i10) {
            int i11 = this.f16856l;
            int i12 = this.k / 2;
            if (f11 >= i11 - i12 && f11 <= i12 + i11) {
                return true;
            }
        }
        return false;
    }

    public final void l(int i10) {
        RunnableC0834i runnableC0834i = this.f16845B;
        StateListDrawable stateListDrawable = this.f16848c;
        if (i10 == 2 && this.f16866v != 2) {
            stateListDrawable.setState(f16842C);
            this.f16863s.removeCallbacks(runnableC0834i);
        }
        if (i10 == 0) {
            this.f16863s.invalidate();
        } else {
            m();
        }
        if (this.f16866v == 2 && i10 != 2) {
            stateListDrawable.setState(f16843D);
            this.f16863s.removeCallbacks(runnableC0834i);
            this.f16863s.postDelayed(runnableC0834i, 1200);
        } else if (i10 == 1) {
            this.f16863s.removeCallbacks(runnableC0834i);
            this.f16863s.postDelayed(runnableC0834i, 1500);
        }
        this.f16866v = i10;
    }

    public final void m() {
        int i10 = this.f16844A;
        ValueAnimator valueAnimator = this.f16870z;
        if (i10 != 0) {
            if (i10 != 3) {
                return;
            } else {
                valueAnimator.cancel();
            }
        }
        this.f16844A = 1;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        valueAnimator.setDuration(500L);
        valueAnimator.setStartDelay(0L);
        valueAnimator.start();
    }

    @Override // androidx.recyclerview.widget.W
    public final void e(boolean z3) {
    }
}
