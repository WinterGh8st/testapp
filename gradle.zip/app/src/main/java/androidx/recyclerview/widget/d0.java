package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class d0 extends D1.c {
    public static final Parcelable.Creator<d0> CREATOR = new D1.b(9);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Parcelable f16770c;

    public d0(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f16770c = parcel.readParcelable(classLoader == null ? T.class.getClassLoader() : classLoader);
    }

    @Override // D1.c, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        super.writeToParcel(parcel, i10);
        parcel.writeParcelable(this.f16770c, 0);
    }
}
