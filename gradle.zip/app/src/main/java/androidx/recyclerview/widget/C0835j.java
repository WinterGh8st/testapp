package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0835j extends X {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0838m f16829a;

    public C0835j(C0838m c0838m) {
        this.f16829a = c0838m;
    }

    @Override // androidx.recyclerview.widget.X
    public final void b(RecyclerView recyclerView, int i10, int i11) {
        int iComputeHorizontalScrollOffset = recyclerView.computeHorizontalScrollOffset();
        int iComputeVerticalScrollOffset = recyclerView.computeVerticalScrollOffset();
        C0838m c0838m = this.f16829a;
        int iComputeVerticalScrollRange = c0838m.f16863s.computeVerticalScrollRange();
        int i12 = c0838m.f16862r;
        int i13 = iComputeVerticalScrollRange - i12;
        int i14 = c0838m.f16846a;
        c0838m.f16864t = i13 > 0 && i12 >= i14;
        int iComputeHorizontalScrollRange = c0838m.f16863s.computeHorizontalScrollRange();
        int i15 = c0838m.f16861q;
        boolean z3 = iComputeHorizontalScrollRange - i15 > 0 && i15 >= i14;
        c0838m.f16865u = z3;
        boolean z5 = c0838m.f16864t;
        if (!z5 && !z3) {
            if (c0838m.f16866v != 0) {
                c0838m.l(0);
                return;
            }
            return;
        }
        if (z5) {
            float f10 = i12;
            c0838m.f16856l = (int) ((((f10 / 2.0f) + iComputeVerticalScrollOffset) * f10) / iComputeVerticalScrollRange);
            c0838m.k = Math.min(i12, (i12 * i12) / iComputeVerticalScrollRange);
        }
        if (c0838m.f16865u) {
            float f11 = iComputeHorizontalScrollOffset;
            float f12 = i15;
            c0838m.f16859o = (int) ((((f12 / 2.0f) + f11) * f12) / iComputeHorizontalScrollRange);
            c0838m.f16858n = Math.min(i15, (i15 * i15) / iComputeHorizontalScrollRange);
        }
        int i16 = c0838m.f16866v;
        if (i16 == 0 || i16 == 1) {
            c0838m.l(1);
        }
    }
}
