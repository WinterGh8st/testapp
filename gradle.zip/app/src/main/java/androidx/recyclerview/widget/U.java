package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface U {
    void a(View view);

    void d(View view);
}
