package androidx.recyclerview.widget;

import C9.C0090f1;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: androidx.recyclerview.widget.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0843s extends GestureDetector.SimpleOnGestureListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16916a = true;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0846v f16917b;

    public C0843s(C0846v c0846v) {
        this.f16917b = c0846v;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public final boolean onDown(MotionEvent motionEvent) {
        return true;
    }

    @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
    public final void onLongPress(MotionEvent motionEvent) {
        C0846v c0846v;
        View viewM;
        l0 l0VarL;
        if (!this.f16916a || (viewM = (c0846v = this.f16917b).m(motionEvent)) == null || (l0VarL = c0846v.f16956r.L(viewM)) == null) {
            return;
        }
        C0090f1 c0090f1 = c0846v.f16951m;
        PaymentMethodsRecyclerView paymentMethodsRecyclerView = c0846v.f16956r;
        int iD = c0090f1.d(paymentMethodsRecyclerView, l0VarL);
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        if ((AbstractC0844t.b(iD, paymentMethodsRecyclerView.getLayoutDirection()) & 16711680) != 0) {
            int pointerId = motionEvent.getPointerId(0);
            int i10 = c0846v.f16950l;
            if (pointerId == i10) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i10);
                float x10 = motionEvent.getX(iFindPointerIndex);
                float y10 = motionEvent.getY(iFindPointerIndex);
                c0846v.f16943d = x10;
                c0846v.f16944e = y10;
                c0846v.f16948i = 0.0f;
                c0846v.f16947h = 0.0f;
                c0846v.f16951m.getClass();
                c0846v.r(l0VarL, 2);
            }
        }
    }
}
