package androidx.recyclerview.widget;

import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class o0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16886a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16887b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16888c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16889d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16890e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int[] f16891f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final /* synthetic */ StaggeredGridLayoutManager f16892g;

    public o0(StaggeredGridLayoutManager staggeredGridLayoutManager) {
        this.f16892g = staggeredGridLayoutManager;
        a();
    }

    public final void a() {
        this.f16886a = -1;
        this.f16887b = Integer.MIN_VALUE;
        this.f16888c = false;
        this.f16889d = false;
        this.f16890e = false;
        int[] iArr = this.f16891f;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
    }
}
