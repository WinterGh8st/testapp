package androidx.recyclerview.widget;

import android.view.MotionEvent;

/* JADX INFO: loaded from: classes.dex */
public interface W {
    void b(MotionEvent motionEvent);

    boolean c(MotionEvent motionEvent);

    void e(boolean z3);
}
