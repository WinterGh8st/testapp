package androidx.recyclerview.widget;

import G6.F0;
import G6.y0;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import java.io.Serializable;
import java.util.LinkedHashSet;
import p021b8.C0886c;
import p021b8.C0887d;
import p021b8.C0888e;
import p021b8.C0889f;
import p021b8.C0890g;
import p021b8.C0897n;
import p021b8.C0898o;
import p021b8.EnumC0885b;
import p032c7.C0934j;
import p032c7.C0935k;
import p032c7.C0936l;
import p032c7.C0938n;
import p032c7.C0939o;
import p032c7.C0944u;
import p032c7.C0945v;
import p183p8.C1408m1;
import p183p8.C1430u0;
import p183p8.C1431u1;
import p183p8.R0;

/* JADX INFO: loaded from: classes.dex */
public final class p0 implements Parcelable.Creator {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16893a;

    public /* synthetic */ p0(int i10) {
        this.f16893a = i10;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        int i10;
        int i11;
        p024c.b bVar;
        int i12;
        int i13;
        int i14;
        int i15 = 3;
        int i16 = 1;
        switch (this.f16893a) {
            case 0:
                q0 q0Var = new q0();
                q0Var.f16895a = parcel.readInt();
                q0Var.f16896b = parcel.readInt();
                q0Var.f16898d = parcel.readInt() == 1;
                int i17 = parcel.readInt();
                if (i17 > 0) {
                    int[] iArr = new int[i17];
                    q0Var.f16897c = iArr;
                    parcel.readIntArray(iArr);
                }
                return q0Var;
            case 1:
                s0 s0Var = new s0();
                s0Var.f16918a = parcel.readInt();
                s0Var.f16919b = parcel.readInt();
                int i18 = parcel.readInt();
                s0Var.f16920c = i18;
                if (i18 > 0) {
                    int[] iArr2 = new int[i18];
                    s0Var.f16921d = iArr2;
                    parcel.readIntArray(iArr2);
                }
                int i19 = parcel.readInt();
                s0Var.f16922e = i19;
                if (i19 > 0) {
                    int[] iArr3 = new int[i19];
                    s0Var.f16923f = iArr3;
                    parcel.readIntArray(iArr3);
                }
                s0Var.f16925r = parcel.readInt() == 1;
                s0Var.f16926s = parcel.readInt() == 1;
                s0Var.f16927t = parcel.readInt() == 1;
                s0Var.f16924q = parcel.readArrayList(q0.class.getClassLoader());
                return s0Var;
            case 2:
                p097ha.k.f(parcel, "parcel");
                boolean z3 = parcel.readInt() != 0;
                String string = parcel.readString();
                if (string == null) {
                    throw new NullPointerException("Name is null");
                }
                if (string.equals("Min")) {
                    i10 = 1;
                } else {
                    if (!string.equals("Full")) {
                        throw new IllegalArgumentException("No enum constant com.stripe.android.googlepaylauncher.GooglePayLauncher.BillingAddressConfig.Format.".concat(string));
                    }
                    i10 = 2;
                }
                return new C0886c(i10, z3, parcel.readInt() != 0);
            case 3:
                p097ha.k.f(parcel, "parcel");
                return new C0887d(EnumC0885b.valueOf(parcel.readString()), parcel.readString(), parcel.readString(), parcel.readInt() != 0, C0886c.CREATOR.createFromParcel(parcel), parcel.readInt() != 0, parcel.readInt() != 0);
            case 4:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return C0888e.f17762a;
            case 5:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return C0889f.f17763a;
            case 6:
                p097ha.k.f(parcel, "parcel");
                return new C0890g((Throwable) parcel.readSerializable());
            case 7:
                p097ha.k.f(parcel, "parcel");
                return new C0897n(parcel.readString(), C0887d.CREATOR.createFromParcel(parcel));
            case 8:
                p097ha.k.f(parcel, "parcel");
                return new C0898o(parcel.readString(), C0887d.CREATOR.createFromParcel(parcel), parcel.readString());
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                p097ha.k.f(parcel, "parcel");
                boolean z5 = parcel.readInt() != 0;
                String string2 = parcel.readString();
                if (string2 == null) {
                    throw new NullPointerException("Name is null");
                }
                if (string2.equals("Min")) {
                    i11 = 1;
                } else {
                    if (!string2.equals("Full")) {
                        throw new IllegalArgumentException("No enum constant com.stripe.android.googlepaylauncher.GooglePayPaymentMethodLauncher.BillingAddressConfig.Format.".concat(string2));
                    }
                    i11 = 2;
                }
                return new p021b8.w(i11, z5, parcel.readInt() != 0);
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                p097ha.k.f(parcel, "parcel");
                return new p021b8.x(EnumC0885b.valueOf(parcel.readString()), parcel.readString(), parcel.readString(), parcel.readInt() != 0, p021b8.w.CREATOR.createFromParcel(parcel), parcel.readInt() != 0, parcel.readInt() != 0);
            case 11:
                p097ha.k.f(parcel, "parcel");
                parcel.readInt();
                return p021b8.y.f17821a;
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                p097ha.k.f(parcel, "parcel");
                return new p021b8.z(R0.CREATOR.createFromParcel(parcel));
            case 13:
                p097ha.k.f(parcel, "parcel");
                return new p021b8.A(parcel.readInt(), (Throwable) parcel.readSerializable());
            case 14:
                p097ha.k.f(parcel, "parcel");
                return new p021b8.I(p021b8.x.CREATOR.createFromParcel(parcel), parcel.readString(), parcel.readLong(), parcel.readString(), parcel.readInt() == 0 ? null : p021b8.H.CREATOR.createFromParcel(parcel));
            case 15:
                p097ha.k.f(parcel, "parcel");
                String string3 = parcel.readString();
                int i20 = parcel.readInt();
                LinkedHashSet linkedHashSet = new LinkedHashSet(i20);
                for (int i21 = 0; i21 != i20; i21++) {
                    linkedHashSet.add(parcel.readString());
                }
                return new p021b8.H(string3, linkedHashSet, parcel.readInt() != 0, parcel.readString(), parcel.readString());
            case 16:
                p097ha.k.f(parcel, "parcel");
                return new b9.a(parcel.readString(), parcel.readInt());
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                p097ha.k.f(parcel, "parcel");
                String string4 = parcel.readString();
                String string5 = parcel.readString();
                String string6 = parcel.readString();
                if (string6 == null) {
                    throw new NullPointerException("Name is null");
                }
                if (string6.equals("LOW")) {
                    i15 = 1;
                } else if (string6.equals("MEDIUM")) {
                    i15 = 2;
                } else if (!string6.equals("HIGH")) {
                    throw new IllegalArgumentException("No enum constant com.stripe.android.stripe3ds2.init.Warning.Severity.".concat(string6));
                }
                return new b9.m(i15, string4, string5);
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                p024c.d dVar = new p024c.d();
                IBinder strongBinder = parcel.readStrongBinder();
                int i22 = p024c.c.f17963b;
                if (strongBinder == null) {
                    bVar = null;
                } else {
                    IInterface iInterfaceQueryLocalInterface = strongBinder.queryLocalInterface(p024c.b.f17962d);
                    if (iInterfaceQueryLocalInterface == null || !(iInterfaceQueryLocalInterface instanceof p024c.b)) {
                        p024c.a aVar = new p024c.a();
                        aVar.f17961a = strongBinder;
                        bVar = aVar;
                    } else {
                        bVar = (p024c.b) iInterfaceQueryLocalInterface;
                    }
                }
                dVar.f17965a = bVar;
                return dVar;
            case 19:
                p097ha.k.f(parcel, "parcel");
                boolean z10 = parcel.readInt() != 0;
                String string7 = parcel.readString();
                if (string7 == null) {
                    throw new NullPointerException("Name is null");
                }
                if (string7.equals("Min")) {
                    i12 = 1;
                } else {
                    if (!string7.equals("Full")) {
                        throw new IllegalArgumentException("No enum constant com.stripe.android.GooglePayJsonFactory.BillingAddressParameters.Format.".concat(string7));
                    }
                    i12 = 2;
                }
                return new C0934j(i12, z10, parcel.readInt() != 0);
            case 20:
                p097ha.k.f(parcel, "parcel");
                return new C0935k(parcel.readString());
            case 21:
                p097ha.k.f(parcel, "parcel");
                String string8 = parcel.readString();
                String string9 = parcel.readString();
                if (string9 == null) {
                    throw new NullPointerException("Name is null");
                }
                if (string9.equals("NotCurrentlyKnown")) {
                    i13 = 2;
                    i15 = 1;
                } else if (string9.equals("Estimated")) {
                    i15 = 2;
                    i13 = 2;
                } else {
                    if (!string9.equals("Final")) {
                        throw new IllegalArgumentException("No enum constant com.stripe.android.GooglePayJsonFactory.TransactionInfo.TotalPriceStatus.".concat(string9));
                    }
                    i13 = 2;
                }
                String string10 = parcel.readString();
                String string11 = parcel.readString();
                Long lValueOf = parcel.readInt() != 0 ? Long.valueOf(parcel.readLong()) : null;
                String string12 = parcel.readString();
                if (parcel.readInt() == 0) {
                    i14 = 0;
                } else {
                    String string13 = parcel.readString();
                    if (string13 == null) {
                        throw new NullPointerException("Name is null");
                    }
                    if (!string13.equals("Default")) {
                        if (!string13.equals("CompleteImmediatePurchase")) {
                            throw new IllegalArgumentException("No enum constant com.stripe.android.GooglePayJsonFactory.TransactionInfo.CheckoutOption.".concat(string13));
                        }
                        i16 = i13;
                    }
                    i14 = i16;
                }
                return new C0936l(string8, i15, string10, string11, lValueOf, string12, i14);
            case 22:
                p097ha.k.f(parcel, "parcel");
                return new C0938n(parcel.readInt(), C0939o.CREATOR.createFromParcel(parcel));
            case 23:
                p097ha.k.f(parcel, "parcel");
                return new C0939o((p034c9.h) parcel.readParcelable(C0939o.class.getClassLoader()));
            case 24:
                p097ha.k.f(parcel, "parcel");
                return new C0944u(parcel.readString(), parcel.readString());
            case 25:
                p097ha.k.f(parcel, "parcel");
                return new C0945v(C1430u0.CREATOR.createFromParcel(parcel), parcel.readInt(), parcel.readString());
            case 26:
                p097ha.k.f(parcel, "parcel");
                Serializable serializable = parcel.readSerializable();
                p097ha.k.d(serializable, "null cannot be cast to non-null type com.stripe.android.core.exception.StripeException");
                return new p032c7.w((p107i7.c) serializable, parcel.readInt());
            case 27:
                p097ha.k.f(parcel, "parcel");
                return new p032c7.x(C1430u0.CREATOR.createFromParcel(parcel), parcel.readString());
            case 28:
                p097ha.k.f(parcel, "parcel");
                return new p032c7.y(C1408m1.CREATOR.createFromParcel(parcel), parcel.readString());
            default:
                p097ha.k.f(parcel, "parcel");
                return new p032c7.z(C1431u1.CREATOR.createFromParcel(parcel), parcel.readString());
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i10) {
        switch (this.f16893a) {
            case 0:
                return new q0[i10];
            case 1:
                return new s0[i10];
            case 2:
                return new C0886c[i10];
            case 3:
                return new C0887d[i10];
            case 4:
                return new C0888e[i10];
            case 5:
                return new C0889f[i10];
            case 6:
                return new C0890g[i10];
            case 7:
                return new C0897n[i10];
            case 8:
                return new C0898o[i10];
            case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                return new p021b8.w[i10];
            case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                return new p021b8.x[i10];
            case 11:
                return new p021b8.y[i10];
            case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                return new p021b8.z[i10];
            case 13:
                return new p021b8.A[i10];
            case 14:
                return new p021b8.I[i10];
            case 15:
                return new p021b8.H[i10];
            case 16:
                return new b9.a[i10];
            case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                return new b9.m[i10];
            case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                return new p024c.d[i10];
            case 19:
                return new C0934j[i10];
            case 20:
                return new C0935k[i10];
            case 21:
                return new C0936l[i10];
            case 22:
                return new C0938n[i10];
            case 23:
                return new C0939o[i10];
            case 24:
                return new C0944u[i10];
            case 25:
                return new C0945v[i10];
            case 26:
                return new p032c7.w[i10];
            case 27:
                return new p032c7.x[i10];
            case 28:
                return new p032c7.y[i10];
            default:
                return new p032c7.z[i10];
        }
    }
}
