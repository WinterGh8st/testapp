package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import com.google.android.material.internal.ClippableRoundedCornerLayout;

/* JADX INFO: renamed from: androidx.recyclerview.widget.k, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0836k extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16830a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16831b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f16832c;

    public C0836k(B8.i iVar, boolean z3) {
        this.f16830a = 1;
        this.f16832c = iVar;
        this.f16831b = z3;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.f16830a) {
            case 0:
                this.f16831b = true;
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f16830a) {
            case 0:
                if (!this.f16831b) {
                    C0838m c0838m = (C0838m) this.f16832c;
                    if (((Float) c0838m.f16870z.getAnimatedValue()).floatValue() != 0.0f) {
                        c0838m.f16844A = 2;
                        c0838m.f16863s.invalidate();
                    } else {
                        c0838m.f16844A = 0;
                        c0838m.l(0);
                    }
                } else {
                    this.f16831b = false;
                }
                break;
            default:
                float f10 = this.f16831b ? 1.0f : 0.0f;
                B8.i iVar = (B8.i) this.f16832c;
                B8.i.a(iVar, f10);
                ClippableRoundedCornerLayout clippableRoundedCornerLayout = (ClippableRoundedCornerLayout) iVar.k;
                clippableRoundedCornerLayout.f19544a = null;
                clippableRoundedCornerLayout.f19545b = 0.0f;
                clippableRoundedCornerLayout.invalidate();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        switch (this.f16830a) {
            case 1:
                B8.i.a((B8.i) this.f16832c, this.f16831b ? 0.0f : 1.0f);
                break;
            default:
                super.onAnimationStart(animator);
                break;
        }
    }

    public C0836k(C0838m c0838m) {
        this.f16830a = 0;
        this.f16832c = c0838m;
        this.f16831b = false;
    }
}
