package androidx.recyclerview.widget;

import android.view.View;
import java.util.List;

/* JADX INFO: renamed from: androidx.recyclerview.widget.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0850z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16987a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16988b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16989c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16990d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16991e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16992f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16993g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f16994h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f16995i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f16996j;
    public List k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f16997l;

    public final void a(View view) {
        int layoutPosition;
        int size = this.k.size();
        View view2 = null;
        int i10 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        for (int i11 = 0; i11 < size; i11++) {
            View view3 = ((l0) this.k.get(i11)).itemView;
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view3.getLayoutParams();
            if (view3 != view && !layoutParams.f16690a.isRemoved() && (layoutPosition = (layoutParams.f16690a.getLayoutPosition() - this.f16990d) * this.f16991e) >= 0 && layoutPosition < i10) {
                view2 = view3;
                if (layoutPosition == 0) {
                    break;
                } else {
                    i10 = layoutPosition;
                }
            }
        }
        if (view2 == null) {
            this.f16990d = -1;
        } else {
            this.f16990d = ((RecyclerView.LayoutParams) view2.getLayoutParams()).f16690a.getLayoutPosition();
        }
    }

    public final View b(a0 a0Var) {
        List list = this.k;
        if (list == null) {
            View view = a0Var.k(this.f16990d, Long.MAX_VALUE).itemView;
            this.f16990d += this.f16991e;
            return view;
        }
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            View view2 = ((l0) this.k.get(i10)).itemView;
            RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view2.getLayoutParams();
            if (!layoutParams.f16690a.isRemoved() && this.f16990d == layoutParams.f16690a.getLayoutPosition()) {
                a(view2);
                return view2;
            }
        }
        return null;
    }
}
