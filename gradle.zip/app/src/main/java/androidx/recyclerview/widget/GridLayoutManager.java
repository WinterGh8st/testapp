package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import java.util.Arrays;
import java.util.WeakHashMap;
import p199r0.AbstractC1464s;

/* JADX INFO: loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f16573E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f16574F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public int[] f16575G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public View[] f16576H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final SparseIntArray f16577I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final SparseIntArray f16578J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public G2.b f16579K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final Rect f16580L;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i10, int i11) {
        super(context, attributeSet, i10, i11);
        this.f16573E = false;
        this.f16574F = -1;
        this.f16577I = new SparseIntArray();
        this.f16578J = new SparseIntArray();
        this.f16579K = new C0841p(4, false);
        this.f16580L = new Rect();
        v1(T.N(context, attributeSet, i10, i11).f16695b);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final boolean H0() {
        return this.f16599z == null && !this.f16573E;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void J0(h0 h0Var, C0850z c0850z, Db.m mVar) {
        int i10;
        int iP = this.f16574F;
        for (int i11 = 0; i11 < this.f16574F && (i10 = c0850z.f16990d) >= 0 && i10 < h0Var.b() && iP > 0; i11++) {
            int i12 = c0850z.f16990d;
            mVar.a(i12, Math.max(0, c0850z.f16993g));
            iP -= this.f16579K.p(i12);
            c0850z.f16990d += c0850z.f16991e;
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final int O(a0 a0Var, h0 h0Var) {
        if (this.f16589p == 0) {
            return this.f16574F;
        }
        if (h0Var.b() < 1) {
            return 0;
        }
        return r1(h0Var.b() - 1, a0Var, h0Var) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View W0(a0 a0Var, h0 h0Var, boolean z3, boolean z5) {
        int i10;
        int iW;
        int iW2 = w();
        int i11 = 1;
        if (z5) {
            iW = w() - 1;
            i10 = -1;
            i11 = -1;
        } else {
            i10 = iW2;
            iW = 0;
        }
        int iB = h0Var.b();
        O0();
        int iK = this.f16591r.k();
        int iG = this.f16591r.g();
        View view = null;
        View view2 = null;
        while (iW != i10) {
            View viewV = v(iW);
            int iM = T.M(viewV);
            if (iM >= 0 && iM < iB && s1(iM, a0Var, h0Var) == 0) {
                if (((RecyclerView.LayoutParams) viewV.getLayoutParams()).f16690a.isRemoved()) {
                    if (view2 == null) {
                        view2 = viewV;
                    }
                } else {
                    if (this.f16591r.e(viewV) < iG && this.f16591r.b(viewV) >= iK) {
                        return viewV;
                    }
                    if (view == null) {
                        view = viewV;
                    }
                }
            }
            iW += i11;
        }
        return view != null ? view : view2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:62:0x00e2, code lost:
    
        if (r13 == (r2 > r15)) goto L57;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View Y(android.view.View r23, int r24, androidx.recyclerview.widget.a0 r25, androidx.recyclerview.widget.h0 r26) {
        /*
            Method dump skipped, instruction units count: 326
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.Y(android.view.View, int, androidx.recyclerview.widget.a0, androidx.recyclerview.widget.h0):android.view.View");
    }

    @Override // androidx.recyclerview.widget.T
    public final void a0(a0 a0Var, h0 h0Var, p211s1.i iVar) {
        super.a0(a0Var, h0Var, iVar);
        iVar.k(GridView.class.getName());
    }

    @Override // androidx.recyclerview.widget.T
    public final void c0(a0 a0Var, h0 h0Var, View view, p211s1.i iVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof LayoutParams)) {
            b0(view, iVar);
            return;
        }
        LayoutParams layoutParams2 = (LayoutParams) layoutParams;
        int iR1 = r1(layoutParams2.f16690a.getLayoutPosition(), a0Var, h0Var);
        if (this.f16589p == 0) {
            iVar.m(p211s1.h.a(layoutParams2.f16581e, layoutParams2.f16582f, iR1, 1, false, false));
        } else {
            iVar.m(p211s1.h.a(iR1, 1, layoutParams2.f16581e, layoutParams2.f16582f, false, false));
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void c1(a0 a0Var, h0 h0Var, C0850z c0850z, C0849y c0849y) {
        int i10;
        int i11;
        int i12;
        int iD;
        int iJ;
        int iL;
        int iD2;
        int iX;
        int iX2;
        boolean z3;
        int i13;
        View viewB;
        int iJ2 = this.f16591r.j();
        boolean z5 = iJ2 != 1073741824;
        int i14 = w() > 0 ? this.f16575G[this.f16574F] : 0;
        if (z5) {
            w1();
        }
        boolean z10 = c0850z.f16991e == 1;
        int iS1 = this.f16574F;
        if (!z10) {
            iS1 = s1(c0850z.f16990d, a0Var, h0Var) + t1(c0850z.f16990d, a0Var, h0Var);
        }
        int i15 = 0;
        while (i15 < this.f16574F && (i13 = c0850z.f16990d) >= 0 && i13 < h0Var.b() && iS1 > 0) {
            int i16 = c0850z.f16990d;
            int iT1 = t1(i16, a0Var, h0Var);
            if (iT1 > this.f16574F) {
                throw new IllegalArgumentException(AbstractC1464s.h(p015b2.a.g("Item at position ", i16, " requires ", iT1, " spans but GridLayoutManager has only "), this.f16574F, " spans."));
            }
            iS1 -= iT1;
            if (iS1 < 0 || (viewB = c0850z.b(a0Var)) == null) {
                break;
            }
            this.f16576H[i15] = viewB;
            i15++;
        }
        if (i15 == 0) {
            c0849y.f16984b = true;
            return;
        }
        if (z10) {
            i12 = 1;
            i11 = i15;
            i10 = 0;
        } else {
            i10 = i15 - 1;
            i11 = -1;
            i12 = -1;
        }
        int i17 = 0;
        while (i10 != i11) {
            View view = this.f16576H[i10];
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            int iT2 = t1(T.M(view), a0Var, h0Var);
            layoutParams.f16582f = iT2;
            layoutParams.f16581e = i17;
            i17 += iT2;
            i10 += i12;
        }
        float f10 = 0.0f;
        int i18 = 0;
        for (int i19 = 0; i19 < i15; i19++) {
            View view2 = this.f16576H[i19];
            if (c0850z.k != null) {
                z3 = false;
                if (z10) {
                    b(view2, -1, true);
                } else {
                    b(view2, 0, true);
                }
            } else if (z10) {
                z3 = false;
                b(view2, -1, false);
            } else {
                z3 = false;
                b(view2, 0, false);
            }
            d(this.f16580L, view2);
            u1(view2, iJ2, z3);
            int iC = this.f16591r.c(view2);
            if (iC > i18) {
                i18 = iC;
            }
            float fD = (this.f16591r.d(view2) * 1.0f) / ((LayoutParams) view2.getLayoutParams()).f16582f;
            if (fD > f10) {
                f10 = fD;
            }
        }
        if (z5) {
            o1(Math.max(Math.round(f10 * this.f16574F), i14));
            i18 = 0;
            for (int i20 = 0; i20 < i15; i20++) {
                View view3 = this.f16576H[i20];
                u1(view3, 1073741824, true);
                int iC2 = this.f16591r.c(view3);
                if (iC2 > i18) {
                    i18 = iC2;
                }
            }
        }
        for (int i21 = 0; i21 < i15; i21++) {
            View view4 = this.f16576H[i21];
            if (this.f16591r.c(view4) != i18) {
                LayoutParams layoutParams2 = (LayoutParams) view4.getLayoutParams();
                Rect rect = layoutParams2.f16691b;
                int i22 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin;
                int i23 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin;
                int iQ1 = q1(layoutParams2.f16581e, layoutParams2.f16582f);
                if (this.f16589p == 1) {
                    iX2 = T.x(false, iQ1, 1073741824, i23, ((ViewGroup.MarginLayoutParams) layoutParams2).width);
                    iX = View.MeasureSpec.makeMeasureSpec(i18 - i22, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i18 - i23, 1073741824);
                    iX = T.x(false, iQ1, 1073741824, i22, ((ViewGroup.MarginLayoutParams) layoutParams2).height);
                    iX2 = iMakeMeasureSpec;
                }
                if (E0(view4, iX2, iX, (RecyclerView.LayoutParams) view4.getLayoutParams())) {
                    view4.measure(iX2, iX);
                }
            }
        }
        c0849y.f16983a = i18;
        if (this.f16589p != 1) {
            if (c0850z.f16992f == -1) {
                int i24 = c0850z.f16988b;
                iJ = i24 - i18;
                iD = i24;
            } else {
                int i25 = c0850z.f16988b;
                iD = i25 + i18;
                iJ = i25;
            }
            iL = 0;
            iD2 = 0;
        } else if (c0850z.f16992f == -1) {
            iD2 = c0850z.f16988b;
            iL = iD2 - i18;
            iJ = 0;
            iD = 0;
        } else {
            int i26 = c0850z.f16988b;
            iL = i26;
            iD = 0;
            iD2 = i26 + i18;
            iJ = 0;
        }
        for (int i27 = 0; i27 < i15; i27++) {
            View view5 = this.f16576H[i27];
            LayoutParams layoutParams3 = (LayoutParams) view5.getLayoutParams();
            if (this.f16589p != 1) {
                iL = L() + this.f16575G[layoutParams3.f16581e];
                iD2 = this.f16591r.d(view5) + iL;
            } else if (b1()) {
                int iJ3 = J() + this.f16575G[this.f16574F - layoutParams3.f16581e];
                iD = iJ3;
                iJ = iJ3 - this.f16591r.d(view5);
            } else {
                iJ = J() + this.f16575G[layoutParams3.f16581e];
                iD = this.f16591r.d(view5) + iJ;
            }
            T.S(view5, iJ, iL, iD, iD2);
            if (layoutParams3.f16690a.isRemoved() || layoutParams3.f16690a.isUpdated()) {
                c0849y.f16985c = true;
            }
            c0849y.f16986d = view5.hasFocusable() | c0849y.f16986d;
        }
        Arrays.fill(this.f16576H, (Object) null);
    }

    @Override // androidx.recyclerview.widget.T
    public final void d0(int i10, int i11) {
        this.f16579K.r();
        ((SparseIntArray) this.f16579K.f4155b).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void d1(a0 a0Var, h0 h0Var, C0848x c0848x, int i10) {
        w1();
        if (h0Var.b() > 0 && !h0Var.f16820g) {
            boolean z3 = i10 == 1;
            int iS1 = s1(c0848x.f16979b, a0Var, h0Var);
            if (z3) {
                while (iS1 > 0) {
                    int i11 = c0848x.f16979b;
                    if (i11 <= 0) {
                        break;
                    }
                    int i12 = i11 - 1;
                    c0848x.f16979b = i12;
                    iS1 = s1(i12, a0Var, h0Var);
                }
            } else {
                int iB = h0Var.b() - 1;
                int i13 = c0848x.f16979b;
                while (i13 < iB) {
                    int i14 = i13 + 1;
                    int iS2 = s1(i14, a0Var, h0Var);
                    if (iS2 <= iS1) {
                        break;
                    }
                    i13 = i14;
                    iS1 = iS2;
                }
                c0848x.f16979b = i13;
            }
        }
        p1();
    }

    @Override // androidx.recyclerview.widget.T
    public final void e0() {
        this.f16579K.r();
        ((SparseIntArray) this.f16579K.f4155b).clear();
    }

    @Override // androidx.recyclerview.widget.T
    public final void f0(int i10, int i11) {
        this.f16579K.r();
        ((SparseIntArray) this.f16579K.f4155b).clear();
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // androidx.recyclerview.widget.T
    public final void g0(int i10, int i11) {
        this.f16579K.r();
        ((SparseIntArray) this.f16579K.f4155b).clear();
    }

    @Override // androidx.recyclerview.widget.T
    public final void h0(int i10, int i11) {
        this.f16579K.r();
        ((SparseIntArray) this.f16579K.f4155b).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final void i0(a0 a0Var, h0 h0Var) {
        boolean z3 = h0Var.f16820g;
        SparseIntArray sparseIntArray = this.f16578J;
        SparseIntArray sparseIntArray2 = this.f16577I;
        if (z3) {
            int iW = w();
            for (int i10 = 0; i10 < iW; i10++) {
                LayoutParams layoutParams = (LayoutParams) v(i10).getLayoutParams();
                int layoutPosition = layoutParams.f16690a.getLayoutPosition();
                sparseIntArray2.put(layoutPosition, layoutParams.f16582f);
                sparseIntArray.put(layoutPosition, layoutParams.f16581e);
            }
        }
        super.i0(a0Var, h0Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final void j0(h0 h0Var) {
        super.j0(h0Var);
        this.f16573E = false;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void k1(boolean z3) {
        if (z3) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.k1(false);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int l(h0 h0Var) {
        return L0(h0Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int m(h0 h0Var) {
        return M0(h0Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int o(h0 h0Var) {
        return L0(h0Var);
    }

    public final void o1(int i10) {
        int i11;
        int[] iArr = this.f16575G;
        int i12 = this.f16574F;
        if (iArr == null || iArr.length != i12 + 1 || iArr[iArr.length - 1] != i10) {
            iArr = new int[i12 + 1];
        }
        int i13 = 0;
        iArr[0] = 0;
        int i14 = i10 / i12;
        int i15 = i10 % i12;
        int i16 = 0;
        for (int i17 = 1; i17 <= i12; i17++) {
            i13 += i15;
            if (i13 <= 0 || i12 - i13 >= i15) {
                i11 = i14;
            } else {
                i11 = i14 + 1;
                i13 -= i12;
            }
            i16 += i11;
            iArr[i17] = i16;
        }
        this.f16575G = iArr;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int p(h0 h0Var) {
        return M0(h0Var);
    }

    public final void p1() {
        View[] viewArr = this.f16576H;
        if (viewArr == null || viewArr.length != this.f16574F) {
            this.f16576H = new View[this.f16574F];
        }
    }

    public final int q1(int i10, int i11) {
        if (this.f16589p != 1 || !b1()) {
            int[] iArr = this.f16575G;
            return iArr[i11 + i10] - iArr[i10];
        }
        int[] iArr2 = this.f16575G;
        int i12 = this.f16574F;
        return iArr2[i12 - i10] - iArr2[(i12 - i10) - i11];
    }

    public final int r1(int i10, a0 a0Var, h0 h0Var) {
        if (!h0Var.f16820g) {
            return this.f16579K.n(i10, this.f16574F);
        }
        int iB = a0Var.b(i10);
        if (iB != -1) {
            return this.f16579K.n(iB, this.f16574F);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i10);
        return 0;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams s() {
        return this.f16589p == 0 ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
    }

    public final int s1(int i10, a0 a0Var, h0 h0Var) {
        if (!h0Var.f16820g) {
            return this.f16579K.o(i10, this.f16574F);
        }
        int i11 = this.f16578J.get(i10, -1);
        if (i11 != -1) {
            return i11;
        }
        int iB = a0Var.b(i10);
        if (iB != -1) {
            return this.f16579K.o(iB, this.f16574F);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i10);
        return 0;
    }

    @Override // androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams t(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    public final int t1(int i10, a0 a0Var, h0 h0Var) {
        if (!h0Var.f16820g) {
            return this.f16579K.p(i10);
        }
        int i11 = this.f16577I.get(i10, -1);
        if (i11 != -1) {
            return i11;
        }
        int iB = a0Var.b(i10);
        if (iB != -1) {
            return this.f16579K.p(iB);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i10);
        return 1;
    }

    @Override // androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams u(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams2 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams2.f16581e = -1;
            layoutParams2.f16582f = 0;
            return layoutParams2;
        }
        LayoutParams layoutParams3 = new LayoutParams(layoutParams);
        layoutParams3.f16581e = -1;
        layoutParams3.f16582f = 0;
        return layoutParams3;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int u0(int i10, a0 a0Var, h0 h0Var) {
        w1();
        p1();
        return super.u0(i10, a0Var, h0Var);
    }

    public final void u1(View view, int i10, boolean z3) {
        int iX;
        int iX2;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        Rect rect = layoutParams.f16691b;
        int i11 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
        int i12 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        int iQ1 = q1(layoutParams.f16581e, layoutParams.f16582f);
        if (this.f16589p == 1) {
            iX2 = T.x(false, iQ1, i10, i12, ((ViewGroup.MarginLayoutParams) layoutParams).width);
            iX = T.x(true, this.f16591r.l(), this.f16732m, i11, ((ViewGroup.MarginLayoutParams) layoutParams).height);
        } else {
            int iX3 = T.x(false, iQ1, i10, i11, ((ViewGroup.MarginLayoutParams) layoutParams).height);
            int iX4 = T.x(true, this.f16591r.l(), this.f16731l, i12, ((ViewGroup.MarginLayoutParams) layoutParams).width);
            iX = iX3;
            iX2 = iX4;
        }
        RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) view.getLayoutParams();
        if (z3 ? E0(view, iX2, iX, layoutParams2) : C0(view, iX2, iX, layoutParams2)) {
            view.measure(iX2, iX);
        }
    }

    public final void v1(int i10) {
        if (i10 == this.f16574F) {
            return;
        }
        this.f16573E = true;
        if (i10 < 1) {
            throw new IllegalArgumentException(p096h9.i.i(i10, "Span count should be at least 1. Provided "));
        }
        this.f16574F = i10;
        this.f16579K.r();
        t0();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.T
    public final int w0(int i10, a0 a0Var, h0 h0Var) {
        w1();
        p1();
        return super.w0(i10, a0Var, h0Var);
    }

    public final void w1() {
        int I10;
        int iL;
        if (this.f16589p == 1) {
            I10 = this.f16733n - K();
            iL = J();
        } else {
            I10 = this.f16734o - I();
            iL = L();
        }
        o1(I10 - iL);
    }

    @Override // androidx.recyclerview.widget.T
    public final int y(a0 a0Var, h0 h0Var) {
        if (this.f16589p == 1) {
            return this.f16574F;
        }
        if (h0Var.b() < 1) {
            return 0;
        }
        return r1(h0Var.b() - 1, a0Var, h0Var) + 1;
    }

    @Override // androidx.recyclerview.widget.T
    public final void z0(Rect rect, int i10, int i11) {
        int iH;
        int iH2;
        if (this.f16575G == null) {
            super.z0(rect, i10, i11);
        }
        int iK = K() + J();
        int I10 = I() + L();
        if (this.f16589p == 1) {
            int iHeight = rect.height() + I10;
            RecyclerView recyclerView = this.f16722b;
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            iH2 = T.h(i11, iHeight, recyclerView.getMinimumHeight());
            int[] iArr = this.f16575G;
            iH = T.h(i10, iArr[iArr.length - 1] + iK, this.f16722b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iK;
            RecyclerView recyclerView2 = this.f16722b;
            WeakHashMap weakHashMap2 = p200r1.U.f27683a;
            iH = T.h(i10, iWidth, recyclerView2.getMinimumWidth());
            int[] iArr2 = this.f16575G;
            iH2 = T.h(i11, iArr2[iArr2.length - 1] + I10, this.f16722b.getMinimumHeight());
        }
        this.f16722b.setMeasuredDimension(iH, iH2);
    }

    public static class LayoutParams extends RecyclerView.LayoutParams {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f16581e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f16582f;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f16581e = -1;
            this.f16582f = 0;
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.f16581e = -1;
            this.f16582f = 0;
        }
    }

    public GridLayoutManager(int i10) {
        super(1);
        this.f16573E = false;
        this.f16574F = -1;
        this.f16577I = new SparseIntArray();
        this.f16578J = new SparseIntArray();
        this.f16579K = new C0841p(4, false);
        this.f16580L = new Rect();
        v1(i10);
    }

    public GridLayoutManager() {
        super(1);
        this.f16573E = false;
        this.f16574F = -1;
        this.f16577I = new SparseIntArray();
        this.f16578J = new SparseIntArray();
        this.f16579K = new C0841p(4, false);
        this.f16580L = new Rect();
        v1(2);
    }
}
