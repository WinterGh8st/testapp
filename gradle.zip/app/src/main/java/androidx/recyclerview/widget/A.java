package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public final class A implements Parcelable {
    public static final Parcelable.Creator<A> CREATOR = new T3.v(29);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16556a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16557b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16558c;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f16556a);
        parcel.writeInt(this.f16557b);
        parcel.writeInt(this.f16558c ? 1 : 0);
    }
}
