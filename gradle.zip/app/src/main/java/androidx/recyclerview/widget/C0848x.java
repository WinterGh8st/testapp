package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: renamed from: androidx.recyclerview.widget.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0848x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public I1.g f16978a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16979b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16980c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16981d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16982e;

    public C0848x() {
        d();
    }

    public final void a() {
        this.f16980c = this.f16981d ? this.f16978a.g() : this.f16978a.k();
    }

    public final void b(View view, int i10) {
        if (this.f16981d) {
            int iB = this.f16978a.b(view);
            I1.g gVar = this.f16978a;
            this.f16980c = (Integer.MIN_VALUE == gVar.f5744a ? 0 : gVar.l() - gVar.f5744a) + iB;
        } else {
            this.f16980c = this.f16978a.e(view);
        }
        this.f16979b = i10;
    }

    public final void c(View view, int i10) {
        I1.g gVar = this.f16978a;
        int iL = Integer.MIN_VALUE == gVar.f5744a ? 0 : gVar.l() - gVar.f5744a;
        if (iL >= 0) {
            b(view, i10);
            return;
        }
        this.f16979b = i10;
        if (!this.f16981d) {
            int iE = this.f16978a.e(view);
            int iK = iE - this.f16978a.k();
            this.f16980c = iE;
            if (iK > 0) {
                int iG = (this.f16978a.g() - Math.min(0, (this.f16978a.g() - iL) - this.f16978a.b(view))) - (this.f16978a.c(view) + iE);
                if (iG < 0) {
                    this.f16980c -= Math.min(iK, -iG);
                    return;
                }
                return;
            }
            return;
        }
        int iG2 = (this.f16978a.g() - iL) - this.f16978a.b(view);
        this.f16980c = this.f16978a.g() - iG2;
        if (iG2 > 0) {
            int iC = this.f16980c - this.f16978a.c(view);
            int iK2 = this.f16978a.k();
            int iMin = iC - (Math.min(this.f16978a.e(view) - iK2, 0) + iK2);
            if (iMin < 0) {
                this.f16980c = Math.min(iG2, -iMin) + this.f16980c;
            }
        }
    }

    public final void d() {
        this.f16979b = -1;
        this.f16980c = Integer.MIN_VALUE;
        this.f16981d = false;
        this.f16982e = false;
    }

    public final String toString() {
        return "AnchorInfo{mPosition=" + this.f16979b + ", mCoordinate=" + this.f16980c + ", mLayoutFromEnd=" + this.f16981d + ", mValid=" + this.f16982e + '}';
    }
}
