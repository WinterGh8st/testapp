package androidx.recyclerview.widget;

import C9.C0090f1;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: androidx.recyclerview.widget.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0846v extends O implements U {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public Rect f16938A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public long f16939B;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f16943d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f16944e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f16945f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public float f16946g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public float f16947h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public float f16948i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f16949j;
    public float k;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public final C0090f1 f16951m;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f16953o;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f16955q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public PaymentMethodsRecyclerView f16956r;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public VelocityTracker f16958t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public ArrayList f16959u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ArrayList f16960v;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public p074g0.c f16962x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public C0843s f16963y;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16940a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float[] f16941b = new float[2];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public l0 f16942c = null;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f16950l = -1;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f16952n = 0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final ArrayList f16954p = new ArrayList();

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final RunnableC0834i f16957s = new RunnableC0834i(this, 1);

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public View f16961w = null;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final C0842q f16964z = new C0842q(this);

    public C0846v(C0090f1 c0090f1) {
        this.f16951m = c0090f1;
    }

    public static boolean o(View view, float f10, float f11, float f12, float f13) {
        return f10 >= f12 && f10 <= f12 + ((float) view.getWidth()) && f11 >= f13 && f11 <= f13 + ((float) view.getHeight());
    }

    @Override // androidx.recyclerview.widget.U
    public final void d(View view) {
        q(view);
        l0 l0VarL = this.f16956r.L(view);
        if (l0VarL == null) {
            return;
        }
        l0 l0Var = this.f16942c;
        if (l0Var != null && l0VarL == l0Var) {
            r(null, 0);
            return;
        }
        l(l0VarL, false);
        if (this.f16940a.remove(l0VarL.itemView)) {
            this.f16951m.getClass();
            AbstractC0844t.a(l0VarL);
        }
    }

    @Override // androidx.recyclerview.widget.O
    public final void f(Rect rect, View view, RecyclerView recyclerView) {
        rect.setEmpty();
    }

    @Override // androidx.recyclerview.widget.O
    public final void g(Canvas canvas, RecyclerView recyclerView) {
        float f10;
        float f11;
        if (this.f16942c != null) {
            float[] fArr = this.f16941b;
            n(fArr);
            float f12 = fArr[0];
            f10 = fArr[1];
            f11 = f12;
        } else {
            f10 = 0.0f;
            f11 = 0.0f;
        }
        l0 l0Var = this.f16942c;
        ArrayList arrayList = this.f16954p;
        C0090f1 c0090f1 = this.f16951m;
        c0090f1.getClass();
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            r rVar = (r) arrayList.get(i10);
            float f13 = rVar.f16899a;
            float f14 = rVar.f16901c;
            l0 l0Var2 = rVar.f16903e;
            if (f13 == f14) {
                rVar.f16907i = l0Var2.itemView.getTranslationX();
            } else {
                rVar.f16907i = p096h9.i.e(f14, f13, rVar.f16910m, f13);
            }
            float f15 = rVar.f16900b;
            float f16 = rVar.f16902d;
            if (f15 == f16) {
                rVar.f16908j = l0Var2.itemView.getTranslationY();
            } else {
                rVar.f16908j = p096h9.i.e(f16, f15, rVar.f16910m, f15);
            }
            int iSave = canvas.save();
            c0090f1.f(canvas, recyclerView, rVar.f16903e, rVar.f16907i, rVar.f16908j, false);
            canvas.restoreToCount(iSave);
        }
        if (l0Var != null) {
            int iSave2 = canvas.save();
            c0090f1.f(canvas, recyclerView, l0Var, f11, f10, true);
            canvas.restoreToCount(iSave2);
        }
    }

    @Override // androidx.recyclerview.widget.O
    public final void h(Canvas canvas, RecyclerView recyclerView) {
        boolean z3 = false;
        if (this.f16942c != null) {
            float[] fArr = this.f16941b;
            n(fArr);
            float f10 = fArr[0];
            float f11 = fArr[1];
        }
        l0 l0Var = this.f16942c;
        ArrayList arrayList = this.f16954p;
        this.f16951m.getClass();
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            r rVar = (r) arrayList.get(i10);
            int iSave = canvas.save();
            View view = rVar.f16903e.itemView;
            canvas.restoreToCount(iSave);
        }
        if (l0Var != null) {
            canvas.restoreToCount(canvas.save());
        }
        for (int i11 = size - 1; i11 >= 0; i11--) {
            r rVar2 = (r) arrayList.get(i11);
            boolean z5 = rVar2.f16909l;
            if (z5 && !rVar2.f16906h) {
                arrayList.remove(i11);
            } else if (!z5) {
                z3 = true;
            }
        }
        if (z3) {
            recyclerView.invalidate();
        }
    }

    public final int i(l0 l0Var, int i10) {
        if ((i10 & 12) == 0) {
            return 0;
        }
        int i11 = this.f16947h > 0.0f ? 8 : 4;
        VelocityTracker velocityTracker = this.f16958t;
        C0090f1 c0090f1 = this.f16951m;
        if (velocityTracker != null && this.f16950l > -1) {
            float f10 = this.f16946g;
            c0090f1.getClass();
            velocityTracker.computeCurrentVelocity(1000, f10);
            float xVelocity = this.f16958t.getXVelocity(this.f16950l);
            float yVelocity = this.f16958t.getYVelocity(this.f16950l);
            int i12 = xVelocity > 0.0f ? 8 : 4;
            float fAbs = Math.abs(xVelocity);
            if ((i12 & i10) != 0 && i11 == i12 && fAbs >= this.f16945f && fAbs > Math.abs(yVelocity)) {
                return i12;
            }
        }
        float width = this.f16956r.getWidth();
        c0090f1.getClass();
        p097ha.k.f(l0Var, "viewHolder");
        float f11 = width * 0.5f;
        if ((i10 & i11) == 0 || Math.abs(this.f16947h) <= f11) {
            return 0;
        }
        return i11;
    }

    public final void j(int i10, int i11, MotionEvent motionEvent) {
        View viewM;
        if (this.f16942c == null && i10 == 2 && this.f16952n != 2) {
            C0090f1 c0090f1 = this.f16951m;
            c0090f1.getClass();
            if (this.f16956r.getScrollState() == 1) {
                return;
            }
            T layoutManager = this.f16956r.getLayoutManager();
            int i12 = this.f16950l;
            l0 l0VarL = null;
            if (i12 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i12);
                float x10 = motionEvent.getX(iFindPointerIndex) - this.f16943d;
                float y10 = motionEvent.getY(iFindPointerIndex) - this.f16944e;
                float fAbs = Math.abs(x10);
                float fAbs2 = Math.abs(y10);
                float f10 = this.f16955q;
                if ((fAbs >= f10 || fAbs2 >= f10) && ((fAbs <= fAbs2 || !layoutManager.e()) && ((fAbs2 <= fAbs || !layoutManager.f()) && (viewM = m(motionEvent)) != null))) {
                    l0VarL = this.f16956r.L(viewM);
                }
            }
            if (l0VarL == null) {
                return;
            }
            PaymentMethodsRecyclerView paymentMethodsRecyclerView = this.f16956r;
            int iD = c0090f1.d(paymentMethodsRecyclerView, l0VarL);
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            int iB = (AbstractC0844t.b(iD, paymentMethodsRecyclerView.getLayoutDirection()) & 65280) >> 8;
            if (iB == 0) {
                return;
            }
            float x11 = motionEvent.getX(i11);
            float y11 = motionEvent.getY(i11);
            float f11 = x11 - this.f16943d;
            float f12 = y11 - this.f16944e;
            float fAbs3 = Math.abs(f11);
            float fAbs4 = Math.abs(f12);
            float f13 = this.f16955q;
            if (fAbs3 >= f13 || fAbs4 >= f13) {
                if (fAbs3 > fAbs4) {
                    if (f11 < 0.0f && (iB & 4) == 0) {
                        return;
                    }
                    if (f11 > 0.0f && (iB & 8) == 0) {
                        return;
                    }
                } else {
                    if (f12 < 0.0f && (iB & 1) == 0) {
                        return;
                    }
                    if (f12 > 0.0f && (iB & 2) == 0) {
                        return;
                    }
                }
                this.f16948i = 0.0f;
                this.f16947h = 0.0f;
                this.f16950l = motionEvent.getPointerId(0);
                r(l0VarL, 1);
            }
        }
    }

    public final int k(l0 l0Var, int i10) {
        if ((i10 & 3) == 0) {
            return 0;
        }
        int i11 = this.f16948i > 0.0f ? 2 : 1;
        VelocityTracker velocityTracker = this.f16958t;
        C0090f1 c0090f1 = this.f16951m;
        if (velocityTracker != null && this.f16950l > -1) {
            float f10 = this.f16946g;
            c0090f1.getClass();
            velocityTracker.computeCurrentVelocity(1000, f10);
            float xVelocity = this.f16958t.getXVelocity(this.f16950l);
            float yVelocity = this.f16958t.getYVelocity(this.f16950l);
            int i12 = yVelocity > 0.0f ? 2 : 1;
            float fAbs = Math.abs(yVelocity);
            if ((i12 & i10) != 0 && i12 == i11 && fAbs >= this.f16945f && fAbs > Math.abs(xVelocity)) {
                return i12;
            }
        }
        float height = this.f16956r.getHeight();
        c0090f1.getClass();
        p097ha.k.f(l0Var, "viewHolder");
        float f11 = height * 0.5f;
        if ((i10 & i11) == 0 || Math.abs(this.f16948i) <= f11) {
            return 0;
        }
        return i11;
    }

    public final void l(l0 l0Var, boolean z3) {
        ArrayList arrayList = this.f16954p;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            r rVar = (r) arrayList.get(size);
            if (rVar.f16903e == l0Var) {
                rVar.k |= z3;
                if (!rVar.f16909l) {
                    rVar.f16905g.cancel();
                }
                arrayList.remove(size);
                return;
            }
        }
    }

    public final View m(MotionEvent motionEvent) {
        float x10 = motionEvent.getX();
        float y10 = motionEvent.getY();
        l0 l0Var = this.f16942c;
        if (l0Var != null) {
            View view = l0Var.itemView;
            if (o(view, x10, y10, this.f16949j + this.f16947h, this.k + this.f16948i)) {
                return view;
            }
        }
        ArrayList arrayList = this.f16954p;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            r rVar = (r) arrayList.get(size);
            View view2 = rVar.f16903e.itemView;
            if (o(view2, x10, y10, rVar.f16907i, rVar.f16908j)) {
                return view2;
            }
        }
        PaymentMethodsRecyclerView paymentMethodsRecyclerView = this.f16956r;
        for (int iD = paymentMethodsRecyclerView.f16659f.D() - 1; iD >= 0; iD--) {
            View viewC = paymentMethodsRecyclerView.f16659f.C(iD);
            float translationX = viewC.getTranslationX();
            float translationY = viewC.getTranslationY();
            if (x10 >= viewC.getLeft() + translationX && x10 <= viewC.getRight() + translationX && y10 >= viewC.getTop() + translationY && y10 <= viewC.getBottom() + translationY) {
                return viewC;
            }
        }
        return null;
    }

    public final void n(float[] fArr) {
        if ((this.f16953o & 12) != 0) {
            fArr[0] = (this.f16949j + this.f16947h) - this.f16942c.itemView.getLeft();
        } else {
            fArr[0] = this.f16942c.itemView.getTranslationX();
        }
        if ((this.f16953o & 3) != 0) {
            fArr[1] = (this.k + this.f16948i) - this.f16942c.itemView.getTop();
        } else {
            fArr[1] = this.f16942c.itemView.getTranslationY();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void p(l0 l0Var) {
        int bottom;
        int iAbs;
        int top;
        int iAbs2;
        int left;
        int iAbs3;
        int right;
        int iAbs4;
        int i10;
        if (this.f16956r.isLayoutRequested()) {
            return;
        }
        char c10 = 2;
        if (this.f16952n != 2) {
            return;
        }
        this.f16951m.getClass();
        int i11 = (int) (this.f16949j + this.f16947h);
        int i12 = (int) (this.k + this.f16948i);
        if (Math.abs(i12 - l0Var.itemView.getTop()) >= l0Var.itemView.getHeight() * 0.5f || Math.abs(i11 - l0Var.itemView.getLeft()) >= l0Var.itemView.getWidth() * 0.5f) {
            ArrayList arrayList = this.f16959u;
            if (arrayList == null) {
                this.f16959u = new ArrayList();
                this.f16960v = new ArrayList();
            } else {
                arrayList.clear();
                this.f16960v.clear();
            }
            int iRound = Math.round(this.f16949j + this.f16947h);
            int iRound2 = Math.round(this.k + this.f16948i);
            int width = l0Var.itemView.getWidth() + iRound;
            int height = l0Var.itemView.getHeight() + iRound2;
            int i13 = (iRound + width) / 2;
            int i14 = (iRound2 + height) / 2;
            T layoutManager = this.f16956r.getLayoutManager();
            int iW = layoutManager.w();
            int i15 = 0;
            while (i15 < iW) {
                View viewV = layoutManager.v(i15);
                char c11 = c10;
                if (viewV != l0Var.itemView && viewV.getBottom() >= iRound2 && viewV.getTop() <= height && viewV.getRight() >= iRound && viewV.getLeft() <= width) {
                    l0 l0VarL = this.f16956r.L(viewV);
                    int iAbs5 = Math.abs(i13 - ((viewV.getRight() + viewV.getLeft()) / 2));
                    int iAbs6 = Math.abs(i14 - ((viewV.getBottom() + viewV.getTop()) / 2));
                    int i16 = (iAbs6 * iAbs6) + (iAbs5 * iAbs5);
                    int size = this.f16959u.size();
                    int i17 = 0;
                    int i18 = 0;
                    while (true) {
                        i10 = iRound;
                        if (i17 >= size || i16 <= ((Integer) this.f16960v.get(i17)).intValue()) {
                            break;
                        }
                        i18++;
                        i17++;
                        iRound = i10;
                    }
                    this.f16959u.add(i18, l0VarL);
                    this.f16960v.add(i18, Integer.valueOf(i16));
                } else {
                    i10 = iRound;
                }
                i15++;
                c10 = c11;
                i11 = i11;
                i12 = i12;
                iRound = i10;
            }
            int i19 = i11;
            int i20 = i12;
            ArrayList arrayList2 = this.f16959u;
            if (arrayList2.size() == 0) {
                return;
            }
            int width2 = l0Var.itemView.getWidth() + i19;
            int height2 = l0Var.itemView.getHeight() + i20;
            int left2 = i19 - l0Var.itemView.getLeft();
            int top2 = i20 - l0Var.itemView.getTop();
            int size2 = arrayList2.size();
            l0 l0Var2 = null;
            int i21 = -1;
            for (int i22 = 0; i22 < size2; i22++) {
                l0 l0Var3 = (l0) arrayList2.get(i22);
                if (left2 > 0 && (right = l0Var3.itemView.getRight() - width2) < 0 && l0Var3.itemView.getRight() > l0Var.itemView.getRight() && (iAbs4 = Math.abs(right)) > i21) {
                    l0Var2 = l0Var3;
                    i21 = iAbs4;
                }
                if (left2 < 0 && (left = l0Var3.itemView.getLeft() - i19) > 0 && l0Var3.itemView.getLeft() < l0Var.itemView.getLeft() && (iAbs3 = Math.abs(left)) > i21) {
                    l0Var2 = l0Var3;
                    i21 = iAbs3;
                }
                if (top2 < 0 && (top = l0Var3.itemView.getTop() - i20) > 0 && l0Var3.itemView.getTop() < l0Var.itemView.getTop() && (iAbs2 = Math.abs(top)) > i21) {
                    l0Var2 = l0Var3;
                    i21 = iAbs2;
                }
                if (top2 > 0 && (bottom = l0Var3.itemView.getBottom() - height2) < 0 && l0Var3.itemView.getBottom() > l0Var.itemView.getBottom() && (iAbs = Math.abs(bottom)) > i21) {
                    l0Var2 = l0Var3;
                    i21 = iAbs;
                }
            }
            if (l0Var2 == null) {
                this.f16959u.clear();
                this.f16960v.clear();
                return;
            }
            int absoluteAdapterPosition = l0Var2.getAbsoluteAdapterPosition();
            l0Var.getAbsoluteAdapterPosition();
            p097ha.k.f(this.f16956r, "recyclerView");
            PaymentMethodsRecyclerView paymentMethodsRecyclerView = this.f16956r;
            T layoutManager2 = paymentMethodsRecyclerView.getLayoutManager();
            if (!(layoutManager2 instanceof InterfaceC0845u)) {
                if (layoutManager2.e()) {
                    if (T.B(l0Var2.itemView) <= paymentMethodsRecyclerView.getPaddingLeft()) {
                        paymentMethodsRecyclerView.h0(absoluteAdapterPosition);
                    }
                    if (T.E(l0Var2.itemView) >= paymentMethodsRecyclerView.getWidth() - paymentMethodsRecyclerView.getPaddingRight()) {
                        paymentMethodsRecyclerView.h0(absoluteAdapterPosition);
                    }
                }
                if (layoutManager2.f()) {
                    if (T.F(l0Var2.itemView) <= paymentMethodsRecyclerView.getPaddingTop()) {
                        paymentMethodsRecyclerView.h0(absoluteAdapterPosition);
                    }
                    if (T.z(l0Var2.itemView) >= paymentMethodsRecyclerView.getHeight() - paymentMethodsRecyclerView.getPaddingBottom()) {
                        paymentMethodsRecyclerView.h0(absoluteAdapterPosition);
                        return;
                    }
                    return;
                }
                return;
            }
            View view = l0Var.itemView;
            View view2 = l0Var2.itemView;
            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) ((InterfaceC0845u) layoutManager2);
            linearLayoutManager.c("Cannot drop a view during a scroll or layout calculation");
            linearLayoutManager.O0();
            linearLayoutManager.g1();
            int iM = T.M(view);
            int iM2 = T.M(view2);
            byte b10 = iM < iM2 ? (byte) 1 : (byte) -1;
            if (linearLayoutManager.f16594u) {
                if (b10 == 1) {
                    linearLayoutManager.i1(iM2, linearLayoutManager.f16591r.g() - (linearLayoutManager.f16591r.c(view) + linearLayoutManager.f16591r.e(view2)));
                    return;
                } else {
                    linearLayoutManager.i1(iM2, linearLayoutManager.f16591r.g() - linearLayoutManager.f16591r.b(view2));
                    return;
                }
            }
            if (b10 == -1) {
                linearLayoutManager.i1(iM2, linearLayoutManager.f16591r.e(view2));
            } else {
                linearLayoutManager.i1(iM2, linearLayoutManager.f16591r.b(view2) - linearLayoutManager.f16591r.c(view));
            }
        }
    }

    public final void q(View view) {
        if (view == this.f16961w) {
            this.f16961w = null;
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x0047  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v4, types: [C9.f1, androidx.recyclerview.widget.t] */
    /* JADX WARN: Type inference failed for: r0v6, types: [android.view.ViewParent] */
    /* JADX WARN: Type inference failed for: r13v1 */
    /* JADX WARN: Type inference failed for: r13v10 */
    /* JADX WARN: Type inference failed for: r13v11 */
    /* JADX WARN: Type inference failed for: r13v2 */
    /* JADX WARN: Type inference failed for: r13v3, types: [boolean] */
    /* JADX WARN: Type inference failed for: r13v4 */
    /* JADX WARN: Type inference failed for: r13v5 */
    /* JADX WARN: Type inference failed for: r13v6 */
    /* JADX WARN: Type inference failed for: r13v7, types: [boolean] */
    /* JADX WARN: Type inference failed for: r13v9 */
    /* JADX WARN: Type inference failed for: r18v0 */
    /* JADX WARN: Type inference failed for: r18v1 */
    /* JADX WARN: Type inference failed for: r18v2, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r18v3 */
    /* JADX WARN: Type inference failed for: r18v4, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r18v5 */
    /* JADX WARN: Type inference failed for: r18v6 */
    /* JADX WARN: Type inference failed for: r18v7 */
    /* JADX WARN: Type inference failed for: r20v0, types: [androidx.recyclerview.widget.v] */
    /* JADX WARN: Type inference failed for: r2v1, types: [androidx.recyclerview.widget.l0] */
    /* JADX WARN: Type inference failed for: r2v2 */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v4, types: [androidx.recyclerview.widget.t] */
    /* JADX WARN: Type inference failed for: r2v5 */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void r(l0 l0Var, int i10) {
        ?? r18;
        ?? r13;
        boolean z3;
        ?? r7;
        ?? r14;
        ?? r10;
        ?? r15;
        ?? r19;
        int iK;
        char c10;
        float fSignum;
        long j10;
        if (l0Var == this.f16942c && i10 == this.f16952n) {
            return;
        }
        this.f16939B = Long.MIN_VALUE;
        int i11 = this.f16952n;
        l(l0Var, true);
        this.f16952n = i10;
        if (i10 == 2) {
            if (l0Var == null) {
                throw new IllegalArgumentException("Must pass a ViewHolder when dragging");
            }
            this.f16961w = l0Var.itemView;
        }
        int i12 = (1 << ((i10 * 8) + 8)) - 1;
        ?? r11 = this.f16942c;
        ?? r12 = this.f16951m;
        if (r11 != 0) {
            if (r11.itemView.getParent() != null) {
                if (i11 == 2 || this.f16952n == 2) {
                    iK = 0;
                } else {
                    int iD = r12.d(this.f16956r, r11);
                    PaymentMethodsRecyclerView paymentMethodsRecyclerView = this.f16956r;
                    WeakHashMap weakHashMap = p200r1.U.f27683a;
                    int iB = (AbstractC0844t.b(iD, paymentMethodsRecyclerView.getLayoutDirection()) & 65280) >> 8;
                    if (iB == 0) {
                        iK = 0;
                    } else {
                        int i13 = (iD & 65280) >> 8;
                        if (Math.abs(this.f16947h) > Math.abs(this.f16948i)) {
                            iK = i(r11, iB);
                            if (iK <= 0) {
                                iK = k(r11, iB);
                                if (iK <= 0) {
                                    iK = 0;
                                }
                            } else if ((i13 & iK) == 0) {
                                iK = AbstractC0844t.c(iK, this.f16956r.getLayoutDirection());
                            }
                        } else {
                            iK = k(r11, iB);
                            if (iK <= 0) {
                                iK = i(r11, iB);
                                if (iK <= 0) {
                                    iK = 0;
                                } else if ((i13 & iK) == 0) {
                                    iK = AbstractC0844t.c(iK, this.f16956r.getLayoutDirection());
                                }
                            }
                        }
                    }
                }
                VelocityTracker velocityTracker = this.f16958t;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f16958t = null;
                }
                char c11 = 4;
                float fSignum2 = 0.0f;
                if (iK == 1 || iK == 2) {
                    c10 = 0;
                    fSignum = Math.signum(this.f16948i) * this.f16956r.getHeight();
                } else if (iK == 4 || iK == 8 || iK == 16 || iK == 32) {
                    c10 = 0;
                    fSignum = 0.0f;
                    fSignum2 = Math.signum(this.f16947h) * this.f16956r.getWidth();
                } else {
                    fSignum = 0.0f;
                    c10 = 0;
                }
                if (i11 == 2) {
                    c11 = '\b';
                } else if (iK > 0) {
                    c11 = 2;
                }
                float[] fArr = this.f16941b;
                n(fArr);
                ?? r110 = r12;
                char c12 = c11;
                ?? r16 = c10;
                r rVar = new r(this, r11, i11, fArr[c10], fArr[1], fSignum2, fSignum, iK, r11);
                PaymentMethodsRecyclerView paymentMethodsRecyclerView2 = this.f16956r;
                r110.getClass();
                N itemAnimator = paymentMethodsRecyclerView2.getItemAnimator();
                if (itemAnimator == null) {
                    j10 = c12 == '\b' ? 200L : 250L;
                } else {
                    j10 = c12 == '\b' ? itemAnimator.f16604e : itemAnimator.f16603d;
                }
                ValueAnimator valueAnimator = rVar.f16905g;
                valueAnimator.setDuration(j10);
                this.f16954p.add(rVar);
                r11.setIsRecyclable(r16);
                valueAnimator.start();
                z3 = true;
                r15 = r16;
                r19 = r110;
            } else {
                ?? r111 = r12;
                r15 = 0;
                q(r11.itemView);
                r111.getClass();
                AbstractC0844t.a(r11);
                z3 = false;
                r19 = r111;
            }
            this.f16942c = null;
            r13 = r15;
            r18 = r19;
        } else {
            r18 = r12;
            r13 = 0;
            z3 = false;
        }
        if (l0Var != null) {
            PaymentMethodsRecyclerView paymentMethodsRecyclerView3 = this.f16956r;
            r10 = r18;
            int iD2 = r10.d(paymentMethodsRecyclerView3, l0Var);
            WeakHashMap weakHashMap2 = p200r1.U.f27683a;
            this.f16953o = (AbstractC0844t.b(iD2, paymentMethodsRecyclerView3.getLayoutDirection()) & i12) >> (this.f16952n * 8);
            this.f16949j = l0Var.itemView.getLeft();
            this.k = l0Var.itemView.getTop();
            this.f16942c = l0Var;
            if (i10 == 2) {
                r7 = r10;
                l0Var.itemView.performHapticFeedback(r13 == true ? 1 : 0);
                r7 = r10;
            }
        } else {
            r7 = r18;
        }
        r7 = r10;
        ?? parent = this.f16956r.getParent();
        if (parent != 0) {
            if (this.f16942c != null) {
                r14 = r13;
                r14 = 1;
            }
            r14 = r13;
            parent.requestDisallowInterceptTouchEvent(r14);
        }
        if (!z3) {
            this.f16956r.getLayoutManager().f16726f = true;
        }
        r7.getClass();
        this.f16956r.invalidate();
    }

    public final void s(int i10, int i11, MotionEvent motionEvent) {
        float x10 = motionEvent.getX(i11);
        float y10 = motionEvent.getY(i11);
        float f10 = x10 - this.f16943d;
        this.f16947h = f10;
        this.f16948i = y10 - this.f16944e;
        if ((i10 & 4) == 0) {
            this.f16947h = Math.max(0.0f, f10);
        }
        if ((i10 & 8) == 0) {
            this.f16947h = Math.min(0.0f, this.f16947h);
        }
        if ((i10 & 1) == 0) {
            this.f16948i = Math.max(0.0f, this.f16948i);
        }
        if ((i10 & 2) == 0) {
            this.f16948i = Math.min(0.0f, this.f16948i);
        }
    }

    @Override // androidx.recyclerview.widget.U
    public final void a(View view) {
    }
}
