package androidx.recyclerview.widget;

import android.util.Log;
import android.view.animation.BaseInterpolator;

/* JADX INFO: loaded from: classes.dex */
public final class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16776a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16777b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16778c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16779d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public BaseInterpolator f16780e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f16781f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16782g;

    public final void a(RecyclerView recyclerView) {
        int i10 = this.f16779d;
        if (i10 >= 0) {
            this.f16779d = -1;
            recyclerView.Q(i10);
            this.f16781f = false;
            return;
        }
        if (!this.f16781f) {
            this.f16782g = 0;
            return;
        }
        BaseInterpolator baseInterpolator = this.f16780e;
        if (baseInterpolator != null && this.f16778c < 1) {
            throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
        }
        int i11 = this.f16778c;
        if (i11 < 1) {
            throw new IllegalStateException("Scroll duration must be a positive number");
        }
        recyclerView.f16669o0.c(this.f16776a, this.f16777b, i11, baseInterpolator);
        int i12 = this.f16782g + 1;
        this.f16782g = i12;
        if (i12 > 10) {
            Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
        }
        this.f16781f = false;
    }
}
