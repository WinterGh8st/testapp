package androidx.recyclerview.widget;

import android.util.SparseArray;
import java.util.Set;

/* JADX INFO: loaded from: classes.dex */
public final class Z {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public SparseArray f16739a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16740b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Set f16741c;

    public final Y a(int i10) {
        SparseArray sparseArray = this.f16739a;
        Y y10 = (Y) sparseArray.get(i10);
        if (y10 != null) {
            return y10;
        }
        Y y11 = new Y();
        sparseArray.put(i10, y11);
        return y11;
    }
}
