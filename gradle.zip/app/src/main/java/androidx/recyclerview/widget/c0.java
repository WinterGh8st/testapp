package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends K {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f16763b;

    public /* synthetic */ c0(Object obj, int i10) {
        this.f16762a = i10;
        this.f16763b = obj;
    }

    @Override // androidx.recyclerview.widget.K
    public final void a() {
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                recyclerView.k(null);
                recyclerView.f16674r0.f16819f = true;
                recyclerView.Y(true);
                if (!recyclerView.f16657e.n()) {
                    recyclerView.requestLayout();
                }
                break;
            default:
                ((K6.d) this.f16763b).j();
                break;
        }
    }

    @Override // androidx.recyclerview.widget.K
    public final void b(int i10, int i11, Object obj) {
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                recyclerView.k(null);
                B.P p10 = recyclerView.f16657e;
                if (i11 >= 1) {
                    ArrayList arrayList = (ArrayList) p10.f537c;
                    arrayList.add(p10.q(obj, 4, i10, i11));
                    p10.f535a |= 4;
                    if (arrayList.size() == 1) {
                        g();
                    }
                } else {
                    p10.getClass();
                }
                break;
            default:
                ((K6.d) this.f16763b).j();
                break;
        }
    }

    @Override // androidx.recyclerview.widget.K
    public final void c(int i10, int i11) {
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                recyclerView.k(null);
                B.P p10 = recyclerView.f16657e;
                if (i11 >= 1) {
                    ArrayList arrayList = (ArrayList) p10.f537c;
                    arrayList.add(p10.q(null, 1, i10, i11));
                    p10.f535a |= 1;
                    if (arrayList.size() == 1) {
                        g();
                    }
                } else {
                    p10.getClass();
                }
                break;
            default:
                ((K6.d) this.f16763b).j();
                break;
        }
    }

    @Override // androidx.recyclerview.widget.K
    public final void d(int i10, int i11) {
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                recyclerView.k(null);
                B.P p10 = recyclerView.f16657e;
                p10.getClass();
                if (i10 != i11) {
                    ArrayList arrayList = (ArrayList) p10.f537c;
                    arrayList.add(p10.q(null, 8, i10, i11));
                    p10.f535a |= 8;
                    if (arrayList.size() == 1) {
                        g();
                    }
                    break;
                }
                break;
            default:
                ((K6.d) this.f16763b).j();
                break;
        }
    }

    @Override // androidx.recyclerview.widget.K
    public final void e(int i10, int i11) {
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                recyclerView.k(null);
                B.P p10 = recyclerView.f16657e;
                if (i11 >= 1) {
                    ArrayList arrayList = (ArrayList) p10.f537c;
                    arrayList.add(p10.q(null, 2, i10, i11));
                    p10.f535a |= 2;
                    if (arrayList.size() == 1) {
                        g();
                    }
                } else {
                    p10.getClass();
                }
                break;
            default:
                ((K6.d) this.f16763b).j();
                break;
        }
    }

    @Override // androidx.recyclerview.widget.K
    public void f() {
        I i10;
        switch (this.f16762a) {
            case 0:
                RecyclerView recyclerView = (RecyclerView) this.f16763b;
                if (recyclerView.f16655d != null && (i10 = recyclerView.f16682w) != null && i10.canRestoreState()) {
                    recyclerView.requestLayout();
                }
                break;
        }
    }

    public void g() {
        boolean z3 = RecyclerView.f16612P0;
        RecyclerView recyclerView = (RecyclerView) this.f16763b;
        if (z3 && recyclerView.f16623D && recyclerView.f16621C) {
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            recyclerView.postOnAnimation(recyclerView.f16675s);
        } else {
            recyclerView.f16637K = true;
            recyclerView.requestLayout();
        }
    }
}
