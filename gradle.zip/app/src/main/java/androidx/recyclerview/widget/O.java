package androidx.recyclerview.widget;

import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public abstract class O {
    public void f(Rect rect, View view, RecyclerView recyclerView) {
        ((RecyclerView.LayoutParams) view.getLayoutParams()).f16690a.getLayoutPosition();
        rect.set(0, 0, 0, 0);
    }

    public void g(Canvas canvas, RecyclerView recyclerView) {
    }

    public void h(Canvas canvas, RecyclerView recyclerView) {
    }
}
