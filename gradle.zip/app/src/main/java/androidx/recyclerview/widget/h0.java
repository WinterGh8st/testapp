package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public final class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16814a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16815b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16816c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16817d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16818e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f16819f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f16820g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16821h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f16822i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f16823j;
    public boolean k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f16824l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public long f16825m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f16826n;

    public final void a(int i10) {
        if ((this.f16817d & i10) != 0) {
            return;
        }
        throw new IllegalStateException("Layout state should be one of " + Integer.toBinaryString(i10) + " but it is " + Integer.toBinaryString(this.f16817d));
    }

    public final int b() {
        return this.f16820g ? this.f16815b - this.f16816c : this.f16818e;
    }

    public final String toString() {
        return "State{mTargetPosition=" + this.f16814a + ", mData=null, mItemCount=" + this.f16818e + ", mIsMeasuring=" + this.f16822i + ", mPreviousLayoutItemCount=" + this.f16815b + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.f16816c + ", mStructureChanged=" + this.f16819f + ", mInPreLayout=" + this.f16820g + ", mRunSimpleAnimations=" + this.f16823j + ", mRunPredictiveAnimations=" + this.k + '}';
    }
}
