package androidx.recyclerview.widget;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface u0 {
    int a();

    int b(View view);

    View c(int i10);

    int d();

    int e(View view);
}
