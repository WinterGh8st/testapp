package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* JADX INFO: renamed from: androidx.recyclerview.widget.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0829d extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ l0 f16764a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f16765b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f16766c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f16767d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f16768e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0833h f16769f;

    public C0829d(C0833h c0833h, l0 l0Var, int i10, View view, int i11, ViewPropertyAnimator viewPropertyAnimator) {
        this.f16769f = c0833h;
        this.f16764a = l0Var;
        this.f16765b = i10;
        this.f16766c = view;
        this.f16767d = i11;
        this.f16768e = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        int i10 = this.f16765b;
        View view = this.f16766c;
        if (i10 != 0) {
            view.setTranslationX(0.0f);
        }
        if (this.f16767d != 0) {
            view.setTranslationY(0.0f);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        this.f16768e.setListener(null);
        C0833h c0833h = this.f16769f;
        l0 l0Var = this.f16764a;
        c0833h.c(l0Var);
        c0833h.f16811p.remove(l0Var);
        c0833h.j();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        this.f16769f.getClass();
    }
}
