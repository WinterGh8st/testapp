package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class q0 implements Parcelable {
    public static final Parcelable.Creator<q0> CREATOR = new p0(0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16895a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16896b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int[] f16897c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16898d;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "FullSpanItem{mPosition=" + this.f16895a + ", mGapDir=" + this.f16896b + ", mHasUnwantedGapAfter=" + this.f16898d + ", mGapPerSpan=" + Arrays.toString(this.f16897c) + '}';
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f16895a);
        parcel.writeInt(this.f16896b);
        parcel.writeInt(this.f16898d ? 1 : 0);
        int[] iArr = this.f16897c;
        if (iArr == null || iArr.length <= 0) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(iArr.length);
            parcel.writeIntArray(this.f16897c);
        }
    }
}
