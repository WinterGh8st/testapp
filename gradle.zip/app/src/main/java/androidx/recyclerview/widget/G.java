package androidx.recyclerview.widget;

import L.C0499e0;
import android.util.Log;
import android.view.View;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class G {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f16572a;

    public /* synthetic */ G(Object obj) {
        this.f16572a = obj;
    }

    public void a(C0826a c0826a) {
        int i10 = c0826a.f16742a;
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        if (i10 == 1) {
            recyclerView.f16684x.d0(c0826a.f16743b, c0826a.f16745d);
            return;
        }
        if (i10 == 2) {
            recyclerView.f16684x.g0(c0826a.f16743b, c0826a.f16745d);
        } else if (i10 == 4) {
            recyclerView.f16684x.h0(c0826a.f16743b, c0826a.f16745d);
        } else {
            if (i10 != 8) {
                return;
            }
            recyclerView.f16684x.f0(c0826a.f16743b, c0826a.f16745d);
        }
    }

    public l0 b(int i10) {
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        int iH = recyclerView.f16659f.H();
        l0 l0Var = null;
        for (int i11 = 0; i11 < iH; i11++) {
            l0 l0VarM = RecyclerView.M(recyclerView.f16659f.G(i11));
            if (l0VarM != null && !l0VarM.isRemoved() && l0VarM.mPosition == i10) {
                if (!((ArrayList) recyclerView.f16659f.f7158e).contains(l0VarM.itemView)) {
                    l0Var = l0VarM;
                    break;
                }
                l0Var = l0VarM;
            }
        }
        if (l0Var != null) {
            if (!((ArrayList) recyclerView.f16659f.f7158e).contains(l0Var.itemView)) {
                return l0Var;
            }
            if (RecyclerView.f16609L0) {
                Log.d("RecyclerView", "assuming view holder cannot be find because it is hidden");
            }
        }
        return null;
    }

    public void c(int i10, int i11, Object obj) {
        int i12;
        int i13;
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        int iH = recyclerView.f16659f.H();
        int i14 = i11 + i10;
        for (int i15 = 0; i15 < iH; i15++) {
            View viewG = recyclerView.f16659f.G(i15);
            l0 l0VarM = RecyclerView.M(viewG);
            if (l0VarM != null && !l0VarM.shouldIgnore() && (i13 = l0VarM.mPosition) >= i10 && i13 < i14) {
                l0VarM.addFlags(2);
                l0VarM.addChangePayload(obj);
                ((RecyclerView.LayoutParams) viewG.getLayoutParams()).f16692c = true;
            }
        }
        a0 a0Var = recyclerView.f16653c;
        ArrayList arrayList = a0Var.f16748c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            l0 l0Var = (l0) arrayList.get(size);
            if (l0Var != null && (i12 = l0Var.mPosition) >= i10 && i12 < i14) {
                l0Var.addFlags(2);
                a0Var.g(size);
            }
        }
        recyclerView.v0 = true;
    }

    public void d(int i10, int i11) {
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        int iH = recyclerView.f16659f.H();
        for (int i12 = 0; i12 < iH; i12++) {
            l0 l0VarM = RecyclerView.M(recyclerView.f16659f.G(i12));
            if (l0VarM != null && !l0VarM.shouldIgnore() && l0VarM.mPosition >= i10) {
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForInsert attached child " + i12 + " holder " + l0VarM + " now at position " + (l0VarM.mPosition + i11));
                }
                l0VarM.offsetPosition(i11, false);
                recyclerView.f16674r0.f16819f = true;
            }
        }
        ArrayList arrayList = recyclerView.f16653c.f16748c;
        int size = arrayList.size();
        for (int i13 = 0; i13 < size; i13++) {
            l0 l0Var = (l0) arrayList.get(i13);
            if (l0Var != null && l0Var.mPosition >= i10) {
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForInsert cached " + i13 + " holder " + l0Var + " now at position " + (l0Var.mPosition + i11));
                }
                l0Var.offsetPosition(i11, false);
            }
        }
        recyclerView.requestLayout();
        recyclerView.f16680u0 = true;
    }

    public void e(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        int iH = recyclerView.f16659f.H();
        if (i10 < i11) {
            i13 = i10;
            i12 = i11;
            i14 = -1;
        } else {
            i12 = i10;
            i13 = i11;
            i14 = 1;
        }
        boolean z3 = false;
        for (int i20 = 0; i20 < iH; i20++) {
            l0 l0VarM = RecyclerView.M(recyclerView.f16659f.G(i20));
            if (l0VarM != null && (i19 = l0VarM.mPosition) >= i13 && i19 <= i12) {
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForMove attached child " + i20 + " holder " + l0VarM);
                }
                if (l0VarM.mPosition == i10) {
                    l0VarM.offsetPosition(i11 - i10, false);
                } else {
                    l0VarM.offsetPosition(i14, false);
                }
                recyclerView.f16674r0.f16819f = true;
            }
        }
        a0 a0Var = recyclerView.f16653c;
        a0Var.getClass();
        if (i10 < i11) {
            i16 = i10;
            i15 = i11;
            i17 = -1;
        } else {
            i15 = i10;
            i16 = i11;
            i17 = 1;
        }
        ArrayList arrayList = a0Var.f16748c;
        int size = arrayList.size();
        int i21 = 0;
        while (i21 < size) {
            l0 l0Var = (l0) arrayList.get(i21);
            if (l0Var != null && (i18 = l0Var.mPosition) >= i16 && i18 <= i15) {
                if (i18 == i10) {
                    l0Var.offsetPosition(i11 - i10, z3);
                } else {
                    l0Var.offsetPosition(i17, z3);
                }
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForMove cached child " + i21 + " holder " + l0Var);
                }
            }
            i21++;
            z3 = false;
        }
        recyclerView.requestLayout();
        recyclerView.f16680u0 = true;
    }

    /* JADX WARN: Code duplicated, block: B:9:0x0022  */
    public void f(l0 l0Var, C0499e0 c0499e0, C0499e0 c0499e1) {
        boolean zH;
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        recyclerView.getClass();
        l0Var.setIsRecyclable(false);
        C0833h c0833h = (C0833h) recyclerView.f16648W;
        if (c0499e0 != null) {
            c0833h.getClass();
            int i10 = c0499e0.f7841a;
            int i11 = c0499e1.f7841a;
            if (i10 == i11 && c0499e0.f7842b == c0499e1.f7842b) {
                c0833h.m(l0Var);
                l0Var.itemView.setAlpha(0.0f);
                c0833h.f16805i.add(l0Var);
                zH = true;
            } else {
                zH = c0833h.h(l0Var, i10, c0499e0.f7842b, i11, c0499e1.f7842b);
            }
        } else {
            c0833h.m(l0Var);
            l0Var.itemView.setAlpha(0.0f);
            c0833h.f16805i.add(l0Var);
            zH = true;
        }
        if (zH) {
            recyclerView.W();
        }
    }

    public void g(l0 l0Var, C0499e0 c0499e0, C0499e0 c0499e1) {
        boolean zH;
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        recyclerView.f16653c.l(l0Var);
        recyclerView.h(l0Var);
        l0Var.setIsRecyclable(false);
        C0833h c0833h = (C0833h) recyclerView.f16648W;
        c0833h.getClass();
        int i10 = c0499e0.f7841a;
        int i11 = c0499e0.f7842b;
        View view = l0Var.itemView;
        int left = c0499e1 == null ? view.getLeft() : c0499e1.f7841a;
        int top = c0499e1 == null ? view.getTop() : c0499e1.f7842b;
        if (l0Var.isRemoved() || (i10 == left && i11 == top)) {
            c0833h.m(l0Var);
            c0833h.f16804h.add(l0Var);
            zH = true;
        } else {
            view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
            zH = c0833h.h(l0Var, i10, i11, left, top);
        }
        if (zH) {
            recyclerView.W();
        }
    }

    public void h(int i10) {
        RecyclerView recyclerView = (RecyclerView) this.f16572a;
        View childAt = recyclerView.getChildAt(i10);
        if (childAt != null) {
            recyclerView.r(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeViewAt(i10);
    }
}
