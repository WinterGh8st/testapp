package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class Q implements u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ T f16607a;

    public Q(T t10) {
        this.f16607a = t10;
    }

    @Override // androidx.recyclerview.widget.u0
    public final int a() {
        T t10 = this.f16607a;
        return t10.f16734o - t10.I();
    }

    @Override // androidx.recyclerview.widget.u0
    public final int b(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f16607a.getClass();
        return T.F(view) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
    }

    @Override // androidx.recyclerview.widget.u0
    public final View c(int i10) {
        return this.f16607a.v(i10);
    }

    @Override // androidx.recyclerview.widget.u0
    public final int d() {
        return this.f16607a.L();
    }

    @Override // androidx.recyclerview.widget.u0
    public final int e(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f16607a.getClass();
        return T.z(view) + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
    }
}
