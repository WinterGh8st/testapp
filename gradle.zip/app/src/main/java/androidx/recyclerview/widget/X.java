package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public abstract class X {
    public abstract void b(RecyclerView recyclerView, int i10, int i11);

    public void a(RecyclerView recyclerView, int i10) {
    }
}
