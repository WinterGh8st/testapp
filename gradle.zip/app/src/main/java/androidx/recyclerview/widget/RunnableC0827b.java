package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.recyclerview.widget.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class RunnableC0827b implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16754a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f16755b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0833h f16756c;

    public /* synthetic */ RunnableC0827b(C0833h c0833h, ArrayList arrayList, int i10) {
        this.f16754a = i10;
        this.f16756c = c0833h;
        this.f16755b = arrayList;
    }

    @Override // java.lang.Runnable
    public final void run() {
        switch (this.f16754a) {
            case 0:
                ArrayList arrayList = this.f16755b;
                int size = arrayList.size();
                int i10 = 0;
                while (true) {
                    C0833h c0833h = this.f16756c;
                    if (i10 >= size) {
                        arrayList.clear();
                        c0833h.f16808m.remove(arrayList);
                    } else {
                        Object obj = arrayList.get(i10);
                        i10++;
                        C0832g c0832g = (C0832g) obj;
                        l0 l0Var = c0832g.f16789a;
                        c0833h.getClass();
                        View view = l0Var.itemView;
                        int i11 = c0832g.f16792d - c0832g.f16790b;
                        int i12 = c0832g.f16793e - c0832g.f16791c;
                        if (i11 != 0) {
                            view.animate().translationX(0.0f);
                        }
                        if (i12 != 0) {
                            view.animate().translationY(0.0f);
                        }
                        ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
                        c0833h.f16811p.add(l0Var);
                        viewPropertyAnimatorAnimate.setDuration(c0833h.f16604e).setListener(new C0829d(c0833h, l0Var, i11, view, i12, viewPropertyAnimatorAnimate)).start();
                    }
                    break;
                }
                break;
            case 1:
                ArrayList arrayList2 = this.f16755b;
                int size2 = arrayList2.size();
                int i13 = 0;
                while (true) {
                    C0833h c0833h2 = this.f16756c;
                    if (i13 >= size2) {
                        arrayList2.clear();
                        c0833h2.f16809n.remove(arrayList2);
                        break;
                    } else {
                        Object obj2 = arrayList2.get(i13);
                        i13++;
                        C0831f c0831f = (C0831f) obj2;
                        c0833h2.getClass();
                        l0 l0Var2 = c0831f.f16783a;
                        View view2 = l0Var2 == null ? null : l0Var2.itemView;
                        l0 l0Var3 = c0831f.f16784b;
                        View view3 = l0Var3 != null ? l0Var3.itemView : null;
                        ArrayList arrayList3 = c0833h2.f16813r;
                        long j10 = c0833h2.f16605f;
                        if (view2 != null) {
                            ViewPropertyAnimator duration = view2.animate().setDuration(j10);
                            arrayList3.add(c0831f.f16783a);
                            duration.translationX(c0831f.f16787e - c0831f.f16785c);
                            duration.translationY(c0831f.f16788f - c0831f.f16786d);
                            duration.alpha(0.0f).setListener(new C0830e(c0833h2, c0831f, duration, view2, 0)).start();
                        }
                        if (view3 != null) {
                            ViewPropertyAnimator viewPropertyAnimatorAnimate2 = view3.animate();
                            arrayList3.add(c0831f.f16784b);
                            viewPropertyAnimatorAnimate2.translationX(0.0f).translationY(0.0f).setDuration(j10).alpha(1.0f).setListener(new C0830e(c0833h2, c0831f, viewPropertyAnimatorAnimate2, view3, 1)).start();
                        }
                    }
                }
                break;
            default:
                ArrayList arrayList4 = this.f16755b;
                int size3 = arrayList4.size();
                int i14 = 0;
                while (true) {
                    C0833h c0833h3 = this.f16756c;
                    if (i14 >= size3) {
                        arrayList4.clear();
                        c0833h3.f16807l.remove(arrayList4);
                    } else {
                        Object obj3 = arrayList4.get(i14);
                        i14++;
                        l0 l0Var4 = (l0) obj3;
                        c0833h3.getClass();
                        View view4 = l0Var4.itemView;
                        ViewPropertyAnimator viewPropertyAnimatorAnimate3 = view4.animate();
                        c0833h3.f16810o.add(l0Var4);
                        viewPropertyAnimatorAnimate3.alpha(1.0f).setDuration(c0833h3.f16602c).setListener(new C0828c(c0833h3, l0Var4, view4, viewPropertyAnimatorAnimate3)).start();
                    }
                    break;
                }
                break;
        }
    }
}
