package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* JADX INFO: renamed from: androidx.recyclerview.widget.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0830e extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16771a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0831f f16772b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f16773c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ View f16774d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0833h f16775e;

    public /* synthetic */ C0830e(C0833h c0833h, C0831f c0831f, ViewPropertyAnimator viewPropertyAnimator, View view, int i10) {
        this.f16771a = i10;
        this.f16775e = c0833h;
        this.f16772b = c0831f;
        this.f16773c = viewPropertyAnimator;
        this.f16774d = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f16771a) {
            case 0:
                this.f16773c.setListener(null);
                View view = this.f16774d;
                view.setAlpha(1.0f);
                view.setTranslationX(0.0f);
                view.setTranslationY(0.0f);
                C0831f c0831f = this.f16772b;
                l0 l0Var = c0831f.f16783a;
                C0833h c0833h = this.f16775e;
                c0833h.c(l0Var);
                c0833h.f16813r.remove(c0831f.f16783a);
                c0833h.j();
                break;
            default:
                this.f16773c.setListener(null);
                View view2 = this.f16774d;
                view2.setAlpha(1.0f);
                view2.setTranslationX(0.0f);
                view2.setTranslationY(0.0f);
                C0831f c0831f2 = this.f16772b;
                l0 l0Var2 = c0831f2.f16784b;
                C0833h c0833h2 = this.f16775e;
                c0833h2.c(l0Var2);
                c0833h2.f16813r.remove(c0831f2.f16784b);
                c0833h2.j();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        switch (this.f16771a) {
            case 0:
                l0 l0Var = this.f16772b.f16783a;
                this.f16775e.getClass();
                break;
            default:
                l0 l0Var2 = this.f16772b.f16784b;
                this.f16775e.getClass();
                break;
        }
    }
}
