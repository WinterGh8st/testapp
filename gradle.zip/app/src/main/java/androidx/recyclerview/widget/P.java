package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class P implements u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ T f16606a;

    public P(T t10) {
        this.f16606a = t10;
    }

    @Override // androidx.recyclerview.widget.u0
    public final int a() {
        T t10 = this.f16606a;
        return t10.f16733n - t10.K();
    }

    @Override // androidx.recyclerview.widget.u0
    public final int b(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f16606a.getClass();
        return T.B(view) - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
    }

    @Override // androidx.recyclerview.widget.u0
    public final View c(int i10) {
        return this.f16606a.v(i10);
    }

    @Override // androidx.recyclerview.widget.u0
    public final int d() {
        return this.f16606a.J();
    }

    @Override // androidx.recyclerview.widget.u0
    public final int e(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        this.f16606a.getClass();
        return T.E(view) + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
    }
}
