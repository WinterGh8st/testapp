package androidx.recyclerview.widget;

import H9.C0337f;
import L.C0499e0;
import android.util.Log;
import android.view.View;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public abstract class N {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public G f16600a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f16601b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f16602c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f16603d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public long f16604e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public long f16605f;

    public static void b(l0 l0Var) {
        int i10 = l0Var.mFlags;
        if (!l0Var.isInvalid() && (i10 & 4) == 0) {
            l0Var.getOldPosition();
            l0Var.getAbsoluteAdapterPosition();
        }
    }

    public abstract boolean a(l0 l0Var, l0 l0Var2, C0499e0 c0499e0, C0499e0 c0499e1);

    /* JADX WARN: Code duplicated, block: B:32:0x0073  */
    /* JADX WARN: Code duplicated, block: B:34:0x0083  */
    /* JADX WARN: Instruction removed from duplicated block: B:34:0x0083, please report this as an issue */
    public final void c(l0 l0Var) {
        g(l0Var);
        G g10 = this.f16600a;
        if (g10 != null) {
            boolean z3 = true;
            l0Var.setIsRecyclable(true);
            if (l0Var.mShadowedHolder != null && l0Var.mShadowingHolder == null) {
                l0Var.mShadowedHolder = null;
            }
            l0Var.mShadowingHolder = null;
            if (l0Var.shouldBeKeptAsChild()) {
                return;
            }
            View view = l0Var.itemView;
            RecyclerView recyclerView = (RecyclerView) g10.f16572a;
            recyclerView.l0();
            Ka.A a3 = recyclerView.f16659f;
            C0337f c0337f = (C0337f) a3.f7157d;
            G g11 = (G) a3.f7156c;
            int i10 = a3.f7155b;
            if (i10 != 1) {
                if (i10 == 2) {
                    throw new IllegalStateException("Cannot call removeViewIfHidden within removeViewIfHidden");
                }
                try {
                    a3.f7155b = 2;
                    int iIndexOfChild = ((RecyclerView) g11.f16572a).indexOfChild(view);
                    if (iIndexOfChild == -1) {
                        a3.T(view);
                    } else if (c0337f.d(iIndexOfChild)) {
                        c0337f.g(iIndexOfChild);
                        a3.T(view);
                        g11.h(iIndexOfChild);
                    } else {
                        a3.f7155b = 0;
                    }
                    a3.f7155b = 0;
                    if (z3) {
                        l0 l0VarM = RecyclerView.M(view);
                        a0 a0Var = recyclerView.f16653c;
                        a0Var.l(l0VarM);
                        a0Var.i(l0VarM);
                        if (RecyclerView.f16609L0) {
                            Log.d("RecyclerView", "after removing animated view: " + view + ", " + recyclerView);
                        }
                    }
                    recyclerView.m0(!z3);
                    if (z3 && l0Var.isTmpDetached()) {
                        recyclerView.removeDetachedView(l0Var.itemView, false);
                        return;
                    }
                } catch (Throwable th) {
                    a3.f7155b = 0;
                    throw th;
                }
            }
            if (((View) a3.f7159f) != view) {
                throw new IllegalStateException("Cannot call removeViewIfHidden within removeView(At) for a different view");
            }
            z3 = false;
            if (z3) {
                l0 l0VarM2 = RecyclerView.M(view);
                a0 a0Var2 = recyclerView.f16653c;
                a0Var2.l(l0VarM2);
                a0Var2.i(l0VarM2);
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "after removing animated view: " + view + ", " + recyclerView);
                }
            }
            recyclerView.m0(!z3);
            if (z3) {
            }
        }
    }

    public abstract void d(l0 l0Var);

    public abstract void e();

    public abstract boolean f();

    public void g(l0 l0Var) {
    }
}
