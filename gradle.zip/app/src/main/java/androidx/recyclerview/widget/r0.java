package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
public final class r0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int[] f16914a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f16915b;

    public final void a() {
        int[] iArr = this.f16914a;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        this.f16915b = null;
    }

    public final void b(int i10) {
        int[] iArr = this.f16914a;
        if (iArr == null) {
            int[] iArr2 = new int[Math.max(i10, 10) + 1];
            this.f16914a = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i10 >= iArr.length) {
            int length = iArr.length;
            while (length <= i10) {
                length *= 2;
            }
            int[] iArr3 = new int[length];
            this.f16914a = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            int[] iArr4 = this.f16914a;
            Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
        }
    }

    public final void c(int i10, int i11) {
        int[] iArr = this.f16914a;
        if (iArr == null || i10 >= iArr.length) {
            return;
        }
        int i12 = i10 + i11;
        b(i12);
        int[] iArr2 = this.f16914a;
        System.arraycopy(iArr2, i10, iArr2, i12, (iArr2.length - i10) - i11);
        Arrays.fill(this.f16914a, i10, i12, -1);
        ArrayList arrayList = this.f16915b;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            q0 q0Var = (q0) this.f16915b.get(size);
            int i13 = q0Var.f16895a;
            if (i13 >= i10) {
                q0Var.f16895a = i13 + i11;
            }
        }
    }

    public final void d(int i10, int i11) {
        int[] iArr = this.f16914a;
        if (iArr == null || i10 >= iArr.length) {
            return;
        }
        int i12 = i10 + i11;
        b(i12);
        int[] iArr2 = this.f16914a;
        System.arraycopy(iArr2, i12, iArr2, i10, (iArr2.length - i10) - i11);
        int[] iArr3 = this.f16914a;
        Arrays.fill(iArr3, iArr3.length - i11, iArr3.length, -1);
        ArrayList arrayList = this.f16915b;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            q0 q0Var = (q0) this.f16915b.get(size);
            int i13 = q0Var.f16895a;
            if (i13 >= i10) {
                if (i13 < i12) {
                    this.f16915b.remove(size);
                } else {
                    q0Var.f16895a = i13 - i11;
                }
            }
        }
    }
}
