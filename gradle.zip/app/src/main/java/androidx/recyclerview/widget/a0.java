package androidx.recyclerview.widget;

import H9.C0337f;
import L.AbstractC0492c;
import L.C0499e0;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityManager;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import p200r1.C1469a;
import p200r1.C1471b;

/* JADX INFO: loaded from: classes.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16746a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ArrayList f16747b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f16748c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final List f16749d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16750e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16751f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public Z f16752g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f16753h;

    public a0(RecyclerView recyclerView) {
        this.f16753h = recyclerView;
        ArrayList arrayList = new ArrayList();
        this.f16746a = arrayList;
        this.f16747b = null;
        this.f16748c = new ArrayList();
        this.f16749d = Collections.unmodifiableList(arrayList);
        this.f16750e = 2;
        this.f16751f = 2;
    }

    public final void a(l0 l0Var, boolean z3) {
        RecyclerView.l(l0Var);
        View view = l0Var.itemView;
        RecyclerView recyclerView = this.f16753h;
        m0 m0Var = recyclerView.f16687y0;
        if (m0Var != null) {
            G1.b bVar = m0Var.f16872e;
            p200r1.U.q(view, bVar != null ? (C1471b) ((WeakHashMap) bVar.f4146f).remove(view) : null);
        }
        if (z3) {
            ArrayList arrayList = recyclerView.f16686y;
            if (arrayList.size() > 0) {
                arrayList.get(0).getClass();
                throw new ClassCastException();
            }
            I i10 = recyclerView.f16682w;
            if (i10 != null) {
                i10.onViewRecycled(l0Var);
            }
            if (recyclerView.f16674r0 != null) {
                recyclerView.f16671q.y(l0Var);
            }
            if (RecyclerView.f16609L0) {
                Log.d("RecyclerView", "dispatchViewRecycled: " + l0Var);
            }
        }
        l0Var.mBindingAdapter = null;
        l0Var.mOwnerRecyclerView = null;
        Z zC = c();
        zC.getClass();
        int itemViewType = l0Var.getItemViewType();
        ArrayList arrayList2 = zC.a(itemViewType).f16735a;
        if (((Y) zC.f16739a.get(itemViewType)).f16736b <= arrayList2.size()) {
            p054e4.e.x(l0Var.itemView);
        } else {
            if (RecyclerView.f16608K0 && arrayList2.contains(l0Var)) {
                throw new IllegalArgumentException("this scrap item already exists");
            }
            l0Var.resetInternal();
            arrayList2.add(l0Var);
        }
    }

    public final int b(int i10) {
        RecyclerView recyclerView = this.f16753h;
        if (i10 >= 0 && i10 < recyclerView.f16674r0.b()) {
            return !recyclerView.f16674r0.f16820g ? i10 : recyclerView.f16657e.i(i10, 0);
        }
        StringBuilder sbK = p096h9.i.k(i10, "invalid position ", ". State item count is ");
        sbK.append(recyclerView.f16674r0.b());
        sbK.append(recyclerView.C());
        throw new IndexOutOfBoundsException(sbK.toString());
    }

    public final Z c() {
        if (this.f16752g == null) {
            Z z3 = new Z();
            z3.f16739a = new SparseArray();
            z3.f16740b = 0;
            z3.f16741c = Collections.newSetFromMap(new IdentityHashMap());
            this.f16752g = z3;
            d();
        }
        return this.f16752g;
    }

    public final void d() {
        RecyclerView recyclerView;
        I i10;
        Z z3 = this.f16752g;
        if (z3 == null || (i10 = (recyclerView = this.f16753h).f16682w) == null || !recyclerView.f16621C) {
            return;
        }
        z3.f16741c.add(i10);
    }

    public final void e(I i10, boolean z3) {
        Z z5 = this.f16752g;
        if (z5 == null) {
            return;
        }
        Set set = z5.f16741c;
        set.remove(i10);
        if (set.size() != 0 || z3) {
            return;
        }
        int i11 = 0;
        while (true) {
            SparseArray sparseArray = z5.f16739a;
            if (i11 >= sparseArray.size()) {
                return;
            }
            ArrayList arrayList = ((Y) sparseArray.get(sparseArray.keyAt(i11))).f16735a;
            for (int i12 = 0; i12 < arrayList.size(); i12++) {
                p054e4.e.x(((l0) arrayList.get(i12)).itemView);
            }
            i11++;
        }
    }

    public final void f() {
        ArrayList arrayList = this.f16748c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            g(size);
        }
        arrayList.clear();
        if (RecyclerView.f16613Q0) {
            Db.m mVar = this.f16753h.f16672q0;
            int[] iArr = (int[]) mVar.f2664e;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            mVar.f2663d = 0;
        }
    }

    public final void g(int i10) {
        if (RecyclerView.f16609L0) {
            Log.d("RecyclerView", "Recycling cached view at index " + i10);
        }
        ArrayList arrayList = this.f16748c;
        l0 l0Var = (l0) arrayList.get(i10);
        if (RecyclerView.f16609L0) {
            Log.d("RecyclerView", "CachedViewHolder to be recycled: " + l0Var);
        }
        a(l0Var, true);
        arrayList.remove(i10);
    }

    public final void h(View view) {
        l0 l0VarM = RecyclerView.M(view);
        boolean zIsTmpDetached = l0VarM.isTmpDetached();
        RecyclerView recyclerView = this.f16753h;
        if (zIsTmpDetached) {
            recyclerView.removeDetachedView(view, false);
        }
        if (l0VarM.isScrap()) {
            l0VarM.unScrap();
        } else if (l0VarM.wasReturnedFromScrap()) {
            l0VarM.clearReturnedFromScrapFlag();
        }
        i(l0VarM);
        if (recyclerView.f16648W == null || l0VarM.isRecyclable()) {
            return;
        }
        recyclerView.f16648W.d(l0VarM);
    }

    /* JADX WARN: Code duplicated, block: B:54:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:56:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:58:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:61:0x00df A[LOOP:2: B:57:0x00d2->B:61:0x00df, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:87:0x00e2 A[EDGE_INSN: B:87:0x00e2->B:62:0x00e2 BREAK  A[LOOP:1: B:53:0x00bb->B:60:0x00dc], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x00e2 A[EDGE_INSN: B:88:0x00e2->B:62:0x00e2 BREAK  A[LOOP:1: B:53:0x00bb->B:60:0x00dc, LOOP_LABEL: LOOP:1: B:53:0x00bb->B:60:0x00dc], SYNTHETIC] */
    public final void i(l0 l0Var) {
        boolean z3;
        int i10;
        int i11;
        Db.m mVar;
        int i12;
        int i13;
        boolean zIsScrap = l0Var.isScrap();
        boolean z5 = false;
        boolean z10 = true;
        RecyclerView recyclerView = this.f16753h;
        if (zIsScrap || l0Var.itemView.getParent() != null) {
            StringBuilder sb2 = new StringBuilder("Scrapped or attached views may not be recycled. isScrap:");
            sb2.append(l0Var.isScrap());
            sb2.append(" isAttached:");
            sb2.append(l0Var.itemView.getParent() != null);
            sb2.append(recyclerView.C());
            throw new IllegalArgumentException(sb2.toString());
        }
        if (l0Var.isTmpDetached()) {
            StringBuilder sb3 = new StringBuilder("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
            sb3.append(l0Var);
            throw new IllegalArgumentException(AbstractC0492c.i(recyclerView, sb3));
        }
        if (l0Var.shouldIgnore()) {
            throw new IllegalArgumentException(AbstractC0492c.i(recyclerView, new StringBuilder("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.")));
        }
        boolean zDoesTransientStatePreventRecycling = l0Var.doesTransientStatePreventRecycling();
        I i14 = recyclerView.f16682w;
        boolean z11 = i14 != null && zDoesTransientStatePreventRecycling && i14.onFailedToRecycleView(l0Var);
        boolean z12 = RecyclerView.f16608K0;
        ArrayList arrayList = this.f16748c;
        if (z12 && arrayList.contains(l0Var)) {
            StringBuilder sb4 = new StringBuilder("cached view received recycle internal? ");
            sb4.append(l0Var);
            throw new IllegalArgumentException(AbstractC0492c.i(recyclerView, sb4));
        }
        if (z11 || l0Var.isRecyclable()) {
            if (this.f16751f <= 0 || l0Var.hasAnyOfTheFlags(526)) {
                z3 = false;
            } else {
                int size = arrayList.size();
                if (size >= this.f16751f && size > 0) {
                    g(0);
                    size--;
                }
                if (RecyclerView.f16613Q0 && size > 0) {
                    Db.m mVar2 = recyclerView.f16672q0;
                    int i15 = l0Var.mPosition;
                    if (((int[]) mVar2.f2664e) != null) {
                        int i16 = mVar2.f2663d * 2;
                        int i17 = 0;
                        while (true) {
                            if (i17 >= i16) {
                                i10 = size - 1;
                                loop1: while (i10 >= 0) {
                                    i11 = ((l0) arrayList.get(i10)).mPosition;
                                    mVar = recyclerView.f16672q0;
                                    if (((int[]) mVar.f2664e) != null) {
                                        break;
                                    }
                                    i12 = mVar.f2663d * 2;
                                    i13 = 0;
                                    while (true) {
                                        if (i13 < i12) {
                                            break loop1;
                                        } else if (((int[]) mVar.f2664e)[i13] == i11) {
                                            break;
                                        } else {
                                            i13 += 2;
                                        }
                                    }
                                    i10--;
                                }
                                size = i10 + 1;
                            } else if (((int[]) mVar2.f2664e)[i17] != i15) {
                                i17 += 2;
                            }
                        }
                    } else {
                        i10 = size - 1;
                        loop1: while (i10 >= 0) {
                            i11 = ((l0) arrayList.get(i10)).mPosition;
                            mVar = recyclerView.f16672q0;
                            if (((int[]) mVar.f2664e) != null) {
                                break;
                                break;
                            }
                            i12 = mVar.f2663d * 2;
                            i13 = 0;
                            while (true) {
                                if (i13 < i12) {
                                    break loop1;
                                    break loop1;
                                } else if (((int[]) mVar.f2664e)[i13] == i11) {
                                    break;
                                } else {
                                    i13 += 2;
                                }
                            }
                            i10--;
                        }
                        size = i10 + 1;
                    }
                }
                arrayList.add(size, l0Var);
                z3 = true;
            }
            if (z3) {
                z10 = false;
            } else {
                a(l0Var, true);
            }
            z5 = z3;
        } else {
            if (RecyclerView.f16609L0) {
                Log.d("RecyclerView", "trying to recycle a non-recycleable holder. Hopefully, it will re-visit here. We are still removing it from animation lists" + recyclerView.C());
            }
            z10 = false;
        }
        recyclerView.f16671q.y(l0Var);
        if (z5 || z10 || !zDoesTransientStatePreventRecycling) {
            return;
        }
        p054e4.e.x(l0Var.itemView);
        l0Var.mBindingAdapter = null;
        l0Var.mOwnerRecyclerView = null;
    }

    public final void j(View view) {
        N n10;
        l0 l0VarM = RecyclerView.M(view);
        boolean zHasAnyOfTheFlags = l0VarM.hasAnyOfTheFlags(12);
        RecyclerView recyclerView = this.f16753h;
        if (!zHasAnyOfTheFlags && l0VarM.isUpdated() && (n10 = recyclerView.f16648W) != null) {
            C0833h c0833h = (C0833h) n10;
            if (l0VarM.getUnmodifiedPayloads().isEmpty() && c0833h.f16803g && !l0VarM.isInvalid()) {
                if (this.f16747b == null) {
                    this.f16747b = new ArrayList();
                }
                l0VarM.setScrapContainer(this, true);
                this.f16747b.add(l0VarM);
                return;
            }
        }
        if (l0VarM.isInvalid() && !l0VarM.isRemoved() && !recyclerView.f16682w.hasStableIds()) {
            throw new IllegalArgumentException(AbstractC0492c.i(recyclerView, new StringBuilder("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.")));
        }
        l0VarM.setScrapContainer(this, false);
        this.f16746a.add(l0VarM);
    }

    /* JADX WARN: Code duplicated, block: B:191:0x0381 A[EDGE_INSN: B:191:0x0381->B:192:0x0382 BREAK  A[LOOP:3: B:186:0x0369->B:190:0x037e]] */
    /* JADX WARN: Code duplicated, block: B:302:0x054e  */
    /* JADX WARN: Code duplicated, block: B:303:0x055a  */
    /* JADX WARN: Code duplicated, block: B:305:0x0560  */
    /* JADX WARN: Code duplicated, block: B:306:0x056c  */
    /* JADX WARN: Code duplicated, block: B:311:0x0575  */
    /* JADX WARN: Code duplicated, block: B:35:0x0081 A[EDGE_INSN: B:35:0x0081->B:36:0x0082 BREAK  A[LOOP:0: B:14:0x0027->B:20:0x0041]] */
    /* JADX WARN: Code duplicated, block: B:75:0x0130  */
    public final l0 k(int i10, long j10) {
        boolean z3;
        l0 l0VarCreateViewHolder;
        boolean z5;
        long j11;
        boolean z10;
        boolean z11;
        byte b10;
        ViewGroup.LayoutParams layoutParams;
        RecyclerView.LayoutParams layoutParams2;
        RecyclerView recyclerViewH;
        l0 l0Var;
        View view;
        int iB;
        boolean z12;
        int size;
        int i11;
        boolean z13 = true;
        RecyclerView recyclerView = this.f16753h;
        if (i10 < 0 || i10 >= recyclerView.f16674r0.b()) {
            StringBuilder sbG = p015b2.a.g("Invalid item position ", i10, "(", i10, "). Item count:");
            sbG.append(recyclerView.f16674r0.b());
            sbG.append(recyclerView.C());
            throw new IndexOutOfBoundsException(sbG.toString());
        }
        h0 h0Var = recyclerView.f16674r0;
        if (h0Var.f16820g) {
            ArrayList arrayList = this.f16747b;
            if (arrayList != null && (size = arrayList.size()) != 0) {
                int i12 = 0;
                while (true) {
                    if (i12 >= size) {
                        if (recyclerView.f16682w.hasStableIds() && (i11 = recyclerView.f16657e.i(i10, 0)) > 0 && i11 < recyclerView.f16682w.getItemCount()) {
                            long itemId = recyclerView.f16682w.getItemId(i11);
                            int i13 = 0;
                            while (true) {
                                if (i13 >= size) {
                                    l0VarCreateViewHolder = null;
                                    break;
                                }
                                l0 l0Var2 = (l0) this.f16747b.get(i13);
                                if (!l0Var2.wasReturnedFromScrap() && l0Var2.getItemId() == itemId) {
                                    l0Var2.addFlags(32);
                                    l0VarCreateViewHolder = l0Var2;
                                    break;
                                }
                                i13++;
                            }
                        } else {
                            l0VarCreateViewHolder = null;
                            break;
                        }
                    } else {
                        l0VarCreateViewHolder = (l0) this.f16747b.get(i12);
                        if (!l0VarCreateViewHolder.wasReturnedFromScrap() && l0VarCreateViewHolder.getLayoutPosition() == i10) {
                            l0VarCreateViewHolder.addFlags(32);
                            break;
                        }
                        i12++;
                    }
                }
            } else {
                l0VarCreateViewHolder = null;
                break;
            }
            z3 = l0VarCreateViewHolder != null;
        } else {
            z3 = false;
            l0VarCreateViewHolder = null;
        }
        ArrayList arrayList2 = this.f16748c;
        ArrayList arrayList3 = this.f16746a;
        if (l0VarCreateViewHolder == null) {
            int size2 = arrayList3.size();
            int i14 = 0;
            while (true) {
                if (i14 >= size2) {
                    z5 = z13;
                    ArrayList arrayList4 = (ArrayList) recyclerView.f16659f.f7158e;
                    int size3 = arrayList4.size();
                    int i15 = 0;
                    while (true) {
                        if (i15 >= size3) {
                            view = null;
                            break;
                        }
                        view = (View) arrayList4.get(i15);
                        l0 l0VarM = RecyclerView.M(view);
                        if (l0VarM.getLayoutPosition() == i10 && !l0VarM.isInvalid() && !l0VarM.isRemoved()) {
                            break;
                        }
                        i15++;
                    }
                    if (view == null) {
                        int size4 = arrayList2.size();
                        int i16 = 0;
                        while (true) {
                            if (i16 >= size4) {
                                l0VarCreateViewHolder = null;
                                break;
                            }
                            l0VarCreateViewHolder = (l0) arrayList2.get(i16);
                            if (!l0VarCreateViewHolder.isInvalid() && l0VarCreateViewHolder.getLayoutPosition() == i10 && !l0VarCreateViewHolder.isAttachedToTransitionOverlay()) {
                                arrayList2.remove(i16);
                                if (!RecyclerView.f16609L0) {
                                    break;
                                }
                                Log.d("RecyclerView", "getScrapOrHiddenOrCachedHolderForPosition(" + i10 + ") found match in cache: " + l0VarCreateViewHolder);
                                break;
                            }
                            i16++;
                        }
                    } else {
                        l0 l0VarM2 = RecyclerView.M(view);
                        Ka.A a3 = recyclerView.f16659f;
                        int iIndexOfChild = ((RecyclerView) ((G) a3.f7156c).f16572a).indexOfChild(view);
                        if (iIndexOfChild < 0) {
                            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
                        }
                        C0337f c0337f = (C0337f) a3.f7157d;
                        if (!c0337f.d(iIndexOfChild)) {
                            throw new RuntimeException("trying to unhide a view that was not hidden" + view);
                        }
                        c0337f.a(iIndexOfChild);
                        a3.T(view);
                        Ka.A a9 = recyclerView.f16659f;
                        int iIndexOfChild2 = ((RecyclerView) ((G) a9.f7156c).f16572a).indexOfChild(view);
                        if (iIndexOfChild2 == -1) {
                            iB = -1;
                        } else {
                            C0337f c0337f2 = (C0337f) a9.f7157d;
                            if (c0337f2.d(iIndexOfChild2)) {
                                iB = -1;
                            } else {
                                iB = iIndexOfChild2 - c0337f2.b(iIndexOfChild2);
                            }
                        }
                        if (iB == -1) {
                            StringBuilder sb2 = new StringBuilder("layout index should not be -1 after unhiding a view:");
                            sb2.append(l0VarM2);
                            throw new IllegalStateException(AbstractC0492c.i(recyclerView, sb2));
                        }
                        recyclerView.f16659f.x(iB);
                        j(view);
                        l0VarM2.addFlags(8224);
                        l0VarCreateViewHolder = l0VarM2;
                        break;
                    }
                } else {
                    l0 l0Var3 = (l0) arrayList3.get(i14);
                    if (!l0Var3.wasReturnedFromScrap()) {
                        z5 = z13;
                        if (l0Var3.getLayoutPosition() == i10 && !l0Var3.isInvalid() && (h0Var.f16820g || !l0Var3.isRemoved())) {
                            l0Var3.addFlags(32);
                            l0VarCreateViewHolder = l0Var3;
                            break;
                        }
                    } else {
                        z5 = z13;
                    }
                    i14++;
                    z13 = z5;
                }
            }
            if (l0VarCreateViewHolder != null) {
                if (!l0VarCreateViewHolder.isRemoved()) {
                    int i17 = l0VarCreateViewHolder.mPosition;
                    if (i17 < 0 || i17 >= recyclerView.f16682w.getItemCount()) {
                        StringBuilder sb3 = new StringBuilder("Inconsistency detected. Invalid view holder adapter position");
                        sb3.append(l0VarCreateViewHolder);
                        throw new IndexOutOfBoundsException(AbstractC0492c.i(recyclerView, sb3));
                    }
                    z12 = ((h0Var.f16820g || recyclerView.f16682w.getItemViewType(l0VarCreateViewHolder.mPosition) == l0VarCreateViewHolder.getItemViewType()) && (!recyclerView.f16682w.hasStableIds() || l0VarCreateViewHolder.getItemId() == recyclerView.f16682w.getItemId(l0VarCreateViewHolder.mPosition))) ? z5 : false;
                } else {
                    if (RecyclerView.f16608K0 && !h0Var.f16820g) {
                        throw new IllegalStateException(AbstractC0492c.i(recyclerView, new StringBuilder("should not receive a removed view unless it is pre layout")));
                    }
                    z12 = h0Var.f16820g;
                }
                if (z12) {
                    z3 = z5;
                } else {
                    l0VarCreateViewHolder.addFlags(4);
                    if (l0VarCreateViewHolder.isScrap()) {
                        recyclerView.removeDetachedView(l0VarCreateViewHolder.itemView, false);
                        l0VarCreateViewHolder.unScrap();
                    } else if (l0VarCreateViewHolder.wasReturnedFromScrap()) {
                        l0VarCreateViewHolder.clearReturnedFromScrapFlag();
                    }
                    i(l0VarCreateViewHolder);
                    l0VarCreateViewHolder = null;
                }
            }
        } else {
            z5 = true;
        }
        if (l0VarCreateViewHolder == null) {
            int i18 = recyclerView.f16657e.i(i10, 0);
            if (i18 < 0 || i18 >= recyclerView.f16682w.getItemCount()) {
                StringBuilder sbG2 = p015b2.a.g("Inconsistency detected. Invalid item position ", i10, "(offset:", i18, ").state:");
                sbG2.append(h0Var.b());
                sbG2.append(recyclerView.C());
                throw new IndexOutOfBoundsException(sbG2.toString());
            }
            int itemViewType = recyclerView.f16682w.getItemViewType(i18);
            if (recyclerView.f16682w.hasStableIds()) {
                long itemId2 = recyclerView.f16682w.getItemId(i18);
                int size5 = arrayList3.size() - 1;
                while (true) {
                    if (size5 < 0) {
                        j11 = 3;
                        int size6 = arrayList2.size() - 1;
                        while (true) {
                            if (size6 >= 0) {
                                l0 l0Var4 = (l0) arrayList2.get(size6);
                                if (l0Var4.getItemId() != itemId2 || l0Var4.isAttachedToTransitionOverlay()) {
                                    size6--;
                                } else {
                                    if (itemViewType == l0Var4.getItemViewType()) {
                                        arrayList2.remove(size6);
                                        l0VarCreateViewHolder = l0Var4;
                                        break;
                                    }
                                    g(size6);
                                }
                            }
                            l0VarCreateViewHolder = null;
                            break;
                        }
                    }
                    l0VarCreateViewHolder = (l0) arrayList3.get(size5);
                    if (l0VarCreateViewHolder.getItemId() == itemId2 && !l0VarCreateViewHolder.wasReturnedFromScrap()) {
                        j11 = 3;
                        if (itemViewType == l0VarCreateViewHolder.getItemViewType()) {
                            l0VarCreateViewHolder.addFlags(32);
                            if (!l0VarCreateViewHolder.isRemoved() || h0Var.f16820g) {
                                break;
                                break;
                            }
                            l0VarCreateViewHolder.setFlags(2, 14);
                            break;
                        }
                        arrayList3.remove(size5);
                        recyclerView.removeDetachedView(l0VarCreateViewHolder.itemView, false);
                        l0 l0VarM3 = RecyclerView.M(l0VarCreateViewHolder.itemView);
                        l0VarM3.mScrapContainer = null;
                        l0VarM3.mInChangeScrap = false;
                        l0VarM3.clearReturnedFromScrapFlag();
                        i(l0VarM3);
                    }
                    size5--;
                }
                if (l0VarCreateViewHolder != null) {
                    l0VarCreateViewHolder.mPosition = i18;
                    z3 = z5;
                }
            } else {
                j11 = 3;
            }
            if (l0VarCreateViewHolder == null) {
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "tryGetViewHolderForPositionByDeadline(" + i10 + ") fetching from shared pool");
                }
                Y y10 = (Y) c().f16739a.get(itemViewType);
                if (y10 == null) {
                    l0Var = null;
                    break;
                }
                ArrayList arrayList5 = y10.f16735a;
                if (!arrayList5.isEmpty()) {
                    int size7 = arrayList5.size() - 1;
                    while (true) {
                        if (size7 < 0) {
                            l0Var = null;
                            break;
                        }
                        if (!((l0) arrayList5.get(size7)).isAttachedToTransitionOverlay()) {
                            l0Var = (l0) arrayList5.remove(size7);
                            break;
                        }
                        size7--;
                    }
                } else {
                    l0Var = null;
                    break;
                }
                if (l0Var != null) {
                    l0Var.resetInternal();
                    boolean z14 = RecyclerView.f16608K0;
                }
                l0VarCreateViewHolder = l0Var;
            }
            if (l0VarCreateViewHolder == null) {
                long nanoTime = recyclerView.getNanoTime();
                if (j10 != Long.MAX_VALUE) {
                    long j12 = this.f16752g.a(itemViewType).f16737c;
                    if (!((j12 == 0 || j12 + nanoTime < j10) ? z5 : false)) {
                        return null;
                    }
                }
                l0VarCreateViewHolder = recyclerView.f16682w.createViewHolder(recyclerView, itemViewType);
                if (RecyclerView.f16613Q0 && (recyclerViewH = RecyclerView.H(l0VarCreateViewHolder.itemView)) != null) {
                    l0VarCreateViewHolder.mNestedRecyclerView = new WeakReference<>(recyclerViewH);
                }
                long nanoTime2 = recyclerView.getNanoTime() - nanoTime;
                Y yA = this.f16752g.a(itemViewType);
                long j13 = yA.f16737c;
                if (j13 != 0) {
                    nanoTime2 = (nanoTime2 / 4) + ((j13 / 4) * j11);
                }
                yA.f16737c = nanoTime2;
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "tryGetViewHolderForPositionByDeadline created new ViewHolder");
                }
            }
        } else {
            j11 = 3;
        }
        if (z3 && !h0Var.f16820g && l0VarCreateViewHolder.hasAnyOfTheFlags(8192)) {
            l0VarCreateViewHolder.setFlags(0, 8192);
            if (h0Var.f16823j) {
                N.b(l0VarCreateViewHolder);
                N n10 = recyclerView.f16648W;
                l0VarCreateViewHolder.getUnmodifiedPayloads();
                n10.getClass();
                C0499e0 c0499e0 = new C0499e0();
                c0499e0.a(l0VarCreateViewHolder);
                recyclerView.Z(l0VarCreateViewHolder, c0499e0);
            }
        }
        if (!h0Var.f16820g || !l0VarCreateViewHolder.isBound()) {
            if (!l0VarCreateViewHolder.isBound() || l0VarCreateViewHolder.needsUpdate() || l0VarCreateViewHolder.isInvalid()) {
                if (RecyclerView.f16608K0 && l0VarCreateViewHolder.isRemoved()) {
                    StringBuilder sb4 = new StringBuilder("Removed holder should be bound and it should come here only in pre-layout. Holder: ");
                    sb4.append(l0VarCreateViewHolder);
                    throw new IllegalStateException(AbstractC0492c.i(recyclerView, sb4));
                }
                int i19 = recyclerView.f16657e.i(i10, 0);
                C1471b c1471b = null;
                l0VarCreateViewHolder.mBindingAdapter = null;
                l0VarCreateViewHolder.mOwnerRecyclerView = recyclerView;
                int itemViewType2 = l0VarCreateViewHolder.getItemViewType();
                long nanoTime3 = recyclerView.getNanoTime();
                if (j10 != Long.MAX_VALUE) {
                    long j14 = this.f16752g.a(itemViewType2).f16738d;
                    if (j14 == 0 || j14 + nanoTime3 < j10) {
                    }
                }
                if (l0VarCreateViewHolder.isTmpDetached()) {
                    recyclerView.attachViewToParent(l0VarCreateViewHolder.itemView, recyclerView.getChildCount(), l0VarCreateViewHolder.itemView.getLayoutParams());
                    z10 = z5;
                } else {
                    z10 = false;
                }
                recyclerView.f16682w.bindViewHolder(l0VarCreateViewHolder, i19);
                if (z10) {
                    recyclerView.detachViewFromParent(l0VarCreateViewHolder.itemView);
                }
                long nanoTime4 = recyclerView.getNanoTime() - nanoTime3;
                Y yA2 = this.f16752g.a(l0VarCreateViewHolder.getItemViewType());
                long j15 = yA2.f16738d;
                if (j15 != 0) {
                    nanoTime4 = (nanoTime4 / 4) + ((j15 / 4) * j11);
                }
                yA2.f16738d = nanoTime4;
                AccessibilityManager accessibilityManager = recyclerView.f16638L;
                if ((accessibilityManager == null || !accessibilityManager.isEnabled()) ? false : z5) {
                    View view2 = l0VarCreateViewHolder.itemView;
                    WeakHashMap weakHashMap = p200r1.U.f27683a;
                    if (view2.getImportantForAccessibility() == 0) {
                        z11 = z5;
                        view2.setImportantForAccessibility(z11 ? 1 : 0);
                    } else {
                        z11 = z5;
                    }
                    m0 m0Var = recyclerView.f16687y0;
                    if (m0Var != null) {
                        G1.b bVar = m0Var.f16872e;
                        if (bVar != null) {
                            View.AccessibilityDelegate accessibilityDelegateF = p200r1.U.f(view2);
                            if (accessibilityDelegateF != null) {
                                c1471b = accessibilityDelegateF instanceof C1469a ? ((C1469a) accessibilityDelegateF).f27693a : new C1471b(accessibilityDelegateF);
                            }
                            if (c1471b != null && c1471b != bVar) {
                                ((WeakHashMap) bVar.f4146f).put(view2, c1471b);
                            }
                        }
                        p200r1.U.q(view2, bVar);
                    }
                } else {
                    z11 = z5;
                }
                if (h0Var.f16820g) {
                    l0VarCreateViewHolder.mPreLayoutPosition = i10;
                }
                b10 = z11 ? 1 : 0;
            }
            layoutParams = l0VarCreateViewHolder.itemView.getLayoutParams();
            if (layoutParams == null) {
                layoutParams2 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
                l0VarCreateViewHolder.itemView.setLayoutParams(layoutParams2);
            } else if (recyclerView.checkLayoutParams(layoutParams)) {
                layoutParams2 = (RecyclerView.LayoutParams) layoutParams;
            } else {
                layoutParams2 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams);
                l0VarCreateViewHolder.itemView.setLayoutParams(layoutParams2);
            }
            layoutParams2.f16690a = l0VarCreateViewHolder;
            if (z3 || b10 == 0) {
                z11 = false;
            }
            layoutParams2.f16693d = z11;
            return l0VarCreateViewHolder;
        }
        l0VarCreateViewHolder.mPreLayoutPosition = i10;
        b10 = 0;
        z11 = z5;
        layoutParams = l0VarCreateViewHolder.itemView.getLayoutParams();
        if (layoutParams == null) {
            layoutParams2 = (RecyclerView.LayoutParams) recyclerView.generateDefaultLayoutParams();
            l0VarCreateViewHolder.itemView.setLayoutParams(layoutParams2);
        } else if (recyclerView.checkLayoutParams(layoutParams)) {
            layoutParams2 = (RecyclerView.LayoutParams) recyclerView.generateLayoutParams(layoutParams);
            l0VarCreateViewHolder.itemView.setLayoutParams(layoutParams2);
        } else {
            layoutParams2 = (RecyclerView.LayoutParams) layoutParams;
        }
        layoutParams2.f16690a = l0VarCreateViewHolder;
        if (z3) {
            z11 = false;
        } else {
            z11 = false;
        }
        layoutParams2.f16693d = z11;
        return l0VarCreateViewHolder;
    }

    public final void l(l0 l0Var) {
        if (l0Var.mInChangeScrap) {
            this.f16747b.remove(l0Var);
        } else {
            this.f16746a.remove(l0Var);
        }
        l0Var.mScrapContainer = null;
        l0Var.mInChangeScrap = false;
        l0Var.clearReturnedFromScrapFlag();
    }

    public final void m() {
        T t10 = this.f16753h.f16684x;
        this.f16751f = this.f16750e + (t10 != null ? t10.f16730j : 0);
        ArrayList arrayList = this.f16748c;
        for (int size = arrayList.size() - 1; size >= 0 && arrayList.size() > this.f16751f; size--) {
            g(size);
        }
    }
}
