package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* JADX INFO: renamed from: androidx.recyclerview.widget.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0828c extends AnimatorListenerAdapter {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16757a = 1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ l0 f16758b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f16759c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f16760d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0833h f16761e;

    public C0828c(C0833h c0833h, l0 l0Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f16761e = c0833h;
        this.f16758b = l0Var;
        this.f16760d = viewPropertyAnimator;
        this.f16759c = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.f16757a) {
            case 1:
                this.f16759c.setAlpha(1.0f);
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f16757a) {
            case 0:
                this.f16760d.setListener(null);
                this.f16759c.setAlpha(1.0f);
                C0833h c0833h = this.f16761e;
                l0 l0Var = this.f16758b;
                c0833h.c(l0Var);
                c0833h.f16812q.remove(l0Var);
                c0833h.j();
                break;
            default:
                this.f16760d.setListener(null);
                C0833h c0833h2 = this.f16761e;
                l0 l0Var2 = this.f16758b;
                c0833h2.c(l0Var2);
                c0833h2.f16810o.remove(l0Var2);
                c0833h2.j();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        switch (this.f16757a) {
            case 0:
                this.f16761e.getClass();
                break;
            default:
                this.f16761e.getClass();
                break;
        }
    }

    public C0828c(C0833h c0833h, l0 l0Var, View view, ViewPropertyAnimator viewPropertyAnimator) {
        this.f16761e = c0833h;
        this.f16758b = l0Var;
        this.f16759c = view;
        this.f16760d = viewPropertyAnimator;
    }
}
