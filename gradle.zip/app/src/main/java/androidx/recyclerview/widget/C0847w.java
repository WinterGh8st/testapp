package androidx.recyclerview.widget;

import p032c7.AbstractC0933i;

/* JADX INFO: renamed from: androidx.recyclerview.widget.w, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0847w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16969a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16970b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16971c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16972d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16973e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16974f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16975g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16976h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f16977i;

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("LayoutState{mAvailable=");
        sb2.append(this.f16970b);
        sb2.append(", mCurrentPosition=");
        sb2.append(this.f16971c);
        sb2.append(", mItemDirection=");
        sb2.append(this.f16972d);
        sb2.append(", mLayoutDirection=");
        sb2.append(this.f16973e);
        sb2.append(", mStartLine=");
        sb2.append(this.f16974f);
        sb2.append(", mEndLine=");
        return AbstractC0933i.h(sb2, this.f16975g, '}');
    }
}
