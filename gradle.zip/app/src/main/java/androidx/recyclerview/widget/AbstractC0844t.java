package androidx.recyclerview.widget;

import C9.C0090f1;
import C9.p1;
import android.view.View;
import com.flamingotools.ws.R;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.util.WeakHashMap;

/* JADX INFO: renamed from: androidx.recyclerview.widget.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0844t {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final E1.d f16928c = new E1.d(1);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final E1.d f16929d = new E1.d(2);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16930a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16931b;

    public static void a(l0 l0Var) {
        View view = l0Var.itemView;
        Object tag = view.getTag(R.id.item_touch_helper_previous_elevation);
        if (tag instanceof Float) {
            float fFloatValue = ((Float) tag).floatValue();
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            p200r1.H.s(view, fFloatValue);
        }
        view.setTag(R.id.item_touch_helper_previous_elevation, null);
        view.setTranslationX(0.0f);
        view.setTranslationY(0.0f);
    }

    public static int b(int i10, int i11) {
        int i12;
        int i13 = i10 & 3158064;
        if (i13 == 0) {
            return i10;
        }
        int i14 = i10 & (~i13);
        if (i11 == 0) {
            i12 = i13 >> 2;
        } else {
            int i15 = i13 >> 1;
            i14 |= (-3158065) & i15;
            i12 = (i15 & 3158064) >> 2;
        }
        return i14 | i12;
    }

    public static int c(int i10, int i11) {
        int i12;
        int i13 = i10 & 789516;
        if (i13 == 0) {
            return i10;
        }
        int i14 = i10 & (~i13);
        if (i11 == 0) {
            i12 = i13 << 2;
        } else {
            int i15 = i13 << 1;
            i14 |= (-789517) & i15;
            i12 = (i15 & 789516) << 2;
        }
        return i14 | i12;
    }

    public final int d(PaymentMethodsRecyclerView paymentMethodsRecyclerView, l0 l0Var) {
        C0090f1 c0090f1 = (C0090f1) this;
        p097ha.k.f(paymentMethodsRecyclerView, "recyclerView");
        p097ha.k.f(l0Var, "viewHolder");
        int i10 = l0Var instanceof p1 ? c0090f1.f16931b : 0;
        return i10 | (i10 << 8);
    }

    public final int e(PaymentMethodsRecyclerView paymentMethodsRecyclerView, int i10, int i11, long j10) {
        if (this.f16930a == -1) {
            this.f16930a = paymentMethodsRecyclerView.getResources().getDimensionPixelSize(R.dimen.item_touch_helper_max_drag_scroll_per_frame);
        }
        int interpolation = (int) (f16928c.getInterpolation(j10 <= 2000 ? j10 / 2000.0f : 1.0f) * ((int) (f16929d.getInterpolation(Math.min(1.0f, (Math.abs(i11) * 1.0f) / i10)) * ((int) Math.signum(i11)) * this.f16930a)));
        if (interpolation == 0) {
            return i11 > 0 ? 1 : -1;
        }
        return interpolation;
    }
}
