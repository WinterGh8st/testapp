package androidx.recyclerview.widget;

import p032c7.AbstractC0933i;

/* JADX INFO: renamed from: androidx.recyclerview.widget.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0831f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l0 f16783a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public l0 f16784b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16785c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16786d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16787e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16788f;

    public final String toString() {
        StringBuilder sb2 = new StringBuilder("ChangeInfo{oldHolder=");
        sb2.append(this.f16783a);
        sb2.append(", newHolder=");
        sb2.append(this.f16784b);
        sb2.append(", fromX=");
        sb2.append(this.f16785c);
        sb2.append(", fromY=");
        sb2.append(this.f16786d);
        sb2.append(", toX=");
        sb2.append(this.f16787e);
        sb2.append(", toY=");
        return AbstractC0933i.h(sb2, this.f16788f, '}');
    }
}
