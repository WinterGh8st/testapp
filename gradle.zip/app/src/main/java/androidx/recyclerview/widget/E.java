package androidx.recyclerview.widget;

import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Scroller;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class E extends V {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public RecyclerView f16566a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final n0 f16567b = new n0(this);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public D f16568c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C f16569d;

    public static int c(View view, I1.g gVar) {
        return ((gVar.c(view) / 2) + gVar.e(view)) - ((gVar.l() / 2) + gVar.k());
    }

    public static View d(T t10, I1.g gVar) {
        int iW = t10.w();
        View view = null;
        if (iW == 0) {
            return null;
        }
        int iL = (gVar.l() / 2) + gVar.k();
        int i10 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        for (int i11 = 0; i11 < iW; i11++) {
            View viewV = t10.v(i11);
            int iAbs = Math.abs(((gVar.c(viewV) / 2) + gVar.e(viewV)) - iL);
            if (iAbs < i10) {
                view = viewV;
                i10 = iAbs;
            }
        }
        return view;
    }

    public final void a(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f16566a;
        if (recyclerView2 == recyclerView) {
            return;
        }
        n0 n0Var = this.f16567b;
        if (recyclerView2 != null) {
            ArrayList arrayList = recyclerView2.f16678t0;
            if (arrayList != null) {
                arrayList.remove(n0Var);
            }
            this.f16566a.setOnFlingListener(null);
        }
        this.f16566a = recyclerView;
        if (recyclerView != null) {
            if (recyclerView.getOnFlingListener() != null) {
                throw new IllegalStateException("An instance of OnFlingListener already set.");
            }
            this.f16566a.j(n0Var);
            this.f16566a.setOnFlingListener(this);
            new Scroller(this.f16566a.getContext(), new DecelerateInterpolator());
            h();
        }
    }

    public final int[] b(T t10, View view) {
        int[] iArr = new int[2];
        if (t10.e()) {
            iArr[0] = c(view, f(t10));
        } else {
            iArr[0] = 0;
        }
        if (t10.f()) {
            iArr[1] = c(view, g(t10));
            return iArr;
        }
        iArr[1] = 0;
        return iArr;
    }

    public View e(T t10) {
        if (t10.f()) {
            return d(t10, g(t10));
        }
        if (t10.e()) {
            return d(t10, f(t10));
        }
        return null;
    }

    public final I1.g f(T t10) {
        C c10 = this.f16569d;
        if (c10 == null || ((T) c10.f5745b) != t10) {
            this.f16569d = new C(t10);
        }
        return this.f16569d;
    }

    public final I1.g g(T t10) {
        D d10 = this.f16568c;
        if (d10 == null || ((T) d10.f5745b) != t10) {
            this.f16568c = new D(t10);
        }
        return this.f16568c;
    }

    public final void h() {
        T layoutManager;
        View viewE;
        RecyclerView recyclerView = this.f16566a;
        if (recyclerView == null || (layoutManager = recyclerView.getLayoutManager()) == null || (viewE = e(layoutManager)) == null) {
            return;
        }
        int[] iArrB = b(layoutManager, viewE);
        int i10 = iArrB[0];
        if (i10 == 0 && iArrB[1] == 0) {
            return;
        }
        this.f16566a.j0(i10, iArrB[1], false);
    }
}
