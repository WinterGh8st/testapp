package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/* JADX INFO: loaded from: classes.dex */
public class B extends g0 {
    public PointF k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public final DisplayMetrics f16561l;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public float f16563n;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final LinearInterpolator f16559i = new LinearInterpolator();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final DecelerateInterpolator f16560j = new DecelerateInterpolator();

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f16562m = false;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f16564o = 0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f16565p = 0;

    public B(Context context) {
        this.f16561l = context.getResources().getDisplayMetrics();
    }

    public static int e(int i10, int i11, int i12, int i13, int i14) {
        if (i14 == -1) {
            return i12 - i10;
        }
        if (i14 != 0) {
            if (i14 == 1) {
                return i13 - i11;
            }
            throw new IllegalArgumentException("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
        }
        int i15 = i12 - i10;
        if (i15 > 0) {
            return i15;
        }
        int i16 = i13 - i11;
        if (i16 < 0) {
            return i16;
        }
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:10:0x0015  */
    @Override // androidx.recyclerview.widget.g0
    public void c(View view, e0 e0Var) {
        int i10;
        PointF pointF = this.k;
        int i11 = 0;
        if (pointF != null) {
            float f10 = pointF.x;
            if (f10 == 0.0f) {
                i10 = 0;
            } else {
                i10 = f10 > 0.0f ? 1 : -1;
            }
        } else {
            i10 = 0;
        }
        int iF = f(view, i10);
        PointF pointF2 = this.k;
        if (pointF2 != null) {
            float f11 = pointF2.y;
            if (f11 != 0.0f) {
                i11 = f11 > 0.0f ? 1 : -1;
            }
        }
        int iG = g(view, i11);
        int iCeil = (int) Math.ceil(((double) i((int) Math.sqrt((iG * iG) + (iF * iF)))) / 0.3356d);
        if (iCeil > 0) {
            DecelerateInterpolator decelerateInterpolator = this.f16560j;
            e0Var.f16776a = -iF;
            e0Var.f16777b = -iG;
            e0Var.f16778c = iCeil;
            e0Var.f16780e = decelerateInterpolator;
            e0Var.f16781f = true;
        }
    }

    public int f(View view, int i10) {
        T t10 = this.f16796c;
        if (t10 == null || !t10.e()) {
            return 0;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        return e(T.B(view) - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, T.E(view) + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, t10.J(), t10.f16733n - t10.K(), i10);
    }

    public int g(View view, int i10) {
        T t10 = this.f16796c;
        if (t10 == null || !t10.f()) {
            return 0;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        return e(T.F(view) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, T.z(view) + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, t10.L(), t10.f16734o - t10.I(), i10);
    }

    public float h(DisplayMetrics displayMetrics) {
        return 25.0f / displayMetrics.densityDpi;
    }

    public int i(int i10) {
        float fAbs = Math.abs(i10);
        if (!this.f16562m) {
            this.f16563n = h(this.f16561l);
            this.f16562m = true;
        }
        return (int) Math.ceil(fAbs * this.f16563n);
    }
}
