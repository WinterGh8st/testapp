package androidx.recyclerview.widget;

import H9.C0337f;
import L.AbstractC0492c;
import L.C0499e0;
import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p200r1.C1488o;
import p200r1.InterfaceC1487n;
import p232u0.z0;

/* JADX INFO: loaded from: classes.dex */
public class RecyclerView extends ViewGroup implements InterfaceC1487n {

    /* JADX INFO: renamed from: K0, reason: collision with root package name */
    public static boolean f16608K0 = false;

    /* JADX INFO: renamed from: L0, reason: collision with root package name */
    public static boolean f16609L0 = false;

    /* JADX INFO: renamed from: M0, reason: collision with root package name */
    public static final int[] f16610M0 = {R.attr.nestedScrollingEnabled};

    /* JADX INFO: renamed from: N0, reason: collision with root package name */
    public static final float f16611N0 = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final boolean O0 = true;

    /* JADX INFO: renamed from: P0, reason: collision with root package name */
    public static final boolean f16612P0 = true;

    /* JADX INFO: renamed from: Q0, reason: collision with root package name */
    public static final boolean f16613Q0 = true;

    /* JADX INFO: renamed from: R0, reason: collision with root package name */
    public static final Class[] f16614R0;

    /* JADX INFO: renamed from: S0, reason: collision with root package name */
    public static final E1.d f16615S0;

    /* JADX INFO: renamed from: T0, reason: collision with root package name */
    public static final i0 f16616T0;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final ArrayList f16617A;

    /* JADX INFO: renamed from: A0, reason: collision with root package name */
    public C1488o f16618A0;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public W f16619B;

    /* JADX INFO: renamed from: B0, reason: collision with root package name */
    public final int[] f16620B0;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f16621C;

    /* JADX INFO: renamed from: C0, reason: collision with root package name */
    public final int[] f16622C0;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f16623D;

    /* JADX INFO: renamed from: D0, reason: collision with root package name */
    public final int[] f16624D0;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f16625E;

    /* JADX INFO: renamed from: E0, reason: collision with root package name */
    public final ArrayList f16626E0;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f16627F;

    /* JADX INFO: renamed from: F0, reason: collision with root package name */
    public final F f16628F0;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f16629G;

    /* JADX INFO: renamed from: G0, reason: collision with root package name */
    public boolean f16630G0;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public boolean f16631H;

    /* JADX INFO: renamed from: H0, reason: collision with root package name */
    public int f16632H0;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f16633I;

    /* JADX INFO: renamed from: I0, reason: collision with root package name */
    public int f16634I0;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int f16635J;

    /* JADX INFO: renamed from: J0, reason: collision with root package name */
    public final G f16636J0;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public boolean f16637K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final AccessibilityManager f16638L;
    public ArrayList M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public boolean f16639N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public boolean f16640O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public int f16641P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public int f16642Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public M f16643R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public EdgeEffect f16644S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public EdgeEffect f16645T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public EdgeEffect f16646U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public EdgeEffect f16647V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public N f16648W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f16649a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public int f16650a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c0 f16651b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public int f16652b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final a0 f16653c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public VelocityTracker f16654c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public d0 f16655d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public int f16656d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final B.P f16657e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public int f16658e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Ka.A f16659f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public int f16660f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public int f16661g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public int f16662h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public V f16663i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public final int f16664j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public final int f16665k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public final float f16666l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public final float f16667m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public boolean f16668n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public final k0 f16669o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public RunnableC0840o f16670p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final O2.k f16671q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public final Db.m f16672q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f16673r;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final h0 f16674r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final F f16675s;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public X f16676s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Rect f16677t;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public ArrayList f16678t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Rect f16679u;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public boolean f16680u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final RectF f16681v;
    public boolean v0;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public I f16682w;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public final G f16683w0;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public T f16684x;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public boolean f16685x0;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final ArrayList f16686y;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public m0 f16687y0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final ArrayList f16688z;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public final int[] f16689z0;

    static {
        Class cls = Integer.TYPE;
        f16614R0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        f16615S0 = new E1.d(3);
        f16616T0 = new i0();
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.flamingotools.ws.R.attr.recyclerViewStyle);
    }

    public static RecyclerView H(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            RecyclerView recyclerViewH = H(viewGroup.getChildAt(i10));
            if (recyclerViewH != null) {
                return recyclerViewH;
            }
        }
        return null;
    }

    public static l0 M(View view) {
        if (view == null) {
            return null;
        }
        return ((LayoutParams) view.getLayoutParams()).f16690a;
    }

    private C1488o getScrollingChildHelper() {
        if (this.f16618A0 == null) {
            this.f16618A0 = new C1488o(this);
        }
        return this.f16618A0;
    }

    public static void l(l0 l0Var) {
        WeakReference<RecyclerView> weakReference = l0Var.mNestedRecyclerView;
        if (weakReference != null) {
            RecyclerView recyclerView = weakReference.get();
            while (recyclerView != null) {
                if (recyclerView == l0Var.itemView) {
                    return;
                }
                Object parent = recyclerView.getParent();
                recyclerView = parent instanceof View ? (View) parent : null;
            }
            l0Var.mNestedRecyclerView = null;
        }
    }

    public static int o(int i10, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i11) {
        if (i10 > 0 && edgeEffect != null && p197qa.h.j(edgeEffect) != 0.0f) {
            int iRound = Math.round(p197qa.h.m(edgeEffect, ((-i10) * 4.0f) / i11, 0.5f) * ((-i11) / 4.0f));
            if (iRound != i10) {
                edgeEffect.finish();
            }
            return i10 - iRound;
        }
        if (i10 >= 0 || edgeEffect2 == null || p197qa.h.j(edgeEffect2) == 0.0f) {
            return i10;
        }
        float f10 = i11;
        int iRound2 = Math.round(p197qa.h.m(edgeEffect2, (i10 * 4.0f) / f10, 0.5f) * (f10 / 4.0f));
        if (iRound2 != i10) {
            edgeEffect2.finish();
        }
        return i10 - iRound2;
    }

    public static void setDebugAssertionsEnabled(boolean z3) {
        f16608K0 = z3;
    }

    public static void setVerboseLoggingEnabled(boolean z3) {
        f16609L0 = z3;
    }

    public final void A() {
        if (this.f16646U != null) {
            return;
        }
        ((i0) this.f16643R).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f16646U = edgeEffect;
        if (this.f16673r) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    public final void B() {
        if (this.f16645T != null) {
            return;
        }
        ((i0) this.f16643R).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f16645T = edgeEffect;
        if (this.f16673r) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final String C() {
        return " " + super.toString() + ", adapter:" + this.f16682w + ", layout:" + this.f16684x + ", context:" + getContext();
    }

    public final void D(h0 h0Var) {
        if (getScrollState() != 2) {
            h0Var.getClass();
            return;
        }
        OverScroller overScroller = this.f16669o0.f16835c;
        overScroller.getFinalX();
        overScroller.getCurrX();
        h0Var.getClass();
        overScroller.getFinalY();
        overScroller.getCurrY();
    }

    public final View E(View view) {
        ViewParent parent = view.getParent();
        while (parent != null && parent != this && (parent instanceof View)) {
            view = parent;
            parent = view.getParent();
        }
        if (parent == this) {
            return view;
        }
        return null;
    }

    public final boolean F(MotionEvent motionEvent) {
        int action = motionEvent.getAction();
        ArrayList arrayList = this.f16617A;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            W w9 = (W) arrayList.get(i10);
            if (w9.c(motionEvent) && action != 3) {
                this.f16619B = w9;
                return true;
            }
        }
        return false;
    }

    public final void G(int[] iArr) {
        int iD = this.f16659f.D();
        if (iD == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i10 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        int i11 = Integer.MIN_VALUE;
        for (int i12 = 0; i12 < iD; i12++) {
            l0 l0VarM = M(this.f16659f.C(i12));
            if (!l0VarM.shouldIgnore()) {
                int layoutPosition = l0VarM.getLayoutPosition();
                if (layoutPosition < i10) {
                    i10 = layoutPosition;
                }
                if (layoutPosition > i11) {
                    i11 = layoutPosition;
                }
            }
        }
        iArr[0] = i10;
        iArr[1] = i11;
    }

    public final l0 I(int i10) {
        l0 l0Var = null;
        if (this.f16639N) {
            return null;
        }
        int iH = this.f16659f.H();
        for (int i11 = 0; i11 < iH; i11++) {
            l0 l0VarM = M(this.f16659f.G(i11));
            if (l0VarM != null && !l0VarM.isRemoved() && J(l0VarM) == i10) {
                Ka.A a3 = this.f16659f;
                if (!((ArrayList) a3.f7158e).contains(l0VarM.itemView)) {
                    return l0VarM;
                }
                l0Var = l0VarM;
            }
        }
        return l0Var;
    }

    public final int J(l0 l0Var) {
        if (l0Var.hasAnyOfTheFlags(524) || !l0Var.isBound()) {
            return -1;
        }
        B.P p10 = this.f16657e;
        int i10 = l0Var.mPosition;
        ArrayList arrayList = (ArrayList) p10.f537c;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            C0826a c0826a = (C0826a) arrayList.get(i11);
            int i12 = c0826a.f16742a;
            if (i12 != 1) {
                if (i12 == 2) {
                    int i13 = c0826a.f16743b;
                    if (i13 <= i10) {
                        int i14 = c0826a.f16745d;
                        if (i13 + i14 > i10) {
                            return -1;
                        }
                        i10 -= i14;
                    } else {
                        continue;
                    }
                } else if (i12 == 8) {
                    int i15 = c0826a.f16743b;
                    if (i15 == i10) {
                        i10 = c0826a.f16745d;
                    } else {
                        if (i15 < i10) {
                            i10--;
                        }
                        if (c0826a.f16745d <= i10) {
                            i10++;
                        }
                    }
                }
            } else if (c0826a.f16743b <= i10) {
                i10 += c0826a.f16745d;
            }
        }
        return i10;
    }

    public final long K(l0 l0Var) {
        return this.f16682w.hasStableIds() ? l0Var.getItemId() : l0Var.mPosition;
    }

    public final l0 L(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return M(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public final Rect N(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        boolean z3 = layoutParams.f16692c;
        Rect rect = layoutParams.f16691b;
        if (!z3 || (this.f16674r0.f16820g && (layoutParams.f16690a.isUpdated() || layoutParams.f16690a.isInvalid()))) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.f16688z;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            Rect rect2 = this.f16677t;
            rect2.set(0, 0, 0, 0);
            ((O) arrayList.get(i10)).f(rect2, view, this);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        layoutParams.f16692c = false;
        return rect;
    }

    public final boolean O() {
        return !this.f16625E || this.f16639N || this.f16657e.n();
    }

    public final boolean P() {
        return this.f16641P > 0;
    }

    public final void Q(int i10) {
        if (this.f16684x == null) {
            return;
        }
        setScrollState(2);
        this.f16684x.v0(i10);
        awakenScrollBars();
    }

    public final void R() {
        int iH = this.f16659f.H();
        for (int i10 = 0; i10 < iH; i10++) {
            ((LayoutParams) this.f16659f.G(i10).getLayoutParams()).f16692c = true;
        }
        ArrayList arrayList = this.f16653c.f16748c;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            LayoutParams layoutParams = (LayoutParams) ((l0) arrayList.get(i11)).itemView.getLayoutParams();
            if (layoutParams != null) {
                layoutParams.f16692c = true;
            }
        }
    }

    public final void S(int i10, int i11, boolean z3) {
        int i12 = i10 + i11;
        int iH = this.f16659f.H();
        for (int i13 = 0; i13 < iH; i13++) {
            l0 l0VarM = M(this.f16659f.G(i13));
            if (l0VarM != null && !l0VarM.shouldIgnore()) {
                int i14 = l0VarM.mPosition;
                h0 h0Var = this.f16674r0;
                if (i14 >= i12) {
                    if (f16609L0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i13 + " holder " + l0VarM + " now at position " + (l0VarM.mPosition - i11));
                    }
                    l0VarM.offsetPosition(-i11, z3);
                    h0Var.f16819f = true;
                } else if (i14 >= i10) {
                    if (f16609L0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i13 + " holder " + l0VarM + " now REMOVED");
                    }
                    l0VarM.flagRemovedAndOffsetPosition(i10 - 1, -i11, z3);
                    h0Var.f16819f = true;
                }
            }
        }
        a0 a0Var = this.f16653c;
        ArrayList arrayList = a0Var.f16748c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            l0 l0Var = (l0) arrayList.get(size);
            if (l0Var != null) {
                int i15 = l0Var.mPosition;
                if (i15 >= i12) {
                    if (f16609L0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove cached " + size + " holder " + l0Var + " now at position " + (l0Var.mPosition - i11));
                    }
                    l0Var.offsetPosition(-i11, z3);
                } else if (i15 >= i10) {
                    l0Var.addFlags(8);
                    a0Var.g(size);
                }
            }
        }
        requestLayout();
    }

    public final void T() {
        this.f16641P++;
    }

    public final void U(boolean z3) {
        int i10;
        AccessibilityManager accessibilityManager;
        int i11 = this.f16641P - 1;
        this.f16641P = i11;
        if (i11 < 1) {
            if (f16608K0 && i11 < 0) {
                throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("layout or scroll counter cannot go below zero.Some calls are not matching")));
            }
            this.f16641P = 0;
            if (z3) {
                int i12 = this.f16635J;
                this.f16635J = 0;
                if (i12 != 0 && (accessibilityManager = this.f16638L) != null && accessibilityManager.isEnabled()) {
                    AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                    accessibilityEventObtain.setEventType(2048);
                    accessibilityEventObtain.setContentChangeTypes(i12);
                    sendAccessibilityEventUnchecked(accessibilityEventObtain);
                }
                ArrayList arrayList = this.f16626E0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    l0 l0Var = (l0) arrayList.get(size);
                    if (l0Var.itemView.getParent() == this && !l0Var.shouldIgnore() && (i10 = l0Var.mPendingAccessibilityState) != -1) {
                        View view = l0Var.itemView;
                        WeakHashMap weakHashMap = p200r1.U.f27683a;
                        view.setImportantForAccessibility(i10);
                        l0Var.mPendingAccessibilityState = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    public final void V(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f16652b0) {
            int i10 = actionIndex == 0 ? 1 : 0;
            this.f16652b0 = motionEvent.getPointerId(i10);
            int x10 = (int) (motionEvent.getX(i10) + 0.5f);
            this.f16660f0 = x10;
            this.f16656d0 = x10;
            int y10 = (int) (motionEvent.getY(i10) + 0.5f);
            this.f16661g0 = y10;
            this.f16658e0 = y10;
        }
    }

    public final void W() {
        if (this.f16685x0 || !this.f16621C) {
            return;
        }
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        postOnAnimation(this.f16628F0);
        this.f16685x0 = true;
    }

    public final void X() {
        boolean z3;
        boolean z5 = false;
        if (this.f16639N) {
            B.P p10 = this.f16657e;
            p10.x((ArrayList) p10.f537c);
            p10.x((ArrayList) p10.f538d);
            p10.f535a = 0;
            if (this.f16640O) {
                this.f16684x.e0();
            }
        }
        if (this.f16648W == null || !this.f16684x.H0()) {
            this.f16657e.d();
        } else {
            this.f16657e.w();
        }
        boolean z10 = this.f16680u0 || this.v0;
        boolean z11 = this.f16625E && this.f16648W != null && ((z3 = this.f16639N) || z10 || this.f16684x.f16726f) && (!z3 || this.f16682w.hasStableIds());
        h0 h0Var = this.f16674r0;
        h0Var.f16823j = z11;
        if (z11 && z10 && !this.f16639N && this.f16648W != null && this.f16684x.H0()) {
            z5 = true;
        }
        h0Var.k = z5;
    }

    public final void Y(boolean z3) {
        this.f16640O = z3 | this.f16640O;
        this.f16639N = true;
        int iH = this.f16659f.H();
        for (int i10 = 0; i10 < iH; i10++) {
            l0 l0VarM = M(this.f16659f.G(i10));
            if (l0VarM != null && !l0VarM.shouldIgnore()) {
                l0VarM.addFlags(6);
            }
        }
        R();
        a0 a0Var = this.f16653c;
        ArrayList arrayList = a0Var.f16748c;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            l0 l0Var = (l0) arrayList.get(i11);
            if (l0Var != null) {
                l0Var.addFlags(6);
                l0Var.addChangePayload(null);
            }
        }
        I i12 = a0Var.f16753h.f16682w;
        if (i12 == null || !i12.hasStableIds()) {
            a0Var.f();
        }
    }

    public final void Z(l0 l0Var, C0499e0 c0499e0) {
        l0Var.setFlags(0, 8192);
        boolean z3 = this.f16674r0.f16821h;
        O2.k kVar = this.f16671q;
        if (z3 && l0Var.isUpdated() && !l0Var.isRemoved() && !l0Var.shouldIgnore()) {
            ((p240v.e) kVar.f9773c).d(l0Var, K(l0Var));
        }
        p240v.k kVar2 = (p240v.k) kVar.f9772b;
        v0 v0VarA = (v0) kVar2.getOrDefault(l0Var, null);
        if (v0VarA == null) {
            v0VarA = v0.a();
            kVar2.put(l0Var, v0VarA);
        }
        v0VarA.f16967b = c0499e0;
        v0VarA.f16966a |= 4;
    }

    public final int a0(int i10, float f10) {
        float height = f10 / getHeight();
        float width = i10 / getWidth();
        EdgeEffect edgeEffect = this.f16644S;
        float f11 = 0.0f;
        if (edgeEffect == null || p197qa.h.j(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.f16646U;
            if (edgeEffect2 != null && p197qa.h.j(edgeEffect2) != 0.0f) {
                if (canScrollHorizontally(1)) {
                    this.f16646U.onRelease();
                } else {
                    float fM = p197qa.h.m(this.f16646U, width, height);
                    if (p197qa.h.j(this.f16646U) == 0.0f) {
                        this.f16646U.onRelease();
                    }
                    f11 = fM;
                }
                invalidate();
            }
        } else {
            if (canScrollHorizontally(-1)) {
                this.f16644S.onRelease();
            } else {
                float f12 = -p197qa.h.m(this.f16644S, -width, 1.0f - height);
                if (p197qa.h.j(this.f16644S) == 0.0f) {
                    this.f16644S.onRelease();
                }
                f11 = f12;
            }
            invalidate();
        }
        return Math.round(f11 * getWidth());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i10, int i11) {
        T t10 = this.f16684x;
        if (t10 != null) {
            t10.getClass();
        }
        super.addFocusables(arrayList, i10, i11);
    }

    public final int b0(int i10, float f10) {
        float width = f10 / getWidth();
        float height = i10 / getHeight();
        EdgeEffect edgeEffect = this.f16645T;
        float f11 = 0.0f;
        if (edgeEffect == null || p197qa.h.j(edgeEffect) == 0.0f) {
            EdgeEffect edgeEffect2 = this.f16647V;
            if (edgeEffect2 != null && p197qa.h.j(edgeEffect2) != 0.0f) {
                if (canScrollVertically(1)) {
                    this.f16647V.onRelease();
                } else {
                    float fM = p197qa.h.m(this.f16647V, height, 1.0f - width);
                    if (p197qa.h.j(this.f16647V) == 0.0f) {
                        this.f16647V.onRelease();
                    }
                    f11 = fM;
                }
                invalidate();
            }
        } else {
            if (canScrollVertically(-1)) {
                this.f16645T.onRelease();
            } else {
                float f12 = -p197qa.h.m(this.f16645T, -height, width);
                if (p197qa.h.j(this.f16645T) == 0.0f) {
                    this.f16645T.onRelease();
                }
                f11 = f12;
            }
            invalidate();
        }
        return Math.round(f11 * getHeight());
    }

    public final void c0(O o4) {
        T t10 = this.f16684x;
        if (t10 != null) {
            t10.c("Cannot remove item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f16688z;
        arrayList.remove(o4);
        if (arrayList.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        R();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && this.f16684x.g((LayoutParams) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        T t10 = this.f16684x;
        if (t10 != null && t10.e()) {
            return this.f16684x.k(this.f16674r0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        T t10 = this.f16684x;
        if (t10 != null && t10.e()) {
            return this.f16684x.l(this.f16674r0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        T t10 = this.f16684x;
        if (t10 != null && t10.e()) {
            return this.f16684x.m(this.f16674r0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        T t10 = this.f16684x;
        if (t10 != null && t10.f()) {
            return this.f16684x.n(this.f16674r0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        T t10 = this.f16684x;
        if (t10 != null && t10.f()) {
            return this.f16684x.o(this.f16674r0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        T t10 = this.f16684x;
        if (t10 != null && t10.f()) {
            return this.f16684x.p(this.f16674r0);
        }
        return 0;
    }

    public final void d0(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f16677t;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            if (!layoutParams2.f16692c) {
                int i10 = rect.left;
                Rect rect2 = layoutParams2.f16691b;
                rect.left = i10 - rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f16684x.s0(this, view, this.f16677t, !this.f16625E, view2 == null);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f10, float f11, boolean z3) {
        return getScrollingChildHelper().a(f10, f11, z3);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f10, float f11) {
        return getScrollingChildHelper().b(f10, f11);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i10, int i11, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i10, i11, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i10, int i11, int i12, int i13, int[] iArr) {
        return getScrollingChildHelper().d(i10, i11, i12, i13, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z3;
        super.draw(canvas);
        ArrayList arrayList = this.f16688z;
        int size = arrayList.size();
        boolean z5 = false;
        for (int i10 = 0; i10 < size; i10++) {
            ((O) arrayList.get(i10)).h(canvas, this);
        }
        EdgeEffect edgeEffect = this.f16644S;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z3 = false;
        } else {
            int iSave = canvas.save();
            int paddingBottom = this.f16673r ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.f16644S;
            z3 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect3 = this.f16645T;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int iSave2 = canvas.save();
            if (this.f16673r) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.f16645T;
            z3 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(iSave2);
        }
        EdgeEffect edgeEffect5 = this.f16646U;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int iSave3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f16673r ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.f16646U;
            z3 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(iSave3);
        }
        EdgeEffect edgeEffect7 = this.f16647V;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int iSave4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f16673r) {
                canvas.translate(getPaddingRight() + (-getWidth()), getPaddingBottom() + (-getHeight()));
            } else {
                canvas.translate(-getWidth(), -getHeight());
            }
            EdgeEffect edgeEffect8 = this.f16647V;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z5 = true;
            }
            z3 |= z5;
            canvas.restoreToCount(iSave4);
        }
        if ((z3 || this.f16648W == null || arrayList.size() <= 0 || !this.f16648W.f()) ? z3 : true) {
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        return super.drawChild(canvas, view, j10);
    }

    public final void e0() {
        VelocityTracker velocityTracker = this.f16654c0;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean zIsFinished = false;
        n0(0);
        EdgeEffect edgeEffect = this.f16644S;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            zIsFinished = this.f16644S.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f16645T;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            zIsFinished |= this.f16645T.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f16646U;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            zIsFinished |= this.f16646U.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f16647V;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            zIsFinished |= this.f16647V.isFinished();
        }
        if (zIsFinished) {
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            postInvalidateOnAnimation();
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:33:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:35:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:36:0x00fc A[DONT_INVERT, PHI: r7
  0x00fc: PHI (r7v10 boolean) = (r7v8 boolean), (r7v11 boolean) binds: [B:34:0x00e3, B:32:0x00de] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:37:0x00fe  */
    /* JADX WARN: Code duplicated, block: B:41:0x0106  */
    public final boolean f0(int i10, int i11, MotionEvent motionEvent, int i12) {
        int i13;
        int i14;
        int i15;
        int i16;
        boolean z3;
        boolean z5;
        p();
        I i17 = this.f16682w;
        int[] iArr = this.f16624D0;
        if (i17 != null) {
            iArr[0] = 0;
            iArr[1] = 0;
            g0(i10, i11, iArr);
            i13 = iArr[0];
            i14 = iArr[1];
            i15 = i10 - i13;
            i16 = i11 - i14;
        } else {
            i13 = 0;
            i14 = 0;
            i15 = 0;
            i16 = 0;
        }
        if (!this.f16688z.isEmpty()) {
            invalidate();
        }
        iArr[0] = 0;
        iArr[1] = 0;
        w(i13, i14, i15, i16, this.f16620B0, i12, iArr);
        int i18 = iArr[0];
        int i19 = i15 - i18;
        int i20 = iArr[1];
        int i21 = i16 - i20;
        boolean z10 = (i18 == 0 && i20 == 0) ? false : true;
        int i22 = this.f16660f0;
        int[] iArr2 = this.f16620B0;
        int i23 = iArr2[0];
        this.f16660f0 = i22 - i23;
        int i24 = this.f16661g0;
        int i25 = iArr2[1];
        this.f16661g0 = i24 - i25;
        int[] iArr3 = this.f16622C0;
        iArr3[0] = iArr3[0] + i23;
        iArr3[1] = iArr3[1] + i25;
        if (getOverScrollMode() != 2) {
            if (motionEvent == null || (motionEvent.getSource() & 8194) == 8194) {
                z3 = true;
            } else {
                float x10 = motionEvent.getX();
                float f10 = i19;
                float y10 = motionEvent.getY();
                float f11 = i21;
                if (f10 < 0.0f) {
                    z();
                    z3 = true;
                    p197qa.h.m(this.f16644S, (-f10) / getWidth(), 1.0f - (y10 / getHeight()));
                } else {
                    z3 = true;
                    if (f10 > 0.0f) {
                        A();
                        p197qa.h.m(this.f16646U, f10 / getWidth(), y10 / getHeight());
                    } else {
                        z5 = false;
                    }
                    if (f11 < 0.0f) {
                        B();
                        p197qa.h.m(this.f16645T, (-f11) / getHeight(), x10 / getWidth());
                    } else if (f11 > 0.0f) {
                        y();
                        p197qa.h.m(this.f16647V, f11 / getHeight(), 1.0f - (x10 / getWidth()));
                    } else if (z5 || f10 != 0.0f || f11 != 0.0f) {
                        WeakHashMap weakHashMap = p200r1.U.f27683a;
                        postInvalidateOnAnimation();
                    }
                    z5 = z3;
                    if (z5) {
                        WeakHashMap weakHashMap2 = p200r1.U.f27683a;
                        postInvalidateOnAnimation();
                    } else {
                        WeakHashMap weakHashMap3 = p200r1.U.f27683a;
                        postInvalidateOnAnimation();
                    }
                }
                z5 = z3;
                if (f11 < 0.0f) {
                    B();
                    p197qa.h.m(this.f16645T, (-f11) / getHeight(), x10 / getWidth());
                } else if (f11 > 0.0f) {
                    y();
                    p197qa.h.m(this.f16647V, f11 / getHeight(), 1.0f - (x10 / getWidth()));
                } else if (z5) {
                    WeakHashMap weakHashMap4 = p200r1.U.f27683a;
                    postInvalidateOnAnimation();
                } else {
                    WeakHashMap weakHashMap5 = p200r1.U.f27683a;
                    postInvalidateOnAnimation();
                }
                z5 = z3;
                if (z5) {
                    WeakHashMap weakHashMap6 = p200r1.U.f27683a;
                    postInvalidateOnAnimation();
                } else {
                    WeakHashMap weakHashMap7 = p200r1.U.f27683a;
                    postInvalidateOnAnimation();
                }
            }
            n(i10, i11);
        } else {
            z3 = true;
        }
        if (i13 != 0 || i14 != 0) {
            x(i13, i14);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (!z10 && i13 == 0 && i14 == 0) {
            return false;
        }
        return z3;
    }

    /* JADX WARN: Code duplicated, block: B:118:0x0163  */
    /* JADX WARN: Code duplicated, block: B:137:0x0193 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:138:0x0194  */
    /* JADX WARN: Code duplicated, block: B:24:0x004c  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    public final View focusSearch(View view, int i10) {
        View viewY;
        int i11;
        byte b10;
        boolean z3;
        this.f16684x.getClass();
        boolean z5 = true;
        boolean z10 = (this.f16682w == null || this.f16684x == null || P() || this.f16631H) ? false : true;
        FocusFinder focusFinder = FocusFinder.getInstance();
        h0 h0Var = this.f16674r0;
        a0 a0Var = this.f16653c;
        if (z10 && (i10 == 2 || i10 == 1)) {
            if (this.f16684x.f()) {
                if (focusFinder.findNextFocus(this, view, i10 == 2 ? 130 : 33) == null) {
                    z3 = true;
                } else {
                    z3 = false;
                }
            } else {
                z3 = false;
            }
            if (!z3 && this.f16684x.e()) {
                z3 = focusFinder.findNextFocus(this, view, (this.f16684x.H() == 1) ^ (i10 == 2) ? 66 : 17) == null;
            }
            if (z3) {
                p();
                if (E(view) != null) {
                    l0();
                    this.f16684x.Y(view, i10, a0Var, h0Var);
                    m0(false);
                }
                return null;
            }
            viewY = focusFinder.findNextFocus(this, view, i10);
            if (viewY == null) {
            }
            if (viewY != null) {
                z5 = false;
            } else {
                z5 = false;
            }
            if (z5) {
                return viewY;
            }
            return super.focusSearch(view, i10);
        }
        View viewFindNextFocus = focusFinder.findNextFocus(this, view, i10);
        if (viewFindNextFocus == null && z10) {
            p();
            if (E(view) != null) {
                l0();
                viewY = this.f16684x.Y(view, i10, a0Var, h0Var);
                m0(false);
            }
            return null;
        }
        viewY = viewFindNextFocus;
        if (viewY == null && !viewY.hasFocusable()) {
            if (getFocusedChild() == null) {
                return super.focusSearch(view, i10);
            }
            d0(viewY, null);
            return view;
        }
        if (viewY != null || viewY == this || viewY == view) {
            z5 = false;
        } else if (E(viewY) == null) {
            z5 = false;
        } else if (view != null && E(view) != null) {
            int width = view.getWidth();
            int height = view.getHeight();
            Rect rect = this.f16677t;
            rect.set(0, 0, width, height);
            int width2 = viewY.getWidth();
            int height2 = viewY.getHeight();
            Rect rect2 = this.f16679u;
            rect2.set(0, 0, width2, height2);
            offsetDescendantRectToMyCoords(view, rect);
            offsetDescendantRectToMyCoords(viewY, rect2);
            int i12 = this.f16684x.H() == 1 ? -1 : 1;
            int i13 = rect.left;
            int i14 = rect2.left;
            if ((i13 < i14 || rect.right <= i14) && rect.right < rect2.right) {
                i11 = 1;
            } else {
                int i15 = rect.right;
                int i16 = rect2.right;
                i11 = ((i15 > i16 || i13 >= i16) && i13 > i14) ? -1 : 0;
            }
            int i17 = rect.top;
            int i18 = rect2.top;
            if ((i17 < i18 || rect.bottom <= i18) && rect.bottom < rect2.bottom) {
                b10 = 1;
            } else {
                int i19 = rect.bottom;
                int i20 = rect2.bottom;
                b10 = ((i19 > i20 || i17 >= i20) && i17 > i18) ? (byte) -1 : (byte) 0;
            }
            if (i10 != 1) {
                if (i10 != 2) {
                    if (i10 != 17) {
                        if (i10 != 33) {
                            if (i10 != 66) {
                                if (i10 != 130) {
                                    StringBuilder sb2 = new StringBuilder("Invalid direction: ");
                                    sb2.append(i10);
                                    throw new IllegalArgumentException(AbstractC0492c.i(this, sb2));
                                }
                                if (b10 <= 0) {
                                    z5 = false;
                                }
                            } else if (i11 <= 0) {
                                z5 = false;
                            }
                        } else if (b10 >= 0) {
                            z5 = false;
                        }
                    } else if (i11 >= 0) {
                        z5 = false;
                    }
                } else if (b10 <= 0 && (b10 != 0 || i11 * i12 <= 0)) {
                    z5 = false;
                }
            } else if (b10 >= 0 && (b10 != 0 || i11 * i12 >= 0)) {
                z5 = false;
            }
        }
        if (z5) {
            return viewY;
        }
        return super.focusSearch(view, i10);
    }

    public final void g0(int i10, int i11, int[] iArr) {
        l0 l0Var;
        Ka.A a3 = this.f16659f;
        l0();
        T();
        int i12 = p144m1.l.f24833a;
        Trace.beginSection("RV Scroll");
        h0 h0Var = this.f16674r0;
        D(h0Var);
        a0 a0Var = this.f16653c;
        int iU0 = i10 != 0 ? this.f16684x.u0(i10, a0Var, h0Var) : 0;
        int iW0 = i11 != 0 ? this.f16684x.w0(i11, a0Var, h0Var) : 0;
        Trace.endSection();
        int iD = a3.D();
        for (int i13 = 0; i13 < iD; i13++) {
            View viewC = a3.C(i13);
            l0 l0VarL = L(viewC);
            if (l0VarL != null && (l0Var = l0VarL.mShadowingHolder) != null) {
                View view = l0Var.itemView;
                int left = viewC.getLeft();
                int top = viewC.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        U(true);
        m0(false);
        if (iArr != null) {
            iArr[0] = iU0;
            iArr[1] = iW0;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        T t10 = this.f16684x;
        if (t10 != null) {
            return t10.s();
        }
        throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        T t10 = this.f16684x;
        if (t10 != null) {
            return t10.t(getContext(), attributeSet);
        }
        throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public I getAdapter() {
        return this.f16682w;
    }

    @Override // android.view.View
    public int getBaseline() {
        T t10 = this.f16684x;
        if (t10 == null) {
            return super.getBaseline();
        }
        t10.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i10, int i11) {
        return super.getChildDrawingOrder(i10, i11);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f16673r;
    }

    public m0 getCompatAccessibilityDelegate() {
        return this.f16687y0;
    }

    public M getEdgeEffectFactory() {
        return this.f16643R;
    }

    public N getItemAnimator() {
        return this.f16648W;
    }

    public int getItemDecorationCount() {
        return this.f16688z.size();
    }

    public T getLayoutManager() {
        return this.f16684x;
    }

    public int getMaxFlingVelocity() {
        return this.f16665k0;
    }

    public int getMinFlingVelocity() {
        return this.f16664j0;
    }

    public long getNanoTime() {
        if (f16613Q0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public V getOnFlingListener() {
        return this.f16663i0;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f16668n0;
    }

    public Z getRecycledViewPool() {
        return this.f16653c.c();
    }

    public int getScrollState() {
        return this.f16650a0;
    }

    public final void h(l0 l0Var) {
        View view = l0Var.itemView;
        boolean z3 = view.getParent() == this;
        this.f16653c.l(L(view));
        if (l0Var.isTmpDetached()) {
            this.f16659f.k(view, -1, view.getLayoutParams(), true);
            return;
        }
        if (!z3) {
            this.f16659f.e(view, -1, true);
            return;
        }
        Ka.A a3 = this.f16659f;
        int iIndexOfChild = ((RecyclerView) ((G) a3.f7156c).f16572a).indexOfChild(view);
        if (iIndexOfChild >= 0) {
            ((C0337f) a3.f7157d).j(iIndexOfChild);
            a3.J(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public final void h0(int i10) {
        B b10;
        if (this.f16631H) {
            return;
        }
        setScrollState(0);
        k0 k0Var = this.f16669o0;
        k0Var.f16839q.removeCallbacks(k0Var);
        k0Var.f16835c.abortAnimation();
        T t10 = this.f16684x;
        if (t10 != null && (b10 = t10.f16725e) != null) {
            b10.d();
        }
        T t11 = this.f16684x;
        if (t11 == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            t11.v0(i10);
            awakenScrollBars();
        }
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().f(0);
    }

    public final void i(O o4) {
        T t10 = this.f16684x;
        if (t10 != null) {
            t10.c("Cannot add item decoration during a scroll  or layout");
        }
        ArrayList arrayList = this.f16688z;
        if (arrayList.isEmpty()) {
            setWillNotDraw(false);
        }
        arrayList.add(o4);
        R();
        requestLayout();
    }

    public final boolean i0(EdgeEffect edgeEffect, int i10, int i11) {
        if (i10 > 0) {
            return true;
        }
        float fJ = p197qa.h.j(edgeEffect) * i11;
        float fAbs = Math.abs(-i10) * 0.35f;
        float f10 = this.f16649a * 0.015f;
        double dLog = Math.log(fAbs / f10);
        double d10 = f16611N0;
        return ((float) (Math.exp((d10 / (d10 - 1.0d)) * dLog) * ((double) f10))) < fJ;
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f16621C;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f16631H;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f27746d;
    }

    public final void j(X x10) {
        if (this.f16678t0 == null) {
            this.f16678t0 = new ArrayList();
        }
        this.f16678t0.add(x10);
    }

    public final void j0(int i10, int i11, boolean z3) {
        T t10 = this.f16684x;
        if (t10 == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f16631H) {
            return;
        }
        if (!t10.e()) {
            i10 = 0;
        }
        if (!this.f16684x.f()) {
            i11 = 0;
        }
        if (i10 == 0 && i11 == 0) {
            return;
        }
        if (z3) {
            int i12 = i10 != 0 ? 1 : 0;
            if (i11 != 0) {
                i12 |= 2;
            }
            getScrollingChildHelper().g(i12, 1);
        }
        this.f16669o0.c(i10, i11, Integer.MIN_VALUE, null);
    }

    public final void k(String str) {
        if (P()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("Cannot call this method while RecyclerView is computing a layout or scrolling")));
        }
        if (this.f16642Q > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(AbstractC0492c.i(this, new StringBuilder(""))));
        }
    }

    public final void k0(int i10) {
        if (this.f16631H) {
            return;
        }
        T t10 = this.f16684x;
        if (t10 == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            t10.F0(this, i10);
        }
    }

    public final void l0() {
        int i10 = this.f16627F + 1;
        this.f16627F = i10;
        if (i10 != 1 || this.f16631H) {
            return;
        }
        this.f16629G = false;
    }

    public final void m() {
        int iH = this.f16659f.H();
        for (int i10 = 0; i10 < iH; i10++) {
            l0 l0VarM = M(this.f16659f.G(i10));
            if (!l0VarM.shouldIgnore()) {
                l0VarM.clearOldPosition();
            }
        }
        a0 a0Var = this.f16653c;
        ArrayList arrayList = a0Var.f16748c;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            ((l0) arrayList.get(i11)).clearOldPosition();
        }
        ArrayList arrayList2 = a0Var.f16746a;
        int size2 = arrayList2.size();
        for (int i12 = 0; i12 < size2; i12++) {
            ((l0) arrayList2.get(i12)).clearOldPosition();
        }
        ArrayList arrayList3 = a0Var.f16747b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i13 = 0; i13 < size3; i13++) {
                ((l0) a0Var.f16747b.get(i13)).clearOldPosition();
            }
        }
    }

    public final void m0(boolean z3) {
        if (this.f16627F < 1) {
            if (f16608K0) {
                throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("stopInterceptRequestLayout was called more times than startInterceptRequestLayout.")));
            }
            this.f16627F = 1;
        }
        if (!z3 && !this.f16631H) {
            this.f16629G = false;
        }
        if (this.f16627F == 1) {
            if (z3 && this.f16629G && !this.f16631H && this.f16684x != null && this.f16682w != null) {
                s();
            }
            if (!this.f16631H) {
                this.f16629G = false;
            }
        }
        this.f16627F--;
    }

    public final void n(int i10, int i11) {
        boolean zIsFinished;
        EdgeEffect edgeEffect = this.f16644S;
        if (edgeEffect == null || edgeEffect.isFinished() || i10 <= 0) {
            zIsFinished = false;
        } else {
            this.f16644S.onRelease();
            zIsFinished = this.f16644S.isFinished();
        }
        EdgeEffect edgeEffect2 = this.f16646U;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i10 < 0) {
            this.f16646U.onRelease();
            zIsFinished |= this.f16646U.isFinished();
        }
        EdgeEffect edgeEffect3 = this.f16645T;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i11 > 0) {
            this.f16645T.onRelease();
            zIsFinished |= this.f16645T.isFinished();
        }
        EdgeEffect edgeEffect4 = this.f16647V;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i11 < 0) {
            this.f16647V.onRelease();
            zIsFinished |= this.f16647V.isFinished();
        }
        if (zIsFinished) {
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            postInvalidateOnAnimation();
        }
    }

    public final void n0(int i10) {
        getScrollingChildHelper().h(i10);
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0066  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        float refreshRate;
        super.onAttachedToWindow();
        this.f16641P = 0;
        this.f16621C = true;
        this.f16625E = this.f16625E && !isLayoutRequested();
        this.f16653c.d();
        T t10 = this.f16684x;
        if (t10 != null) {
            t10.f16727g = true;
            t10.W(this);
        }
        this.f16685x0 = false;
        if (f16613Q0) {
            ThreadLocal threadLocal = RunnableC0840o.f16880e;
            RunnableC0840o runnableC0840o = (RunnableC0840o) threadLocal.get();
            this.f16670p0 = runnableC0840o;
            if (runnableC0840o == null) {
                RunnableC0840o runnableC0840o2 = new RunnableC0840o();
                runnableC0840o2.f16882a = new ArrayList();
                runnableC0840o2.f16885d = new ArrayList();
                this.f16670p0 = runnableC0840o2;
                WeakHashMap weakHashMap = p200r1.U.f27683a;
                Display display = getDisplay();
                if (isInEditMode() || display == null) {
                    refreshRate = 60.0f;
                } else {
                    refreshRate = display.getRefreshRate();
                    if (refreshRate < 30.0f) {
                        refreshRate = 60.0f;
                    }
                }
                RunnableC0840o runnableC0840o3 = this.f16670p0;
                runnableC0840o3.f16884c = (long) (1.0E9f / refreshRate);
                threadLocal.set(runnableC0840o3);
            }
            RunnableC0840o runnableC0840o4 = this.f16670p0;
            runnableC0840o4.getClass();
            boolean z3 = f16608K0;
            ArrayList arrayList = runnableC0840o4.f16882a;
            if (z3 && arrayList.contains(this)) {
                throw new IllegalStateException("RecyclerView already present in worker list!");
            }
            arrayList.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        a0 a0Var;
        RunnableC0840o runnableC0840o;
        B b10;
        super.onDetachedFromWindow();
        N n10 = this.f16648W;
        if (n10 != null) {
            n10.e();
        }
        int i10 = 0;
        setScrollState(0);
        k0 k0Var = this.f16669o0;
        k0Var.f16839q.removeCallbacks(k0Var);
        k0Var.f16835c.abortAnimation();
        T t10 = this.f16684x;
        if (t10 != null && (b10 = t10.f16725e) != null) {
            b10.d();
        }
        this.f16621C = false;
        T t11 = this.f16684x;
        if (t11 != null) {
            t11.f16727g = false;
            t11.X(this);
        }
        this.f16626E0.clear();
        removeCallbacks(this.f16628F0);
        this.f16671q.getClass();
        while (v0.f16965d.a() != null) {
        }
        int i11 = 0;
        while (true) {
            a0Var = this.f16653c;
            ArrayList arrayList = a0Var.f16748c;
            if (i11 >= arrayList.size()) {
                break;
            }
            p054e4.e.x(((l0) arrayList.get(i11)).itemView);
            i11++;
        }
        a0Var.e(a0Var.f16753h.f16682w, false);
        while (i10 < getChildCount()) {
            int i12 = i10 + 1;
            View childAt = getChildAt(i10);
            if (childAt == null) {
                throw new IndexOutOfBoundsException();
            }
            ArrayList arrayList2 = p054e4.e.b0(childAt).f1630a;
            for (int iJ0 = U9.o.j0(arrayList2); -1 < iJ0; iJ0--) {
                ((z0) arrayList2.get(iJ0)).f29966a.c();
            }
            i10 = i12;
        }
        if (!f16613Q0 || (runnableC0840o = this.f16670p0) == null) {
            return;
        }
        boolean zRemove = runnableC0840o.f16882a.remove(this);
        if (f16608K0 && !zRemove) {
            throw new IllegalStateException("RecyclerView removal failed!");
        }
        this.f16670p0 = null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f16688z;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((O) arrayList.get(i10)).g(canvas, this);
        }
    }

    /* JADX WARN: Code duplicated, block: B:28:0x0064  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f10;
        float axisValue;
        if (this.f16684x != null && !this.f16631H && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f10 = this.f16684x.f() ? -motionEvent.getAxisValue(9) : 0.0f;
                axisValue = this.f16684x.e() ? motionEvent.getAxisValue(10) : 0.0f;
            } else if ((motionEvent.getSource() & 4194304) != 0) {
                float axisValue2 = motionEvent.getAxisValue(26);
                if (this.f16684x.f()) {
                    f10 = -axisValue2;
                } else if (this.f16684x.e()) {
                    axisValue = axisValue2;
                    f10 = 0.0f;
                } else {
                    f10 = 0.0f;
                    axisValue = 0.0f;
                }
            } else {
                f10 = 0.0f;
                axisValue = 0.0f;
            }
            if (f10 != 0.0f || axisValue != 0.0f) {
                int i10 = (int) (axisValue * this.f16666l0);
                int i11 = (int) (f10 * this.f16667m0);
                T t10 = this.f16684x;
                if (t10 == null) {
                    Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
                    return false;
                }
                if (!this.f16631H) {
                    int[] iArr = this.f16624D0;
                    iArr[0] = 0;
                    iArr[1] = 0;
                    boolean zE = t10.e();
                    boolean zF = this.f16684x.f();
                    int i12 = zF ? (zE ? 1 : 0) | 2 : zE ? 1 : 0;
                    float y10 = motionEvent.getY();
                    float x10 = motionEvent.getX();
                    int iA0 = i10 - a0(i10, y10);
                    int iB0 = i11 - b0(i11, x10);
                    getScrollingChildHelper().g(i12, 1);
                    if (v(zE ? iA0 : 0, zF ? iB0 : 0, 1, this.f16624D0, this.f16620B0)) {
                        iA0 -= iArr[0];
                        iB0 -= iArr[1];
                    }
                    f0(zE ? iA0 : 0, zF ? iB0 : 0, motionEvent, 1);
                    RunnableC0840o runnableC0840o = this.f16670p0;
                    if (runnableC0840o != null && (iA0 != 0 || iB0 != 0)) {
                        runnableC0840o.a(this, iA0, iB0);
                    }
                    n0(1);
                }
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        boolean z5;
        if (!this.f16631H) {
            this.f16619B = null;
            if (F(motionEvent)) {
                e0();
                setScrollState(0);
                return true;
            }
            T t10 = this.f16684x;
            if (t10 != null) {
                boolean zE = t10.e();
                boolean zF = this.f16684x.f();
                if (this.f16654c0 == null) {
                    this.f16654c0 = VelocityTracker.obtain();
                }
                this.f16654c0.addMovement(motionEvent);
                int actionMasked = motionEvent.getActionMasked();
                int actionIndex = motionEvent.getActionIndex();
                if (actionMasked == 0) {
                    if (this.f16633I) {
                        this.f16633I = false;
                    }
                    this.f16652b0 = motionEvent.getPointerId(0);
                    int x10 = (int) (motionEvent.getX() + 0.5f);
                    this.f16660f0 = x10;
                    this.f16656d0 = x10;
                    int y10 = (int) (motionEvent.getY() + 0.5f);
                    this.f16661g0 = y10;
                    this.f16658e0 = y10;
                    EdgeEffect edgeEffect = this.f16644S;
                    if (edgeEffect == null || p197qa.h.j(edgeEffect) == 0.0f || canScrollHorizontally(-1)) {
                        z3 = false;
                    } else {
                        p197qa.h.m(this.f16644S, 0.0f, 1.0f - (motionEvent.getY() / getHeight()));
                        z3 = true;
                    }
                    EdgeEffect edgeEffect2 = this.f16646U;
                    boolean z10 = z3;
                    if (edgeEffect2 != null && p197qa.h.j(edgeEffect2) != 0.0f && !canScrollHorizontally(1)) {
                        z10 = z3;
                        z10 = z3;
                        p197qa.h.m(this.f16646U, 0.0f, motionEvent.getY() / getHeight());
                        z10 = true;
                    }
                    z10 = z3;
                    z10 = z3;
                    z10 = z3;
                    EdgeEffect edgeEffect3 = this.f16645T;
                    boolean z11 = z10;
                    if (edgeEffect3 != null && p197qa.h.j(edgeEffect3) != 0.0f && !canScrollVertically(-1)) {
                        z11 = z10;
                        z11 = z10;
                        p197qa.h.m(this.f16645T, 0.0f, motionEvent.getX() / getWidth());
                        z11 = true;
                    }
                    z11 = z10;
                    z11 = z10;
                    z11 = z10;
                    EdgeEffect edgeEffect4 = this.f16647V;
                    boolean z12 = z11;
                    if (edgeEffect4 != null && p197qa.h.j(edgeEffect4) != 0.0f && !canScrollVertically(1)) {
                        z12 = z11;
                        z12 = z11;
                        p197qa.h.m(this.f16647V, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
                        z12 = true;
                    }
                    if (z12 || this.f16650a0 == 2) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        setScrollState(1);
                        n0(1);
                    }
                    int[] iArr = this.f16622C0;
                    iArr[1] = 0;
                    iArr[0] = 0;
                    int i10 = zE;
                    if (zF) {
                        i10 = (zE ? 1 : 0) | 2;
                    }
                    getScrollingChildHelper().g(i10, 0);
                } else if (actionMasked == 1) {
                    this.f16654c0.clear();
                    n0(0);
                } else if (actionMasked == 2) {
                    int iFindPointerIndex = motionEvent.findPointerIndex(this.f16652b0);
                    if (iFindPointerIndex < 0) {
                        Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.f16652b0 + " not found. Did any MotionEvents get skipped?");
                        return false;
                    }
                    int x11 = (int) (motionEvent.getX(iFindPointerIndex) + 0.5f);
                    int y11 = (int) (motionEvent.getY(iFindPointerIndex) + 0.5f);
                    if (this.f16650a0 != 1) {
                        int i11 = x11 - this.f16656d0;
                        int i12 = y11 - this.f16658e0;
                        if (!zE || Math.abs(i11) <= this.f16662h0) {
                            z5 = false;
                        } else {
                            this.f16660f0 = x11;
                            z5 = true;
                        }
                        if (zF && Math.abs(i12) > this.f16662h0) {
                            this.f16661g0 = y11;
                            z5 = true;
                        }
                        if (z5) {
                            setScrollState(1);
                        }
                    }
                } else if (actionMasked == 3) {
                    e0();
                    setScrollState(0);
                } else if (actionMasked == 5) {
                    this.f16652b0 = motionEvent.getPointerId(actionIndex);
                    int x12 = (int) (motionEvent.getX(actionIndex) + 0.5f);
                    this.f16660f0 = x12;
                    this.f16656d0 = x12;
                    int y12 = (int) (motionEvent.getY(actionIndex) + 0.5f);
                    this.f16661g0 = y12;
                    this.f16658e0 = y12;
                } else if (actionMasked == 6) {
                    V(motionEvent);
                }
                if (this.f16650a0 == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int i14 = p144m1.l.f24833a;
        Trace.beginSection("RV OnLayout");
        s();
        Trace.endSection();
        this.f16625E = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        T t10 = this.f16684x;
        if (t10 == null) {
            q(i10, i11);
            return;
        }
        boolean zQ = t10.Q();
        boolean z3 = false;
        h0 h0Var = this.f16674r0;
        if (zQ) {
            int mode = View.MeasureSpec.getMode(i10);
            int mode2 = View.MeasureSpec.getMode(i11);
            this.f16684x.f16722b.q(i10, i11);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z3 = true;
            }
            this.f16630G0 = z3;
            if (z3 || this.f16682w == null) {
                return;
            }
            if (h0Var.f16817d == 1) {
                t();
            }
            this.f16684x.y0(i10, i11);
            h0Var.f16822i = true;
            u();
            this.f16684x.A0(i10, i11);
            if (this.f16684x.D0()) {
                this.f16684x.y0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                h0Var.f16822i = true;
                u();
                this.f16684x.A0(i10, i11);
            }
            this.f16632H0 = getMeasuredWidth();
            this.f16634I0 = getMeasuredHeight();
            return;
        }
        if (this.f16623D) {
            this.f16684x.f16722b.q(i10, i11);
            return;
        }
        if (this.f16637K) {
            l0();
            T();
            X();
            U(true);
            if (h0Var.k) {
                h0Var.f16820g = true;
            } else {
                this.f16657e.d();
                h0Var.f16820g = false;
            }
            this.f16637K = false;
            m0(false);
        } else if (h0Var.k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        I i12 = this.f16682w;
        if (i12 != null) {
            h0Var.f16818e = i12.getItemCount();
        } else {
            h0Var.f16818e = 0;
        }
        l0();
        this.f16684x.f16722b.q(i10, i11);
        m0(false);
        h0Var.f16820g = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i10, Rect rect) {
        if (P()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i10, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof d0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        d0 d0Var = (d0) parcelable;
        this.f16655d = d0Var;
        super.onRestoreInstanceState(d0Var.f2402a);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        d0 d0Var = new d0(super.onSaveInstanceState());
        d0 d0Var2 = this.f16655d;
        if (d0Var2 != null) {
            d0Var.f16770c = d0Var2.f16770c;
            return d0Var;
        }
        T t10 = this.f16684x;
        if (t10 != null) {
            d0Var.f16770c = t10.l0();
            return d0Var;
        }
        d0Var.f16770c = null;
        return d0Var;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i10, int i11, int i12, int i13) {
        super.onSizeChanged(i10, i11, i12, i13);
        if (i10 == i12 && i11 == i13) {
            return;
        }
        this.f16647V = null;
        this.f16645T = null;
        this.f16646U = null;
        this.f16644S = null;
    }

    /* JADX WARN: Code duplicated, block: B:141:0x024e  */
    /* JADX WARN: Code duplicated, block: B:159:0x0290  */
    /* JADX WARN: Code duplicated, block: B:198:0x0317  */
    /* JADX WARN: Code duplicated, block: B:261:0x03dd  */
    /* JADX WARN: Code duplicated, block: B:263:0x03e3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:264:0x03e5  */
    /* JADX WARN: Code duplicated, block: B:265:0x03e8  */
    /* JADX WARN: Code duplicated, block: B:57:0x00fd A[PHI: r1
  0x00fd: PHI (r1v70 int) = (r1v54 int), (r1v74 int) binds: [B:51:0x00e6, B:55:0x00f9] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code restructure failed: missing block: B:167:0x02b2, code lost:
    
        if (r5 == 0) goto L267;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v9, types: [androidx.recyclerview.widget.T] */
    /* JADX WARN: Type inference failed for: r1v17, types: [r1.o] */
    /* JADX WARN: Type inference failed for: r1v22, types: [r1.o] */
    /* JADX WARN: Type inference failed for: r22v0 */
    /* JADX WARN: Type inference failed for: r22v1 */
    /* JADX WARN: Type inference failed for: r22v10 */
    /* JADX WARN: Type inference failed for: r5v16, types: [androidx.recyclerview.widget.E, java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v21 */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [int] */
    /* JADX WARN: Type inference failed for: r9v1, types: [int] */
    /* JADX WARN: Type inference failed for: r9v7 */
    /* JADX WARN: Type inference failed for: r9v8 */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean onTouchEvent(android.view.MotionEvent r26) {
        /*
            Method dump skipped, instruction units count: 1091
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void p() {
        Ka.A a3 = this.f16659f;
        B.P p10 = this.f16657e;
        if (!this.f16625E || this.f16639N) {
            int i10 = p144m1.l.f24833a;
            Trace.beginSection("RV FullInvalidate");
            s();
            Trace.endSection();
            return;
        }
        if (p10.n()) {
            int i11 = p10.f535a;
            if ((i11 & 4) == 0 || (i11 & 11) != 0) {
                if (p10.n()) {
                    int i12 = p144m1.l.f24833a;
                    Trace.beginSection("RV FullInvalidate");
                    s();
                    Trace.endSection();
                    return;
                }
                return;
            }
            int i13 = p144m1.l.f24833a;
            Trace.beginSection("RV PartialInvalidate");
            l0();
            T();
            p10.w();
            if (!this.f16629G) {
                int iD = a3.D();
                for (int i14 = 0; i14 < iD; i14++) {
                    l0 l0VarM = M(a3.C(i14));
                    if (l0VarM != null && !l0VarM.shouldIgnore() && l0VarM.isUpdated()) {
                        s();
                    }
                }
                p10.c();
            }
            m0(true);
            U(true);
            Trace.endSection();
        }
    }

    public final void q(int i10, int i11) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        setMeasuredDimension(T.h(i10, paddingRight, getMinimumWidth()), T.h(i11, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public final void r(View view) {
        l0 l0VarM = M(view);
        I i10 = this.f16682w;
        if (i10 != null && l0VarM != null) {
            i10.onViewDetachedFromWindow(l0VarM);
        }
        ArrayList arrayList = this.M;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((U) this.M.get(size)).d(view);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z3) {
        l0 l0VarM = M(view);
        if (l0VarM != null) {
            if (l0VarM.isTmpDetached()) {
                l0VarM.clearTmpDetachFlag();
            } else if (!l0VarM.shouldIgnore()) {
                StringBuilder sb2 = new StringBuilder("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb2.append(l0VarM);
                throw new IllegalArgumentException(AbstractC0492c.i(this, sb2));
            }
        } else if (f16608K0) {
            StringBuilder sb3 = new StringBuilder("No ViewHolder found for child: ");
            sb3.append(view);
            throw new IllegalArgumentException(AbstractC0492c.i(this, sb3));
        }
        view.clearAnimation();
        r(view);
        super.removeDetachedView(view, z3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        B b10 = this.f16684x.f16725e;
        if ((b10 == null || !b10.f16798e) && !P() && view2 != null) {
            d0(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z3) {
        return this.f16684x.s0(this, view, rect, z3, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        ArrayList arrayList = this.f16617A;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((W) arrayList.get(i10)).e(z3);
        }
        super.requestDisallowInterceptTouchEvent(z3);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f16627F != 0 || this.f16631H) {
            this.f16629G = true;
        } else {
            super.requestLayout();
        }
    }

    /* JADX WARN: Code duplicated, block: B:166:0x0356  */
    /* JADX WARN: Code duplicated, block: B:188:0x03aa  */
    /* JADX WARN: Code duplicated, block: B:190:0x03ad  */
    /* JADX WARN: Code duplicated, block: B:196:0x03c7  */
    /* JADX WARN: Code duplicated, block: B:198:0x03cf  */
    /* JADX WARN: Code duplicated, block: B:200:0x03d3  */
    /* JADX WARN: Code duplicated, block: B:203:0x03db  */
    /* JADX WARN: Code duplicated, block: B:206:0x03e2  */
    /* JADX WARN: Code duplicated, block: B:209:0x03ed A[LOOP:4: B:202:0x03d9->B:209:0x03ed, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:212:0x03fa  */
    /* JADX WARN: Code duplicated, block: B:215:0x0401  */
    /* JADX WARN: Code duplicated, block: B:218:0x040c A[LOOP:5: B:211:0x03f8->B:218:0x040c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:220:0x0411  */
    /* JADX WARN: Code duplicated, block: B:250:0x03f0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:251:0x03f0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:252:0x03ea A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:254:0x040f A[EDGE_INSN: B:254:0x040f->B:219:0x040f BREAK  A[LOOP:5: B:211:0x03f8->B:218:0x040c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:255:0x0409 A[SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1, types: [androidx.recyclerview.widget.l0] */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v15 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v3 */
    /* JADX WARN: Type inference failed for: r11v4 */
    /* JADX WARN: Type inference failed for: r11v9 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v18 */
    /* JADX WARN: Type inference failed for: r3v19, types: [int] */
    /* JADX WARN: Type inference failed for: r3v22 */
    /* JADX WARN: Type inference failed for: r3v25 */
    /* JADX WARN: Type inference failed for: r3v26 */
    /* JADX WARN: Type inference failed for: r3v27 */
    /* JADX WARN: Type inference failed for: r3v28 */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void s() {
        boolean z3;
        ?? r11;
        int i10;
        int iB;
        int i11;
        int iMin;
        l0 l0VarI;
        l0 l0VarI2;
        int i12;
        View viewFindViewById;
        C0499e0 c0499e0;
        ?? r7;
        boolean zH;
        boolean z5;
        if (this.f16682w == null) {
            Log.w("RecyclerView", "No adapter attached; skipping layout");
            return;
        }
        if (this.f16684x == null) {
            Log.e("RecyclerView", "No layout manager attached; skipping layout");
            return;
        }
        h0 h0Var = this.f16674r0;
        boolean z10 = false;
        h0Var.f16822i = false;
        boolean z11 = true;
        boolean z12 = this.f16630G0 && !(this.f16632H0 == getWidth() && this.f16634I0 == getHeight());
        this.f16632H0 = 0;
        this.f16634I0 = 0;
        this.f16630G0 = false;
        if (h0Var.f16817d == 1) {
            t();
            this.f16684x.x0(this);
            u();
        } else {
            B.P p10 = this.f16657e;
            if ((((ArrayList) p10.f538d).isEmpty() || ((ArrayList) p10.f537c).isEmpty()) && !z12 && this.f16684x.f16733n == getWidth() && this.f16684x.f16734o == getHeight()) {
                this.f16684x.x0(this);
            } else {
                this.f16684x.x0(this);
                u();
            }
        }
        h0Var.a(4);
        l0();
        T();
        h0Var.f16817d = 1;
        boolean z13 = h0Var.f16823j;
        View view = null;
        Long l4 = null;
        a0 a0Var = this.f16653c;
        O2.k kVar = this.f16671q;
        if (z13) {
            int iD = this.f16659f.D() - 1;
            while (iD >= 0) {
                l0 l0VarM = M(this.f16659f.C(iD));
                if (l0VarM.shouldIgnore()) {
                    z5 = z11;
                } else {
                    long jK = K(l0VarM);
                    this.f16648W.getClass();
                    C0499e0 c0499e1 = new C0499e0();
                    c0499e1.a(l0VarM);
                    l0 l0Var = (l0) ((p240v.e) kVar.f9773c).c(jK, l4);
                    if (l0Var == null || l0Var.shouldIgnore()) {
                        z5 = z11;
                        kVar.e(l0VarM, c0499e1);
                    } else {
                        p240v.k kVar2 = (p240v.k) kVar.f9772b;
                        z5 = z11;
                        v0 v0Var = (v0) kVar2.getOrDefault(l0Var, l4);
                        boolean z14 = (v0Var == null || (v0Var.f16966a & 1) == 0) ? false : z5;
                        v0 v0Var2 = (v0) kVar2.getOrDefault(l0VarM, l4);
                        boolean z15 = (v0Var2 == null || (v0Var2.f16966a & 1) == 0) ? false : z5;
                        if (z14 && l0Var == l0VarM) {
                            kVar.e(l0VarM, c0499e1);
                        } else {
                            C0499e0 c0499e0W = kVar.w(l0Var, 4);
                            kVar.e(l0VarM, c0499e1);
                            C0499e0 c0499e0W2 = kVar.w(l0VarM, 8);
                            if (c0499e0W == null) {
                                int iD2 = this.f16659f.D();
                                for (int i13 = 0; i13 < iD2; i13++) {
                                    l0 l0VarM2 = M(this.f16659f.C(i13));
                                    if (l0VarM2 != l0VarM && K(l0VarM2) == jK) {
                                        I i14 = this.f16682w;
                                        if (i14 == null || !i14.hasStableIds()) {
                                            StringBuilder sb2 = new StringBuilder("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                                            sb2.append(l0VarM2);
                                            sb2.append(" \n View Holder 2:");
                                            sb2.append(l0VarM);
                                            throw new IllegalStateException(AbstractC0492c.i(this, sb2));
                                        }
                                        StringBuilder sb3 = new StringBuilder("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                                        sb3.append(l0VarM2);
                                        sb3.append(" \n View Holder 2:");
                                        sb3.append(l0VarM);
                                        throw new IllegalStateException(AbstractC0492c.i(this, sb3));
                                    }
                                }
                                Log.e("RecyclerView", "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + l0Var + " cannot be found but it is necessary for " + l0VarM + C());
                            } else {
                                l0Var.setIsRecyclable(false);
                                if (z14) {
                                    h(l0Var);
                                }
                                if (l0Var != l0VarM) {
                                    if (z15) {
                                        h(l0VarM);
                                    }
                                    l0Var.mShadowedHolder = l0VarM;
                                    h(l0Var);
                                    a0Var.l(l0Var);
                                    l0VarM.setIsRecyclable(false);
                                    l0VarM.mShadowingHolder = l0Var;
                                }
                                if (this.f16648W.a(l0Var, l0VarM, c0499e0W, c0499e0W2)) {
                                    W();
                                }
                            }
                        }
                    }
                }
                iD--;
                z11 = z5;
                l4 = null;
            }
            z3 = z11;
            p240v.k kVar3 = (p240v.k) kVar.f9772b;
            int i15 = kVar3.f30333c - 1;
            while (i15 >= 0) {
                l0 l0Var2 = (l0) kVar3.k(i15);
                v0 v0Var3 = (v0) kVar3.m(i15);
                int i16 = v0Var3.f16966a;
                int i17 = i16 & 3;
                G g10 = this.f16636J0;
                if (i17 == 3) {
                    RecyclerView recyclerView = (RecyclerView) g10.f16572a;
                    recyclerView.f16684x.q0(l0Var2.itemView, recyclerView.f16653c);
                    r7 = z10;
                } else if ((i16 & 1) != 0) {
                    C0499e0 c0499e2 = v0Var3.f16967b;
                    if (c0499e2 == null) {
                        RecyclerView recyclerView2 = (RecyclerView) g10.f16572a;
                        recyclerView2.f16684x.q0(l0Var2.itemView, recyclerView2.f16653c);
                        r7 = z10;
                    } else {
                        g10.g(l0Var2, c0499e2, v0Var3.f16968c);
                        r7 = z10;
                    }
                } else if ((i16 & 14) == 14) {
                    g10.f(l0Var2, v0Var3.f16967b, v0Var3.f16968c);
                    r7 = z10;
                } else {
                    if ((i16 & 12) == 12) {
                        C0499e0 c0499e3 = v0Var3.f16967b;
                        C0499e0 c0499e4 = v0Var3.f16968c;
                        g10.getClass();
                        l0Var2.setIsRecyclable(z10);
                        RecyclerView recyclerView3 = (RecyclerView) g10.f16572a;
                        if (!recyclerView3.f16639N) {
                            C0833h c0833h = (C0833h) recyclerView3.f16648W;
                            c0833h.getClass();
                            int i18 = c0499e3.f7841a;
                            int i19 = c0499e4.f7841a;
                            if (i18 == i19 && c0499e3.f7842b == c0499e4.f7842b) {
                                c0833h.c(l0Var2);
                                zH = false;
                            } else {
                                zH = c0833h.h(l0Var2, i18, c0499e3.f7842b, i19, c0499e4.f7842b);
                            }
                            if (zH) {
                                recyclerView3.W();
                            }
                        } else if (recyclerView3.f16648W.a(l0Var2, l0Var2, c0499e3, c0499e4)) {
                            recyclerView3.W();
                        }
                        r7 = 0;
                    } else {
                        if ((i16 & 4) != 0) {
                            c0499e0 = null;
                            g10.g(l0Var2, v0Var3.f16967b, null);
                        } else {
                            c0499e0 = null;
                            if ((i16 & 8) != 0) {
                                g10.f(l0Var2, v0Var3.f16967b, v0Var3.f16968c);
                            }
                        }
                        r7 = 0;
                    }
                    v0Var3.f16966a = r7;
                    v0Var3.f16967b = c0499e0;
                    v0Var3.f16968c = c0499e0;
                    v0.f16965d.c(v0Var3);
                    i15--;
                    z10 = false;
                }
                c0499e0 = null;
                v0Var3.f16966a = r7;
                v0Var3.f16967b = c0499e0;
                v0Var3.f16968c = c0499e0;
                v0.f16965d.c(v0Var3);
                i15--;
                z10 = false;
            }
            view = null;
        } else {
            z3 = true;
        }
        this.f16684x.p0(a0Var);
        h0Var.f16815b = h0Var.f16818e;
        this.f16639N = false;
        this.f16640O = false;
        h0Var.f16823j = false;
        h0Var.k = false;
        this.f16684x.f16726f = false;
        ArrayList arrayList = a0Var.f16747b;
        if (arrayList != null) {
            arrayList.clear();
        }
        T t10 = this.f16684x;
        if (t10.k) {
            t10.f16730j = 0;
            t10.k = false;
            a0Var.m();
        }
        this.f16684x.j0(h0Var);
        U(z3);
        m0(false);
        ((p240v.k) kVar.f9772b).clear();
        ((p240v.e) kVar.f9773c).a();
        int[] iArr = this.f16689z0;
        int i20 = iArr[0];
        int i21 = iArr[1];
        G(iArr);
        if ((iArr[0] == i20 && iArr[1] == i21) ? false : true) {
            x(0, 0);
        }
        if (this.f16668n0 && this.f16682w != null && hasFocus() && getDescendantFocusability() != 393216 && (getDescendantFocusability() != 131072 || !isFocused())) {
            if (isFocused()) {
                if (h0Var.f16825m == -1) {
                    r11 = view;
                } else {
                    r11 = view;
                }
                if (r11 != 0) {
                    if (this.f16659f.D() > 0) {
                        int i22 = h0Var.f16824l;
                        if (i22 != -1) {
                        }
                        iB = h0Var.b();
                        i11 = i10;
                        while (true) {
                            if (i11 < iB) {
                                l0VarI2 = I(i11);
                                if (l0VarI2 != null) {
                                    if (l0VarI2.itemView.hasFocusable()) {
                                        view = l0VarI2.itemView;
                                    } else {
                                        i11++;
                                    }
                                }
                            }
                            for (iMin = Math.min(iB, i10) - 1; iMin >= 0; iMin--) {
                                l0VarI = I(iMin);
                                if (l0VarI == null) {
                                    break;
                                    break;
                                } else {
                                    if (l0VarI.itemView.hasFocusable()) {
                                        view = l0VarI.itemView;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } else if (((ArrayList) this.f16659f.f7158e).contains(r11.itemView)) {
                    if (this.f16659f.D() > 0) {
                        int i23 = h0Var.f16824l;
                        if (i23 != -1) {
                        }
                        iB = h0Var.b();
                        i11 = i10;
                        while (true) {
                            if (i11 < iB) {
                                l0VarI2 = I(i11);
                                if (l0VarI2 != null) {
                                    if (l0VarI2.itemView.hasFocusable()) {
                                        view = l0VarI2.itemView;
                                    } else {
                                        i11++;
                                    }
                                }
                            }
                            while (iMin >= 0) {
                                l0VarI = I(iMin);
                                if (l0VarI == null) {
                                    break;
                                    break;
                                } else {
                                    if (l0VarI.itemView.hasFocusable()) {
                                        view = l0VarI.itemView;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } else if (this.f16659f.D() > 0) {
                    int i24 = h0Var.f16824l;
                    if (i24 != -1) {
                    }
                    iB = h0Var.b();
                    i11 = i10;
                    while (true) {
                        if (i11 < iB) {
                            l0VarI2 = I(i11);
                            if (l0VarI2 != null) {
                                if (l0VarI2.itemView.hasFocusable()) {
                                    view = l0VarI2.itemView;
                                } else {
                                    i11++;
                                }
                            }
                        }
                        while (iMin >= 0) {
                            l0VarI = I(iMin);
                            if (l0VarI == null) {
                                break;
                                break;
                            } else {
                                if (l0VarI.itemView.hasFocusable()) {
                                    view = l0VarI.itemView;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (view != null) {
                    i12 = h0Var.f16826n;
                    if (i12 != -1) {
                        view = viewFindViewById;
                    }
                    view.requestFocus();
                }
            } else if (((ArrayList) this.f16659f.f7158e).contains(getFocusedChild())) {
                if (h0Var.f16825m == -1 && this.f16682w.hasStableIds()) {
                    long j10 = h0Var.f16825m;
                    I i25 = this.f16682w;
                    if (i25 == null || !i25.hasStableIds()) {
                        r11 = view;
                    } else {
                        int iH = this.f16659f.H();
                        int i26 = 0;
                        r11 = view;
                        while (i26 < iH) {
                            l0 l0VarM3 = M(this.f16659f.G(i26));
                            if (l0VarM3 != null && !l0VarM3.isRemoved() && l0VarM3.getItemId() == j10) {
                                if (!((ArrayList) this.f16659f.f7158e).contains(l0VarM3.itemView)) {
                                    r11 = l0VarM3;
                                    break;
                                }
                                r11 = l0VarM3;
                            }
                            i26++;
                            r11 = r11;
                        }
                    }
                } else {
                    r11 = view;
                }
                if (r11 != 0) {
                    if (this.f16659f.D() > 0) {
                        int i27 = h0Var.f16824l;
                        if (i27 != -1) {
                        }
                        iB = h0Var.b();
                        i11 = i10;
                        while (true) {
                            if (i11 < iB) {
                                l0VarI2 = I(i11);
                                if (l0VarI2 != null) {
                                    if (l0VarI2.itemView.hasFocusable()) {
                                        view = l0VarI2.itemView;
                                    } else {
                                        i11++;
                                    }
                                }
                            }
                            while (iMin >= 0) {
                                l0VarI = I(iMin);
                                if (l0VarI == null) {
                                    break;
                                    break;
                                } else {
                                    if (l0VarI.itemView.hasFocusable()) {
                                        view = l0VarI.itemView;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } else if (((ArrayList) this.f16659f.f7158e).contains(r11.itemView) && r11.itemView.hasFocusable()) {
                    view = r11.itemView;
                } else if (this.f16659f.D() > 0) {
                    int i28 = h0Var.f16824l;
                    i10 = i28 != -1 ? i28 : 0;
                    iB = h0Var.b();
                    i11 = i10;
                    while (true) {
                        if (i11 < iB) {
                            l0VarI2 = I(i11);
                            if (l0VarI2 != null) {
                                if (l0VarI2.itemView.hasFocusable()) {
                                    view = l0VarI2.itemView;
                                } else {
                                    i11++;
                                }
                            }
                        }
                        while (iMin >= 0) {
                            l0VarI = I(iMin);
                            if (l0VarI == null) {
                                break;
                            }
                            if (l0VarI.itemView.hasFocusable()) {
                                view = l0VarI.itemView;
                                break;
                            }
                        }
                    }
                }
                if (view != null) {
                    i12 = h0Var.f16826n;
                    if (i12 != -1 && (viewFindViewById = view.findViewById(i12)) != null && viewFindViewById.isFocusable()) {
                        view = viewFindViewById;
                    }
                    view.requestFocus();
                }
            }
        }
        h0Var.f16825m = -1L;
        h0Var.f16824l = -1;
        h0Var.f16826n = -1;
    }

    @Override // android.view.View
    public final void scrollBy(int i10, int i11) {
        T t10 = this.f16684x;
        if (t10 == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f16631H) {
            return;
        }
        boolean zE = t10.e();
        boolean zF = this.f16684x.f();
        if (zE || zF) {
            if (!zE) {
                i10 = 0;
            }
            if (!zF) {
                i11 = 0;
            }
            f0(i10, i11, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i10, int i11) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!P()) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        } else {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.f16635J |= contentChangeTypes != 0 ? contentChangeTypes : 0;
        }
    }

    public void setAccessibilityDelegateCompat(m0 m0Var) {
        this.f16687y0 = m0Var;
        p200r1.U.q(this, m0Var);
    }

    public void setAdapter(I i10) {
        setLayoutFrozen(false);
        I i11 = this.f16682w;
        c0 c0Var = this.f16651b;
        if (i11 != null) {
            i11.unregisterAdapterDataObserver(c0Var);
            this.f16682w.onDetachedFromRecyclerView(this);
        }
        N n10 = this.f16648W;
        if (n10 != null) {
            n10.e();
        }
        T t10 = this.f16684x;
        a0 a0Var = this.f16653c;
        if (t10 != null) {
            t10.o0(a0Var);
            this.f16684x.p0(a0Var);
        }
        a0Var.f16746a.clear();
        a0Var.f();
        B.P p10 = this.f16657e;
        p10.x((ArrayList) p10.f537c);
        p10.x((ArrayList) p10.f538d);
        p10.f535a = 0;
        I i12 = this.f16682w;
        this.f16682w = i10;
        if (i10 != null) {
            i10.registerAdapterDataObserver(c0Var);
            i10.onAttachedToRecyclerView(this);
        }
        T t11 = this.f16684x;
        if (t11 != null) {
            t11.V();
        }
        I i13 = this.f16682w;
        a0Var.f16746a.clear();
        a0Var.f();
        a0Var.e(i12, true);
        Z zC = a0Var.c();
        if (i12 != null) {
            zC.f16740b--;
        }
        if (zC.f16740b == 0) {
            int i14 = 0;
            while (true) {
                SparseArray sparseArray = zC.f16739a;
                if (i14 >= sparseArray.size()) {
                    break;
                }
                Y y10 = (Y) sparseArray.valueAt(i14);
                ArrayList arrayList = y10.f16735a;
                int size = arrayList.size();
                int i15 = 0;
                while (i15 < size) {
                    Object obj = arrayList.get(i15);
                    i15++;
                    p054e4.e.x(((l0) obj).itemView);
                }
                y10.f16735a.clear();
                i14++;
            }
        }
        if (i13 != null) {
            zC.f16740b++;
        }
        a0Var.d();
        this.f16674r0.f16819f = true;
        Y(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(L l4) {
        if (l4 == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(l4 != null);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z3) {
        if (z3 != this.f16673r) {
            this.f16647V = null;
            this.f16645T = null;
            this.f16646U = null;
            this.f16644S = null;
        }
        this.f16673r = z3;
        super.setClipToPadding(z3);
        if (this.f16625E) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(M m2) {
        m2.getClass();
        this.f16643R = m2;
        this.f16647V = null;
        this.f16645T = null;
        this.f16646U = null;
        this.f16644S = null;
    }

    public void setHasFixedSize(boolean z3) {
        this.f16623D = z3;
    }

    public void setItemAnimator(N n10) {
        N n11 = this.f16648W;
        if (n11 != null) {
            n11.e();
            this.f16648W.f16600a = null;
        }
        this.f16648W = n10;
        if (n10 != null) {
            n10.f16600a = this.f16683w0;
        }
    }

    public void setItemViewCacheSize(int i10) {
        a0 a0Var = this.f16653c;
        a0Var.f16750e = i10;
        a0Var.m();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z3) {
        suppressLayout(z3);
    }

    public void setLayoutManager(T t10) {
        RecyclerView recyclerView;
        B b10;
        if (t10 == this.f16684x) {
            return;
        }
        setScrollState(0);
        k0 k0Var = this.f16669o0;
        k0Var.f16839q.removeCallbacks(k0Var);
        k0Var.f16835c.abortAnimation();
        T t11 = this.f16684x;
        if (t11 != null && (b10 = t11.f16725e) != null) {
            b10.d();
        }
        T t12 = this.f16684x;
        a0 a0Var = this.f16653c;
        if (t12 != null) {
            N n10 = this.f16648W;
            if (n10 != null) {
                n10.e();
            }
            this.f16684x.o0(a0Var);
            this.f16684x.p0(a0Var);
            a0Var.f16746a.clear();
            a0Var.f();
            if (this.f16621C) {
                T t13 = this.f16684x;
                t13.f16727g = false;
                t13.X(this);
            }
            this.f16684x.B0(null);
            this.f16684x = null;
        } else {
            a0Var.f16746a.clear();
            a0Var.f();
        }
        Ka.A a3 = this.f16659f;
        ((C0337f) a3.f7157d).h();
        ArrayList arrayList = (ArrayList) a3.f7158e;
        int size = arrayList.size() - 1;
        while (true) {
            recyclerView = (RecyclerView) ((G) a3.f7156c).f16572a;
            if (size < 0) {
                break;
            }
            l0 l0VarM = M((View) arrayList.get(size));
            if (l0VarM != null) {
                l0VarM.onLeftHiddenState(recyclerView);
            }
            arrayList.remove(size);
            size--;
        }
        int childCount = recyclerView.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = recyclerView.getChildAt(i10);
            recyclerView.r(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeAllViews();
        this.f16684x = t10;
        if (t10 != null) {
            if (t10.f16722b != null) {
                StringBuilder sb2 = new StringBuilder("LayoutManager ");
                sb2.append(t10);
                sb2.append(" is already attached to a RecyclerView:");
                throw new IllegalArgumentException(AbstractC0492c.i(t10.f16722b, sb2));
            }
            t10.B0(this);
            if (this.f16621C) {
                T t14 = this.f16684x;
                t14.f16727g = true;
                t14.W(this);
            }
        }
        a0Var.m();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z3) {
        C1488o scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f27746d) {
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            p200r1.H.z(scrollingChildHelper.f27745c);
        }
        scrollingChildHelper.f27746d = z3;
    }

    public void setOnFlingListener(V v10) {
        this.f16663i0 = v10;
    }

    @Deprecated
    public void setOnScrollListener(X x10) {
        this.f16676s0 = x10;
    }

    public void setPreserveFocusAfterLayout(boolean z3) {
        this.f16668n0 = z3;
    }

    public void setRecycledViewPool(Z z3) {
        a0 a0Var = this.f16653c;
        RecyclerView recyclerView = a0Var.f16753h;
        a0Var.e(recyclerView.f16682w, false);
        Z z5 = a0Var.f16752g;
        if (z5 != null) {
            z5.f16740b--;
        }
        a0Var.f16752g = z3;
        if (z3 != null && recyclerView.getAdapter() != null) {
            a0Var.f16752g.f16740b++;
        }
        a0Var.d();
    }

    @Deprecated
    public void setRecyclerListener(b0 b0Var) {
    }

    public void setScrollState(int i10) {
        B b10;
        if (i10 == this.f16650a0) {
            return;
        }
        if (f16609L0) {
            StringBuilder sbK = p096h9.i.k(i10, "setting scroll state to ", " from ");
            sbK.append(this.f16650a0);
            Log.d("RecyclerView", sbK.toString(), new Exception());
        }
        this.f16650a0 = i10;
        if (i10 != 2) {
            k0 k0Var = this.f16669o0;
            k0Var.f16839q.removeCallbacks(k0Var);
            k0Var.f16835c.abortAnimation();
            T t10 = this.f16684x;
            if (t10 != null && (b10 = t10.f16725e) != null) {
                b10.d();
            }
        }
        T t11 = this.f16684x;
        if (t11 != null) {
            t11.m0(i10);
        }
        X x10 = this.f16676s0;
        if (x10 != null) {
            x10.a(this, i10);
        }
        ArrayList arrayList = this.f16678t0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((X) this.f16678t0.get(size)).a(this, i10);
            }
        }
    }

    public void setScrollingTouchSlop(int i10) {
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i10 != 0) {
            if (i10 == 1) {
                this.f16662h0 = viewConfiguration.getScaledPagingTouchSlop();
                return;
            }
            Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i10 + "; using default value");
        }
        this.f16662h0 = viewConfiguration.getScaledTouchSlop();
    }

    public void setViewCacheExtension(j0 j0Var) {
        this.f16653c.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i10) {
        return getScrollingChildHelper().g(i10, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().h(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z3) {
        B b10;
        if (z3 != this.f16631H) {
            k("Do not suppressLayout in layout or scroll");
            if (!z3) {
                this.f16631H = false;
                if (this.f16629G && this.f16684x != null && this.f16682w != null) {
                    requestLayout();
                }
                this.f16629G = false;
                return;
            }
            long jUptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0));
            this.f16631H = true;
            this.f16633I = true;
            setScrollState(0);
            k0 k0Var = this.f16669o0;
            k0Var.f16839q.removeCallbacks(k0Var);
            k0Var.f16835c.abortAnimation();
            T t10 = this.f16684x;
            if (t10 == null || (b10 = t10.f16725e) == null) {
                return;
            }
            b10.d();
        }
    }

    public final void t() {
        View viewE;
        v0 v0Var;
        h0 h0Var = this.f16674r0;
        h0Var.a(1);
        D(h0Var);
        h0Var.f16822i = false;
        l0();
        O2.k kVar = this.f16671q;
        ((p240v.k) kVar.f9772b).clear();
        p240v.e eVar = (p240v.e) kVar.f9773c;
        eVar.a();
        T();
        X();
        View focusedChild = (this.f16668n0 && hasFocus() && this.f16682w != null) ? getFocusedChild() : null;
        l0 l0VarL = (focusedChild == null || (viewE = E(focusedChild)) == null) ? null : L(viewE);
        if (l0VarL == null) {
            h0Var.f16825m = -1L;
            h0Var.f16824l = -1;
            h0Var.f16826n = -1;
        } else {
            h0Var.f16825m = this.f16682w.hasStableIds() ? l0VarL.getItemId() : -1L;
            h0Var.f16824l = this.f16639N ? -1 : l0VarL.isRemoved() ? l0VarL.mOldPosition : l0VarL.getAbsoluteAdapterPosition();
            View focusedChild2 = l0VarL.itemView;
            int id = focusedChild2.getId();
            while (!focusedChild2.isFocused() && (focusedChild2 instanceof ViewGroup) && focusedChild2.hasFocus()) {
                focusedChild2 = ((ViewGroup) focusedChild2).getFocusedChild();
                if (focusedChild2.getId() != -1) {
                    id = focusedChild2.getId();
                }
            }
            h0Var.f16826n = id;
        }
        h0Var.f16821h = h0Var.f16823j && this.v0;
        this.v0 = false;
        this.f16680u0 = false;
        h0Var.f16820g = h0Var.k;
        h0Var.f16818e = this.f16682w.getItemCount();
        G(this.f16689z0);
        boolean z3 = h0Var.f16823j;
        p240v.k kVar2 = (p240v.k) kVar.f9772b;
        if (z3) {
            int iD = this.f16659f.D();
            for (int i10 = 0; i10 < iD; i10++) {
                l0 l0VarM = M(this.f16659f.C(i10));
                if (!l0VarM.shouldIgnore() && (!l0VarM.isInvalid() || this.f16682w.hasStableIds())) {
                    N n10 = this.f16648W;
                    N.b(l0VarM);
                    l0VarM.getUnmodifiedPayloads();
                    n10.getClass();
                    C0499e0 c0499e0 = new C0499e0();
                    c0499e0.a(l0VarM);
                    v0 v0VarA = (v0) kVar2.getOrDefault(l0VarM, null);
                    if (v0VarA == null) {
                        v0VarA = v0.a();
                        kVar2.put(l0VarM, v0VarA);
                    }
                    v0VarA.f16967b = c0499e0;
                    v0VarA.f16966a |= 4;
                    if (h0Var.f16821h && l0VarM.isUpdated() && !l0VarM.isRemoved() && !l0VarM.shouldIgnore() && !l0VarM.isInvalid()) {
                        eVar.d(l0VarM, K(l0VarM));
                    }
                }
            }
        }
        if (h0Var.k) {
            int iH = this.f16659f.H();
            for (int i11 = 0; i11 < iH; i11++) {
                l0 l0VarM2 = M(this.f16659f.G(i11));
                if (f16608K0 && l0VarM2.mPosition == -1 && !l0VarM2.isRemoved()) {
                    throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("view holder cannot have position -1 unless it is removed")));
                }
                if (!l0VarM2.shouldIgnore()) {
                    l0VarM2.saveOldPosition();
                }
            }
            boolean z5 = h0Var.f16819f;
            h0Var.f16819f = false;
            this.f16684x.i0(this.f16653c, h0Var);
            h0Var.f16819f = z5;
            for (int i12 = 0; i12 < this.f16659f.D(); i12++) {
                l0 l0VarM3 = M(this.f16659f.C(i12));
                if (!l0VarM3.shouldIgnore() && ((v0Var = (v0) kVar2.getOrDefault(l0VarM3, null)) == null || (v0Var.f16966a & 4) == 0)) {
                    N.b(l0VarM3);
                    boolean zHasAnyOfTheFlags = l0VarM3.hasAnyOfTheFlags(8192);
                    N n11 = this.f16648W;
                    l0VarM3.getUnmodifiedPayloads();
                    n11.getClass();
                    C0499e0 c0499e1 = new C0499e0();
                    c0499e1.a(l0VarM3);
                    if (zHasAnyOfTheFlags) {
                        Z(l0VarM3, c0499e1);
                    } else {
                        v0 v0VarA2 = (v0) kVar2.getOrDefault(l0VarM3, null);
                        if (v0VarA2 == null) {
                            v0VarA2 = v0.a();
                            kVar2.put(l0VarM3, v0VarA2);
                        }
                        v0VarA2.f16966a |= 2;
                        v0VarA2.f16967b = c0499e1;
                    }
                }
            }
            m();
        } else {
            m();
        }
        U(true);
        m0(false);
        h0Var.f16817d = 2;
    }

    public final void u() {
        l0();
        T();
        h0 h0Var = this.f16674r0;
        h0Var.a(6);
        this.f16657e.d();
        h0Var.f16818e = this.f16682w.getItemCount();
        h0Var.f16816c = 0;
        if (this.f16655d != null && this.f16682w.canRestoreState()) {
            Parcelable parcelable = this.f16655d.f16770c;
            if (parcelable != null) {
                this.f16684x.k0(parcelable);
            }
            this.f16655d = null;
        }
        h0Var.f16820g = false;
        this.f16684x.i0(this.f16653c, h0Var);
        h0Var.f16819f = false;
        h0Var.f16823j = h0Var.f16823j && this.f16648W != null;
        h0Var.f16817d = 4;
        U(true);
        m0(false);
    }

    public final boolean v(int i10, int i11, int i12, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().c(i10, i11, i12, iArr, iArr2);
    }

    public final void w(int i10, int i11, int i12, int i13, int[] iArr, int i14, int[] iArr2) {
        getScrollingChildHelper().d(i10, i11, i12, i13, iArr, i14, iArr2);
    }

    public final void x(int i10, int i11) {
        this.f16642Q++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i10, scrollY - i11);
        X x10 = this.f16676s0;
        if (x10 != null) {
            x10.b(this, i10, i11);
        }
        ArrayList arrayList = this.f16678t0;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((X) this.f16678t0.get(size)).b(this, i10, i11);
            }
        }
        this.f16642Q--;
    }

    public final void y() {
        if (this.f16647V != null) {
            return;
        }
        ((i0) this.f16643R).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f16647V = edgeEffect;
        if (this.f16673r) {
            edgeEffect.setSize((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom());
        } else {
            edgeEffect.setSize(getMeasuredWidth(), getMeasuredHeight());
        }
    }

    public final void z() {
        if (this.f16644S != null) {
            return;
        }
        ((i0) this.f16643R).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.f16644S = edgeEffect;
        if (this.f16673r) {
            edgeEffect.setSize((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight());
        } else {
            edgeEffect.setSize(getMeasuredHeight(), getMeasuredWidth());
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public RecyclerView(Context context, AttributeSet attributeSet, int i10) {
        float fA;
        int i11;
        Constructor constructor;
        Object[] objArr;
        super(context, attributeSet, i10);
        int i12 = 2;
        int i13 = 0;
        this.f16651b = new c0(this, i13);
        this.f16653c = new a0(this);
        this.f16671q = new O2.k(19);
        this.f16675s = new F(this, i13);
        this.f16677t = new Rect();
        this.f16679u = new Rect();
        this.f16681v = new RectF();
        this.f16686y = new ArrayList();
        this.f16688z = new ArrayList();
        this.f16617A = new ArrayList();
        this.f16627F = 0;
        this.f16639N = false;
        this.f16640O = false;
        this.f16641P = 0;
        this.f16642Q = 0;
        this.f16643R = f16616T0;
        this.f16648W = new C0833h();
        this.f16650a0 = 0;
        this.f16652b0 = -1;
        this.f16666l0 = Float.MIN_VALUE;
        this.f16667m0 = Float.MIN_VALUE;
        int i14 = 1;
        this.f16668n0 = true;
        this.f16669o0 = new k0(this);
        this.f16672q0 = f16613Q0 ? new Db.m(i12) : null;
        h0 h0Var = new h0();
        h0Var.f16814a = -1;
        h0Var.f16815b = 0;
        h0Var.f16816c = 0;
        h0Var.f16817d = 1;
        h0Var.f16818e = 0;
        h0Var.f16819f = false;
        h0Var.f16820g = false;
        h0Var.f16821h = false;
        h0Var.f16822i = false;
        h0Var.f16823j = false;
        h0Var.k = false;
        this.f16674r0 = h0Var;
        this.f16680u0 = false;
        this.v0 = false;
        G g10 = new G(this);
        this.f16683w0 = g10;
        this.f16685x0 = false;
        this.f16689z0 = new int[2];
        this.f16620B0 = new int[2];
        this.f16622C0 = new int[2];
        this.f16624D0 = new int[2];
        this.f16626E0 = new ArrayList();
        this.f16628F0 = new F(this, i14);
        this.f16632H0 = 0;
        this.f16634I0 = 0;
        this.f16636J0 = new G(this);
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f16662h0 = viewConfiguration.getScaledTouchSlop();
        int i15 = Build.VERSION.SDK_INT;
        if (i15 >= 26) {
            Method method = p200r1.Y.f27689a;
            fA = p200r1.V.a(viewConfiguration);
        } else {
            fA = p200r1.Y.a(viewConfiguration, context);
        }
        this.f16666l0 = fA;
        this.f16667m0 = i15 >= 26 ? p200r1.V.b(viewConfiguration) : p200r1.Y.a(viewConfiguration, context);
        this.f16664j0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f16665k0 = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f16649a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        setWillNotDraw(getOverScrollMode() == 2);
        this.f16648W.f16600a = g10;
        G g11 = new G(this);
        B.P p10 = new B.P();
        p10.f536b = new S0.d(30);
        p10.f537c = new ArrayList();
        p10.f538d = new ArrayList();
        p10.f535a = 0;
        p10.f539e = g11;
        p10.f540f = new G(p10);
        this.f16657e = p10;
        this.f16659f = new Ka.A(new G(this));
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        if ((i15 >= 26 ? p200r1.K.c(this) : 0) == 0 && i15 >= 26) {
            p200r1.K.m(this, 8);
        }
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
        this.f16638L = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new m0(this));
        int[] iArr = p064f2.a.f22321a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        p200r1.U.p(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i10);
        String string = typedArrayObtainStyledAttributes.getString(8);
        if (typedArrayObtainStyledAttributes.getInt(2, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.f16673r = typedArrayObtainStyledAttributes.getBoolean(1, true);
        if (typedArrayObtainStyledAttributes.getBoolean(3, false)) {
            StateListDrawable stateListDrawable = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(6);
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(7);
            StateListDrawable stateListDrawable2 = (StateListDrawable) typedArrayObtainStyledAttributes.getDrawable(4);
            Drawable drawable2 = typedArrayObtainStyledAttributes.getDrawable(5);
            if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
                throw new IllegalArgumentException(AbstractC0492c.i(this, new StringBuilder("Trying to set fast scroller without both required drawables.")));
            }
            Resources resources = getContext().getResources();
            i11 = 4;
            new C0838m(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(com.flamingotools.ws.R.dimen.fastscroll_default_thickness), resources.getDimensionPixelSize(com.flamingotools.ws.R.dimen.fastscroll_minimum_range), resources.getDimensionPixelOffset(com.flamingotools.ws.R.dimen.fastscroll_margin));
        } else {
            i11 = 4;
        }
        typedArrayObtainStyledAttributes.recycle();
        if (string != null) {
            String strTrim = string.trim();
            if (!strTrim.isEmpty()) {
                if (strTrim.charAt(0) == '.') {
                    strTrim = context.getPackageName() + strTrim;
                } else if (!strTrim.contains(".")) {
                    strTrim = RecyclerView.class.getPackage().getName() + '.' + strTrim;
                }
                String str = strTrim;
                try {
                    Class<? extends U> clsAsSubclass = Class.forName(str, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(T.class);
                    try {
                        constructor = clsAsSubclass.getConstructor(f16614R0);
                        Object[] objArr2 = new Object[i11];
                        objArr2[0] = context;
                        objArr2[i14] = attributeSet;
                        objArr2[2] = Integer.valueOf(i10);
                        objArr2[3] = 0;
                        objArr = objArr2;
                    } catch (NoSuchMethodException e10) {
                        try {
                            constructor = clsAsSubclass.getConstructor(null);
                            objArr = null;
                        } catch (NoSuchMethodException e11) {
                            e11.initCause(e10);
                            throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + str, e11);
                        }
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((T) constructor.newInstance(objArr));
                } catch (ClassCastException e12) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + str, e12);
                } catch (ClassNotFoundException e13) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + str, e13);
                } catch (IllegalAccessException e14) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + str, e14);
                } catch (InstantiationException e15) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e15);
                } catch (InvocationTargetException e16) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + str, e16);
                }
            }
        }
        int[] iArr2 = f16610M0;
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, iArr2, i10, 0);
        p200r1.U.p(this, context, iArr2, attributeSet, typedArrayObtainStyledAttributes2, i10);
        boolean z3 = typedArrayObtainStyledAttributes2.getBoolean(0, true);
        typedArrayObtainStyledAttributes2.recycle();
        setNestedScrollingEnabled(z3);
        setTag(com.flamingotools.ws.R.id.is_pooling_container_tag, Boolean.TRUE);
    }

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public l0 f16690a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final Rect f16691b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f16692c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f16693d;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f16691b = new Rect();
            this.f16692c = true;
            this.f16693d = false;
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.f16691b = new Rect();
            this.f16692c = true;
            this.f16693d = false;
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f16691b = new Rect();
            this.f16692c = true;
            this.f16693d = false;
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f16691b = new Rect();
            this.f16692c = true;
            this.f16693d = false;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.LayoutParams) layoutParams);
            this.f16691b = new Rect();
            this.f16692c = true;
            this.f16693d = false;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        T t10 = this.f16684x;
        if (t10 != null) {
            return t10.u(layoutParams);
        }
        throw new IllegalStateException(AbstractC0492c.i(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }
}
