package androidx.recyclerview.widget;

import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class Y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16735a = new ArrayList();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f16736b = 5;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public long f16737c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public long f16738d = 0;
}
