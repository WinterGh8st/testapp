package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.p, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0841p extends G2.b {
    @Override // G2.b
    public final int o(int i10, int i11) {
        return i10 % i11;
    }

    @Override // G2.b
    public final int p(int i10) {
        return 1;
    }
}
