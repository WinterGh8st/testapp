package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public final class i0 extends M {
}
