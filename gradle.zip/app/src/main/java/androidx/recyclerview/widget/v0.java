package androidx.recyclerview.widget;

import L.C0499e0;

/* JADX INFO: loaded from: classes.dex */
public final class v0 {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final S0.d f16965d = new S0.d(20);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16966a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public C0499e0 f16967b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C0499e0 f16968c;

    public static v0 a() {
        v0 v0Var = (v0) f16965d.a();
        return v0Var == null ? new v0() : v0Var;
    }
}
