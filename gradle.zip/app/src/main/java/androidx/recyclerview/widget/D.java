package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public final class D extends I1.g {
    @Override // I1.g
    public final int b(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        ((T) this.f5745b).getClass();
        return T.z(view) + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
    }

    @Override // I1.g
    public final int c(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        ((T) this.f5745b).getClass();
        return T.C(view) + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
    }

    @Override // I1.g
    public final int d(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        ((T) this.f5745b).getClass();
        return T.D(view) + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
    }

    @Override // I1.g
    public final int e(View view) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        ((T) this.f5745b).getClass();
        return T.F(view) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
    }

    @Override // I1.g
    public final int f() {
        return ((T) this.f5745b).f16734o;
    }

    @Override // I1.g
    public final int g() {
        T t10 = (T) this.f5745b;
        return t10.f16734o - t10.I();
    }

    @Override // I1.g
    public final int h() {
        return ((T) this.f5745b).I();
    }

    @Override // I1.g
    public final int i() {
        return ((T) this.f5745b).f16732m;
    }

    @Override // I1.g
    public final int j() {
        return ((T) this.f5745b).f16731l;
    }

    @Override // I1.g
    public final int k() {
        return ((T) this.f5745b).L();
    }

    @Override // I1.g
    public final int l() {
        T t10 = (T) this.f5745b;
        return (t10.f16734o - t10.L()) - t10.I();
    }

    @Override // I1.g
    public final int m(View view) {
        T t10 = (T) this.f5745b;
        Rect rect = (Rect) this.f5746c;
        t10.P(rect, view);
        return rect.bottom;
    }

    @Override // I1.g
    public final int n(View view) {
        T t10 = (T) this.f5745b;
        Rect rect = (Rect) this.f5746c;
        t10.P(rect, view);
        return rect.top;
    }

    @Override // I1.g
    public final void o(int i10) {
        ((T) this.f5745b).U(i10);
    }
}
