package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.n, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0839n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f16873a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16874b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16875c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public RecyclerView f16876d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16877e;
}
