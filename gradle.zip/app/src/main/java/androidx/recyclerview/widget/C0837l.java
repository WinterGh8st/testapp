package androidx.recyclerview.widget;

import android.animation.ValueAnimator;

/* JADX INFO: renamed from: androidx.recyclerview.widget.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0837l implements ValueAnimator.AnimatorUpdateListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16840a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f16841b;

    public /* synthetic */ C0837l(Object obj, int i10) {
        this.f16840a = i10;
        this.f16841b = obj;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        switch (this.f16840a) {
            case 0:
                int iFloatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
                C0838m c0838m = (C0838m) this.f16841b;
                c0838m.f16848c.setAlpha(iFloatValue);
                c0838m.f16849d.setAlpha(iFloatValue);
                c0838m.f16863s.invalidate();
                break;
            default:
                ((r) this.f16841b).f16910m = valueAnimator.getAnimatedFraction();
                break;
        }
    }
}
