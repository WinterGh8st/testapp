package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class LinearLayoutManager extends T implements InterfaceC0845u, f0 {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final C0848x f16585A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final C0849y f16586B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final int f16587C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int[] f16588D;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f16589p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public C0850z f16590q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public I1.g f16591r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f16592s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final boolean f16593t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f16594u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f16595v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final boolean f16596w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f16597x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f16598y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public A f16599z;

    public LinearLayoutManager(int i10) {
        this.f16589p = 1;
        this.f16593t = false;
        this.f16594u = false;
        this.f16595v = false;
        this.f16596w = true;
        this.f16597x = -1;
        this.f16598y = Integer.MIN_VALUE;
        this.f16599z = null;
        this.f16585A = new C0848x();
        this.f16586B = new C0849y();
        this.f16587C = 2;
        this.f16588D = new int[2];
        j1(i10);
        c(null);
        if (this.f16593t) {
            this.f16593t = false;
            t0();
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean D0() {
        if (this.f16732m != 1073741824 && this.f16731l != 1073741824) {
            int iW = w();
            for (int i10 = 0; i10 < iW; i10++) {
                ViewGroup.LayoutParams layoutParams = v(i10).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // androidx.recyclerview.widget.T
    public void F0(RecyclerView recyclerView, int i10) {
        B b10 = new B(recyclerView.getContext());
        b10.f16794a = i10;
        G0(b10);
    }

    @Override // androidx.recyclerview.widget.T
    public boolean H0() {
        return this.f16599z == null && this.f16592s == this.f16595v;
    }

    public void I0(h0 h0Var, int[] iArr) {
        int i10;
        int iL = h0Var.f16814a != -1 ? this.f16591r.l() : 0;
        if (this.f16590q.f16992f == -1) {
            i10 = 0;
        } else {
            i10 = iL;
            iL = 0;
        }
        iArr[0] = iL;
        iArr[1] = i10;
    }

    public void J0(h0 h0Var, C0850z c0850z, Db.m mVar) {
        int i10 = c0850z.f16990d;
        if (i10 < 0 || i10 >= h0Var.b()) {
            return;
        }
        mVar.a(i10, Math.max(0, c0850z.f16993g));
    }

    public final int K0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        O0();
        I1.g gVar = this.f16591r;
        boolean z3 = !this.f16596w;
        return p123ja.a.m(h0Var, gVar, R0(z3), Q0(z3), this, this.f16596w);
    }

    public final int L0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        O0();
        I1.g gVar = this.f16591r;
        boolean z3 = !this.f16596w;
        return p123ja.a.n(h0Var, gVar, R0(z3), Q0(z3), this, this.f16596w, this.f16594u);
    }

    public final int M0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        O0();
        I1.g gVar = this.f16591r;
        boolean z3 = !this.f16596w;
        return p123ja.a.o(h0Var, gVar, R0(z3), Q0(z3), this, this.f16596w);
    }

    public final int N0(int i10) {
        if (i10 == 1) {
            return (this.f16589p != 1 && b1()) ? 1 : -1;
        }
        if (i10 == 2) {
            return (this.f16589p != 1 && b1()) ? -1 : 1;
        }
        if (i10 == 17) {
            return this.f16589p == 0 ? -1 : Integer.MIN_VALUE;
        }
        if (i10 == 33) {
            return this.f16589p == 1 ? -1 : Integer.MIN_VALUE;
        }
        if (i10 != 66) {
            return (i10 == 130 && this.f16589p == 1) ? 1 : Integer.MIN_VALUE;
        }
        return this.f16589p == 0 ? 1 : Integer.MIN_VALUE;
    }

    public final void O0() {
        if (this.f16590q == null) {
            C0850z c0850z = new C0850z();
            c0850z.f16987a = true;
            c0850z.f16994h = 0;
            c0850z.f16995i = 0;
            c0850z.k = null;
            this.f16590q = c0850z;
        }
    }

    public final int P0(a0 a0Var, C0850z c0850z, h0 h0Var, boolean z3) {
        int i10;
        int i11 = c0850z.f16989c;
        int i12 = c0850z.f16993g;
        if (i12 != Integer.MIN_VALUE) {
            if (i11 < 0) {
                c0850z.f16993g = i12 + i11;
            }
            e1(a0Var, c0850z);
        }
        int i13 = c0850z.f16989c + c0850z.f16994h;
        while (true) {
            if ((!c0850z.f16997l && i13 <= 0) || (i10 = c0850z.f16990d) < 0 || i10 >= h0Var.b()) {
                break;
            }
            C0849y c0849y = this.f16586B;
            c0849y.f16983a = 0;
            c0849y.f16984b = false;
            c0849y.f16985c = false;
            c0849y.f16986d = false;
            c1(a0Var, h0Var, c0850z, c0849y);
            if (!c0849y.f16984b) {
                int i14 = c0850z.f16988b;
                int i15 = c0849y.f16983a;
                c0850z.f16988b = (c0850z.f16992f * i15) + i14;
                if (!c0849y.f16985c || c0850z.k != null || !h0Var.f16820g) {
                    c0850z.f16989c -= i15;
                    i13 -= i15;
                }
                int i16 = c0850z.f16993g;
                if (i16 != Integer.MIN_VALUE) {
                    int i17 = i16 + i15;
                    c0850z.f16993g = i17;
                    int i18 = c0850z.f16989c;
                    if (i18 < 0) {
                        c0850z.f16993g = i17 + i18;
                    }
                    e1(a0Var, c0850z);
                }
                if (z3 && c0849y.f16986d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i11 - c0850z.f16989c;
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean Q() {
        return true;
    }

    public final View Q0(boolean z3) {
        return this.f16594u ? V0(0, w(), z3) : V0(w() - 1, -1, z3);
    }

    public final View R0(boolean z3) {
        return this.f16594u ? V0(w() - 1, -1, z3) : V0(0, w(), z3);
    }

    public final int S0() {
        View viewV0 = V0(0, w(), false);
        if (viewV0 == null) {
            return -1;
        }
        return T.M(viewV0);
    }

    public final int T0() {
        View viewV0 = V0(w() - 1, -1, false);
        if (viewV0 == null) {
            return -1;
        }
        return T.M(viewV0);
    }

    public final View U0(int i10, int i11) {
        int i12;
        int i13;
        O0();
        if (i11 <= i10 && i11 >= i10) {
            return v(i10);
        }
        if (this.f16591r.e(v(i10)) < this.f16591r.k()) {
            i12 = 16644;
            i13 = 16388;
        } else {
            i12 = 4161;
            i13 = 4097;
        }
        return this.f16589p == 0 ? this.f16723c.l(i10, i11, i12, i13) : this.f16724d.l(i10, i11, i12, i13);
    }

    public final View V0(int i10, int i11, boolean z3) {
        O0();
        int i12 = z3 ? 24579 : 320;
        return this.f16589p == 0 ? this.f16723c.l(i10, i11, i12, 320) : this.f16724d.l(i10, i11, i12, 320);
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0075  */
    /* JADX WARN: Code duplicated, block: B:35:0x0079  */
    public View W0(a0 a0Var, h0 h0Var, boolean z3, boolean z5) {
        int i10;
        int iW;
        int i11;
        O0();
        int iW2 = w();
        if (z5) {
            iW = w() - 1;
            i10 = -1;
            i11 = -1;
        } else {
            i10 = iW2;
            iW = 0;
            i11 = 1;
        }
        int iB = h0Var.b();
        int iK = this.f16591r.k();
        int iG = this.f16591r.g();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (iW != i10) {
            View viewV = v(iW);
            int iM = T.M(viewV);
            int iE = this.f16591r.e(viewV);
            int iB2 = this.f16591r.b(viewV);
            if (iM >= 0 && iM < iB) {
                if (!((RecyclerView.LayoutParams) viewV.getLayoutParams()).f16690a.isRemoved()) {
                    boolean z10 = iB2 <= iK && iE < iK;
                    boolean z11 = iE >= iG && iB2 > iG;
                    if (!z10 && !z11) {
                        return viewV;
                    }
                    if (z3) {
                        if (z11) {
                            view2 = viewV;
                        } else if (view == null) {
                            view = viewV;
                        }
                    } else if (z10) {
                        view2 = viewV;
                    } else if (view == null) {
                        view = viewV;
                    }
                } else if (view3 == null) {
                    view3 = viewV;
                }
            }
            iW += i11;
        }
        if (view != null) {
            return view;
        }
        return view2 != null ? view2 : view3;
    }

    public final int X0(int i10, a0 a0Var, h0 h0Var, boolean z3) {
        int iG;
        int iG2 = this.f16591r.g() - i10;
        if (iG2 <= 0) {
            return 0;
        }
        int i11 = -h1(-iG2, a0Var, h0Var);
        int i12 = i10 + i11;
        if (!z3 || (iG = this.f16591r.g() - i12) <= 0) {
            return i11;
        }
        this.f16591r.o(iG);
        return iG + i11;
    }

    @Override // androidx.recyclerview.widget.T
    public View Y(View view, int i10, a0 a0Var, h0 h0Var) {
        int iN0;
        View viewU0;
        g1();
        if (w() != 0 && (iN0 = N0(i10)) != Integer.MIN_VALUE) {
            O0();
            l1(iN0, (int) (this.f16591r.l() * 0.33333334f), false, h0Var);
            C0850z c0850z = this.f16590q;
            c0850z.f16993g = Integer.MIN_VALUE;
            c0850z.f16987a = false;
            P0(a0Var, c0850z, h0Var, true);
            if (iN0 == -1) {
                viewU0 = this.f16594u ? U0(w() - 1, -1) : U0(0, w());
            } else {
                viewU0 = this.f16594u ? U0(0, w()) : U0(w() - 1, -1);
            }
            View viewA1 = iN0 == -1 ? a1() : Z0();
            if (!viewA1.hasFocusable()) {
                return viewU0;
            }
            if (viewU0 != null) {
                return viewA1;
            }
        }
        return null;
    }

    public final int Y0(int i10, a0 a0Var, h0 h0Var, boolean z3) {
        int iK;
        int iK2 = i10 - this.f16591r.k();
        if (iK2 <= 0) {
            return 0;
        }
        int i11 = -h1(iK2, a0Var, h0Var);
        int i12 = i10 + i11;
        if (!z3 || (iK = i12 - this.f16591r.k()) <= 0) {
            return i11;
        }
        this.f16591r.o(-iK);
        return i11 - iK;
    }

    @Override // androidx.recyclerview.widget.T
    public final void Z(AccessibilityEvent accessibilityEvent) {
        super.Z(accessibilityEvent);
        if (w() > 0) {
            accessibilityEvent.setFromIndex(S0());
            accessibilityEvent.setToIndex(T0());
        }
    }

    public final View Z0() {
        return v(this.f16594u ? 0 : w() - 1);
    }

    @Override // androidx.recyclerview.widget.f0
    public final PointF a(int i10) {
        if (w() == 0) {
            return null;
        }
        int i11 = (i10 < T.M(v(0))) != this.f16594u ? -1 : 1;
        return this.f16589p == 0 ? new PointF(i11, 0.0f) : new PointF(0.0f, i11);
    }

    public final View a1() {
        return v(this.f16594u ? w() - 1 : 0);
    }

    public final boolean b1() {
        return H() == 1;
    }

    @Override // androidx.recyclerview.widget.T
    public final void c(String str) {
        if (this.f16599z == null) {
            super.c(str);
        }
    }

    public void c1(a0 a0Var, h0 h0Var, C0850z c0850z, C0849y c0849y) {
        int iJ;
        int i10;
        int i11;
        int iD;
        View viewB = c0850z.b(a0Var);
        if (viewB == null) {
            c0849y.f16984b = true;
            return;
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) viewB.getLayoutParams();
        if (c0850z.k == null) {
            if (this.f16594u == (c0850z.f16992f == -1)) {
                b(viewB, -1, false);
            } else {
                b(viewB, 0, false);
            }
        } else {
            if (this.f16594u == (c0850z.f16992f == -1)) {
                b(viewB, -1, true);
            } else {
                b(viewB, 0, true);
            }
        }
        RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) viewB.getLayoutParams();
        Rect rectN = this.f16722b.N(viewB);
        int i12 = rectN.left + rectN.right;
        int i13 = rectN.top + rectN.bottom;
        int iX = T.x(e(), this.f16733n, this.f16731l, K() + J() + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin + i12, ((ViewGroup.MarginLayoutParams) layoutParams2).width);
        int iX2 = T.x(f(), this.f16734o, this.f16732m, I() + L() + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin + i13, ((ViewGroup.MarginLayoutParams) layoutParams2).height);
        if (C0(viewB, iX, iX2, layoutParams2)) {
            viewB.measure(iX, iX2);
        }
        c0849y.f16983a = this.f16591r.c(viewB);
        if (this.f16589p == 1) {
            if (b1()) {
                iD = this.f16733n - K();
                iJ = iD - this.f16591r.d(viewB);
            } else {
                iJ = J();
                iD = this.f16591r.d(viewB) + iJ;
            }
            if (c0850z.f16992f == -1) {
                i10 = c0850z.f16988b;
                i11 = i10 - c0849y.f16983a;
            } else {
                i11 = c0850z.f16988b;
                i10 = c0849y.f16983a + i11;
            }
        } else {
            int iL = L();
            int iD2 = this.f16591r.d(viewB) + iL;
            if (c0850z.f16992f == -1) {
                int i14 = c0850z.f16988b;
                int i15 = i14 - c0849y.f16983a;
                iD = i14;
                i10 = iD2;
                iJ = i15;
                i11 = iL;
            } else {
                int i16 = c0850z.f16988b;
                int i17 = c0849y.f16983a + i16;
                iJ = i16;
                i10 = iD2;
                i11 = iL;
                iD = i17;
            }
        }
        T.S(viewB, iJ, i11, iD, i10);
        if (layoutParams.f16690a.isRemoved() || layoutParams.f16690a.isUpdated()) {
            c0849y.f16985c = true;
        }
        c0849y.f16986d = viewB.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean e() {
        return this.f16589p == 0;
    }

    public final void e1(a0 a0Var, C0850z c0850z) {
        if (!c0850z.f16987a || c0850z.f16997l) {
            return;
        }
        int i10 = c0850z.f16993g;
        int i11 = c0850z.f16995i;
        if (c0850z.f16992f == -1) {
            int iW = w();
            if (i10 < 0) {
                return;
            }
            int iF = (this.f16591r.f() - i10) + i11;
            if (this.f16594u) {
                for (int i12 = 0; i12 < iW; i12++) {
                    View viewV = v(i12);
                    if (this.f16591r.e(viewV) < iF || this.f16591r.n(viewV) < iF) {
                        f1(a0Var, 0, i12);
                        return;
                    }
                }
                return;
            }
            int i13 = iW - 1;
            for (int i14 = i13; i14 >= 0; i14--) {
                View viewV2 = v(i14);
                if (this.f16591r.e(viewV2) < iF || this.f16591r.n(viewV2) < iF) {
                    f1(a0Var, i13, i14);
                    return;
                }
            }
            return;
        }
        if (i10 < 0) {
            return;
        }
        int i15 = i10 - i11;
        int iW2 = w();
        if (!this.f16594u) {
            for (int i16 = 0; i16 < iW2; i16++) {
                View viewV3 = v(i16);
                if (this.f16591r.b(viewV3) > i15 || this.f16591r.m(viewV3) > i15) {
                    f1(a0Var, 0, i16);
                    return;
                }
            }
            return;
        }
        int i17 = iW2 - 1;
        for (int i18 = i17; i18 >= 0; i18--) {
            View viewV4 = v(i18);
            if (this.f16591r.b(viewV4) > i15 || this.f16591r.m(viewV4) > i15) {
                f1(a0Var, i17, i18);
                return;
            }
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean f() {
        return this.f16589p == 1;
    }

    public final void f1(a0 a0Var, int i10, int i11) {
        if (i10 == i11) {
            return;
        }
        if (i11 <= i10) {
            while (i10 > i11) {
                View viewV = v(i10);
                r0(i10);
                a0Var.h(viewV);
                i10--;
            }
            return;
        }
        for (int i12 = i11 - 1; i12 >= i10; i12--) {
            View viewV2 = v(i12);
            r0(i12);
            a0Var.h(viewV2);
        }
    }

    public final void g1() {
        if (this.f16589p == 1 || !b1()) {
            this.f16594u = this.f16593t;
        } else {
            this.f16594u = !this.f16593t;
        }
    }

    public final int h1(int i10, a0 a0Var, h0 h0Var) {
        if (w() != 0 && i10 != 0) {
            O0();
            this.f16590q.f16987a = true;
            int i11 = i10 > 0 ? 1 : -1;
            int iAbs = Math.abs(i10);
            l1(i11, iAbs, true, h0Var);
            C0850z c0850z = this.f16590q;
            int iP0 = P0(a0Var, c0850z, h0Var, false) + c0850z.f16993g;
            if (iP0 >= 0) {
                if (iAbs > iP0) {
                    i10 = i11 * iP0;
                }
                this.f16591r.o(-i10);
                this.f16590q.f16996j = i10;
                return i10;
            }
        }
        return 0;
    }

    @Override // androidx.recyclerview.widget.T
    public final void i(int i10, int i11, h0 h0Var, Db.m mVar) {
        if (this.f16589p != 0) {
            i10 = i11;
        }
        if (w() == 0 || i10 == 0) {
            return;
        }
        O0();
        l1(i10 > 0 ? 1 : -1, Math.abs(i10), true, h0Var);
        J0(h0Var, this.f16590q, mVar);
    }

    /* JADX WARN: Code duplicated, block: B:102:0x01ab  */
    /* JADX WARN: Code duplicated, block: B:104:0x01ae  */
    /* JADX WARN: Code duplicated, block: B:111:0x01d9  */
    /* JADX WARN: Code duplicated, block: B:114:0x01e0  */
    /* JADX WARN: Code duplicated, block: B:118:0x01f3  */
    /* JADX WARN: Code duplicated, block: B:122:0x0213 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:124:0x0217  */
    /* JADX WARN: Code duplicated, block: B:126:0x021a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:128:0x021e  */
    /* JADX WARN: Code duplicated, block: B:130:0x0221 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:131:0x0223  */
    /* JADX WARN: Code duplicated, block: B:133:0x0227  */
    /* JADX WARN: Code duplicated, block: B:135:0x022b  */
    /* JADX WARN: Code duplicated, block: B:137:0x0232  */
    /* JADX WARN: Code duplicated, block: B:138:0x0238  */
    /* JADX WARN: Code duplicated, block: B:95:0x0194  */
    @Override // androidx.recyclerview.widget.T
    public void i0(a0 a0Var, h0 h0Var) {
        View focusedChild;
        int iB;
        RecyclerView recyclerView;
        View focusedChild2;
        boolean z3;
        boolean z5;
        View viewW0;
        int iE;
        int iB2;
        int iK;
        int iG;
        boolean z10;
        boolean z11;
        RecyclerView.LayoutParams layoutParams;
        int i10;
        int iE2;
        int i11;
        int i12;
        List list;
        int i13;
        int i14;
        int iX0;
        int i15;
        View viewR;
        int iE3;
        int iG2;
        int i16;
        int i17 = -1;
        if (!(this.f16599z == null && this.f16597x == -1) && h0Var.b() == 0) {
            o0(a0Var);
            return;
        }
        A a3 = this.f16599z;
        if (a3 != null && (i16 = a3.f16556a) >= 0) {
            this.f16597x = i16;
        }
        O0();
        this.f16590q.f16987a = false;
        g1();
        RecyclerView recyclerView2 = this.f16722b;
        if (recyclerView2 == null || (focusedChild = recyclerView2.getFocusedChild()) == null || ((ArrayList) this.f16721a.f7158e).contains(focusedChild)) {
            focusedChild = null;
        }
        C0848x c0848x = this.f16585A;
        if (!c0848x.f16982e || this.f16597x != -1 || this.f16599z != null) {
            c0848x.d();
            c0848x.f16981d = this.f16594u ^ this.f16595v;
            if (h0Var.f16820g || (i10 = this.f16597x) == -1) {
                if (w() != 0) {
                    recyclerView = this.f16722b;
                    if (recyclerView != null || (focusedChild2 = recyclerView.getFocusedChild()) == null || ((ArrayList) this.f16721a.f7158e).contains(focusedChild2)) {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        layoutParams = (RecyclerView.LayoutParams) focusedChild2.getLayoutParams();
                        if (!layoutParams.f16690a.isRemoved() || layoutParams.f16690a.getLayoutPosition() < 0 || layoutParams.f16690a.getLayoutPosition() >= h0Var.b()) {
                            z3 = this.f16592s;
                            z5 = this.f16595v;
                            if (z3 == z5 || (viewW0 = W0(a0Var, h0Var, c0848x.f16981d, z5)) == null) {
                                c0848x.a();
                                if (this.f16595v) {
                                    iB = h0Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                c0848x.f16979b = iB;
                            } else {
                                c0848x.b(viewW0, T.M(viewW0));
                                if (!h0Var.f16820g && H0()) {
                                    iE = this.f16591r.e(viewW0);
                                    iB2 = this.f16591r.b(viewW0);
                                    iK = this.f16591r.k();
                                    iG = this.f16591r.g();
                                    if (iB2 <= iK || iE >= iK) {
                                        z10 = false;
                                    } else {
                                        z10 = true;
                                    }
                                    if (iE >= iG || iB2 <= iG) {
                                        z11 = false;
                                    } else {
                                        z11 = true;
                                    }
                                    if (z10 || z11) {
                                        if (c0848x.f16981d) {
                                            iK = iG;
                                        }
                                        c0848x.f16980c = iK;
                                    }
                                }
                            }
                        } else {
                            c0848x.c(focusedChild2, T.M(focusedChild2));
                        }
                    } else {
                        z3 = this.f16592s;
                        z5 = this.f16595v;
                        if (z3 == z5) {
                            c0848x.a();
                            if (this.f16595v) {
                                iB = h0Var.b() - 1;
                            } else {
                                iB = 0;
                            }
                            c0848x.f16979b = iB;
                        } else {
                            c0848x.b(viewW0, T.M(viewW0));
                            if (!h0Var.f16820g) {
                                iE = this.f16591r.e(viewW0);
                                iB2 = this.f16591r.b(viewW0);
                                iK = this.f16591r.k();
                                iG = this.f16591r.g();
                                if (iB2 <= iK) {
                                    z10 = false;
                                } else {
                                    z10 = false;
                                }
                                if (iE >= iG) {
                                    z11 = false;
                                } else {
                                    z11 = false;
                                }
                                if (z10) {
                                    if (c0848x.f16981d) {
                                        iK = iG;
                                    }
                                    c0848x.f16980c = iK;
                                } else {
                                    if (c0848x.f16981d) {
                                        iK = iG;
                                    }
                                    c0848x.f16980c = iK;
                                }
                            }
                        }
                    }
                } else {
                    c0848x.a();
                    if (this.f16595v) {
                        iB = h0Var.b() - 1;
                    } else {
                        iB = 0;
                    }
                    c0848x.f16979b = iB;
                }
            } else if (i10 < 0 || i10 >= h0Var.b()) {
                this.f16597x = -1;
                this.f16598y = Integer.MIN_VALUE;
                if (w() != 0) {
                    recyclerView = this.f16722b;
                    if (recyclerView != null) {
                        focusedChild2 = null;
                    } else {
                        focusedChild2 = null;
                    }
                    if (focusedChild2 != null) {
                        layoutParams = (RecyclerView.LayoutParams) focusedChild2.getLayoutParams();
                        if (layoutParams.f16690a.isRemoved()) {
                            z3 = this.f16592s;
                            z5 = this.f16595v;
                            if (z3 == z5) {
                                c0848x.a();
                                if (this.f16595v) {
                                    iB = h0Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                c0848x.f16979b = iB;
                            } else {
                                c0848x.b(viewW0, T.M(viewW0));
                                if (!h0Var.f16820g) {
                                    iE = this.f16591r.e(viewW0);
                                    iB2 = this.f16591r.b(viewW0);
                                    iK = this.f16591r.k();
                                    iG = this.f16591r.g();
                                    if (iB2 <= iK) {
                                        z10 = false;
                                    } else {
                                        z10 = false;
                                    }
                                    if (iE >= iG) {
                                        z11 = false;
                                    } else {
                                        z11 = false;
                                    }
                                    if (z10) {
                                        if (c0848x.f16981d) {
                                            iK = iG;
                                        }
                                        c0848x.f16980c = iK;
                                    } else {
                                        if (c0848x.f16981d) {
                                            iK = iG;
                                        }
                                        c0848x.f16980c = iK;
                                    }
                                }
                            }
                        } else {
                            z3 = this.f16592s;
                            z5 = this.f16595v;
                            if (z3 == z5) {
                                c0848x.a();
                                if (this.f16595v) {
                                    iB = h0Var.b() - 1;
                                } else {
                                    iB = 0;
                                }
                                c0848x.f16979b = iB;
                            } else {
                                c0848x.b(viewW0, T.M(viewW0));
                                if (!h0Var.f16820g) {
                                    iE = this.f16591r.e(viewW0);
                                    iB2 = this.f16591r.b(viewW0);
                                    iK = this.f16591r.k();
                                    iG = this.f16591r.g();
                                    if (iB2 <= iK) {
                                        z10 = false;
                                    } else {
                                        z10 = false;
                                    }
                                    if (iE >= iG) {
                                        z11 = false;
                                    } else {
                                        z11 = false;
                                    }
                                    if (z10) {
                                        if (c0848x.f16981d) {
                                            iK = iG;
                                        }
                                        c0848x.f16980c = iK;
                                    } else {
                                        if (c0848x.f16981d) {
                                            iK = iG;
                                        }
                                        c0848x.f16980c = iK;
                                    }
                                }
                            }
                        }
                    } else {
                        z3 = this.f16592s;
                        z5 = this.f16595v;
                        if (z3 == z5) {
                            c0848x.a();
                            if (this.f16595v) {
                                iB = h0Var.b() - 1;
                            } else {
                                iB = 0;
                            }
                            c0848x.f16979b = iB;
                        } else {
                            c0848x.b(viewW0, T.M(viewW0));
                            if (!h0Var.f16820g) {
                                iE = this.f16591r.e(viewW0);
                                iB2 = this.f16591r.b(viewW0);
                                iK = this.f16591r.k();
                                iG = this.f16591r.g();
                                if (iB2 <= iK) {
                                    z10 = false;
                                } else {
                                    z10 = false;
                                }
                                if (iE >= iG) {
                                    z11 = false;
                                } else {
                                    z11 = false;
                                }
                                if (z10) {
                                    if (c0848x.f16981d) {
                                        iK = iG;
                                    }
                                    c0848x.f16980c = iK;
                                } else {
                                    if (c0848x.f16981d) {
                                        iK = iG;
                                    }
                                    c0848x.f16980c = iK;
                                }
                            }
                        }
                    }
                } else {
                    c0848x.a();
                    if (this.f16595v) {
                        iB = h0Var.b() - 1;
                    } else {
                        iB = 0;
                    }
                    c0848x.f16979b = iB;
                }
            } else {
                int i18 = this.f16597x;
                c0848x.f16979b = i18;
                A a9 = this.f16599z;
                if (a9 != null && a9.f16556a >= 0) {
                    boolean z12 = a9.f16558c;
                    c0848x.f16981d = z12;
                    if (z12) {
                        c0848x.f16980c = this.f16591r.g() - this.f16599z.f16557b;
                    } else {
                        c0848x.f16980c = this.f16591r.k() + this.f16599z.f16557b;
                    }
                } else if (this.f16598y == Integer.MIN_VALUE) {
                    View viewR2 = r(i18);
                    if (viewR2 == null) {
                        if (w() > 0) {
                            c0848x.f16981d = (this.f16597x < T.M(v(0))) == this.f16594u;
                        }
                        c0848x.a();
                    } else if (this.f16591r.c(viewR2) > this.f16591r.l()) {
                        c0848x.a();
                    } else if (this.f16591r.e(viewR2) - this.f16591r.k() < 0) {
                        c0848x.f16980c = this.f16591r.k();
                        c0848x.f16981d = false;
                    } else if (this.f16591r.g() - this.f16591r.b(viewR2) < 0) {
                        c0848x.f16980c = this.f16591r.g();
                        c0848x.f16981d = true;
                    } else {
                        if (c0848x.f16981d) {
                            int iB3 = this.f16591r.b(viewR2);
                            I1.g gVar = this.f16591r;
                            iE2 = (Integer.MIN_VALUE == gVar.f5744a ? 0 : gVar.l() - gVar.f5744a) + iB3;
                        } else {
                            iE2 = this.f16591r.e(viewR2);
                        }
                        c0848x.f16980c = iE2;
                    }
                } else {
                    boolean z13 = this.f16594u;
                    c0848x.f16981d = z13;
                    if (z13) {
                        c0848x.f16980c = this.f16591r.g() - this.f16598y;
                    } else {
                        c0848x.f16980c = this.f16591r.k() + this.f16598y;
                    }
                }
            }
            c0848x.f16982e = true;
        } else if (focusedChild != null && (this.f16591r.e(focusedChild) >= this.f16591r.g() || this.f16591r.b(focusedChild) <= this.f16591r.k())) {
            c0848x.c(focusedChild, T.M(focusedChild));
        }
        C0850z c0850z = this.f16590q;
        c0850z.f16992f = c0850z.f16996j >= 0 ? 1 : -1;
        int[] iArr = this.f16588D;
        iArr[0] = 0;
        iArr[1] = 0;
        I0(h0Var, iArr);
        int iK2 = this.f16591r.k() + Math.max(0, iArr[0]);
        int iH = this.f16591r.h() + Math.max(0, iArr[1]);
        if (h0Var.f16820g && (i15 = this.f16597x) != -1 && this.f16598y != Integer.MIN_VALUE && (viewR = r(i15)) != null) {
            if (this.f16594u) {
                iG2 = this.f16591r.g() - this.f16591r.b(viewR);
                iE3 = this.f16598y;
            } else {
                iE3 = this.f16591r.e(viewR) - this.f16591r.k();
                iG2 = this.f16598y;
            }
            int i19 = iG2 - iE3;
            if (i19 > 0) {
                iK2 += i19;
            } else {
                iH -= i19;
            }
        }
        if (!c0848x.f16981d ? !this.f16594u : this.f16594u) {
            i17 = 1;
        }
        d1(a0Var, h0Var, c0848x, i17);
        q(a0Var);
        this.f16590q.f16997l = this.f16591r.i() == 0 && this.f16591r.f() == 0;
        this.f16590q.getClass();
        this.f16590q.f16995i = 0;
        if (c0848x.f16981d) {
            n1(c0848x.f16979b, c0848x.f16980c);
            C0850z c0850z2 = this.f16590q;
            c0850z2.f16994h = iK2;
            P0(a0Var, c0850z2, h0Var, false);
            C0850z c0850z3 = this.f16590q;
            i12 = c0850z3.f16988b;
            int i20 = c0850z3.f16990d;
            int i21 = c0850z3.f16989c;
            if (i21 > 0) {
                iH += i21;
            }
            m1(c0848x.f16979b, c0848x.f16980c);
            C0850z c0850z4 = this.f16590q;
            c0850z4.f16994h = iH;
            c0850z4.f16990d += c0850z4.f16991e;
            P0(a0Var, c0850z4, h0Var, false);
            C0850z c0850z5 = this.f16590q;
            i11 = c0850z5.f16988b;
            int i22 = c0850z5.f16989c;
            if (i22 > 0) {
                n1(i20, i12);
                C0850z c0850z6 = this.f16590q;
                c0850z6.f16994h = i22;
                P0(a0Var, c0850z6, h0Var, false);
                i12 = this.f16590q.f16988b;
            }
        } else {
            m1(c0848x.f16979b, c0848x.f16980c);
            C0850z c0850z7 = this.f16590q;
            c0850z7.f16994h = iH;
            P0(a0Var, c0850z7, h0Var, false);
            C0850z c0850z8 = this.f16590q;
            i11 = c0850z8.f16988b;
            int i23 = c0850z8.f16990d;
            int i24 = c0850z8.f16989c;
            if (i24 > 0) {
                iK2 += i24;
            }
            n1(c0848x.f16979b, c0848x.f16980c);
            C0850z c0850z9 = this.f16590q;
            c0850z9.f16994h = iK2;
            c0850z9.f16990d += c0850z9.f16991e;
            P0(a0Var, c0850z9, h0Var, false);
            C0850z c0850z10 = this.f16590q;
            int i25 = c0850z10.f16988b;
            int i26 = c0850z10.f16989c;
            if (i26 > 0) {
                m1(i23, i11);
                C0850z c0850z11 = this.f16590q;
                c0850z11.f16994h = i26;
                P0(a0Var, c0850z11, h0Var, false);
                i11 = this.f16590q.f16988b;
            }
            i12 = i25;
        }
        if (w() > 0) {
            if (this.f16594u ^ this.f16595v) {
                int iX1 = X0(i11, a0Var, h0Var, true);
                i13 = i12 + iX1;
                i14 = i11 + iX1;
                iX0 = Y0(i13, a0Var, h0Var, false);
            } else {
                int iY0 = Y0(i12, a0Var, h0Var, true);
                i13 = i12 + iY0;
                i14 = i11 + iY0;
                iX0 = X0(i14, a0Var, h0Var, false);
            }
            i12 = i13 + iX0;
            i11 = i14 + iX0;
        }
        if (h0Var.k && w() != 0 && !h0Var.f16820g && H0()) {
            List list2 = a0Var.f16749d;
            int size = list2.size();
            int iM = T.M(v(0));
            int iC = 0;
            int iC2 = 0;
            for (int i27 = 0; i27 < size; i27++) {
                l0 l0Var = (l0) list2.get(i27);
                if (!l0Var.isRemoved()) {
                    if ((l0Var.getLayoutPosition() < iM) != this.f16594u) {
                        iC += this.f16591r.c(l0Var.itemView);
                    } else {
                        iC2 += this.f16591r.c(l0Var.itemView);
                    }
                }
            }
            this.f16590q.k = list2;
            if (iC > 0) {
                n1(T.M(a1()), i12);
                C0850z c0850z12 = this.f16590q;
                c0850z12.f16994h = iC;
                c0850z12.f16989c = 0;
                c0850z12.a(null);
                P0(a0Var, this.f16590q, h0Var, false);
            }
            if (iC2 > 0) {
                m1(T.M(Z0()), i11);
                C0850z c0850z13 = this.f16590q;
                c0850z13.f16994h = iC2;
                c0850z13.f16989c = 0;
                list = null;
                c0850z13.a(null);
                P0(a0Var, this.f16590q, h0Var, false);
            } else {
                list = null;
            }
            this.f16590q.k = list;
        }
        if (h0Var.f16820g) {
            c0848x.d();
        } else {
            I1.g gVar2 = this.f16591r;
            gVar2.f5744a = gVar2.l();
        }
        this.f16592s = this.f16595v;
    }

    public final void i1(int i10, int i11) {
        this.f16597x = i10;
        this.f16598y = i11;
        A a3 = this.f16599z;
        if (a3 != null) {
            a3.f16556a = -1;
        }
        t0();
    }

    @Override // androidx.recyclerview.widget.T
    public final void j(int i10, Db.m mVar) {
        boolean z3;
        int i11;
        A a3 = this.f16599z;
        if (a3 == null || (i11 = a3.f16556a) < 0) {
            g1();
            z3 = this.f16594u;
            i11 = this.f16597x;
            if (i11 == -1) {
                i11 = z3 ? i10 - 1 : 0;
            }
        } else {
            z3 = a3.f16558c;
        }
        int i12 = z3 ? -1 : 1;
        for (int i13 = 0; i13 < this.f16587C && i11 >= 0 && i11 < i10; i13++) {
            mVar.a(i11, 0);
            i11 += i12;
        }
    }

    @Override // androidx.recyclerview.widget.T
    public void j0(h0 h0Var) {
        this.f16599z = null;
        this.f16597x = -1;
        this.f16598y = Integer.MIN_VALUE;
        this.f16585A.d();
    }

    public final void j1(int i10) {
        if (i10 != 0 && i10 != 1) {
            throw new IllegalArgumentException(p096h9.i.i(i10, "invalid orientation:"));
        }
        c(null);
        if (i10 != this.f16589p || this.f16591r == null) {
            I1.g gVarA = I1.g.a(this, i10);
            this.f16591r = gVarA;
            this.f16585A.f16978a = gVarA;
            this.f16589p = i10;
            t0();
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final int k(h0 h0Var) {
        return K0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void k0(Parcelable parcelable) {
        if (parcelable instanceof A) {
            A a3 = (A) parcelable;
            this.f16599z = a3;
            if (this.f16597x != -1) {
                a3.f16556a = -1;
            }
            t0();
        }
    }

    public void k1(boolean z3) {
        c(null);
        if (this.f16595v == z3) {
            return;
        }
        this.f16595v = z3;
        t0();
    }

    @Override // androidx.recyclerview.widget.T
    public int l(h0 h0Var) {
        return L0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final Parcelable l0() {
        A a3 = this.f16599z;
        if (a3 != null) {
            A a9 = new A();
            a9.f16556a = a3.f16556a;
            a9.f16557b = a3.f16557b;
            a9.f16558c = a3.f16558c;
            return a9;
        }
        A a10 = new A();
        if (w() <= 0) {
            a10.f16556a = -1;
            return a10;
        }
        O0();
        boolean z3 = this.f16592s ^ this.f16594u;
        a10.f16558c = z3;
        if (z3) {
            View viewZ0 = Z0();
            a10.f16557b = this.f16591r.g() - this.f16591r.b(viewZ0);
            a10.f16556a = T.M(viewZ0);
            return a10;
        }
        View viewA1 = a1();
        a10.f16556a = T.M(viewA1);
        a10.f16557b = this.f16591r.e(viewA1) - this.f16591r.k();
        return a10;
    }

    public final void l1(int i10, int i11, boolean z3, h0 h0Var) {
        int iK;
        this.f16590q.f16997l = this.f16591r.i() == 0 && this.f16591r.f() == 0;
        this.f16590q.f16992f = i10;
        int[] iArr = this.f16588D;
        iArr[0] = 0;
        iArr[1] = 0;
        I0(h0Var, iArr);
        int iMax = Math.max(0, iArr[0]);
        int iMax2 = Math.max(0, iArr[1]);
        boolean z5 = i10 == 1;
        C0850z c0850z = this.f16590q;
        int i12 = z5 ? iMax2 : iMax;
        c0850z.f16994h = i12;
        if (!z5) {
            iMax = iMax2;
        }
        c0850z.f16995i = iMax;
        if (z5) {
            c0850z.f16994h = this.f16591r.h() + i12;
            View viewZ0 = Z0();
            C0850z c0850z2 = this.f16590q;
            c0850z2.f16991e = this.f16594u ? -1 : 1;
            int iM = T.M(viewZ0);
            C0850z c0850z3 = this.f16590q;
            c0850z2.f16990d = iM + c0850z3.f16991e;
            c0850z3.f16988b = this.f16591r.b(viewZ0);
            iK = this.f16591r.b(viewZ0) - this.f16591r.g();
        } else {
            View viewA1 = a1();
            C0850z c0850z4 = this.f16590q;
            c0850z4.f16994h = this.f16591r.k() + c0850z4.f16994h;
            C0850z c0850z5 = this.f16590q;
            c0850z5.f16991e = this.f16594u ? 1 : -1;
            int iM2 = T.M(viewA1);
            C0850z c0850z6 = this.f16590q;
            c0850z5.f16990d = iM2 + c0850z6.f16991e;
            c0850z6.f16988b = this.f16591r.e(viewA1);
            iK = (-this.f16591r.e(viewA1)) + this.f16591r.k();
        }
        C0850z c0850z7 = this.f16590q;
        c0850z7.f16989c = i11;
        if (z3) {
            c0850z7.f16989c = i11 - iK;
        }
        c0850z7.f16993g = iK;
    }

    @Override // androidx.recyclerview.widget.T
    public int m(h0 h0Var) {
        return M0(h0Var);
    }

    public final void m1(int i10, int i11) {
        this.f16590q.f16989c = this.f16591r.g() - i11;
        C0850z c0850z = this.f16590q;
        c0850z.f16991e = this.f16594u ? -1 : 1;
        c0850z.f16990d = i10;
        c0850z.f16992f = 1;
        c0850z.f16988b = i11;
        c0850z.f16993g = Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.T
    public final int n(h0 h0Var) {
        return K0(h0Var);
    }

    public final void n1(int i10, int i11) {
        this.f16590q.f16989c = i11 - this.f16591r.k();
        C0850z c0850z = this.f16590q;
        c0850z.f16990d = i10;
        c0850z.f16991e = this.f16594u ? 1 : -1;
        c0850z.f16992f = -1;
        c0850z.f16988b = i11;
        c0850z.f16993g = Integer.MIN_VALUE;
    }

    @Override // androidx.recyclerview.widget.T
    public int o(h0 h0Var) {
        return L0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public int p(h0 h0Var) {
        return M0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final View r(int i10) {
        int iW = w();
        if (iW == 0) {
            return null;
        }
        int iM = i10 - T.M(v(0));
        if (iM >= 0 && iM < iW) {
            View viewV = v(iM);
            if (T.M(viewV) == i10) {
                return viewV;
            }
        }
        return super.r(i10);
    }

    @Override // androidx.recyclerview.widget.T
    public RecyclerView.LayoutParams s() {
        return new RecyclerView.LayoutParams(-2, -2);
    }

    @Override // androidx.recyclerview.widget.T
    public int u0(int i10, a0 a0Var, h0 h0Var) {
        if (this.f16589p == 1) {
            return 0;
        }
        return h1(i10, a0Var, h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void v0(int i10) {
        this.f16597x = i10;
        this.f16598y = Integer.MIN_VALUE;
        A a3 = this.f16599z;
        if (a3 != null) {
            a3.f16556a = -1;
        }
        t0();
    }

    @Override // androidx.recyclerview.widget.T
    public int w0(int i10, a0 a0Var, h0 h0Var) {
        if (this.f16589p == 0) {
            return 0;
        }
        return h1(i10, a0Var, h0Var);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i10, int i11) {
        this.f16589p = 1;
        this.f16593t = false;
        this.f16594u = false;
        this.f16595v = false;
        this.f16596w = true;
        this.f16597x = -1;
        this.f16598y = Integer.MIN_VALUE;
        this.f16599z = null;
        this.f16585A = new C0848x();
        this.f16586B = new C0849y();
        this.f16587C = 2;
        this.f16588D = new int[2];
        S sN = T.N(context, attributeSet, i10, i11);
        j1(sN.f16694a);
        boolean z3 = sN.f16696c;
        c(null);
        if (z3 != this.f16593t) {
            this.f16593t = z3;
            t0();
        }
        k1(sN.f16697d);
    }

    @Override // androidx.recyclerview.widget.T
    public final void X(RecyclerView recyclerView) {
    }

    public void d1(a0 a0Var, h0 h0Var, C0848x c0848x, int i10) {
    }
}
