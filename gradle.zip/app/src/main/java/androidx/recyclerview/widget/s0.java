package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public final class s0 implements Parcelable {
    public static final Parcelable.Creator<s0> CREATOR = new p0(1);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16918a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16919b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16920c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int[] f16921d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16922e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int[] f16923f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ArrayList f16924q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f16925r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f16926s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f16927t;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f16918a);
        parcel.writeInt(this.f16919b);
        parcel.writeInt(this.f16920c);
        if (this.f16920c > 0) {
            parcel.writeIntArray(this.f16921d);
        }
        parcel.writeInt(this.f16922e);
        if (this.f16922e > 0) {
            parcel.writeIntArray(this.f16923f);
        }
        parcel.writeInt(this.f16925r ? 1 : 0);
        parcel.writeInt(this.f16926s ? 1 : 0);
        parcel.writeInt(this.f16927t ? 1 : 0);
        parcel.writeList(this.f16924q);
    }
}
