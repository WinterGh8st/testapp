package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import p200r1.C1471b;

/* JADX INFO: loaded from: classes.dex */
public class m0 extends C1471b {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final RecyclerView f16871d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final G1.b f16872e;

    public m0(RecyclerView recyclerView) {
        this.f16871d = recyclerView;
        G1.b bVar = this.f16872e;
        if (bVar != null) {
            this.f16872e = bVar;
        } else {
            this.f16872e = new G1.b(this);
        }
    }

    @Override // p200r1.C1471b
    public final void c(View view, AccessibilityEvent accessibilityEvent) {
        super.c(view, accessibilityEvent);
        if (!(view instanceof RecyclerView) || this.f16871d.O()) {
            return;
        }
        RecyclerView recyclerView = (RecyclerView) view;
        if (recyclerView.getLayoutManager() != null) {
            recyclerView.getLayoutManager().Z(accessibilityEvent);
        }
    }

    @Override // p200r1.C1471b
    public void d(View view, p211s1.i iVar) {
        this.f27696a.onInitializeAccessibilityNodeInfo(view, iVar.f27949a);
        RecyclerView recyclerView = this.f16871d;
        if (recyclerView.O() || recyclerView.getLayoutManager() == null) {
            return;
        }
        T layoutManager = recyclerView.getLayoutManager();
        RecyclerView recyclerView2 = layoutManager.f16722b;
        layoutManager.a0(recyclerView2.f16653c, recyclerView2.f16674r0, iVar);
    }

    @Override // p200r1.C1471b
    public final boolean g(View view, int i10, Bundle bundle) {
        if (super.g(view, i10, bundle)) {
            return true;
        }
        RecyclerView recyclerView = this.f16871d;
        if (recyclerView.O() || recyclerView.getLayoutManager() == null) {
            return false;
        }
        T layoutManager = recyclerView.getLayoutManager();
        RecyclerView recyclerView2 = layoutManager.f16722b;
        return layoutManager.n0(recyclerView2.f16653c, recyclerView2.f16674r0, i10, bundle);
    }
}
