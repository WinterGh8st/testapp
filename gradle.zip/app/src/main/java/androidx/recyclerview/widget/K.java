package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public abstract class K {
    public abstract void a();

    public abstract void b(int i10, int i11, Object obj);

    public abstract void c(int i10, int i11);

    public abstract void d(int i10, int i11);

    public abstract void e(int i10, int i11);

    public void f() {
    }
}
