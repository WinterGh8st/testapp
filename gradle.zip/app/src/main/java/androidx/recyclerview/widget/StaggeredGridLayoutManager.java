package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class StaggeredGridLayoutManager extends T implements f0 {

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final r0 f16699B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final int f16700C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public boolean f16701D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public boolean f16702E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public s0 f16703F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final Rect f16704G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final o0 f16705H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final boolean f16706I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public int[] f16707J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final RunnableC0834i f16708K;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final int f16709p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final t0[] f16710q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final I1.g f16711r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final I1.g f16712s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f16713t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f16714u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final C0847w f16715v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f16716w;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final BitSet f16718y;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f16717x = false;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f16719z = -1;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f16698A = Integer.MIN_VALUE;

    public static class LayoutParams extends RecyclerView.LayoutParams {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public t0 f16720e;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i10, int i11) {
        this.f16709p = -1;
        this.f16716w = false;
        r0 r0Var = new r0();
        this.f16699B = r0Var;
        this.f16700C = 2;
        this.f16704G = new Rect();
        this.f16705H = new o0(this);
        this.f16706I = true;
        this.f16708K = new RunnableC0834i(this, 2);
        S sN = T.N(context, attributeSet, i10, i11);
        int i12 = sN.f16694a;
        if (i12 != 0 && i12 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        c(null);
        if (i12 != this.f16713t) {
            this.f16713t = i12;
            I1.g gVar = this.f16711r;
            this.f16711r = this.f16712s;
            this.f16712s = gVar;
            t0();
        }
        int i13 = sN.f16695b;
        c(null);
        if (i13 != this.f16709p) {
            r0Var.a();
            t0();
            this.f16709p = i13;
            this.f16718y = new BitSet(this.f16709p);
            this.f16710q = new t0[this.f16709p];
            for (int i14 = 0; i14 < this.f16709p; i14++) {
                this.f16710q[i14] = new t0(this, i14);
            }
            t0();
        }
        boolean z3 = sN.f16696c;
        c(null);
        s0 s0Var = this.f16703F;
        if (s0Var != null && s0Var.f16925r != z3) {
            s0Var.f16925r = z3;
        }
        this.f16716w = z3;
        t0();
        C0847w c0847w = new C0847w();
        c0847w.f16969a = true;
        c0847w.f16974f = 0;
        c0847w.f16975g = 0;
        this.f16715v = c0847w;
        this.f16711r = I1.g.a(this, this.f16713t);
        this.f16712s = I1.g.a(this, 1 - this.f16713t);
    }

    public static int k1(int i10, int i11, int i12) {
        int mode;
        return (!(i11 == 0 && i12 == 0) && ((mode = View.MeasureSpec.getMode(i10)) == Integer.MIN_VALUE || mode == 1073741824)) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i10) - i11) - i12), mode) : i10;
    }

    @Override // androidx.recyclerview.widget.T
    public final void F0(RecyclerView recyclerView, int i10) {
        B b10 = new B(recyclerView.getContext());
        b10.f16794a = i10;
        G0(b10);
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean H0() {
        return this.f16703F == null;
    }

    public final boolean I0() {
        int iR0;
        if (w() != 0 && this.f16700C != 0 && this.f16727g) {
            if (this.f16717x) {
                iR0 = S0();
                R0();
            } else {
                iR0 = R0();
                S0();
            }
            r0 r0Var = this.f16699B;
            if (iR0 == 0 && W0() != null) {
                r0Var.a();
                this.f16726f = true;
                t0();
                return true;
            }
        }
        return false;
    }

    public final int J0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        I1.g gVar = this.f16711r;
        boolean z3 = !this.f16706I;
        return p123ja.a.m(h0Var, gVar, O0(z3), N0(z3), this, this.f16706I);
    }

    public final int K0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        I1.g gVar = this.f16711r;
        boolean z3 = !this.f16706I;
        return p123ja.a.n(h0Var, gVar, O0(z3), N0(z3), this, this.f16706I, this.f16717x);
    }

    public final int L0(h0 h0Var) {
        if (w() == 0) {
            return 0;
        }
        I1.g gVar = this.f16711r;
        boolean z3 = !this.f16706I;
        return p123ja.a.o(h0Var, gVar, O0(z3), N0(z3), this, this.f16706I);
    }

    /* JADX WARN: Type inference failed for: r6v20 */
    /* JADX WARN: Type inference failed for: r6v3 */
    /* JADX WARN: Type inference failed for: r6v4, types: [boolean, int] */
    public final int M0(a0 a0Var, C0847w c0847w, h0 h0Var) {
        t0 t0Var;
        ?? r7;
        int i10;
        int iH;
        int iC;
        int iK;
        int iC2;
        int i11;
        int i12;
        int i13;
        int i14 = 0;
        int i15 = 1;
        this.f16718y.set(0, this.f16709p, true);
        C0847w c0847w2 = this.f16715v;
        int i16 = c0847w2.f16977i ? c0847w.f16973e == 1 ? com.google.android.gms.common.api.f.API_PRIORITY_OTHER : Integer.MIN_VALUE : c0847w.f16973e == 1 ? c0847w.f16975g + c0847w.f16970b : c0847w.f16974f - c0847w.f16970b;
        int i17 = c0847w.f16973e;
        for (int i18 = 0; i18 < this.f16709p; i18++) {
            if (!this.f16710q[i18].f16932a.isEmpty()) {
                j1(this.f16710q[i18], i17, i16);
            }
        }
        int iG = this.f16717x ? this.f16711r.g() : this.f16711r.k();
        boolean z3 = false;
        while (true) {
            int i19 = c0847w.f16971c;
            if (((i19 < 0 || i19 >= h0Var.b()) ? i14 : i15) == 0 || (!c0847w2.f16977i && this.f16718y.isEmpty())) {
                break;
            }
            View view = a0Var.k(c0847w.f16971c, Long.MAX_VALUE).itemView;
            c0847w.f16971c += c0847w.f16972d;
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            int layoutPosition = layoutParams.f16690a.getLayoutPosition();
            r0 r0Var = this.f16699B;
            int[] iArr = r0Var.f16914a;
            int i20 = (iArr == null || layoutPosition >= iArr.length) ? -1 : iArr[layoutPosition];
            if (i20 == -1) {
                if (a1(c0847w.f16973e)) {
                    i13 = this.f16709p - i15;
                    i12 = -1;
                    i11 = -1;
                } else {
                    i11 = i15;
                    i12 = this.f16709p;
                    i13 = i14;
                }
                t0 t0Var2 = null;
                if (c0847w.f16973e == i15) {
                    int iK2 = this.f16711r.k();
                    int i21 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
                    while (i13 != i12) {
                        t0 t0Var3 = this.f16710q[i13];
                        int iF = t0Var3.f(iK2);
                        if (iF < i21) {
                            i21 = iF;
                            t0Var2 = t0Var3;
                        }
                        i13 += i11;
                    }
                } else {
                    int iG2 = this.f16711r.g();
                    int i22 = Integer.MIN_VALUE;
                    while (i13 != i12) {
                        t0 t0Var4 = this.f16710q[i13];
                        int iH2 = t0Var4.h(iG2);
                        if (iH2 > i22) {
                            t0Var2 = t0Var4;
                            i22 = iH2;
                        }
                        i13 += i11;
                    }
                }
                t0Var = t0Var2;
                r0Var.b(layoutPosition);
                r0Var.f16914a[layoutPosition] = t0Var.f16936e;
            } else {
                t0Var = this.f16710q[i20];
            }
            layoutParams.f16720e = t0Var;
            if (c0847w.f16973e == 1) {
                r7 = 0;
                b(view, -1, false);
            } else {
                r7 = 0;
                b(view, 0, false);
            }
            if (this.f16713t == 1) {
                i10 = 1;
                Y0(view, T.x(r7, this.f16714u, this.f16731l, r7, ((ViewGroup.MarginLayoutParams) layoutParams).width), T.x(true, this.f16734o, this.f16732m, I() + L(), ((ViewGroup.MarginLayoutParams) layoutParams).height));
            } else {
                i10 = 1;
                Y0(view, T.x(true, this.f16733n, this.f16731l, K() + J(), ((ViewGroup.MarginLayoutParams) layoutParams).width), T.x(false, this.f16714u, this.f16732m, 0, ((ViewGroup.MarginLayoutParams) layoutParams).height));
            }
            if (c0847w.f16973e == i10) {
                iC = t0Var.f(iG);
                iH = this.f16711r.c(view) + iC;
            } else {
                iH = t0Var.h(iG);
                iC = iH - this.f16711r.c(view);
            }
            if (c0847w.f16973e == 1) {
                t0 t0Var5 = layoutParams.f16720e;
                t0Var5.getClass();
                LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                layoutParams2.f16720e = t0Var5;
                ArrayList arrayList = t0Var5.f16932a;
                arrayList.add(view);
                t0Var5.f16934c = Integer.MIN_VALUE;
                if (arrayList.size() == 1) {
                    t0Var5.f16933b = Integer.MIN_VALUE;
                }
                if (layoutParams2.f16690a.isRemoved() || layoutParams2.f16690a.isUpdated()) {
                    t0Var5.f16935d = t0Var5.f16937f.f16711r.c(view) + t0Var5.f16935d;
                }
            } else {
                t0 t0Var6 = layoutParams.f16720e;
                t0Var6.getClass();
                LayoutParams layoutParams3 = (LayoutParams) view.getLayoutParams();
                layoutParams3.f16720e = t0Var6;
                ArrayList arrayList2 = t0Var6.f16932a;
                arrayList2.add(0, view);
                t0Var6.f16933b = Integer.MIN_VALUE;
                if (arrayList2.size() == 1) {
                    t0Var6.f16934c = Integer.MIN_VALUE;
                }
                if (layoutParams3.f16690a.isRemoved() || layoutParams3.f16690a.isUpdated()) {
                    t0Var6.f16935d = t0Var6.f16937f.f16711r.c(view) + t0Var6.f16935d;
                }
            }
            if (X0() && this.f16713t == 1) {
                iC2 = this.f16712s.g() - (((this.f16709p - 1) - t0Var.f16936e) * this.f16714u);
                iK = iC2 - this.f16712s.c(view);
            } else {
                iK = this.f16712s.k() + (t0Var.f16936e * this.f16714u);
                iC2 = this.f16712s.c(view) + iK;
            }
            if (this.f16713t == 1) {
                T.S(view, iK, iC, iC2, iH);
            } else {
                T.S(view, iC, iK, iH, iC2);
            }
            j1(t0Var, c0847w2.f16973e, i16);
            c1(a0Var, c0847w2);
            if (c0847w2.f16976h && view.hasFocusable()) {
                this.f16718y.set(t0Var.f16936e, false);
            }
            i15 = 1;
            z3 = true;
            i14 = 0;
        }
        if (!z3) {
            c1(a0Var, c0847w2);
        }
        int iK3 = c0847w2.f16973e == -1 ? this.f16711r.k() - U0(this.f16711r.k()) : T0(this.f16711r.g()) - this.f16711r.g();
        if (iK3 > 0) {
            return Math.min(c0847w.f16970b, iK3);
        }
        return 0;
    }

    public final View N0(boolean z3) {
        int iK = this.f16711r.k();
        int iG = this.f16711r.g();
        View view = null;
        for (int iW = w() - 1; iW >= 0; iW--) {
            View viewV = v(iW);
            int iE = this.f16711r.e(viewV);
            int iB = this.f16711r.b(viewV);
            if (iB > iK && iE < iG) {
                if (iB <= iG || !z3) {
                    return viewV;
                }
                if (view == null) {
                    view = viewV;
                }
            }
        }
        return view;
    }

    public final View O0(boolean z3) {
        int iK = this.f16711r.k();
        int iG = this.f16711r.g();
        int iW = w();
        View view = null;
        for (int i10 = 0; i10 < iW; i10++) {
            View viewV = v(i10);
            int iE = this.f16711r.e(viewV);
            if (this.f16711r.b(viewV) > iK && iE < iG) {
                if (iE >= iK || !z3) {
                    return viewV;
                }
                if (view == null) {
                    view = viewV;
                }
            }
        }
        return view;
    }

    public final void P0(a0 a0Var, h0 h0Var, boolean z3) {
        int iG;
        int iT0 = T0(Integer.MIN_VALUE);
        if (iT0 != Integer.MIN_VALUE && (iG = this.f16711r.g() - iT0) > 0) {
            int i10 = iG - (-g1(-iG, a0Var, h0Var));
            if (!z3 || i10 <= 0) {
                return;
            }
            this.f16711r.o(i10);
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean Q() {
        return this.f16700C != 0;
    }

    public final void Q0(a0 a0Var, h0 h0Var, boolean z3) {
        int iK;
        int iU0 = U0(com.google.android.gms.common.api.f.API_PRIORITY_OTHER);
        if (iU0 != Integer.MAX_VALUE && (iK = iU0 - this.f16711r.k()) > 0) {
            int iG1 = iK - g1(iK, a0Var, h0Var);
            if (!z3 || iG1 <= 0) {
                return;
            }
            this.f16711r.o(-iG1);
        }
    }

    public final int R0() {
        if (w() == 0) {
            return 0;
        }
        return T.M(v(0));
    }

    public final int S0() {
        int iW = w();
        if (iW == 0) {
            return 0;
        }
        return T.M(v(iW - 1));
    }

    @Override // androidx.recyclerview.widget.T
    public final void T(int i10) {
        super.T(i10);
        for (int i11 = 0; i11 < this.f16709p; i11++) {
            t0 t0Var = this.f16710q[i11];
            int i12 = t0Var.f16933b;
            if (i12 != Integer.MIN_VALUE) {
                t0Var.f16933b = i12 + i10;
            }
            int i13 = t0Var.f16934c;
            if (i13 != Integer.MIN_VALUE) {
                t0Var.f16934c = i13 + i10;
            }
        }
    }

    public final int T0(int i10) {
        int iF = this.f16710q[0].f(i10);
        for (int i11 = 1; i11 < this.f16709p; i11++) {
            int iF2 = this.f16710q[i11].f(i10);
            if (iF2 > iF) {
                iF = iF2;
            }
        }
        return iF;
    }

    @Override // androidx.recyclerview.widget.T
    public final void U(int i10) {
        super.U(i10);
        for (int i11 = 0; i11 < this.f16709p; i11++) {
            t0 t0Var = this.f16710q[i11];
            int i12 = t0Var.f16933b;
            if (i12 != Integer.MIN_VALUE) {
                t0Var.f16933b = i12 + i10;
            }
            int i13 = t0Var.f16934c;
            if (i13 != Integer.MIN_VALUE) {
                t0Var.f16934c = i13 + i10;
            }
        }
    }

    public final int U0(int i10) {
        int iH = this.f16710q[0].h(i10);
        for (int i11 = 1; i11 < this.f16709p; i11++) {
            int iH2 = this.f16710q[i11].h(i10);
            if (iH2 < iH) {
                iH = iH2;
            }
        }
        return iH;
    }

    @Override // androidx.recyclerview.widget.T
    public final void V() {
        this.f16699B.a();
        for (int i10 = 0; i10 < this.f16709p; i10++) {
            this.f16710q[i10].b();
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0030  */
    /* JADX WARN: Code duplicated, block: B:22:0x0032 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:24:0x0035  */
    /* JADX WARN: Code duplicated, block: B:26:0x003d  */
    /* JADX WARN: Code duplicated, block: B:29:0x004a A[LOOP:0: B:25:0x003b->B:29:0x004a, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:30:0x004d A[EDGE_INSN: B:30:0x004d->B:31:0x004e BREAK  A[LOOP:0: B:25:0x003b->B:29:0x004a]] */
    /* JADX WARN: Code duplicated, block: B:32:0x0050  */
    /* JADX WARN: Code duplicated, block: B:35:0x005e  */
    /* JADX WARN: Code duplicated, block: B:38:0x006b A[LOOP:1: B:34:0x005c->B:38:0x006b, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:41:0x0071  */
    /* JADX WARN: Code duplicated, block: B:43:0x0082  */
    /* JADX WARN: Code duplicated, block: B:44:0x008c  */
    /* JADX WARN: Code duplicated, block: B:47:0x009d  */
    /* JADX WARN: Code duplicated, block: B:49:0x00a0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:51:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:52:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:53:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:56:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:58:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:59:0x00bd  */
    /* JADX WARN: Code duplicated, block: B:61:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:63:0x004d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:64:0x004e A[EDGE_INSN: B:64:0x004e->B:31:0x004e BREAK  A[LOOP:0: B:25:0x003b->B:29:0x004a], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:65:0x006e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:66:0x006f A[EDGE_INSN: B:66:0x006f->B:40:0x006f BREAK  A[LOOP:1: B:34:0x005c->B:38:0x006b], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:67:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:68:? A[RETURN, SYNTHETIC] */
    public final void V0(int i10, int i11, int i12) {
        int i13;
        int i14;
        r0 r0Var;
        int[] iArr;
        int iS0;
        ArrayList arrayList;
        q0 q0Var;
        int size;
        int i15;
        int i16;
        int size2;
        int iS1 = this.f16717x ? S0() : R0();
        if (i12 == 8) {
            if (i10 < i11) {
                i13 = i11 + 1;
            } else {
                i13 = i10 + 1;
                i14 = i11;
            }
            r0Var = this.f16699B;
            iArr = r0Var.f16914a;
            if (iArr != null && i14 < iArr.length) {
                arrayList = r0Var.f16915b;
                if (arrayList != null) {
                    if (arrayList == null) {
                        size2 = arrayList.size() - 1;
                        while (true) {
                            if (size2 >= 0) {
                                q0Var = null;
                                break;
                            }
                            q0Var = (q0) r0Var.f16915b.get(size2);
                            if (q0Var.f16895a == i14) {
                                break;
                            } else {
                                size2--;
                            }
                        }
                    } else {
                        q0Var = null;
                        break;
                    }
                    if (q0Var != null) {
                        r0Var.f16915b.remove(q0Var);
                    }
                    size = r0Var.f16915b.size();
                    i15 = 0;
                    while (true) {
                        if (i15 < size) {
                            i15 = -1;
                            break;
                        } else if (((q0) r0Var.f16915b.get(i15)).f16895a >= i14) {
                            break;
                        } else {
                            i15++;
                        }
                    }
                    if (i15 != -1) {
                        q0 q0Var2 = (q0) r0Var.f16915b.get(i15);
                        r0Var.f16915b.remove(i15);
                        i16 = q0Var2.f16895a;
                    } else {
                        i16 = -1;
                    }
                } else {
                    i16 = -1;
                }
                if (i16 == -1) {
                    int[] iArr2 = r0Var.f16914a;
                    Arrays.fill(iArr2, i14, iArr2.length, -1);
                    int length = r0Var.f16914a.length;
                } else {
                    Arrays.fill(r0Var.f16914a, i14, Math.min(i16 + 1, r0Var.f16914a.length), -1);
                }
            }
            if (i12 != 1) {
                r0Var.c(i10, i11);
            } else if (i12 != 2) {
                r0Var.d(i10, i11);
            } else if (i12 == 8) {
                r0Var.d(i10, 1);
                r0Var.c(i11, 1);
            }
            if (i13 <= iS1) {
                return;
            }
            if (this.f16717x) {
                iS0 = R0();
            } else {
                iS0 = S0();
            }
            if (i14 <= iS0) {
                t0();
            }
        }
        i13 = i10 + i11;
        i14 = i10;
        r0Var = this.f16699B;
        iArr = r0Var.f16914a;
        if (iArr != null) {
            arrayList = r0Var.f16915b;
            if (arrayList != null) {
                if (arrayList == null) {
                    size2 = arrayList.size() - 1;
                    while (true) {
                        if (size2 >= 0) {
                            q0Var = null;
                            break;
                        }
                        q0Var = (q0) r0Var.f16915b.get(size2);
                        if (q0Var.f16895a == i14) {
                            break;
                            break;
                        }
                        size2--;
                    }
                } else {
                    q0Var = null;
                    break;
                }
                if (q0Var != null) {
                    r0Var.f16915b.remove(q0Var);
                }
                size = r0Var.f16915b.size();
                i15 = 0;
                while (true) {
                    if (i15 < size) {
                        i15 = -1;
                        break;
                    } else {
                        if (((q0) r0Var.f16915b.get(i15)).f16895a >= i14) {
                            break;
                            break;
                        }
                        i15++;
                    }
                }
                if (i15 != -1) {
                    q0 q0Var3 = (q0) r0Var.f16915b.get(i15);
                    r0Var.f16915b.remove(i15);
                    i16 = q0Var3.f16895a;
                } else {
                    i16 = -1;
                }
            } else {
                i16 = -1;
            }
            if (i16 == -1) {
                int[] iArr3 = r0Var.f16914a;
                Arrays.fill(iArr3, i14, iArr3.length, -1);
                int length2 = r0Var.f16914a.length;
            } else {
                Arrays.fill(r0Var.f16914a, i14, Math.min(i16 + 1, r0Var.f16914a.length), -1);
            }
        }
        if (i12 != 1) {
            r0Var.c(i10, i11);
        } else if (i12 != 2) {
            r0Var.d(i10, i11);
        } else if (i12 == 8) {
            r0Var.d(i10, 1);
            r0Var.c(i11, 1);
        }
        if (i13 <= iS1) {
            return;
        }
        if (this.f16717x) {
            iS0 = R0();
        } else {
            iS0 = S0();
        }
        if (i14 <= iS0) {
            t0();
        }
    }

    /* JADX WARN: Code duplicated, block: B:51:0x00f0  */
    /* JADX WARN: Code duplicated, block: B:52:0x00f2  */
    /* JADX WARN: Code duplicated, block: B:54:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:55:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:68:0x00fa A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:74:0x002c A[SYNTHETIC] */
    public final View W0() {
        boolean z3;
        boolean z5;
        int iW = w();
        int i10 = iW - 1;
        BitSet bitSet = new BitSet(this.f16709p);
        bitSet.set(0, this.f16709p, true);
        byte b10 = (this.f16713t == 1 && X0()) ? (byte) 1 : (byte) -1;
        if (this.f16717x) {
            iW = -1;
        } else {
            i10 = 0;
        }
        int i11 = i10 < iW ? 1 : -1;
        while (i10 != iW) {
            View viewV = v(i10);
            LayoutParams layoutParams = (LayoutParams) viewV.getLayoutParams();
            if (bitSet.get(layoutParams.f16720e.f16936e)) {
                t0 t0Var = layoutParams.f16720e;
                if (this.f16717x) {
                    int i12 = t0Var.f16934c;
                    if (i12 == Integer.MIN_VALUE) {
                        t0Var.a();
                        i12 = t0Var.f16934c;
                    }
                    if (i12 < this.f16711r.g()) {
                        ((LayoutParams) ((View) p096h9.i.h(1, t0Var.f16932a)).getLayoutParams()).getClass();
                        return viewV;
                    }
                } else {
                    int i13 = t0Var.f16933b;
                    if (i13 == Integer.MIN_VALUE) {
                        View view = (View) t0Var.f16932a.get(0);
                        LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                        t0Var.f16933b = t0Var.f16937f.f16711r.e(view);
                        layoutParams2.getClass();
                        i13 = t0Var.f16933b;
                    }
                    if (i13 > this.f16711r.k()) {
                        ((LayoutParams) ((View) t0Var.f16932a.get(0)).getLayoutParams()).getClass();
                        return viewV;
                    }
                }
                bitSet.clear(layoutParams.f16720e.f16936e);
            }
            i10 += i11;
            if (i10 != iW) {
                View viewV2 = v(i10);
                if (this.f16717x) {
                    int iB = this.f16711r.b(viewV);
                    int iB2 = this.f16711r.b(viewV2);
                    if (iB >= iB2) {
                        if (iB == iB2) {
                            if (layoutParams.f16720e.f16936e - ((LayoutParams) viewV2.getLayoutParams()).f16720e.f16936e < 0) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            if (b10 < 0) {
                                z5 = true;
                            } else {
                                z5 = false;
                            }
                            if (z3 != z5) {
                            }
                        } else {
                            continue;
                        }
                    }
                    return viewV;
                }
                int iE = this.f16711r.e(viewV);
                int iE2 = this.f16711r.e(viewV2);
                if (iE <= iE2) {
                    if (iE == iE2) {
                        if (layoutParams.f16720e.f16936e - ((LayoutParams) viewV2.getLayoutParams()).f16720e.f16936e < 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        if (b10 < 0) {
                            z5 = true;
                        } else {
                            z5 = false;
                        }
                        if (z3 != z5) {
                        }
                    } else {
                        continue;
                    }
                }
                return viewV;
            }
        }
        return null;
    }

    @Override // androidx.recyclerview.widget.T
    public final void X(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f16722b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.f16708K);
        }
        for (int i10 = 0; i10 < this.f16709p; i10++) {
            this.f16710q[i10].b();
        }
        recyclerView.requestLayout();
    }

    public final boolean X0() {
        return H() == 1;
    }

    /* JADX WARN: Code duplicated, block: B:31:0x0048  */
    /* JADX WARN: Code duplicated, block: B:37:0x0053  */
    @Override // androidx.recyclerview.widget.T
    public final View Y(View view, int i10, a0 a0Var, h0 h0Var) {
        View viewE;
        int i11;
        if (w() != 0) {
            RecyclerView recyclerView = this.f16722b;
            if (recyclerView == null || (viewE = recyclerView.E(view)) == null || ((ArrayList) this.f16721a.f7158e).contains(viewE)) {
                viewE = null;
            }
            if (viewE != null) {
                f1();
                if (i10 != 1) {
                    if (i10 != 2) {
                        if (i10 != 17) {
                            if (i10 != 33) {
                                if (i10 == 66 ? this.f16713t == 0 : !(i10 != 130 || this.f16713t != 1)) {
                                    i11 = 1;
                                }
                            } else if (this.f16713t == 1) {
                                i11 = -1;
                            }
                            i11 = Integer.MIN_VALUE;
                        } else if (this.f16713t == 0) {
                            i11 = -1;
                        } else {
                            i11 = Integer.MIN_VALUE;
                        }
                    } else if (this.f16713t != 1 && X0()) {
                        i11 = -1;
                    } else {
                        i11 = 1;
                    }
                } else if (this.f16713t != 1 && X0()) {
                    i11 = 1;
                } else {
                    i11 = -1;
                }
                if (i11 != Integer.MIN_VALUE) {
                    LayoutParams layoutParams = (LayoutParams) viewE.getLayoutParams();
                    layoutParams.getClass();
                    t0 t0Var = layoutParams.f16720e;
                    int iS0 = i11 == 1 ? S0() : R0();
                    i1(iS0, h0Var);
                    h1(i11);
                    C0847w c0847w = this.f16715v;
                    c0847w.f16971c = c0847w.f16972d + iS0;
                    c0847w.f16970b = (int) (this.f16711r.l() * 0.33333334f);
                    c0847w.f16976h = true;
                    c0847w.f16969a = false;
                    M0(a0Var, c0847w, h0Var);
                    this.f16701D = this.f16717x;
                    View viewG = t0Var.g(iS0, i11);
                    if (viewG != null && viewG != viewE) {
                        return viewG;
                    }
                    if (a1(i11)) {
                        for (int i12 = this.f16709p - 1; i12 >= 0; i12--) {
                            View viewG2 = this.f16710q[i12].g(iS0, i11);
                            if (viewG2 != null && viewG2 != viewE) {
                                return viewG2;
                            }
                        }
                    } else {
                        for (int i13 = 0; i13 < this.f16709p; i13++) {
                            View viewG3 = this.f16710q[i13].g(iS0, i11);
                            if (viewG3 != null && viewG3 != viewE) {
                                return viewG3;
                            }
                        }
                    }
                    boolean z3 = (this.f16716w ^ true) == (i11 == -1);
                    View viewR = r(z3 ? t0Var.c() : t0Var.d());
                    if (viewR != null && viewR != viewE) {
                        return viewR;
                    }
                    if (a1(i11)) {
                        for (int i14 = this.f16709p - 1; i14 >= 0; i14--) {
                            if (i14 != t0Var.f16936e) {
                                View viewR2 = r(z3 ? this.f16710q[i14].c() : this.f16710q[i14].d());
                                if (viewR2 != null && viewR2 != viewE) {
                                    return viewR2;
                                }
                            }
                        }
                    } else {
                        for (int i15 = 0; i15 < this.f16709p; i15++) {
                            View viewR3 = r(z3 ? this.f16710q[i15].c() : this.f16710q[i15].d());
                            if (viewR3 != null && viewR3 != viewE) {
                                return viewR3;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    public final void Y0(View view, int i10, int i11) {
        Rect rect = this.f16704G;
        d(rect, view);
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int iK1 = k1(i10, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin + rect.right);
        int iK2 = k1(i11, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin + rect.bottom);
        if (C0(view, iK1, iK2, layoutParams)) {
            view.measure(iK1, iK2);
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final void Z(AccessibilityEvent accessibilityEvent) {
        super.Z(accessibilityEvent);
        if (w() > 0) {
            View viewO0 = O0(false);
            View viewN0 = N0(false);
            if (viewO0 == null || viewN0 == null) {
                return;
            }
            int iM = T.M(viewO0);
            int iM2 = T.M(viewN0);
            if (iM < iM2) {
                accessibilityEvent.setFromIndex(iM);
                accessibilityEvent.setToIndex(iM2);
            } else {
                accessibilityEvent.setFromIndex(iM2);
                accessibilityEvent.setToIndex(iM);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:108:0x01a8  */
    /* JADX WARN: Code duplicated, block: B:109:0x01aa  */
    /* JADX WARN: Code duplicated, block: B:123:0x01e1  */
    /* JADX WARN: Code duplicated, block: B:125:0x01ec  */
    /* JADX WARN: Code duplicated, block: B:131:0x01fe  */
    /* JADX WARN: Code duplicated, block: B:133:0x0209  */
    /* JADX WARN: Code duplicated, block: B:255:0x0417  */
    /* JADX WARN: Code duplicated, block: B:266:0x01fc A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:270:0x01fc A[SYNTHETIC] */
    public final void Z0(a0 a0Var, h0 h0Var, boolean z3) {
        boolean z5;
        s0 s0Var;
        int iW;
        int i10;
        int iM;
        int iM2;
        int iW2;
        int i11;
        boolean z10;
        s0 s0Var2 = this.f16703F;
        o0 o0Var = this.f16705H;
        if (!(s0Var2 == null && this.f16719z == -1) && h0Var.b() == 0) {
            o0(a0Var);
            o0Var.a();
            return;
        }
        boolean z11 = (o0Var.f16890e && this.f16719z == -1 && this.f16703F == null) ? false : true;
        r0 r0Var = this.f16699B;
        StaggeredGridLayoutManager staggeredGridLayoutManager = o0Var.f16892g;
        if (z11) {
            o0Var.a();
            s0 s0Var3 = this.f16703F;
            if (s0Var3 != null) {
                int i12 = s0Var3.f16920c;
                if (i12 > 0) {
                    if (i12 == this.f16709p) {
                        for (int i13 = 0; i13 < this.f16709p; i13++) {
                            this.f16710q[i13].b();
                            s0 s0Var4 = this.f16703F;
                            int iG = s0Var4.f16921d[i13];
                            if (iG != Integer.MIN_VALUE) {
                                iG += s0Var4.f16926s ? this.f16711r.g() : this.f16711r.k();
                            }
                            t0 t0Var = this.f16710q[i13];
                            t0Var.f16933b = iG;
                            t0Var.f16934c = iG;
                        }
                    } else {
                        s0Var3.f16921d = null;
                        s0Var3.f16920c = 0;
                        s0Var3.f16922e = 0;
                        s0Var3.f16923f = null;
                        s0Var3.f16924q = null;
                        s0Var3.f16918a = s0Var3.f16919b;
                    }
                }
                s0 s0Var5 = this.f16703F;
                this.f16702E = s0Var5.f16927t;
                boolean z12 = s0Var5.f16925r;
                c(null);
                s0 s0Var6 = this.f16703F;
                if (s0Var6 != null && s0Var6.f16925r != z12) {
                    s0Var6.f16925r = z12;
                }
                this.f16716w = z12;
                t0();
                f1();
                s0 s0Var7 = this.f16703F;
                int i14 = s0Var7.f16918a;
                if (i14 != -1) {
                    this.f16719z = i14;
                    o0Var.f16888c = s0Var7.f16926s;
                } else {
                    o0Var.f16888c = this.f16717x;
                }
                if (s0Var7.f16922e > 1) {
                    r0Var.f16914a = s0Var7.f16923f;
                    r0Var.f16915b = s0Var7.f16924q;
                }
            } else {
                f1();
                o0Var.f16888c = this.f16717x;
            }
            if (h0Var.f16820g || (i11 = this.f16719z) == -1) {
                if (this.f16701D) {
                    int iB = h0Var.b();
                    iW2 = w() - 1;
                    while (true) {
                        if (iW2 < 0) {
                            iM2 = 0;
                            break;
                        }
                        iM2 = T.M(v(iW2));
                        if (iM2 < 0 && iM2 < iB) {
                            break;
                        } else {
                            iW2--;
                        }
                    }
                } else {
                    int iB2 = h0Var.b();
                    iW = w();
                    i10 = 0;
                    while (true) {
                        if (i10 >= iW) {
                            iM2 = 0;
                            break;
                        }
                        iM = T.M(v(i10));
                        if (iM < 0 && iM < iB2) {
                            iM2 = iM;
                            break;
                        }
                        i10++;
                    }
                }
                o0Var.f16886a = iM2;
                o0Var.f16887b = Integer.MIN_VALUE;
            } else if (i11 < 0 || i11 >= h0Var.b()) {
                this.f16719z = -1;
                this.f16698A = Integer.MIN_VALUE;
                if (this.f16701D) {
                    int iB3 = h0Var.b();
                    iW2 = w() - 1;
                    while (true) {
                        if (iW2 < 0) {
                            iM2 = 0;
                            break;
                        } else {
                            iM2 = T.M(v(iW2));
                            if (iM2 < 0) {
                            }
                            iW2--;
                        }
                    }
                } else {
                    int iB4 = h0Var.b();
                    iW = w();
                    i10 = 0;
                    while (true) {
                        if (i10 >= iW) {
                            iM2 = 0;
                            break;
                        } else {
                            iM = T.M(v(i10));
                            if (iM < 0) {
                            }
                            i10++;
                        }
                    }
                }
                o0Var.f16886a = iM2;
                o0Var.f16887b = Integer.MIN_VALUE;
            } else {
                s0 s0Var8 = this.f16703F;
                if (s0Var8 == null || s0Var8.f16918a == -1 || s0Var8.f16920c < 1) {
                    View viewR = r(this.f16719z);
                    if (viewR != null) {
                        o0Var.f16886a = this.f16717x ? S0() : R0();
                        if (this.f16698A != Integer.MIN_VALUE) {
                            if (o0Var.f16888c) {
                                o0Var.f16887b = (this.f16711r.g() - this.f16698A) - this.f16711r.b(viewR);
                            } else {
                                o0Var.f16887b = (this.f16711r.k() + this.f16698A) - this.f16711r.e(viewR);
                            }
                        } else if (this.f16711r.c(viewR) > this.f16711r.l()) {
                            o0Var.f16887b = o0Var.f16888c ? this.f16711r.g() : this.f16711r.k();
                        } else {
                            int iE = this.f16711r.e(viewR) - this.f16711r.k();
                            if (iE < 0) {
                                o0Var.f16887b = -iE;
                            } else {
                                int iG2 = this.f16711r.g() - this.f16711r.b(viewR);
                                if (iG2 < 0) {
                                    o0Var.f16887b = iG2;
                                } else {
                                    o0Var.f16887b = Integer.MIN_VALUE;
                                }
                            }
                        }
                    } else {
                        int i15 = this.f16719z;
                        o0Var.f16886a = i15;
                        int i16 = this.f16698A;
                        if (i16 == Integer.MIN_VALUE) {
                            if (w() != 0) {
                                if ((i15 < R0()) != this.f16717x) {
                                    z10 = false;
                                } else {
                                    z10 = true;
                                }
                            } else if (this.f16717x) {
                                z10 = true;
                            } else {
                                z10 = false;
                            }
                            o0Var.f16888c = z10;
                            o0Var.f16887b = z10 ? staggeredGridLayoutManager.f16711r.g() : staggeredGridLayoutManager.f16711r.k();
                        } else if (o0Var.f16888c) {
                            o0Var.f16887b = staggeredGridLayoutManager.f16711r.g() - i16;
                        } else {
                            o0Var.f16887b = staggeredGridLayoutManager.f16711r.k() + i16;
                        }
                        o0Var.f16889d = true;
                    }
                } else {
                    o0Var.f16887b = Integer.MIN_VALUE;
                    o0Var.f16886a = this.f16719z;
                }
            }
            o0Var.f16890e = true;
        }
        if (this.f16703F == null && this.f16719z == -1 && (o0Var.f16888c != this.f16701D || X0() != this.f16702E)) {
            r0Var.a();
            o0Var.f16889d = true;
        }
        if (w() > 0 && ((s0Var = this.f16703F) == null || s0Var.f16920c < 1)) {
            if (o0Var.f16889d) {
                for (int i17 = 0; i17 < this.f16709p; i17++) {
                    this.f16710q[i17].b();
                    int i18 = o0Var.f16887b;
                    if (i18 != Integer.MIN_VALUE) {
                        t0 t0Var2 = this.f16710q[i17];
                        t0Var2.f16933b = i18;
                        t0Var2.f16934c = i18;
                    }
                }
            } else if (z11 || o0Var.f16891f == null) {
                for (int i19 = 0; i19 < this.f16709p; i19++) {
                    t0 t0Var3 = this.f16710q[i19];
                    boolean z13 = this.f16717x;
                    int i20 = o0Var.f16887b;
                    int iF = z13 ? t0Var3.f(Integer.MIN_VALUE) : t0Var3.h(Integer.MIN_VALUE);
                    t0Var3.b();
                    if (iF != Integer.MIN_VALUE) {
                        StaggeredGridLayoutManager staggeredGridLayoutManager2 = t0Var3.f16937f;
                        if ((!z13 || iF >= staggeredGridLayoutManager2.f16711r.g()) && (z13 || iF <= staggeredGridLayoutManager2.f16711r.k())) {
                            if (i20 != Integer.MIN_VALUE) {
                                iF += i20;
                            }
                            t0Var3.f16934c = iF;
                            t0Var3.f16933b = iF;
                        }
                    }
                }
                t0[] t0VarArr = this.f16710q;
                int length = t0VarArr.length;
                int[] iArr = o0Var.f16891f;
                if (iArr == null || iArr.length < length) {
                    o0Var.f16891f = new int[staggeredGridLayoutManager.f16710q.length];
                }
                for (int i21 = 0; i21 < length; i21++) {
                    o0Var.f16891f[i21] = t0VarArr[i21].h(Integer.MIN_VALUE);
                }
            } else {
                for (int i22 = 0; i22 < this.f16709p; i22++) {
                    t0 t0Var4 = this.f16710q[i22];
                    t0Var4.b();
                    int i23 = o0Var.f16891f[i22];
                    t0Var4.f16933b = i23;
                    t0Var4.f16934c = i23;
                }
            }
        }
        q(a0Var);
        C0847w c0847w = this.f16715v;
        c0847w.f16969a = false;
        int iL = this.f16712s.l();
        this.f16714u = iL / this.f16709p;
        View.MeasureSpec.makeMeasureSpec(iL, this.f16712s.i());
        i1(o0Var.f16886a, h0Var);
        if (o0Var.f16888c) {
            h1(-1);
            M0(a0Var, c0847w, h0Var);
            h1(1);
            c0847w.f16971c = o0Var.f16886a + c0847w.f16972d;
            M0(a0Var, c0847w, h0Var);
        } else {
            h1(1);
            M0(a0Var, c0847w, h0Var);
            h1(-1);
            c0847w.f16971c = o0Var.f16886a + c0847w.f16972d;
            M0(a0Var, c0847w, h0Var);
        }
        if (this.f16712s.i() != 1073741824) {
            int iW3 = w();
            float fMax = 0.0f;
            for (int i24 = 0; i24 < iW3; i24++) {
                View viewV = v(i24);
                float fC = this.f16712s.c(viewV);
                if (fC >= fMax) {
                    ((LayoutParams) viewV.getLayoutParams()).getClass();
                    fMax = Math.max(fMax, fC);
                }
            }
            int i25 = this.f16714u;
            int iRound = Math.round(fMax * this.f16709p);
            if (this.f16712s.i() == Integer.MIN_VALUE) {
                iRound = Math.min(iRound, this.f16712s.l());
            }
            this.f16714u = iRound / this.f16709p;
            View.MeasureSpec.makeMeasureSpec(iRound, this.f16712s.i());
            if (this.f16714u != i25) {
                for (int i26 = 0; i26 < iW3; i26++) {
                    View viewV2 = v(i26);
                    LayoutParams layoutParams = (LayoutParams) viewV2.getLayoutParams();
                    layoutParams.getClass();
                    if (X0() && this.f16713t == 1) {
                        int i27 = -((this.f16709p - 1) - layoutParams.f16720e.f16936e);
                        viewV2.offsetLeftAndRight((this.f16714u * i27) - (i27 * i25));
                    } else {
                        int i28 = layoutParams.f16720e.f16936e;
                        int i29 = this.f16714u * i28;
                        int i30 = i28 * i25;
                        if (this.f16713t == 1) {
                            viewV2.offsetLeftAndRight(i29 - i30);
                        } else {
                            viewV2.offsetTopAndBottom(i29 - i30);
                        }
                    }
                }
            }
        }
        if (w() > 0) {
            if (this.f16717x) {
                P0(a0Var, h0Var, true);
                Q0(a0Var, h0Var, false);
            } else {
                Q0(a0Var, h0Var, true);
                P0(a0Var, h0Var, false);
            }
        }
        if (z3 && !h0Var.f16820g && this.f16700C != 0 && w() > 0 && W0() != null) {
            RecyclerView recyclerView = this.f16722b;
            if (recyclerView != null) {
                recyclerView.removeCallbacks(this.f16708K);
            }
            z5 = I0();
        }
        if (h0Var.f16820g) {
            o0Var.a();
        }
        this.f16701D = o0Var.f16888c;
        this.f16702E = X0();
        if (z5) {
            o0Var.a();
            Z0(a0Var, h0Var, false);
        }
    }

    /* JADX WARN: Code duplicated, block: B:6:0x000c  */
    @Override // androidx.recyclerview.widget.f0
    public final PointF a(int i10) {
        int i11 = -1;
        if (w() != 0) {
            if ((i10 < R0()) == this.f16717x) {
                i11 = 1;
            }
        } else if (this.f16717x) {
            i11 = 1;
        }
        PointF pointF = new PointF();
        if (i11 == 0) {
            return null;
        }
        if (this.f16713t == 0) {
            pointF.x = i11;
            pointF.y = 0.0f;
            return pointF;
        }
        pointF.x = 0.0f;
        pointF.y = i11;
        return pointF;
    }

    public final boolean a1(int i10) {
        if (this.f16713t == 0) {
            return (i10 == -1) != this.f16717x;
        }
        return ((i10 == -1) == this.f16717x) == X0();
    }

    public final void b1(int i10, h0 h0Var) {
        int iR0;
        int i11;
        if (i10 > 0) {
            iR0 = S0();
            i11 = 1;
        } else {
            iR0 = R0();
            i11 = -1;
        }
        C0847w c0847w = this.f16715v;
        c0847w.f16969a = true;
        i1(iR0, h0Var);
        h1(i11);
        c0847w.f16971c = iR0 + c0847w.f16972d;
        c0847w.f16970b = Math.abs(i10);
    }

    @Override // androidx.recyclerview.widget.T
    public final void c(String str) {
        if (this.f16703F == null) {
            super.c(str);
        }
    }

    public final void c1(a0 a0Var, C0847w c0847w) {
        int iMin;
        if (!c0847w.f16969a || c0847w.f16977i) {
            return;
        }
        if (c0847w.f16970b == 0) {
            if (c0847w.f16973e == -1) {
                d1(a0Var, c0847w.f16975g);
                return;
            } else {
                e1(a0Var, c0847w.f16974f);
                return;
            }
        }
        int i10 = 1;
        if (c0847w.f16973e == -1) {
            int i11 = c0847w.f16974f;
            int iH = this.f16710q[0].h(i11);
            while (i10 < this.f16709p) {
                int iH2 = this.f16710q[i10].h(i11);
                if (iH2 > iH) {
                    iH = iH2;
                }
                i10++;
            }
            int i12 = i11 - iH;
            d1(a0Var, i12 < 0 ? c0847w.f16975g : c0847w.f16975g - Math.min(i12, c0847w.f16970b));
            return;
        }
        int i13 = c0847w.f16975g;
        int iF = this.f16710q[0].f(i13);
        while (i10 < this.f16709p) {
            int iF2 = this.f16710q[i10].f(i13);
            if (iF2 < iF) {
                iF = iF2;
            }
            i10++;
        }
        int i14 = iF - c0847w.f16975g;
        if (i14 < 0) {
            iMin = c0847w.f16974f;
        } else {
            iMin = Math.min(i14, c0847w.f16970b) + c0847w.f16974f;
        }
        e1(a0Var, iMin);
    }

    @Override // androidx.recyclerview.widget.T
    public final void d0(int i10, int i11) {
        V0(i10, i11, 1);
    }

    public final void d1(a0 a0Var, int i10) {
        for (int iW = w() - 1; iW >= 0; iW--) {
            View viewV = v(iW);
            if (this.f16711r.e(viewV) < i10 || this.f16711r.n(viewV) < i10) {
                return;
            }
            LayoutParams layoutParams = (LayoutParams) viewV.getLayoutParams();
            layoutParams.getClass();
            if (layoutParams.f16720e.f16932a.size() == 1) {
                return;
            }
            t0 t0Var = layoutParams.f16720e;
            ArrayList arrayList = t0Var.f16932a;
            int size = arrayList.size();
            View view = (View) arrayList.remove(size - 1);
            LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
            layoutParams2.f16720e = null;
            if (layoutParams2.f16690a.isRemoved() || layoutParams2.f16690a.isUpdated()) {
                t0Var.f16935d -= t0Var.f16937f.f16711r.c(view);
            }
            if (size == 1) {
                t0Var.f16933b = Integer.MIN_VALUE;
            }
            t0Var.f16934c = Integer.MIN_VALUE;
            q0(viewV, a0Var);
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean e() {
        return this.f16713t == 0;
    }

    @Override // androidx.recyclerview.widget.T
    public final void e0() {
        this.f16699B.a();
        t0();
    }

    public final void e1(a0 a0Var, int i10) {
        while (w() > 0) {
            View viewV = v(0);
            if (this.f16711r.b(viewV) > i10 || this.f16711r.m(viewV) > i10) {
                return;
            }
            LayoutParams layoutParams = (LayoutParams) viewV.getLayoutParams();
            layoutParams.getClass();
            if (layoutParams.f16720e.f16932a.size() == 1) {
                return;
            }
            t0 t0Var = layoutParams.f16720e;
            ArrayList arrayList = t0Var.f16932a;
            View view = (View) arrayList.remove(0);
            LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
            layoutParams2.f16720e = null;
            if (arrayList.size() == 0) {
                t0Var.f16934c = Integer.MIN_VALUE;
            }
            if (layoutParams2.f16690a.isRemoved() || layoutParams2.f16690a.isUpdated()) {
                t0Var.f16935d -= t0Var.f16937f.f16711r.c(view);
            }
            t0Var.f16933b = Integer.MIN_VALUE;
            q0(viewV, a0Var);
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean f() {
        return this.f16713t == 1;
    }

    @Override // androidx.recyclerview.widget.T
    public final void f0(int i10, int i11) {
        V0(i10, i11, 8);
    }

    public final void f1() {
        if (this.f16713t == 1 || !X0()) {
            this.f16717x = this.f16716w;
        } else {
            this.f16717x = !this.f16716w;
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final boolean g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // androidx.recyclerview.widget.T
    public final void g0(int i10, int i11) {
        V0(i10, i11, 2);
    }

    public final int g1(int i10, a0 a0Var, h0 h0Var) {
        if (w() == 0 || i10 == 0) {
            return 0;
        }
        b1(i10, h0Var);
        C0847w c0847w = this.f16715v;
        int iM0 = M0(a0Var, c0847w, h0Var);
        if (c0847w.f16970b >= iM0) {
            i10 = i10 < 0 ? -iM0 : iM0;
        }
        this.f16711r.o(-i10);
        this.f16701D = this.f16717x;
        c0847w.f16970b = 0;
        c1(a0Var, c0847w);
        return i10;
    }

    @Override // androidx.recyclerview.widget.T
    public final void h0(int i10, int i11) {
        V0(i10, i11, 4);
    }

    public final void h1(int i10) {
        C0847w c0847w = this.f16715v;
        c0847w.f16973e = i10;
        c0847w.f16972d = this.f16717x != (i10 == -1) ? -1 : 1;
    }

    @Override // androidx.recyclerview.widget.T
    public final void i(int i10, int i11, h0 h0Var, Db.m mVar) {
        C0847w c0847w;
        int iF;
        int iH;
        if (this.f16713t != 0) {
            i10 = i11;
        }
        if (w() == 0 || i10 == 0) {
            return;
        }
        b1(i10, h0Var);
        int[] iArr = this.f16707J;
        if (iArr == null || iArr.length < this.f16709p) {
            this.f16707J = new int[this.f16709p];
        }
        int i12 = 0;
        int i13 = 0;
        while (true) {
            int i14 = this.f16709p;
            c0847w = this.f16715v;
            if (i12 >= i14) {
                break;
            }
            if (c0847w.f16972d == -1) {
                iF = c0847w.f16974f;
                iH = this.f16710q[i12].h(iF);
            } else {
                iF = this.f16710q[i12].f(c0847w.f16975g);
                iH = c0847w.f16975g;
            }
            int i15 = iF - iH;
            if (i15 >= 0) {
                this.f16707J[i13] = i15;
                i13++;
            }
            i12++;
        }
        Arrays.sort(this.f16707J, 0, i13);
        for (int i16 = 0; i16 < i13; i16++) {
            int i17 = c0847w.f16971c;
            if (i17 < 0 || i17 >= h0Var.b()) {
                return;
            }
            mVar.a(c0847w.f16971c, this.f16707J[i16]);
            c0847w.f16971c += c0847w.f16972d;
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final void i0(a0 a0Var, h0 h0Var) {
        Z0(a0Var, h0Var, true);
    }

    public final void i1(int i10, h0 h0Var) {
        int iL;
        int iL2;
        int i11;
        C0847w c0847w = this.f16715v;
        boolean z3 = false;
        c0847w.f16970b = 0;
        c0847w.f16971c = i10;
        B b10 = this.f16725e;
        if (!(b10 != null && b10.f16798e) || (i11 = h0Var.f16814a) == -1) {
            iL = 0;
            iL2 = 0;
        } else {
            if (this.f16717x == (i11 < i10)) {
                iL = this.f16711r.l();
                iL2 = 0;
            } else {
                iL2 = this.f16711r.l();
                iL = 0;
            }
        }
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView == null || !recyclerView.f16673r) {
            c0847w.f16975g = this.f16711r.f() + iL;
            c0847w.f16974f = -iL2;
        } else {
            c0847w.f16974f = this.f16711r.k() - iL2;
            c0847w.f16975g = this.f16711r.g() + iL;
        }
        c0847w.f16976h = false;
        c0847w.f16969a = true;
        if (this.f16711r.i() == 0 && this.f16711r.f() == 0) {
            z3 = true;
        }
        c0847w.f16977i = z3;
    }

    @Override // androidx.recyclerview.widget.T
    public final void j0(h0 h0Var) {
        this.f16719z = -1;
        this.f16698A = Integer.MIN_VALUE;
        this.f16703F = null;
        this.f16705H.a();
    }

    public final void j1(t0 t0Var, int i10, int i11) {
        int i12 = t0Var.f16935d;
        int i13 = t0Var.f16936e;
        if (i10 != -1) {
            int i14 = t0Var.f16934c;
            if (i14 == Integer.MIN_VALUE) {
                t0Var.a();
                i14 = t0Var.f16934c;
            }
            if (i14 - i12 >= i11) {
                this.f16718y.set(i13, false);
                return;
            }
            return;
        }
        int i15 = t0Var.f16933b;
        if (i15 == Integer.MIN_VALUE) {
            View view = (View) t0Var.f16932a.get(0);
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            t0Var.f16933b = t0Var.f16937f.f16711r.e(view);
            layoutParams.getClass();
            i15 = t0Var.f16933b;
        }
        if (i15 + i12 <= i11) {
            this.f16718y.set(i13, false);
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final int k(h0 h0Var) {
        return J0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void k0(Parcelable parcelable) {
        if (parcelable instanceof s0) {
            s0 s0Var = (s0) parcelable;
            this.f16703F = s0Var;
            if (this.f16719z != -1) {
                s0Var.f16921d = null;
                s0Var.f16920c = 0;
                s0Var.f16918a = -1;
                s0Var.f16919b = -1;
                s0Var.f16921d = null;
                s0Var.f16920c = 0;
                s0Var.f16922e = 0;
                s0Var.f16923f = null;
                s0Var.f16924q = null;
            }
            t0();
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final int l(h0 h0Var) {
        return K0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final Parcelable l0() {
        int iH;
        int iK;
        int[] iArr;
        s0 s0Var = this.f16703F;
        if (s0Var != null) {
            s0 s0Var2 = new s0();
            s0Var2.f16920c = s0Var.f16920c;
            s0Var2.f16918a = s0Var.f16918a;
            s0Var2.f16919b = s0Var.f16919b;
            s0Var2.f16921d = s0Var.f16921d;
            s0Var2.f16922e = s0Var.f16922e;
            s0Var2.f16923f = s0Var.f16923f;
            s0Var2.f16925r = s0Var.f16925r;
            s0Var2.f16926s = s0Var.f16926s;
            s0Var2.f16927t = s0Var.f16927t;
            s0Var2.f16924q = s0Var.f16924q;
            return s0Var2;
        }
        s0 s0Var3 = new s0();
        s0Var3.f16925r = this.f16716w;
        s0Var3.f16926s = this.f16701D;
        s0Var3.f16927t = this.f16702E;
        r0 r0Var = this.f16699B;
        if (r0Var == null || (iArr = r0Var.f16914a) == null) {
            s0Var3.f16922e = 0;
        } else {
            s0Var3.f16923f = iArr;
            s0Var3.f16922e = iArr.length;
            s0Var3.f16924q = r0Var.f16915b;
        }
        if (w() <= 0) {
            s0Var3.f16918a = -1;
            s0Var3.f16919b = -1;
            s0Var3.f16920c = 0;
            return s0Var3;
        }
        s0Var3.f16918a = this.f16701D ? S0() : R0();
        View viewN0 = this.f16717x ? N0(true) : O0(true);
        s0Var3.f16919b = viewN0 != null ? T.M(viewN0) : -1;
        int i10 = this.f16709p;
        s0Var3.f16920c = i10;
        s0Var3.f16921d = new int[i10];
        for (int i11 = 0; i11 < this.f16709p; i11++) {
            if (this.f16701D) {
                iH = this.f16710q[i11].f(Integer.MIN_VALUE);
                if (iH != Integer.MIN_VALUE) {
                    iK = this.f16711r.g();
                    iH -= iK;
                }
            } else {
                iH = this.f16710q[i11].h(Integer.MIN_VALUE);
                if (iH != Integer.MIN_VALUE) {
                    iK = this.f16711r.k();
                    iH -= iK;
                }
            }
            s0Var3.f16921d[i11] = iH;
        }
        return s0Var3;
    }

    @Override // androidx.recyclerview.widget.T
    public final int m(h0 h0Var) {
        return L0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void m0(int i10) {
        if (i10 == 0) {
            I0();
        }
    }

    @Override // androidx.recyclerview.widget.T
    public final int n(h0 h0Var) {
        return J0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final int o(h0 h0Var) {
        return K0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final int p(h0 h0Var) {
        return L0(h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams s() {
        return this.f16713t == 0 ? new LayoutParams(-2, -1) : new LayoutParams(-1, -2);
    }

    @Override // androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams t(Context context, AttributeSet attributeSet) {
        return new LayoutParams(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.T
    public final RecyclerView.LayoutParams u(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    @Override // androidx.recyclerview.widget.T
    public final int u0(int i10, a0 a0Var, h0 h0Var) {
        return g1(i10, a0Var, h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void v0(int i10) {
        s0 s0Var = this.f16703F;
        if (s0Var != null && s0Var.f16918a != i10) {
            s0Var.f16921d = null;
            s0Var.f16920c = 0;
            s0Var.f16918a = -1;
            s0Var.f16919b = -1;
        }
        this.f16719z = i10;
        this.f16698A = Integer.MIN_VALUE;
        t0();
    }

    @Override // androidx.recyclerview.widget.T
    public final int w0(int i10, a0 a0Var, h0 h0Var) {
        return g1(i10, a0Var, h0Var);
    }

    @Override // androidx.recyclerview.widget.T
    public final void z0(Rect rect, int i10, int i11) {
        int iH;
        int iH2;
        int i12 = this.f16709p;
        int iK = K() + J();
        int I10 = I() + L();
        if (this.f16713t == 1) {
            int iHeight = rect.height() + I10;
            RecyclerView recyclerView = this.f16722b;
            WeakHashMap weakHashMap = p200r1.U.f27683a;
            iH2 = T.h(i11, iHeight, recyclerView.getMinimumHeight());
            iH = T.h(i10, (this.f16714u * i12) + iK, this.f16722b.getMinimumWidth());
        } else {
            int iWidth = rect.width() + iK;
            RecyclerView recyclerView2 = this.f16722b;
            WeakHashMap weakHashMap2 = p200r1.U.f27683a;
            iH = T.h(i10, iWidth, recyclerView2.getMinimumWidth());
            iH2 = T.h(i11, (this.f16714u * i12) + I10, this.f16722b.getMinimumHeight());
        }
        this.f16722b.setMeasuredDimension(iH, iH2);
    }
}
