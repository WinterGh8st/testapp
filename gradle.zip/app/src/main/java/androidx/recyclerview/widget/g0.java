package androidx.recyclerview.widget;

import android.graphics.PointF;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;

/* JADX INFO: loaded from: classes.dex */
public abstract class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16794a = -1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public RecyclerView f16795b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public T f16796c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16797d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16798e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public View f16799f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final e0 f16800g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16801h;

    public g0() {
        e0 e0Var = new e0();
        e0Var.f16779d = -1;
        e0Var.f16781f = false;
        e0Var.f16782g = 0;
        e0Var.f16776a = 0;
        e0Var.f16777b = 0;
        e0Var.f16778c = Integer.MIN_VALUE;
        e0Var.f16780e = null;
        this.f16800g = e0Var;
    }

    public PointF a(int i10) {
        Object obj = this.f16796c;
        if (obj instanceof f0) {
            return ((f0) obj).a(i10);
        }
        Log.w("RecyclerView", "You should override computeScrollVectorForPosition when the LayoutManager does not implement " + f0.class.getCanonicalName());
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:50:0x00fb  */
    public final void b(int i10, int i11) {
        PointF pointFA;
        RecyclerView recyclerView = this.f16795b;
        if (this.f16794a == -1 || recyclerView == null) {
            d();
        }
        if (this.f16797d && this.f16799f == null && this.f16796c != null && (pointFA = a(this.f16794a)) != null) {
            float f10 = pointFA.x;
            if (f10 != 0.0f || pointFA.y != 0.0f) {
                recyclerView.g0((int) Math.signum(f10), (int) Math.signum(pointFA.y), null);
            }
        }
        this.f16797d = false;
        View view = this.f16799f;
        e0 e0Var = this.f16800g;
        if (view != null) {
            this.f16795b.getClass();
            l0 l0VarM = RecyclerView.M(view);
            if ((l0VarM != null ? l0VarM.getLayoutPosition() : -1) == this.f16794a) {
                View view2 = this.f16799f;
                h0 h0Var = recyclerView.f16674r0;
                c(view2, e0Var);
                e0Var.a(recyclerView);
                d();
            } else {
                Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                this.f16799f = null;
            }
        }
        if (this.f16798e) {
            h0 h0Var2 = recyclerView.f16674r0;
            B b10 = (B) this;
            if (b10.f16795b.f16684x.w() == 0) {
                b10.d();
            } else {
                int i12 = b10.f16564o;
                int i13 = i12 - i10;
                if (i12 * i13 <= 0) {
                    i13 = 0;
                }
                b10.f16564o = i13;
                int i14 = b10.f16565p;
                int i15 = i14 - i11;
                if (i14 * i15 <= 0) {
                    i15 = 0;
                }
                b10.f16565p = i15;
                if (i13 == 0 && i15 == 0) {
                    PointF pointFA2 = b10.a(b10.f16794a);
                    if (pointFA2 != null) {
                        float f11 = pointFA2.x;
                        if (f11 == 0.0f && pointFA2.y == 0.0f) {
                            e0Var.f16779d = b10.f16794a;
                            b10.d();
                        } else {
                            float f12 = pointFA2.y;
                            float fSqrt = (float) Math.sqrt((f12 * f12) + (f11 * f11));
                            float f13 = pointFA2.x / fSqrt;
                            pointFA2.x = f13;
                            float f14 = pointFA2.y / fSqrt;
                            pointFA2.y = f14;
                            b10.k = pointFA2;
                            b10.f16564o = (int) (f13 * 10000.0f);
                            b10.f16565p = (int) (f14 * 10000.0f);
                            int i16 = b10.i(10000);
                            int i17 = (int) (b10.f16564o * 1.2f);
                            int i18 = (int) (b10.f16565p * 1.2f);
                            LinearInterpolator linearInterpolator = b10.f16559i;
                            e0Var.f16776a = i17;
                            e0Var.f16777b = i18;
                            e0Var.f16778c = (int) (i16 * 1.2f);
                            e0Var.f16780e = linearInterpolator;
                            e0Var.f16781f = true;
                        }
                    } else {
                        e0Var.f16779d = b10.f16794a;
                        b10.d();
                    }
                }
            }
            boolean z3 = e0Var.f16779d >= 0;
            e0Var.a(recyclerView);
            if (z3 && this.f16798e) {
                this.f16797d = true;
                recyclerView.f16669o0.b();
            }
        }
    }

    public abstract void c(View view, e0 e0Var);

    public final void d() {
        if (this.f16798e) {
            this.f16798e = false;
            B b10 = (B) this;
            b10.f16565p = 0;
            b10.f16564o = 0;
            b10.k = null;
            this.f16795b.f16674r0.f16814a = -1;
            this.f16799f = null;
            this.f16794a = -1;
            this.f16797d = false;
            T t10 = this.f16796c;
            if (t10.f16725e == this) {
                t10.f16725e = null;
            }
            this.f16796c = null;
            this.f16795b = null;
        }
    }
}
