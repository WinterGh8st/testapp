package androidx.recyclerview.widget;

/* JADX INFO: loaded from: classes.dex */
public final class S {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16694a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16695b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16696c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16697d;
}
