package androidx.recyclerview.widget;

/* JADX INFO: renamed from: androidx.recyclerview.widget.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0849y {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16983a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16984b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16985c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16986d;
}
