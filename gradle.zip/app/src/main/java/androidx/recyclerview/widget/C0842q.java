package androidx.recyclerview.widget;

import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import com.stripe.android.view.PaymentMethodsRecyclerView;
import java.util.ArrayList;

/* JADX INFO: renamed from: androidx.recyclerview.widget.q, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0842q implements W {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ C0846v f16894a;

    public C0842q(C0846v c0846v) {
        this.f16894a = c0846v;
    }

    @Override // androidx.recyclerview.widget.W
    public final void b(MotionEvent motionEvent) {
        C0846v c0846v = this.f16894a;
        ((GestureDetector) c0846v.f16962x.f22727a).onTouchEvent(motionEvent);
        VelocityTracker velocityTracker = c0846v.f16958t;
        if (velocityTracker != null) {
            velocityTracker.addMovement(motionEvent);
        }
        if (c0846v.f16950l == -1) {
            return;
        }
        int actionMasked = motionEvent.getActionMasked();
        int iFindPointerIndex = motionEvent.findPointerIndex(c0846v.f16950l);
        if (iFindPointerIndex >= 0) {
            c0846v.j(actionMasked, iFindPointerIndex, motionEvent);
        }
        l0 l0Var = c0846v.f16942c;
        if (l0Var == null) {
            return;
        }
        if (actionMasked != 1) {
            if (actionMasked == 2) {
                if (iFindPointerIndex >= 0) {
                    c0846v.s(c0846v.f16953o, iFindPointerIndex, motionEvent);
                    c0846v.p(l0Var);
                    PaymentMethodsRecyclerView paymentMethodsRecyclerView = c0846v.f16956r;
                    RunnableC0834i runnableC0834i = c0846v.f16957s;
                    paymentMethodsRecyclerView.removeCallbacks(runnableC0834i);
                    runnableC0834i.run();
                    c0846v.f16956r.invalidate();
                    return;
                }
                return;
            }
            if (actionMasked != 3) {
                if (actionMasked != 6) {
                    return;
                }
                int actionIndex = motionEvent.getActionIndex();
                if (motionEvent.getPointerId(actionIndex) == c0846v.f16950l) {
                    c0846v.f16950l = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                    c0846v.s(c0846v.f16953o, actionIndex, motionEvent);
                    return;
                }
                return;
            }
            VelocityTracker velocityTracker2 = c0846v.f16958t;
            if (velocityTracker2 != null) {
                velocityTracker2.clear();
            }
        }
        c0846v.r(null, 0);
        c0846v.f16950l = -1;
    }

    @Override // androidx.recyclerview.widget.W
    public final boolean c(MotionEvent motionEvent) {
        int iFindPointerIndex;
        C0846v c0846v = this.f16894a;
        ((GestureDetector) c0846v.f16962x.f22727a).onTouchEvent(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        r rVar = null;
        if (actionMasked == 0) {
            c0846v.f16950l = motionEvent.getPointerId(0);
            c0846v.f16943d = motionEvent.getX();
            c0846v.f16944e = motionEvent.getY();
            VelocityTracker velocityTracker = c0846v.f16958t;
            if (velocityTracker != null) {
                velocityTracker.recycle();
            }
            c0846v.f16958t = VelocityTracker.obtain();
            if (c0846v.f16942c == null) {
                ArrayList arrayList = c0846v.f16954p;
                if (!arrayList.isEmpty()) {
                    View viewM = c0846v.m(motionEvent);
                    for (int size = arrayList.size() - 1; size >= 0; size--) {
                        r rVar2 = (r) arrayList.get(size);
                        if (rVar2.f16903e.itemView == viewM) {
                            rVar = rVar2;
                            break;
                        }
                    }
                }
                if (rVar != null) {
                    c0846v.f16943d -= rVar.f16907i;
                    c0846v.f16944e -= rVar.f16908j;
                    l0 l0Var = rVar.f16903e;
                    c0846v.l(l0Var, true);
                    if (c0846v.f16940a.remove(l0Var.itemView)) {
                        c0846v.f16951m.getClass();
                        AbstractC0844t.a(l0Var);
                    }
                    c0846v.r(l0Var, rVar.f16904f);
                    c0846v.s(c0846v.f16953o, 0, motionEvent);
                }
            }
        } else if (actionMasked == 3 || actionMasked == 1) {
            c0846v.f16950l = -1;
            c0846v.r(null, 0);
        } else {
            int i10 = c0846v.f16950l;
            if (i10 != -1 && (iFindPointerIndex = motionEvent.findPointerIndex(i10)) >= 0) {
                c0846v.j(actionMasked, iFindPointerIndex, motionEvent);
            }
        }
        VelocityTracker velocityTracker2 = c0846v.f16958t;
        if (velocityTracker2 != null) {
            velocityTracker2.addMovement(motionEvent);
        }
        return c0846v.f16942c != null;
    }

    @Override // androidx.recyclerview.widget.W
    public final void e(boolean z3) {
        if (z3) {
            this.f16894a.r(null, 0);
        }
    }
}
