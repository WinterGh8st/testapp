package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public final class r implements Animator.AnimatorListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f16899a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f16900b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f16901c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f16902d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final l0 f16903e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f16904f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final ValueAnimator f16905g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16906h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public float f16907i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public float f16908j;
    public boolean k = false;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f16909l = false;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public float f16910m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final /* synthetic */ int f16911n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final /* synthetic */ l0 f16912o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final /* synthetic */ C0846v f16913p;

    public r(C0846v c0846v, l0 l0Var, int i10, float f10, float f11, float f12, float f13, int i11, l0 l0Var2) {
        this.f16913p = c0846v;
        this.f16911n = i11;
        this.f16912o = l0Var2;
        this.f16904f = i10;
        this.f16903e = l0Var;
        this.f16899a = f10;
        this.f16900b = f11;
        this.f16901c = f12;
        this.f16902d = f13;
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f16905g = valueAnimatorOfFloat;
        valueAnimatorOfFloat.addUpdateListener(new C0837l(this, 1));
        valueAnimatorOfFloat.setTarget(l0Var.itemView);
        valueAnimatorOfFloat.addListener(this);
        this.f16910m = 0.0f;
    }

    public final void a(Animator animator) {
        if (!this.f16909l) {
            this.f16903e.setIsRecyclable(true);
        }
        this.f16909l = true;
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        this.f16910m = 1.0f;
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        a(animator);
        if (this.k) {
            return;
        }
        int i10 = this.f16911n;
        l0 l0Var = this.f16912o;
        C0846v c0846v = this.f16913p;
        if (i10 <= 0) {
            c0846v.f16951m.getClass();
            AbstractC0844t.a(l0Var);
        } else {
            c0846v.f16940a.add(l0Var.itemView);
            this.f16906h = true;
            if (i10 > 0) {
                c0846v.f16956r.post(new A5.b(c0846v, this, i10));
            }
        }
        View view = c0846v.f16961w;
        View view2 = l0Var.itemView;
        if (view == view2) {
            c0846v.q(view2);
        }
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationRepeat(Animator animator) {
    }

    @Override // android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
    }
}
