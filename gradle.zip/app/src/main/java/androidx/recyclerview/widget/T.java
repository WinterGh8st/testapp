package androidx.recyclerview.widget;

import H9.C0337f;
import L.AbstractC0492c;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class T {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Ka.A f16721a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public RecyclerView f16722b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final O2.k f16723c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final O2.k f16724d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public B f16725e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f16726f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f16727g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final boolean f16728h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final boolean f16729i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f16730j;
    public boolean k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f16731l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f16732m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int f16733n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f16734o;

    public T() {
        P p10 = new P(this);
        Q q10 = new Q(this);
        this.f16723c = new O2.k((u0) p10);
        this.f16724d = new O2.k((u0) q10);
        this.f16726f = false;
        this.f16727g = false;
        this.f16728h = true;
        this.f16729i = true;
    }

    public static int B(View view) {
        return view.getLeft() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b.left;
    }

    public static int C(View view) {
        Rect rect = ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b;
        return view.getMeasuredHeight() + rect.top + rect.bottom;
    }

    public static int D(View view) {
        Rect rect = ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b;
        return view.getMeasuredWidth() + rect.left + rect.right;
    }

    public static int E(View view) {
        return view.getRight() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b.right;
    }

    public static int F(View view) {
        return view.getTop() - ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b.top;
    }

    public static int M(View view) {
        return ((RecyclerView.LayoutParams) view.getLayoutParams()).f16690a.getLayoutPosition();
    }

    public static S N(Context context, AttributeSet attributeSet, int i10, int i11) {
        S s5 = new S();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p064f2.a.f22321a, i10, i11);
        s5.f16694a = typedArrayObtainStyledAttributes.getInt(0, 1);
        s5.f16695b = typedArrayObtainStyledAttributes.getInt(10, 1);
        s5.f16696c = typedArrayObtainStyledAttributes.getBoolean(9, false);
        s5.f16697d = typedArrayObtainStyledAttributes.getBoolean(11, false);
        typedArrayObtainStyledAttributes.recycle();
        return s5;
    }

    public static boolean R(int i10, int i11, int i12) {
        int mode = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i11);
        if (i12 > 0 && i10 != i12) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i10;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i10;
        }
        return true;
    }

    public static void S(View view, int i10, int i11, int i12, int i13) {
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        Rect rect = layoutParams.f16691b;
        view.layout(i10 + rect.left + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i11 + rect.top + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, (i12 - rect.right) - ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, (i13 - rect.bottom) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
    }

    public static int h(int i10, int i11, int i12) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        if (mode != Integer.MIN_VALUE) {
            return mode != 1073741824 ? Math.max(i11, i12) : size;
        }
        return Math.min(size, Math.max(i11, i12));
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001a  */
    /* JADX WARN: Code duplicated, block: B:14:0x0022  */
    /* JADX WARN: Code duplicated, block: B:5:0x0010  */
    public static int x(boolean z3, int i10, int i11, int i12, int i13) {
        int iMax = Math.max(0, i10 - i12);
        if (z3) {
            if (i13 >= 0) {
                i11 = 1073741824;
            } else if (i13 != -1 || (i11 != Integer.MIN_VALUE && (i11 == 0 || i11 != 1073741824))) {
                i11 = 0;
                i13 = 0;
            } else {
                i13 = iMax;
            }
        } else if (i13 >= 0) {
            i11 = 1073741824;
        } else if (i13 == -1) {
            i13 = iMax;
        } else if (i13 != -2) {
            i11 = 0;
            i13 = 0;
        } else if (i11 == Integer.MIN_VALUE || i11 == 1073741824) {
            i13 = iMax;
            i11 = Integer.MIN_VALUE;
        } else {
            i13 = iMax;
            i11 = 0;
        }
        return View.MeasureSpec.makeMeasureSpec(i13, i11);
    }

    public static int z(View view) {
        return view.getBottom() + ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b.bottom;
    }

    public void A(Rect rect, View view) {
        boolean z3 = RecyclerView.f16608K0;
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        Rect rect2 = layoutParams.f16691b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
    }

    public final void A0(int i10, int i11) {
        int iW = w();
        if (iW == 0) {
            this.f16722b.q(i10, i11);
            return;
        }
        int i12 = Integer.MIN_VALUE;
        int i13 = Integer.MAX_VALUE;
        int i14 = Integer.MIN_VALUE;
        int i15 = Integer.MAX_VALUE;
        for (int i16 = 0; i16 < iW; i16++) {
            View viewV = v(i16);
            Rect rect = this.f16722b.f16677t;
            A(rect, viewV);
            int i17 = rect.left;
            if (i17 < i15) {
                i15 = i17;
            }
            int i18 = rect.right;
            if (i18 > i12) {
                i12 = i18;
            }
            int i19 = rect.top;
            if (i19 < i13) {
                i13 = i19;
            }
            int i20 = rect.bottom;
            if (i20 > i14) {
                i14 = i20;
            }
        }
        this.f16722b.f16677t.set(i15, i13, i12, i14);
        z0(this.f16722b.f16677t, i10, i11);
    }

    public final void B0(RecyclerView recyclerView) {
        if (recyclerView == null) {
            this.f16722b = null;
            this.f16721a = null;
            this.f16733n = 0;
            this.f16734o = 0;
        } else {
            this.f16722b = recyclerView;
            this.f16721a = recyclerView.f16659f;
            this.f16733n = recyclerView.getWidth();
            this.f16734o = recyclerView.getHeight();
        }
        this.f16731l = 1073741824;
        this.f16732m = 1073741824;
    }

    public final boolean C0(View view, int i10, int i11, RecyclerView.LayoutParams layoutParams) {
        return (!view.isLayoutRequested() && this.f16728h && R(view.getWidth(), i10, ((ViewGroup.MarginLayoutParams) layoutParams).width) && R(view.getHeight(), i11, ((ViewGroup.MarginLayoutParams) layoutParams).height)) ? false : true;
    }

    public boolean D0() {
        return false;
    }

    public final boolean E0(View view, int i10, int i11, RecyclerView.LayoutParams layoutParams) {
        return (this.f16728h && R(view.getMeasuredWidth(), i10, ((ViewGroup.MarginLayoutParams) layoutParams).width) && R(view.getMeasuredHeight(), i11, ((ViewGroup.MarginLayoutParams) layoutParams).height)) ? false : true;
    }

    public abstract void F0(RecyclerView recyclerView, int i10);

    public final int G() {
        RecyclerView recyclerView = this.f16722b;
        I adapter = recyclerView != null ? recyclerView.getAdapter() : null;
        if (adapter != null) {
            return adapter.getItemCount();
        }
        return 0;
    }

    public final void G0(B b10) {
        B b11 = this.f16725e;
        if (b11 != null && b10 != b11 && b11.f16798e) {
            b11.d();
        }
        this.f16725e = b10;
        RecyclerView recyclerView = this.f16722b;
        k0 k0Var = recyclerView.f16669o0;
        k0Var.f16839q.removeCallbacks(k0Var);
        k0Var.f16835c.abortAnimation();
        if (b10.f16801h) {
            Log.w("RecyclerView", "An instance of " + b10.getClass().getSimpleName() + " was started more than once. Each instance of" + b10.getClass().getSimpleName() + " is intended to only be used once. You should create a new instance for each use.");
        }
        b10.f16795b = recyclerView;
        b10.f16796c = this;
        int i10 = b10.f16794a;
        if (i10 == -1) {
            throw new IllegalArgumentException("Invalid target position");
        }
        recyclerView.f16674r0.f16814a = i10;
        b10.f16798e = true;
        b10.f16797d = true;
        b10.f16799f = recyclerView.f16684x.r(i10);
        b10.f16795b.f16669o0.b();
        b10.f16801h = true;
    }

    public final int H() {
        RecyclerView recyclerView = this.f16722b;
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        return recyclerView.getLayoutDirection();
    }

    public boolean H0() {
        return false;
    }

    public final int I() {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            return recyclerView.getPaddingBottom();
        }
        return 0;
    }

    public final int J() {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            return recyclerView.getPaddingLeft();
        }
        return 0;
    }

    public final int K() {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            return recyclerView.getPaddingRight();
        }
        return 0;
    }

    public final int L() {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            return recyclerView.getPaddingTop();
        }
        return 0;
    }

    public int O(a0 a0Var, h0 h0Var) {
        return -1;
    }

    public final void P(Rect rect, View view) {
        Matrix matrix;
        Rect rect2 = ((RecyclerView.LayoutParams) view.getLayoutParams()).f16691b;
        rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
        if (this.f16722b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
            RectF rectF = this.f16722b.f16681v;
            rectF.set(rect);
            matrix.mapRect(rectF);
            rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
        }
        rect.offset(view.getLeft(), view.getTop());
    }

    public abstract boolean Q();

    public void T(int i10) {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            int iD = recyclerView.f16659f.D();
            for (int i11 = 0; i11 < iD; i11++) {
                recyclerView.f16659f.C(i11).offsetLeftAndRight(i10);
            }
        }
    }

    public void U(int i10) {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            int iD = recyclerView.f16659f.D();
            for (int i11 = 0; i11 < iD; i11++) {
                recyclerView.f16659f.C(i11).offsetTopAndBottom(i10);
            }
        }
    }

    public abstract void X(RecyclerView recyclerView);

    public abstract View Y(View view, int i10, a0 a0Var, h0 h0Var);

    public void Z(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.f16722b;
        a0 a0Var = recyclerView.f16653c;
        if (accessibilityEvent == null) {
            return;
        }
        boolean z3 = true;
        if (!recyclerView.canScrollVertically(1) && !this.f16722b.canScrollVertically(-1) && !this.f16722b.canScrollHorizontally(-1) && !this.f16722b.canScrollHorizontally(1)) {
            z3 = false;
        }
        accessibilityEvent.setScrollable(z3);
        I i10 = this.f16722b.f16682w;
        if (i10 != null) {
            accessibilityEvent.setItemCount(i10.getItemCount());
        }
    }

    public void a0(a0 a0Var, h0 h0Var, p211s1.i iVar) {
        if (this.f16722b.canScrollVertically(-1) || this.f16722b.canScrollHorizontally(-1)) {
            iVar.a(8192);
            iVar.p(true);
        }
        if (this.f16722b.canScrollVertically(1) || this.f16722b.canScrollHorizontally(1)) {
            iVar.a(4096);
            iVar.p(true);
        }
        iVar.l(p088h1.g.s(O(a0Var, h0Var), y(a0Var, h0Var), 0));
    }

    /* JADX WARN: Code duplicated, block: B:21:0x0063  */
    public final void b(View view, int i10, boolean z3) {
        int iB;
        l0 l0VarM = RecyclerView.M(view);
        if (z3 || l0VarM.isRemoved()) {
            p240v.k kVar = (p240v.k) this.f16722b.f16671q.f9772b;
            v0 v0VarA = (v0) kVar.getOrDefault(l0VarM, null);
            if (v0VarA == null) {
                v0VarA = v0.a();
                kVar.put(l0VarM, v0VarA);
            }
            v0VarA.f16966a |= 1;
        } else {
            this.f16722b.f16671q.x(l0VarM);
        }
        RecyclerView.LayoutParams layoutParams = (RecyclerView.LayoutParams) view.getLayoutParams();
        if (l0VarM.wasReturnedFromScrap() || l0VarM.isScrap()) {
            if (l0VarM.isScrap()) {
                l0VarM.unScrap();
            } else {
                l0VarM.clearReturnedFromScrapFlag();
            }
            this.f16721a.k(view, i10, view.getLayoutParams(), false);
        } else {
            if (view.getParent() == this.f16722b) {
                Ka.A a3 = this.f16721a;
                int iIndexOfChild = ((RecyclerView) ((G) a3.f7156c).f16572a).indexOfChild(view);
                if (iIndexOfChild == -1) {
                    iB = -1;
                } else {
                    C0337f c0337f = (C0337f) a3.f7157d;
                    if (c0337f.d(iIndexOfChild)) {
                        iB = -1;
                    } else {
                        iB = iIndexOfChild - c0337f.b(iIndexOfChild);
                    }
                }
                if (i10 == -1) {
                    i10 = this.f16721a.D();
                }
                if (iB == -1) {
                    StringBuilder sb2 = new StringBuilder("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                    sb2.append(this.f16722b.indexOfChild(view));
                    throw new IllegalStateException(AbstractC0492c.i(this.f16722b, sb2));
                }
                if (iB != i10) {
                    T t10 = this.f16722b.f16684x;
                    View viewV = t10.v(iB);
                    if (viewV == null) {
                        throw new IllegalArgumentException("Cannot move a child from non-existing index:" + iB + t10.f16722b.toString());
                    }
                    t10.v(iB);
                    t10.f16721a.x(iB);
                    RecyclerView.LayoutParams layoutParams2 = (RecyclerView.LayoutParams) viewV.getLayoutParams();
                    l0 l0VarM2 = RecyclerView.M(viewV);
                    if (l0VarM2.isRemoved()) {
                        p240v.k kVar2 = (p240v.k) t10.f16722b.f16671q.f9772b;
                        v0 v0VarA2 = (v0) kVar2.getOrDefault(l0VarM2, null);
                        if (v0VarA2 == null) {
                            v0VarA2 = v0.a();
                            kVar2.put(l0VarM2, v0VarA2);
                        }
                        v0VarA2.f16966a = 1 | v0VarA2.f16966a;
                    } else {
                        t10.f16722b.f16671q.x(l0VarM2);
                    }
                    t10.f16721a.k(viewV, i10, layoutParams2, l0VarM2.isRemoved());
                }
            } else {
                this.f16721a.e(view, i10, false);
                layoutParams.f16692c = true;
                B b10 = this.f16725e;
                if (b10 != null && b10.f16798e) {
                    b10.f16795b.getClass();
                    l0 l0VarM3 = RecyclerView.M(view);
                    if ((l0VarM3 != null ? l0VarM3.getLayoutPosition() : -1) == b10.f16794a) {
                        b10.f16799f = view;
                        if (RecyclerView.f16609L0) {
                            Log.d("RecyclerView", "smooth scroll target view has been attached");
                        }
                    }
                }
            }
        }
        if (layoutParams.f16693d) {
            if (RecyclerView.f16609L0) {
                Log.d("RecyclerView", "consuming pending invalidate on child " + layoutParams.f16690a);
            }
            l0VarM.itemView.invalidate();
            layoutParams.f16693d = false;
        }
    }

    public final void b0(View view, p211s1.i iVar) {
        l0 l0VarM = RecyclerView.M(view);
        if (l0VarM == null || l0VarM.isRemoved()) {
            return;
        }
        Ka.A a3 = this.f16721a;
        if (((ArrayList) a3.f7158e).contains(l0VarM.itemView)) {
            return;
        }
        RecyclerView recyclerView = this.f16722b;
        c0(recyclerView.f16653c, recyclerView.f16674r0, view, iVar);
    }

    public void c(String str) {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            recyclerView.k(str);
        }
    }

    public final void d(Rect rect, View view) {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.N(view));
        }
    }

    public abstract boolean e();

    public abstract boolean f();

    public boolean g(RecyclerView.LayoutParams layoutParams) {
        return layoutParams != null;
    }

    public abstract void i0(a0 a0Var, h0 h0Var);

    public abstract void j0(h0 h0Var);

    public abstract int k(h0 h0Var);

    public abstract int l(h0 h0Var);

    public Parcelable l0() {
        return null;
    }

    public abstract int m(h0 h0Var);

    public abstract int n(h0 h0Var);

    /* JADX WARN: Code duplicated, block: B:22:0x0062 A[PHI: r3
  0x0062: PHI (r3v8 int) = (r3v5 int), (r3v11 int) binds: [B:28:0x007e, B:20:0x0054] A[DONT_GENERATE, DONT_INLINE]] */
    public boolean n0(a0 a0Var, h0 h0Var, int i10, Bundle bundle) {
        int iL;
        int iJ;
        if (this.f16722b != null) {
            int iHeight = this.f16734o;
            int iWidth = this.f16733n;
            Rect rect = new Rect();
            if (this.f16722b.getMatrix().isIdentity() && this.f16722b.getGlobalVisibleRect(rect)) {
                iHeight = rect.height();
                iWidth = rect.width();
            }
            if (i10 == 4096) {
                iL = this.f16722b.canScrollVertically(1) ? (iHeight - L()) - I() : 0;
                if (this.f16722b.canScrollHorizontally(1)) {
                    iJ = (iWidth - J()) - K();
                } else {
                    iJ = 0;
                }
            } else if (i10 != 8192) {
                iL = 0;
                iJ = 0;
            } else {
                iL = this.f16722b.canScrollVertically(-1) ? -((iHeight - L()) - I()) : 0;
                if (this.f16722b.canScrollHorizontally(-1)) {
                    iJ = -((iWidth - J()) - K());
                } else {
                    iJ = 0;
                }
            }
            if (iL != 0 || iJ != 0) {
                this.f16722b.j0(iJ, iL, true);
                return true;
            }
        }
        return false;
    }

    public abstract int o(h0 h0Var);

    public final void o0(a0 a0Var) {
        for (int iW = w() - 1; iW >= 0; iW--) {
            if (!RecyclerView.M(v(iW)).shouldIgnore()) {
                View viewV = v(iW);
                r0(iW);
                a0Var.h(viewV);
            }
        }
    }

    public abstract int p(h0 h0Var);

    public final void p0(a0 a0Var) {
        ArrayList arrayList;
        int size = a0Var.f16746a.size();
        int i10 = size - 1;
        while (true) {
            arrayList = a0Var.f16746a;
            if (i10 < 0) {
                break;
            }
            View view = ((l0) arrayList.get(i10)).itemView;
            l0 l0VarM = RecyclerView.M(view);
            if (!l0VarM.shouldIgnore()) {
                l0VarM.setIsRecyclable(false);
                if (l0VarM.isTmpDetached()) {
                    this.f16722b.removeDetachedView(view, false);
                }
                N n10 = this.f16722b.f16648W;
                if (n10 != null) {
                    n10.d(l0VarM);
                }
                l0VarM.setIsRecyclable(true);
                l0 l0VarM2 = RecyclerView.M(view);
                l0VarM2.mScrapContainer = null;
                l0VarM2.mInChangeScrap = false;
                l0VarM2.clearReturnedFromScrapFlag();
                a0Var.i(l0VarM2);
            }
            i10--;
        }
        arrayList.clear();
        ArrayList arrayList2 = a0Var.f16747b;
        if (arrayList2 != null) {
            arrayList2.clear();
        }
        if (size > 0) {
            this.f16722b.invalidate();
        }
    }

    public final void q(a0 a0Var) {
        for (int iW = w() - 1; iW >= 0; iW--) {
            View viewV = v(iW);
            l0 l0VarM = RecyclerView.M(viewV);
            if (l0VarM.shouldIgnore()) {
                if (RecyclerView.f16609L0) {
                    Log.d("RecyclerView", "ignoring view " + l0VarM);
                }
            } else if (!l0VarM.isInvalid() || l0VarM.isRemoved() || this.f16722b.f16682w.hasStableIds()) {
                v(iW);
                this.f16721a.x(iW);
                a0Var.j(viewV);
                this.f16722b.f16671q.x(l0VarM);
            } else {
                r0(iW);
                a0Var.i(l0VarM);
            }
        }
    }

    public final void q0(View view, a0 a0Var) {
        Ka.A a3 = this.f16721a;
        G g10 = (G) a3.f7156c;
        int i10 = a3.f7155b;
        if (i10 == 1) {
            throw new IllegalStateException("Cannot call removeView(At) within removeView(At)");
        }
        if (i10 == 2) {
            throw new IllegalStateException("Cannot call removeView(At) within removeViewIfHidden");
        }
        try {
            a3.f7155b = 1;
            a3.f7159f = view;
            int iIndexOfChild = ((RecyclerView) g10.f16572a).indexOfChild(view);
            if (iIndexOfChild >= 0) {
                if (((C0337f) a3.f7157d).g(iIndexOfChild)) {
                    a3.T(view);
                }
                g10.h(iIndexOfChild);
            }
            a3.f7155b = 0;
            a3.f7159f = null;
            a0Var.h(view);
        } catch (Throwable th) {
            a3.f7155b = 0;
            a3.f7159f = null;
            throw th;
        }
    }

    public View r(int i10) {
        int iW = w();
        for (int i11 = 0; i11 < iW; i11++) {
            View viewV = v(i11);
            l0 l0VarM = RecyclerView.M(viewV);
            if (l0VarM != null && l0VarM.getLayoutPosition() == i10 && !l0VarM.shouldIgnore() && (this.f16722b.f16674r0.f16820g || !l0VarM.isRemoved())) {
                return viewV;
            }
        }
        return null;
    }

    public final void r0(int i10) {
        if (v(i10) != null) {
            Ka.A a3 = this.f16721a;
            G g10 = (G) a3.f7156c;
            int i11 = a3.f7155b;
            if (i11 == 1) {
                throw new IllegalStateException("Cannot call removeView(At) within removeView(At)");
            }
            if (i11 == 2) {
                throw new IllegalStateException("Cannot call removeView(At) within removeViewIfHidden");
            }
            try {
                int iE = a3.E(i10);
                View childAt = ((RecyclerView) g10.f16572a).getChildAt(iE);
                if (childAt != null) {
                    a3.f7155b = 1;
                    a3.f7159f = childAt;
                    if (((C0337f) a3.f7157d).g(iE)) {
                        a3.T(childAt);
                    }
                    g10.h(iE);
                }
            } finally {
                a3.f7155b = 0;
                a3.f7159f = null;
            }
        }
    }

    public abstract RecyclerView.LayoutParams s();

    /* JADX WARN: Code duplicated, block: B:28:0x00ae  */
    /* JADX WARN: Code duplicated, block: B:33:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:35:0x00ba  */
    public boolean s0(RecyclerView recyclerView, View view, Rect rect, boolean z3, boolean z5) {
        int iJ = J();
        int iL = L();
        int iK = this.f16733n - K();
        int I10 = this.f16734o - I();
        int left = (view.getLeft() + rect.left) - view.getScrollX();
        int top = (view.getTop() + rect.top) - view.getScrollY();
        int iWidth = rect.width() + left;
        int iHeight = rect.height() + top;
        int i10 = left - iJ;
        int iMin = Math.min(0, i10);
        int i11 = top - iL;
        int iMin2 = Math.min(0, i11);
        int i12 = iWidth - iK;
        int iMax = Math.max(0, i12);
        int iMax2 = Math.max(0, iHeight - I10);
        if (H() != 1) {
            if (iMin == 0) {
                iMin = Math.min(i10, iMax);
            }
            iMax = iMin;
        } else if (iMax == 0) {
            iMax = Math.max(iMin, i12);
        }
        if (iMin2 == 0) {
            iMin2 = Math.min(i11, iMax2);
        }
        int[] iArr = {iMax, iMin2};
        int i13 = iArr[0];
        int i14 = iArr[1];
        if (z5) {
            View focusedChild = recyclerView.getFocusedChild();
            if (focusedChild != null) {
                int iJ2 = J();
                int iL2 = L();
                int iK2 = this.f16733n - K();
                int I11 = this.f16734o - I();
                Rect rect2 = this.f16722b.f16677t;
                A(rect2, focusedChild);
                if (rect2.left - i13 < iK2 && rect2.right - i13 > iJ2 && rect2.top - i14 < I11 && rect2.bottom - i14 > iL2) {
                    if (i13 == 0) {
                    }
                    if (z3) {
                        recyclerView.scrollBy(i13, i14);
                        return true;
                    }
                    recyclerView.j0(i13, i14, false);
                    return true;
                }
            }
        } else if (i13 == 0 || i14 != 0) {
            if (z3) {
                recyclerView.scrollBy(i13, i14);
                return true;
            }
            recyclerView.j0(i13, i14, false);
            return true;
        }
        return false;
    }

    public RecyclerView.LayoutParams t(Context context, AttributeSet attributeSet) {
        return new RecyclerView.LayoutParams(context, attributeSet);
    }

    public final void t0() {
        RecyclerView recyclerView = this.f16722b;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    public RecyclerView.LayoutParams u(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof RecyclerView.LayoutParams) {
            return new RecyclerView.LayoutParams((RecyclerView.LayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new RecyclerView.LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new RecyclerView.LayoutParams(layoutParams);
    }

    public abstract int u0(int i10, a0 a0Var, h0 h0Var);

    public final View v(int i10) {
        Ka.A a3 = this.f16721a;
        if (a3 != null) {
            return a3.C(i10);
        }
        return null;
    }

    public abstract void v0(int i10);

    public final int w() {
        Ka.A a3 = this.f16721a;
        if (a3 != null) {
            return a3.D();
        }
        return 0;
    }

    public abstract int w0(int i10, a0 a0Var, h0 h0Var);

    public final void x0(RecyclerView recyclerView) {
        y0(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
    }

    public int y(a0 a0Var, h0 h0Var) {
        return -1;
    }

    public final void y0(int i10, int i11) {
        this.f16733n = View.MeasureSpec.getSize(i10);
        int mode = View.MeasureSpec.getMode(i10);
        this.f16731l = mode;
        if (mode == 0 && !RecyclerView.O0) {
            this.f16733n = 0;
        }
        this.f16734o = View.MeasureSpec.getSize(i11);
        int mode2 = View.MeasureSpec.getMode(i11);
        this.f16732m = mode2;
        if (mode2 != 0 || RecyclerView.O0) {
            return;
        }
        this.f16734o = 0;
    }

    public void z0(Rect rect, int i10, int i11) {
        int iK = K() + J() + rect.width();
        int I10 = I() + L() + rect.height();
        RecyclerView recyclerView = this.f16722b;
        WeakHashMap weakHashMap = p200r1.U.f27683a;
        this.f16722b.setMeasuredDimension(h(i10, iK, recyclerView.getMinimumWidth()), h(i11, I10, this.f16722b.getMinimumHeight()));
    }

    public void V() {
    }

    public void e0() {
    }

    public void W(RecyclerView recyclerView) {
    }

    public void k0(Parcelable parcelable) {
    }

    public void m0(int i10) {
    }

    public void d0(int i10, int i11) {
    }

    public void f0(int i10, int i11) {
    }

    public void g0(int i10, int i11) {
    }

    public void h0(int i10, int i11) {
    }

    public void j(int i10, Db.m mVar) {
    }

    public void c0(a0 a0Var, h0 h0Var, View view, p211s1.i iVar) {
    }

    public void i(int i10, int i11, h0 h0Var, Db.m mVar) {
    }
}
