package androidx.emoji2.text;

import F2.C0215f;
import I1.j;
import I1.k;
import I1.r;
import android.content.Context;
import androidx.lifecycle.D;
import androidx.lifecycle.F;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import p115j2.a;
import p115j2.b;

/* JADX INFO: loaded from: classes.dex */
public class EmojiCompatInitializer implements b {
    @Override // p115j2.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // p115j2.b
    public final Object b(Context context) {
        Object objB;
        r rVar = new r(new C0215f(context, 5));
        rVar.f5744a = 1;
        if (j.k == null) {
            synchronized (j.f5747j) {
                try {
                    if (j.k == null) {
                        j.k = new j(rVar);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        a aVarC = a.c(context);
        aVarC.getClass();
        synchronized (a.f23953e) {
            try {
                objB = aVarC.f23954a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
        F fJ = ((D) objB).j();
        fJ.a(new k(this, fJ));
        return Boolean.TRUE;
    }
}
