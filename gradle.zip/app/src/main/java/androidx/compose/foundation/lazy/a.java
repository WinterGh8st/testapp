package androidx.compose.foundation.lazy;

import N0.g;
import O.C0597d0;
import Z.m;
import p097ha.k;
import p143m0.c;
import p195q8.n;
import p260x.Q;
import p260x.n0;

/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public C0597d0 f15765a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public C0597d0 f15766b;

    public static m a(a aVar, m mVar) {
        int i10 = g.f8977c;
        Object obj = n0.f31831a;
        Q qR = n.r(1, new g(c.g(1, 1)));
        aVar.getClass();
        k.f(mVar, "<this>");
        return mVar.k(new AnimateItemPlacementElement(qR));
    }
}
