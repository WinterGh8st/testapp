package androidx.compose.foundation.layout;

import B.f0;
import p084ga.e;
import p096h9.i;
import p097ha.k;
import p097ha.l;
import p199r0.AbstractC1464s;
import p220t0.P;
import p260x.AbstractC1876h;

/* JADX INFO: loaded from: classes.dex */
final class WrapContentElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f15753b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final l f15754c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Object f15755d;

    /* JADX WARN: Multi-variable type inference failed */
    public WrapContentElement(int i10, e eVar, Object obj, String str) {
        i.n(i10, "direction");
        this.f15753b = i10;
        this.f15754c = (l) eVar;
        this.f15755d = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!WrapContentElement.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        k.d(obj, "null cannot be cast to non-null type androidx.compose.foundation.layout.WrapContentElement");
        WrapContentElement wrapContentElement = (WrapContentElement) obj;
        return this.f15753b == wrapContentElement.f15753b && this.f15755d.equals(wrapContentElement.f15755d);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15755d.hashCode() + AbstractC1464s.d(AbstractC1876h.c(this.f15753b) * 31, 31, false);
    }

    @Override // p220t0.P
    public final Z.l l() {
        int i10 = this.f15753b;
        i.n(i10, "direction");
        l lVar = this.f15754c;
        f0 f0Var = new f0();
        f0Var.f598x = i10;
        f0Var.f599y = lVar;
        return f0Var;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        f0 f0Var = (f0) lVar;
        k.f(f0Var, "node");
        int i10 = this.f15753b;
        i.n(i10, "<set-?>");
        f0Var.f598x = i10;
        f0Var.f599y = this.f15754c;
    }
}
