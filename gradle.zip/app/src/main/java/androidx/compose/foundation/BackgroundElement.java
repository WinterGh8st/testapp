package androidx.compose.foundation;

import Z.l;
import p050e0.AbstractC1060m;
import p050e0.J;
import p050e0.q;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;
import p271y.C1917l;

/* JADX INFO: loaded from: classes.dex */
final class BackgroundElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f15695b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final AbstractC1060m f15696c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f15697d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final J f15698e;

    public BackgroundElement(long j10, AbstractC1060m abstractC1060m, J j11, int i10) {
        j10 = (i10 & 1) != 0 ? q.f21752i : j10;
        abstractC1060m = (i10 & 2) != 0 ? null : abstractC1060m;
        k.f(j11, "shape");
        this.f15695b = j10;
        this.f15696c = abstractC1060m;
        this.f15697d = 1.0f;
        this.f15698e = j11;
    }

    public final boolean equals(Object obj) {
        BackgroundElement backgroundElement = obj instanceof BackgroundElement ? (BackgroundElement) obj : null;
        return backgroundElement != null && q.c(this.f15695b, backgroundElement.f15695b) && k.b(this.f15696c, backgroundElement.f15696c) && this.f15697d == backgroundElement.f15697d && k.b(this.f15698e, backgroundElement.f15698e);
    }

    @Override // p220t0.P
    public final int hashCode() {
        int i10 = q.f21753j;
        int iHashCode = Long.hashCode(this.f15695b) * 31;
        AbstractC1060m abstractC1060m = this.f15696c;
        return this.f15698e.hashCode() + AbstractC1464s.b((iHashCode + (abstractC1060m != null ? abstractC1060m.hashCode() : 0)) * 31, this.f15697d, 31);
    }

    @Override // p220t0.P
    public final l l() {
        J j10 = this.f15698e;
        k.f(j10, "shape");
        C1917l c1917l = new C1917l();
        c1917l.f32308x = this.f15695b;
        c1917l.f32309y = this.f15696c;
        c1917l.f32310z = this.f15697d;
        c1917l.f32303A = j10;
        return c1917l;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C1917l c1917l = (C1917l) lVar;
        k.f(c1917l, "node");
        c1917l.f32308x = this.f15695b;
        c1917l.f32309y = this.f15696c;
        c1917l.f32310z = this.f15697d;
        J j10 = this.f15698e;
        k.f(j10, "<set-?>");
        c1917l.f32303A = j10;
    }
}
