package androidx.compose.foundation.layout;

import B.InterfaceC0035q;
import Z.m;
import p097ha.k;

/* JADX INFO: loaded from: classes.dex */
public final class a implements InterfaceC0035q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f15756a = new a();

    @Override // B.InterfaceC0035q
    public final m a(m mVar, Z.d dVar) {
        k.f(mVar, "<this>");
        return mVar.k(new BoxChildDataElement(dVar));
    }
}
