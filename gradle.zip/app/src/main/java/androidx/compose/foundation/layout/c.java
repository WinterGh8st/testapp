package androidx.compose.foundation.layout;

import A7.A;
import B.C0029k;
import B.L;
import N0.j;
import Z.m;
import p097ha.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {
    public static L a(int i10, float f10) {
        if ((i10 & 1) != 0) {
            f10 = 0;
        }
        float f11 = 0;
        return new L(f10, f11, f10, f11);
    }

    public static L b(float f10, float f11, float f12, float f13, int i10) {
        if ((i10 & 1) != 0) {
            f10 = 0;
        }
        if ((i10 & 2) != 0) {
            f11 = 0;
        }
        if ((i10 & 4) != 0) {
            f12 = 0;
        }
        if ((i10 & 8) != 0) {
            f13 = 0;
        }
        return new L(f10, f11, f12, f13);
    }

    public static final float c(L l4, j jVar) {
        k.f(l4, "<this>");
        k.f(jVar, "layoutDirection");
        return jVar == j.f8984a ? l4.b(jVar) : l4.a(jVar);
    }

    public static final float d(L l4, j jVar) {
        k.f(l4, "<this>");
        k.f(jVar, "layoutDirection");
        return jVar == j.f8984a ? l4.a(jVar) : l4.b(jVar);
    }

    public static final m e(m mVar, p084ga.c cVar) {
        k.f(mVar, "<this>");
        k.f(cVar, "offset");
        return mVar.k(new OffsetPxElement(cVar, new C0029k(1, 5)));
    }

    public static final m f(m mVar, float f10, float f11) {
        k.f(mVar, "$this$offset");
        return mVar.k(new OffsetElement(f10, f11, new C0029k(1, 4)));
    }

    public static final m g(m mVar, L l4) {
        k.f(mVar, "<this>");
        k.f(l4, "paddingValues");
        return mVar.k(new PaddingValuesElement(l4, new C0029k(1, 9)));
    }

    public static final m h(m mVar, float f10) {
        k.f(mVar, "$this$padding");
        return mVar.k(new PaddingElement(f10, f10, f10, f10, new C0029k(1, 8)));
    }

    public static final m i(m mVar, float f10, float f11) {
        k.f(mVar, "$this$padding");
        return mVar.k(new PaddingElement(f10, f11, f10, f11, new C0029k(1, 7)));
    }

    public static m j(m mVar, float f10, float f11, int i10) {
        if ((i10 & 1) != 0) {
            f10 = 0;
        }
        if ((i10 & 2) != 0) {
            f11 = 0;
        }
        return i(mVar, f10, f11);
    }

    public static final m k(m mVar, float f10, float f11, float f12, float f13) {
        k.f(mVar, "$this$padding");
        return mVar.k(new PaddingElement(f10, f11, f12, f13, new C0029k(1, 6)));
    }

    public static m l(m mVar, float f10, float f11, float f12, float f13, int i10) {
        if ((i10 & 1) != 0) {
            f10 = 0;
        }
        if ((i10 & 2) != 0) {
            f11 = 0;
        }
        if ((i10 & 4) != 0) {
            f12 = 0;
        }
        if ((i10 & 8) != 0) {
            f13 = 0;
        }
        return k(mVar, f10, f11, f12, f13);
    }

    public static WrapContentElement m(Z.d dVar) {
        return new WrapContentElement(3, new A(dVar, 3), dVar, "wrapContentSize");
    }
}
