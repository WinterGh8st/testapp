package androidx.compose.foundation;

import Z.m;
import p210s0.h;
import p232u0.C1710z;
import p271y.L;
import p283z.C1945e;

/* JADX INFO: loaded from: classes.dex */
public abstract class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final h f15713a = new h(L.f32176b);

    public static final m a(C1945e c1945e, C1710z c1710z) {
        return c1945e.k(new FocusedBoundsObserverElement(c1710z));
    }
}
