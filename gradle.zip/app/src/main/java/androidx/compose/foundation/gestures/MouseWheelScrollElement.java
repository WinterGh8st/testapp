package androidx.compose.foundation.gestures;

import O.Z;
import Z.l;
import p097ha.k;
import p220t0.P;
import p283z.C1937a;
import p283z.W;

/* JADX INFO: loaded from: classes.dex */
final class MouseWheelScrollElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Z f15724b;

    public MouseWheelScrollElement(Z z3) {
        this.f15724b = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof MouseWheelScrollElement)) {
            return false;
        }
        if (!this.f15724b.equals(((MouseWheelScrollElement) obj).f15724b)) {
            return false;
        }
        Object obj2 = C1937a.f33001a;
        return obj2.equals(obj2);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return C1937a.f33001a.hashCode() + (this.f15724b.hashCode() * 31);
    }

    @Override // p220t0.P
    public final l l() {
        return new W(this.f15724b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        W w9 = (W) lVar;
        k.f(w9, "node");
        w9.f32989z = this.f15724b;
        w9.f32987A = C1937a.f33001a;
    }
}
