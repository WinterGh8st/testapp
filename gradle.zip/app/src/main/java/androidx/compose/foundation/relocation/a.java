package androidx.compose.foundation.relocation;

import F.f;
import Z.m;
import p097ha.k;
import p283z.C1945e;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(m mVar, f fVar) {
        k.f(mVar, "<this>");
        k.f(fVar, "bringIntoViewRequester");
        return mVar.k(new BringIntoViewRequesterElement(fVar));
    }

    public static final m b(m mVar, C1945e c1945e) {
        k.f(mVar, "<this>");
        return mVar.k(new BringIntoViewResponderElement(c1945e));
    }
}
