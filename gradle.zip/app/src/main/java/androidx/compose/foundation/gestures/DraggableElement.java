package androidx.compose.foundation.gestures;

import p084ga.c;
import p084ga.f;
import p097ha.k;
import p097ha.l;
import p199r0.AbstractC1464s;
import p220t0.P;
import p283z.O;
import p283z.X;

/* JADX INFO: loaded from: classes.dex */
public final class DraggableElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p283z.P f15715b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final l f15716c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final X f15717d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f15718e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final A.l f15719f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final p084ga.a f15720g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final f f15721h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final f f15722i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final boolean f15723j;

    /* JADX WARN: Multi-variable type inference failed */
    public DraggableElement(p283z.P p10, c cVar, X x10, boolean z3, A.l lVar, p084ga.a aVar, f fVar, f fVar2, boolean z5) {
        k.f(p10, "state");
        k.f(aVar, "startDragImmediately");
        k.f(fVar, "onDragStarted");
        k.f(fVar2, "onDragStopped");
        this.f15715b = p10;
        this.f15716c = (l) cVar;
        this.f15717d = x10;
        this.f15718e = z3;
        this.f15719f = lVar;
        this.f15720g = aVar;
        this.f15721h = fVar;
        this.f15722i = fVar2;
        this.f15723j = z5;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!DraggableElement.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        k.d(obj, "null cannot be cast to non-null type androidx.compose.foundation.gestures.DraggableElement");
        DraggableElement draggableElement = (DraggableElement) obj;
        return k.b(this.f15715b, draggableElement.f15715b) && this.f15716c.equals(draggableElement.f15716c) && this.f15717d == draggableElement.f15717d && this.f15718e == draggableElement.f15718e && k.b(this.f15719f, draggableElement.f15719f) && k.b(this.f15720g, draggableElement.f15720g) && k.b(this.f15721h, draggableElement.f15721h) && k.b(this.f15722i, draggableElement.f15722i) && this.f15723j == draggableElement.f15723j;
    }

    @Override // p220t0.P
    public final int hashCode() {
        int iD = AbstractC1464s.d((this.f15717d.hashCode() + ((this.f15716c.hashCode() + (this.f15715b.hashCode() * 31)) * 31)) * 31, 31, this.f15718e);
        A.l lVar = this.f15719f;
        return Boolean.hashCode(this.f15723j) + ((this.f15722i.hashCode() + ((this.f15721h.hashCode() + ((this.f15720g.hashCode() + ((iD + (lVar != null ? lVar.hashCode() : 0)) * 31)) * 31)) * 31)) * 31);
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [ga.c, ha.l] */
    @Override // p220t0.P
    public final Z.l l() {
        return new O(this.f15715b, this.f15716c, this.f15717d, this.f15718e, this.f15719f, this.f15720g, this.f15721h, this.f15722i, this.f15723j);
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        boolean z3;
        O o4 = (O) lVar;
        k.f(o4, "node");
        p283z.P p10 = this.f15715b;
        k.f(p10, "state");
        l lVar2 = this.f15716c;
        X x10 = this.f15717d;
        p084ga.a aVar = this.f15720g;
        k.f(aVar, "startDragImmediately");
        f fVar = this.f15721h;
        k.f(fVar, "onDragStarted");
        f fVar2 = this.f15722i;
        k.f(fVar2, "onDragStopped");
        boolean z5 = true;
        if (k.b(o4.f32930z, p10)) {
            z3 = false;
        } else {
            o4.f32930z = p10;
            z3 = true;
        }
        o4.f32917A = lVar2;
        if (o4.f32918B != x10) {
            o4.f32918B = x10;
            z3 = true;
        }
        boolean z10 = o4.f32919C;
        boolean z11 = this.f15718e;
        if (z10 != z11) {
            o4.f32919C = z11;
            if (!z11) {
                o4.J0();
            }
            z3 = true;
        }
        A.l lVar3 = o4.f32920D;
        A.l lVar4 = this.f15719f;
        if (!k.b(lVar3, lVar4)) {
            o4.J0();
            o4.f32920D = lVar4;
        }
        o4.f32921E = aVar;
        o4.f32922F = fVar;
        o4.f32923G = fVar2;
        boolean z12 = o4.f32924H;
        boolean z13 = this.f15723j;
        if (z12 != z13) {
            o4.f32924H = z13;
        } else {
            z5 = z3;
        }
        if (z5) {
            o4.f32928L.H0();
        }
    }
}
