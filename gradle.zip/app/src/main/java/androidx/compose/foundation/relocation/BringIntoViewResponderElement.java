package androidx.compose.foundation.relocation;

import Z.l;
import p097ha.k;
import p220t0.P;
import p283z.C1945e;

/* JADX INFO: loaded from: classes.dex */
final class BringIntoViewResponderElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1945e f15768b;

    public BringIntoViewResponderElement(C1945e c1945e) {
        this.f15768b = c1945e;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof BringIntoViewResponderElement) {
            return this.f15768b.equals(((BringIntoViewResponderElement) obj).f15768b);
        }
        return false;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15768b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        return new F.l(this.f15768b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        F.l lVar2 = (F.l) lVar;
        k.f(lVar2, "node");
        lVar2.f3489z = this.f15768b;
    }
}
