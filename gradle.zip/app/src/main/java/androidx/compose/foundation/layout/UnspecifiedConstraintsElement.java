package androidx.compose.foundation.layout;

import B.W;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class UnspecifiedConstraintsElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15751b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15752c;

    public UnspecifiedConstraintsElement(float f10, float f11) {
        this.f15751b = f10;
        this.f15752c = f11;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof UnspecifiedConstraintsElement)) {
            return false;
        }
        UnspecifiedConstraintsElement unspecifiedConstraintsElement = (UnspecifiedConstraintsElement) obj;
        return N0.d.a(this.f15751b, unspecifiedConstraintsElement.f15751b) && N0.d.a(this.f15752c, unspecifiedConstraintsElement.f15752c);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Float.hashCode(this.f15752c) + (Float.hashCode(this.f15751b) * 31);
    }

    @Override // p220t0.P
    public final l l() {
        W w9 = new W();
        w9.f553x = this.f15751b;
        w9.f554y = this.f15752c;
        return w9;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        W w9 = (W) lVar;
        k.f(w9, "node");
        w9.f553x = this.f15751b;
        w9.f554y = this.f15752c;
    }
}
