package androidx.compose.foundation;

import Z.l;
import p097ha.k;
import p220t0.P;
import p232u0.C1710z;
import p271y.N;

/* JADX INFO: loaded from: classes.dex */
final class FocusedBoundsObserverElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1710z f15708b;

    public FocusedBoundsObserverElement(C1710z c1710z) {
        this.f15708b = c1710z;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        FocusedBoundsObserverElement focusedBoundsObserverElement = obj instanceof FocusedBoundsObserverElement ? (FocusedBoundsObserverElement) obj : null;
        if (focusedBoundsObserverElement == null) {
            return false;
        }
        return this.f15708b.equals(focusedBoundsObserverElement.f15708b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15708b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        return new N(this.f15708b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        N n10 = (N) lVar;
        k.f(n10, "node");
        n10.f32182x = this.f15708b;
    }
}
