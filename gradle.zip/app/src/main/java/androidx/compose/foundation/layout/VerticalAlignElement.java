package androidx.compose.foundation.layout;

import B.Y;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class VerticalAlignElement extends P {
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if ((obj instanceof VerticalAlignElement ? (VerticalAlignElement) obj : null) == null) {
            return false;
        }
        Z.c cVar = Z.a.f14397t;
        return cVar.equals(cVar);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Float.hashCode(0.0f);
    }

    @Override // p220t0.P
    public final l l() {
        Z.c cVar = Z.a.f14397t;
        Y y10 = new Y();
        y10.f557x = cVar;
        return y10;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        Y y10 = (Y) lVar;
        k.f(y10, "node");
        y10.f557x = Z.a.f14397t;
    }
}
