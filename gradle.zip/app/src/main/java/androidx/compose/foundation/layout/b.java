package androidx.compose.foundation.layout;

import B.InterfaceC0035q;
import Z.m;
import p097ha.k;
import p199r0.U;

/* JADX INFO: loaded from: classes.dex */
public final class b implements InterfaceC0035q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final U f15757a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final long f15758b;

    public b(U u5, long j10) {
        k.f(u5, "density");
        this.f15757a = u5;
        this.f15758b = j10;
    }

    @Override // B.InterfaceC0035q
    public final m a(m mVar, Z.d dVar) {
        k.f(mVar, "<this>");
        return mVar.k(new BoxChildDataElement(dVar));
    }

    public final float b() {
        long j10 = this.f15758b;
        if (!N0.a.d(j10)) {
            return Float.POSITIVE_INFINITY;
        }
        return this.f15757a.l0(N0.a.h(j10));
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return k.b(this.f15757a, bVar.f15757a) && N0.a.b(this.f15758b, bVar.f15758b);
    }

    public final int hashCode() {
        return Long.hashCode(this.f15758b) + (this.f15757a.hashCode() * 31);
    }

    public final String toString() {
        return "BoxWithConstraintsScopeImpl(density=" + this.f15757a + ", constraints=" + ((Object) N0.a.k(this.f15758b)) + ')';
    }
}
