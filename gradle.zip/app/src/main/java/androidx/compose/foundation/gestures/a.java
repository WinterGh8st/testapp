package androidx.compose.foundation.gestures;

import A9.h;
import O.AbstractC0630v;
import O.C0610k;
import O.C0629u;
import O.D;
import O.W;
import O.Z;
import Z.j;
import Z.m;
import androidx.compose.foundation.b;
import androidx.compose.ui.focus.FocusTargetNode$FocusTargetElement;
import p084ga.f;
import p097ha.k;
import p097ha.l;
import p154n0.d;
import p232u0.C1674g0;
import p271y.C1919n;
import p271y.o0;
import p282ya.e;
import p283z.AbstractC1966o0;
import p283z.B;
import p283z.C;
import p283z.C1942c0;
import p283z.C1945e;
import p283z.C1953i;
import p283z.C1960l0;
import p283z.C1964n0;
import p283z.C1979v0;
import p283z.InterfaceC1968p0;
import p283z.T;
import p283z.X;

/* JADX INFO: loaded from: classes.dex */
public final class a extends l implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ X f15725a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ InterfaceC1968p0 f15726b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ boolean f15727c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ A.l f15728d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C1953i f15729e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ o0 f15730f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ boolean f15731q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(X x10, InterfaceC1968p0 interfaceC1968p0, boolean z3, A.l lVar, C1953i c1953i, o0 o0Var, boolean z5) {
        super(3);
        this.f15725a = x10;
        this.f15726b = interfaceC1968p0;
        this.f15727c = z3;
        this.f15728d = lVar;
        this.f15729e = c1953i;
        this.f15730f = o0Var;
        this.f15731q = z5;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        C0629u c0629u = (C0629u) obj2;
        ((Number) obj3).intValue();
        k.f((m) obj, "$this$composed");
        c0629u.a0(-629830927);
        c0629u.a0(773894976);
        c0629u.a0(-492369756);
        Object objE = c0629u.E();
        W w9 = C0610k.f9587a;
        if (objE == w9) {
            D d10 = new D(AbstractC0630v.z(c0629u));
            c0629u.m0(d10);
            objE = d10;
        }
        c0629u.u(false);
        e eVar = ((D) objE).f9451a;
        c0629u.u(false);
        boolean z3 = this.f15727c;
        Boolean boolValueOf = Boolean.valueOf(z3);
        X x10 = this.f15725a;
        InterfaceC1968p0 interfaceC1968p0 = this.f15726b;
        Object[] objArr = {eVar, x10, interfaceC1968p0, boolValueOf};
        c0629u.a0(-568225417);
        boolean zF = false;
        for (int i10 = 0; i10 < 4; i10++) {
            zF |= c0629u.f(objArr[i10]);
        }
        Object objE2 = c0629u.E();
        if (zF || objE2 == w9) {
            objE2 = new C1945e(eVar, x10, interfaceC1968p0, z3);
            c0629u.m0(objE2);
        }
        c0629u.u(false);
        m mVar = j.f14412b;
        C1674g0 c1674g0 = b.f15711a;
        mVar.k(c1674g0);
        m mVarK = androidx.compose.ui.focus.a.a(c1674g0, C1919n.f32316c).k(FocusTargetNode$FocusTargetElement.f15799b).k(((C1945e) objE2).f33035n);
        c0629u.a0(-2012025036);
        c0629u.a0(-1730185954);
        C1953i c1953iH = this.f15729e;
        if (c1953iH == null) {
            c1953iH = p196q9.a.h(c0629u);
        }
        C1953i c1953i = c1953iH;
        c0629u.u(false);
        c0629u.a0(-492369756);
        Object objE3 = c0629u.E();
        if (objE3 == w9) {
            objE3 = AbstractC0630v.I(new d(), W.f9545e);
            c0629u.m0(objE3);
        }
        c0629u.u(false);
        Z z5 = (Z) objE3;
        Z zL = AbstractC0630v.L(new C1979v0(x10, this.f15727c, z5, this.f15726b, c1953i, this.f15730f), c0629u);
        boolean z10 = this.f15731q;
        Boolean boolValueOf2 = Boolean.valueOf(z10);
        c0629u.a0(1157296644);
        boolean zF2 = c0629u.f(boolValueOf2);
        Object objE4 = c0629u.E();
        if (zF2 || objE4 == w9) {
            objE4 = new C1964n0(zL, z10);
            c0629u.m0(objE4);
        }
        c0629u.u(false);
        p154n0.a aVar = (p154n0.a) objE4;
        c0629u.a0(-492369756);
        Object objE5 = c0629u.E();
        if (objE5 == w9) {
            objE5 = new C1942c0(zL);
            c0629u.m0(objE5);
        }
        c0629u.u(false);
        C1942c0 c1942c0 = (C1942c0) objE5;
        c0629u.a0(-1485272842);
        c0629u.u(false);
        B b10 = AbstractC1966o0.f33085a;
        C c10 = C.f32830e;
        c0629u.a0(1157296644);
        boolean zF3 = c0629u.f(zL);
        Object objE6 = c0629u.E();
        if (zF3 || objE6 == w9) {
            objE6 = new h(zL, 16);
            c0629u.m0(objE6);
        }
        c0629u.u(false);
        p084ga.a aVar2 = (p084ga.a) objE6;
        c0629u.a0(511388516);
        boolean zF4 = c0629u.f(z5) | c0629u.f(zL);
        Object objE7 = c0629u.E();
        if (zF4 || objE7 == w9) {
            objE7 = new C1960l0(z5, zL, null);
            c0629u.m0(objE7);
        }
        c0629u.u(false);
        m mVarA = androidx.compose.ui.input.nestedscroll.a.a(mVarK.k(new DraggableElement(c1942c0, c10, x10, z10, this.f15728d, aVar2, b10, (f) objE7, false)).k(new MouseWheelScrollElement(zL)), aVar, (d) z5.getValue());
        c0629u.u(false);
        if (this.f15731q) {
            mVar = T.f32964b;
        }
        m mVarK2 = mVarA.k(mVar);
        c0629u.u(false);
        return mVarK2;
    }
}
