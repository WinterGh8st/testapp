package androidx.compose.foundation;

import Z.l;
import p050e0.J;
import p050e0.L;
import p097ha.k;
import p220t0.P;
import p271y.C1922q;

/* JADX INFO: loaded from: classes.dex */
public final class BorderModifierNodeElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15699b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final L f15700c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final J f15701d;

    public BorderModifierNodeElement(float f10, L l4, J j10) {
        k.f(j10, "shape");
        this.f15699b = f10;
        this.f15700c = l4;
        this.f15701d = j10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof BorderModifierNodeElement)) {
            return false;
        }
        BorderModifierNodeElement borderModifierNodeElement = (BorderModifierNodeElement) obj;
        return N0.d.a(this.f15699b, borderModifierNodeElement.f15699b) && this.f15700c.equals(borderModifierNodeElement.f15700c) && k.b(this.f15701d, borderModifierNodeElement.f15701d);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15701d.hashCode() + ((this.f15700c.hashCode() + (Float.hashCode(this.f15699b) * 31)) * 31);
    }

    @Override // p220t0.P
    public final l l() {
        return new C1922q(this.f15699b, this.f15700c, this.f15701d);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C1922q c1922q = (C1922q) lVar;
        k.f(c1922q, "node");
        float f10 = c1922q.f32335A;
        float f11 = this.f15699b;
        boolean zA = N0.d.a(f10, f11);
        p013b0.b bVar = c1922q.f32338D;
        if (!zA) {
            c1922q.f32335A = f11;
            bVar.F0();
        }
        L l4 = this.f15700c;
        if (!k.b(c1922q.f32336B, l4)) {
            c1922q.f32336B = l4;
            bVar.F0();
        }
        J j10 = this.f15701d;
        k.f(j10, "value");
        if (k.b(c1922q.f32337C, j10)) {
            return;
        }
        c1922q.f32337C = j10;
        bVar.F0();
    }

    public final String toString() {
        return "BorderModifierNodeElement(width=" + ((Object) N0.d.b(this.f15699b)) + ", brush=" + this.f15700c + ", shape=" + this.f15701d + ')';
    }
}
