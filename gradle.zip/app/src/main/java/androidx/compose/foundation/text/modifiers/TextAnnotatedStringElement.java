package androidx.compose.foundation.text.modifiers;

import B0.C0049f;
import B0.D;
import G0.InterfaceC0271h;
import J.d;
import J.f;
import Z.l;
import java.util.List;
import p015b2.a;
import p084ga.c;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.AbstractC1590g;
import p220t0.P;
import p232u0.C1691p;

/* JADX INFO: loaded from: classes.dex */
public final class TextAnnotatedStringElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C0049f f15769b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D f15770c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final InterfaceC0271h f15771d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final c f15772e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f15773f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f15774g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f15775h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final int f15776i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final List f15777j;
    public final c k;

    public TextAnnotatedStringElement(C0049f c0049f, D d10, InterfaceC0271h interfaceC0271h, c cVar, int i10, boolean z3, int i11, int i12, List list, c cVar2) {
        k.f(c0049f, "text");
        k.f(d10, "style");
        k.f(interfaceC0271h, "fontFamilyResolver");
        this.f15769b = c0049f;
        this.f15770c = d10;
        this.f15771d = interfaceC0271h;
        this.f15772e = cVar;
        this.f15773f = i10;
        this.f15774g = z3;
        this.f15775h = i11;
        this.f15776i = i12;
        this.f15777j = list;
        this.k = cVar2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextAnnotatedStringElement)) {
            return false;
        }
        TextAnnotatedStringElement textAnnotatedStringElement = (TextAnnotatedStringElement) obj;
        textAnnotatedStringElement.getClass();
        return k.b(this.f15769b, textAnnotatedStringElement.f15769b) && k.b(this.f15770c, textAnnotatedStringElement.f15770c) && k.b(this.f15777j, textAnnotatedStringElement.f15777j) && k.b(this.f15771d, textAnnotatedStringElement.f15771d) && k.b(this.f15772e, textAnnotatedStringElement.f15772e) && this.f15773f == textAnnotatedStringElement.f15773f && this.f15774g == textAnnotatedStringElement.f15774g && this.f15775h == textAnnotatedStringElement.f15775h && this.f15776i == textAnnotatedStringElement.f15776i && k.b(this.k, textAnnotatedStringElement.k);
    }

    @Override // p220t0.P
    public final int hashCode() {
        int iHashCode = (this.f15771d.hashCode() + a.b(this.f15769b.hashCode() * 31, 31, this.f15770c)) * 31;
        c cVar = this.f15772e;
        int iD = (((AbstractC1464s.d(a.a(this.f15773f, (iHashCode + (cVar != null ? cVar.hashCode() : 0)) * 31, 31), 31, this.f15774g) + this.f15775h) * 31) + this.f15776i) * 31;
        List list = this.f15777j;
        int iHashCode2 = (iD + (list != null ? list.hashCode() : 0)) * 31;
        c cVar2 = this.k;
        return (iHashCode2 + (cVar2 != null ? cVar2.hashCode() : 0)) * 961;
    }

    @Override // p220t0.P
    public final l l() {
        int i10 = this.f15776i;
        List list = this.f15777j;
        C0049f c0049f = this.f15769b;
        D d10 = this.f15770c;
        InterfaceC0271h interfaceC0271h = this.f15771d;
        c cVar = this.f15772e;
        int i11 = this.f15773f;
        boolean z3 = this.f15774g;
        int i12 = this.f15775h;
        c cVar2 = this.k;
        k.f(c0049f, "text");
        k.f(d10, "style");
        k.f(interfaceC0271h, "fontFamilyResolver");
        f fVar = new f();
        fVar.f6299x = c0049f;
        fVar.f6300y = d10;
        fVar.f6301z = interfaceC0271h;
        fVar.f6289A = cVar;
        fVar.f6290B = i11;
        fVar.f6291C = z3;
        fVar.f6292D = i12;
        fVar.f6293E = i10;
        fVar.f6294F = list;
        fVar.f6295G = cVar2;
        return fVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        boolean z3;
        f fVar = (f) lVar;
        k.f(fVar, "node");
        D d10 = this.f15770c;
        k.f(d10, "style");
        D d11 = fVar.f6300y;
        k.f(d11, "other");
        boolean z5 = false;
        boolean z10 = d10 == d11 || d10.f688a.c(d11.f688a);
        C0049f c0049f = this.f15769b;
        k.f(c0049f, "text");
        if (!k.b(fVar.f6299x, c0049f)) {
            fVar.f6299x = c0049f;
            z5 = true;
        }
        InterfaceC0271h interfaceC0271h = this.f15771d;
        int i10 = this.f15773f;
        D d12 = this.f15770c;
        List list = this.f15777j;
        int i11 = this.f15776i;
        int i12 = this.f15775h;
        boolean z11 = this.f15774g;
        fVar.getClass();
        k.f(d12, "style");
        k.f(interfaceC0271h, "fontFamilyResolver");
        boolean z12 = true;
        boolean z13 = !fVar.f6300y.c(d12);
        fVar.f6300y = d12;
        if (!k.b(fVar.f6294F, list)) {
            fVar.f6294F = list;
            z13 = true;
        }
        if (fVar.f6293E != i11) {
            fVar.f6293E = i11;
            z13 = true;
        }
        if (fVar.f6292D != i12) {
            fVar.f6292D = i12;
            z13 = true;
        }
        if (fVar.f6291C != z11) {
            fVar.f6291C = z11;
            z13 = true;
        }
        if (!k.b(fVar.f6301z, interfaceC0271h)) {
            fVar.f6301z = interfaceC0271h;
            z13 = true;
        }
        if (fVar.f6290B == i10) {
            z12 = z13;
        } else {
            fVar.f6290B = i10;
        }
        c cVar = this.f15772e;
        c cVar2 = this.k;
        boolean z14 = true;
        if (k.b(fVar.f6289A, cVar)) {
            z3 = false;
        } else {
            fVar.f6289A = cVar;
            z3 = true;
        }
        if (k.b(fVar.f6295G, cVar2)) {
            z14 = z3;
        } else {
            fVar.f6295G = cVar2;
        }
        if (fVar.f14425w) {
            if (z5 || (!z10 && fVar.f6298J != null)) {
                androidx.compose.ui.node.a aVarW = AbstractC1590g.w(fVar);
                aVarW.f15852w = null;
                ((C1691p) AbstractC1590g.x(aVarW)).x();
            }
            if (z5 || z12 || z14) {
                d dVarF0 = fVar.F0();
                C0049f c0049f2 = fVar.f6299x;
                D d13 = fVar.f6300y;
                InterfaceC0271h interfaceC0271h2 = fVar.f6301z;
                int i13 = fVar.f6290B;
                boolean z15 = fVar.f6291C;
                int i14 = fVar.f6292D;
                int i15 = fVar.f6293E;
                List list2 = fVar.f6294F;
                k.f(c0049f2, "text");
                k.f(d13, "style");
                k.f(interfaceC0271h2, "fontFamilyResolver");
                dVarF0.f6257a = c0049f2;
                dVarF0.f6258b = d13;
                dVarF0.f6259c = interfaceC0271h2;
                dVarF0.f6260d = i13;
                dVarF0.f6261e = z15;
                dVarF0.f6262f = i14;
                dVarF0.f6263g = i15;
                dVarF0.f6264h = list2;
                dVarF0.f6267l = null;
                dVarF0.f6269n = null;
                AbstractC1590g.t(fVar);
                AbstractC1590g.s(fVar);
            }
            if (z10) {
                return;
            }
            AbstractC1590g.s(fVar);
        }
    }
}
