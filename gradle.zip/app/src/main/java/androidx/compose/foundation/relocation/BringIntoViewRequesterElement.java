package androidx.compose.foundation.relocation;

import F.f;
import F.g;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class BringIntoViewRequesterElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final f f15767b;

    public BringIntoViewRequesterElement(f fVar) {
        k.f(fVar, "requester");
        this.f15767b = fVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof BringIntoViewRequesterElement) {
            return k.b(this.f15767b, ((BringIntoViewRequesterElement) obj).f15767b);
        }
        return false;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15767b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        return new g(this.f15767b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        g gVar = (g) lVar;
        k.f(gVar, "node");
        f fVar = this.f15767b;
        k.f(fVar, "requester");
        f fVar2 = gVar.f3472z;
        if (fVar2 != null) {
            fVar2.f3471a.l(gVar);
        }
        fVar.f3471a.b(gVar);
        gVar.f3472z = fVar;
    }
}
