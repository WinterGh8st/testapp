package androidx.compose.foundation.layout;

import B.C0029k;
import B.J;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class OffsetPxElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p084ga.c f15740b;

    public OffsetPxElement(p084ga.c cVar, C0029k c0029k) {
        k.f(cVar, "offset");
        this.f15740b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        OffsetPxElement offsetPxElement = obj instanceof OffsetPxElement ? (OffsetPxElement) obj : null;
        return offsetPxElement != null && k.b(this.f15740b, offsetPxElement.f15740b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(true) + (this.f15740b.hashCode() * 31);
    }

    @Override // p220t0.P
    public final l l() {
        p084ga.c cVar = this.f15740b;
        k.f(cVar, "offset");
        J j10 = new J();
        j10.f516x = cVar;
        j10.f517y = true;
        return j10;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        J j10 = (J) lVar;
        k.f(j10, "node");
        p084ga.c cVar = this.f15740b;
        k.f(cVar, "<set-?>");
        j10.f516x = cVar;
        j10.f517y = true;
    }

    public final String toString() {
        return "OffsetPxModifier(offset=" + this.f15740b + ", rtlAware=true)";
    }
}
