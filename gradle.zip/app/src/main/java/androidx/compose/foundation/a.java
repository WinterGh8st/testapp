package androidx.compose.foundation;

import A.l;
import A9.i;
import G6.C;
import I.u0;
import O.R0;
import Z.j;
import Z.m;
import p050e0.AbstractC1060m;
import p050e0.D;
import p050e0.E;
import p050e0.J;
import p097ha.k;
import p232u0.AbstractC1676h0;
import p232u0.C1685m;
import p271y.C1919n;
import p271y.X;
import p271y.Z;
import p284z0.g;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static m a(m mVar, AbstractC1060m abstractC1060m) {
        D d10 = E.f21690a;
        k.f(mVar, "<this>");
        k.f(abstractC1060m, "brush");
        return mVar.k(new BackgroundElement(0L, abstractC1060m, d10, 1));
    }

    public static final m b(m mVar, long j10, J j11) {
        k.f(mVar, "$this$background");
        k.f(j11, "shape");
        return mVar.k(new BackgroundElement(j10, null, j11, 2));
    }

    public static final m c(m mVar, l lVar, X x10, boolean z3, String str, g gVar, p084ga.a aVar) {
        k.f(mVar, "$this$clickable");
        k.f(lVar, "interactionSource");
        k.f(aVar, "onClick");
        C1685m c1685m = C1685m.f29826y;
        m hoverableElement = j.f14412b;
        R0 r7 = Z.f32211a;
        m mVarG = C.G(hoverableElement, new i(12, x10, lVar));
        if (z3) {
            hoverableElement = new HoverableElement(lVar);
        }
        m mVarK = mVarG.k(hoverableElement);
        C1919n c1919n = new C1919n(1, 6);
        FocusableKt$FocusableInNonTouchModeElement$1 focusableKt$FocusableInNonTouchModeElement$1 = b.f15712b;
        k.f(focusableKt$FocusableInNonTouchModeElement$1, "other");
        return AbstractC1676h0.a(mVar, c1685m, AbstractC1676h0.a(mVarK, c1919n, b.a(focusableKt$FocusableInNonTouchModeElement$1, z3, lVar)).k(new ClickableElement(lVar, z3, str, gVar, aVar)));
    }

    public static /* synthetic */ m d(m mVar, l lVar, X x10, boolean z3, g gVar, p084ga.a aVar, int i10) {
        if ((i10 & 16) != 0) {
            gVar = null;
        }
        return c(mVar, lVar, x10, z3, null, gVar, aVar);
    }

    public static m e(m mVar, boolean z3, String str, p084ga.a aVar, int i10) {
        if ((i10 & 1) != 0) {
            z3 = true;
        }
        if ((i10 & 2) != 0) {
            str = null;
        }
        k.f(mVar, "$this$clickable");
        k.f(aVar, "onClick");
        return C.G(mVar, new u0(z3, str, aVar));
    }
}
