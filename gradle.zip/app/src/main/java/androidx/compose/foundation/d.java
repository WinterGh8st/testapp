package androidx.compose.foundation;

import O.AbstractC0630v;
import O.C0610k;
import O.C0629u;
import O.D;
import Z.j;
import Z.m;
import p084ga.f;
import p097ha.k;
import p097ha.l;
import p232u0.W;
import p248v9.C1774u;
import p271y.A;
import p271y.o0;
import p271y.x0;
import p282ya.e;
import p283z.AbstractC1966o0;
import p283z.X;

/* JADX INFO: loaded from: classes.dex */
public final class d extends l implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ x0 f15714a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public d(x0 x0Var) {
        super(3);
        this.f15714a = x0Var;
    }

    @Override // p084ga.f
    public final Object I(Object obj, Object obj2, Object obj3) {
        C0629u c0629u = (C0629u) obj2;
        ((Number) obj3).intValue();
        k.f((m) obj, "$this$composed");
        c0629u.a0(1478351300);
        o0 o0VarJ = p196q9.a.j(c0629u);
        c0629u.a0(773894976);
        c0629u.a0(-492369756);
        Object objE = c0629u.E();
        if (objE == C0610k.f9587a) {
            D d10 = new D(AbstractC0630v.z(c0629u));
            c0629u.m0(d10);
            objE = d10;
        }
        c0629u.u(false);
        e eVar = ((D) objE).f9451a;
        c0629u.u(false);
        j jVar = j.f14412b;
        x0 x0Var = this.f15714a;
        m mVarA = p284z0.k.a(jVar, false, new C1774u(13, x0Var, eVar));
        X x10 = X.f32990a;
        k.f((N0.j) c0629u.l(W.k), "layoutDirection");
        m mVarB = AbstractC1966o0.b(jVar, x0Var, x10, o0VarJ, true, true, null, x0Var.f32387c);
        m mVarK = p195q8.m.h(A.a(mVarA, x10), o0VarJ).k(mVarB).k(new ScrollingLayoutElement(x0Var));
        c0629u.u(false);
        return mVarK;
    }
}
