package androidx.compose.foundation.layout;

import B.C0042y;
import Z.l;
import p096h9.i;
import p097ha.k;
import p220t0.P;
import p260x.AbstractC1876h;

/* JADX INFO: loaded from: classes.dex */
final class FillElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f15733b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15734c;

    public FillElement(int i10, float f10, String str) {
        i.n(i10, "direction");
        this.f15733b = i10;
        this.f15734c = f10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof FillElement)) {
            return false;
        }
        FillElement fillElement = (FillElement) obj;
        return this.f15733b == fillElement.f15733b && this.f15734c == fillElement.f15734c;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Float.hashCode(this.f15734c) + (AbstractC1876h.c(this.f15733b) * 31);
    }

    @Override // p220t0.P
    public final l l() {
        int i10 = this.f15733b;
        i.n(i10, "direction");
        C0042y c0042y = new C0042y();
        c0042y.f666x = i10;
        c0042y.f667y = this.f15734c;
        return c0042y;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C0042y c0042y = (C0042y) lVar;
        k.f(c0042y, "node");
        int i10 = this.f15733b;
        i.n(i10, "<set-?>");
        c0042y.f666x = i10;
        c0042y.f667y = this.f15734c;
    }
}
