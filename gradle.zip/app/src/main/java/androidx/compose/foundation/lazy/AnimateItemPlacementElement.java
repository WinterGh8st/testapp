package androidx.compose.foundation.lazy;

import C.C0061a;
import E.C0154o;
import Z.l;
import p097ha.k;
import p220t0.P;
import p260x.InterfaceC1892y;

/* JADX INFO: loaded from: classes.dex */
final class AnimateItemPlacementElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final InterfaceC1892y f15764b;

    public AnimateItemPlacementElement(InterfaceC1892y interfaceC1892y) {
        this.f15764b = interfaceC1892y;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AnimateItemPlacementElement)) {
            return false;
        }
        return !k.b(this.f15764b, ((AnimateItemPlacementElement) obj).f15764b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15764b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        return new C0061a(this.f15764b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C0061a c0061a = (C0061a) lVar;
        k.f(c0061a, "node");
        C0154o c0154o = c0061a.f1449z;
        c0154o.getClass();
        c0154o.f2837x = this.f15764b;
    }
}
