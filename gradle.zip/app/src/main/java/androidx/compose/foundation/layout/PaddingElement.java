package androidx.compose.foundation.layout;

import B.K;
import Z.l;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class PaddingElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15741b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15742c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f15743d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float f15744e;

    public PaddingElement(float f10, float f11, float f12, float f13, p084ga.c cVar) {
        this.f15741b = f10;
        this.f15742c = f11;
        this.f15743d = f12;
        this.f15744e = f13;
        if ((f10 < 0.0f && !N0.d.a(f10, Float.NaN)) || ((f11 < 0.0f && !N0.d.a(f11, Float.NaN)) || ((f12 < 0.0f && !N0.d.a(f12, Float.NaN)) || (f13 < 0.0f && !N0.d.a(f13, Float.NaN))))) {
            throw new IllegalArgumentException("Padding must be non-negative");
        }
    }

    public final boolean equals(Object obj) {
        PaddingElement paddingElement = obj instanceof PaddingElement ? (PaddingElement) obj : null;
        return paddingElement != null && N0.d.a(this.f15741b, paddingElement.f15741b) && N0.d.a(this.f15742c, paddingElement.f15742c) && N0.d.a(this.f15743d, paddingElement.f15743d) && N0.d.a(this.f15744e, paddingElement.f15744e);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(true) + AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(Float.hashCode(this.f15741b) * 31, this.f15742c, 31), this.f15743d, 31), this.f15744e, 31);
    }

    @Override // p220t0.P
    public final l l() {
        K k = new K();
        k.f520x = this.f15741b;
        k.f521y = this.f15742c;
        k.f522z = this.f15743d;
        k.f518A = this.f15744e;
        k.f519B = true;
        return k;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        K k = (K) lVar;
        k.f(k, "node");
        k.f520x = this.f15741b;
        k.f521y = this.f15742c;
        k.f522z = this.f15743d;
        k.f518A = this.f15744e;
        k.f519B = true;
    }
}
