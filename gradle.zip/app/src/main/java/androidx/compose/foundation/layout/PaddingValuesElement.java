package androidx.compose.foundation.layout;

import B.C0029k;
import B.L;
import B.M;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class PaddingValuesElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final L f15745b;

    public PaddingValuesElement(L l4, C0029k c0029k) {
        k.f(l4, "paddingValues");
        this.f15745b = l4;
    }

    public final boolean equals(Object obj) {
        PaddingValuesElement paddingValuesElement = obj instanceof PaddingValuesElement ? (PaddingValuesElement) obj : null;
        if (paddingValuesElement == null) {
            return false;
        }
        return k.b(this.f15745b, paddingValuesElement.f15745b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15745b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        L l4 = this.f15745b;
        k.f(l4, "paddingValues");
        M m2 = new M();
        m2.f527x = l4;
        return m2;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        M m2 = (M) lVar;
        k.f(m2, "node");
        L l4 = this.f15745b;
        k.f(l4, "<set-?>");
        m2.f527x = l4;
    }
}
