package androidx.compose.foundation;

import A.l;
import p097ha.k;
import p220t0.P;
import p271y.U;

/* JADX INFO: loaded from: classes.dex */
final class HoverableElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15709b;

    public HoverableElement(l lVar) {
        k.f(lVar, "interactionSource");
        this.f15709b = lVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof HoverableElement) && k.b(((HoverableElement) obj).f15709b, this.f15709b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15709b.hashCode() * 31;
    }

    @Override // p220t0.P
    public final Z.l l() {
        l lVar = this.f15709b;
        k.f(lVar, "interactionSource");
        U u5 = new U();
        u5.f32199x = lVar;
        return u5;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        U u5 = (U) lVar;
        k.f(u5, "node");
        l lVar2 = this.f15709b;
        k.f(lVar2, "interactionSource");
        if (k.b(u5.f32199x, lVar2)) {
            return;
        }
        u5.H0();
        u5.f32199x = lVar2;
    }
}
