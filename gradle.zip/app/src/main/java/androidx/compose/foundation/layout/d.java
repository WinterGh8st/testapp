package androidx.compose.foundation.layout;

import A7.A;
import L.K0;
import Z.m;
import p097ha.k;
import p248v9.H;

/* JADX INFO: loaded from: classes.dex */
public abstract class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final FillElement f15759a = new FillElement(2, 1.0f, "fillMaxWidth");

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final FillElement f15760b = new FillElement(1, 1.0f, "fillMaxHeight");

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final FillElement f15761c = new FillElement(3, 1.0f, "fillMaxSize");

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final WrapContentElement f15762d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final WrapContentElement f15763e;

    static {
        Z.b bVar = Z.a.f14400w;
        new WrapContentElement(2, new A(bVar, 4), bVar, "wrapContentWidth");
        Z.b bVar2 = Z.a.f14399v;
        new WrapContentElement(2, new A(bVar2, 4), bVar2, "wrapContentWidth");
        Z.c cVar = Z.a.f14397t;
        new WrapContentElement(1, new A(cVar, 2), cVar, "wrapContentHeight");
        Z.c cVar2 = Z.a.f14396s;
        new WrapContentElement(1, new A(cVar2, 2), cVar2, "wrapContentHeight");
        f15762d = c.m(Z.a.f14392e);
        f15763e = c.m(Z.a.f14388a);
    }

    public static final m a(m mVar, float f10, float f11) {
        k.f(mVar, "$this$defaultMinSize");
        return mVar.k(new UnspecifiedConstraintsElement(f10, f11));
    }

    public static final m b(m mVar, float f10) {
        k.f(mVar, "<this>");
        return mVar.k(f10 == 1.0f ? f15760b : new FillElement(1, f10, "fillMaxHeight"));
    }

    public static m c(m mVar) {
        k.f(mVar, "<this>");
        return mVar.k(f15761c);
    }

    public static final m d(m mVar, float f10) {
        k.f(mVar, "<this>");
        return mVar.k(f10 == 1.0f ? f15759a : new FillElement(2, f10, "fillMaxWidth"));
    }

    public static final m e(m mVar, float f10) {
        k.f(mVar, "$this$height");
        return mVar.k(new SizeElement(0.0f, f10, 0.0f, f10, true, 5));
    }

    public static final m f(float f10, float f11) {
        return new SizeElement(0.0f, f10, 0.0f, f11, true, 5);
    }

    public static final m g(m mVar, float f10) {
        k.f(mVar, "$this$requiredHeight");
        return mVar.k(new SizeElement(0.0f, f10, 0.0f, f10, false, 5));
    }

    public static final m h(m mVar) {
        float f10 = L.A.f7251c;
        k.f(mVar, "$this$requiredSize");
        return mVar.k(new SizeElement(f10, f10, f10, f10, false));
    }

    public static m i(m mVar, float f10, int i10) {
        float f11 = (i10 & 2) != 0 ? Float.NaN : H.f30477b;
        float f12 = (i10 & 8) != 0 ? Float.NaN : f10;
        k.f(mVar, "$this$requiredSizeIn");
        return mVar.k(new SizeElement(Float.NaN, f11, Float.NaN, f12, false));
    }

    public static final m j(m mVar, float f10) {
        k.f(mVar, "$this$requiredWidth");
        return mVar.k(new SizeElement(f10, 0.0f, f10, 0.0f, false, 10));
    }

    public static final m k(m mVar, float f10) {
        k.f(mVar, "$this$size");
        return mVar.k(new SizeElement(f10, f10, f10, f10, true));
    }

    public static final m l(m mVar, float f10, float f11) {
        k.f(mVar, "$this$size");
        return mVar.k(new SizeElement(f10, f11, f10, f11, true));
    }

    public static final m m(m mVar, float f10) {
        k.f(mVar, "$this$width");
        return mVar.k(new SizeElement(f10, 0.0f, f10, 0.0f, true, 10));
    }

    public static m n(m mVar, float f10, int i10) {
        float f11 = K0.f7429b;
        float f12 = (i10 & 1) != 0 ? Float.NaN : f10;
        float f13 = (i10 & 2) != 0 ? Float.NaN : f11;
        k.f(mVar, "$this$widthIn");
        return mVar.k(new SizeElement(f12, 0.0f, f13, 0.0f, true, 10));
    }

    public static m o(m mVar, Z.d dVar) {
        WrapContentElement wrapContentElementM;
        Z.d dVar2 = Z.a.f14392e;
        k.f(mVar, "<this>");
        if (dVar.equals(dVar2)) {
            wrapContentElementM = f15762d;
        } else {
            wrapContentElementM = dVar.equals(Z.a.f14388a) ? f15763e : c.m(dVar);
        }
        return mVar.k(wrapContentElementM);
    }
}
