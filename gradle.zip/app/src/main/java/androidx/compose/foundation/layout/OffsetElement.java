package androidx.compose.foundation.layout;

import B.C0029k;
import B.I;
import Z.l;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class OffsetElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15738b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15739c;

    public OffsetElement(float f10, float f11, C0029k c0029k) {
        this.f15738b = f10;
        this.f15739c = f11;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        OffsetElement offsetElement = obj instanceof OffsetElement ? (OffsetElement) obj : null;
        return offsetElement != null && N0.d.a(this.f15738b, offsetElement.f15738b) && N0.d.a(this.f15739c, offsetElement.f15739c);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(true) + AbstractC1464s.b(Float.hashCode(this.f15738b) * 31, this.f15739c, 31);
    }

    @Override // p220t0.P
    public final l l() {
        I i10 = new I();
        i10.f513x = this.f15738b;
        i10.f514y = this.f15739c;
        i10.f515z = true;
        return i10;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        I i10 = (I) lVar;
        k.f(i10, "node");
        i10.f513x = this.f15738b;
        i10.f514y = this.f15739c;
        i10.f515z = true;
    }

    public final String toString() {
        return "OffsetModifierElement(x=" + ((Object) N0.d.b(this.f15738b)) + ", y=" + ((Object) N0.d.b(this.f15739c)) + ", rtlAware=true)";
    }
}
