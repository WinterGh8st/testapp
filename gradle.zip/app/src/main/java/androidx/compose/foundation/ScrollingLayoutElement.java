package androidx.compose.foundation;

import Z.l;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;
import p271y.x0;
import p271y.y0;

/* JADX INFO: loaded from: classes.dex */
final class ScrollingLayoutElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final x0 f15710b;

    public ScrollingLayoutElement(x0 x0Var) {
        k.f(x0Var, "scrollState");
        this.f15710b = x0Var;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof ScrollingLayoutElement) {
            return k.b(this.f15710b, ((ScrollingLayoutElement) obj).f15710b);
        }
        return false;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(true) + AbstractC1464s.d(this.f15710b.hashCode() * 31, 31, false);
    }

    @Override // p220t0.P
    public final l l() {
        x0 x0Var = this.f15710b;
        k.f(x0Var, "scrollerState");
        y0 y0Var = new y0();
        y0Var.f32395x = x0Var;
        y0Var.f32396y = true;
        return y0Var;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        y0 y0Var = (y0) lVar;
        k.f(y0Var, "node");
        x0 x0Var = this.f15710b;
        k.f(x0Var, "<set-?>");
        y0Var.f32395x = x0Var;
        y0Var.f32396y = true;
    }
}
