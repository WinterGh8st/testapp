package androidx.compose.foundation.layout;

import B.A;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class HorizontalAlignElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Z.b f15735b;

    public HorizontalAlignElement(Z.b bVar) {
        this.f15735b = bVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        HorizontalAlignElement horizontalAlignElement = obj instanceof HorizontalAlignElement ? (HorizontalAlignElement) obj : null;
        if (horizontalAlignElement == null) {
            return false;
        }
        return this.f15735b.equals(horizontalAlignElement.f15735b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Float.hashCode(this.f15735b.f14402a);
    }

    @Override // p220t0.P
    public final l l() {
        Z.b bVar = this.f15735b;
        A a3 = new A();
        a3.f485x = bVar;
        return a3;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        A a3 = (A) lVar;
        k.f(a3, "node");
        a3.f485x = this.f15735b;
    }
}
