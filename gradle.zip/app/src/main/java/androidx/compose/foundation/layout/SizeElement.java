package androidx.compose.foundation.layout;

import B.U;
import Z.l;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class SizeElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15746b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15747c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f15748d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float f15749e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f15750f;

    public SizeElement(float f10, float f11, float f12, float f13, boolean z3) {
        this.f15746b = f10;
        this.f15747c = f11;
        this.f15748d = f12;
        this.f15749e = f13;
        this.f15750f = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SizeElement)) {
            return false;
        }
        SizeElement sizeElement = (SizeElement) obj;
        return N0.d.a(this.f15746b, sizeElement.f15746b) && N0.d.a(this.f15747c, sizeElement.f15747c) && N0.d.a(this.f15748d, sizeElement.f15748d) && N0.d.a(this.f15749e, sizeElement.f15749e) && this.f15750f == sizeElement.f15750f;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(this.f15750f) + AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(Float.hashCode(this.f15746b) * 31, this.f15747c, 31), this.f15748d, 31), this.f15749e, 31);
    }

    @Override // p220t0.P
    public final l l() {
        U u5 = new U();
        u5.f548x = this.f15746b;
        u5.f549y = this.f15747c;
        u5.f550z = this.f15748d;
        u5.f546A = this.f15749e;
        u5.f547B = this.f15750f;
        return u5;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        U u5 = (U) lVar;
        k.f(u5, "node");
        u5.f548x = this.f15746b;
        u5.f549y = this.f15747c;
        u5.f550z = this.f15748d;
        u5.f546A = this.f15749e;
        u5.f547B = this.f15750f;
    }

    public /* synthetic */ SizeElement(float f10, float f11, float f12, float f13, boolean z3, int i10) {
        this((i10 & 1) != 0 ? Float.NaN : f10, (i10 & 2) != 0 ? Float.NaN : f11, (i10 & 4) != 0 ? Float.NaN : f12, (i10 & 8) != 0 ? Float.NaN : f13, z3);
    }
}
