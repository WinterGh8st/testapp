package androidx.compose.foundation.layout;

import B.G;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class LayoutWeightElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15736b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f15737c;

    public LayoutWeightElement(float f10, boolean z3) {
        this.f15736b = f10;
        this.f15737c = z3;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        LayoutWeightElement layoutWeightElement = obj instanceof LayoutWeightElement ? (LayoutWeightElement) obj : null;
        return layoutWeightElement != null && this.f15736b == layoutWeightElement.f15736b && this.f15737c == layoutWeightElement.f15737c;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(this.f15737c) + (Float.hashCode(this.f15736b) * 31);
    }

    @Override // p220t0.P
    public final l l() {
        G g10 = new G();
        g10.f510x = this.f15736b;
        g10.f511y = this.f15737c;
        return g10;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        G g10 = (G) lVar;
        k.f(g10, "node");
        g10.f510x = this.f15736b;
        g10.f511y = this.f15737c;
    }
}
