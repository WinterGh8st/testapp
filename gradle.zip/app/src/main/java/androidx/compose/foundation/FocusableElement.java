package androidx.compose.foundation;

import A.e;
import A.l;
import p097ha.k;
import p220t0.P;
import p271y.G;
import p271y.I;

/* JADX INFO: loaded from: classes.dex */
final class FocusableElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15707b;

    public FocusableElement(l lVar) {
        this.f15707b = lVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof FocusableElement) {
            return k.b(this.f15707b, ((FocusableElement) obj).f15707b);
        }
        return false;
    }

    @Override // p220t0.P
    public final int hashCode() {
        l lVar = this.f15707b;
        if (lVar != null) {
            return lVar.hashCode();
        }
        return 0;
    }

    @Override // p220t0.P
    public final Z.l l() {
        return new I(this.f15707b);
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        A.d dVar;
        I i10 = (I) lVar;
        k.f(i10, "node");
        G g10 = i10.f32167B;
        l lVar2 = g10.f32162x;
        l lVar3 = this.f15707b;
        if (k.b(lVar2, lVar3)) {
            return;
        }
        l lVar4 = g10.f32162x;
        if (lVar4 != null && (dVar = g10.f32163y) != null) {
            lVar4.f13a.c(new e(dVar));
        }
        g10.f32163y = null;
        g10.f32162x = lVar3;
    }
}
