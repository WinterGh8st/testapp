package androidx.compose.foundation;

import A.l;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.P;
import p271y.C1925u;
import p271y.C1927w;
import p271y.C1928x;
import p284z0.g;

/* JADX INFO: loaded from: classes.dex */
final class ClickableElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15702b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final boolean f15703c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final String f15704d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final g f15705e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final p084ga.a f15706f;

    public ClickableElement(l lVar, boolean z3, String str, g gVar, p084ga.a aVar) {
        k.f(lVar, "interactionSource");
        k.f(aVar, "onClick");
        this.f15702b = lVar;
        this.f15703c = z3;
        this.f15704d = str;
        this.f15705e = gVar;
        this.f15706f = aVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!ClickableElement.class.equals(obj != null ? obj.getClass() : null)) {
            return false;
        }
        k.d(obj, "null cannot be cast to non-null type androidx.compose.foundation.ClickableElement");
        ClickableElement clickableElement = (ClickableElement) obj;
        return k.b(this.f15702b, clickableElement.f15702b) && this.f15703c == clickableElement.f15703c && k.b(this.f15704d, clickableElement.f15704d) && k.b(this.f15705e, clickableElement.f15705e) && k.b(this.f15706f, clickableElement.f15706f);
    }

    @Override // p220t0.P
    public final int hashCode() {
        int iD = AbstractC1464s.d(this.f15702b.hashCode() * 31, 31, this.f15703c);
        String str = this.f15704d;
        int iHashCode = (iD + (str != null ? str.hashCode() : 0)) * 31;
        g gVar = this.f15705e;
        return this.f15706f.hashCode() + ((iHashCode + (gVar != null ? Integer.hashCode(gVar.f33186a) : 0)) * 31);
    }

    @Override // p220t0.P
    public final Z.l l() {
        return new C1925u(this.f15702b, this.f15703c, this.f15704d, this.f15705e, this.f15706f);
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        C1925u c1925u = (C1925u) lVar;
        k.f(c1925u, "node");
        l lVar2 = this.f15702b;
        k.f(lVar2, "interactionSource");
        p084ga.a aVar = this.f15706f;
        k.f(aVar, "onClick");
        if (!k.b(c1925u.f32363z, lVar2)) {
            c1925u.G0();
            c1925u.f32363z = lVar2;
        }
        boolean z3 = c1925u.f32358A;
        boolean z5 = this.f15703c;
        if (z3 != z5) {
            if (!z5) {
                c1925u.G0();
            }
            c1925u.f32358A = z5;
        }
        c1925u.f32359B = aVar;
        C1928x c1928x = c1925u.f32361D;
        c1928x.getClass();
        c1928x.f32381x = z5;
        c1928x.f32382y = this.f15704d;
        c1928x.f32383z = this.f15705e;
        c1928x.f32380A = aVar;
        C1927w c1927w = c1925u.f32362E;
        c1927w.getClass();
        c1927w.f32378z = z5;
        c1927w.f32374B = aVar;
        c1927w.f32373A = lVar2;
    }
}
