package androidx.compose.foundation.text.modifiers;

import B0.D;
import G0.InterfaceC0271h;
import J.e;
import J.g;
import Z.l;
import p015b2.a;
import p097ha.k;
import p168o5.b;
import p199r0.AbstractC1464s;
import p220t0.AbstractC1590g;
import p220t0.P;
import p232u0.C1691p;

/* JADX INFO: loaded from: classes.dex */
public final class TextStringSimpleElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f15778b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final D f15779c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final InterfaceC0271h f15780d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f15781e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final boolean f15782f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final int f15783g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final int f15784h;

    public TextStringSimpleElement(String str, D d10, InterfaceC0271h interfaceC0271h, int i10, boolean z3, int i11, int i12) {
        k.f(str, "text");
        k.f(d10, "style");
        k.f(interfaceC0271h, "fontFamilyResolver");
        this.f15778b = str;
        this.f15779c = d10;
        this.f15780d = interfaceC0271h;
        this.f15781e = i10;
        this.f15782f = z3;
        this.f15783g = i11;
        this.f15784h = i12;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof TextStringSimpleElement)) {
            return false;
        }
        TextStringSimpleElement textStringSimpleElement = (TextStringSimpleElement) obj;
        textStringSimpleElement.getClass();
        return k.b(this.f15778b, textStringSimpleElement.f15778b) && k.b(this.f15779c, textStringSimpleElement.f15779c) && k.b(this.f15780d, textStringSimpleElement.f15780d) && this.f15781e == textStringSimpleElement.f15781e && this.f15782f == textStringSimpleElement.f15782f && this.f15783g == textStringSimpleElement.f15783g && this.f15784h == textStringSimpleElement.f15784h;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return (((AbstractC1464s.d(a.a(this.f15781e, (this.f15780d.hashCode() + a.b(this.f15778b.hashCode() * 31, 31, this.f15779c)) * 31, 31), 31, this.f15782f) + this.f15783g) * 31) + this.f15784h) * 31;
    }

    @Override // p220t0.P
    public final l l() {
        String str = this.f15778b;
        k.f(str, "text");
        D d10 = this.f15779c;
        k.f(d10, "style");
        InterfaceC0271h interfaceC0271h = this.f15780d;
        k.f(interfaceC0271h, "fontFamilyResolver");
        g gVar = new g();
        gVar.f6309x = str;
        gVar.f6310y = d10;
        gVar.f6311z = interfaceC0271h;
        gVar.f6302A = this.f15781e;
        gVar.f6303B = this.f15782f;
        gVar.f6304C = this.f15783g;
        gVar.f6305D = this.f15784h;
        return gVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        boolean z3;
        g gVar = (g) lVar;
        k.f(gVar, "node");
        D d10 = this.f15779c;
        k.f(d10, "style");
        D d11 = gVar.f6310y;
        k.f(d11, "other");
        boolean z5 = true;
        boolean z10 = (d10 == d11 || d10.f688a.c(d11.f688a)) ? false : true;
        String str = this.f15778b;
        k.f(str, "text");
        if (k.b(gVar.f6309x, str)) {
            z3 = false;
        } else {
            gVar.f6309x = str;
            z3 = true;
        }
        InterfaceC0271h interfaceC0271h = this.f15780d;
        k.f(interfaceC0271h, "fontFamilyResolver");
        boolean z11 = !gVar.f6310y.c(d10);
        gVar.f6310y = d10;
        int i10 = gVar.f6305D;
        int i11 = this.f15784h;
        if (i10 != i11) {
            gVar.f6305D = i11;
            z11 = true;
        }
        int i12 = gVar.f6304C;
        int i13 = this.f15783g;
        if (i12 != i13) {
            gVar.f6304C = i13;
            z11 = true;
        }
        boolean z12 = gVar.f6303B;
        boolean z13 = this.f15782f;
        if (z12 != z13) {
            gVar.f6303B = z13;
            z11 = true;
        }
        if (!k.b(gVar.f6311z, interfaceC0271h)) {
            gVar.f6311z = interfaceC0271h;
            z11 = true;
        }
        int i14 = gVar.f6302A;
        int i15 = this.f15781e;
        if (i14 == i15) {
            z5 = z11;
        } else {
            gVar.f6302A = i15;
        }
        if (gVar.f14425w) {
            if (z3 || (z10 && gVar.f6308G != null)) {
                androidx.compose.ui.node.a aVarW = AbstractC1590g.w(gVar);
                aVarW.f15852w = null;
                ((C1691p) AbstractC1590g.x(aVarW)).x();
            }
            if (z3 || z5) {
                e eVarF0 = gVar.F0();
                String str2 = gVar.f6309x;
                D d12 = gVar.f6310y;
                InterfaceC0271h interfaceC0271h2 = gVar.f6311z;
                int i16 = gVar.f6302A;
                boolean z14 = gVar.f6303B;
                int i17 = gVar.f6304C;
                int i18 = gVar.f6305D;
                k.f(str2, "text");
                k.f(d12, "style");
                k.f(interfaceC0271h2, "fontFamilyResolver");
                eVarF0.f6272a = str2;
                eVarF0.f6273b = d12;
                eVarF0.f6274c = interfaceC0271h2;
                eVarF0.f6275d = i16;
                eVarF0.f6276e = z14;
                eVarF0.f6277f = i17;
                eVarF0.f6278g = i18;
                eVarF0.f6281j = null;
                eVarF0.f6284n = null;
                eVarF0.f6285o = null;
                eVarF0.f6287q = -1;
                eVarF0.f6288r = -1;
                eVarF0.f6286p = com.bumptech.glide.e.B(0, 0);
                eVarF0.f6282l = b.b(0, 0);
                eVarF0.k = false;
                AbstractC1590g.t(gVar);
                AbstractC1590g.s(gVar);
            }
            if (z10) {
                AbstractC1590g.s(gVar);
            }
        }
    }
}
