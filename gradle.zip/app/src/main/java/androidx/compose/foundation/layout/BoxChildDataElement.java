package androidx.compose.foundation.layout;

import B.C0028j;
import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class BoxChildDataElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Z.d f15732b;

    public BoxChildDataElement(Z.d dVar) {
        this.f15732b = dVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        BoxChildDataElement boxChildDataElement = obj instanceof BoxChildDataElement ? (BoxChildDataElement) obj : null;
        return boxChildDataElement != null && this.f15732b.equals(boxChildDataElement.f15732b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Boolean.hashCode(false) + (this.f15732b.hashCode() * 31);
    }

    @Override // p220t0.P
    public final l l() {
        Z.d dVar = this.f15732b;
        C0028j c0028j = new C0028j();
        c0028j.f626x = dVar;
        return c0028j;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C0028j c0028j = (C0028j) lVar;
        k.f(c0028j, "node");
        c0028j.f626x = this.f15732b;
    }
}
