package androidx.compose.foundation;

import Z.j;
import Z.l;
import Z.m;
import androidx.compose.ui.focus.FocusTargetNode$FocusTargetElement;
import p097ha.k;
import p220t0.P;
import p232u0.C1674g0;
import p232u0.C1685m;
import p271y.E;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final C1674g0 f15711a = new C1674g0(C1685m.f29826y);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final FocusableKt$FocusableInNonTouchModeElement$1 f15712b = new P() { // from class: androidx.compose.foundation.FocusableKt$FocusableInNonTouchModeElement$1
        public final boolean equals(Object obj) {
            return this == obj;
        }

        @Override // p220t0.P
        public final int hashCode() {
            return System.identityHashCode(this);
        }

        @Override // p220t0.P
        public final l l() {
            return new E();
        }

        @Override // p220t0.P
        public final void m(l lVar) {
            k.f((E) lVar, "node");
        }
    };

    public static final m a(m mVar, boolean z3, A.l lVar) {
        k.f(mVar, "<this>");
        return mVar.k(z3 ? new FocusableElement(lVar).k(FocusTargetNode$FocusTargetElement.f15799b) : j.f14412b);
    }
}
