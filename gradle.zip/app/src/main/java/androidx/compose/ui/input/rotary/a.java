package androidx.compose.ui.input.rotary;

import Z.m;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a() {
        return new RotaryInputElement();
    }
}
