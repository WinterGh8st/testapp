package androidx.compose.ui.input.pointer;

import Z.l;
import o0.J;
import p084ga.e;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class SuspendPointerInputElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f15813b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final e f15814c;

    public SuspendPointerInputElement(Object obj, e eVar) {
        k.f(eVar, "pointerInputHandler");
        this.f15813b = obj;
        this.f15814c = eVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof SuspendPointerInputElement) {
            return k.b(this.f15813b, ((SuspendPointerInputElement) obj).f15813b);
        }
        return false;
    }

    @Override // p220t0.P
    public final int hashCode() {
        Object obj = this.f15813b;
        return (obj != null ? obj.hashCode() : 0) * 961;
    }

    @Override // p220t0.P
    public final l l() {
        return new J(this.f15814c);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        J j10 = (J) lVar;
        k.f(j10, "node");
        e eVar = this.f15814c;
        k.f(eVar, "value");
        j10.H0();
        j10.f26130x = eVar;
    }
}
