package androidx.compose.ui.semantics;

import Z.l;
import p097ha.k;
import p220t0.P;
import p284z0.d;

/* JADX INFO: loaded from: classes.dex */
public final class EmptySemanticsElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final EmptySemanticsElement f15869b = new EmptySemanticsElement();

    private EmptySemanticsElement() {
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return System.identityHashCode(this);
    }

    @Override // p220t0.P
    public final l l() {
        return new d();
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        k.f((d) lVar, "node");
    }
}
