package androidx.compose.ui.platform;

import O.AbstractC0630v;
import O.C0603g0;
import O.C0619o0;
import O.C0629u;
import O.W;
import android.content.Context;
import android.util.AttributeSet;
import p084ga.e;
import p097ha.k;
import p162n9.C1279q;

/* JADX INFO: loaded from: classes.dex */
public final class ComposeView extends AbstractComposeView {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final C0603g0 f15865s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f15866t;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ComposeView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 4);
        k.f(context, "context");
    }

    public static /* synthetic */ void getShouldCreateCompositionOnAttachedToWindow$annotations() {
    }

    @Override // androidx.compose.ui.platform.AbstractComposeView
    public final void a(int i10, C0629u c0629u) {
        c0629u.b0(420213850);
        e eVar = (e) this.f15865s.getValue();
        if (eVar != null) {
            eVar.invoke(c0629u, 0);
        }
        C0619o0 c0619o0W = c0629u.w();
        if (c0619o0W == null) {
            return;
        }
        c0619o0W.f9606d = new C1279q(this, i10, 8);
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.compose.ui.platform.ComposeView";
    }

    @Override // androidx.compose.ui.platform.AbstractComposeView
    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return this.f15866t;
    }

    public final void setContent(e eVar) {
        k.f(eVar, "content");
        this.f15866t = true;
        this.f15865s.setValue(eVar);
        if (isAttachedToWindow()) {
            if (this.f15860d == null && !isAttachedToWindow()) {
                throw new IllegalStateException("createComposition requires either a parent reference or the View to be attachedto a window. Attach the View or call setParentCompositionReference.");
            }
            d();
        }
    }

    public ComposeView(Context context, AttributeSet attributeSet, int i10) {
        super(context, (i10 & 2) != 0 ? null : attributeSet, 0);
        this.f15865s = AbstractC0630v.I(null, W.f9545e);
    }
}
