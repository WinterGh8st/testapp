package androidx.compose.ui.draw;

import Z.l;
import p013b0.b;
import p084ga.c;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class DrawWithCacheElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f15787b;

    public DrawWithCacheElement(c cVar) {
        k.f(cVar, "onBuildDrawCache");
        this.f15787b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof DrawWithCacheElement) && k.b(this.f15787b, ((DrawWithCacheElement) obj).f15787b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15787b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        return new b(new p013b0.c(), this.f15787b);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        b bVar = (b) lVar;
        k.f(bVar, "node");
        c cVar = this.f15787b;
        k.f(cVar, "value");
        bVar.f17232z = cVar;
        bVar.F0();
    }

    public final String toString() {
        return "DrawWithCacheElement(onBuildDrawCache=" + this.f15787b + ')';
    }
}
