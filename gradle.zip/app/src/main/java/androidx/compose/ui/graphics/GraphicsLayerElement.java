package androidx.compose.ui.graphics;

import J7.g;
import Z.l;
import p050e0.J;
import p050e0.K;
import p050e0.O;
import p050e0.q;
import p097ha.k;
import p199r0.AbstractC1464s;
import p220t0.AbstractC1590g;
import p220t0.P;
import p220t0.V;

/* JADX INFO: loaded from: classes.dex */
final class GraphicsLayerElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final float f15801b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final float f15802c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final float f15803d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final long f15804e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final J f15805f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final boolean f15806g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final long f15807h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final long f15808i;

    public GraphicsLayerElement(float f10, float f11, float f12, long j10, J j11, boolean z3, long j12, long j13) {
        this.f15801b = f10;
        this.f15802c = f11;
        this.f15803d = f12;
        this.f15804e = j10;
        this.f15805f = j11;
        this.f15806g = z3;
        this.f15807h = j12;
        this.f15808i = j13;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof GraphicsLayerElement) {
            GraphicsLayerElement graphicsLayerElement = (GraphicsLayerElement) obj;
            if (Float.compare(this.f15801b, graphicsLayerElement.f15801b) == 0 && Float.compare(this.f15802c, graphicsLayerElement.f15802c) == 0 && Float.compare(this.f15803d, graphicsLayerElement.f15803d) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(0.0f, 0.0f) == 0 && Float.compare(8.0f, 8.0f) == 0) {
                int i10 = O.f21726c;
                if (this.f15804e == graphicsLayerElement.f15804e && this.f15805f.equals(graphicsLayerElement.f15805f) && this.f15806g == graphicsLayerElement.f15806g && q.c(this.f15807h, graphicsLayerElement.f15807h) && q.c(this.f15808i, graphicsLayerElement.f15808i)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v14, types: [int] */
    /* JADX WARN: Type inference failed for: r0v18 */
    /* JADX WARN: Type inference failed for: r0v19 */
    /* JADX WARN: Type inference failed for: r2v10, types: [int] */
    @Override // p220t0.P
    public final int hashCode() {
        int iB = AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(AbstractC1464s.b(Float.hashCode(this.f15801b) * 31, this.f15802c, 31), this.f15803d, 31), 0.0f, 31), 0.0f, 31), 0.0f, 31), 0.0f, 31), 0.0f, 31), 0.0f, 31), 8.0f, 31);
        int i10 = O.f21726c;
        int iHashCode = (this.f15805f.hashCode() + AbstractC1464s.c(iB, 31, this.f15804e)) * 31;
        boolean z3 = this.f15806g;
        ?? r7 = z3;
        if (z3) {
            r7 = 1;
        }
        int i11 = (iHashCode + r7) * 961;
        int i12 = q.f21753j;
        return Integer.hashCode(0) + AbstractC1464s.c(AbstractC1464s.c(i11, 31, this.f15807h), 31, this.f15808i);
    }

    @Override // p220t0.P
    public final l l() {
        J j10 = this.f15805f;
        K k = new K();
        k.f21719x = this.f15801b;
        k.f21720y = this.f15802c;
        k.f21721z = this.f15803d;
        k.f21712A = 8.0f;
        k.f21713B = this.f15804e;
        k.f21714C = j10;
        k.f21715D = this.f15806g;
        k.f21716E = this.f15807h;
        k.f21717F = this.f15808i;
        k.f21718G = new g(k, 20);
        return k;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        K k = (K) lVar;
        k.f(k, "node");
        k.f21719x = this.f15801b;
        k.f21720y = this.f15802c;
        k.f21721z = this.f15803d;
        k.f21712A = 8.0f;
        k.f21713B = this.f15804e;
        k.f21714C = this.f15805f;
        k.f21715D = this.f15806g;
        k.f21716E = this.f15807h;
        k.f21717F = this.f15808i;
        V v10 = AbstractC1590g.v(k, 2).f29095s;
        if (v10 != null) {
            v10.b1(k.f21718G, true);
        }
    }

    public final String toString() {
        return "GraphicsLayerElement(scaleX=" + this.f15801b + ", scaleY=" + this.f15802c + ", alpha=" + this.f15803d + ", translationX=0.0, translationY=0.0, shadowElevation=0.0, rotationX=0.0, rotationY=0.0, rotationZ=0.0, cameraDistance=8.0, transformOrigin=" + ((Object) O.a(this.f15804e)) + ", shape=" + this.f15805f + ", clip=" + this.f15806g + ", renderEffect=null, ambientShadowColor=" + ((Object) q.i(this.f15807h)) + ", spotShadowColor=" + ((Object) q.i(this.f15808i)) + ", compositingStrategy=CompositingStrategy(value=0))";
    }
}
