package androidx.compose.ui.input.nestedscroll;

import Z.m;
import p097ha.k;
import p154n0.d;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(m mVar, p154n0.a aVar, d dVar) {
        k.f(mVar, "<this>");
        k.f(aVar, "connection");
        return mVar.k(new NestedScrollElement(aVar, dVar));
    }
}
