package androidx.compose.ui.semantics;

import Z.k;
import Z.l;
import p084ga.c;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class AppendedSemanticsElement extends P implements k {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f15867b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final c f15868c;

    public AppendedSemanticsElement(c cVar, boolean z3) {
        p097ha.k.f(cVar, "properties");
        this.f15867b = z3;
        this.f15868c = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppendedSemanticsElement)) {
            return false;
        }
        AppendedSemanticsElement appendedSemanticsElement = (AppendedSemanticsElement) obj;
        return this.f15867b == appendedSemanticsElement.f15867b && p097ha.k.b(this.f15868c, appendedSemanticsElement.f15868c);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v4 */
    @Override // p220t0.P
    public final int hashCode() {
        boolean z3 = this.f15867b;
        ?? r7 = z3;
        if (z3) {
            r7 = 1;
        }
        return this.f15868c.hashCode() + (r7 * 31);
    }

    @Override // p220t0.P
    public final l l() {
        c cVar = this.f15868c;
        p097ha.k.f(cVar, "properties");
        p284z0.c cVar2 = new p284z0.c();
        cVar2.f33182x = this.f15867b;
        cVar2.f33183y = cVar;
        return cVar2;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        p284z0.c cVar = (p284z0.c) lVar;
        p097ha.k.f(cVar, "node");
        cVar.f33182x = this.f15867b;
        c cVar2 = this.f15868c;
        p097ha.k.f(cVar2, "<set-?>");
        cVar.f33183y = cVar2;
    }

    public final String toString() {
        return "AppendedSemanticsElement(mergeDescendants=" + this.f15867b + ", properties=" + this.f15868c + ')';
    }
}
