package androidx.compose.ui.input.key;

import Z.m;
import p084ga.c;
import p097ha.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(c cVar) {
        return new KeyInputElement(cVar, null);
    }

    public static final m b(m mVar, c cVar) {
        k.f(mVar, "<this>");
        return mVar.k(new KeyInputElement(null, cVar));
    }
}
