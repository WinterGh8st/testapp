package androidx.compose.ui.focus;

import Z.l;
import p084ga.c;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class FocusChangedElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f15794b;

    public FocusChangedElement(c cVar) {
        k.f(cVar, "onFocusChanged");
        this.f15794b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusChangedElement) && k.b(this.f15794b, ((FocusChangedElement) obj).f15794b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15794b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        c cVar = this.f15794b;
        k.f(cVar, "onFocusChanged");
        p025c0.a aVar = new p025c0.a();
        aVar.f17966x = cVar;
        return aVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        p025c0.a aVar = (p025c0.a) lVar;
        k.f(aVar, "node");
        c cVar = this.f15794b;
        k.f(cVar, "<set-?>");
        aVar.f17966x = cVar;
    }

    public final String toString() {
        return "FocusChangedElement(onFocusChanged=" + this.f15794b + ')';
    }
}
