package androidx.compose.ui.focus;

import Z.l;
import p025c0.p;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class FocusTargetNode$FocusTargetElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final FocusTargetNode$FocusTargetElement f15799b = new FocusTargetNode$FocusTargetElement();

    private FocusTargetNode$FocusTargetElement() {
    }

    public final boolean equals(Object obj) {
        return obj == this;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return 1739042953;
    }

    @Override // p220t0.P
    public final l l() {
        return new p();
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        k.f((p) lVar, "node");
    }
}
