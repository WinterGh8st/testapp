package androidx.compose.ui.layout;

import Z.l;
import p084ga.c;
import p097ha.k;
import p199r0.G;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class OnGloballyPositionedElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f15817b;

    public OnGloballyPositionedElement(c cVar) {
        k.f(cVar, "onGloballyPositioned");
        this.f15817b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof OnGloballyPositionedElement)) {
            return false;
        }
        return k.b(this.f15817b, ((OnGloballyPositionedElement) obj).f15817b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15817b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        c cVar = this.f15817b;
        k.f(cVar, "callback");
        G g10 = new G();
        g10.f27569x = cVar;
        return g10;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        G g10 = (G) lVar;
        k.f(g10, "node");
        c cVar = this.f15817b;
        k.f(cVar, "<set-?>");
        g10.f27569x = cVar;
    }
}
