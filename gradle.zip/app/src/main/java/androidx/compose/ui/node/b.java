package androidx.compose.ui.node;

import Z.k;
import p220t0.P;
import p220t0.S;

/* JADX INFO: loaded from: classes.dex */
public abstract class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final S f15856a;

    static {
        S s5 = new S();
        s5.f14416d = -1;
        f15856a = s5;
    }

    public static final int a(k kVar, k kVar2) {
        p097ha.k.f(kVar, "prev");
        p097ha.k.f(kVar2, "next");
        if (kVar.equals(kVar2)) {
            return 2;
        }
        if (kVar.getClass() == kVar2.getClass()) {
            return 1;
        }
        if (!(kVar instanceof ForceUpdateElement)) {
            return 0;
        }
        P p10 = ((ForceUpdateElement) kVar).f15818b;
        p097ha.k.f(p10, "a");
        return p10.getClass() == kVar2.getClass() ? 1 : 0;
    }
}
