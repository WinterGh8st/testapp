package androidx.compose.ui.layout;

import p084ga.f;
import p097ha.k;
import p097ha.l;
import p199r0.r;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class LayoutElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15815b;

    /* JADX WARN: Multi-variable type inference failed */
    public LayoutElement(f fVar) {
        this.f15815b = (l) fVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof LayoutElement) && this.f15815b.equals(((LayoutElement) obj).f15815b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15815b.hashCode();
    }

    @Override // p220t0.P
    public final Z.l l() {
        l lVar = this.f15815b;
        r rVar = new r();
        rVar.f27627x = lVar;
        return rVar;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        r rVar = (r) lVar;
        k.f(rVar, "node");
        rVar.f27627x = this.f15815b;
    }

    public final String toString() {
        return "LayoutElement(measure=" + this.f15815b + ')';
    }
}
