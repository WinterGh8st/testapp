package androidx.compose.ui.input.rotary;

import Z.l;
import p097ha.k;
import p220t0.P;
import p232u0.C1685m;

/* JADX INFO: loaded from: classes.dex */
final class RotaryInputElement extends P {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof RotaryInputElement)) {
            return false;
        }
        ((RotaryInputElement) obj).getClass();
        Object obj2 = C1685m.f29814c;
        return obj2.equals(obj2);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return C1685m.f29814c.hashCode() * 31;
    }

    @Override // p220t0.P
    public final l l() {
        p188q0.a aVar = new p188q0.a();
        aVar.f27442x = C1685m.f29814c;
        return aVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        p188q0.a aVar = (p188q0.a) lVar;
        k.f(aVar, "node");
        aVar.f27442x = C1685m.f29814c;
    }

    public final String toString() {
        return "RotaryInputElement(onRotaryScrollEvent=" + C1685m.f29814c + ", onPreRotaryScrollEvent=null)";
    }
}
