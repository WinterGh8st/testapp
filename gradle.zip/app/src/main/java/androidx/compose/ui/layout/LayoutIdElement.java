package androidx.compose.ui.layout;

import Z.l;
import p097ha.k;
import p199r0.C1462p;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class LayoutIdElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final String f15816b;

    public LayoutIdElement(String str) {
        this.f15816b = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof LayoutIdElement) && this.f15816b.equals(((LayoutIdElement) obj).f15816b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15816b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        String str = this.f15816b;
        C1462p c1462p = new C1462p();
        c1462p.f27626x = str;
        return c1462p;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C1462p c1462p = (C1462p) lVar;
        k.f(c1462p, "node");
        c1462p.f27626x = this.f15816b;
    }

    public final String toString() {
        return "LayoutIdElement(layoutId=" + ((Object) this.f15816b) + ')';
    }
}
