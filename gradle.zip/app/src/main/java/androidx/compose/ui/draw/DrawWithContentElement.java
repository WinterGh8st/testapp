package androidx.compose.ui.draw;

import p013b0.f;
import p084ga.c;
import p097ha.k;
import p097ha.l;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class DrawWithContentElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15788b;

    /* JADX WARN: Multi-variable type inference failed */
    public DrawWithContentElement(c cVar) {
        this.f15788b = (l) cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof DrawWithContentElement) && this.f15788b.equals(((DrawWithContentElement) obj).f15788b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15788b.hashCode();
    }

    @Override // p220t0.P
    public final Z.l l() {
        l lVar = this.f15788b;
        f fVar = new f();
        fVar.f17236x = lVar;
        return fVar;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        f fVar = (f) lVar;
        k.f(fVar, "node");
        fVar.f17236x = this.f15788b;
    }

    public final String toString() {
        return "DrawWithContentElement(onDraw=" + this.f15788b + ')';
    }
}
