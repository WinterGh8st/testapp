package androidx.compose.ui.graphics;

import Z.m;
import p050e0.E;
import p050e0.J;
import p050e0.O;
import p050e0.x;
import p084ga.c;
import p097ha.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(m mVar, c cVar) {
        k.f(mVar, "<this>");
        k.f(cVar, "block");
        return mVar.k(new BlockGraphicsLayerElement(cVar));
    }

    public static m b(m mVar, float f10, float f11, float f12, J j10, int i10) {
        float f13 = (i10 & 1) != 0 ? 1.0f : f10;
        float f14 = (i10 & 2) != 0 ? 1.0f : f11;
        float f15 = (i10 & 4) != 0 ? 1.0f : f12;
        long j11 = O.f21725b;
        J j12 = (i10 & 2048) != 0 ? E.f21690a : j10;
        boolean z3 = (i10 & 4096) == 0;
        long j13 = x.f21762a;
        k.f(mVar, "$this$graphicsLayer");
        k.f(j12, "shape");
        return mVar.k(new GraphicsLayerElement(f13, f14, f15, j11, j12, z3, j13, j13));
    }
}
