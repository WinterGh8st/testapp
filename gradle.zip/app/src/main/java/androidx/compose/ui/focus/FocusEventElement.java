package androidx.compose.ui.focus;

import Z.l;
import p025c0.d;
import p097ha.k;
import p220t0.P;
import p248v9.C1774u;

/* JADX INFO: loaded from: classes.dex */
final class FocusEventElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final C1774u f15795b;

    public FocusEventElement(C1774u c1774u) {
        this.f15795b = c1774u;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusEventElement) && this.f15795b.equals(((FocusEventElement) obj).f15795b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15795b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        C1774u c1774u = this.f15795b;
        d dVar = new d();
        dVar.f17969x = c1774u;
        return dVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        d dVar = (d) lVar;
        k.f(dVar, "node");
        dVar.f17969x = this.f15795b;
    }

    public final String toString() {
        return "FocusEventElement(onFocusEvent=" + this.f15795b + ')';
    }
}
