package androidx.compose.ui.focus;

import p025c0.k;
import p084ga.c;
import p097ha.l;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class FocusPropertiesElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15797b;

    /* JADX WARN: Multi-variable type inference failed */
    public FocusPropertiesElement(c cVar) {
        this.f15797b = (l) cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusPropertiesElement) && this.f15797b.equals(((FocusPropertiesElement) obj).f15797b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15797b.hashCode();
    }

    @Override // p220t0.P
    public final Z.l l() {
        l lVar = this.f15797b;
        k kVar = new k();
        kVar.f17989x = lVar;
        return kVar;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        k kVar = (k) lVar;
        p097ha.k.f(kVar, "node");
        kVar.f17989x = this.f15797b;
    }

    public final String toString() {
        return "FocusPropertiesElement(scope=" + this.f15797b + ')';
    }
}
