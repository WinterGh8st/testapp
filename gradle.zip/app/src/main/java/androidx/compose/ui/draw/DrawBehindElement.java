package androidx.compose.ui.draw;

import Z.l;
import p013b0.d;
import p084ga.c;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class DrawBehindElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f15786b;

    public DrawBehindElement(c cVar) {
        k.f(cVar, "onDraw");
        this.f15786b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof DrawBehindElement) && k.b(this.f15786b, ((DrawBehindElement) obj).f15786b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15786b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        c cVar = this.f15786b;
        k.f(cVar, "onDraw");
        d dVar = new d();
        dVar.f17235x = cVar;
        return dVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        d dVar = (d) lVar;
        k.f(dVar, "node");
        c cVar = this.f15786b;
        k.f(cVar, "<set-?>");
        dVar.f17235x = cVar;
    }

    public final String toString() {
        return "DrawBehindElement(onDraw=" + this.f15786b + ')';
    }
}
