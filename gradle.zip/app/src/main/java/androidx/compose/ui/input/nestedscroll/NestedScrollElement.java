package androidx.compose.ui.input.nestedscroll;

import U8.g0;
import Z.l;
import p097ha.k;
import p154n0.d;
import p154n0.g;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class NestedScrollElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p154n0.a f15811b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f15812c;

    public NestedScrollElement(p154n0.a aVar, d dVar) {
        k.f(aVar, "connection");
        this.f15811b = aVar;
        this.f15812c = dVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof NestedScrollElement)) {
            return false;
        }
        NestedScrollElement nestedScrollElement = (NestedScrollElement) obj;
        return k.b(nestedScrollElement.f15811b, this.f15811b) && k.b(nestedScrollElement.f15812c, this.f15812c);
    }

    @Override // p220t0.P
    public final int hashCode() {
        int iHashCode = this.f15811b.hashCode() * 31;
        d dVar = this.f15812c;
        return iHashCode + (dVar != null ? dVar.hashCode() : 0);
    }

    @Override // p220t0.P
    public final l l() {
        return new g(this.f15811b, this.f15812c);
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        g gVar = (g) lVar;
        k.f(gVar, "node");
        p154n0.a aVar = this.f15811b;
        k.f(aVar, "connection");
        gVar.f25197x = aVar;
        d dVar = gVar.f25198y;
        if (dVar.f25183a == gVar) {
            dVar.f25183a = null;
        }
        d dVar2 = this.f15812c;
        if (dVar2 == null) {
            gVar.f25198y = new d();
        } else if (!dVar2.equals(dVar)) {
            gVar.f25198y = dVar2;
        }
        if (gVar.f14425w) {
            d dVar3 = gVar.f25198y;
            dVar3.f25183a = gVar;
            dVar3.f25184b = new g0(gVar, 17);
            dVar3.f25185c = gVar.u0();
        }
    }
}
