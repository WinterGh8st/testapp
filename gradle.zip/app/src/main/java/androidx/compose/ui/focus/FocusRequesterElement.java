package androidx.compose.ui.focus;

import p025c0.l;
import p025c0.n;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class FocusRequesterElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final l f15798b;

    public FocusRequesterElement(l lVar) {
        k.f(lVar, "focusRequester");
        this.f15798b = lVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof FocusRequesterElement) && k.b(this.f15798b, ((FocusRequesterElement) obj).f15798b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15798b.hashCode();
    }

    @Override // p220t0.P
    public final Z.l l() {
        l lVar = this.f15798b;
        k.f(lVar, "focusRequester");
        n nVar = new n();
        nVar.f17993x = lVar;
        return nVar;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        n nVar = (n) lVar;
        k.f(nVar, "node");
        nVar.f17993x.f17992a.l(nVar);
        l lVar2 = this.f15798b;
        k.f(lVar2, "<set-?>");
        nVar.f17993x = lVar2;
        lVar2.f17992a.b(nVar);
    }

    public final String toString() {
        return "FocusRequesterElement(focusRequester=" + this.f15798b + ')';
    }
}
