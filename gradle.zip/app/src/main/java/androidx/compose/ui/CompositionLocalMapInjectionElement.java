package androidx.compose.ui;

import O.InterfaceC0611k0;
import Z.i;
import Z.l;
import p097ha.k;
import p220t0.AbstractC1590g;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class CompositionLocalMapInjectionElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final InterfaceC0611k0 f15785b;

    public CompositionLocalMapInjectionElement(InterfaceC0611k0 interfaceC0611k0) {
        k.f(interfaceC0611k0, "map");
        this.f15785b = interfaceC0611k0;
    }

    public final boolean equals(Object obj) {
        return (obj instanceof CompositionLocalMapInjectionElement) && k.b(((CompositionLocalMapInjectionElement) obj).f15785b, this.f15785b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15785b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        InterfaceC0611k0 interfaceC0611k0 = this.f15785b;
        k.f(interfaceC0611k0, "map");
        i iVar = new i();
        iVar.f14411x = interfaceC0611k0;
        return iVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        i iVar = (i) lVar;
        k.f(iVar, "node");
        InterfaceC0611k0 interfaceC0611k0 = this.f15785b;
        k.f(interfaceC0611k0, "value");
        iVar.f14411x = interfaceC0611k0;
        AbstractC1590g.w(iVar).T(interfaceC0611k0);
    }
}
