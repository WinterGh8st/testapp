package androidx.compose.ui.graphics;

import Z.l;
import p050e0.C1059l;
import p084ga.c;
import p097ha.k;
import p220t0.AbstractC1590g;
import p220t0.P;
import p220t0.V;

/* JADX INFO: loaded from: classes.dex */
final class BlockGraphicsLayerElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final c f15800b;

    public BlockGraphicsLayerElement(c cVar) {
        k.f(cVar, "block");
        this.f15800b = cVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof BlockGraphicsLayerElement) && k.b(this.f15800b, ((BlockGraphicsLayerElement) obj).f15800b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15800b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        c cVar = this.f15800b;
        k.f(cVar, "layerBlock");
        C1059l c1059l = new C1059l();
        c1059l.f21742x = cVar;
        return c1059l;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        C1059l c1059l = (C1059l) lVar;
        k.f(c1059l, "node");
        c cVar = this.f15800b;
        k.f(cVar, "<set-?>");
        c1059l.f21742x = cVar;
        V v10 = AbstractC1590g.v(c1059l, 2).f29095s;
        if (v10 != null) {
            v10.b1(c1059l.f21742x, true);
        }
    }

    public final String toString() {
        return "BlockGraphicsLayerElement(block=" + this.f15800b + ')';
    }
}
