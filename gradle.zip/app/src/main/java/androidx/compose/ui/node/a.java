package androidx.compose.ui.node;

import C0.i;
import F9.C0241c;
import J7.g;
import L.AbstractC0492c;
import N0.j;
import O.AbstractC0630v;
import O.C;
import O.C0603g0;
import O.InterfaceC0606i;
import O.R0;
import P.e;
import P.h;
import P0.c;
import P0.d;
import P0.q;
import U8.g0;
import Z.f;
import Z.l;
import Z.m;
import androidx.compose.ui.input.pointer.SuspendPointerInputElement;
import java.util.Arrays;
import java.util.List;
import p025c0.p;
import p050e0.G;
import p050e0.InterfaceC1062o;
import p097ha.u;
import p199r0.AbstractC1464s;
import p199r0.y;
import p200r1.f0;
import p220t0.A;
import p220t0.AbstractC1590g;
import p220t0.AbstractC1597n;
import p220t0.B;
import p220t0.C1598o;
import p220t0.C1601s;
import p220t0.C1603u;
import p220t0.C1608z;
import p220t0.D;
import p220t0.E;
import p220t0.H;
import p220t0.InterfaceC1594k;
import p220t0.InterfaceC1595l;
import p220t0.InterfaceC1605w;
import p220t0.J;
import p220t0.K;
import p220t0.O;
import p220t0.P;
import p220t0.S;
import p220t0.V;
import p220t0.Z;
import p220t0.a0;
import p220t0.c0;
import p220t0.d0;
import p220t0.i0;
import p232u0.AbstractC1662a0;
import p232u0.B0;
import p232u0.C1691p;
import p232u0.W;
import p260x.AbstractC1876h;
import p284z0.k;

/* JADX INFO: loaded from: classes.dex */
public final class a implements InterfaceC0606i, c0, InterfaceC1594k, a0 {

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public static final B f15819S = new B("Undefined intrinsics block and it is required");

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public static final C1598o f15820T = C1598o.f29160c;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public static final A f15821U = new A();

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public static final i f15822V = new i(15);

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final f0 f15823A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public N0.b f15824B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public j f15825C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public B0 f15826D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public C f15827E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public boolean f15828F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final C0241c f15829G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final K f15830H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public y f15831I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public V f15832J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public boolean f15833K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public m f15834L;
    public c M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public d f15835N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public boolean f15836O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public boolean f15837P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public int f15838Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public int f15839R;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final boolean f15840a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f15841b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public a f15842c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f15843d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f0 f15844e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public h f15845f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f15846q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public a f15847r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public C1691p f15848s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public q f15849t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f15850u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f15851v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public p284z0.j f15852w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final h f15853x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f15854y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public p199r0.B f15855z;

    public a(int i10) {
        this(k.f33213a.addAndGet(1), (i10 & 1) == 0);
    }

    public static boolean J(a aVar) {
        J j10 = aVar.f15830H.f29039n;
        N0.a aVar2 = j10.f29019s ? new N0.a(j10.f27579d) : null;
        if (aVar2 == null) {
            aVar.getClass();
            return false;
        }
        if (aVar.f15838Q == 3) {
            aVar.c();
        }
        return aVar.f15830H.f29039n.w0(aVar2.f8965a);
    }

    public static void N(a aVar, boolean z3, int i10) {
        C1691p c1691p;
        a aVarR;
        if ((i10 & 1) != 0) {
            z3 = false;
        }
        boolean z5 = (i10 & 2) != 0;
        if (aVar.f15842c == null) {
            throw new IllegalStateException("Lookahead measure cannot be requested on a node that is not a part of theLookaheadLayout");
        }
        C1691p c1691p2 = aVar.f15848s;
        if (c1691p2 == null || aVar.f15851v || aVar.f15840a) {
            return;
        }
        c1691p2.v(aVar, true, z3, z5);
        H h10 = aVar.f15830H.f29040o;
        p097ha.k.c(h10);
        K k = h10.f28992E;
        a aVarR2 = k.f29027a.r();
        int i11 = k.f29027a.f15838Q;
        if (aVarR2 == null || i11 == 3) {
            return;
        }
        while (aVarR2.f15838Q == i11 && (aVarR = aVarR2.r()) != null) {
            aVarR2 = aVarR;
        }
        int iC = AbstractC1876h.c(i11);
        if (iC == 0) {
            if (aVarR2.f15842c != null) {
                N(aVarR2, z3, 2);
                return;
            } else {
                P(aVarR2, z3, 2);
                return;
            }
        }
        if (iC != 1) {
            throw new IllegalStateException("Intrinsics isn't used by the parent");
        }
        if (aVarR2.f15842c == null) {
            aVarR2.O(z3);
        } else {
            if (aVarR2.f15840a || (c1691p = aVarR2.f15848s) == null) {
                return;
            }
            c1691p.w(aVarR2, true, z3);
        }
    }

    public static void P(a aVar, boolean z3, int i10) {
        C1691p c1691p;
        a aVarR;
        if ((i10 & 1) != 0) {
            z3 = false;
        }
        boolean z5 = (i10 & 2) != 0;
        if (aVar.f15851v || aVar.f15840a || (c1691p = aVar.f15848s) == null) {
            return;
        }
        c1691p.v(aVar, false, z3, z5);
        K k = aVar.f15830H.f29039n.f29015H;
        a aVarR2 = k.f29027a.r();
        int i11 = k.f29027a.f15838Q;
        if (aVarR2 == null || i11 == 3) {
            return;
        }
        while (aVarR2.f15838Q == i11 && (aVarR = aVarR2.r()) != null) {
            aVarR2 = aVarR;
        }
        int iC = AbstractC1876h.c(i11);
        if (iC == 0) {
            P(aVarR2, z3, 2);
        } else {
            if (iC != 1) {
                throw new IllegalStateException("Intrinsics isn't used by the parent");
            }
            aVarR2.O(z3);
        }
    }

    public static void Q(a aVar) {
        C1691p c1691p;
        K k = aVar.f15830H;
        if (D.f28972a[AbstractC1876h.c(k.f29028b)] != 1) {
            throw new IllegalStateException("Unexpected state ".concat(AbstractC1464s.p(k.f29028b)));
        }
        if (k.f29029c) {
            P(aVar, true, 2);
            return;
        }
        if (k.f29030d) {
            aVar.O(true);
            return;
        }
        if (k.f29032f) {
            N(aVar, true, 2);
        } else {
            if (!k.f29033g || aVar.f15840a || (c1691p = aVar.f15848s) == null) {
                return;
            }
            c1691p.w(aVar, true, true);
        }
    }

    public final void A() {
        a aVar;
        if (this.f15843d > 0) {
            this.f15846q = true;
        }
        if (!this.f15840a || (aVar = this.f15847r) == null) {
            return;
        }
        aVar.A();
    }

    public final boolean B() {
        return this.f15848s != null;
    }

    public final boolean C() {
        return this.f15830H.f29039n.f29009B;
    }

    public final Boolean D() {
        H h10 = this.f15830H.f29040o;
        if (h10 != null) {
            return Boolean.valueOf(h10.f29001x);
        }
        return null;
    }

    public final void E() {
        if (this.f15838Q == 3) {
            g();
        }
        H h10 = this.f15830H.f29040o;
        p097ha.k.c(h10);
        try {
            h10.f28993f = true;
            if (!h10.f28998u) {
                throw new IllegalStateException("Check failed.");
            }
            h10.g0(h10.f29000w, 0.0f, null);
            h10.f28993f = false;
        } catch (Throwable th) {
            h10.f28993f = false;
            throw th;
        }
    }

    @Override // p220t0.c0
    public final boolean F() {
        return B();
    }

    public final void G(int i10, int i11, int i12) {
        if (i10 == i11) {
            return;
        }
        for (int i13 = 0; i13 < i12; i13++) {
            int i14 = i10 > i11 ? i10 + i13 : i10;
            int i15 = i10 > i11 ? i11 + i13 : (i11 + i12) - 2;
            f0 f0Var = this.f15844e;
            Object objM = ((h) f0Var.f27707b).m(i14);
            g0 g0Var = (g0) f0Var.f27708c;
            g0Var.m();
            ((h) f0Var.f27707b).a(i15, (a) objM);
            g0Var.m();
        }
        I();
        A();
        z();
    }

    public final void H(a aVar) {
        if (aVar.f15830H.f29038m > 0) {
            K k = this.f15830H;
            k.c(k.f29038m - 1);
        }
        if (this.f15848s != null) {
            aVar.i();
        }
        aVar.f15847r = null;
        ((V) aVar.f15829G.f3903d).f29096t = null;
        if (aVar.f15840a) {
            this.f15843d--;
            h hVar = (h) aVar.f15844e.f27707b;
            int i10 = hVar.f10080c;
            if (i10 > 0) {
                Object[] objArr = hVar.f10078a;
                int i11 = 0;
                do {
                    ((V) ((a) objArr[i11]).f15829G.f3903d).f29096t = null;
                    i11++;
                } while (i11 < i10);
            }
        }
        A();
        I();
    }

    public final void I() {
        if (!this.f15840a) {
            this.f15854y = true;
            return;
        }
        a aVarR = r();
        if (aVarR != null) {
            aVarR.I();
        }
    }

    public final void K() {
        f0 f0Var = this.f15844e;
        int i10 = ((h) f0Var.f27707b).f10080c;
        while (true) {
            i10--;
            h hVar = (h) f0Var.f27707b;
            if (-1 >= i10) {
                hVar.g();
                ((g0) f0Var.f27708c).m();
                return;
            }
            H((a) hVar.f10078a[i10]);
        }
    }

    public final void L(int i10, int i11) {
        if (i11 < 0) {
            throw new IllegalArgumentException(AbstractC0492c.h(i11, "count (", ") must be greater than 0").toString());
        }
        int i12 = (i11 + i10) - 1;
        if (i10 > i12) {
            return;
        }
        while (true) {
            f0 f0Var = this.f15844e;
            Object objM = ((h) f0Var.f27707b).m(i12);
            ((g0) f0Var.f27708c).m();
            H((a) objM);
            if (i12 == i10) {
                return;
            } else {
                i12--;
            }
        }
    }

    public final void M() {
        if (this.f15838Q == 3) {
            g();
        }
        J j10 = this.f15830H.f29039n;
        j10.getClass();
        try {
            j10.f29016f = true;
            if (!j10.f29020t) {
                throw new IllegalStateException("Check failed.");
            }
            j10.v0(j10.f29023w, j10.f29025y, j10.f29024x);
            j10.f29016f = false;
        } catch (Throwable th) {
            j10.f29016f = false;
            throw th;
        }
    }

    public final void O(boolean z3) {
        C1691p c1691p;
        if (this.f15840a || (c1691p = this.f15848s) == null) {
            return;
        }
        c1691p.w(this, false, z3);
    }

    public final void R() {
        int i10;
        C0241c c0241c = this.f15829G;
        for (l lVar = (i0) c0241c.f3904e; lVar != null; lVar = lVar.f14417e) {
            if (lVar.f14425w) {
                lVar.B0();
            }
        }
        h hVar = (h) c0241c.f3906g;
        if (hVar != null && (i10 = hVar.f10080c) > 0) {
            Object[] objArr = hVar.f10078a;
            int i11 = 0;
            do {
                Z.k kVar = (Z.k) objArr[i11];
                if (kVar instanceof SuspendPointerInputElement) {
                    ForceUpdateElement forceUpdateElement = new ForceUpdateElement((P) kVar);
                    Object[] objArr2 = hVar.f10078a;
                    Object obj = objArr2[i11];
                    objArr2[i11] = forceUpdateElement;
                }
                i11++;
            } while (i11 < i10);
        }
        l lVar2 = (i0) c0241c.f3904e;
        for (l lVar3 = lVar2; lVar3 != null; lVar3 = lVar3.f14417e) {
            if (lVar3.f14425w) {
                lVar3.D0();
            }
        }
        while (lVar2 != null) {
            if (lVar2.f14425w) {
                lVar2.x0();
            }
            lVar2 = lVar2.f14417e;
        }
    }

    public final void S() {
        h hVarU = u();
        int i10 = hVarU.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i11 = 0;
            do {
                a aVar = (a) objArr[i11];
                int i12 = aVar.f15839R;
                aVar.f15838Q = i12;
                if (i12 != 3) {
                    aVar.S();
                }
                i11++;
            } while (i11 < i10);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v1 */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v12 */
    /* JADX WARN: Type inference failed for: r2v13 */
    /* JADX WARN: Type inference failed for: r2v14 */
    /* JADX WARN: Type inference failed for: r2v2, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v8, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v3, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Type inference failed for: r3v6, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r4v5 */
    public final void T(C c10) {
        p097ha.k.f(c10, "value");
        this.f15827E = c10;
        R0 r7 = W.f29758e;
        V.c cVar = (V.c) c10;
        p097ha.k.f(r7, "key");
        U((N0.b) AbstractC0630v.J(cVar, r7));
        R0 r10 = W.k;
        p097ha.k.f(r10, "key");
        j jVar = (j) AbstractC0630v.J(cVar, r10);
        p097ha.k.f(jVar, "value");
        if (this.f15825C != jVar) {
            this.f15825C = jVar;
            z();
            a aVarR = r();
            if (aVarR != null) {
                aVarR.x();
            }
            y();
        }
        R0 r11 = W.f29768p;
        p097ha.k.f(r11, "key");
        Y((B0) AbstractC0630v.J(cVar, r11));
        l lVar = (l) this.f15829G.f3905f;
        if ((lVar.f14416d & 32768) != 0) {
            while (lVar != null) {
                if ((lVar.f14415c & 32768) != 0) {
                    ?? F10 = lVar;
                    ?? r12 = 0;
                    while (F10 != 0) {
                        if (F10 instanceof InterfaceC1595l) {
                            l lVar2 = ((l) ((InterfaceC1595l) F10)).f14413a;
                            if (lVar2.f14425w) {
                                AbstractC1590g.k(lVar2);
                            } else {
                                lVar2.f14422t = true;
                            }
                        } else if ((F10.f14415c & 32768) != 0 && (F10 instanceof AbstractC1597n)) {
                            l lVar3 = ((AbstractC1597n) F10).f29158y;
                            int i10 = 0;
                            while (lVar3 != null) {
                                if ((lVar3.f14415c & 32768) != 0) {
                                    i10++;
                                    if (i10 == 1) {
                                        F10 = F10;
                                        r12 = r12;
                                        r12 = r12;
                                        F10 = lVar3;
                                    } else {
                                        if (r12 == 0) {
                                            h hVar = new h();
                                            hVar.f10078a = new l[16];
                                            hVar.f10080c = 0;
                                            r12 = hVar;
                                        }
                                        if (F10 != 0) {
                                            r12.b(F10);
                                            F10 = 0;
                                        }
                                        r12.b(lVar3);
                                    }
                                } else {
                                    F10 = F10;
                                    r12 = r12;
                                }
                                lVar3 = lVar3.f14418f;
                                F10 = F10;
                                r12 = r12;
                            }
                            if (i10 == 1) {
                                F10 = F10;
                                r12 = r12;
                            } else {
                                F10 = F10;
                                r12 = r12;
                            }
                        }
                        F10 = AbstractC1590g.f(r12);
                    }
                }
                if ((lVar.f14416d & 32768) == 0) {
                    return;
                } else {
                    lVar = lVar.f14418f;
                }
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v3, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Type inference failed for: r3v6, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r4v4 */
    public final void U(N0.b bVar) {
        p097ha.k.f(bVar, "value");
        if (p097ha.k.b(this.f15824B, bVar)) {
            return;
        }
        this.f15824B = bVar;
        z();
        a aVarR = r();
        if (aVarR != null) {
            aVarR.x();
        }
        y();
        l lVar = (l) this.f15829G.f3905f;
        if ((lVar.f14416d & 16) != 0) {
            while (lVar != null) {
                if ((lVar.f14415c & 16) != 0) {
                    ?? F10 = lVar;
                    ?? r7 = 0;
                    while (F10 != 0) {
                        if (F10 instanceof p220t0.f0) {
                            ((p220t0.f0) F10).n();
                        } else if ((F10.f14415c & 16) != 0 && (F10 instanceof AbstractC1597n)) {
                            l lVar2 = ((AbstractC1597n) F10).f29158y;
                            int i10 = 0;
                            F10 = F10;
                            r7 = r7;
                            while (lVar2 != null) {
                                if ((lVar2.f14415c & 16) != 0) {
                                    i10++;
                                    if (i10 == 1) {
                                        r7 = r7;
                                        F10 = lVar2;
                                    } else {
                                        if (r7 == 0) {
                                            h hVar = new h();
                                            hVar.f10078a = new l[16];
                                            hVar.f10080c = 0;
                                            r7 = hVar;
                                        }
                                        if (F10 != 0) {
                                            r7.b(F10);
                                            F10 = 0;
                                        }
                                        r7.b(lVar2);
                                    }
                                }
                                lVar2 = lVar2.f14418f;
                                F10 = F10;
                                r7 = r7;
                            }
                            if (i10 == 1) {
                            }
                        }
                        F10 = AbstractC1590g.f(r7);
                    }
                }
                if ((lVar.f14416d & 16) == 0) {
                    return;
                } else {
                    lVar = lVar.f14418f;
                }
            }
        }
    }

    public final void V(a aVar) {
        if (p097ha.k.b(aVar, this.f15842c)) {
            return;
        }
        this.f15842c = aVar;
        if (aVar != null) {
            K k = this.f15830H;
            if (k.f29040o == null) {
                k.f29040o = new H(k);
            }
            C0241c c0241c = this.f15829G;
            V v10 = ((C1603u) c0241c.f3902c).f29095s;
            for (V v11 = (V) c0241c.f3903d; !p097ha.k.b(v11, v10) && v11 != null; v11 = v11.f29095s) {
                v11.G0();
            }
        }
        z();
    }

    public final void W(p199r0.B b10) {
        p097ha.k.f(b10, "value");
        if (p097ha.k.b(this.f15855z, b10)) {
            return;
        }
        this.f15855z = b10;
        f0 f0Var = this.f15823A;
        f0Var.getClass();
        ((C0603g0) f0Var.f27708c).setValue(b10);
        z();
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void X(m mVar) {
        p097ha.k.f(mVar, "value");
        if (this.f15840a && this.f15834L != Z.j.f14412b) {
            throw new IllegalArgumentException("Modifiers are not supported on virtual LayoutNodes");
        }
        this.f15834L = mVar;
        C0241c c0241c = this.f15829G;
        c0241c.getClass();
        l lVar = (l) c0241c.f3905f;
        l lVarB = b.f15856a;
        if (lVar == lVarB) {
            throw new IllegalStateException("padChain called on already padded chain");
        }
        lVar.f14417e = lVarB;
        lVarB.f14418f = lVar;
        h hVar = (h) c0241c.f3906g;
        int i10 = 0;
        int i11 = hVar != null ? hVar.f10080c : 0;
        h hVar2 = (h) c0241c.f3907h;
        if (hVar2 == null) {
            hVar2 = new h();
            hVar2.f10078a = new Z.k[16];
            hVar2.f10080c = 0;
        }
        int i12 = hVar2.f10080c;
        if (i12 < 16) {
            i12 = 16;
        }
        h hVar3 = new h();
        hVar3.f10078a = new m[i12];
        hVar3.f10080c = 0;
        hVar3.b(mVar);
        while (hVar3.k()) {
            m mVar2 = (m) hVar3.m(hVar3.f10080c - 1);
            if (mVar2 instanceof f) {
                f fVar = (f) mVar2;
                hVar3.b(fVar.f14408c);
                hVar3.b(fVar.f14407b);
            } else if (mVar2 instanceof Z.k) {
                hVar2.b(mVar2);
            } else {
                mVar2.e(new g(hVar2, 29));
            }
        }
        int i13 = hVar2.f10080c;
        l lVar2 = (i0) c0241c.f3904e;
        a aVar = (a) c0241c.f3901b;
        if (i13 == i11) {
            l lVar3 = lVarB.f14418f;
            int i14 = i11;
            int i15 = 0;
            while (lVar3 != null && i15 < i14) {
                if (hVar == null) {
                    throw new IllegalStateException("expected prior modifier list to be non-empty");
                }
                Z.k kVar = (Z.k) hVar.f10078a[i15];
                Z.k kVar2 = (Z.k) hVar2.f10078a[i15];
                int iA = b.a(kVar, kVar2);
                if (iA == 0) {
                    lVar3 = lVar3.f14417e;
                    break;
                }
                if (iA == 1) {
                    C0241c.h(kVar, kVar2, lVar3);
                }
                lVar3 = lVar3.f14418f;
                i15++;
            }
            l lVar4 = lVar3;
            if (i15 < i14) {
                if (hVar == null) {
                    throw new IllegalStateException("expected prior modifier list to be non-empty");
                }
                if (lVar4 == null) {
                    throw new IllegalStateException("structuralUpdate requires a non-null tail");
                }
                c0241c.f(i15, hVar, hVar2, lVar4, aVar.B());
                i10 = 1;
            }
        } else {
            int i16 = i11;
            if (!aVar.B() && i16 == 0) {
                for (int i17 = 0; i17 < hVar2.f10080c; i17++) {
                    lVarB = C0241c.b((Z.k) hVar2.f10078a[i17], lVarB);
                }
                for (l lVar5 = lVar2.f14417e; lVar5 != null && lVar5 != b.f15856a; lVar5 = lVar5.f14417e) {
                    i10 |= lVar5.f14415c;
                    lVar5.f14416d = i10;
                }
            } else if (hVar2.f10080c != 0) {
                if (hVar == null) {
                    hVar = new h();
                    hVar.f10078a = new Z.k[16];
                    hVar.f10080c = 0;
                }
                c0241c.f(0, hVar, hVar2, lVarB, aVar.B());
            } else {
                if (hVar == null) {
                    throw new IllegalStateException("expected prior modifier list to be non-empty");
                }
                l lVar6 = lVarB.f14418f;
                for (int i18 = 0; lVar6 != null && i18 < hVar.f10080c; i18++) {
                    lVar6 = C0241c.c(lVar6).f14418f;
                }
                a aVarR = aVar.r();
                C1603u c1603u = aVarR != null ? (C1603u) aVarR.f15829G.f3902c : null;
                C1603u c1603u2 = (C1603u) c0241c.f3902c;
                c1603u2.f29096t = c1603u;
                c0241c.f3903d = c1603u2;
            }
            i10 = 1;
        }
        c0241c.f3906g = hVar2;
        if (hVar != null) {
            hVar.g();
        } else {
            hVar = null;
        }
        c0241c.f3907h = hVar;
        S s5 = b.f15856a;
        l lVar7 = s5.f14418f;
        if (lVar7 != null) {
            lVar2 = lVar7;
        }
        lVar2.f14417e = null;
        s5.f14418f = null;
        s5.f14416d = -1;
        s5.f14420r = null;
        if (lVar2 == s5) {
            throw new IllegalStateException("trimChain did not update the head");
        }
        c0241c.f3905f = lVar2;
        if (i10 != 0) {
            c0241c.g();
        }
        this.f15830H.f();
        if (c0241c.d(512) && this.f15842c == null) {
            V(this);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0 */
    /* JADX WARN: Type inference failed for: r2v1, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v10 */
    /* JADX WARN: Type inference failed for: r2v11 */
    /* JADX WARN: Type inference failed for: r2v3 */
    /* JADX WARN: Type inference failed for: r2v4, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r2v5, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    /* JADX WARN: Type inference failed for: r3v0 */
    /* JADX WARN: Type inference failed for: r3v1 */
    /* JADX WARN: Type inference failed for: r3v10 */
    /* JADX WARN: Type inference failed for: r3v11 */
    /* JADX WARN: Type inference failed for: r3v2 */
    /* JADX WARN: Type inference failed for: r3v3, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v4 */
    /* JADX WARN: Type inference failed for: r3v5 */
    /* JADX WARN: Type inference failed for: r3v6, types: [P.h] */
    /* JADX WARN: Type inference failed for: r3v8 */
    /* JADX WARN: Type inference failed for: r3v9 */
    /* JADX WARN: Type inference failed for: r4v4 */
    public final void Y(B0 b10) {
        p097ha.k.f(b10, "value");
        if (p097ha.k.b(this.f15826D, b10)) {
            return;
        }
        this.f15826D = b10;
        l lVar = (l) this.f15829G.f3905f;
        if ((lVar.f14416d & 16) != 0) {
            while (lVar != null) {
                if ((lVar.f14415c & 16) != 0) {
                    ?? F10 = lVar;
                    ?? r7 = 0;
                    while (F10 != 0) {
                        if (F10 instanceof p220t0.f0) {
                            ((p220t0.f0) F10).Z();
                        } else if ((F10.f14415c & 16) != 0 && (F10 instanceof AbstractC1597n)) {
                            l lVar2 = ((AbstractC1597n) F10).f29158y;
                            int i10 = 0;
                            F10 = F10;
                            r7 = r7;
                            while (lVar2 != null) {
                                if ((lVar2.f14415c & 16) != 0) {
                                    i10++;
                                    if (i10 == 1) {
                                        r7 = r7;
                                        F10 = lVar2;
                                    } else {
                                        if (r7 == 0) {
                                            h hVar = new h();
                                            hVar.f10078a = new l[16];
                                            hVar.f10080c = 0;
                                            r7 = hVar;
                                        }
                                        if (F10 != 0) {
                                            r7.b(F10);
                                            F10 = 0;
                                        }
                                        r7.b(lVar2);
                                    }
                                }
                                lVar2 = lVar2.f14418f;
                                F10 = F10;
                                r7 = r7;
                            }
                            if (i10 == 1) {
                            }
                        }
                        F10 = AbstractC1590g.f(r7);
                    }
                }
                if ((lVar.f14416d & 16) == 0) {
                    return;
                } else {
                    lVar = lVar.f14418f;
                }
            }
        }
    }

    public final void Z() {
        if (this.f15843d <= 0 || !this.f15846q) {
            return;
        }
        int i10 = 0;
        this.f15846q = false;
        h hVar = this.f15845f;
        if (hVar == null) {
            hVar = new h();
            hVar.f10078a = new a[16];
            hVar.f10080c = 0;
            this.f15845f = hVar;
        }
        hVar.g();
        h hVar2 = (h) this.f15844e.f27707b;
        int i11 = hVar2.f10080c;
        if (i11 > 0) {
            Object[] objArr = hVar2.f10078a;
            do {
                a aVar = (a) objArr[i10];
                if (aVar.f15840a) {
                    hVar.c(hVar.f10080c, aVar.u());
                } else {
                    hVar.b(aVar);
                }
                i10++;
            } while (i10 < i11);
        }
        K k = this.f15830H;
        k.f29039n.f29012E = true;
        H h10 = k.f29040o;
        if (h10 != null) {
            h10.f28988A = true;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r6v1 */
    /* JADX WARN: Type inference failed for: r6v10 */
    /* JADX WARN: Type inference failed for: r6v11 */
    /* JADX WARN: Type inference failed for: r6v12 */
    /* JADX WARN: Type inference failed for: r6v2, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r6v4 */
    /* JADX WARN: Type inference failed for: r6v5, types: [Z.l] */
    /* JADX WARN: Type inference failed for: r6v6, types: [java.lang.Object] */
    /* JADX WARN: Type inference failed for: r6v7 */
    /* JADX WARN: Type inference failed for: r6v8 */
    /* JADX WARN: Type inference failed for: r6v9 */
    /* JADX WARN: Type inference failed for: r7v0 */
    /* JADX WARN: Type inference failed for: r7v1 */
    /* JADX WARN: Type inference failed for: r7v10 */
    /* JADX WARN: Type inference failed for: r7v11 */
    /* JADX WARN: Type inference failed for: r7v2 */
    /* JADX WARN: Type inference failed for: r7v3, types: [P.h] */
    /* JADX WARN: Type inference failed for: r7v4 */
    /* JADX WARN: Type inference failed for: r7v5 */
    /* JADX WARN: Type inference failed for: r7v6, types: [P.h] */
    /* JADX WARN: Type inference failed for: r7v8 */
    /* JADX WARN: Type inference failed for: r7v9 */
    /* JADX WARN: Type inference failed for: r8v6 */
    @Override // p220t0.a0
    public final void a() {
        l lVar;
        C0241c c0241c = this.f15829G;
        C1603u c1603u = (C1603u) c0241c.f3902c;
        boolean zR = AbstractC1590g.r(128);
        if (zR) {
            lVar = c1603u.f29170N;
        } else {
            lVar = c1603u.f29170N.f14417e;
            if (lVar == null) {
                return;
            }
        }
        G g10 = V.f29082J;
        for (l lVarN0 = c1603u.N0(zR); lVarN0 != null && (lVarN0.f14416d & 128) != 0; lVarN0 = lVarN0.f14418f) {
            if ((lVarN0.f14415c & 128) != 0) {
                ?? F10 = lVarN0;
                ?? r7 = 0;
                while (F10 != 0) {
                    if (F10 instanceof InterfaceC1605w) {
                        ((InterfaceC1605w) F10).U((C1603u) c0241c.f3902c);
                    } else if ((F10.f14415c & 128) != 0 && (F10 instanceof AbstractC1597n)) {
                        l lVar2 = ((AbstractC1597n) F10).f29158y;
                        int i10 = 0;
                        while (lVar2 != null) {
                            if ((lVar2.f14415c & 128) != 0) {
                                i10++;
                                if (i10 == 1) {
                                    F10 = F10;
                                    r7 = r7;
                                    r7 = r7;
                                    F10 = lVar2;
                                } else {
                                    if (r7 == 0) {
                                        h hVar = new h();
                                        hVar.f10078a = new l[16];
                                        hVar.f10080c = 0;
                                        r7 = hVar;
                                    }
                                    if (F10 != 0) {
                                        r7.b(F10);
                                        F10 = 0;
                                    }
                                    r7.b(lVar2);
                                }
                            } else {
                                F10 = F10;
                                r7 = r7;
                            }
                            lVar2 = lVar2.f14418f;
                            F10 = F10;
                            r7 = r7;
                        }
                        if (i10 == 1) {
                            F10 = F10;
                            r7 = r7;
                        } else {
                            F10 = F10;
                            r7 = r7;
                        }
                    }
                    F10 = AbstractC1590g.f(r7);
                }
            }
            if (lVarN0 == lVar) {
                return;
            }
        }
    }

    public final void b(C1691p c1691p) {
        a aVar;
        p097ha.k.f(c1691p, "owner");
        if (this.f15848s != null) {
            throw new IllegalStateException(("Cannot attach " + this + " as it already is attached.  Tree: " + h(0)).toString());
        }
        a aVar2 = this.f15847r;
        if (aVar2 != null && !p097ha.k.b(aVar2.f15848s, c1691p)) {
            StringBuilder sb2 = new StringBuilder("Attaching to a different owner(");
            sb2.append(c1691p);
            sb2.append(") than the parent's owner(");
            a aVarR = r();
            sb2.append(aVarR != null ? aVarR.f15848s : null);
            sb2.append("). This tree: ");
            sb2.append(h(0));
            sb2.append(" Parent tree: ");
            a aVar3 = this.f15847r;
            sb2.append(aVar3 != null ? aVar3.h(0) : null);
            throw new IllegalStateException(sb2.toString().toString());
        }
        a aVarR2 = r();
        K k = this.f15830H;
        if (aVarR2 == null) {
            k.f29039n.f29009B = true;
            H h10 = k.f29040o;
            if (h10 != null) {
                h10.f29001x = true;
            }
        }
        C0241c c0241c = this.f15829G;
        ((V) c0241c.f3903d).f29096t = aVarR2 != null ? (C1603u) aVarR2.f15829G.f3902c : null;
        this.f15848s = c1691p;
        this.f15850u = (aVarR2 != null ? aVarR2.f15850u : -1) + 1;
        if (c0241c.d(8)) {
            this.f15852w = null;
            ((C1691p) AbstractC1590g.x(this)).x();
        }
        a aVar4 = this.f15847r;
        if (aVar4 == null || (aVar = aVar4.f15842c) == null) {
            aVar = this.f15842c;
        }
        V(aVar);
        if (!this.f15837P) {
            for (l lVar = (l) c0241c.f3905f; lVar != null; lVar = lVar.f14418f) {
                lVar.w0();
            }
        }
        h hVar = (h) this.f15844e.f27707b;
        int i10 = hVar.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVar.f10078a;
            int i11 = 0;
            do {
                ((a) objArr[i11]).b(c1691p);
                i11++;
            } while (i11 < i10);
        }
        if (!this.f15837P) {
            c0241c.e();
        }
        z();
        if (aVarR2 != null) {
            aVarR2.z();
        }
        V v10 = ((C1603u) c0241c.f3902c).f29095s;
        for (V v11 = (V) c0241c.f3903d; !p097ha.k.b(v11, v10) && v11 != null; v11 = v11.f29095s) {
            v11.b1(v11.f29099w, true);
            Z z3 = v11.f29093I;
            if (z3 != null) {
                z3.invalidate();
            }
        }
        c cVar = this.M;
        if (cVar != null) {
            cVar.invoke(c1691p);
        }
        k.f();
        if (this.f15837P) {
            return;
        }
        l lVar2 = (l) c0241c.f3905f;
        if ((lVar2.f14416d & 7168) != 0) {
            while (lVar2 != null) {
                int i12 = lVar2.f14415c;
                if (((i12 & 4096) != 0) | ((i12 & 1024) != 0) | ((i12 & 2048) != 0)) {
                    AbstractC1590g.h(lVar2);
                }
                lVar2 = lVar2.f14418f;
            }
        }
    }

    public final void c() {
        this.f15839R = this.f15838Q;
        this.f15838Q = 3;
        h hVarU = u();
        int i10 = hVarU.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i11 = 0;
            do {
                a aVar = (a) objArr[i11];
                if (aVar.f15838Q != 3) {
                    aVar.c();
                }
                i11++;
            } while (i11 < i10);
        }
    }

    @Override // O.InterfaceC0606i
    public final void d() {
        if (!B()) {
            throw new IllegalArgumentException("onReuse is only expected on attached node");
        }
        q qVar = this.f15849t;
        if (qVar != null) {
            qVar.d();
        }
        if (this.f15837P) {
            this.f15837P = false;
        } else {
            R();
        }
        this.f15841b = k.f33213a.addAndGet(1);
        C0241c c0241c = this.f15829G;
        for (l lVar = (l) c0241c.f3905f; lVar != null; lVar = lVar.f14418f) {
            lVar.w0();
        }
        c0241c.e();
    }

    @Override // O.InterfaceC0606i
    public final void e() {
        q qVar = this.f15849t;
        if (qVar != null) {
            qVar.e();
        }
        C0241c c0241c = this.f15829G;
        V v10 = ((C1603u) c0241c.f3902c).f29095s;
        for (V v11 = (V) c0241c.f3903d; !p097ha.k.b(v11, v10) && v11 != null; v11 = v11.f29095s) {
            v11.f29097u = true;
            if (v11.f29093I != null) {
                v11.b1(null, false);
            }
        }
    }

    @Override // O.InterfaceC0606i
    public final void f() {
        q qVar = this.f15849t;
        if (qVar != null) {
            qVar.f();
        }
        this.f15837P = true;
        R();
    }

    public final void g() {
        this.f15839R = this.f15838Q;
        this.f15838Q = 3;
        h hVarU = u();
        int i10 = hVarU.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i11 = 0;
            do {
                a aVar = (a) objArr[i11];
                if (aVar.f15838Q == 2) {
                    aVar.g();
                }
                i11++;
            } while (i11 < i10);
        }
    }

    public final String h(int i10) {
        StringBuilder sb2 = new StringBuilder();
        for (int i11 = 0; i11 < i10; i11++) {
            sb2.append("  ");
        }
        sb2.append("|-");
        sb2.append(toString());
        sb2.append('\n');
        h hVarU = u();
        int i12 = hVarU.f10080c;
        if (i12 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i13 = 0;
            do {
                sb2.append(((a) objArr[i13]).h(i10 + 1));
                i13++;
            } while (i13 < i12);
        }
        String string = sb2.toString();
        p097ha.k.e(string, "tree.toString()");
        if (i10 != 0) {
            return string;
        }
        String strSubstring = string.substring(0, string.length() - 1);
        p097ha.k.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        return strSubstring;
    }

    public final void i() {
        E e10;
        C1691p c1691p = this.f15848s;
        if (c1691p == null) {
            StringBuilder sb2 = new StringBuilder("Cannot detach node that is already detached!  Tree: ");
            a aVarR = r();
            sb2.append(aVarR != null ? aVarR.h(0) : null);
            throw new IllegalStateException(sb2.toString().toString());
        }
        C0241c c0241c = this.f15829G;
        int i10 = ((l) c0241c.f3905f).f14416d & 1024;
        l lVar = (i0) c0241c.f3904e;
        if (i10 != 0) {
            for (l lVar2 = lVar; lVar2 != null; lVar2 = lVar2.f14417e) {
                if ((lVar2.f14415c & 1024) != 0) {
                    h hVar = null;
                    l lVarF = lVar2;
                    while (lVarF != null) {
                        if (lVarF instanceof p) {
                            p pVar = (p) lVarF;
                            if (pVar.f18000z.a()) {
                                ((p025c0.f) ((C1691p) AbstractC1590g.x(this)).getFocusOwner()).b(true, false);
                                pVar.H0();
                            }
                        } else if ((lVarF.f14415c & 1024) != 0 && (lVarF instanceof AbstractC1597n)) {
                            int i11 = 0;
                            for (l lVar3 = ((AbstractC1597n) lVarF).f29158y; lVar3 != null; lVar3 = lVar3.f14418f) {
                                if ((lVar3.f14415c & 1024) != 0) {
                                    i11++;
                                    if (i11 == 1) {
                                        lVarF = lVar3;
                                    } else {
                                        if (hVar == null) {
                                            hVar = new h();
                                            hVar.f10078a = new l[16];
                                            hVar.f10080c = 0;
                                        }
                                        if (lVarF != null) {
                                            hVar.b(lVarF);
                                            lVarF = null;
                                        }
                                        hVar.b(lVar3);
                                    }
                                }
                            }
                            if (i11 == 1) {
                            }
                        }
                        lVarF = AbstractC1590g.f(hVar);
                    }
                }
            }
        }
        a aVarR2 = r();
        K k = this.f15830H;
        if (aVarR2 != null) {
            aVarR2.x();
            aVarR2.z();
            J j10 = k.f29039n;
            j10.getClass();
            j10.f29021u = 3;
            H h10 = k.f29040o;
            if (h10 != null) {
                h10.f28996s = 3;
            }
        }
        E e11 = k.f29039n.f29010C;
        e11.f28974b = true;
        e11.f28975c = false;
        e11.f28977e = false;
        e11.f28976d = false;
        e11.f28978f = false;
        e11.f28979g = false;
        e11.f28980h = null;
        H h11 = k.f29040o;
        if (h11 != null && (e10 = h11.f29002y) != null) {
            e10.f28974b = true;
            e10.f28975c = false;
            e10.f28977e = false;
            e10.f28976d = false;
            e10.f28978f = false;
            e10.f28979g = false;
            e10.f28980h = null;
        }
        d dVar = this.f15835N;
        if (dVar != null) {
            dVar.invoke(c1691p);
        }
        if (c0241c.d(8)) {
            this.f15852w = null;
            ((C1691p) AbstractC1590g.x(this)).x();
        }
        for (l lVar4 = lVar; lVar4 != null; lVar4 = lVar4.f14417e) {
            if (lVar4.f14425w) {
                lVar4.D0();
            }
        }
        this.f15851v = true;
        h hVar2 = (h) this.f15844e.f27707b;
        int i12 = hVar2.f10080c;
        if (i12 > 0) {
            Object[] objArr = hVar2.f10078a;
            int i13 = 0;
            do {
                ((a) objArr[i13]).i();
                i13++;
            } while (i13 < i12);
        }
        this.f15851v = false;
        while (lVar != null) {
            if (lVar.f14425w) {
                lVar.x0();
            }
            lVar = lVar.f14417e;
        }
        O o4 = c1691p.M;
        o4.getClass();
        f0 f0Var = o4.f29053b;
        f0Var.getClass();
        ((f0) f0Var.f27707b).s(this);
        ((f0) f0Var.f27708c).s(this);
        c1691p.f29860D = true;
        this.f15848s = null;
        V(null);
        this.f15850u = 0;
        J j11 = k.f29039n;
        j11.f29018r = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        j11.f29017q = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        j11.f29009B = false;
        H h12 = k.f29040o;
        if (h12 != null) {
            h12.f28995r = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
            h12.f28994q = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
            h12.f29001x = false;
        }
    }

    public final void j(InterfaceC1062o interfaceC1062o) {
        p097ha.k.f(interfaceC1062o, "canvas");
        ((V) this.f15829G.f3903d).D0(interfaceC1062o);
    }

    public final void k() {
        if (this.f15842c != null) {
            N(this, false, 1);
        } else {
            P(this, false, 1);
        }
        J j10 = this.f15830H.f29039n;
        N0.a aVar = j10.f29019s ? new N0.a(j10.f27579d) : null;
        if (aVar != null) {
            C1691p c1691p = this.f15848s;
            if (c1691p != null) {
                c1691p.r(this, aVar.f8965a);
                return;
            }
            return;
        }
        C1691p c1691p2 = this.f15848s;
        if (c1691p2 != null) {
            c1691p2.q(true);
        }
    }

    public final List l() {
        H h10 = this.f15830H.f29040o;
        p097ha.k.c(h10);
        K k = h10.f28992E;
        k.f29027a.n();
        boolean z3 = h10.f28988A;
        h hVar = h10.f29003z;
        if (!z3) {
            return hVar.e();
        }
        a aVar = k.f29027a;
        h hVarU = aVar.u();
        int i10 = hVarU.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i11 = 0;
            do {
                a aVar2 = (a) objArr[i11];
                if (hVar.f10080c <= i11) {
                    H h11 = aVar2.f15830H.f29040o;
                    p097ha.k.c(h11);
                    hVar.b(h11);
                } else {
                    H h12 = aVar2.f15830H.f29040o;
                    p097ha.k.c(h12);
                    Object[] objArr2 = hVar.f10078a;
                    Object obj = objArr2[i11];
                    objArr2[i11] = h12;
                }
                i11++;
            } while (i11 < i10);
        }
        hVar.n(((e) aVar.n()).f10072a.f10080c, hVar.f10080c);
        h10.f28988A = false;
        return hVar.e();
    }

    public final List m() {
        J j10 = this.f15830H.f29039n;
        K k = j10.f29015H;
        k.f29027a.Z();
        boolean z3 = j10.f29012E;
        h hVar = j10.f29011D;
        if (!z3) {
            return hVar.e();
        }
        a aVar = k.f29027a;
        h hVarU = aVar.u();
        int i10 = hVarU.f10080c;
        if (i10 > 0) {
            Object[] objArr = hVarU.f10078a;
            int i11 = 0;
            do {
                a aVar2 = (a) objArr[i11];
                if (hVar.f10080c <= i11) {
                    hVar.b(aVar2.f15830H.f29039n);
                } else {
                    J j11 = aVar2.f15830H.f29039n;
                    Object[] objArr2 = hVar.f10078a;
                    Object obj = objArr2[i11];
                    objArr2[i11] = j11;
                }
                i11++;
            } while (i11 < i10);
        }
        hVar.n(((e) aVar.n()).f10072a.f10080c, hVar.f10080c);
        j10.f29012E = false;
        return hVar.e();
    }

    public final List n() {
        return u().e();
    }

    public final p284z0.j o() {
        if (!this.f15829G.d(8) || this.f15852w != null) {
            return this.f15852w;
        }
        u uVar = new u();
        uVar.f23278a = new p284z0.j();
        d0 snapshotObserver = ((C1691p) AbstractC1590g.x(this)).getSnapshotObserver();
        Z1.g gVar = new Z1.g(10, this, uVar);
        snapshotObserver.getClass();
        snapshotObserver.a(this, snapshotObserver.f29116d, gVar);
        p284z0.j jVar = (p284z0.j) uVar.f23278a;
        this.f15852w = jVar;
        return jVar;
    }

    public final List p() {
        return ((h) this.f15844e.f27707b).e();
    }

    public final int q() {
        int i10;
        H h10 = this.f15830H.f29040o;
        if (h10 == null || (i10 = h10.f28996s) == 0) {
            return 3;
        }
        return i10;
    }

    public final a r() {
        a aVar = this.f15847r;
        while (aVar != null && aVar.f15840a) {
            aVar = aVar.f15847r;
        }
        return aVar;
    }

    public final int s() {
        return this.f15830H.f29039n.f29018r;
    }

    public final h t() {
        boolean z3 = this.f15854y;
        h hVar = this.f15853x;
        if (z3) {
            hVar.g();
            hVar.c(hVar.f10080c, u());
            i iVar = f15822V;
            p097ha.k.f(iVar, "comparator");
            Arrays.sort(hVar.f10078a, 0, hVar.f10080c, iVar);
            this.f15854y = false;
        }
        return hVar;
    }

    public final String toString() {
        return AbstractC1662a0.y(this) + " children: " + ((e) n()).f10072a.f10080c + " measurePolicy: " + this.f15855z;
    }

    public final h u() {
        Z();
        if (this.f15843d == 0) {
            return (h) this.f15844e.f27707b;
        }
        h hVar = this.f15845f;
        p097ha.k.c(hVar);
        return hVar;
    }

    public final void v(long j10, C1601s c1601s, boolean z3, boolean z5) {
        p097ha.k.f(c1601s, "hitTestResult");
        C0241c c0241c = this.f15829G;
        ((V) c0241c.f3903d).O0(V.f29084L, ((V) c0241c.f3903d).I0(j10), c1601s, z3, z5);
    }

    public final void w(int i10, a aVar) {
        p097ha.k.f(aVar, "instance");
        if (aVar.f15847r != null) {
            StringBuilder sb2 = new StringBuilder("Cannot insert ");
            sb2.append(aVar);
            sb2.append(" because it already has a parent. This tree: ");
            sb2.append(h(0));
            sb2.append(" Other tree: ");
            a aVar2 = aVar.f15847r;
            sb2.append(aVar2 != null ? aVar2.h(0) : null);
            throw new IllegalStateException(sb2.toString().toString());
        }
        if (aVar.f15848s != null) {
            throw new IllegalStateException(("Cannot insert " + aVar + " because it already has an owner. This tree: " + h(0) + " Other tree: " + aVar.h(0)).toString());
        }
        aVar.f15847r = this;
        f0 f0Var = this.f15844e;
        ((h) f0Var.f27707b).a(i10, aVar);
        ((g0) f0Var.f27708c).m();
        I();
        if (aVar.f15840a) {
            this.f15843d++;
        }
        A();
        C1691p c1691p = this.f15848s;
        if (c1691p != null) {
            aVar.b(c1691p);
        }
        if (aVar.f15830H.f29038m > 0) {
            K k = this.f15830H;
            k.c(k.f29038m + 1);
        }
    }

    public final void x() {
        if (this.f15833K) {
            C0241c c0241c = this.f15829G;
            V v10 = (C1603u) c0241c.f3902c;
            V v11 = ((V) c0241c.f3903d).f29096t;
            this.f15832J = null;
            while (!p097ha.k.b(v10, v11)) {
                if ((v10 != null ? v10.f29093I : null) != null) {
                    this.f15832J = v10;
                    break;
                }
                v10 = v10 != null ? v10.f29096t : null;
            }
        }
        V v12 = this.f15832J;
        if (v12 != null && v12.f29093I == null) {
            throw new IllegalArgumentException("Required value was null.");
        }
        if (v12 != null) {
            v12.Q0();
            return;
        }
        a aVarR = r();
        if (aVarR != null) {
            aVarR.x();
        }
    }

    public final void y() {
        C0241c c0241c = this.f15829G;
        V v10 = (V) c0241c.f3903d;
        C1603u c1603u = (C1603u) c0241c.f3902c;
        while (v10 != c1603u) {
            p097ha.k.d(v10, "null cannot be cast to non-null type androidx.compose.ui.node.LayoutModifierNodeCoordinator");
            C1608z c1608z = (C1608z) v10;
            Z z3 = c1608z.f29093I;
            if (z3 != null) {
                z3.invalidate();
            }
            v10 = c1608z.f29095s;
        }
        Z z5 = ((C1603u) c0241c.f3902c).f29093I;
        if (z5 != null) {
            z5.invalidate();
        }
    }

    public final void z() {
        if (this.f15842c != null) {
            N(this, false, 3);
        } else {
            P(this, false, 3);
        }
    }

    public a(int i10, boolean z3) {
        this.f15840a = z3;
        this.f15841b = i10;
        h hVar = new h();
        hVar.f10078a = new a[16];
        hVar.f10080c = 0;
        this.f15844e = new f0(10, hVar, new g0(this, 22));
        h hVar2 = new h();
        hVar2.f10078a = new a[16];
        hVar2.f10080c = 0;
        this.f15853x = hVar2;
        this.f15854y = true;
        this.f15855z = f15819S;
        this.f15823A = new f0(this);
        this.f15824B = AbstractC1590g.f29135b;
        this.f15825C = j.f8984a;
        this.f15826D = f15821U;
        C.f9447g.getClass();
        this.f15827E = O.B.f9443b;
        this.f15838Q = 3;
        this.f15839R = 3;
        this.f15829G = new C0241c(this);
        this.f15830H = new K(this);
        this.f15833K = true;
        this.f15834L = Z.j.f14412b;
    }
}
