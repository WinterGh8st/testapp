package androidx.compose.ui.draw;

import Z.d;
import Z.m;
import p050e0.r;
import p084ga.c;
import p087h0.b;
import p097ha.k;
import p199r0.F;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(m mVar, c cVar) {
        k.f(mVar, "<this>");
        k.f(cVar, "onDraw");
        return mVar.k(new DrawBehindElement(cVar));
    }

    public static final m b(c cVar) {
        k.f(cVar, "onBuildDrawCache");
        return new DrawWithCacheElement(cVar);
    }

    public static final m c(m mVar, c cVar) {
        k.f(mVar, "<this>");
        return mVar.k(new DrawWithContentElement(cVar));
    }

    public static m d(m mVar, b bVar, d dVar, F f10, float f11, r rVar, int i10) {
        if ((i10 & 4) != 0) {
            dVar = Z.a.f14392e;
        }
        d dVar2 = dVar;
        if ((i10 & 16) != 0) {
            f11 = 1.0f;
        }
        k.f(mVar, "<this>");
        k.f(bVar, "painter");
        k.f(dVar2, "alignment");
        k.f(f10, "contentScale");
        return mVar.k(new PainterElement(bVar, dVar2, f10, f11, rVar));
    }
}
