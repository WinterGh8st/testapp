package androidx.compose.ui;

import Z.l;
import Z.o;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
public final class ZIndexElement extends P {
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ZIndexElement)) {
            return false;
        }
        ((ZIndexElement) obj).getClass();
        return Float.compare(1.0f, 1.0f) == 0;
    }

    @Override // p220t0.P
    public final int hashCode() {
        return Float.hashCode(1.0f);
    }

    @Override // p220t0.P
    public final l l() {
        o oVar = new o();
        oVar.f14426x = 1.0f;
        return oVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        o oVar = (o) lVar;
        k.f(oVar, "node");
        oVar.f14426x = 1.0f;
    }

    public final String toString() {
        return "ZIndexElement(zIndex=1.0)";
    }
}
