package androidx.compose.ui.focus;

import Z.m;
import p025c0.l;
import p084ga.c;
import p097ha.k;
import p248v9.C1774u;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final m a(m mVar, c cVar) {
        k.f(mVar, "<this>");
        return mVar.k(new FocusPropertiesElement(cVar));
    }

    public static final m b(m mVar, l lVar) {
        k.f(mVar, "<this>");
        k.f(lVar, "focusRequester");
        return mVar.k(new FocusRequesterElement(lVar));
    }

    public static final m c(m mVar, c cVar) {
        k.f(mVar, "<this>");
        k.f(cVar, "onFocusChanged");
        return mVar.k(new FocusChangedElement(cVar));
    }

    public static final m d(m mVar, C1774u c1774u) {
        k.f(mVar, "<this>");
        return mVar.k(new FocusEventElement(c1774u));
    }
}
