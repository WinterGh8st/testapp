package androidx.compose.ui.platform;

import C.p;
import K6.d;
import N1.B;
import O.AbstractC0632x;
import O.C0607i0;
import O.C0629u;
import O.EnumC0621p0;
import O.W;
import O.X;
import O.u0;
import Ua.l;
import X9.i;
import X9.j;
import Z.n;
import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.lifecycle.D;
import androidx.lifecycle.F;
import androidx.lifecycle.j0;
import com.flamingotools.ws.R;
import java.lang.ref.WeakReference;
import p084ga.a;
import p097ha.k;
import p097ha.u;
import p162n9.C1279q;
import p220t0.b0;
import p230ta.C1626a0;
import p230ta.E;
import p232u0.A0;
import p232u0.C1682k0;
import p232u0.C1691p;
import p232u0.J0;
import p232u0.K0;
import p232u0.L;
import p232u0.L0;
import p232u0.M0;
import p232u0.Q0;
import p232u0.S0;
import p232u0.V0;
import p232u0.Y0;
import p232u0.z0;
import p239ua.f;
import p282ya.e;

/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractComposeView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public WeakReference f15857a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public IBinder f15858b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public V0 f15859c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public AbstractC0632x f15860d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public a f15861e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f15862f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f15863q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f15864r;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public AbstractComposeView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 4, 0);
        k.f(context, "context");
    }

    private static /* synthetic */ void getDisposeViewCompositionStrategy$annotations() {
    }

    public static /* synthetic */ void getShowLayoutBounds$annotations() {
    }

    private final void setParentContext(AbstractC0632x abstractC0632x) {
        if (this.f15860d != abstractC0632x) {
            this.f15860d = abstractC0632x;
            if (abstractC0632x != null) {
                this.f15857a = null;
            }
            V0 v0 = this.f15859c;
            if (v0 != null) {
                v0.a();
                this.f15859c = null;
                if (isAttachedToWindow()) {
                    d();
                }
            }
        }
    }

    private final void setPreviousAttachedWindowToken(IBinder iBinder) {
        if (this.f15858b != iBinder) {
            this.f15858b = iBinder;
            this.f15857a = null;
        }
    }

    public abstract void a(int i10, C0629u c0629u);

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        b();
        super.addView(view);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        b();
        return super.addViewInLayout(view, i10, layoutParams);
    }

    public final void b() {
        if (this.f15863q) {
            return;
        }
        throw new UnsupportedOperationException("Cannot add views to " + getClass().getSimpleName() + "; only Compose content is supported");
    }

    public final void c() {
        V0 v0 = this.f15859c;
        if (v0 != null) {
            v0.a();
        }
        this.f15859c = null;
        requestLayout();
    }

    public final void d() {
        if (this.f15859c == null) {
            try {
                this.f15863q = true;
                this.f15859c = Y0.a(this, g(), l.v(-656146368, new C1279q(this, 6), true));
            } finally {
                this.f15863q = false;
            }
        }
    }

    public void e(boolean z3, int i10, int i11, int i12, int i13) {
        View childAt = getChildAt(0);
        if (childAt != null) {
            childAt.layout(getPaddingLeft(), getPaddingTop(), (i12 - i10) - getPaddingRight(), (i13 - i11) - getPaddingBottom());
        }
    }

    public void f(int i10, int i11) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            super.onMeasure(i10, i11);
            return;
        }
        childAt.measure(View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i10) - getPaddingLeft()) - getPaddingRight()), View.MeasureSpec.getMode(i10)), View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i11) - getPaddingTop()) - getPaddingBottom()), View.MeasureSpec.getMode(i11)));
        setMeasuredDimension(getPaddingRight() + getPaddingLeft() + childAt.getMeasuredWidth(), getPaddingBottom() + getPaddingTop() + childAt.getMeasuredHeight());
    }

    public final AbstractC0632x g() {
        u0 u0Var;
        i iVar;
        C0607i0 c0607i0;
        int i10 = 2;
        AbstractC0632x abstractC0632xB = this.f15860d;
        if (abstractC0632xB == null) {
            abstractC0632xB = S0.b(this);
            if (abstractC0632xB == null) {
                for (ViewParent parent = getParent(); abstractC0632xB == null && (parent instanceof View); parent = parent.getParent()) {
                    abstractC0632xB = S0.b((View) parent);
                }
            }
            if (abstractC0632xB != null) {
                AbstractC0632x abstractC0632x = (!(abstractC0632xB instanceof u0) || ((EnumC0621p0) ((u0) abstractC0632xB).f9719q.getValue()).compareTo(EnumC0621p0.f9619b) > 0) ? abstractC0632xB : null;
                if (abstractC0632x != null) {
                    this.f15857a = new WeakReference(abstractC0632x);
                }
            } else {
                abstractC0632xB = null;
            }
            if (abstractC0632xB == null) {
                WeakReference weakReference = this.f15857a;
                if (weakReference == null || (abstractC0632xB = (AbstractC0632x) weakReference.get()) == null || ((abstractC0632xB instanceof u0) && ((EnumC0621p0) ((u0) abstractC0632xB).f9719q.getValue()).compareTo(EnumC0621p0.f9619b) <= 0)) {
                    abstractC0632xB = null;
                }
                if (abstractC0632xB == null) {
                    if (!isAttachedToWindow()) {
                        throw new IllegalStateException(("Cannot locate windowRecomposer; View " + this + " is not attached to a window").toString());
                    }
                    Object parent2 = getParent();
                    View view = this;
                    while (parent2 instanceof View) {
                        View view2 = (View) parent2;
                        if (view2.getId() == 16908290) {
                            break;
                        }
                        view = view2;
                        parent2 = view2.getParent();
                    }
                    AbstractC0632x abstractC0632xB2 = S0.b(view);
                    if (abstractC0632xB2 == null) {
                        ((J0) ((K0) M0.f29708a.get())).getClass();
                        i iVar2 = j.f13659a;
                        T9.l lVar = L.f29692w;
                        if (Looper.myLooper() == Looper.getMainLooper()) {
                            iVar = (i) L.f29692w.getValue();
                        } else {
                            iVar = (i) L.f29693x.get();
                            if (iVar == null) {
                                throw new IllegalStateException("no AndroidUiDispatcher for this thread");
                            }
                        }
                        i iVarM = iVar.m(iVar2);
                        X x10 = (X) iVarM.i(W.f9542b);
                        if (x10 != null) {
                            c0607i0 = new C0607i0(x10);
                            d dVar = (d) c0607i0.f9579c;
                            synchronized (dVar.f6932c) {
                                dVar.f6931b = false;
                            }
                        } else {
                            c0607i0 = null;
                        }
                        u uVar = new u();
                        i c1682k0 = (n) iVarM.i(Z.a.f14401x);
                        if (c1682k0 == null) {
                            c1682k0 = new C1682k0();
                            uVar.f23278a = c1682k0;
                        }
                        if (c0607i0 != null) {
                            iVar2 = c0607i0;
                        }
                        i iVarM2 = iVarM.m(iVar2).m(c1682k0);
                        u0Var = new u0(iVarM2);
                        synchronized (u0Var.f9705b) {
                            u0Var.f9718p = true;
                        }
                        e eVarA = E.a(iVarM2);
                        D dF = j0.f(view);
                        F fJ = dF != null ? dF.j() : null;
                        if (fJ == null) {
                            throw new IllegalStateException(("ViewTreeLifecycleOwner not found from " + view).toString());
                        }
                        view.addOnAttachStateChangeListener(new B(view, u0Var, i10));
                        fJ.a(new Q0(eVarA, c0607i0, u0Var, uVar, view));
                        view.setTag(R.id.androidx_compose_ui_view_composition_context, u0Var);
                        C1626a0 c1626a0 = C1626a0.f29507a;
                        Handler handler = view.getHandler();
                        k.e(handler, "rootView.handler");
                        int i11 = f.f30222a;
                        view.addOnAttachStateChangeListener(new N1.X(E.t(c1626a0, new p239ua.e(handler, "windowRecomposer cleanup", false).f30221f, new L0(u0Var, view, null), 2), 8));
                    } else {
                        if (!(abstractC0632xB2 instanceof u0)) {
                            throw new IllegalStateException("root viewTreeParentCompositionContext is not a Recomposer");
                        }
                        u0Var = (u0) abstractC0632xB2;
                    }
                    u0 u0Var2 = ((EnumC0621p0) u0Var.f9719q.getValue()).compareTo(EnumC0621p0.f9619b) > 0 ? u0Var : null;
                    if (u0Var2 != null) {
                        this.f15857a = new WeakReference(u0Var2);
                    }
                    return u0Var;
                }
            }
        }
        return abstractC0632xB;
    }

    public final boolean getHasComposition() {
        return this.f15859c != null;
    }

    public boolean getShouldCreateCompositionOnAttachedToWindow() {
        return true;
    }

    public final boolean getShowLayoutBounds() {
        return this.f15862f;
    }

    @Override // android.view.ViewGroup
    public final boolean isTransitionGroup() {
        return !this.f15864r || super.isTransitionGroup();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        setPreviousAttachedWindowToken(getWindowToken());
        if (getShouldCreateCompositionOnAttachedToWindow()) {
            d();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        e(z3, i10, i11, i12, i13);
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        d();
        f(i10, i11);
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        View childAt = getChildAt(0);
        if (childAt == null) {
            return;
        }
        childAt.setLayoutDirection(i10);
    }

    public final void setParentCompositionContext(AbstractC0632x abstractC0632x) {
        setParentContext(abstractC0632x);
    }

    public final void setShowLayoutBounds(boolean z3) {
        this.f15862f = z3;
        KeyEvent.Callback childAt = getChildAt(0);
        if (childAt != null) {
            ((C1691p) ((b0) childAt)).setShowLayoutBounds(z3);
        }
    }

    @Override // android.view.ViewGroup
    public void setTransitionGroup(boolean z3) {
        super.setTransitionGroup(z3);
        this.f15864r = true;
    }

    public final void setViewCompositionStrategy(A0 a3) {
        k.f(a3, "strategy");
        a aVar = this.f15861e;
        if (aVar != null) {
            aVar.m();
        }
        this.f15861e = a3.a(this);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public /* synthetic */ AbstractComposeView(Context context, AttributeSet attributeSet, int i10, int i11) {
        this(context, (i10 & 2) != 0 ? null : attributeSet, 0);
    }

    public AbstractComposeView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, 0);
        setClipChildren(false);
        setClipToPadding(false);
        N1.X x10 = new N1.X(this, 7);
        addOnAttachStateChangeListener(x10);
        z0 z0Var = new z0(this);
        p054e4.e.b0(this).f1630a.add(z0Var);
        this.f15861e = new p(this, x10, z0Var, 8);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10) {
        b();
        super.addView(view, i10);
    }

    @Override // android.view.ViewGroup
    public final boolean addViewInLayout(View view, int i10, ViewGroup.LayoutParams layoutParams, boolean z3) {
        b();
        return super.addViewInLayout(view, i10, layoutParams, z3);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, int i11) {
        b();
        super.addView(view, i10, i11);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, layoutParams);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        b();
        super.addView(view, i10, layoutParams);
    }
}
