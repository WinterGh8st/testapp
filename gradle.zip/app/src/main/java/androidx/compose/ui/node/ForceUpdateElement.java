package androidx.compose.ui.node;

import Z.l;
import p097ha.k;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class ForceUpdateElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P f15818b;

    public ForceUpdateElement(P p10) {
        k.f(p10, "original");
        this.f15818b = p10;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof ForceUpdateElement) && k.b(this.f15818b, ((ForceUpdateElement) obj).f15818b);
    }

    @Override // p220t0.P
    public final int hashCode() {
        return this.f15818b.hashCode();
    }

    @Override // p220t0.P
    public final l l() {
        throw new IllegalStateException("Shouldn't be called");
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        k.f(lVar, "node");
        throw new IllegalStateException("Shouldn't be called");
    }

    public final String toString() {
        return "ForceUpdateElement(original=" + this.f15818b + ')';
    }
}
