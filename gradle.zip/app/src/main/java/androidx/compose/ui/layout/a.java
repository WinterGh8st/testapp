package androidx.compose.ui.layout;

import Z.m;
import p084ga.c;
import p084ga.f;
import p097ha.k;
import p199r0.A;
import p199r0.C1462p;

/* JADX INFO: loaded from: classes.dex */
public abstract class a {
    public static final Object a(A a3) {
        k.f(a3, "<this>");
        Object objI = a3.i();
        C1462p c1462p = objI instanceof C1462p ? (C1462p) objI : null;
        if (c1462p != null) {
            return c1462p.f27626x;
        }
        return null;
    }

    public static final m b(m mVar, f fVar) {
        k.f(mVar, "<this>");
        return mVar.k(new LayoutElement(fVar));
    }

    public static final m c(m mVar, String str) {
        k.f(mVar, "<this>");
        return mVar.k(new LayoutIdElement(str));
    }

    public static final m d(m mVar, c cVar) {
        k.f(mVar, "<this>");
        k.f(cVar, "onGloballyPositioned");
        return mVar.k(new OnGloballyPositionedElement(cVar));
    }
}
