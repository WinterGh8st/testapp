package androidx.compose.ui.draw;

import Z.d;
import Z.l;
import p013b0.h;
import p038d0.f;
import p050e0.r;
import p087h0.b;
import p097ha.k;
import p199r0.AbstractC1464s;
import p199r0.F;
import p220t0.AbstractC1590g;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class PainterElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final b f15789b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final d f15790c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final F f15791d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final float f15792e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final r f15793f;

    public PainterElement(b bVar, d dVar, F f10, float f11, r rVar) {
        k.f(bVar, "painter");
        this.f15789b = bVar;
        this.f15790c = dVar;
        this.f15791d = f10;
        this.f15792e = f11;
        this.f15793f = rVar;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PainterElement)) {
            return false;
        }
        PainterElement painterElement = (PainterElement) obj;
        return k.b(this.f15789b, painterElement.f15789b) && this.f15790c.equals(painterElement.f15790c) && this.f15791d.equals(painterElement.f15791d) && Float.compare(this.f15792e, painterElement.f15792e) == 0 && k.b(this.f15793f, painterElement.f15793f);
    }

    @Override // p220t0.P
    public final int hashCode() {
        int iB = AbstractC1464s.b((this.f15791d.hashCode() + ((this.f15790c.hashCode() + (((this.f15789b.hashCode() * 31) + 1) * 31)) * 31)) * 31, this.f15792e, 31);
        r rVar = this.f15793f;
        return iB + (rVar == null ? 0 : rVar.hashCode());
    }

    @Override // p220t0.P
    public final l l() {
        b bVar = this.f15789b;
        k.f(bVar, "painter");
        d dVar = this.f15790c;
        F f10 = this.f15791d;
        h hVar = new h();
        hVar.f17244x = bVar;
        hVar.f17245y = true;
        hVar.f17246z = dVar;
        hVar.f17241A = f10;
        hVar.f17242B = this.f15792e;
        hVar.f17243C = this.f15793f;
        return hVar;
    }

    @Override // p220t0.P
    public final void m(l lVar) {
        h hVar = (h) lVar;
        k.f(hVar, "node");
        boolean z3 = hVar.f17245y;
        b bVar = this.f15789b;
        boolean z5 = (z3 && f.a(hVar.f17244x.c(), bVar.c())) ? false : true;
        k.f(bVar, "<set-?>");
        hVar.f17244x = bVar;
        hVar.f17245y = true;
        hVar.f17246z = this.f15790c;
        hVar.f17241A = this.f15791d;
        hVar.f17242B = this.f15792e;
        hVar.f17243C = this.f15793f;
        if (z5) {
            AbstractC1590g.t(hVar);
        }
        AbstractC1590g.s(hVar);
    }

    public final String toString() {
        return "PainterElement(painter=" + this.f15789b + ", sizeToIntrinsics=true, alignment=" + this.f15790c + ", contentScale=" + this.f15791d + ", alpha=" + this.f15792e + ", colorFilter=" + this.f15793f + ')';
    }
}
