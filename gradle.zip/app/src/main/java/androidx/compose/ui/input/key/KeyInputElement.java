package androidx.compose.ui.input.key;

import p084ga.c;
import p097ha.k;
import p097ha.l;
import p143m0.e;
import p220t0.P;

/* JADX INFO: loaded from: classes.dex */
final class KeyInputElement extends P {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f15809b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final l f15810c;

    /* JADX WARN: Multi-variable type inference failed */
    public KeyInputElement(c cVar, c cVar2) {
        this.f15809b = cVar;
        this.f15810c = (l) cVar2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof KeyInputElement)) {
            return false;
        }
        KeyInputElement keyInputElement = (KeyInputElement) obj;
        return k.b(this.f15809b, keyInputElement.f15809b) && k.b(this.f15810c, keyInputElement.f15810c);
    }

    @Override // p220t0.P
    public final int hashCode() {
        Object obj = this.f15809b;
        int iHashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        l lVar = this.f15810c;
        return iHashCode + (lVar != null ? lVar.hashCode() : 0);
    }

    @Override // p220t0.P
    public final Z.l l() {
        e eVar = new e();
        eVar.f24823x = this.f15809b;
        eVar.f24824y = this.f15810c;
        return eVar;
    }

    @Override // p220t0.P
    public final void m(Z.l lVar) {
        e eVar = (e) lVar;
        k.f(eVar, "node");
        eVar.f24823x = this.f15809b;
        eVar.f24824y = this.f15810c;
    }

    public final String toString() {
        return "KeyInputElement(onKeyEvent=" + this.f15809b + ", onPreKeyEvent=" + this.f15810c + ')';
    }
}
