package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import p200r1.f0;
import p214s4.D;
import p231u.a;

/* JADX INFO: loaded from: classes.dex */
public class CardView extends FrameLayout {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final int[] f15688f = {R.attr.colorBackground};

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public static final D f15689q = new D(10);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f15690a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f15691b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f15692c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Rect f15693d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final f0 f15694e;

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.flamingotools.ws.R.attr.cardViewStyle);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((a) ((Drawable) this.f15694e.f27707b)).f29586h;
    }

    public float getCardElevation() {
        return ((CardView) this.f15694e.f27708c).getElevation();
    }

    public int getContentPaddingBottom() {
        return this.f15692c.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f15692c.left;
    }

    public int getContentPaddingRight() {
        return this.f15692c.right;
    }

    public int getContentPaddingTop() {
        return this.f15692c.top;
    }

    public float getMaxCardElevation() {
        return ((a) ((Drawable) this.f15694e.f27707b)).f29583e;
    }

    public boolean getPreventCornerOverlap() {
        return this.f15691b;
    }

    public float getRadius() {
        return ((a) ((Drawable) this.f15694e.f27707b)).f29579a;
    }

    public boolean getUseCompatPadding() {
        return this.f15690a;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
    }

    public void setCardBackgroundColor(int i10) {
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(i10);
        a aVar = (a) ((Drawable) this.f15694e.f27707b);
        if (colorStateListValueOf == null) {
            aVar.getClass();
            colorStateListValueOf = ColorStateList.valueOf(0);
        }
        aVar.f29586h = colorStateListValueOf;
        aVar.f29580b.setColor(colorStateListValueOf.getColorForState(aVar.getState(), aVar.f29586h.getDefaultColor()));
        aVar.invalidateSelf();
    }

    public void setCardElevation(float f10) {
        ((CardView) this.f15694e.f27708c).setElevation(f10);
    }

    public void setMaxCardElevation(float f10) {
        f15689q.a(this.f15694e, f10);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i10) {
        super.setMinimumHeight(i10);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i10) {
        super.setMinimumWidth(i10);
    }

    @Override // android.view.View
    public final void setPadding(int i10, int i11, int i12, int i13) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i10, int i11, int i12, int i13) {
    }

    public void setPreventCornerOverlap(boolean z3) {
        if (z3 != this.f15691b) {
            this.f15691b = z3;
            D d10 = f15689q;
            f0 f0Var = this.f15694e;
            d10.a(f0Var, ((a) ((Drawable) f0Var.f27707b)).f29583e);
        }
    }

    public void setRadius(float f10) {
        a aVar = (a) ((Drawable) this.f15694e.f27707b);
        if (f10 == aVar.f29579a) {
            return;
        }
        aVar.f29579a = f10;
        aVar.b(null);
        aVar.invalidateSelf();
    }

    public void setUseCompatPadding(boolean z3) {
        if (this.f15690a != z3) {
            this.f15690a = z3;
            D d10 = f15689q;
            f0 f0Var = this.f15694e;
            d10.a(f0Var, ((a) ((Drawable) f0Var.f27707b)).f29583e);
        }
    }

    public CardView(Context context, AttributeSet attributeSet, int i10) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, i10);
        Rect rect = new Rect();
        this.f15692c = rect;
        this.f15693d = new Rect();
        f0 f0Var = new f0(this, 11);
        this.f15694e = f0Var;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p219t.a.f28970a, i10, com.flamingotools.ws.R.style.CardView);
        if (typedArrayObtainStyledAttributes.hasValue(2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(f15688f);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(com.flamingotools.ws.R.color.cardview_light_background) : getResources().getColor(com.flamingotools.ws.R.color.cardview_dark_background));
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(5, 0.0f);
        this.f15690a = typedArrayObtainStyledAttributes.getBoolean(7, false);
        this.f15691b = typedArrayObtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        D d10 = f15689q;
        a aVar = new a(colorStateListValueOf, dimension);
        f0Var.f27707b = aVar;
        setBackgroundDrawable(aVar);
        setClipToOutline(true);
        setElevation(dimension2);
        d10.a(f0Var, dimension3);
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        a aVar = (a) ((Drawable) this.f15694e.f27707b);
        if (colorStateList == null) {
            aVar.getClass();
            colorStateList = ColorStateList.valueOf(0);
        }
        aVar.f29586h = colorStateList;
        aVar.f29580b.setColor(colorStateList.getColorForState(aVar.getState(), aVar.f29586h.getDefaultColor()));
        aVar.invalidateSelf();
    }
}
