package androidx.swiperefreshlayout.widget;

import L.C0499e0;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.ListView;
import java.util.WeakHashMap;
import l2.a;
import l2.c;
import l2.d;
import l2.e;
import l2.f;
import l2.g;
import l2.i;
import l2.j;
import p128k5.h;
import p200r1.C1488o;
import p200r1.H;
import p200r1.InterfaceC1487n;
import p200r1.InterfaceC1489p;
import p200r1.InterfaceC1490q;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class SwipeRefreshLayout extends ViewGroup implements InterfaceC1490q, InterfaceC1489p, InterfaceC1487n {

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public static final int[] f17023U = {R.attr.enabled};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f17024A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f17025B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final DecelerateInterpolator f17026C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final a f17027D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f17028E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f17029F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final int f17030G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final int f17031H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f17032I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final d f17033J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public f f17034K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public f f17035L;
    public g M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public g f17036N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public boolean f17037O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public int f17038P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public boolean f17039Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public final e f17040R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final f f17041S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final f f17042T;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public View f17043a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public i f17044b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f17045c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f17046d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f17047e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f17048f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final C0499e0 f17049q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final C1488o f17050r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int[] f17051s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int[] f17052t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int[] f17053u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f17054v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f17055w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f17056x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public float f17057y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f17058z;

    public SwipeRefreshLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f17045c = false;
        this.f17047e = -1.0f;
        this.f17051s = new int[2];
        this.f17052t = new int[2];
        this.f17053u = new int[2];
        this.f17025B = -1;
        this.f17028E = -1;
        this.f17040R = new e(this, 0);
        this.f17041S = new f(this, 2);
        this.f17042T = new f(this, 3);
        this.f17046d = ViewConfiguration.get(context).getScaledTouchSlop();
        this.f17055w = getResources().getInteger(R.integer.config_mediumAnimTime);
        setWillNotDraw(false);
        this.f17026C = new DecelerateInterpolator(2.0f);
        DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
        this.f17038P = (int) (displayMetrics.density * 40.0f);
        a aVar = new a(getContext());
        float f10 = aVar.getContext().getResources().getDisplayMetrics().density;
        TypedArray typedArrayObtainStyledAttributes = aVar.getContext().obtainStyledAttributes(p127k2.a.f24340a);
        aVar.f24658b = typedArrayObtainStyledAttributes.getColor(0, -328966);
        typedArrayObtainStyledAttributes.recycle();
        ShapeDrawable shapeDrawable = new ShapeDrawable(new OvalShape());
        WeakHashMap weakHashMap = U.f27683a;
        H.s(aVar, f10 * 4.0f);
        shapeDrawable.getPaint().setColor(aVar.f24658b);
        aVar.setBackground(shapeDrawable);
        this.f17027D = aVar;
        d dVar = new d(getContext());
        this.f17033J = dVar;
        dVar.c(1);
        this.f17027D.setImageDrawable(this.f17033J);
        this.f17027D.setVisibility(8);
        addView(this.f17027D);
        setChildrenDrawingOrderEnabled(true);
        int i10 = (int) (displayMetrics.density * 64.0f);
        this.f17031H = i10;
        this.f17047e = i10;
        this.f17049q = new C0499e0();
        this.f17050r = new C1488o(this);
        setNestedScrollingEnabled(true);
        int i11 = -this.f17038P;
        this.f17056x = i11;
        this.f17030G = i11;
        k(1.0f);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, f17023U);
        setEnabled(typedArrayObtainStyledAttributes2.getBoolean(0, true));
        typedArrayObtainStyledAttributes2.recycle();
    }

    private void setColorViewAlpha(int i10) {
        this.f17027D.getBackground().setAlpha(i10);
        this.f17033J.setAlpha(i10);
    }

    @Override // p200r1.InterfaceC1489p
    public final void a(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            onNestedScrollAccepted(view, view2, i10);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void b(View view, int i10) {
        if (i10 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        if (i12 == 0) {
            onNestedPreScroll(view, i10, i11, iArr);
        }
    }

    public final boolean d() {
        View view = this.f17043a;
        return view instanceof ListView ? ((ListView) view).canScrollList(-1) : view.canScrollVertically(-1);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (keyEvent == null || keyEvent.getAction() != 1 || keyEvent.getKeyCode() != 285) {
            return super.dispatchKeyEvent(keyEvent);
        }
        n(true, true);
        return true;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f10, float f11, boolean z3) {
        return this.f17050r.a(f10, f11, z3);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f10, float f11) {
        return this.f17050r.b(f10, f11);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i10, int i11, int[] iArr, int[] iArr2) {
        return this.f17050r.c(i10, i11, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i10, int i11, int i12, int i13, int[] iArr) {
        return this.f17050r.d(i10, i11, i12, i13, iArr, 0, null);
    }

    public final void e() {
        if (this.f17043a == null) {
            for (int i10 = 0; i10 < getChildCount(); i10++) {
                View childAt = getChildAt(i10);
                if (!childAt.equals(this.f17027D)) {
                    this.f17043a = childAt;
                    return;
                }
            }
        }
    }

    public final void f(float f10) {
        if (f10 > this.f17047e) {
            m(true, true);
            return;
        }
        this.f17045c = false;
        d dVar = this.f17033J;
        c cVar = dVar.f24684a;
        cVar.f24665e = 0.0f;
        cVar.f24666f = 0.0f;
        dVar.invalidateSelf();
        e eVar = new e(this, 1);
        this.f17029F = this.f17056x;
        f fVar = this.f17042T;
        fVar.reset();
        fVar.setDuration(200L);
        fVar.setInterpolator(this.f17026C);
        a aVar = this.f17027D;
        aVar.f24657a = eVar;
        aVar.clearAnimation();
        this.f17027D.startAnimation(fVar);
        d dVar2 = this.f17033J;
        c cVar2 = dVar2.f24684a;
        if (cVar2.f24673n) {
            cVar2.f24673n = false;
        }
        dVar2.invalidateSelf();
    }

    @Override // p200r1.InterfaceC1490q
    public final void g(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        if (i14 != 0) {
            return;
        }
        int i15 = iArr[1];
        if (i14 == 0) {
            this.f17050r.d(i10, i11, i12, i13, this.f17052t, i14, iArr);
        }
        int i16 = i13 - (iArr[1] - i15);
        int i17 = i16 == 0 ? i13 + this.f17052t[1] : i16;
        if (i17 >= 0 || d()) {
            return;
        }
        float fAbs = this.f17048f + Math.abs(i17);
        this.f17048f = fAbs;
        h(fAbs);
        iArr[1] = iArr[1] + i16;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i10, int i11) {
        int i12 = this.f17028E;
        if (i12 < 0) {
            return i11;
        }
        if (i11 == i10 - 1) {
            return i12;
        }
        return i11 >= i12 ? i11 + 1 : i11;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0499e0 c0499e0 = this.f17049q;
        return c0499e0.f7842b | c0499e0.f7841a;
    }

    public int getProgressCircleDiameter() {
        return this.f17038P;
    }

    public int getProgressViewEndOffset() {
        return this.f17031H;
    }

    public int getProgressViewStartOffset() {
        return this.f17030G;
    }

    public final void h(float f10) {
        g gVar;
        g gVar2;
        d dVar = this.f17033J;
        c cVar = dVar.f24684a;
        if (!cVar.f24673n) {
            cVar.f24673n = true;
        }
        dVar.invalidateSelf();
        float fMin = Math.min(1.0f, Math.abs(f10 / this.f17047e));
        float fMax = (((float) Math.max(((double) fMin) - 0.4d, 0.0d)) * 5.0f) / 3.0f;
        float fAbs = Math.abs(f10) - this.f17047e;
        int i10 = this.f17032I;
        if (i10 <= 0) {
            i10 = this.f17031H;
        }
        float f11 = i10;
        double dMax = Math.max(0.0f, Math.min(fAbs, f11 * 2.0f) / f11) / 4.0f;
        float fPow = ((float) (dMax - Math.pow(dMax, 2.0d))) * 2.0f;
        int i11 = this.f17030G + ((int) ((f11 * fMin) + (f11 * fPow * 2.0f)));
        if (this.f17027D.getVisibility() != 0) {
            this.f17027D.setVisibility(0);
        }
        this.f17027D.setScaleX(1.0f);
        this.f17027D.setScaleY(1.0f);
        if (f10 < this.f17047e) {
            if (this.f17033J.f24684a.f24679t > 76 && ((gVar2 = this.M) == null || !gVar2.hasStarted() || gVar2.hasEnded())) {
                g gVar3 = new g(this, this.f17033J.f24684a.f24679t, 76);
                gVar3.setDuration(300L);
                a aVar = this.f17027D;
                aVar.f24657a = null;
                aVar.clearAnimation();
                this.f17027D.startAnimation(gVar3);
                this.M = gVar3;
            }
        } else if (this.f17033J.f24684a.f24679t < 255 && ((gVar = this.f17036N) == null || !gVar.hasStarted() || gVar.hasEnded())) {
            g gVar4 = new g(this, this.f17033J.f24684a.f24679t, 255);
            gVar4.setDuration(300L);
            a aVar2 = this.f17027D;
            aVar2.f24657a = null;
            aVar2.clearAnimation();
            this.f17027D.startAnimation(gVar4);
            this.f17036N = gVar4;
        }
        d dVar2 = this.f17033J;
        float fMin2 = Math.min(0.8f, fMax * 0.8f);
        c cVar2 = dVar2.f24684a;
        cVar2.f24665e = 0.0f;
        cVar2.f24666f = fMin2;
        dVar2.invalidateSelf();
        d dVar3 = this.f17033J;
        float fMin3 = Math.min(1.0f, fMax);
        c cVar3 = dVar3.f24684a;
        if (fMin3 != cVar3.f24675p) {
            cVar3.f24675p = fMin3;
        }
        dVar3.invalidateSelf();
        d dVar4 = this.f17033J;
        dVar4.f24684a.f24667g = ((fPow * 2.0f) + ((fMax * 0.4f) - 0.25f)) * 0.5f;
        dVar4.invalidateSelf();
        setTargetOffsetTopAndBottom(i11 - this.f17056x);
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f17050r.f(0);
    }

    @Override // p200r1.InterfaceC1489p
    public final void i(View view, int i10, int i11, int i12, int i13, int i14) {
        g(view, i10, i11, i12, i13, i14, this.f17053u);
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f17050r.f27746d;
    }

    @Override // p200r1.InterfaceC1489p
    public final boolean j(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            return onStartNestedScroll(view, view2, i10);
        }
        return false;
    }

    public final void k(float f10) {
        int i10 = this.f17029F;
        setTargetOffsetTopAndBottom((i10 + ((int) ((this.f17030G - i10) * f10))) - this.f17027D.getTop());
    }

    public final void l() {
        this.f17027D.clearAnimation();
        this.f17033J.stop();
        this.f17027D.setVisibility(8);
        setColorViewAlpha(255);
        setTargetOffsetTopAndBottom(this.f17030G - this.f17056x);
        this.f17056x = this.f17027D.getTop();
    }

    public final void m(boolean z3, boolean z5) {
        if (this.f17045c != z3) {
            this.f17037O = z5;
            e();
            this.f17045c = z3;
            e eVar = this.f17040R;
            if (!z3) {
                f fVar = new f(this, 1);
                this.f17035L = fVar;
                fVar.setDuration(150L);
                a aVar = this.f17027D;
                aVar.f24657a = eVar;
                aVar.clearAnimation();
                this.f17027D.startAnimation(this.f17035L);
                return;
            }
            this.f17029F = this.f17056x;
            f fVar2 = this.f17041S;
            fVar2.reset();
            fVar2.setDuration(200L);
            fVar2.setInterpolator(this.f17026C);
            if (eVar != null) {
                this.f17027D.f24657a = eVar;
            }
            this.f17027D.clearAnimation();
            this.f17027D.startAnimation(fVar2);
        }
    }

    public final void n(boolean z3, boolean z5) {
        if (!z3 || this.f17045c == z3) {
            m(z3, false);
            return;
        }
        this.f17045c = z3;
        setTargetOffsetTopAndBottom((this.f17031H + this.f17030G) - this.f17056x);
        this.f17037O = z5;
        e eVar = this.f17040R;
        this.f17027D.setVisibility(0);
        this.f17033J.setAlpha(255);
        f fVar = new f(this, 0);
        this.f17034K = fVar;
        fVar.setDuration(this.f17055w);
        if (eVar != null) {
            this.f17027D.f24657a = eVar;
        }
        this.f17027D.clearAnimation();
        this.f17027D.startAnimation(this.f17034K);
    }

    public final void o(float f10) {
        float f11 = this.f17058z;
        float f12 = f10 - f11;
        float f13 = this.f17046d;
        if (f12 <= f13 || this.f17024A) {
            return;
        }
        this.f17057y = f11 + f13;
        this.f17024A = true;
        this.f17033J.setAlpha(76);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        l();
    }

    /* JADX WARN: Code duplicated, block: B:34:0x005f  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        e();
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled() && !d() && !this.f17045c && !this.f17054v) {
            if (actionMasked != 0) {
                if (actionMasked == 1) {
                    this.f17024A = false;
                    this.f17025B = -1;
                } else if (actionMasked == 2) {
                    int i10 = this.f17025B;
                    if (i10 == -1) {
                        Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but don't have an active pointer id.");
                        return false;
                    }
                    int iFindPointerIndex = motionEvent.findPointerIndex(i10);
                    if (iFindPointerIndex >= 0) {
                        o(motionEvent.getY(iFindPointerIndex));
                    }
                } else if (actionMasked == 3) {
                    this.f17024A = false;
                    this.f17025B = -1;
                } else if (actionMasked == 6) {
                    int actionIndex = motionEvent.getActionIndex();
                    if (motionEvent.getPointerId(actionIndex) == this.f17025B) {
                        this.f17025B = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                    }
                }
                return this.f17024A;
            }
            setTargetOffsetTopAndBottom(this.f17030G - this.f17027D.getTop());
            int pointerId = motionEvent.getPointerId(0);
            this.f17025B = pointerId;
            this.f17024A = false;
            int iFindPointerIndex2 = motionEvent.findPointerIndex(pointerId);
            if (iFindPointerIndex2 >= 0) {
                this.f17058z = motionEvent.getY(iFindPointerIndex2);
                return this.f17024A;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int measuredWidth = getMeasuredWidth();
        int measuredHeight = getMeasuredHeight();
        if (getChildCount() == 0) {
            return;
        }
        if (this.f17043a == null) {
            e();
        }
        View view = this.f17043a;
        if (view == null) {
            return;
        }
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        view.layout(paddingLeft, paddingTop, ((measuredWidth - getPaddingLeft()) - getPaddingRight()) + paddingLeft, ((measuredHeight - getPaddingTop()) - getPaddingBottom()) + paddingTop);
        int measuredWidth2 = this.f17027D.getMeasuredWidth();
        int measuredHeight2 = this.f17027D.getMeasuredHeight();
        int i14 = measuredWidth / 2;
        int i15 = measuredWidth2 / 2;
        int i16 = this.f17056x;
        this.f17027D.layout(i14 - i15, i16, i14 + i15, measuredHeight2 + i16);
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        if (this.f17043a == null) {
            e();
        }
        View view = this.f17043a;
        if (view == null) {
            return;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom(), 1073741824));
        this.f17027D.measure(View.MeasureSpec.makeMeasureSpec(this.f17038P, 1073741824), View.MeasureSpec.makeMeasureSpec(this.f17038P, 1073741824));
        this.f17028E = -1;
        for (int i12 = 0; i12 < getChildCount(); i12++) {
            if (getChildAt(i12) == this.f17027D) {
                this.f17028E = i12;
                return;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        return this.f17050r.a(f10, f11, z3);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return this.f17050r.b(f10, f11);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        if (i11 > 0) {
            float f10 = this.f17048f;
            if (f10 > 0.0f) {
                float f11 = i11;
                if (f11 > f10) {
                    iArr[1] = (int) f10;
                    this.f17048f = 0.0f;
                } else {
                    this.f17048f = f10 - f11;
                    iArr[1] = i11;
                }
                h(this.f17048f);
            }
        }
        int i12 = i10 - iArr[0];
        int i13 = i11 - iArr[1];
        int[] iArr2 = this.f17051s;
        if (dispatchNestedPreScroll(i12, i13, iArr2, null)) {
            iArr[0] = iArr[0] + iArr2[0];
            iArr[1] = iArr[1] + iArr2[1];
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        g(view, i10, i11, i12, i13, 0, this.f17053u);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        this.f17049q.f7841a = i10;
        startNestedScroll(i10 & 2);
        this.f17048f = 0.0f;
        this.f17054v = true;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        j jVar = (j) parcelable;
        super.onRestoreInstanceState(jVar.getSuperState());
        setRefreshing(jVar.f24697a);
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        return new j(super.onSaveInstanceState(), this.f17045c);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return (!isEnabled() || this.f17045c || (i10 & 2) == 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        this.f17049q.f7841a = 0;
        this.f17054v = false;
        float f10 = this.f17048f;
        if (f10 > 0.0f) {
            f(f10);
            this.f17048f = 0.0f;
        } else {
            post(new h(this, 4));
        }
        stopNestedScroll();
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (isEnabled() && !d() && !this.f17045c && !this.f17054v) {
            if (actionMasked == 0) {
                this.f17025B = motionEvent.getPointerId(0);
                this.f17024A = false;
                return true;
            }
            if (actionMasked == 1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f17025B);
                if (iFindPointerIndex < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_UP event but don't have an active pointer id.");
                    return false;
                }
                if (this.f17024A) {
                    float y10 = (motionEvent.getY(iFindPointerIndex) - this.f17057y) * 0.5f;
                    this.f17024A = false;
                    f(y10);
                }
                this.f17025B = -1;
                return false;
            }
            if (actionMasked == 2) {
                int iFindPointerIndex2 = motionEvent.findPointerIndex(this.f17025B);
                if (iFindPointerIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_MOVE event but have an invalid active pointer id.");
                    return false;
                }
                float y11 = motionEvent.getY(iFindPointerIndex2);
                o(y11);
                if (this.f17024A) {
                    float f10 = (y11 - this.f17057y) * 0.5f;
                    if (f10 > 0.0f) {
                        getParent().requestDisallowInterceptTouchEvent(true);
                        h(f10);
                    }
                }
                return true;
            }
            if (actionMasked != 3) {
                if (actionMasked != 5) {
                    if (actionMasked == 6) {
                        int actionIndex = motionEvent.getActionIndex();
                        if (motionEvent.getPointerId(actionIndex) == this.f17025B) {
                            this.f17025B = motionEvent.getPointerId(actionIndex == 0 ? 1 : 0);
                            return true;
                        }
                    }
                    return true;
                }
                int actionIndex2 = motionEvent.getActionIndex();
                if (actionIndex2 < 0) {
                    Log.e("SwipeRefreshLayout", "Got ACTION_POINTER_DOWN event but have an invalid action index.");
                    return false;
                }
                this.f17025B = motionEvent.getPointerId(actionIndex2);
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        View view;
        if (this.f17039Q && (view = this.f17043a) != null) {
            WeakHashMap weakHashMap = U.f27683a;
            if (!H.p(view)) {
                return;
            }
        }
        super.requestDisallowInterceptTouchEvent(z3);
    }

    public void setAnimationProgress(float f10) {
        this.f17027D.setScaleX(f10);
        this.f17027D.setScaleY(f10);
    }

    @Deprecated
    public void setColorScheme(int... iArr) {
        setColorSchemeResources(iArr);
    }

    public void setColorSchemeColors(int... iArr) {
        e();
        d dVar = this.f17033J;
        c cVar = dVar.f24684a;
        cVar.f24669i = iArr;
        cVar.a(0);
        cVar.a(0);
        dVar.invalidateSelf();
    }

    public void setColorSchemeResources(int... iArr) {
        Context context = getContext();
        int[] iArr2 = new int[iArr.length];
        for (int i10 = 0; i10 < iArr.length; i10++) {
            iArr2[i10] = p063f1.h.getColor(context, iArr[i10]);
        }
        setColorSchemeColors(iArr2);
    }

    public void setDistanceToTriggerSync(int i10) {
        this.f17047e = i10;
    }

    @Override // android.view.View
    public void setEnabled(boolean z3) {
        super.setEnabled(z3);
        if (z3) {
            return;
        }
        l();
    }

    @Deprecated
    public void setLegacyRequestDisallowInterceptTouchEventEnabled(boolean z3) {
        this.f17039Q = z3;
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z3) {
        C1488o c1488o = this.f17050r;
        if (c1488o.f27746d) {
            WeakHashMap weakHashMap = U.f27683a;
            H.z(c1488o.f27745c);
        }
        c1488o.f27746d = z3;
    }

    public void setOnRefreshListener(i iVar) {
        this.f17044b = iVar;
    }

    @Deprecated
    public void setProgressBackgroundColor(int i10) {
        setProgressBackgroundColorSchemeResource(i10);
    }

    public void setProgressBackgroundColorSchemeColor(int i10) {
        this.f17027D.setBackgroundColor(i10);
    }

    public void setProgressBackgroundColorSchemeResource(int i10) {
        setProgressBackgroundColorSchemeColor(p063f1.h.getColor(getContext(), i10));
    }

    public void setRefreshing(boolean z3) {
        n(z3, false);
    }

    public void setSize(int i10) {
        if (i10 == 0 || i10 == 1) {
            DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
            if (i10 == 0) {
                this.f17038P = (int) (displayMetrics.density * 56.0f);
            } else {
                this.f17038P = (int) (displayMetrics.density * 40.0f);
            }
            this.f17027D.setImageDrawable(null);
            this.f17033J.c(i10);
            this.f17027D.setImageDrawable(this.f17033J);
        }
    }

    public void setSlingshotDistance(int i10) {
        this.f17032I = i10;
    }

    public void setTargetOffsetTopAndBottom(int i10) {
        a aVar = this.f17027D;
        aVar.bringToFront();
        WeakHashMap weakHashMap = U.f27683a;
        aVar.offsetTopAndBottom(i10);
        this.f17056x = aVar.getTop();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i10) {
        return this.f17050r.g(i10, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        this.f17050r.h(0);
    }

    public void setOnChildScrollUpCallback(l2.h hVar) {
    }
}
