package androidx.lifecycle;

import java.util.HashMap;

/* JADX INFO: renamed from: androidx.lifecycle.g, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0807g implements B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16485a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f16486b;

    public /* synthetic */ C0807g(Object obj, int i10) {
        this.f16485a = i10;
        this.f16486b = obj;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        switch (this.f16485a) {
            case 0:
                new HashMap();
                InterfaceC0814n[] interfaceC0814nArr = (InterfaceC0814n[]) this.f16486b;
                if (interfaceC0814nArr.length > 0) {
                    InterfaceC0814n interfaceC0814n = interfaceC0814nArr[0];
                    throw null;
                }
                if (interfaceC0814nArr.length <= 0) {
                    return;
                }
                InterfaceC0814n interfaceC0814n2 = interfaceC0814nArr[0];
                throw null;
            default:
                if (enumC0818s == EnumC0818s.ON_CREATE) {
                    d10.j().f(this);
                    ((k0) this.f16486b).b();
                    return;
                } else {
                    throw new IllegalStateException(("Next event must be ON_CREATE, it was " + enumC0818s).toString());
                }
        }
    }
}
