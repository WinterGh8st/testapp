package androidx.lifecycle;

import p230ta.InterfaceC1640h0;

/* JADX INFO: renamed from: androidx.lifecycle.u, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0820u {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final F f16531a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final EnumC0819t f16532b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final V4.H f16533c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final Z1.h f16534d;

    public C0820u(F f10, EnumC0819t enumC0819t, V4.H h10, InterfaceC1640h0 interfaceC1640h0) {
        p097ha.k.f(f10, "lifecycle");
        p097ha.k.f(h10, "dispatchQueue");
        this.f16531a = f10;
        this.f16532b = enumC0819t;
        this.f16533c = h10;
        Z1.h hVar = new Z1.h(1, this, interfaceC1640h0);
        this.f16534d = hVar;
        if (f10.f16395d != EnumC0819t.f16524a) {
            f10.a(hVar);
        } else {
            interfaceC1640h0.c(null);
            a();
        }
    }

    public final void a() {
        this.f16531a.f(this.f16534d);
        V4.H h10 = this.f16533c;
        h10.f12910b = true;
        h10.a();
    }
}
