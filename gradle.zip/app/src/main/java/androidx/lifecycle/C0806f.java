package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.f, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0806f {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final C0806f f16480c = new C0806f();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f16481a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f16482b = new HashMap();

    public static void b(HashMap map, C0805e c0805e, EnumC0818s enumC0818s, Class cls) {
        EnumC0818s enumC0818s2 = (EnumC0818s) map.get(c0805e);
        if (enumC0818s2 == null || enumC0818s == enumC0818s2) {
            if (enumC0818s2 == null) {
                map.put(c0805e, enumC0818s);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c0805e.f16479b.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + enumC0818s2 + ", new value " + enumC0818s);
    }

    public final C0804d a(Class cls, Method[] methodArr) {
        int i10;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        HashMap map2 = this.f16481a;
        if (superclass != null) {
            C0804d c0804dA = (C0804d) map2.get(superclass);
            if (c0804dA == null) {
                c0804dA = a(superclass, null);
            }
            map.putAll(c0804dA.f16477b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            C0804d c0804dA2 = (C0804d) map2.get(cls2);
            if (c0804dA2 == null) {
                c0804dA2 = a(cls2, null);
            }
            for (Map.Entry entry : c0804dA2.f16477b.entrySet()) {
                b(map, (C0805e) entry.getKey(), (EnumC0818s) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e10) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e10);
            }
        }
        boolean z3 = false;
        for (Method method : methodArr) {
            S s5 = (S) method.getAnnotation(S.class);
            if (s5 != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i10 = 0;
                } else {
                    if (!D.class.isAssignableFrom(parameterTypes[0])) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i10 = 1;
                }
                EnumC0818s enumC0818sValue = s5.value();
                if (parameterTypes.length > 1) {
                    if (!EnumC0818s.class.isAssignableFrom(parameterTypes[1])) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (enumC0818sValue != EnumC0818s.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i10 = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                b(map, new C0805e(i10, method), enumC0818sValue, cls);
                z3 = true;
            }
        }
        C0804d c0804d = new C0804d(map);
        map2.put(cls, c0804d);
        this.f16482b.put(cls, Boolean.valueOf(z3));
        return c0804d;
    }
}
