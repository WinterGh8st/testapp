package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: renamed from: androidx.lifecycle.x, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0823x extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f16544a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0824y f16545b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0823x(C0824y c0824y, X9.d dVar) {
        super(2, dVar);
        this.f16545b = c0824y;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        C0823x c0823x = new C0823x(this.f16545b, dVar);
        c0823x.f16544a = obj;
        return c0823x;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        C0823x c0823x = (C0823x) create((p230ta.C) obj, (X9.d) obj2);
        T9.w wVar = T9.w.f11979a;
        c0823x.invokeSuspend(wVar);
        return wVar;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        AbstractC0862l.m0(obj);
        p230ta.C c10 = (p230ta.C) this.f16544a;
        C0824y c0824y = this.f16545b;
        F f10 = c0824y.f16546a;
        if (f10.f16395d.compareTo(EnumC0819t.f16525b) >= 0) {
            f10.a(c0824y);
        } else {
            p230ta.E.d(c10.g(), null);
        }
        return T9.w.f11979a;
    }
}
