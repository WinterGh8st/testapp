package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class u0 {
    public abstract void c(q0 q0Var);
}
