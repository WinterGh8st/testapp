package androidx.lifecycle;

import p230ta.C1647l;
import p230ta.InterfaceC1640h0;

/* JADX INFO: loaded from: classes.dex */
public final class a0 implements B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ EnumC0818s f16454a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ p097ha.u f16455b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p230ta.C f16456c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ EnumC0818s f16457d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C1647l f16458e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Ca.d f16459f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final /* synthetic */ Z9.i f16460q;

    /* JADX WARN: Multi-variable type inference failed */
    public a0(EnumC0818s enumC0818s, p097ha.u uVar, p230ta.C c10, EnumC0818s enumC0818s2, C1647l c1647l, Ca.d dVar, p084ga.e eVar) {
        this.f16454a = enumC0818s;
        this.f16455b = uVar;
        this.f16456c = c10;
        this.f16457d = enumC0818s2;
        this.f16458e = c1647l;
        this.f16459f = dVar;
        this.f16460q = (Z9.i) eVar;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [Z9.i, ga.e] */
    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        p097ha.u uVar = this.f16455b;
        if (enumC0818s == this.f16454a) {
            uVar.f23278a = p230ta.E.t(this.f16456c, null, new Z(this.f16459f, this.f16460q, null), 3);
            return;
        }
        if (enumC0818s == this.f16457d) {
            InterfaceC1640h0 interfaceC1640h0 = (InterfaceC1640h0) uVar.f23278a;
            if (interfaceC1640h0 != null) {
                interfaceC1640h0.c(null);
            }
            uVar.f23278a = null;
        }
        if (enumC0818s == EnumC0818s.ON_DESTROY) {
            this.f16458e.resumeWith(T9.w.f11979a);
        }
    }
}
