package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class c0 extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16472a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f16473b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ F f16474c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Z9.i f16475d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public c0(F f10, p084ga.e eVar, X9.d dVar) {
        super(2, dVar);
        EnumC0819t enumC0819t = EnumC0819t.f16524a;
        this.f16474c = f10;
        this.f16475d = (Z9.i) eVar;
    }

    /* JADX WARN: Type inference failed for: r1v1, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        EnumC0819t enumC0819t = EnumC0819t.f16524a;
        c0 c0Var = new c0(this.f16474c, this.f16475d, dVar);
        c0Var.f16473b = obj;
        return c0Var;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((c0) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Type inference failed for: r4v0, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16472a;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            p230ta.C c10 = (p230ta.C) this.f16473b;
            Aa.e eVar = p230ta.M.f29486a;
            p239ua.e eVar2 = p282ya.n.f32793a.f30221f;
            ?? r7 = this.f16475d;
            EnumC0819t enumC0819t = EnumC0819t.f16524a;
            b0 b0Var = new b0(this.f16474c, c10, r7, null);
            this.f16472a = 1;
            if (p230ta.E.C(eVar2, b0Var, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        return T9.w.f11979a;
    }
}
