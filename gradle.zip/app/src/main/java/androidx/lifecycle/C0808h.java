package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.h, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0808h extends Z9.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f16489a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0809i f16490b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16491c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0808h(C0809i c0809i, Z9.c cVar) {
        super(cVar);
        this.f16490b = c0809i;
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        this.f16489a = obj;
        this.f16491c |= Integer.MIN_VALUE;
        this.f16490b.l(this);
        return T9.w.f11979a;
    }
}
