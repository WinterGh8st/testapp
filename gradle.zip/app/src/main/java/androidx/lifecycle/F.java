package androidx.lifecycle;

import L.AbstractC0492c;
import android.os.Looper;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class F {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public v0 f16392a = new v0();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final boolean f16393b = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public p198r.a f16394c = new p198r.a();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public EnumC0819t f16395d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final WeakReference f16396e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16397f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f16398g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16399h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final ArrayList f16400i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final p259wa.a0 f16401j;

    public F(D d10) {
        EnumC0819t enumC0819t = EnumC0819t.f16525b;
        this.f16395d = enumC0819t;
        this.f16400i = new ArrayList();
        this.f16396e = new WeakReference(d10);
        this.f16401j = p259wa.M.c(enumC0819t);
    }

    public final void a(C c10) {
        B c0812l;
        Object obj;
        D d10;
        EnumC0818s enumC0818s;
        ArrayList arrayList = this.f16400i;
        int i10 = 0;
        p097ha.k.f(c10, "observer");
        c("addObserver");
        EnumC0819t enumC0819t = this.f16395d;
        EnumC0819t enumC0819t2 = EnumC0819t.f16524a;
        if (enumC0819t != enumC0819t2) {
            enumC0819t2 = EnumC0819t.f16525b;
        }
        E e10 = new E();
        HashMap map = G.f16402a;
        boolean z3 = c10 instanceof B;
        boolean z5 = c10 instanceof InterfaceC0810j;
        if (z3 && z5) {
            c0812l = new C0812l((InterfaceC0810j) c10, (B) c10);
        } else if (z5) {
            c0812l = new C0812l((InterfaceC0810j) c10, (B) null);
        } else if (z3) {
            c0812l = (B) c10;
        } else {
            Class<?> cls = c10.getClass();
            if (G.b(cls) == 2) {
                Object obj2 = G.f16403b.get(cls);
                p097ha.k.c(obj2);
                List list = (List) obj2;
                if (list.size() == 1) {
                    G.a((Constructor) list.get(0), c10);
                    throw null;
                }
                int size = list.size();
                InterfaceC0814n[] interfaceC0814nArr = new InterfaceC0814n[size];
                if (size > 0) {
                    G.a((Constructor) list.get(0), c10);
                    throw null;
                }
                c0812l = new C0807g(interfaceC0814nArr, i10);
            } else {
                c0812l = new C0812l(c10);
            }
        }
        e10.f16391b = c0812l;
        e10.f16390a = enumC0819t2;
        p198r.a aVar = this.f16394c;
        p198r.c cVarA = aVar.a(c10);
        if (cVarA != null) {
            obj = cVarA.f27551b;
        } else {
            HashMap map2 = aVar.f27546e;
            p198r.c cVar = new p198r.c(c10, e10);
            aVar.f27560d++;
            p198r.c cVar2 = aVar.f27558b;
            if (cVar2 == null) {
                aVar.f27557a = cVar;
                aVar.f27558b = cVar;
            } else {
                cVar2.f27552c = cVar;
                cVar.f27553d = cVar2;
                aVar.f27558b = cVar;
            }
            map2.put(c10, cVar);
            obj = null;
        }
        if (((E) obj) == null && (d10 = (D) this.f16396e.get()) != null) {
            i10 = (this.f16397f != 0 || this.f16398g) ? 1 : 0;
            EnumC0819t enumC0819tB = b(c10);
            this.f16397f++;
            while (e10.f16390a.compareTo(enumC0819tB) < 0 && this.f16394c.f27546e.containsKey(c10)) {
                arrayList.add(e10.f16390a);
                C0817q c0817q = EnumC0818s.Companion;
                EnumC0819t enumC0819t3 = e10.f16390a;
                c0817q.getClass();
                p097ha.k.f(enumC0819t3, "state");
                int iOrdinal = enumC0819t3.ordinal();
                if (iOrdinal == 1) {
                    enumC0818s = EnumC0818s.ON_CREATE;
                } else if (iOrdinal != 2) {
                    enumC0818s = iOrdinal != 3 ? null : EnumC0818s.ON_RESUME;
                } else {
                    enumC0818s = EnumC0818s.ON_START;
                }
                if (enumC0818s == null) {
                    throw new IllegalStateException("no event up from " + e10.f16390a);
                }
                e10.a(d10, enumC0818s);
                arrayList.remove(arrayList.size() - 1);
                enumC0819tB = b(c10);
            }
            if (i10 == 0) {
                h();
            }
            this.f16397f--;
        }
    }

    public final EnumC0819t b(C c10) {
        HashMap map = this.f16394c.f27546e;
        p198r.c cVar = map.containsKey(c10) ? ((p198r.c) map.get(c10)).f27553d : null;
        EnumC0819t enumC0819t = cVar != null ? ((E) cVar.f27551b).f16390a : null;
        ArrayList arrayList = this.f16400i;
        EnumC0819t enumC0819t2 = arrayList.isEmpty() ? null : (EnumC0819t) p096h9.i.h(1, arrayList);
        EnumC0819t enumC0819t3 = this.f16395d;
        p097ha.k.f(enumC0819t3, "state1");
        if (enumC0819t == null || enumC0819t.compareTo(enumC0819t3) >= 0) {
            enumC0819t = enumC0819t3;
        }
        return (enumC0819t2 == null || enumC0819t2.compareTo(enumC0819t) >= 0) ? enumC0819t : enumC0819t2;
    }

    public final void c(String str) {
        if (this.f16393b) {
            p187q.a.p0().f27438b.getClass();
            if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
                throw new IllegalStateException(AbstractC0492c.l("Method ", str, " must be called on the main thread").toString());
            }
        }
    }

    public final void d(EnumC0818s enumC0818s) {
        p097ha.k.f(enumC0818s, "event");
        c("handleLifecycleEvent");
        e(enumC0818s.a());
    }

    public final void e(EnumC0819t enumC0819t) {
        if (this.f16395d == enumC0819t) {
            return;
        }
        D d10 = (D) this.f16396e.get();
        EnumC0819t enumC0819t2 = this.f16395d;
        p097ha.k.f(enumC0819t2, "current");
        p097ha.k.f(enumC0819t, "next");
        if (enumC0819t2 == EnumC0819t.f16525b && enumC0819t == EnumC0819t.f16524a) {
            throw new IllegalStateException(("State must be at least '" + EnumC0819t.f16526c + "' to be moved to '" + enumC0819t + "' in component " + d10).toString());
        }
        EnumC0819t enumC0819t3 = EnumC0819t.f16524a;
        if (enumC0819t2 == enumC0819t3 && enumC0819t2 != enumC0819t) {
            throw new IllegalStateException(("State is '" + enumC0819t3 + "' and cannot be moved to `" + enumC0819t + "` in component " + d10).toString());
        }
        this.f16395d = enumC0819t;
        if (this.f16398g || this.f16397f != 0) {
            this.f16399h = true;
            return;
        }
        this.f16398g = true;
        h();
        this.f16398g = false;
        if (this.f16395d == enumC0819t3) {
            this.f16394c = new p198r.a();
        }
    }

    public final void f(C c10) {
        p097ha.k.f(c10, "observer");
        c("removeObserver");
        this.f16394c.b(c10);
    }

    public final void g(EnumC0819t enumC0819t) {
        p097ha.k.f(enumC0819t, "state");
        c("setCurrentState");
        e(enumC0819t);
    }

    public final void h() {
        EnumC0818s enumC0818s;
        EnumC0818s enumC0818s2;
        D d10 = (D) this.f16396e.get();
        if (d10 == null) {
            throw new IllegalStateException("LifecycleOwner of this LifecycleRegistry is already garbage collected. It is too late to change lifecycle state.");
        }
        while (true) {
            p198r.a aVar = this.f16394c;
            if (aVar.f27560d != 0) {
                p198r.c cVar = aVar.f27557a;
                p097ha.k.c(cVar);
                EnumC0819t enumC0819t = ((E) cVar.f27551b).f16390a;
                p198r.c cVar2 = this.f16394c.f27558b;
                p097ha.k.c(cVar2);
                EnumC0819t enumC0819t2 = ((E) cVar2.f27551b).f16390a;
                if (enumC0819t == enumC0819t2 && this.f16395d == enumC0819t2) {
                    break;
                }
                this.f16399h = false;
                EnumC0819t enumC0819t3 = this.f16395d;
                p198r.c cVar3 = this.f16394c.f27557a;
                p097ha.k.c(cVar3);
                if (enumC0819t3.compareTo(((E) cVar3.f27551b).f16390a) < 0) {
                    p198r.a aVar2 = this.f16394c;
                    p198r.b bVar = new p198r.b(aVar2.f27558b, aVar2.f27557a, 1);
                    aVar2.f27559c.put(bVar, Boolean.FALSE);
                    while (bVar.hasNext() && !this.f16399h) {
                        Map.Entry entry = (Map.Entry) bVar.next();
                        p097ha.k.c(entry);
                        C c10 = (C) entry.getKey();
                        E e10 = (E) entry.getValue();
                        while (e10.f16390a.compareTo(this.f16395d) > 0 && !this.f16399h && this.f16394c.f27546e.containsKey(c10)) {
                            C0817q c0817q = EnumC0818s.Companion;
                            EnumC0819t enumC0819t4 = e10.f16390a;
                            c0817q.getClass();
                            p097ha.k.f(enumC0819t4, "state");
                            int iOrdinal = enumC0819t4.ordinal();
                            if (iOrdinal == 2) {
                                enumC0818s2 = EnumC0818s.ON_DESTROY;
                            } else if (iOrdinal != 3) {
                                enumC0818s2 = iOrdinal != 4 ? null : EnumC0818s.ON_PAUSE;
                            } else {
                                enumC0818s2 = EnumC0818s.ON_STOP;
                            }
                            if (enumC0818s2 == null) {
                                throw new IllegalStateException("no event down from " + e10.f16390a);
                            }
                            this.f16400i.add(enumC0818s2.a());
                            e10.a(d10, enumC0818s2);
                            ArrayList arrayList = this.f16400i;
                            arrayList.remove(arrayList.size() - 1);
                        }
                    }
                }
                p198r.c cVar4 = this.f16394c.f27558b;
                if (!this.f16399h && cVar4 != null && this.f16395d.compareTo(((E) cVar4.f27551b).f16390a) > 0) {
                    p198r.a aVar3 = this.f16394c;
                    aVar3.getClass();
                    p198r.d dVar = new p198r.d(aVar3);
                    aVar3.f27559c.put(dVar, Boolean.FALSE);
                    while (dVar.hasNext() && !this.f16399h) {
                        Map.Entry entry2 = (Map.Entry) dVar.next();
                        C c11 = (C) entry2.getKey();
                        E e11 = (E) entry2.getValue();
                        while (e11.f16390a.compareTo(this.f16395d) < 0 && !this.f16399h && this.f16394c.f27546e.containsKey(c11)) {
                            this.f16400i.add(e11.f16390a);
                            C0817q c0817q2 = EnumC0818s.Companion;
                            EnumC0819t enumC0819t5 = e11.f16390a;
                            c0817q2.getClass();
                            p097ha.k.f(enumC0819t5, "state");
                            int iOrdinal2 = enumC0819t5.ordinal();
                            if (iOrdinal2 == 1) {
                                enumC0818s = EnumC0818s.ON_CREATE;
                            } else if (iOrdinal2 != 2) {
                                enumC0818s = iOrdinal2 != 3 ? null : EnumC0818s.ON_RESUME;
                            } else {
                                enumC0818s = EnumC0818s.ON_START;
                            }
                            if (enumC0818s == null) {
                                throw new IllegalStateException("no event up from " + e11.f16390a);
                            }
                            e11.a(d10, enumC0818s);
                            ArrayList arrayList2 = this.f16400i;
                            arrayList2.remove(arrayList2.size() - 1);
                        }
                    }
                }
            } else {
                break;
            }
        }
        this.f16399h = false;
        this.f16401j.j(this.f16395d);
    }
}
