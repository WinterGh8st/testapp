package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class J extends K implements B {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final D f16405e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ P f16406f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(P p10, D d10, Q q10) {
        super(p10, q10);
        this.f16406f = p10;
        this.f16405e = d10;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        D d11 = this.f16405e;
        EnumC0819t enumC0819t = d11.j().f16395d;
        if (enumC0819t == EnumC0819t.f16524a) {
            this.f16406f.j(this.f16407a);
            return;
        }
        EnumC0819t enumC0819t2 = null;
        while (enumC0819t2 != enumC0819t) {
            a(g());
            enumC0819t2 = enumC0819t;
            enumC0819t = d11.j().f16395d;
        }
    }

    @Override // androidx.lifecycle.K
    public final void e() {
        this.f16405e.j().f(this);
    }

    @Override // androidx.lifecycle.K
    public final boolean f(D d10) {
        return this.f16405e == d10;
    }

    @Override // androidx.lifecycle.K
    public final boolean g() {
        return this.f16405e.j().f16395d.compareTo(EnumC0819t.f16527d) >= 0;
    }
}
