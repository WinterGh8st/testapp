package androidx.lifecycle;

import Y1.C0794i;
import java.util.concurrent.atomic.AtomicReference;

/* JADX INFO: loaded from: classes.dex */
public final class v0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0794i f16538b = new C0794i(3);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f16539a;

    public v0() {
        this.f16539a = new AtomicReference(null);
    }

    public v0(w0 w0Var, s0 s0Var, S1.c cVar) {
        p097ha.k.f(w0Var, "store");
        p097ha.k.f(s0Var, "factory");
        p097ha.k.f(cVar, "defaultCreationExtras");
        this.f16539a = new p278y6.s(w0Var, s0Var, cVar);
    }

    public v0(X x10) {
        this.f16539a = x10;
    }
}
