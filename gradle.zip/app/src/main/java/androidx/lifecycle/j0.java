package androidx.lifecycle;

import Y1.C0794i;
import android.os.Bundle;
import android.view.View;
import com.flamingotools.ws.R;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicReference;
import p230ta.z0;

/* JADX INFO: loaded from: classes.dex */
public abstract class j0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final Y0.F f16496a = new Y0.F(2);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final C0794i f16497b = new C0794i(2);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final Xa.a f16498c = new Xa.a(3);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final U1.c f16499d = new U1.c();

    public static final void a(q0 q0Var, p056e7.n nVar, F f10) {
        p097ha.k.f(nVar, "registry");
        p097ha.k.f(f10, "lifecycle");
        h0 h0Var = (h0) q0Var.c("androidx.lifecycle.savedstate.vm.tag");
        if (h0Var == null || h0Var.f16494c) {
            return;
        }
        h0Var.e(f10, nVar);
        o(f10, nVar);
    }

    public static final h0 b(p056e7.n nVar, F f10, String str, Bundle bundle) {
        g0 g0Var;
        p097ha.k.f(nVar, "registry");
        p097ha.k.f(f10, "lifecycle");
        Bundle bundleC = nVar.c(str);
        if (bundleC != null) {
            bundle = bundleC;
        }
        if (bundle == null) {
            g0Var = new g0();
        } else {
            ClassLoader classLoader = g0.class.getClassLoader();
            p097ha.k.c(classLoader);
            bundle.setClassLoader(classLoader);
            V9.f fVar = new V9.f(bundle.size());
            for (String str2 : bundle.keySet()) {
                p097ha.k.c(str2);
                fVar.put(str2, bundle.get(str2));
            }
            g0Var = new g0(fVar.d());
        }
        h0 h0Var = new h0(str, g0Var);
        h0Var.e(f10, nVar);
        o(f10, nVar);
        return h0Var;
    }

    public static final g0 c(S1.c cVar) {
        g0 g0Var;
        p097ha.k.f(cVar, "<this>");
        p076g2.e eVar = (p076g2.e) cVar.a(f16496a);
        if (eVar == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `SAVED_STATE_REGISTRY_OWNER_KEY`");
        }
        x0 x0Var = (x0) cVar.a(f16497b);
        if (x0Var == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_STORE_OWNER_KEY`");
        }
        Bundle bundle = (Bundle) cVar.a(f16498c);
        String str = (String) cVar.a(v0.f16538b);
        if (str == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_KEY`");
        }
        p076g2.d dVarO = eVar.b().o();
        Bundle bundle2 = null;
        k0 k0Var = dVarO instanceof k0 ? (k0) dVarO : null;
        if (k0Var == null) {
            throw new IllegalStateException("enableSavedStateHandles() wasn't called prior to createSavedStateHandle() call");
        }
        LinkedHashMap linkedHashMap = i(x0Var).f16508b;
        g0 g0Var2 = (g0) linkedHashMap.get(str);
        if (g0Var2 != null) {
            return g0Var2;
        }
        k0Var.b();
        Bundle bundle3 = k0Var.f16503c;
        if (bundle3 != null && bundle3.containsKey(str)) {
            Bundle bundle4 = bundle3.getBundle(str);
            if (bundle4 == null) {
                bundle4 = G6.C.E((T9.h[]) Arrays.copyOf(new T9.h[0], 0));
            }
            bundle3.remove(str);
            if (bundle3.isEmpty()) {
                k0Var.f16503c = null;
            }
            bundle2 = bundle4;
        }
        if (bundle2 != null) {
            bundle = bundle2;
        }
        if (bundle == null) {
            g0Var = new g0();
        } else {
            ClassLoader classLoader = g0.class.getClassLoader();
            p097ha.k.c(classLoader);
            bundle.setClassLoader(classLoader);
            V9.f fVar = new V9.f(bundle.size());
            for (String str2 : bundle.keySet()) {
                p097ha.k.c(str2);
                fVar.put(str2, bundle.get(str2));
            }
            g0Var = new g0(fVar.d());
        }
        linkedHashMap.put(str, g0Var);
        return g0Var;
    }

    public static final O d(P p10) {
        O o4;
        Object obj;
        p097ha.q qVar = new p097ha.q();
        qVar.f23274a = true;
        if (p10.f16424e != P.k) {
            qVar.f23274a = false;
            o4 = new O(p10.d());
            o4.f16419l = new p198r.f();
        } else {
            o4 = new O();
        }
        p0 p0Var = new p0(new o0(o4, qVar));
        N n10 = new N(p10, p0Var);
        p198r.f fVar = o4.f16419l;
        p198r.c cVarA = fVar.a(p10);
        if (cVarA != null) {
            obj = cVarA.f27551b;
        } else {
            p198r.c cVar = new p198r.c(p10, n10);
            fVar.f27560d++;
            p198r.c cVar2 = fVar.f27558b;
            if (cVar2 == null) {
                fVar.f27557a = cVar;
                fVar.f27558b = cVar;
            } else {
                cVar2.f27552c = cVar;
                cVar.f27553d = cVar2;
                fVar.f27558b = cVar;
            }
            obj = null;
        }
        N n11 = (N) obj;
        if (n11 != null && n11.f16417b != p0Var) {
            throw new IllegalArgumentException("This source was already added with the different observer");
        }
        if (n11 == null && o4.f16422c > 0) {
            n10.b();
        }
        return o4;
    }

    public static final void e(p076g2.e eVar) {
        p097ha.k.f(eVar, "<this>");
        EnumC0819t enumC0819t = eVar.j().f16395d;
        if (enumC0819t != EnumC0819t.f16525b && enumC0819t != EnumC0819t.f16526c) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        if (eVar.b().o() == null) {
            k0 k0Var = new k0(eVar.b(), (x0) eVar);
            eVar.b().E("androidx.lifecycle.internal.SavedStateHandlesProvider", k0Var);
            eVar.j().a(new C0807g(k0Var, 1));
        }
    }

    public static final D f(View view) {
        p097ha.k.f(view, "<this>");
        while (view != null) {
            Object tag = view.getTag(R.id.view_tree_lifecycle_owner);
            D d10 = tag instanceof D ? (D) tag : null;
            if (d10 != null) {
                return d10;
            }
            Object objJ = p195q8.d.j(view);
            view = objJ instanceof View ? (View) objJ : null;
        }
        return null;
    }

    public static final x0 g(View view) {
        p097ha.k.f(view, "<this>");
        while (view != null) {
            Object tag = view.getTag(R.id.view_tree_view_model_store_owner);
            x0 x0Var = tag instanceof x0 ? (x0) tag : null;
            if (x0Var != null) {
                return x0Var;
            }
            Object objJ = p195q8.d.j(view);
            view = objJ instanceof View ? (View) objJ : null;
        }
        return null;
    }

    public static final C0824y h(D d10) {
        p097ha.k.f(d10, "<this>");
        F fJ = d10.j();
        p097ha.k.f(fJ, "<this>");
        while (true) {
            v0 v0Var = fJ.f16392a;
            C0824y c0824y = (C0824y) ((AtomicReference) v0Var.f16539a).get();
            if (c0824y != null) {
                return c0824y;
            }
            z0 z0VarB = p230ta.E.b();
            Aa.e eVar = p230ta.M.f29486a;
            C0824y c0824y2 = new C0824y(fJ, p054e4.e.s0(z0VarB, p282ya.n.f32793a.f30221f));
            AtomicReference atomicReference = (AtomicReference) v0Var.f16539a;
            do {
                if (atomicReference.compareAndSet(null, c0824y2)) {
                    Aa.e eVar2 = p230ta.M.f29486a;
                    p230ta.E.t(c0824y2, p282ya.n.f32793a.f30221f, new C0823x(c0824y2, null), 2);
                    return c0824y2;
                }
            } while (atomicReference.get() == null);
        }
    }

    public static final l0 i(x0 x0Var) {
        p097ha.k.f(x0Var, "<this>");
        i0 i0Var = new i0();
        S1.c cVarE = x0Var instanceof InterfaceC0815o ? ((InterfaceC0815o) x0Var).e() : S1.a.f11265b;
        p097ha.k.f(cVarE, "extras");
        w0 w0VarG = x0Var.g();
        p097ha.k.f(w0VarG, "store");
        return (l0) new p278y6.s(w0VarG, i0Var, cVarE).H(p097ha.v.a(l0.class), "androidx.lifecycle.internal.SavedStateHandlesVM");
    }

    public static final U1.a j(q0 q0Var) {
        U1.a aVar;
        p097ha.k.f(q0Var, "<this>");
        synchronized (f16499d) {
            aVar = (U1.a) q0Var.c("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY");
            if (aVar == null) {
                X9.i iVar = X9.j.f13659a;
                try {
                    Aa.e eVar = p230ta.M.f29486a;
                    iVar = p282ya.n.f32793a.f30221f;
                } catch (T9.g | IllegalStateException unused) {
                }
                U1.a aVar2 = new U1.a(iVar.m(p230ta.E.b()));
                q0Var.a("androidx.lifecycle.viewmodel.internal.ViewModelCoroutineScope.JOB_KEY", aVar2);
                aVar = aVar2;
            }
        }
        return aVar;
    }

    public static C0809i k(p084ga.e eVar) {
        X9.j jVar = X9.j.f13659a;
        C0809i c0809i = new C0809i();
        z0 z0Var = new z0(null);
        Aa.e eVar2 = p230ta.M.f29486a;
        p239ua.e eVar3 = p282ya.n.f32793a.f30221f;
        eVar3.getClass();
        c0809i.f16495m = new D8.x(c0809i, eVar, p230ta.E.a(com.bumptech.glide.e.M(eVar3, jVar).m(z0Var)), new Ea.d(c0809i, 2));
        return c0809i;
    }

    public static final Object l(D d10, p084ga.e eVar, Z9.i iVar) {
        Object objF;
        EnumC0819t enumC0819t = EnumC0819t.f16524a;
        F fJ = d10.j();
        EnumC0819t enumC0819t2 = EnumC0819t.f16524a;
        EnumC0819t enumC0819t3 = fJ.f16395d;
        EnumC0819t enumC0819t4 = EnumC0819t.f16524a;
        T9.w wVar = T9.w.f11979a;
        if (enumC0819t3 == enumC0819t4 || (objF = p230ta.E.f(new c0(fJ, eVar, null), iVar)) != Y9.a.f14375a) {
            objF = wVar;
        }
        return objF == Y9.a.f14375a ? objF : wVar;
    }

    public static final void m(View view, D d10) {
        p097ha.k.f(view, "<this>");
        view.setTag(R.id.view_tree_lifecycle_owner, d10);
    }

    public static final void n(View view, x0 x0Var) {
        p097ha.k.f(view, "<this>");
        view.setTag(R.id.view_tree_view_model_store_owner, x0Var);
    }

    public static void o(F f10, p056e7.n nVar) {
        EnumC0819t enumC0819t = f10.f16395d;
        if (enumC0819t == EnumC0819t.f16525b || enumC0819t.compareTo(EnumC0819t.f16527d) >= 0) {
            nVar.G();
        } else {
            f10.a(new C0812l(f10, nVar));
        }
    }

    public static final Object p(F f10, EnumC0819t enumC0819t, p084ga.e eVar, Z9.i iVar) {
        Aa.e eVar2 = p230ta.M.f29486a;
        return p230ta.E.C(p282ya.n.f32793a.f30221f, new U(f10, enumC0819t, eVar, null), iVar);
    }
}
