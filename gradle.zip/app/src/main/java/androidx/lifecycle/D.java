package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface D {
    F j();
}
