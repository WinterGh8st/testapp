package androidx.lifecycle;

import N1.C0584u;

/* JADX INFO: loaded from: classes.dex */
public final class h0 implements B, AutoCloseable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final String f16492a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final g0 f16493b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16494c;

    public h0(String str, g0 g0Var) {
        this.f16492a = str;
        this.f16493b = g0Var;
    }

    @Override // java.lang.AutoCloseable
    public final void close() {
    }

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        if (enumC0818s == EnumC0818s.ON_DESTROY) {
            this.f16494c = false;
            d10.j().f(this);
        }
    }

    public final void e(F f10, p056e7.n nVar) {
        p097ha.k.f(nVar, "registry");
        p097ha.k.f(f10, "lifecycle");
        if (this.f16494c) {
            throw new IllegalStateException("Already attached to lifecycleOwner");
        }
        this.f16494c = true;
        f10.a(this);
        nVar.E(this.f16492a, (C0584u) this.f16493b.f16488b.f740f);
    }
}
