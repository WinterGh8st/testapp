package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.j, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0810j extends C {
    default void onDestroy(D d10) {
    }

    default void onStart(D d10) {
    }

    default void onStop(D d10) {
    }

    default void b(D d10) {
    }

    default void c(D d10) {
    }
}
