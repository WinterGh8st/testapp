package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface s0 {
    default q0 a(Class cls) {
        throw new UnsupportedOperationException("`Factory.create(String, CreationExtras)` is not implemented. You may need to override the method and provide a custom implementation. Note that using `Factory.create(String)` is not supported and considered an error.");
    }

    default q0 b(Class cls, S1.d dVar) {
        return a(cls);
    }

    default q0 d(p097ha.e eVar, S1.d dVar) {
        return b(G6.C.R(eVar), dVar);
    }
}
