package androidx.lifecycle;

import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public abstract class q0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final U1.d f16519a = new U1.d();

    public final void a(String str, AutoCloseable autoCloseable) {
        AutoCloseable autoCloseable2;
        U1.d dVar = this.f16519a;
        if (dVar != null) {
            if (dVar.f12313d) {
                U1.d.a(autoCloseable);
                return;
            }
            synchronized (dVar.f12310a) {
                autoCloseable2 = (AutoCloseable) dVar.f12311b.put(str, autoCloseable);
            }
            U1.d.a(autoCloseable2);
        }
    }

    public final void b() {
        U1.d dVar = this.f16519a;
        if (dVar != null && !dVar.f12313d) {
            dVar.f12313d = true;
            synchronized (dVar.f12310a) {
                try {
                    Iterator it = dVar.f12311b.values().iterator();
                    while (it.hasNext()) {
                        U1.d.a((AutoCloseable) it.next());
                    }
                    Iterator it2 = dVar.f12312c.iterator();
                    while (it2.hasNext()) {
                        U1.d.a((AutoCloseable) it2.next());
                    }
                    dVar.f12312c.clear();
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        d();
    }

    public final AutoCloseable c(String str) {
        AutoCloseable autoCloseable;
        U1.d dVar = this.f16519a;
        if (dVar == null) {
            return null;
        }
        synchronized (dVar.f12310a) {
            autoCloseable = (AutoCloseable) dVar.f12311b.get(str);
        }
        return autoCloseable;
    }

    public void d() {
    }
}
