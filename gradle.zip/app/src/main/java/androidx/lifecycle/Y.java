package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class Y extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16445a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f16446b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ p084ga.e f16447c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Y(p084ga.e eVar, X9.d dVar) {
        super(2, dVar);
        this.f16447c = eVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        Y y10 = new Y(this.f16447c, dVar);
        y10.f16446b = obj;
        return y10;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((Y) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16445a;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            p230ta.C c10 = (p230ta.C) this.f16446b;
            this.f16445a = 1;
            if (this.f16447c.invoke(c10, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        return T9.w.f11979a;
    }
}
