package androidx.lifecycle;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public abstract class d0 {
    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, EnumC0818s enumC0818s) {
        F fJ;
        p097ha.k.f(enumC0818s, "event");
        if (!(activity instanceof D) || (fJ = ((D) activity).j()) == null) {
            return;
        }
        fJ.d(enumC0818s);
    }

    public static void b(Activity activity) {
        if (Build.VERSION.SDK_INT >= 29) {
            f0.a.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new f0.a());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new f0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }
}
