package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class L extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16411a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ M f16412b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f16413c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(M m2, Object obj, X9.d dVar) {
        super(2, dVar);
        this.f16412b = m2;
        this.f16413c = obj;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new L(this.f16412b, this.f16413c, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((L) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16411a;
        T9.w wVar = T9.w.f11979a;
        M m2 = this.f16412b;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            C0809i c0809i = m2.f16414a;
            this.f16411a = 1;
            c0809i.l(this);
            if (wVar == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        m2.f16414a.k(this.f16413c);
        return wVar;
    }
}
