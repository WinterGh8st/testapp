package androidx.lifecycle;

import android.app.Activity;

/* JADX INFO: loaded from: classes.dex */
public abstract class V {
    public static final void a(Activity activity, W.a aVar) {
        activity.registerActivityLifecycleCallbacks(aVar);
    }
}
