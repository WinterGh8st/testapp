package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements p115j2.b {
    @Override // p115j2.b
    public final List a() {
        return U9.v.f12751a;
    }

    @Override // p115j2.b
    public final Object b(Context context) {
        p097ha.k.f(context, "context");
        p115j2.a aVarC = p115j2.a.c(context);
        p097ha.k.e(aVarC, "getInstance(...)");
        if (!aVarC.f23955b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml");
        }
        if (!A.f16389a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            p097ha.k.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new C0825z());
        }
        X x10 = X.f16436s;
        x10.getClass();
        x10.f16441e = new Handler();
        x10.f16442f.d(EnumC0818s.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        p097ha.k.d(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new W(x10));
        return x10;
    }
}
