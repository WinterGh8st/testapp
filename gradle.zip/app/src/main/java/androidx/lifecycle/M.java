package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class M {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0809i f16414a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final X9.i f16415b;

    public M(C0809i c0809i, X9.i iVar) {
        p097ha.k.f(iVar, "context");
        this.f16414a = c0809i;
        Aa.e eVar = p230ta.M.f29486a;
        this.f16415b = iVar.m(p282ya.n.f32793a.f30221f);
    }

    public final Object a(Object obj, Z9.i iVar) throws Throwable {
        Object objC = p230ta.E.C(this.f16415b, new L(this, obj, null), iVar);
        return objC == Y9.a.f14375a ? objC : T9.w.f11979a;
    }
}
