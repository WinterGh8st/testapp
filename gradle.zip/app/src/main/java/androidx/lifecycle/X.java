package androidx.lifecycle;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class X implements D {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final X f16436s = new X();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16437a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16438b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Handler f16441e;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f16439c = true;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16440d = true;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final F f16442f = new F(this);

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final B3.o f16443q = new B3.o(this, 12);

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final v0 f16444r = new v0(this);

    public final void c() {
        int i10 = this.f16438b + 1;
        this.f16438b = i10;
        if (i10 == 1) {
            if (this.f16439c) {
                this.f16442f.d(EnumC0818s.ON_RESUME);
                this.f16439c = false;
            } else {
                Handler handler = this.f16441e;
                p097ha.k.c(handler);
                handler.removeCallbacks(this.f16443q);
            }
        }
    }

    @Override // androidx.lifecycle.D
    public final F j() {
        return this.f16442f;
    }
}
