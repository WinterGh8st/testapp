package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class N implements Q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f16416a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p0 f16417b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16418c = -1;

    public N(P p10, p0 p0Var) {
        this.f16416a = p10;
        this.f16417b = p0Var;
    }

    @Override // androidx.lifecycle.Q
    public final void a(Object obj) {
        int i10 = this.f16418c;
        int i11 = this.f16416a.f16426g;
        if (i10 != i11) {
            this.f16418c = i11;
            this.f16417b.a(obj);
        }
    }

    public final void b() {
        this.f16416a.f(this);
    }
}
