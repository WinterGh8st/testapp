package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: renamed from: androidx.lifecycle.v, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0821v extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16535a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0824y f16536b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ A8.m f16537c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0821v(C0824y c0824y, A8.m mVar, X9.d dVar) {
        super(2, dVar);
        this.f16536b = c0824y;
        this.f16537c = mVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new C0821v(this.f16536b, this.f16537c, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((C0821v) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16535a;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            F f10 = this.f16536b.f16546a;
            this.f16535a = 1;
            if (j0.p(f10, EnumC0819t.f16528e, this.f16537c, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        return T9.w.f11979a;
    }
}
