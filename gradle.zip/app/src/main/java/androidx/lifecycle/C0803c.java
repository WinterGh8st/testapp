package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: renamed from: androidx.lifecycle.c, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0803c extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16469a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f16470b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ D8.x f16471c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0803c(D8.x xVar, X9.d dVar) {
        super(2, dVar);
        this.f16471c = xVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        C0803c c0803c = new C0803c(this.f16471c, dVar);
        c0803c.f16470b = obj;
        return c0803c;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((C0803c) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Type inference failed for: r6v5, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16469a;
        D8.x xVar = this.f16471c;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            M m2 = new M((C0809i) xVar.f2611b, ((p230ta.C) this.f16470b).g());
            ?? r7 = (Z9.i) xVar.f2612c;
            this.f16469a = 1;
            if (r7.invoke(m2, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        ((Ea.d) xVar.f2614e).m();
        return T9.w.f11979a;
    }
}
