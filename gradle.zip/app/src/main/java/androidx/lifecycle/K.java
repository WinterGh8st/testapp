package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public abstract class K {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Q f16407a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16408b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16409c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ P f16410d;

    public K(P p10, Q q10) {
        this.f16410d = p10;
        this.f16407a = q10;
    }

    public final void a(boolean z3) {
        if (z3 == this.f16408b) {
            return;
        }
        this.f16408b = z3;
        int i10 = z3 ? 1 : -1;
        P p10 = this.f16410d;
        int i11 = p10.f16422c;
        p10.f16422c = i10 + i11;
        if (!p10.f16423d) {
            p10.f16423d = true;
            while (true) {
                try {
                    int i12 = p10.f16422c;
                    if (i11 == i12) {
                        break;
                    }
                    boolean z5 = i11 == 0 && i12 > 0;
                    boolean z10 = i11 > 0 && i12 == 0;
                    if (z5) {
                        p10.g();
                    } else if (z10) {
                        p10.h();
                    }
                    i11 = i12;
                } catch (Throwable th) {
                    p10.f16423d = false;
                    throw th;
                }
            }
            p10.f16423d = false;
        }
        if (this.f16408b) {
            p10.c(this);
        }
    }

    public boolean f(D d10) {
        return false;
    }

    public abstract boolean g();

    public void e() {
    }
}
