package androidx.lifecycle;

import android.app.Application;

/* JADX INFO: renamed from: androidx.lifecycle.a, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public abstract class AbstractC0801a extends q0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Application f16453b;

    public AbstractC0801a(Application application) {
        p097ha.k.f(application, "application");
        this.f16453b = application;
    }

    public final Application e() {
        Application application = this.f16453b;
        p097ha.k.d(application, "null cannot be cast to non-null type T of androidx.lifecycle.AndroidViewModel.getApplication");
        return application;
    }
}
