package androidx.lifecycle;

import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class l0 extends q0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f16508b = new LinkedHashMap();
}
