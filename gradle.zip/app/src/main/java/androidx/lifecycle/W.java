package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public final class W extends AbstractC0813m {
    final /* synthetic */ X this$0;

    public static final class a extends AbstractC0813m {
        final /* synthetic */ X this$0;

        public a(X x10) {
            this.this$0 = x10;
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            p097ha.k.f(activity, "activity");
            this.this$0.c();
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            p097ha.k.f(activity, "activity");
            X x10 = this.this$0;
            int i10 = x10.f16437a + 1;
            x10.f16437a = i10;
            if (i10 == 1 && x10.f16440d) {
                x10.f16442f.d(EnumC0818s.ON_START);
                x10.f16440d = false;
            }
        }
    }

    public W(X x10) {
        this.this$0 = x10;
    }

    @Override // androidx.lifecycle.AbstractC0813m, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        p097ha.k.f(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i10 = f0.f16483b;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            p097ha.k.d(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((f0) fragmentFindFragmentByTag).f16484a = this.this$0.f16444r;
        }
    }

    @Override // androidx.lifecycle.AbstractC0813m, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        p097ha.k.f(activity, "activity");
        X x10 = this.this$0;
        int i10 = x10.f16438b - 1;
        x10.f16438b = i10;
        if (i10 == 0) {
            Handler handler = x10.f16441e;
            p097ha.k.c(handler);
            handler.postDelayed(x10.f16443q, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        p097ha.k.f(activity, "activity");
        V.a(activity, new a(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC0813m, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        p097ha.k.f(activity, "activity");
        X x10 = this.this$0;
        int i10 = x10.f16437a - 1;
        x10.f16437a = i10;
        if (i10 == 0 && x10.f16439c) {
            x10.f16442f.d(EnumC0818s.ON_STOP);
            x10.f16440d = true;
        }
    }
}
