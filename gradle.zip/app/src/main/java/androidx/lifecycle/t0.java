package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public class t0 implements s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static t0 f16530a;

    @Override // androidx.lifecycle.s0
    public q0 a(Class cls) {
        return com.bumptech.glide.e.w(cls);
    }

    @Override // androidx.lifecycle.s0
    public q0 b(Class cls, S1.d dVar) {
        return a(cls);
    }

    @Override // androidx.lifecycle.s0
    public final q0 d(p097ha.e eVar, S1.d dVar) {
        return b(G6.C.R(eVar), dVar);
    }
}
