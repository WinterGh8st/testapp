package androidx.lifecycle;

import java.util.ArrayList;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class g0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f16487a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final B0.l f16488b;

    public g0(V9.f fVar) {
        this.f16487a = new LinkedHashMap();
        this.f16488b = new B0.l(fVar);
    }

    public final Object a(String str) {
        Object value;
        B0.l lVar = this.f16488b;
        LinkedHashMap linkedHashMap = (LinkedHashMap) lVar.f736b;
        LinkedHashMap linkedHashMap2 = (LinkedHashMap) lVar.f739e;
        try {
            p259wa.F f10 = (p259wa.F) linkedHashMap2.get(str);
            if (f10 != null && (value = ((p259wa.a0) f10).getValue()) != null) {
                return value;
            }
            return linkedHashMap.get(str);
        } catch (ClassCastException unused) {
            linkedHashMap.remove(str);
            ((LinkedHashMap) lVar.f738d).remove(str);
            linkedHashMap2.remove(str);
            return null;
        }
    }

    public final p259wa.H b(Object obj, String str) {
        B0.l lVar = this.f16488b;
        boolean zContainsKey = ((LinkedHashMap) lVar.f739e).containsKey(str);
        LinkedHashMap linkedHashMap = (LinkedHashMap) lVar.f736b;
        if (zContainsKey) {
            LinkedHashMap linkedHashMap2 = (LinkedHashMap) lVar.f739e;
            Object objC = linkedHashMap2.get(str);
            if (objC == null) {
                if (!linkedHashMap.containsKey(str)) {
                    linkedHashMap.put(str, obj);
                }
                objC = p259wa.M.c(linkedHashMap.get(str));
                linkedHashMap2.put(str, objC);
            }
            return new p259wa.H((p259wa.F) objC);
        }
        LinkedHashMap linkedHashMap3 = (LinkedHashMap) lVar.f738d;
        Object objC2 = linkedHashMap3.get(str);
        if (objC2 == null) {
            if (!linkedHashMap.containsKey(str)) {
                linkedHashMap.put(str, obj);
            }
            objC2 = p259wa.M.c(linkedHashMap.get(str));
            linkedHashMap3.put(str, objC2);
        }
        return new p259wa.H((p259wa.F) objC2);
    }

    public final void c(Object obj, String str) {
        Object obj2;
        if (obj != null) {
            ArrayList arrayList = R1.a.f11029a;
            if (arrayList == null || !arrayList.isEmpty()) {
                int size = arrayList.size();
                int i10 = 0;
                do {
                    if (i10 < size) {
                        obj2 = arrayList.get(i10);
                        i10++;
                    }
                } while (!((Class) obj2).isInstance(obj));
            }
            throw new IllegalArgumentException(("Can't put value with type " + obj.getClass() + " into saved state").toString());
        }
        ArrayList arrayList2 = R1.a.f11029a;
        Object obj3 = this.f16487a.get(str);
        P p10 = obj3 instanceof P ? (P) obj3 : null;
        if (p10 != null) {
            p10.k(obj);
        }
        this.f16488b.t(obj, str);
    }

    public g0() {
        this.f16487a = new LinkedHashMap();
        this.f16488b = new B0.l(U9.w.f12752a);
    }
}
