package androidx.lifecycle;

import java.util.HashMap;
import java.util.List;

/* JADX INFO: renamed from: androidx.lifecycle.l, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0812l implements B {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f16505a = 2;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Object f16506b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Object f16507c;

    public C0812l(InterfaceC0810j interfaceC0810j, B b10) {
        p097ha.k.f(interfaceC0810j, "defaultLifecycleObserver");
        this.f16506b = interfaceC0810j;
        this.f16507c = b10;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        switch (this.f16505a) {
            case 0:
                int i10 = AbstractC0811k.f16500a[enumC0818s.ordinal()];
                InterfaceC0810j interfaceC0810j = (InterfaceC0810j) this.f16506b;
                switch (i10) {
                    case 1:
                        interfaceC0810j.getClass();
                        break;
                    case 2:
                        interfaceC0810j.onStart(d10);
                        break;
                    case 3:
                        interfaceC0810j.b(d10);
                        break;
                    case 4:
                        interfaceC0810j.getClass();
                        break;
                    case 5:
                        interfaceC0810j.onStop(d10);
                        break;
                    case 6:
                        interfaceC0810j.onDestroy(d10);
                        break;
                    case 7:
                        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
                    default:
                        throw new F9.U();
                }
                B b10 = (B) this.f16507c;
                if (b10 != null) {
                    b10.d(d10, enumC0818s);
                    return;
                }
                return;
            case 1:
                if (enumC0818s == EnumC0818s.ON_START) {
                    ((F) this.f16506b).f(this);
                    ((p056e7.n) this.f16507c).G();
                    return;
                }
                return;
            default:
                HashMap map = ((C0804d) this.f16507c).f16476a;
                List list = (List) map.get(enumC0818s);
                C c10 = (C) this.f16506b;
                C0804d.a(list, d10, enumC0818s, c10);
                C0804d.a((List) map.get(EnumC0818s.ON_ANY), d10, enumC0818s, c10);
                return;
        }
    }

    public C0812l(C c10) {
        this.f16506b = c10;
        C0806f c0806f = C0806f.f16480c;
        Class<?> cls = c10.getClass();
        C0804d c0804d = (C0804d) c0806f.f16481a.get(cls);
        this.f16507c = c0804d == null ? c0806f.a(cls, null) : c0804d;
    }

    public C0812l(F f10, p056e7.n nVar) {
        this.f16506b = f10;
        this.f16507c = nVar;
    }
}
