package androidx.lifecycle;

import java.util.ArrayDeque;
import p230ta.AbstractC1659y;

/* JADX INFO: loaded from: classes.dex */
public final class T extends AbstractC1659y {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final V4.H f16430c = new V4.H();

    @Override // p230ta.AbstractC1659y
    public final void t(X9.i iVar, Runnable runnable) {
        p097ha.k.f(iVar, "context");
        p097ha.k.f(runnable, "block");
        V4.H h10 = this.f16430c;
        h10.getClass();
        Aa.e eVar = p230ta.M.f29486a;
        p239ua.e eVar2 = p282ya.n.f32793a.f30221f;
        if (!eVar2.v(iVar)) {
            if (!(h10.f12910b || !h10.f12909a)) {
                if (!((ArrayDeque) h10.f12912d).offer(runnable)) {
                    throw new IllegalStateException("cannot enqueue any more runnables");
                }
                h10.a();
                return;
            }
        }
        eVar2.t(iVar, new B3.e(14, h10, runnable));
    }

    @Override // p230ta.AbstractC1659y
    public final boolean v(X9.i iVar) {
        p097ha.k.f(iVar, "context");
        Aa.e eVar = p230ta.M.f29486a;
        if (p282ya.n.f32793a.f30221f.v(iVar)) {
            return true;
        }
        V4.H h10 = this.f16430c;
        return !(h10.f12910b || !h10.f12909a);
    }
}
