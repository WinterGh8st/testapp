package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.y, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0824y implements B, p230ta.C {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final F f16546a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final X9.i f16547b;

    public C0824y(F f10, X9.i iVar) {
        p097ha.k.f(iVar, "coroutineContext");
        this.f16546a = f10;
        this.f16547b = iVar;
        if (f10.f16395d == EnumC0819t.f16524a) {
            p230ta.E.d(iVar, null);
        }
    }

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0818s enumC0818s) {
        F f10 = this.f16546a;
        if (f10.f16395d.compareTo(EnumC0819t.f16524a) <= 0) {
            f10.f(this);
            p230ta.E.d(this.f16547b, null);
        }
    }

    @Override // p230ta.C
    public final X9.i g() {
        return this.f16547b;
    }
}
