package androidx.lifecycle;

import java.lang.reflect.Method;

/* JADX INFO: renamed from: androidx.lifecycle.e, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0805e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f16478a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Method f16479b;

    public C0805e(int i10, Method method) {
        this.f16478a = i10;
        this.f16479b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0805e)) {
            return false;
        }
        C0805e c0805e = (C0805e) obj;
        return this.f16478a == c0805e.f16478a && this.f16479b.getName().equals(c0805e.f16479b.getName());
    }

    public final int hashCode() {
        return this.f16479b.getName().hashCode() + (this.f16478a * 31);
    }
}
