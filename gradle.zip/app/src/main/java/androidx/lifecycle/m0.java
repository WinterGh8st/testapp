package androidx.lifecycle;

import Y1.C0794i;
import android.app.Application;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class m0 extends u0 implements s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Application f16509a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final r0 f16510b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Bundle f16511c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final F f16512d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final p056e7.n f16513e;

    public m0(Application application, p076g2.e eVar, Bundle bundle) {
        r0 r0Var;
        p097ha.k.f(eVar, "owner");
        this.f16513e = eVar.b();
        this.f16512d = eVar.j();
        this.f16511c = bundle;
        this.f16509a = application;
        if (application != null) {
            if (r0.f16521c == null) {
                r0.f16521c = new r0(application);
            }
            r0Var = r0.f16521c;
            p097ha.k.c(r0Var);
        } else {
            r0Var = new r0(null);
        }
        this.f16510b = r0Var;
    }

    @Override // androidx.lifecycle.s0
    public final q0 a(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return e(cls, canonicalName);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Override // androidx.lifecycle.s0
    public final q0 b(Class cls, S1.d dVar) {
        C0794i c0794i = v0.f16538b;
        LinkedHashMap linkedHashMap = dVar.f11266a;
        String str = (String) linkedHashMap.get(c0794i);
        if (str == null) {
            throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
        }
        if (linkedHashMap.get(j0.f16496a) == null || linkedHashMap.get(j0.f16497b) == null) {
            if (this.f16512d != null) {
                return e(cls, str);
            }
            throw new IllegalStateException("SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel.");
        }
        Application application = (Application) linkedHashMap.get(r0.f16522d);
        boolean zIsAssignableFrom = AbstractC0801a.class.isAssignableFrom(cls);
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? n0.a(cls, n0.f16515b) : n0.a(cls, n0.f16514a);
        if (constructorA == null) {
            return this.f16510b.b(cls, dVar);
        }
        return (!zIsAssignableFrom || application == null) ? n0.b(cls, constructorA, j0.c(dVar)) : n0.b(cls, constructorA, application, j0.c(dVar));
    }

    @Override // androidx.lifecycle.u0
    public final void c(q0 q0Var) {
        F f10 = this.f16512d;
        if (f10 != null) {
            p056e7.n nVar = this.f16513e;
            p097ha.k.c(nVar);
            j0.a(q0Var, nVar, f10);
        }
    }

    @Override // androidx.lifecycle.s0
    public final q0 d(p097ha.e eVar, S1.d dVar) {
        return b(G6.C.R(eVar), dVar);
    }

    public final q0 e(Class cls, String str) {
        F f10 = this.f16512d;
        if (f10 == null) {
            throw new UnsupportedOperationException("SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
        }
        boolean zIsAssignableFrom = AbstractC0801a.class.isAssignableFrom(cls);
        Application application = this.f16509a;
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? n0.a(cls, n0.f16515b) : n0.a(cls, n0.f16514a);
        if (constructorA == null) {
            if (application != null) {
                return this.f16510b.a(cls);
            }
            if (t0.f16530a == null) {
                t0.f16530a = new t0();
            }
            p097ha.k.c(t0.f16530a);
            return com.bumptech.glide.e.w(cls);
        }
        p056e7.n nVar = this.f16513e;
        p097ha.k.c(nVar);
        h0 h0VarB = j0.b(nVar, f10, str, this.f16511c);
        g0 g0Var = h0VarB.f16493b;
        q0 q0VarB = (!zIsAssignableFrom || application == null) ? n0.b(cls, constructorA, g0Var) : n0.b(cls, constructorA, application, g0Var);
        q0VarB.a("androidx.lifecycle.savedstate.vm.tag", h0VarB);
        return q0VarB;
    }
}
