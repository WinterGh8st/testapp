package androidx.lifecycle;

import L.AbstractC0492c;
import android.os.Looper;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class P {
    public static final Object k = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Object f16420a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final p198r.f f16421b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16422c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16423d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public volatile Object f16424e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public volatile Object f16425f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16426g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f16427h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public boolean f16428i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final H f16429j;

    public P(Object obj) {
        this.f16420a = new Object();
        this.f16421b = new p198r.f();
        this.f16422c = 0;
        this.f16425f = k;
        this.f16429j = new H(this);
        this.f16424e = obj;
        this.f16426g = 0;
    }

    public static void a(String str) {
        p187q.a.p0().f27438b.getClass();
        if (Looper.getMainLooper().getThread() != Thread.currentThread()) {
            throw new IllegalStateException(AbstractC0492c.l("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(K k3) {
        if (k3.f16408b) {
            if (!k3.g()) {
                k3.a(false);
                return;
            }
            int i10 = k3.f16409c;
            int i11 = this.f16426g;
            if (i10 >= i11) {
                return;
            }
            k3.f16409c = i11;
            k3.f16407a.a(this.f16424e);
        }
    }

    public final void c(K k3) {
        if (this.f16427h) {
            this.f16428i = true;
            return;
        }
        this.f16427h = true;
        do {
            this.f16428i = false;
            if (k3 != null) {
                b(k3);
                k3 = null;
            } else {
                p198r.f fVar = this.f16421b;
                fVar.getClass();
                p198r.d dVar = new p198r.d(fVar);
                fVar.f27559c.put(dVar, Boolean.FALSE);
                while (dVar.hasNext()) {
                    b((K) ((Map.Entry) dVar.next()).getValue());
                    if (this.f16428i) {
                        break;
                    }
                }
            }
        } while (this.f16428i);
        this.f16427h = false;
    }

    public final Object d() {
        Object obj = this.f16424e;
        if (obj != k) {
            return obj;
        }
        return null;
    }

    public final void e(D d10, Q q10) {
        Object obj;
        a("observe");
        if (d10.j().f16395d == EnumC0819t.f16524a) {
            return;
        }
        J j10 = new J(this, d10, q10);
        p198r.f fVar = this.f16421b;
        p198r.c cVarA = fVar.a(q10);
        if (cVarA != null) {
            obj = cVarA.f27551b;
        } else {
            p198r.c cVar = new p198r.c(q10, j10);
            fVar.f27560d++;
            p198r.c cVar2 = fVar.f27558b;
            if (cVar2 == null) {
                fVar.f27557a = cVar;
                fVar.f27558b = cVar;
            } else {
                cVar2.f27552c = cVar;
                cVar.f27553d = cVar2;
                fVar.f27558b = cVar;
            }
            obj = null;
        }
        K k3 = (K) obj;
        if (k3 != null && !k3.f(d10)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (k3 != null) {
            return;
        }
        d10.j().a(j10);
    }

    public final void f(Q q10) {
        Object obj;
        a("observeForever");
        I i10 = new I(this, q10);
        p198r.f fVar = this.f16421b;
        p198r.c cVarA = fVar.a(q10);
        if (cVarA != null) {
            obj = cVarA.f27551b;
        } else {
            p198r.c cVar = new p198r.c(q10, i10);
            fVar.f27560d++;
            p198r.c cVar2 = fVar.f27558b;
            if (cVar2 == null) {
                fVar.f27557a = cVar;
                fVar.f27558b = cVar;
            } else {
                cVar2.f27552c = cVar;
                cVar.f27553d = cVar2;
                fVar.f27558b = cVar;
            }
            obj = null;
        }
        K k3 = (K) obj;
        if (k3 instanceof J) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (k3 != null) {
            return;
        }
        i10.a(true);
    }

    public final void i(Object obj) {
        boolean z3;
        synchronized (this.f16420a) {
            z3 = this.f16425f == k;
            this.f16425f = obj;
        }
        if (z3) {
            p187q.a aVarP0 = p187q.a.p0();
            H h10 = this.f16429j;
            p187q.b bVar = aVarP0.f27438b;
            if (bVar.f27441d == null) {
                synchronized (bVar.f27439b) {
                    try {
                        if (bVar.f27441d == null) {
                            bVar.f27441d = p187q.b.p0(Looper.getMainLooper());
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }
            bVar.f27441d.post(h10);
        }
    }

    public void j(Q q10) {
        a("removeObserver");
        K k3 = (K) this.f16421b.b(q10);
        if (k3 == null) {
            return;
        }
        k3.e();
        k3.a(false);
    }

    public void k(Object obj) {
        a("setValue");
        this.f16426g++;
        this.f16424e = obj;
        c(null);
    }

    public P() {
        this.f16420a = new Object();
        this.f16421b = new p198r.f();
        this.f16422c = 0;
        Object obj = k;
        this.f16425f = obj;
        this.f16429j = new H(this);
        this.f16424e = obj;
        this.f16426g = -1;
    }

    public void g() {
    }

    public void h() {
    }
}
