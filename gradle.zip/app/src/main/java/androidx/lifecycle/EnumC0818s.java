package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.s, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0818s {
    private static final /* synthetic */ p011aa.a $ENTRIES;
    private static final /* synthetic */ EnumC0818s[] $VALUES;
    public static final C0817q Companion;
    public static final EnumC0818s ON_ANY;
    public static final EnumC0818s ON_CREATE;
    public static final EnumC0818s ON_DESTROY;
    public static final EnumC0818s ON_PAUSE;
    public static final EnumC0818s ON_RESUME;
    public static final EnumC0818s ON_START;
    public static final EnumC0818s ON_STOP;

    static {
        EnumC0818s enumC0818s = new EnumC0818s("ON_CREATE", 0);
        ON_CREATE = enumC0818s;
        EnumC0818s enumC0818s2 = new EnumC0818s("ON_START", 1);
        ON_START = enumC0818s2;
        EnumC0818s enumC0818s3 = new EnumC0818s("ON_RESUME", 2);
        ON_RESUME = enumC0818s3;
        EnumC0818s enumC0818s4 = new EnumC0818s("ON_PAUSE", 3);
        ON_PAUSE = enumC0818s4;
        EnumC0818s enumC0818s5 = new EnumC0818s("ON_STOP", 4);
        ON_STOP = enumC0818s5;
        EnumC0818s enumC0818s6 = new EnumC0818s("ON_DESTROY", 5);
        ON_DESTROY = enumC0818s6;
        EnumC0818s enumC0818s7 = new EnumC0818s("ON_ANY", 6);
        ON_ANY = enumC0818s7;
        EnumC0818s[] enumC0818sArr = {enumC0818s, enumC0818s2, enumC0818s3, enumC0818s4, enumC0818s5, enumC0818s6, enumC0818s7};
        $VALUES = enumC0818sArr;
        $ENTRIES = p054e4.e.Y(enumC0818sArr);
        Companion = new C0817q();
    }

    public static EnumC0818s valueOf(String str) {
        return (EnumC0818s) Enum.valueOf(EnumC0818s.class, str);
    }

    public static EnumC0818s[] values() {
        return (EnumC0818s[]) $VALUES.clone();
    }

    public final EnumC0819t a() {
        switch (r.f16520a[ordinal()]) {
            case 1:
            case 2:
                return EnumC0819t.f16526c;
            case 3:
            case 4:
                return EnumC0819t.f16527d;
            case 5:
                return EnumC0819t.f16528e;
            case 6:
                return EnumC0819t.f16524a;
            case 7:
                throw new IllegalArgumentException(this + " has no target state");
            default:
                throw new F9.U();
        }
    }
}
