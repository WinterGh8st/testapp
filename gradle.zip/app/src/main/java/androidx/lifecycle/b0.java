package androidx.lifecycle;

import p016b3.AbstractC0862l;
import p230ta.C1647l;
import p230ta.InterfaceC1640h0;

/* JADX INFO: loaded from: classes.dex */
public final class b0 extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public p097ha.u f16463a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public p097ha.u f16464b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16465c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ F f16466d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ p230ta.C f16467e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ Z9.i f16468f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public b0(F f10, p230ta.C c10, p084ga.e eVar, X9.d dVar) {
        super(2, dVar);
        EnumC0819t enumC0819t = EnumC0819t.f16524a;
        this.f16466d = f10;
        this.f16467e = c10;
        this.f16468f = (Z9.i) eVar;
    }

    /* JADX WARN: Type inference failed for: r0v0, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        ?? r7 = this.f16468f;
        EnumC0819t enumC0819t = EnumC0819t.f16524a;
        return new b0(this.f16466d, this.f16467e, r7, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((b0) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0073  */
    /* JADX WARN: Code duplicated, block: B:25:0x007c  */
    /* JADX WARN: Code duplicated, block: B:31:0x0089  */
    /* JADX WARN: Code duplicated, block: B:34:0x0092  */
    /* JADX WARN: Code duplicated, block: B:40:? A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r13v0, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        p097ha.u uVar;
        Throwable th;
        p097ha.u uVar2;
        InterfaceC1640h0 interfaceC1640h0;
        B b10;
        InterfaceC1640h0 interfaceC1640h1;
        B b11;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16465c;
        T9.w wVar = T9.w.f11979a;
        F f10 = this.f16466d;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            if (f10.f16395d != EnumC0819t.f16524a) {
                p097ha.u uVar3 = new p097ha.u();
                uVar = new p097ha.u();
                try {
                    EnumC0819t enumC0819t = EnumC0819t.f16527d;
                    p230ta.C c10 = this.f16467e;
                    ?? r13 = this.f16468f;
                    this.f16463a = uVar3;
                    this.f16464b = uVar;
                    this.f16465c = 1;
                    C1647l c1647l = new C1647l(1, p168o5.b.T(this));
                    c1647l.q();
                    EnumC0818s.Companion.getClass();
                    a0 a0Var = new a0(EnumC0818s.ON_START, uVar3, c10, EnumC0818s.ON_STOP, c1647l, new Ca.d(), r13);
                    uVar.f23278a = a0Var;
                    f10.a(a0Var);
                    if (c1647l.p() == aVar) {
                        return aVar;
                    }
                    uVar2 = uVar3;
                    interfaceC1640h1 = (InterfaceC1640h0) uVar2.f23278a;
                    if (interfaceC1640h1 != null) {
                        interfaceC1640h1.c(null);
                    }
                    b11 = (B) uVar.f23278a;
                    if (b11 != null) {
                        f10.f(b11);
                    }
                } catch (Throwable th2) {
                    th = th2;
                    uVar2 = uVar3;
                    interfaceC1640h0 = (InterfaceC1640h0) uVar2.f23278a;
                    if (interfaceC1640h0 != null) {
                        interfaceC1640h0.c(null);
                    }
                    b10 = (B) uVar.f23278a;
                    if (b10 != null) {
                        throw th;
                    }
                    f10.f(b10);
                    throw th;
                }
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            uVar = this.f16464b;
            uVar2 = this.f16463a;
            try {
                AbstractC0862l.m0(obj);
                interfaceC1640h1 = (InterfaceC1640h0) uVar2.f23278a;
                if (interfaceC1640h1 != null) {
                    interfaceC1640h1.c(null);
                }
                b11 = (B) uVar.f23278a;
                if (b11 != null) {
                    f10.f(b11);
                }
            } catch (Throwable th3) {
                th = th3;
                interfaceC1640h0 = (InterfaceC1640h0) uVar2.f23278a;
                if (interfaceC1640h0 != null) {
                    interfaceC1640h0.c(null);
                }
                b10 = (B) uVar.f23278a;
                if (b10 != null) {
                    throw th;
                }
                f10.f(b10);
                throw th;
            }
        }
        return wVar;
    }
}
