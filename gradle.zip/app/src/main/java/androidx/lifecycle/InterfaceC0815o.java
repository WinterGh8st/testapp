package androidx.lifecycle;

/* JADX INFO: renamed from: androidx.lifecycle.o, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public interface InterfaceC0815o {
    s0 d();

    S1.d e();
}
