package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: renamed from: androidx.lifecycle.d, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0804d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final HashMap f16476a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final HashMap f16477b;

    public C0804d(HashMap map) {
        this.f16477b = map;
        for (Map.Entry entry : map.entrySet()) {
            EnumC0818s enumC0818s = (EnumC0818s) entry.getValue();
            List arrayList = (List) this.f16476a.get(enumC0818s);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f16476a.put(enumC0818s, arrayList);
            }
            arrayList.add((C0805e) entry.getKey());
        }
    }

    public static void a(List list, D d10, EnumC0818s enumC0818s, C c10) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                C0805e c0805e = (C0805e) list.get(size);
                c0805e.getClass();
                try {
                    int i10 = c0805e.f16478a;
                    Method method = c0805e.f16479b;
                    if (i10 == 0) {
                        method.invoke(c10, null);
                    } else if (i10 == 1) {
                        method.invoke(c10, d10);
                    } else if (i10 == 2) {
                        method.invoke(c10, d10, enumC0818s);
                    }
                } catch (IllegalAccessException e10) {
                    throw new RuntimeException(e10);
                } catch (InvocationTargetException e11) {
                    throw new RuntimeException("Failed to call observer method", e11.getCause());
                }
            }
        }
    }
}
