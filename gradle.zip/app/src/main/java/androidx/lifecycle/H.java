package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class H implements Runnable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ P f16404a;

    public H(P p10) {
        this.f16404a = p10;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        synchronized (this.f16404a.f16420a) {
            obj = this.f16404a.f16425f;
            this.f16404a.f16425f = P.k;
        }
        this.f16404a.k(obj);
    }
}
