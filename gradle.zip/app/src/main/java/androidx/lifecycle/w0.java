package androidx.lifecycle;

import java.util.Iterator;
import java.util.LinkedHashMap;

/* JADX INFO: loaded from: classes.dex */
public final class w0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f16543a = new LinkedHashMap();

    public final void a() {
        LinkedHashMap linkedHashMap = this.f16543a;
        Iterator it = linkedHashMap.values().iterator();
        while (it.hasNext()) {
            ((q0) it.next()).b();
        }
        linkedHashMap.clear();
    }
}
