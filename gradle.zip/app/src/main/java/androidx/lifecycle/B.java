package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface B extends C {
    void d(D d10, EnumC0818s enumC0818s);
}
