package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;

/* JADX INFO: renamed from: androidx.lifecycle.z, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0825z extends AbstractC0813m {
    @Override // androidx.lifecycle.AbstractC0813m, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        p097ha.k.f(activity, "activity");
        int i10 = f0.f16483b;
        d0.b(activity);
    }
}
