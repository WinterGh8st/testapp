package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;

/* JADX INFO: loaded from: classes.dex */
public final class r0 extends t0 {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static r0 f16521c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final Y0.F f16522d = new Y0.F(3);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Application f16523b;

    public r0(Application application) {
        this.f16523b = application;
    }

    @Override // androidx.lifecycle.t0, androidx.lifecycle.s0
    public final q0 a(Class cls) {
        Application application = this.f16523b;
        if (application != null) {
            return c(cls, application);
        }
        throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
    }

    @Override // androidx.lifecycle.t0, androidx.lifecycle.s0
    public final q0 b(Class cls, S1.d dVar) {
        if (this.f16523b != null) {
            return a(cls);
        }
        Application application = (Application) dVar.f11266a.get(f16522d);
        if (application != null) {
            return c(cls, application);
        }
        if (AbstractC0801a.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
        }
        return com.bumptech.glide.e.w(cls);
    }

    public final q0 c(Class cls, Application application) {
        if (!AbstractC0801a.class.isAssignableFrom(cls)) {
            return com.bumptech.glide.e.w(cls);
        }
        try {
            q0 q0Var = (q0) cls.getConstructor(Application.class).newInstance(application);
            p097ha.k.c(q0Var);
            return q0Var;
        } catch (IllegalAccessException e10) {
            throw new RuntimeException("Cannot create an instance of " + cls, e10);
        } catch (InstantiationException e11) {
            throw new RuntimeException("Cannot create an instance of " + cls, e11);
        } catch (NoSuchMethodException e12) {
            throw new RuntimeException("Cannot create an instance of " + cls, e12);
        } catch (InvocationTargetException e13) {
            throw new RuntimeException("Cannot create an instance of " + cls, e13);
        }
    }
}
