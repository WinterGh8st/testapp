package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public abstract class n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final List f16514a = U9.o.k0(Application.class, g0.class);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final List f16515b = G6.C.W(g0.class);

    public static final Constructor a(Class cls, List list) {
        p097ha.k.f(list, "signature");
        Ga.i iVarI = p097ha.k.i(cls.getConstructors());
        while (iVarI.hasNext()) {
            Constructor constructor = (Constructor) iVarI.next();
            Class<?>[] parameterTypes = constructor.getParameterTypes();
            p097ha.k.e(parameterTypes, "getParameterTypes(...)");
            List listK0 = U9.l.k0(parameterTypes);
            if (list.equals(listK0)) {
                return constructor;
            }
            if (list.size() == listK0.size() && listK0.containsAll(list)) {
                throw new UnsupportedOperationException("Class " + cls.getSimpleName() + " must have parameters in the proper order: " + list);
            }
        }
        return null;
    }

    public static final q0 b(Class cls, Constructor constructor, Object... objArr) {
        try {
            return (q0) constructor.newInstance(Arrays.copyOf(objArr, objArr.length));
        } catch (IllegalAccessException e10) {
            throw new RuntimeException("Failed to access " + cls, e10);
        } catch (InstantiationException e11) {
            throw new RuntimeException("A " + cls + " cannot be instantiated.", e11);
        } catch (InvocationTargetException e12) {
            throw new RuntimeException("An exception happened in constructor of " + cls, e12.getCause());
        }
    }
}
