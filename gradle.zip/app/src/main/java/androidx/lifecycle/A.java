package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: loaded from: classes.dex */
public abstract class A {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f16389a = new AtomicBoolean(false);
}
