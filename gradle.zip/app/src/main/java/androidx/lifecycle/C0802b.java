package androidx.lifecycle;

import p016b3.AbstractC0862l;
import p230ta.y0;

/* JADX INFO: renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0802b extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16461a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ D8.x f16462b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0802b(D8.x xVar, X9.d dVar) {
        super(2, dVar);
        this.f16462b = xVar;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new C0802b(this.f16462b, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((C0802b) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16461a;
        D8.x xVar = this.f16462b;
        if (i10 == 0) {
            AbstractC0862l.m0(obj);
            xVar.getClass();
            this.f16461a = 1;
            if (p230ta.E.g(5000L, this) == aVar) {
                return aVar;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
        if (((C0809i) xVar.f2611b).f16422c <= 0) {
            y0 y0Var = (y0) xVar.f2615f;
            if (y0Var != null) {
                y0Var.c(null);
            }
            xVar.f2615f = null;
        }
        return T9.w.f11979a;
    }
}
