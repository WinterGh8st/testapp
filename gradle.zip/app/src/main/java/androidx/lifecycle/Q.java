package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public interface Q {
    void a(Object obj);
}
