package androidx.lifecycle;

import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class Z extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Ca.a f16448a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Z9.i f16449b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16450c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Ca.d f16451d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Z9.i f16452e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public Z(Ca.d dVar, p084ga.e eVar, X9.d dVar2) {
        super(2, dVar2);
        this.f16451d = dVar;
        this.f16452e = (Z9.i) eVar;
    }

    /* JADX WARN: Type inference failed for: r1v0, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new Z(this.f16451d, this.f16452e, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((Z) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v2, types: [ga.e] */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v7 */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Ca.d dVar;
        Z9.i iVar;
        Ca.a aVar;
        ?? r7;
        Ca.a aVar2;
        Throwable th;
        Ca.a aVar3;
        Y9.a aVar4 = Y9.a.f14375a;
        int i10 = this.f16450c;
        try {
            if (i10 == 0) {
                AbstractC0862l.m0(obj);
                dVar = this.f16451d;
                this.f16448a = dVar;
                iVar = this.f16452e;
                this.f16449b = iVar;
                this.f16450c = 1;
                if (dVar.c(this) != aVar4) {
                }
                r7 = iVar;
                aVar = dVar;
                return aVar4;
            }
            if (i10 != 1) {
                if (i10 != 2) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                aVar2 = this.f16448a;
                try {
                    AbstractC0862l.m0(obj);
                    aVar3 = aVar2;
                    ((Ca.d) aVar3).d(null);
                    return T9.w.f11979a;
                } catch (Throwable th2) {
                    th = th2;
                    ((Ca.d) aVar2).d(null);
                    throw th;
                }
            }
            p084ga.e eVar = (p084ga.e) this.f16449b;
            Ca.a aVar5 = this.f16448a;
            AbstractC0862l.m0(obj);
            aVar = aVar5;
            r7 = eVar;
            r7 = iVar;
            aVar = dVar;
            Y y10 = new Y(r7, null);
            this.f16448a = aVar;
            this.f16449b = null;
            this.f16450c = 2;
            if (p230ta.E.f(y10, this) != aVar4) {
                aVar3 = aVar;
                ((Ca.d) aVar3).d(null);
                return T9.w.f11979a;
            }
            r7 = iVar;
            aVar = dVar;
            return aVar4;
        } catch (Throwable th3) {
            aVar2 = aVar;
            th = th3;
            ((Ca.d) aVar2).d(null);
            throw th;
        }
    }
}
