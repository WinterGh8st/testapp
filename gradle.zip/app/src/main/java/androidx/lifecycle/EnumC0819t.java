package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: renamed from: androidx.lifecycle.t, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class EnumC0819t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final EnumC0819t f16524a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final EnumC0819t f16525b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final EnumC0819t f16526c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final EnumC0819t f16527d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final EnumC0819t f16528e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ EnumC0819t[] f16529f;

    static {
        EnumC0819t enumC0819t = new EnumC0819t("DESTROYED", 0);
        f16524a = enumC0819t;
        EnumC0819t enumC0819t2 = new EnumC0819t("INITIALIZED", 1);
        f16525b = enumC0819t2;
        EnumC0819t enumC0819t3 = new EnumC0819t("CREATED", 2);
        f16526c = enumC0819t3;
        EnumC0819t enumC0819t4 = new EnumC0819t("STARTED", 3);
        f16527d = enumC0819t4;
        EnumC0819t enumC0819t5 = new EnumC0819t("RESUMED", 4);
        f16528e = enumC0819t5;
        EnumC0819t[] enumC0819tArr = {enumC0819t, enumC0819t2, enumC0819t3, enumC0819t4, enumC0819t5};
        f16529f = enumC0819tArr;
        p054e4.e.Y(enumC0819tArr);
    }

    public static EnumC0819t valueOf(String str) {
        return (EnumC0819t) Enum.valueOf(EnumC0819t.class, str);
    }

    public static EnumC0819t[] values() {
        return (EnumC0819t[]) f16529f.clone();
    }
}
