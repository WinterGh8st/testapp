package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class p0 implements Q, p097ha.g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ o0 f16518a;

    public p0(o0 o0Var) {
        this.f16518a = o0Var;
    }

    @Override // androidx.lifecycle.Q
    public final /* synthetic */ void a(Object obj) {
        this.f16518a.invoke(obj);
    }

    @Override // p097ha.g
    public final T9.c b() {
        return this.f16518a;
    }

    public final boolean equals(Object obj) {
        if ((obj instanceof Q) && (obj instanceof p097ha.g)) {
            return this.f16518a.equals(((p097ha.g) obj).b());
        }
        return false;
    }

    public final int hashCode() {
        return this.f16518a.hashCode();
    }
}
