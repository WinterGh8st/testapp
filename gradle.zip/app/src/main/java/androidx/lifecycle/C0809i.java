package androidx.lifecycle;

import p016b3.AbstractC0862l;
import p230ta.y0;

/* JADX INFO: renamed from: androidx.lifecycle.i, reason: case insensitive filesystem */
/* JADX INFO: loaded from: classes.dex */
public final class C0809i extends O {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public D8.x f16495m;

    @Override // androidx.lifecycle.O, androidx.lifecycle.P
    public final void g() {
        super.g();
        D8.x xVar = this.f16495m;
        if (xVar != null) {
            y0 y0Var = (y0) xVar.f2616q;
            if (y0Var != null) {
                y0Var.c(null);
            }
            xVar.f2616q = null;
            if (((y0) xVar.f2615f) != null) {
                return;
            }
            xVar.f2615f = p230ta.E.t((p282ya.e) xVar.f2613d, null, new C0803c(xVar, null), 3);
        }
    }

    @Override // androidx.lifecycle.O, androidx.lifecycle.P
    public final void h() {
        super.h();
        D8.x xVar = this.f16495m;
        if (xVar != null) {
            if (((y0) xVar.f2616q) != null) {
                throw new IllegalStateException("Cancel call cannot happen without a maybeRun");
            }
            Aa.e eVar = p230ta.M.f29486a;
            xVar.f2616q = p230ta.E.t((p282ya.e) xVar.f2613d, p282ya.n.f32793a.f30221f, new C0802b(xVar, null), 2);
        }
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    public final void l(Z9.c cVar) {
        C0808h c0808h;
        if (cVar instanceof C0808h) {
            c0808h = (C0808h) cVar;
            int i10 = c0808h.f16491c;
            if ((i10 & Integer.MIN_VALUE) != 0) {
                c0808h.f16491c = i10 - Integer.MIN_VALUE;
            } else {
                c0808h = new C0808h(this, cVar);
            }
        } else {
            c0808h = new C0808h(this, cVar);
        }
        Object obj = c0808h.f16489a;
        Y9.a aVar = Y9.a.f14375a;
        int i11 = c0808h.f16491c;
        if (i11 == 0) {
            AbstractC0862l.m0(obj);
        } else {
            if (i11 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
        }
    }
}
