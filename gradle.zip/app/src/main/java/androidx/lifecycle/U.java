package androidx.lifecycle;

import p016b3.AbstractC0862l;
import p230ta.C1660z;
import p230ta.InterfaceC1640h0;

/* JADX INFO: loaded from: classes.dex */
public final class U extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16431a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f16432b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ F f16433c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final /* synthetic */ EnumC0819t f16434d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Z9.i f16435e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public U(F f10, EnumC0819t enumC0819t, p084ga.e eVar, X9.d dVar) {
        super(2, dVar);
        this.f16433c = f10;
        this.f16434d = enumC0819t;
        this.f16435e = (Z9.i) eVar;
    }

    /* JADX WARN: Type inference failed for: r2v0, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        U u5 = new U(this.f16433c, this.f16434d, this.f16435e, dVar);
        u5.f16432b = obj;
        return u5;
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((U) create((p230ta.C) obj, (X9.d) obj2)).invokeSuspend(T9.w.f11979a);
    }

    /* JADX WARN: Type inference failed for: r8v8, types: [Z9.i, ga.e] */
    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        C0820u c0820u;
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f16431a;
        if (i10 != 0) {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            c0820u = (C0820u) this.f16432b;
            try {
                AbstractC0862l.m0(obj);
                c0820u.a();
                return obj;
            } catch (Throwable th) {
                th = th;
                c0820u.a();
                throw th;
            }
        }
        AbstractC0862l.m0(obj);
        InterfaceC1640h0 interfaceC1640h0 = (InterfaceC1640h0) ((p230ta.C) this.f16432b).g().i(C1660z.f29578b);
        if (interfaceC1640h0 == null) {
            throw new IllegalStateException("when[State] methods should have a parent job");
        }
        T t10 = new T();
        C0820u c0820u2 = new C0820u(this.f16433c, this.f16434d, t10.f16430c, interfaceC1640h0);
        try {
            ?? r10 = this.f16435e;
            this.f16432b = c0820u2;
            this.f16431a = 1;
            obj = p230ta.E.C(t10, r10, this);
            if (obj == aVar) {
                return aVar;
            }
            c0820u = c0820u2;
            c0820u.a();
            return obj;
        } catch (Throwable th2) {
            th = th2;
            c0820u = c0820u2;
            c0820u.a();
            throw th;
        }
    }
}
