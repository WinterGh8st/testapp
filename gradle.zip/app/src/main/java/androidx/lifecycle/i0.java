package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class i0 implements s0 {
    @Override // androidx.lifecycle.s0
    public final q0 d(p097ha.e eVar, S1.d dVar) {
        return new l0();
    }
}
