package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public class f0 extends Fragment {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f16483b = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public v0 f16484a;

    public static final class a implements Application.ActivityLifecycleCallbacks {
        public static final e0 Companion = new e0();

        public static final void registerIn(Activity activity) {
            Companion.getClass();
            p097ha.k.f(activity, "activity");
            activity.registerActivityLifecycleCallbacks(new a());
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityCreated(Activity activity, Bundle bundle) {
            p097ha.k.f(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityDestroyed(Activity activity) {
            p097ha.k.f(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPaused(Activity activity) {
            p097ha.k.f(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostCreated(Activity activity, Bundle bundle) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_CREATE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostResumed(Activity activity) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_RESUME);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPostStarted(Activity activity) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_START);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreDestroyed(Activity activity) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_DESTROY);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPrePaused(Activity activity) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_PAUSE);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityPreStopped(Activity activity) {
            p097ha.k.f(activity, "activity");
            int i10 = f0.f16483b;
            d0.a(activity, EnumC0818s.ON_STOP);
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityResumed(Activity activity) {
            p097ha.k.f(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
            p097ha.k.f(activity, "activity");
            p097ha.k.f(bundle, "bundle");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStarted(Activity activity) {
            p097ha.k.f(activity, "activity");
        }

        @Override // android.app.Application.ActivityLifecycleCallbacks
        public void onActivityStopped(Activity activity) {
            p097ha.k.f(activity, "activity");
        }
    }

    public final void a(EnumC0818s enumC0818s) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            p097ha.k.e(activity, "getActivity(...)");
            d0.a(activity, enumC0818s);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(EnumC0818s.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(EnumC0818s.ON_DESTROY);
        this.f16484a = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(EnumC0818s.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        v0 v0Var = this.f16484a;
        if (v0Var != null) {
            ((X) v0Var.f16539a).c();
        }
        a(EnumC0818s.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        v0 v0Var = this.f16484a;
        if (v0Var != null) {
            X x10 = (X) v0Var.f16539a;
            int i10 = x10.f16437a + 1;
            x10.f16437a = i10;
            if (i10 == 1 && x10.f16440d) {
                x10.f16442f.d(EnumC0818s.ON_START);
                x10.f16440d = false;
            }
        }
        a(EnumC0818s.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(EnumC0818s.ON_STOP);
    }
}
