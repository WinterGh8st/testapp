package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class E {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public EnumC0819t f16390a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public B f16391b;

    public final void a(D d10, EnumC0818s enumC0818s) {
        EnumC0819t enumC0819tA = enumC0818s.a();
        EnumC0819t enumC0819t = this.f16390a;
        p097ha.k.f(enumC0819t, "state1");
        if (enumC0819tA.compareTo(enumC0819t) < 0) {
            enumC0819t = enumC0819tA;
        }
        this.f16390a = enumC0819t;
        this.f16391b.d(d10, enumC0818s);
        this.f16390a = enumC0819tA;
    }
}
