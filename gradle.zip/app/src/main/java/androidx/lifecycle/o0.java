package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class o0 implements p084ga.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ O f16516a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ p097ha.q f16517b;

    public /* synthetic */ o0(O o4, p097ha.q qVar) {
        this.f16516a = o4;
        this.f16517b = qVar;
    }

    @Override // p084ga.c
    public final Object invoke(Object obj) {
        O o4 = this.f16516a;
        Object objD = o4.d();
        p097ha.q qVar = this.f16517b;
        if (qVar.f23274a || ((objD == null && obj != null) || (objD != null && !objD.equals(obj)))) {
            qVar.f23274a = false;
            o4.k(obj);
        }
        return T9.w.f11979a;
    }
}
