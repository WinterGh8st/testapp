package androidx.lifecycle;

import N1.C0584u;
import android.os.Bundle;
import java.util.Arrays;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class k0 implements p076g2.d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final p056e7.n f16501a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16502b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Bundle f16503c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final T9.l f16504d;

    public k0(p056e7.n nVar, x0 x0Var) {
        p097ha.k.f(nVar, "savedStateRegistry");
        p097ha.k.f(x0Var, "viewModelStoreOwner");
        this.f16501a = nVar;
        this.f16504d = android.support.v4.media.session.a.T(new Ea.d(x0Var, 3));
    }

    @Override // p076g2.d
    public final Bundle a() {
        Bundle bundleE = G6.C.E((T9.h[]) Arrays.copyOf(new T9.h[0], 0));
        Bundle bundle = this.f16503c;
        if (bundle != null) {
            bundleE.putAll(bundle);
        }
        for (Map.Entry entry : ((l0) this.f16504d.getValue()).f16508b.entrySet()) {
            String str = (String) entry.getKey();
            Bundle bundleA = ((C0584u) ((g0) entry.getValue()).f16488b.f740f).a();
            if (!bundleA.isEmpty()) {
                p097ha.k.f(str, "key");
                bundleE.putBundle(str, bundleA);
            }
        }
        this.f16502b = false;
        return bundleE;
    }

    public final void b() {
        if (this.f16502b) {
            return;
        }
        Bundle bundleC = this.f16501a.c("androidx.lifecycle.internal.SavedStateHandlesProvider");
        Bundle bundleE = G6.C.E((T9.h[]) Arrays.copyOf(new T9.h[0], 0));
        Bundle bundle = this.f16503c;
        if (bundle != null) {
            bundleE.putAll(bundle);
        }
        if (bundleC != null) {
            bundleE.putAll(bundleC);
        }
        this.f16503c = bundleE;
        this.f16502b = true;
    }
}
