package androidx.lifecycle;

/* JADX INFO: loaded from: classes.dex */
public final class I extends K {
    @Override // androidx.lifecycle.K
    public final boolean g() {
        return true;
    }
}
