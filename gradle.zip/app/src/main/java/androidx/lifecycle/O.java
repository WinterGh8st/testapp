package androidx.lifecycle;

import java.util.Iterator;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class O extends P {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public p198r.f f16419l = new p198r.f();

    @Override // androidx.lifecycle.P
    public void g() {
        Iterator it = this.f16419l.iterator();
        while (true) {
            p198r.b bVar = (p198r.b) it;
            if (!bVar.hasNext()) {
                return;
            } else {
                ((N) ((Map.Entry) bVar.next()).getValue()).b();
            }
        }
    }

    @Override // androidx.lifecycle.P
    public void h() {
        Iterator it = this.f16419l.iterator();
        while (true) {
            p198r.b bVar = (p198r.b) it;
            if (!bVar.hasNext()) {
                return;
            }
            N n10 = (N) ((Map.Entry) bVar.next()).getValue();
            n10.f16416a.j(n10);
        }
    }
}
