package androidx.drawerlayout.widget;

import B2.RunnableC0052c;
import E1.e;
import android.view.View;
import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class a extends AbstractC0862l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f16378c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public e f16379d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final RunnableC0052c f16380e = new RunnableC0052c(this, 4);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final /* synthetic */ DrawerLayout f16381f;

    public a(DrawerLayout drawerLayout, int i10) {
        this.f16381f = drawerLayout;
        this.f16378c = i10;
    }

    @Override // p016b3.AbstractC0862l
    public final int O(View view) {
        if (DrawerLayout.l(view)) {
            return view.getWidth();
        }
        return 0;
    }

    @Override // p016b3.AbstractC0862l
    public final void b0(int i10, int i11) {
        int i12 = i10 & 1;
        DrawerLayout drawerLayout = this.f16381f;
        View viewD = i12 == 1 ? drawerLayout.d(3) : drawerLayout.d(5);
        if (viewD == null || drawerLayout.g(viewD) != 0) {
            return;
        }
        this.f16379d.c(viewD, i11);
    }

    @Override // p016b3.AbstractC0862l
    public final void c0() {
        this.f16381f.postDelayed(this.f16380e, 160L);
    }

    @Override // p016b3.AbstractC0862l
    public final void d0(View view, int i10) {
        ((DrawerLayout.LayoutParams) view.getLayoutParams()).f16376c = false;
        int i11 = this.f16378c == 3 ? 5 : 3;
        DrawerLayout drawerLayout = this.f16381f;
        View viewD = drawerLayout.d(i11);
        if (viewD != null) {
            drawerLayout.b(viewD, true);
        }
    }

    @Override // p016b3.AbstractC0862l
    public final void e0(int i10) {
        this.f16381f.r(this.f16379d.f2933t, i10);
    }

    @Override // p016b3.AbstractC0862l
    public final void f0(View view, int i10, int i11) {
        int width = view.getWidth();
        DrawerLayout drawerLayout = this.f16381f;
        float width2 = (drawerLayout.a(view, 3) ? i10 + width : drawerLayout.getWidth() - i10) / width;
        drawerLayout.o(view, width2);
        view.setVisibility(width2 == 0.0f ? 4 : 0);
        drawerLayout.invalidate();
    }

    @Override // p016b3.AbstractC0862l
    public final void g0(View view, float f10, float f11) {
        int i10;
        DrawerLayout drawerLayout = this.f16381f;
        int[] iArr = DrawerLayout.f16341N;
        float f12 = ((DrawerLayout.LayoutParams) view.getLayoutParams()).f16375b;
        int width = view.getWidth();
        if (drawerLayout.a(view, 3)) {
            i10 = (f10 > 0.0f || (f10 == 0.0f && f12 > 0.5f)) ? 0 : -width;
        } else {
            int width2 = drawerLayout.getWidth();
            if (f10 < 0.0f || (f10 == 0.0f && f12 > 0.5f)) {
                width2 -= width;
            }
            i10 = width2;
        }
        this.f16379d.s(i10, view.getTop());
        drawerLayout.invalidate();
    }

    @Override // p016b3.AbstractC0862l
    public final boolean p0(View view, int i10) {
        DrawerLayout drawerLayout = this.f16381f;
        return DrawerLayout.l(view) && drawerLayout.a(view, this.f16378c) && drawerLayout.g(view) == 0;
    }

    @Override // p016b3.AbstractC0862l
    public final int w(View view, int i10) {
        DrawerLayout drawerLayout = this.f16381f;
        if (drawerLayout.a(view, 3)) {
            return Math.max(-view.getWidth(), Math.min(i10, 0));
        }
        int width = drawerLayout.getWidth();
        return Math.max(width - view.getWidth(), Math.min(i10, width));
    }

    @Override // p016b3.AbstractC0862l
    public final int x(View view, int i10) {
        return view.getTop();
    }
}
