package androidx.drawerlayout.widget;

import A6.d;
import B2.C0057h;
import B3.o;
import C9.C0077b0;
import E1.e;
import G1.b;
import G1.c;
import Y4.n;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.google.android.material.navigation.NavigationView;
import java.util.ArrayList;
import java.util.Objects;
import java.util.WeakHashMap;
import p032c7.AbstractC0933i;
import p063f1.h;
import p200r1.A0;
import p200r1.H;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class DrawerLayout extends ViewGroup {

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final int[] f16341N = {R.attr.colorPrimaryDark};

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final int[] f16342O = {R.attr.layout_gravity};

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public static final boolean f16343P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public static final boolean f16344Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public static final boolean f16345R;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f16346A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f16347B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public c f16348C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public ArrayList f16349D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public float f16350E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public float f16351F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public Drawable f16352G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public WindowInsets f16353H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f16354I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final ArrayList f16355J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public Rect f16356K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public Matrix f16357L;
    public final d M;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0077b0 f16358a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f16359b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f16360c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16361d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f16362e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Paint f16363f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final e f16364q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final e f16365r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final a f16366s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final a f16367t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f16368u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f16369v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f16370w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f16371x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f16372y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f16373z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f16374a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f16375b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f16376c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f16377d;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f16374a = 0;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.f16342O);
            this.f16374a = typedArrayObtainStyledAttributes.getInt(0, 0);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    static {
        int i10 = Build.VERSION.SDK_INT;
        f16343P = true;
        f16344Q = true;
        f16345R = i10 >= 29;
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.flamingotools.ws.R.attr.drawerLayoutStyle);
        this.f16358a = new C0077b0(1);
        this.f16361d = -1728053248;
        this.f16363f = new Paint();
        this.f16370w = true;
        this.f16371x = 3;
        this.f16372y = 3;
        this.f16373z = 3;
        this.f16346A = 3;
        this.M = new d(this, 16);
        setDescendantFocusability(262144);
        float f10 = getResources().getDisplayMetrics().density;
        this.f16360c = (int) ((64.0f * f10) + 0.5f);
        float f11 = f10 * 400.0f;
        a aVar = new a(this, 3);
        this.f16366s = aVar;
        a aVar2 = new a(this, 5);
        this.f16367t = aVar2;
        e eVar = new e(getContext(), this, aVar);
        eVar.f2916b = (int) (eVar.f2916b * 1.0f);
        this.f16364q = eVar;
        eVar.f2930q = 1;
        eVar.f2927n = f11;
        aVar.f16379d = eVar;
        e eVar2 = new e(getContext(), this, aVar2);
        eVar2.f2916b = (int) (1.0f * eVar2.f2916b);
        this.f16365r = eVar2;
        eVar2.f2930q = 2;
        eVar2.f2927n = f11;
        aVar2.f16379d = eVar2;
        setFocusableInTouchMode(true);
        WeakHashMap weakHashMap = U.f27683a;
        setImportantForAccessibility(1);
        U.q(this, new b(this));
        setMotionEventSplittingEnabled(false);
        if (getFitsSystemWindows()) {
            setOnApplyWindowInsetsListener(new G1.a());
            setSystemUiVisibility(1280);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(f16341N);
            try {
                this.f16352G = typedArrayObtainStyledAttributes.getDrawable(0);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, F1.a.f3503a, com.flamingotools.ws.R.attr.drawerLayoutStyle, 0);
        try {
            if (typedArrayObtainStyledAttributes2.hasValue(0)) {
                this.f16359b = typedArrayObtainStyledAttributes2.getDimension(0, 0.0f);
            } else {
                this.f16359b = getResources().getDimension(com.flamingotools.ws.R.dimen.def_drawer_elevation);
            }
            typedArrayObtainStyledAttributes2.recycle();
            this.f16355J = new ArrayList();
        } catch (Throwable th2) {
            typedArrayObtainStyledAttributes2.recycle();
            throw th2;
        }
    }

    public static boolean i(View view) {
        WeakHashMap weakHashMap = U.f27683a;
        return (view.getImportantForAccessibility() == 4 || view.getImportantForAccessibility() == 2) ? false : true;
    }

    public static boolean j(View view) {
        return ((LayoutParams) view.getLayoutParams()).f16374a == 0;
    }

    public static boolean k(View view) {
        if (l(view)) {
            return (((LayoutParams) view.getLayoutParams()).f16377d & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public static boolean l(View view) {
        int i10 = ((LayoutParams) view.getLayoutParams()).f16374a;
        WeakHashMap weakHashMap = U.f27683a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, view.getLayoutDirection());
        return ((absoluteGravity & 3) == 0 && (absoluteGravity & 5) == 0) ? false : true;
    }

    public final boolean a(View view, int i10) {
        return (h(view) & i10) == i10;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i10, int i11) {
        ArrayList arrayList2;
        if (getDescendantFocusability() == 393216) {
            return;
        }
        int childCount = getChildCount();
        int i12 = 0;
        boolean z3 = false;
        while (true) {
            arrayList2 = this.f16355J;
            if (i12 >= childCount) {
                break;
            }
            View childAt = getChildAt(i12);
            if (!l(childAt)) {
                arrayList2.add(childAt);
            } else if (k(childAt)) {
                childAt.addFocusables(arrayList, i10, i11);
                z3 = true;
            }
            i12++;
        }
        if (!z3) {
            int size = arrayList2.size();
            for (int i13 = 0; i13 < size; i13++) {
                View view = (View) arrayList2.get(i13);
                if (view.getVisibility() == 0) {
                    view.addFocusables(arrayList, i10, i11);
                }
            }
        }
        arrayList2.clear();
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i10, layoutParams);
        if (e() != null || l(view)) {
            WeakHashMap weakHashMap = U.f27683a;
            view.setImportantForAccessibility(4);
        } else {
            WeakHashMap weakHashMap2 = U.f27683a;
            view.setImportantForAccessibility(1);
        }
        if (f16343P) {
            return;
        }
        U.q(view, this.f16358a);
    }

    public final void b(View view, boolean z3) {
        if (!l(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f16370w) {
            layoutParams.f16375b = 0.0f;
            layoutParams.f16377d = 0;
        } else if (z3) {
            layoutParams.f16377d |= 4;
            if (a(view, 3)) {
                this.f16364q.u(view, -view.getWidth(), view.getTop());
            } else {
                this.f16365r.u(view, getWidth(), view.getTop());
            }
        } else {
            float f10 = ((LayoutParams) view.getLayoutParams()).f16375b;
            float width = view.getWidth();
            int i10 = ((int) (width * 0.0f)) - ((int) (f10 * width));
            if (!a(view, 3)) {
                i10 = -i10;
            }
            view.offsetLeftAndRight(i10);
            o(view, 0.0f);
            r(view, 0);
            view.setVisibility(4);
        }
        invalidate();
    }

    public final void c(boolean z3) {
        int childCount = getChildCount();
        boolean zU = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (l(childAt) && (!z3 || layoutParams.f16376c)) {
                zU |= a(childAt, 3) ? this.f16364q.u(childAt, -childAt.getWidth(), childAt.getTop()) : this.f16365r.u(childAt, getWidth(), childAt.getTop());
                layoutParams.f16376c = false;
            }
        }
        a aVar = this.f16366s;
        aVar.f16381f.removeCallbacks(aVar.f16380e);
        a aVar2 = this.f16367t;
        aVar2.f16381f.removeCallbacks(aVar2.f16380e);
        if (zU) {
            invalidate();
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public final void computeScroll() {
        int childCount = getChildCount();
        float fMax = 0.0f;
        for (int i10 = 0; i10 < childCount; i10++) {
            fMax = Math.max(fMax, ((LayoutParams) getChildAt(i10).getLayoutParams()).f16375b);
        }
        this.f16362e = fMax;
        boolean zH = this.f16364q.h();
        boolean zH2 = this.f16365r.h();
        if (zH || zH2) {
            WeakHashMap weakHashMap = U.f27683a;
            postInvalidateOnAnimation();
        }
    }

    public final View d(int i10) {
        WeakHashMap weakHashMap = U.f27683a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, getLayoutDirection()) & 7;
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if ((h(childAt) & 7) == absoluteGravity) {
                return childAt;
            }
        }
        return null;
    }

    @Override // android.view.View
    public final boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        boolean zDispatchGenericMotionEvent;
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f16362e <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x10 = motionEvent.getX();
        float y10 = motionEvent.getY();
        for (int i10 = childCount - 1; i10 >= 0; i10--) {
            View childAt = getChildAt(i10);
            if (this.f16356K == null) {
                this.f16356K = new Rect();
            }
            childAt.getHitRect(this.f16356K);
            if (this.f16356K.contains((int) x10, (int) y10) && !j(childAt)) {
                if (childAt.getMatrix().isIdentity()) {
                    float scrollX = getScrollX() - childAt.getLeft();
                    float scrollY = getScrollY() - childAt.getTop();
                    motionEvent.offsetLocation(scrollX, scrollY);
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEvent);
                    motionEvent.offsetLocation(-scrollX, -scrollY);
                } else {
                    float scrollX2 = getScrollX() - childAt.getLeft();
                    float scrollY2 = getScrollY() - childAt.getTop();
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(scrollX2, scrollY2);
                    Matrix matrix = childAt.getMatrix();
                    if (!matrix.isIdentity()) {
                        if (this.f16357L == null) {
                            this.f16357L = new Matrix();
                        }
                        matrix.invert(this.f16357L);
                        motionEventObtain.transform(this.f16357L);
                    }
                    zDispatchGenericMotionEvent = childAt.dispatchGenericMotionEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zDispatchGenericMotionEvent) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        Drawable background;
        int height = getHeight();
        boolean zJ = j(view);
        int width = getWidth();
        int iSave = canvas.save();
        int i10 = 0;
        if (zJ) {
            int childCount = getChildCount();
            int i11 = 0;
            for (int i12 = 0; i12 < childCount; i12++) {
                View childAt = getChildAt(i12);
                if (childAt != view && childAt.getVisibility() == 0 && (background = childAt.getBackground()) != null && background.getOpacity() == -1 && l(childAt) && childAt.getHeight() >= height) {
                    if (a(childAt, 3)) {
                        int right = childAt.getRight();
                        if (right > i11) {
                            i11 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i11, 0, width, getHeight());
            i10 = i11;
        }
        boolean zDrawChild = super.drawChild(canvas, view, j10);
        canvas.restoreToCount(iSave);
        float f10 = this.f16362e;
        if (f10 > 0.0f && zJ) {
            int i13 = this.f16361d;
            Paint paint = this.f16363f;
            paint.setColor((((int) ((((-16777216) & i13) >>> 24) * f10)) << 24) | (i13 & 16777215));
            canvas.drawRect(i10, 0.0f, width, getHeight(), paint);
        }
        return zDrawChild;
    }

    public final View e() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((((LayoutParams) childAt.getLayoutParams()).f16377d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    public final View f() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (l(childAt)) {
                if (!l(childAt)) {
                    throw new IllegalArgumentException("View " + childAt + " is not a drawer");
                }
                if (((LayoutParams) childAt.getLayoutParams()).f16375b > 0.0f) {
                    return childAt;
                }
            }
        }
        return null;
    }

    public final int g(View view) {
        if (!l(view)) {
            throw new IllegalArgumentException("View " + view + " is not a drawer");
        }
        int i10 = ((LayoutParams) view.getLayoutParams()).f16374a;
        WeakHashMap weakHashMap = U.f27683a;
        int layoutDirection = getLayoutDirection();
        if (i10 == 3) {
            int i11 = this.f16371x;
            if (i11 != 3) {
                return i11;
            }
            int i12 = layoutDirection == 0 ? this.f16373z : this.f16346A;
            if (i12 != 3) {
                return i12;
            }
            return 0;
        }
        if (i10 == 5) {
            int i13 = this.f16372y;
            if (i13 != 3) {
                return i13;
            }
            int i14 = layoutDirection == 0 ? this.f16346A : this.f16373z;
            if (i14 != 3) {
                return i14;
            }
            return 0;
        }
        if (i10 == 8388611) {
            int i15 = this.f16373z;
            if (i15 != 3) {
                return i15;
            }
            int i16 = layoutDirection == 0 ? this.f16371x : this.f16372y;
            if (i16 != 3) {
                return i16;
            }
            return 0;
        }
        if (i10 != 8388613) {
            return 0;
        }
        int i17 = this.f16346A;
        if (i17 != 3) {
            return i17;
        }
        int i18 = layoutDirection == 0 ? this.f16372y : this.f16371x;
        if (i18 != 3) {
            return i18;
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new LayoutParams(-1, -1);
        layoutParams.f16374a = 0;
        return layoutParams;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            LayoutParams layoutParams3 = new LayoutParams(layoutParams2);
            layoutParams3.f16374a = 0;
            layoutParams3.f16374a = layoutParams2.f16374a;
            return layoutParams3;
        }
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams4 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams4.f16374a = 0;
            return layoutParams4;
        }
        LayoutParams layoutParams5 = new LayoutParams(layoutParams);
        layoutParams5.f16374a = 0;
        return layoutParams5;
    }

    public float getDrawerElevation() {
        if (f16344Q) {
            return this.f16359b;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f16352G;
    }

    public final int h(View view) {
        int i10 = ((LayoutParams) view.getLayoutParams()).f16374a;
        WeakHashMap weakHashMap = U.f27683a;
        return Gravity.getAbsoluteGravity(i10, getLayoutDirection());
    }

    public final void m(View view) {
        if (!l(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f16370w) {
            layoutParams.f16375b = 1.0f;
            layoutParams.f16377d = 1;
            q(view, true);
            p(view);
        } else {
            layoutParams.f16377d |= 2;
            if (a(view, 3)) {
                this.f16364q.u(view, 0, view.getTop());
            } else {
                this.f16365r.u(view, getWidth() - view.getWidth(), view.getTop());
            }
        }
        invalidate();
    }

    public final void n(int i10, int i11) {
        View viewD;
        WeakHashMap weakHashMap = U.f27683a;
        int absoluteGravity = Gravity.getAbsoluteGravity(i11, getLayoutDirection());
        if (i11 == 3) {
            this.f16371x = i10;
        } else if (i11 == 5) {
            this.f16372y = i10;
        } else if (i11 == 8388611) {
            this.f16373z = i10;
        } else if (i11 == 8388613) {
            this.f16346A = i10;
        }
        if (i10 != 0) {
            (absoluteGravity == 3 ? this.f16364q : this.f16365r).b();
        }
        if (i10 != 1) {
            if (i10 == 2 && (viewD = d(absoluteGravity)) != null) {
                m(viewD);
                return;
            }
            return;
        }
        View viewD2 = d(absoluteGravity);
        if (viewD2 != null) {
            b(viewD2, true);
        }
    }

    public final void o(View view, float f10) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f10 == layoutParams.f16375b) {
            return;
        }
        layoutParams.f16375b = f10;
        ArrayList arrayList = this.f16349D;
        if (arrayList != null) {
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                ((c) this.f16349D.get(size)).getClass();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f16370w = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f16370w = true;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f16354I || this.f16352G == null) {
            return;
        }
        WindowInsets windowInsets = this.f16353H;
        int systemWindowInsetTop = windowInsets != null ? windowInsets.getSystemWindowInsetTop() : 0;
        if (systemWindowInsetTop > 0) {
            this.f16352G.setBounds(0, 0, getWidth(), systemWindowInsetTop);
            this.f16352G.draw(canvas);
        }
    }

    /* JADX WARN: Code duplicated, block: B:18:0x005e  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        View viewI;
        int actionMasked = motionEvent.getActionMasked();
        e eVar = this.f16364q;
        boolean zT = eVar.t(motionEvent) | this.f16365r.t(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                c(true);
                this.f16347B = false;
            } else if (actionMasked == 2) {
                int length = eVar.f2918d.length;
                for (int i10 = 0; i10 < length; i10++) {
                    if ((eVar.k & (1 << i10)) != 0) {
                        float f10 = eVar.f2920f[i10] - eVar.f2918d[i10];
                        float f11 = eVar.f2921g[i10] - eVar.f2919e[i10];
                        float f12 = (f11 * f11) + (f10 * f10);
                        int i11 = eVar.f2916b;
                        if (f12 > i11 * i11) {
                            a aVar = this.f16366s;
                            aVar.f16381f.removeCallbacks(aVar.f16380e);
                            a aVar2 = this.f16367t;
                            aVar2.f16381f.removeCallbacks(aVar2.f16380e);
                            break;
                        }
                    }
                }
            } else if (actionMasked == 3) {
                c(true);
                this.f16347B = false;
            }
            z3 = false;
        } else {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            this.f16350E = x10;
            this.f16351F = y10;
            z3 = this.f16362e > 0.0f && (viewI = eVar.i((int) x10, (int) y10)) != null && j(viewI);
            this.f16347B = false;
        }
        if (!zT && !z3) {
            int childCount = getChildCount();
            for (int i12 = 0; i12 < childCount; i12++) {
                if (!((LayoutParams) getChildAt(i12).getLayoutParams()).f16376c) {
                }
            }
            if (!this.f16347B) {
                return false;
            }
        }
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyDown(int i10, KeyEvent keyEvent) {
        if (i10 != 4 || f() == null) {
            return super.onKeyDown(i10, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public final boolean onKeyUp(int i10, KeyEvent keyEvent) {
        if (i10 != 4) {
            return super.onKeyUp(i10, keyEvent);
        }
        View viewF = f();
        if (viewF != null && g(viewF) == 0) {
            c(false);
        }
        return viewF != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        WindowInsets rootWindowInsets;
        float f10;
        int i14;
        boolean z5 = true;
        this.f16369v = true;
        int i15 = i12 - i10;
        int childCount = getChildCount();
        int i16 = 0;
        while (i16 < childCount) {
            View childAt = getChildAt(i16);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (j(childAt)) {
                    int i17 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
                    childAt.layout(i17, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, childAt.getMeasuredWidth() + i17, childAt.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin);
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (a(childAt, 3)) {
                        float f11 = measuredWidth;
                        i14 = (-measuredWidth) + ((int) (layoutParams.f16375b * f11));
                        f10 = (measuredWidth + i14) / f11;
                    } else {
                        float f12 = measuredWidth;
                        int i18 = i15 - ((int) (layoutParams.f16375b * f12));
                        f10 = (i15 - i18) / f12;
                        i14 = i18;
                    }
                    boolean z10 = f10 != layoutParams.f16375b ? z5 : false;
                    int i19 = layoutParams.f16374a & 112;
                    if (i19 == 16) {
                        int i20 = i13 - i11;
                        int i21 = (i20 - measuredHeight) / 2;
                        int i22 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        if (i21 < i22) {
                            i21 = i22;
                        } else {
                            int i23 = i21 + measuredHeight;
                            int i24 = i20 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                            if (i23 > i24) {
                                i21 = i24 - measuredHeight;
                            }
                        }
                        childAt.layout(i14, i21, measuredWidth + i14, measuredHeight + i21);
                    } else if (i19 != 80) {
                        int i25 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        childAt.layout(i14, i25, measuredWidth + i14, measuredHeight + i25);
                    } else {
                        int i26 = i13 - i11;
                        childAt.layout(i14, (i26 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i14, i26 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
                    }
                    if (z10) {
                        o(childAt, f10);
                    }
                    int i27 = layoutParams.f16375b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i27) {
                        childAt.setVisibility(i27);
                    }
                }
            }
            i16++;
            z5 = true;
        }
        if (f16345R && (rootWindowInsets = getRootWindowInsets()) != null) {
            p088h1.c cVarJ = A0.h(null, rootWindowInsets).f27661a.j();
            e eVar = this.f16364q;
            eVar.f2928o = Math.max(eVar.f2929p, cVarJ.f23025a);
            e eVar2 = this.f16365r;
            eVar2.f2928o = Math.max(eVar2.f2929p, cVarJ.f23027c);
        }
        this.f16369v = false;
        this.f16370w = false;
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0039  */
    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        boolean z3;
        int i12;
        String hexString;
        int i13 = 3;
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        char c10 = 0;
        if (mode != 1073741824 || mode2 != 1073741824) {
            if (!isInEditMode()) {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
            if (mode == 0) {
                size = 300;
            }
            if (mode2 == 0) {
                size2 = 300;
            }
        }
        setMeasuredDimension(size, size2);
        if (this.f16353H != null) {
            WeakHashMap weakHashMap = U.f27683a;
            if (getFitsSystemWindows()) {
                z3 = true;
            } else {
                z3 = false;
            }
        } else {
            z3 = false;
        }
        WeakHashMap weakHashMap2 = U.f27683a;
        int layoutDirection = getLayoutDirection();
        int childCount = getChildCount();
        int i14 = 0;
        boolean z5 = false;
        boolean z10 = false;
        while (i14 < childCount) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (z3) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(layoutParams.f16374a, layoutDirection);
                    if (childAt.getFitsSystemWindows()) {
                        WindowInsets windowInsetsReplaceSystemWindowInsets = this.f16353H;
                        if (absoluteGravity == i13) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsetsReplaceSystemWindowInsets);
                    } else {
                        WindowInsets windowInsetsReplaceSystemWindowInsets2 = this.f16353H;
                        if (absoluteGravity == 3) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        } else if (absoluteGravity == 5) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        }
                        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft();
                        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop();
                        ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight();
                        ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom();
                    }
                }
                if (j(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, 1073741824));
                } else {
                    if (!l(childAt)) {
                        throw new IllegalStateException("Child " + childAt + " at index " + i14 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    }
                    if (f16344Q) {
                        float fI = H.i(childAt);
                        float f10 = this.f16359b;
                        if (fI != f10) {
                            H.s(childAt, f10);
                        }
                    }
                    int iH = h(childAt);
                    int i15 = iH & 7;
                    boolean z11 = i15 == 3;
                    if ((z11 && z5) || (!z11 && z10)) {
                        StringBuilder sb2 = new StringBuilder("Child drawer has absolute gravity ");
                        if ((iH & 3) != 3) {
                            hexString = (iH & 5) == 5 ? "RIGHT" : Integer.toHexString(i15);
                        } else {
                            hexString = "LEFT";
                        }
                        throw new IllegalStateException(AbstractC0933i.i(sb2, hexString, " but this DrawerLayout already has a drawer view along that edge"));
                    }
                    i12 = 3;
                    if (z11) {
                        z5 = true;
                    } else {
                        z10 = true;
                    }
                    childAt.measure(ViewGroup.getChildMeasureSpec(i10, this.f16360c + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, ((ViewGroup.MarginLayoutParams) layoutParams).width), ViewGroup.getChildMeasureSpec(i11, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, ((ViewGroup.MarginLayoutParams) layoutParams).height));
                }
                i14++;
                i13 = i12;
                c10 = 0;
            }
            i12 = 3;
            i14++;
            i13 = i12;
            c10 = 0;
        }
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        View viewD;
        if (!(parcelable instanceof G1.d)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        G1.d dVar = (G1.d) parcelable;
        super.onRestoreInstanceState(dVar.f2402a);
        int i10 = dVar.f4147c;
        if (i10 != 0 && (viewD = d(i10)) != null) {
            m(viewD);
        }
        int i11 = dVar.f4148d;
        if (i11 != 3) {
            n(i11, 3);
        }
        int i12 = dVar.f4149e;
        if (i12 != 3) {
            n(i12, 5);
        }
        int i13 = dVar.f4150f;
        if (i13 != 3) {
            n(i13, 8388611);
        }
        int i14 = dVar.f4151q;
        if (i14 != 3) {
            n(i14, 8388613);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        if (f16344Q) {
            return;
        }
        WeakHashMap weakHashMap = U.f27683a;
        getLayoutDirection();
        getLayoutDirection();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        G1.d dVar = new G1.d(super.onSaveInstanceState());
        dVar.f4147c = 0;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            LayoutParams layoutParams = (LayoutParams) getChildAt(i10).getLayoutParams();
            int i11 = layoutParams.f16377d;
            boolean z3 = i11 == 1;
            boolean z5 = i11 == 2;
            if (z3 || z5) {
                dVar.f4147c = layoutParams.f16374a;
                break;
            }
        }
        dVar.f4148d = this.f16371x;
        dVar.f4149e = this.f16372y;
        dVar.f4150f = this.f16373z;
        dVar.f4151q = this.f16346A;
        return dVar;
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0054  */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        View viewE;
        e eVar = this.f16364q;
        eVar.m(motionEvent);
        this.f16365r.m(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            this.f16350E = x10;
            this.f16351F = y10;
            this.f16347B = false;
            return true;
        }
        if (action != 1) {
            if (action != 3) {
                return true;
            }
            c(true);
            this.f16347B = false;
            return true;
        }
        float x11 = motionEvent.getX();
        float y11 = motionEvent.getY();
        View viewI = eVar.i((int) x11, (int) y11);
        if (viewI != null && j(viewI)) {
            float f10 = x11 - this.f16350E;
            float f11 = y11 - this.f16351F;
            int i10 = eVar.f2916b;
            z3 = (f11 * f11) + (f10 * f10) >= ((float) (i10 * i10)) || (viewE = e()) == null || g(viewE) == 2;
        }
        c(z3);
        return true;
    }

    public final void p(View view) {
        p211s1.d dVar = p211s1.d.f27937n;
        U.n(view, dVar.a());
        U.k(view, 0);
        if (!k(view) || g(view) == 2) {
            return;
        }
        U.o(view, dVar, null, this.M);
    }

    public final void q(View view, boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((z3 || l(childAt)) && !(z3 && childAt == view)) {
                WeakHashMap weakHashMap = U.f27683a;
                childAt.setImportantForAccessibility(4);
            } else {
                WeakHashMap weakHashMap2 = U.f27683a;
                childAt.setImportantForAccessibility(1);
            }
        }
    }

    public final void r(View view, int i10) {
        int i11;
        View rootView;
        int i12 = this.f16364q.f2915a;
        int i13 = this.f16365r.f2915a;
        if (i12 == 1 || i13 == 1) {
            i11 = 1;
        } else {
            i11 = 2;
            if (i12 != 2 && i13 != 2) {
                i11 = 0;
            }
        }
        if (view != null && i10 == 0) {
            float f10 = ((LayoutParams) view.getLayoutParams()).f16375b;
            if (f10 == 0.0f) {
                LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
                if ((layoutParams.f16377d & 1) == 1) {
                    layoutParams.f16377d = 0;
                    ArrayList arrayList = this.f16349D;
                    if (arrayList != null) {
                        for (int size = arrayList.size() - 1; size >= 0; size--) {
                            NavigationView navigationView = ((n) ((c) this.f16349D.get(size))).f14331a;
                            if (view == navigationView) {
                                C0057h c0057h = navigationView.f19596E;
                                X4.d dVar = (X4.d) c0057h.f921b;
                                if (dVar != null) {
                                    dVar.c((FrameLayout) c0057h.f923d);
                                }
                                if (navigationView.f19592A && navigationView.f19606z != 0) {
                                    navigationView.f19606z = 0;
                                    navigationView.h(navigationView.getWidth(), navigationView.getHeight());
                                }
                            }
                        }
                    }
                    q(view, false);
                    p(view);
                    if (hasWindowFocus() && (rootView = getRootView()) != null) {
                        rootView.sendAccessibilityEvent(32);
                    }
                }
            } else if (f10 == 1.0f) {
                LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
                if ((layoutParams2.f16377d & 1) == 0) {
                    layoutParams2.f16377d = 1;
                    ArrayList arrayList2 = this.f16349D;
                    if (arrayList2 != null) {
                        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
                            NavigationView navigationView2 = ((n) ((c) this.f16349D.get(size2))).f14331a;
                            if (view == navigationView2) {
                                C0057h c0057h2 = navigationView2.f19596E;
                                Objects.requireNonNull(c0057h2);
                                view.post(new o(c0057h2, 10));
                            }
                        }
                    }
                    q(view, true);
                    p(view);
                    if (hasWindowFocus()) {
                        sendAccessibilityEvent(32);
                    }
                }
            }
        }
        if (i11 != this.f16368u) {
            this.f16368u = i11;
            ArrayList arrayList3 = this.f16349D;
            if (arrayList3 != null) {
                for (int size3 = arrayList3.size() - 1; size3 >= 0; size3--) {
                    ((c) this.f16349D.get(size3)).getClass();
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        super.requestDisallowInterceptTouchEvent(z3);
        if (z3) {
            c(true);
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f16369v) {
            return;
        }
        super.requestLayout();
    }

    public void setDrawerElevation(float f10) {
        this.f16359b = f10;
        for (int i10 = 0; i10 < getChildCount(); i10++) {
            View childAt = getChildAt(i10);
            if (l(childAt)) {
                float f11 = this.f16359b;
                WeakHashMap weakHashMap = U.f27683a;
                H.s(childAt, f11);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(c cVar) {
        ArrayList arrayList;
        c cVar2 = this.f16348C;
        if (cVar2 != null && (arrayList = this.f16349D) != null) {
            arrayList.remove(cVar2);
        }
        if (cVar != null) {
            if (this.f16349D == null) {
                this.f16349D = new ArrayList();
            }
            this.f16349D.add(cVar);
        }
        this.f16348C = cVar;
    }

    public void setDrawerLockMode(int i10) {
        n(i10, 3);
        n(i10, 5);
    }

    public void setScrimColor(int i10) {
        this.f16361d = i10;
        invalidate();
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f16352G = drawable;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i10) {
        this.f16352G = new ColorDrawable(i10);
        invalidate();
    }

    public void setStatusBarBackground(int i10) {
        this.f16352G = i10 != 0 ? h.getDrawable(getContext(), i10) : null;
        invalidate();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }
}
