package androidx.credentials.playservices;

import A1.a;
import M3.l;
import M3.r;
import M3.s;
import X2.h;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.os.ResultReceiver;
import android.util.Log;
import androidx.credentials.playservices.HiddenActivity;
import com.google.android.gms.common.api.d;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.internal.AbstractC0969y;
import com.google.android.gms.common.api.internal.C0946a;
import com.google.android.gms.common.api.j;
import com.google.android.gms.common.internal.L;
import com.google.android.gms.internal.p000authapi.zbaw;
import com.google.android.gms.internal.p000authapi.zbbg;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import p088h1.g;
import p097ha.k;
import p104i4.C1162y;
import p285z1.c;

/* JADX INFO: loaded from: classes.dex */
public class HiddenActivity extends Activity {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f16338c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ResultReceiver f16339a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16340b;

    public final void a(ResultReceiver resultReceiver, String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("FAILURE_RESPONSE", true);
        bundle.putString("EXCEPTION_TYPE", str);
        bundle.putString("EXCEPTION_MESSAGE", str2);
        resultReceiver.send(f.API_PRIORITY_OTHER, bundle);
        finish();
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i10, int i11, Intent intent) {
        super.onActivityResult(i10, i11, intent);
        Bundle bundle = new Bundle();
        bundle.putBoolean("FAILURE_RESPONSE", false);
        bundle.putInt("ACTIVITY_REQUEST_CODE", i10);
        bundle.putParcelable("RESULT_DATA", intent);
        ResultReceiver resultReceiver = this.f16339a;
        if (resultReceiver != null) {
            resultReceiver.send(i11, bundle);
        }
        this.f16340b = false;
        finish();
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        final int i10 = 2;
        final int i11 = 3;
        final int i12 = 1;
        super.onCreate(bundle);
        final int i13 = 0;
        overridePendingTransition(0, 0);
        String stringExtra = getIntent().getStringExtra("TYPE");
        ResultReceiver resultReceiver = (ResultReceiver) getIntent().getParcelableExtra("RESULT_RECEIVER");
        this.f16339a = resultReceiver;
        if (resultReceiver == null) {
            finish();
        }
        if (bundle != null) {
            this.f16340b = bundle.getBoolean("androidx.credentials.playservices.AWAITING_RESULT", false);
        }
        if (!this.f16340b) {
            if (stringExtra != null) {
                Task taskAddOnFailureListener = null;
                switch (stringExtra.hashCode()) {
                    case -441061071:
                        if (stringExtra.equals("BEGIN_SIGN_IN")) {
                            M3.f fVar = (M3.f) getIntent().getParcelableExtra("REQUEST_TYPE");
                            if ((fVar != null ? new zbbg((Activity) this, new s()).beginSignIn(fVar).addOnSuccessListener(new h(new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 0), 10)).addOnFailureListener(new OnFailureListener(this) { // from class: z1.b

                                /* JADX INFO: renamed from: b, reason: collision with root package name */
                                public final /* synthetic */ HiddenActivity f33270b;

                                {
                                    this.f33270b = this;
                                }

                                @Override // com.google.android.gms.tasks.OnFailureListener
                                public final void onFailure(Exception exc) {
                                    String str = "CREATE_UNKNOWN";
                                    String str2 = "GET_NO_CREDENTIALS";
                                    HiddenActivity hiddenActivity = this.f33270b;
                                    switch (i11) {
                                        case 0:
                                            int i14 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver2 = hiddenActivity.f16339a;
                                            k.c(resultReceiver2);
                                            hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                            break;
                                        case 1:
                                            int i15 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver3 = hiddenActivity.f16339a;
                                            k.c(resultReceiver3);
                                            hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                            break;
                                        case 2:
                                            int i16 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver4 = hiddenActivity.f16339a;
                                            k.c(resultReceiver4);
                                            hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                            break;
                                        default:
                                            int i17 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver5 = hiddenActivity.f16339a;
                                            k.c(resultReceiver5);
                                            hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                            break;
                                    }
                                }
                            }) : null) == null) {
                                Log.i("HiddenActivity", "During begin sign in, params is null, nothing to launch for begin sign in");
                                finish();
                            }
                        }
                        break;
                    case 15545322:
                        if (stringExtra.equals("CREATE_PUBLIC_KEY_CREDENTIAL")) {
                            C1162y c1162y = (C1162y) getIntent().getParcelableExtra("REQUEST_TYPE");
                            int intExtra = getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1);
                            if (c1162y != null) {
                                int i14 = p066f4.a.f22380a;
                                d dVar = e.f18651h;
                                C0946a c0946a = new C0946a();
                                Looper mainLooper = getMainLooper();
                                L.k(mainLooper, "Looper must not be null.");
                                p091h4.a aVar = new p091h4.a(this, this, p091h4.a.f23101a, dVar, new com.google.android.gms.common.api.k(c0946a, mainLooper));
                                H4.e eVarA = AbstractC0969y.a();
                                eVarA.f4548d = new g(aVar, c1162y);
                                eVarA.f4547c = 5407;
                                taskAddOnFailureListener = aVar.doRead(eVarA.a()).addOnSuccessListener(new h(new c(this, intExtra, 2), 7)).addOnFailureListener(new OnFailureListener(this) { // from class: z1.b

                                    /* JADX INFO: renamed from: b, reason: collision with root package name */
                                    public final /* synthetic */ HiddenActivity f33270b;

                                    {
                                        this.f33270b = this;
                                    }

                                    @Override // com.google.android.gms.tasks.OnFailureListener
                                    public final void onFailure(Exception exc) {
                                        String str = "CREATE_UNKNOWN";
                                        String str2 = "GET_NO_CREDENTIALS";
                                        HiddenActivity hiddenActivity = this.f33270b;
                                        switch (i13) {
                                            case 0:
                                                int i15 = HiddenActivity.f16338c;
                                                k.f(hiddenActivity, "this$0");
                                                k.f(exc, "e");
                                                if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                    str = "CREATE_INTERRUPTED";
                                                }
                                                ResultReceiver resultReceiver2 = hiddenActivity.f16339a;
                                                k.c(resultReceiver2);
                                                hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                                break;
                                            case 1:
                                                int i16 = HiddenActivity.f16338c;
                                                k.f(hiddenActivity, "this$0");
                                                k.f(exc, "e");
                                                if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                    str = "CREATE_INTERRUPTED";
                                                }
                                                ResultReceiver resultReceiver3 = hiddenActivity.f16339a;
                                                k.c(resultReceiver3);
                                                hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                                break;
                                            case 2:
                                                int i17 = HiddenActivity.f16338c;
                                                k.f(hiddenActivity, "this$0");
                                                k.f(exc, "e");
                                                if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                    str2 = "GET_INTERRUPTED";
                                                }
                                                ResultReceiver resultReceiver4 = hiddenActivity.f16339a;
                                                k.c(resultReceiver4);
                                                hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                                break;
                                            default:
                                                int i18 = HiddenActivity.f16338c;
                                                k.f(hiddenActivity, "this$0");
                                                k.f(exc, "e");
                                                if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                    str2 = "GET_INTERRUPTED";
                                                }
                                                ResultReceiver resultReceiver5 = hiddenActivity.f16339a;
                                                k.c(resultReceiver5);
                                                hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                                break;
                                        }
                                    }
                                });
                            }
                            if (taskAddOnFailureListener == null) {
                                Log.w("HiddenActivity", "During create public key credential, request is null, so nothing to launch for public key credentials");
                                finish();
                            }
                        }
                        break;
                    case 1246634622:
                        if (stringExtra.equals("CREATE_PASSWORD")) {
                            l lVar = (l) getIntent().getParcelableExtra("REQUEST_TYPE");
                            if ((lVar != null ? new zbaw((Activity) this, new r()).savePassword(lVar).addOnSuccessListener(new h(new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 1), 8)).addOnFailureListener(new OnFailureListener(this) { // from class: z1.b

                                /* JADX INFO: renamed from: b, reason: collision with root package name */
                                public final /* synthetic */ HiddenActivity f33270b;

                                {
                                    this.f33270b = this;
                                }

                                @Override // com.google.android.gms.tasks.OnFailureListener
                                public final void onFailure(Exception exc) {
                                    String str = "CREATE_UNKNOWN";
                                    String str2 = "GET_NO_CREDENTIALS";
                                    HiddenActivity hiddenActivity = this.f33270b;
                                    switch (i12) {
                                        case 0:
                                            int i15 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver2 = hiddenActivity.f16339a;
                                            k.c(resultReceiver2);
                                            hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                            break;
                                        case 1:
                                            int i16 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver3 = hiddenActivity.f16339a;
                                            k.c(resultReceiver3);
                                            hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                            break;
                                        case 2:
                                            int i17 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver4 = hiddenActivity.f16339a;
                                            k.c(resultReceiver4);
                                            hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                            break;
                                        default:
                                            int i18 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver5 = hiddenActivity.f16339a;
                                            k.c(resultReceiver5);
                                            hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                            break;
                                    }
                                }
                            }) : null) == null) {
                                Log.i("HiddenActivity", "During save password, params is null, nothing to launch for create password");
                                finish();
                            }
                        }
                        break;
                    case 1980564212:
                        if (stringExtra.equals("SIGN_IN_INTENT")) {
                            M3.j jVar = (M3.j) getIntent().getParcelableExtra("REQUEST_TYPE");
                            if ((jVar != null ? new zbbg((Activity) this, new s()).getSignInIntent(jVar).addOnSuccessListener(new h(new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 3), 9)).addOnFailureListener(new OnFailureListener(this) { // from class: z1.b

                                /* JADX INFO: renamed from: b, reason: collision with root package name */
                                public final /* synthetic */ HiddenActivity f33270b;

                                {
                                    this.f33270b = this;
                                }

                                @Override // com.google.android.gms.tasks.OnFailureListener
                                public final void onFailure(Exception exc) {
                                    String str = "CREATE_UNKNOWN";
                                    String str2 = "GET_NO_CREDENTIALS";
                                    HiddenActivity hiddenActivity = this.f33270b;
                                    switch (i10) {
                                        case 0:
                                            int i15 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver2 = hiddenActivity.f16339a;
                                            k.c(resultReceiver2);
                                            hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                            break;
                                        case 1:
                                            int i16 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver3 = hiddenActivity.f16339a;
                                            k.c(resultReceiver3);
                                            hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                            break;
                                        case 2:
                                            int i17 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver4 = hiddenActivity.f16339a;
                                            k.c(resultReceiver4);
                                            hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                            break;
                                        default:
                                            int i18 = HiddenActivity.f16338c;
                                            k.f(hiddenActivity, "this$0");
                                            k.f(exc, "e");
                                            if ((exc instanceof j) && a.f23a.contains(Integer.valueOf(((j) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver5 = hiddenActivity.f16339a;
                                            k.c(resultReceiver5);
                                            hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                            break;
                                    }
                                }
                            }) : null) == null) {
                                Log.i("HiddenActivity", "During get sign-in intent, params is null, nothing to launch for get sign-in intent");
                                finish();
                            }
                        }
                        break;
                    default:
                        break;
                }
                return;
            }
            Log.w("HiddenActivity", "Activity handed an unsupported type");
            finish();
        }
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        k.f(bundle, "outState");
        bundle.putBoolean("androidx.credentials.playservices.AWAITING_RESULT", this.f16340b);
        super.onSaveInstanceState(bundle);
    }
}
