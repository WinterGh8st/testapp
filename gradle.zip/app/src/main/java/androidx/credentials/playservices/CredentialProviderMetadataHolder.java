package androidx.credentials.playservices;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import p097ha.k;
import p285z1.a;

/* JADX INFO: loaded from: classes.dex */
public final class CredentialProviderMetadataHolder extends Service {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final a f16337a = new a();

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        k.f(intent, "intent");
        return this.f16337a;
    }
}
