package androidx.slidingpanelayout.widget;

import E1.e;
import G1.b;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.WeakHashMap;
import p063f1.h;
import p102i2.c;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class SlidingPaneLayout extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f16998A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final Rect f16999B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final ArrayList f17000C;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f17001a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f17002b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Drawable f17003c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f17004d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f17005e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f17006f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public View f17007q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public float f17008r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public float f17009s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f17010t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f17011u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f17012v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public float f17013w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public float f17014x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final e f17015y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f17016z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public static final int[] f17017e = {R.attr.layout_weight};

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f17018a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f17019b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public boolean f17020c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public Paint f17021d;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f17018a = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f17017e);
            this.f17018a = typedArrayObtainStyledAttributes.getFloat(0, 0.0f);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public SlidingPaneLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f17001a = -858993460;
        this.f16998A = true;
        this.f16999B = new Rect();
        this.f17000C = new ArrayList();
        float f10 = context.getResources().getDisplayMetrics().density;
        this.f17005e = (int) ((32.0f * f10) + 0.5f);
        setWillNotDraw(false);
        U.q(this, new b(this));
        setImportantForAccessibility(1);
        e eVar = new e(getContext(), this, new a(this));
        eVar.f2916b = (int) (2.0f * eVar.f2916b);
        this.f17015y = eVar;
        eVar.f2927n = f10 * 400.0f;
    }

    public final void a(View view, float f10, int i10) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f10 <= 0.0f || i10 == 0) {
            if (view.getLayerType() != 0) {
                Paint paint = layoutParams.f17021d;
                if (paint != null) {
                    paint.setColorFilter(null);
                }
                p102i2.a aVar = new p102i2.a(this, view);
                this.f17000C.add(aVar);
                WeakHashMap weakHashMap = U.f27683a;
                postOnAnimation(aVar);
                return;
            }
            return;
        }
        int i11 = (((int) ((((-16777216) & i10) >>> 24) * f10)) << 24) | (i10 & 16777215);
        if (layoutParams.f17021d == null) {
            layoutParams.f17021d = new Paint();
        }
        layoutParams.f17021d.setColorFilter(new PorterDuffColorFilter(i11, PorterDuff.Mode.SRC_OVER));
        if (view.getLayerType() != 2) {
            view.setLayerType(2, layoutParams.f17021d);
        }
        Paint paint2 = ((LayoutParams) view.getLayoutParams()).f17021d;
        WeakHashMap weakHashMap2 = U.f27683a;
        view.setLayerPaint(paint2);
    }

    public final boolean b(View view) {
        if (view == null) {
            return false;
        }
        return this.f17006f && ((LayoutParams) view.getLayoutParams()).f17020c && this.f17008r > 0.0f;
    }

    public final boolean c() {
        WeakHashMap weakHashMap = U.f27683a;
        return getLayoutDirection() == 1;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public final void computeScroll() {
        e eVar = this.f17015y;
        if (eVar.h()) {
            if (!this.f17006f) {
                eVar.a();
            } else {
                WeakHashMap weakHashMap = U.f27683a;
                postInvalidateOnAnimation();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:9:0x001c  */
    public final void d(float f10) {
        boolean z3;
        boolean zC = c();
        LayoutParams layoutParams = (LayoutParams) this.f17007q.getLayoutParams();
        if (!layoutParams.f17020c) {
            z3 = false;
        } else if ((zC ? ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin : ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin) <= 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt != this.f17007q) {
                float f11 = 1.0f - this.f17009s;
                int i11 = this.f17012v;
                this.f17009s = f10;
                int i12 = ((int) (f11 * i11)) - ((int) ((1.0f - f10) * i11));
                if (zC) {
                    i12 = -i12;
                }
                childAt.offsetLeftAndRight(i12);
                if (z3) {
                    float f12 = this.f17009s;
                    a(childAt, zC ? f12 - 1.0f : 1.0f - f12, this.f17002b);
                }
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i10;
        int right;
        super.draw(canvas);
        Drawable drawable = c() ? this.f17004d : this.f17003c;
        View childAt = getChildCount() > 1 ? getChildAt(1) : null;
        if (childAt == null || drawable == null) {
            return;
        }
        int top = childAt.getTop();
        int bottom = childAt.getBottom();
        int intrinsicWidth = drawable.getIntrinsicWidth();
        if (c()) {
            right = childAt.getRight();
            i10 = intrinsicWidth + right;
        } else {
            int left = childAt.getLeft();
            int i11 = left - intrinsicWidth;
            i10 = left;
            right = i11;
        }
        drawable.setBounds(right, top, i10, bottom);
        drawable.draw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int iSave = canvas.save();
        if (this.f17006f && !layoutParams.f17019b && this.f17007q != null) {
            Rect rect = this.f16999B;
            canvas.getClipBounds(rect);
            if (c()) {
                rect.left = Math.max(rect.left, this.f17007q.getRight());
            } else {
                rect.right = Math.min(rect.right, this.f17007q.getLeft());
            }
            canvas.clipRect(rect);
        }
        boolean zDrawChild = super.drawChild(canvas, view, j10);
        canvas.restoreToCount(iSave);
        return zDrawChild;
    }

    public final boolean e(float f10) {
        int paddingLeft;
        if (this.f17006f) {
            boolean zC = c();
            LayoutParams layoutParams = (LayoutParams) this.f17007q.getLayoutParams();
            if (zC) {
                int paddingRight = getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
                paddingLeft = (int) (getWidth() - (((f10 * this.f17010t) + paddingRight) + this.f17007q.getWidth()));
            } else {
                paddingLeft = (int) ((f10 * this.f17010t) + getPaddingLeft() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin);
            }
            View view = this.f17007q;
            if (this.f17015y.u(view, paddingLeft, view.getTop())) {
                int childCount = getChildCount();
                for (int i10 = 0; i10 < childCount; i10++) {
                    View childAt = getChildAt(i10);
                    if (childAt.getVisibility() == 4) {
                        childAt.setVisibility(0);
                    }
                }
                WeakHashMap weakHashMap = U.f27683a;
                postInvalidateOnAnimation();
                return true;
            }
        }
        return false;
    }

    public final void f(View view) {
        int left;
        int right;
        int top;
        int bottom;
        View childAt;
        View view2 = view;
        boolean zC = c();
        int width = zC ? getWidth() - getPaddingRight() : getPaddingLeft();
        int paddingLeft = zC ? getPaddingLeft() : getWidth() - getPaddingRight();
        int paddingTop = getPaddingTop();
        int height = getHeight() - getPaddingBottom();
        if (view2 == null || !view2.isOpaque()) {
            left = 0;
            right = 0;
            top = 0;
            bottom = 0;
        } else {
            left = view2.getLeft();
            right = view2.getRight();
            top = view2.getTop();
            bottom = view2.getBottom();
        }
        int childCount = getChildCount();
        int i10 = 0;
        while (i10 < childCount && (childAt = getChildAt(i10)) != view2) {
            if (childAt.getVisibility() != 8) {
                childAt.setVisibility((Math.max(zC ? paddingLeft : width, childAt.getLeft()) < left || Math.max(paddingTop, childAt.getTop()) < top || Math.min(zC ? width : paddingLeft, childAt.getRight()) > right || Math.min(height, childAt.getBottom()) > bottom) ? 0 : 4);
            }
            i10++;
            view2 = view;
            zC = zC;
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        LayoutParams layoutParams = new LayoutParams(-1, -1);
        layoutParams.f17018a = 0.0f;
        return layoutParams;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            LayoutParams layoutParams2 = new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams);
            layoutParams2.f17018a = 0.0f;
            return layoutParams2;
        }
        LayoutParams layoutParams3 = new LayoutParams(layoutParams);
        layoutParams3.f17018a = 0.0f;
        return layoutParams3;
    }

    public int getCoveredFadeColor() {
        return this.f17002b;
    }

    public int getParallaxDistance() {
        return this.f17012v;
    }

    public int getSliderFadeColor() {
        return this.f17001a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f16998A = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f16998A = true;
        ArrayList arrayList = this.f17000C;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            ((p102i2.a) arrayList.get(i10)).run();
        }
        arrayList.clear();
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        View childAt;
        int actionMasked = motionEvent.getActionMasked();
        boolean z5 = this.f17006f;
        e eVar = this.f17015y;
        if (!z5 && actionMasked == 0 && getChildCount() > 1 && (childAt = getChildAt(1)) != null) {
            int x10 = (int) motionEvent.getX();
            int y10 = (int) motionEvent.getY();
            eVar.getClass();
            this.f17016z = !e.l(childAt, x10, y10);
        }
        if (!this.f17006f || (this.f17011u && actionMasked != 0)) {
            eVar.b();
            return super.onInterceptTouchEvent(motionEvent);
        }
        if (actionMasked == 3 || actionMasked == 1) {
            eVar.b();
            return false;
        }
        if (actionMasked == 0) {
            this.f17011u = false;
            float x11 = motionEvent.getX();
            float y11 = motionEvent.getY();
            this.f17013w = x11;
            this.f17014x = y11;
            eVar.getClass();
            if (e.l(this.f17007q, (int) x11, (int) y11) && b(this.f17007q)) {
                z3 = true;
            }
            return !eVar.t(motionEvent) || z3;
        }
        if (actionMasked == 2) {
            float x12 = motionEvent.getX();
            float y12 = motionEvent.getY();
            float fAbs = Math.abs(x12 - this.f17013w);
            float fAbs2 = Math.abs(y12 - this.f17014x);
            if (fAbs > eVar.f2916b && fAbs2 > fAbs) {
                eVar.b();
                this.f17011u = true;
                return false;
            }
        }
        z3 = false;
        if (eVar.t(motionEvent)) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:47:0x00bb  */
    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        boolean zC = c();
        e eVar = this.f17015y;
        if (zC) {
            eVar.f2930q = 2;
        } else {
            eVar.f2930q = 1;
        }
        int i19 = i12 - i10;
        int paddingRight = zC ? getPaddingRight() : getPaddingLeft();
        int paddingLeft = zC ? getPaddingLeft() : getPaddingRight();
        int paddingTop = getPaddingTop();
        int childCount = getChildCount();
        if (this.f16998A) {
            this.f17008r = (this.f17006f && this.f17016z) ? 1.0f : 0.0f;
        }
        int i20 = paddingRight;
        for (int i21 = 0; i21 < childCount; i21++) {
            View childAt = getChildAt(i21);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                if (layoutParams.f17019b) {
                    int i22 = i19 - paddingLeft;
                    int iMin = (Math.min(paddingRight, i22 - this.f17005e) - i20) - (((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin);
                    this.f17010t = iMin;
                    int i23 = zC ? ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin : ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
                    layoutParams.f17020c = (measuredWidth / 2) + ((i20 + i23) + iMin) > i22;
                    float f10 = iMin;
                    int i24 = (int) (this.f17008r * f10);
                    i14 = i23 + i24 + i20;
                    this.f17008r = i24 / f10;
                } else {
                    if (!this.f17006f || (i15 = this.f17012v) == 0) {
                        i14 = paddingRight;
                    } else {
                        i16 = (int) ((1.0f - this.f17008r) * i15);
                        i14 = paddingRight;
                    }
                    if (zC) {
                        i18 = (i19 - i14) + i16;
                        i17 = i18 - measuredWidth;
                    } else {
                        i17 = i14 - i16;
                        i18 = i17 + measuredWidth;
                    }
                    childAt.layout(i17, paddingTop, i18, childAt.getMeasuredHeight() + paddingTop);
                    i20 = i14;
                    paddingRight = childAt.getWidth() + paddingRight;
                }
                i16 = 0;
                if (zC) {
                    i18 = (i19 - i14) + i16;
                    i17 = i18 - measuredWidth;
                } else {
                    i17 = i14 - i16;
                    i18 = i17 + measuredWidth;
                }
                childAt.layout(i17, paddingTop, i18, childAt.getMeasuredHeight() + paddingTop);
                i20 = i14;
                paddingRight = childAt.getWidth() + paddingRight;
            }
        }
        if (this.f16998A) {
            if (this.f17006f) {
                if (this.f17012v != 0) {
                    d(this.f17008r);
                }
                if (((LayoutParams) this.f17007q.getLayoutParams()).f17020c) {
                    a(this.f17007q, this.f17008r, this.f17001a);
                }
            } else {
                for (int i25 = 0; i25 < childCount; i25++) {
                    a(getChildAt(i25), 0.0f, this.f17001a);
                }
            }
            f(this.f17007q);
        }
        this.f16998A = false;
    }

    /* JADX WARN: Code duplicated, block: B:132:0x0111 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:40:0x00ab A[PHI: r13
  0x00ab: PHI (r13v2 float) = (r13v1 float), (r13v3 float) binds: [B:36:0x00a3, B:38:0x00a8] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:42:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:43:0x00c0  */
    /* JADX WARN: Code duplicated, block: B:45:0x00c3  */
    /* JADX WARN: Code duplicated, block: B:46:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:49:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:50:0x00df  */
    /* JADX WARN: Code duplicated, block: B:52:0x00e2  */
    /* JADX WARN: Code duplicated, block: B:53:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:60:0x0107  */
    /* JADX WARN: Code duplicated, block: B:61:0x0109  */
    /* JADX WARN: Code duplicated, block: B:64:0x010f  */
    /* JADX WARN: Code duplicated, block: B:73:0x0131  */
    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        int paddingTop;
        int iMin;
        int i12;
        int i13;
        int i14;
        int iMakeMeasureSpec;
        int i15;
        int iMakeMeasureSpec2;
        int i16;
        int i17;
        int iMakeMeasureSpec3;
        int i18;
        int iMakeMeasureSpec4;
        int measuredHeight;
        boolean z3;
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mode != 1073741824) {
            if (!isInEditMode()) {
                throw new IllegalStateException("Width must have an exact value or MATCH_PARENT");
            }
            if (mode != Integer.MIN_VALUE && mode == 0) {
                size = 300;
            }
        } else if (mode2 == 0) {
            if (!isInEditMode()) {
                throw new IllegalStateException("Height must not be UNSPECIFIED");
            }
            if (mode2 == 0) {
                size2 = 300;
                mode2 = Integer.MIN_VALUE;
            }
        }
        boolean z5 = false;
        if (mode2 != Integer.MIN_VALUE) {
            iMin = mode2 != 1073741824 ? 0 : (size2 - getPaddingTop()) - getPaddingBottom();
            paddingTop = iMin;
        } else {
            paddingTop = (size2 - getPaddingTop()) - getPaddingBottom();
            iMin = 0;
        }
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int childCount = getChildCount();
        if (childCount > 2) {
            Log.e("SlidingPaneLayout", "onMeasure: More than two child views are not supported.");
        }
        this.f17007q = null;
        int i19 = 0;
        boolean z10 = false;
        int i20 = paddingLeft;
        float f10 = 0.0f;
        while (true) {
            i12 = 8;
            if (i19 >= childCount) {
                break;
            }
            View childAt = getChildAt(i19);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (childAt.getVisibility() == 8) {
                layoutParams.f17020c = z5;
            } else {
                float f11 = layoutParams.f17018a;
                if (f11 > 0.0f) {
                    f10 += f11;
                    if (((ViewGroup.MarginLayoutParams) layoutParams).width != 0) {
                        i16 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
                        i17 = ((ViewGroup.MarginLayoutParams) layoutParams).width;
                        if (i17 == -2) {
                            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i16, Integer.MIN_VALUE);
                        } else if (i17 == -1) {
                            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i16, 1073741824);
                        } else {
                            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i17, 1073741824);
                        }
                        i18 = ((ViewGroup.MarginLayoutParams) layoutParams).height;
                        if (i18 == -2) {
                            iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(paddingTop, Integer.MIN_VALUE);
                        } else if (i18 == -1) {
                            iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(paddingTop, 1073741824);
                        } else {
                            iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(i18, 1073741824);
                        }
                        childAt.measure(iMakeMeasureSpec3, iMakeMeasureSpec4);
                        int measuredWidth = childAt.getMeasuredWidth();
                        measuredHeight = childAt.getMeasuredHeight();
                        if (mode2 == Integer.MIN_VALUE && measuredHeight > iMin) {
                            iMin = Math.min(measuredHeight, paddingTop);
                        }
                        i20 -= measuredWidth;
                        if (i20 < 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        layoutParams.f17019b = z3;
                        z10 |= z3;
                        if (z3) {
                            this.f17007q = childAt;
                        }
                    }
                } else {
                    i16 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
                    i17 = ((ViewGroup.MarginLayoutParams) layoutParams).width;
                    if (i17 == -2) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i16, Integer.MIN_VALUE);
                    } else if (i17 == -1) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(paddingLeft - i16, 1073741824);
                    } else {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i17, 1073741824);
                    }
                    i18 = ((ViewGroup.MarginLayoutParams) layoutParams).height;
                    if (i18 == -2) {
                        iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(paddingTop, Integer.MIN_VALUE);
                    } else if (i18 == -1) {
                        iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(paddingTop, 1073741824);
                    } else {
                        iMakeMeasureSpec4 = View.MeasureSpec.makeMeasureSpec(i18, 1073741824);
                    }
                    childAt.measure(iMakeMeasureSpec3, iMakeMeasureSpec4);
                    int measuredWidth2 = childAt.getMeasuredWidth();
                    measuredHeight = childAt.getMeasuredHeight();
                    if (mode2 == Integer.MIN_VALUE) {
                        iMin = Math.min(measuredHeight, paddingTop);
                    }
                    i20 -= measuredWidth2;
                    if (i20 < 0) {
                        z3 = true;
                    } else {
                        z3 = false;
                    }
                    layoutParams.f17019b = z3;
                    z10 |= z3;
                    if (z3) {
                        this.f17007q = childAt;
                    }
                }
            }
            i19++;
            z5 = false;
        }
        if (z10 || f10 > 0.0f) {
            int i21 = paddingLeft - this.f17005e;
            int i22 = 0;
            while (i22 < childCount) {
                View childAt2 = getChildAt(i22);
                if (childAt2.getVisibility() == i12) {
                    i13 = i22;
                } else {
                    LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                    if (childAt2.getVisibility() == i12) {
                        i13 = i22;
                    } else {
                        int i23 = ((ViewGroup.MarginLayoutParams) layoutParams2).width;
                        float f12 = layoutParams2.f17018a;
                        boolean z11 = i23 == 0 && f12 > 0.0f;
                        int measuredWidth3 = z11 ? 0 : childAt2.getMeasuredWidth();
                        i13 = i22;
                        if (!z10 || childAt2 == this.f17007q) {
                            if (f12 > 0.0f) {
                                if (((ViewGroup.MarginLayoutParams) layoutParams2).width == 0) {
                                    int i24 = ((ViewGroup.MarginLayoutParams) layoutParams2).height;
                                    if (i24 == -2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(paddingTop, Integer.MIN_VALUE);
                                        i14 = 1073741824;
                                    } else if (i24 == -1) {
                                        i14 = 1073741824;
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(paddingTop, 1073741824);
                                    } else {
                                        i14 = 1073741824;
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i24, 1073741824);
                                    }
                                } else {
                                    i14 = 1073741824;
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(childAt2.getMeasuredHeight(), 1073741824);
                                }
                                if (z10) {
                                    int i25 = paddingLeft - (((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin);
                                    int iMakeMeasureSpec5 = View.MeasureSpec.makeMeasureSpec(i25, i14);
                                    if (measuredWidth3 != i25) {
                                        childAt2.measure(iMakeMeasureSpec5, iMakeMeasureSpec);
                                    }
                                } else {
                                    childAt2.measure(View.MeasureSpec.makeMeasureSpec(measuredWidth3 + ((int) ((f12 * Math.max(0, i20)) / f10)), 1073741824), iMakeMeasureSpec);
                                }
                            }
                        } else if (((ViewGroup.MarginLayoutParams) layoutParams2).width < 0 && (measuredWidth3 > i21 || f12 > 0.0f)) {
                            if (z11) {
                                int i26 = ((ViewGroup.MarginLayoutParams) layoutParams2).height;
                                if (i26 == -2) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(paddingTop, Integer.MIN_VALUE);
                                    i15 = 1073741824;
                                } else if (i26 == -1) {
                                    i15 = 1073741824;
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(paddingTop, 1073741824);
                                } else {
                                    i15 = 1073741824;
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i26, 1073741824);
                                }
                            } else {
                                i15 = 1073741824;
                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(childAt2.getMeasuredHeight(), 1073741824);
                            }
                            childAt2.measure(View.MeasureSpec.makeMeasureSpec(i21, i15), iMakeMeasureSpec2);
                        }
                    }
                }
                i22 = i13 + 1;
                i12 = 8;
            }
        }
        setMeasuredDimension(size, getPaddingBottom() + getPaddingTop() + iMin);
        this.f17006f = z10;
        e eVar = this.f17015y;
        if (eVar.f2915a == 0 || z10) {
            return;
        }
        eVar.a();
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        c cVar = (c) parcelable;
        super.onRestoreInstanceState(cVar.f2402a);
        if (cVar.f23538c) {
            if (this.f16998A || e(1.0f)) {
                this.f17016z = true;
            }
        } else if (this.f16998A || e(0.0f)) {
            this.f17016z = false;
        }
        this.f17016z = cVar.f23538c;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        boolean z3;
        c cVar = new c(super.onSaveInstanceState());
        boolean z5 = this.f17006f;
        if (z5) {
            z3 = !z5 || this.f17008r == 1.0f;
        } else {
            z3 = this.f17016z;
        }
        cVar.f23538c = z3;
        return cVar;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i10, int i11, int i12, int i13) {
        super.onSizeChanged(i10, i11, i12, i13);
        if (i10 != i12) {
            this.f16998A = true;
        }
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.f17006f) {
            return super.onTouchEvent(motionEvent);
        }
        e eVar = this.f17015y;
        eVar.m(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            this.f17013w = x10;
            this.f17014x = y10;
            return true;
        }
        if (actionMasked == 1 && b(this.f17007q)) {
            float x11 = motionEvent.getX();
            float y11 = motionEvent.getY();
            float f10 = x11 - this.f17013w;
            float f11 = y11 - this.f17014x;
            int i10 = eVar.f2916b;
            if ((f11 * f11) + (f10 * f10) < i10 * i10 && e.l(this.f17007q, (int) x11, (int) y11) && (this.f16998A || e(0.0f))) {
                this.f17016z = false;
            }
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        if (isInTouchMode() || this.f17006f) {
            return;
        }
        this.f17016z = view == this.f17007q;
    }

    public void setCoveredFadeColor(int i10) {
        this.f17002b = i10;
    }

    public void setParallaxDistance(int i10) {
        this.f17012v = i10;
        requestLayout();
    }

    @Deprecated
    public void setShadowDrawable(Drawable drawable) {
        setShadowDrawableLeft(drawable);
    }

    public void setShadowDrawableLeft(Drawable drawable) {
        this.f17003c = drawable;
    }

    public void setShadowDrawableRight(Drawable drawable) {
        this.f17004d = drawable;
    }

    @Deprecated
    public void setShadowResource(int i10) {
        setShadowDrawable(getResources().getDrawable(i10));
    }

    public void setShadowResourceLeft(int i10) {
        setShadowDrawableLeft(h.getDrawable(getContext(), i10));
    }

    public void setShadowResourceRight(int i10) {
        setShadowDrawableRight(h.getDrawable(getContext(), i10));
    }

    public void setSliderFadeColor(int i10) {
        this.f17001a = i10;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public void setPanelSlideListener(p102i2.b bVar) {
    }
}
