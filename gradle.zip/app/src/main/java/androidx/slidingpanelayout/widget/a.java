package androidx.slidingpanelayout.widget;

import android.view.View;
import android.view.ViewGroup;
import p016b3.AbstractC0862l;

/* JADX INFO: loaded from: classes.dex */
public final class a extends AbstractC0862l {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ SlidingPaneLayout f17022c;

    public a(SlidingPaneLayout slidingPaneLayout) {
        this.f17022c = slidingPaneLayout;
    }

    @Override // p016b3.AbstractC0862l
    public final int O(View view) {
        return this.f17022c.f17010t;
    }

    @Override // p016b3.AbstractC0862l
    public final void b0(int i10, int i11) {
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        slidingPaneLayout.f17015y.c(slidingPaneLayout.f17007q, i11);
    }

    @Override // p016b3.AbstractC0862l
    public final void d0(View view, int i10) {
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        int childCount = slidingPaneLayout.getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = slidingPaneLayout.getChildAt(i11);
            if (childAt.getVisibility() == 4) {
                childAt.setVisibility(0);
            }
        }
    }

    @Override // p016b3.AbstractC0862l
    public final void e0(int i10) {
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        if (slidingPaneLayout.f17015y.f2915a == 0) {
            if (slidingPaneLayout.f17008r != 0.0f) {
                slidingPaneLayout.sendAccessibilityEvent(32);
                slidingPaneLayout.f17016z = true;
            } else {
                slidingPaneLayout.f(slidingPaneLayout.f17007q);
                slidingPaneLayout.sendAccessibilityEvent(32);
                slidingPaneLayout.f17016z = false;
            }
        }
    }

    @Override // p016b3.AbstractC0862l
    public final void f0(View view, int i10, int i11) {
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        if (slidingPaneLayout.f17007q == null) {
            slidingPaneLayout.f17008r = 0.0f;
        } else {
            boolean zC = slidingPaneLayout.c();
            SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) slidingPaneLayout.f17007q.getLayoutParams();
            int width = slidingPaneLayout.f17007q.getWidth();
            if (zC) {
                i10 = (slidingPaneLayout.getWidth() - i10) - width;
            }
            float paddingRight = (i10 - ((zC ? slidingPaneLayout.getPaddingRight() : slidingPaneLayout.getPaddingLeft()) + (zC ? ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin : ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin))) / slidingPaneLayout.f17010t;
            slidingPaneLayout.f17008r = paddingRight;
            if (slidingPaneLayout.f17012v != 0) {
                slidingPaneLayout.d(paddingRight);
            }
            if (layoutParams.f17020c) {
                slidingPaneLayout.a(slidingPaneLayout.f17007q, slidingPaneLayout.f17008r, slidingPaneLayout.f17001a);
            }
        }
        slidingPaneLayout.invalidate();
    }

    @Override // p016b3.AbstractC0862l
    public final void g0(View view, float f10, float f11) {
        int paddingLeft;
        SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) view.getLayoutParams();
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        if (slidingPaneLayout.c()) {
            int paddingRight = slidingPaneLayout.getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
            if (f10 < 0.0f || (f10 == 0.0f && slidingPaneLayout.f17008r > 0.5f)) {
                paddingRight += slidingPaneLayout.f17010t;
            }
            paddingLeft = (slidingPaneLayout.getWidth() - paddingRight) - slidingPaneLayout.f17007q.getWidth();
        } else {
            paddingLeft = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + slidingPaneLayout.getPaddingLeft();
            if (f10 > 0.0f || (f10 == 0.0f && slidingPaneLayout.f17008r > 0.5f)) {
                paddingLeft += slidingPaneLayout.f17010t;
            }
        }
        slidingPaneLayout.f17015y.s(paddingLeft, view.getTop());
        slidingPaneLayout.invalidate();
    }

    @Override // p016b3.AbstractC0862l
    public final boolean p0(View view, int i10) {
        if (this.f17022c.f17011u) {
            return false;
        }
        return ((SlidingPaneLayout.LayoutParams) view.getLayoutParams()).f17019b;
    }

    @Override // p016b3.AbstractC0862l
    public final int w(View view, int i10) {
        SlidingPaneLayout slidingPaneLayout = this.f17022c;
        SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams) slidingPaneLayout.f17007q.getLayoutParams();
        if (!slidingPaneLayout.c()) {
            int paddingLeft = slidingPaneLayout.getPaddingLeft() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
            return Math.min(Math.max(i10, paddingLeft), slidingPaneLayout.f17010t + paddingLeft);
        }
        int width = slidingPaneLayout.getWidth() - (slidingPaneLayout.f17007q.getWidth() + (slidingPaneLayout.getPaddingRight() + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin));
        return Math.max(Math.min(i10, width), width - slidingPaneLayout.f17010t);
    }

    @Override // p016b3.AbstractC0862l
    public final int x(View view, int i10) {
        return view.getTop();
    }
}
