package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import p2.a;
import p2.b;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f16295a = aVar.f(iconCompat.f16295a, 1);
        byte[] bArr = iconCompat.f16297c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f26632e;
            int i10 = parcel.readInt();
            if (i10 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i10];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f16297c = bArr;
        iconCompat.f16298d = aVar.g(iconCompat.f16298d, 3);
        iconCompat.f16299e = aVar.f(iconCompat.f16299e, 4);
        iconCompat.f16300f = aVar.f(iconCompat.f16300f, 5);
        iconCompat.f16301g = (ColorStateList) aVar.g(iconCompat.f16301g, 6);
        String string = iconCompat.f16303i;
        if (aVar.e(7)) {
            string = ((b) aVar).f26632e.readString();
        }
        iconCompat.f16303i = string;
        String string2 = iconCompat.f16304j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f26632e.readString();
        }
        iconCompat.f16304j = string2;
        iconCompat.f16302h = PorterDuff.Mode.valueOf(iconCompat.f16303i);
        switch (iconCompat.f16295a) {
            case -1:
                Parcelable parcelable = iconCompat.f16298d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f16296b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.f16298d;
                if (parcelable2 != null) {
                    iconCompat.f16296b = parcelable2;
                    return iconCompat;
                }
                byte[] bArr3 = iconCompat.f16297c;
                iconCompat.f16296b = bArr3;
                iconCompat.f16295a = 3;
                iconCompat.f16299e = 0;
                iconCompat.f16300f = bArr3.length;
                return iconCompat;
            case 2:
            case 4:
            case 6:
                String str = new String(iconCompat.f16297c, Charset.forName("UTF-16"));
                iconCompat.f16296b = str;
                if (iconCompat.f16295a == 2 && iconCompat.f16304j == null) {
                    iconCompat.f16304j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f16296b = iconCompat.f16297c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f16303i = iconCompat.f16302h.name();
        switch (iconCompat.f16295a) {
            case -1:
                iconCompat.f16298d = (Parcelable) iconCompat.f16296b;
                break;
            case 1:
            case 5:
                iconCompat.f16298d = (Parcelable) iconCompat.f16296b;
                break;
            case 2:
                iconCompat.f16297c = ((String) iconCompat.f16296b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f16297c = (byte[]) iconCompat.f16296b;
                break;
            case 4:
            case 6:
                iconCompat.f16297c = iconCompat.f16296b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i10 = iconCompat.f16295a;
        if (-1 != i10) {
            aVar.j(i10, 1);
        }
        byte[] bArr = iconCompat.f16297c;
        if (bArr != null) {
            aVar.i(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f26632e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f16298d;
        if (parcelable != null) {
            aVar.i(3);
            ((b) aVar).f26632e.writeParcelable(parcelable, 0);
        }
        int i11 = iconCompat.f16299e;
        if (i11 != 0) {
            aVar.j(i11, 4);
        }
        int i12 = iconCompat.f16300f;
        if (i12 != 0) {
            aVar.j(i12, 5);
        }
        ColorStateList colorStateList = iconCompat.f16301g;
        if (colorStateList != null) {
            aVar.i(6);
            ((b) aVar).f26632e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f16303i;
        if (str != null) {
            aVar.i(7);
            ((b) aVar).f26632e.writeString(str);
        }
        String str2 = iconCompat.f16304j;
        if (str2 != null) {
            aVar.i(8);
            ((b) aVar).f26632e.writeString(str2);
        }
    }
}
