package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.net.Uri;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.lang.reflect.InvocationTargetException;
import p101i1.c;
import p101i1.e;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {
    public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16295a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Object f16296b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f16297c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f16298d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16299e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16300f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f16301g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f16302h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f16303i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f16304j;

    public IconCompat() {
        this.f16295a = -1;
        this.f16297c = null;
        this.f16298d = null;
        this.f16299e = 0;
        this.f16300f = 0;
        this.f16301g = null;
        this.f16302h = k;
        this.f16303i = null;
    }

    public static Bitmap a(Bitmap bitmap, boolean z3) {
        int iMin = (int) (Math.min(bitmap.getWidth(), bitmap.getHeight()) * 0.6666667f);
        Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iMin, iMin, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmapCreateBitmap);
        Paint paint = new Paint(3);
        float f10 = iMin;
        float f11 = 0.5f * f10;
        float f12 = 0.9166667f * f11;
        if (z3) {
            float f13 = 0.010416667f * f10;
            paint.setColor(0);
            paint.setShadowLayer(f13, 0.0f, f10 * 0.020833334f, 1023410176);
            canvas.drawCircle(f11, f11, f12, paint);
            paint.setShadowLayer(f13, 0.0f, 0.0f, 503316480);
            canvas.drawCircle(f11, f11, f12, paint);
            paint.clearShadowLayer();
        }
        paint.setColor(-16777216);
        Shader.TileMode tileMode = Shader.TileMode.CLAMP;
        BitmapShader bitmapShader = new BitmapShader(bitmap, tileMode, tileMode);
        Matrix matrix = new Matrix();
        matrix.setTranslate((-(bitmap.getWidth() - iMin)) / 2.0f, (-(bitmap.getHeight() - iMin)) / 2.0f);
        bitmapShader.setLocalMatrix(matrix);
        paint.setShader(bitmapShader);
        canvas.drawCircle(f11, f11, f12, paint);
        canvas.setBitmap(null);
        return bitmapCreateBitmap;
    }

    public static IconCompat b(int i10) {
        if (i10 == 0) {
            throw new IllegalArgumentException("Drawable resource ID must not be 0");
        }
        IconCompat iconCompat = new IconCompat(2);
        iconCompat.f16299e = i10;
        iconCompat.f16296b = "";
        iconCompat.f16304j = "";
        return iconCompat;
    }

    public final int c() {
        int i10 = this.f16295a;
        if (i10 != -1) {
            if (i10 == 2) {
                return this.f16299e;
            }
            throw new IllegalStateException("called getResId() on " + this);
        }
        int i11 = Build.VERSION.SDK_INT;
        Object obj = this.f16296b;
        if (i11 >= 28) {
            return e.a(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getResId", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e10) {
            Log.e("IconCompat", "Unable to get icon resource", e10);
            return 0;
        } catch (NoSuchMethodException e11) {
            Log.e("IconCompat", "Unable to get icon resource", e11);
            return 0;
        } catch (InvocationTargetException e12) {
            Log.e("IconCompat", "Unable to get icon resource", e12);
            return 0;
        }
    }

    public final int d() {
        int i10 = this.f16295a;
        if (i10 != -1) {
            return i10;
        }
        int i11 = Build.VERSION.SDK_INT;
        Object obj = this.f16296b;
        if (i11 >= 28) {
            return e.c(obj);
        }
        try {
            return ((Integer) obj.getClass().getMethod("getType", null).invoke(obj, null)).intValue();
        } catch (IllegalAccessException e10) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e10);
            return -1;
        } catch (NoSuchMethodException e11) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e11);
            return -1;
        } catch (InvocationTargetException e12) {
            Log.e("IconCompat", "Unable to get icon type " + obj, e12);
            return -1;
        }
    }

    public final Uri e() {
        int i10 = this.f16295a;
        if (i10 == -1) {
            return c.a(this.f16296b);
        }
        if (i10 == 4 || i10 == 6) {
            return Uri.parse((String) this.f16296b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public final String toString() {
        String str;
        if (this.f16295a == -1) {
            return String.valueOf(this.f16296b);
        }
        StringBuilder sb2 = new StringBuilder("Icon(typ=");
        switch (this.f16295a) {
            case 1:
                str = "BITMAP";
                break;
            case 2:
                str = "RESOURCE";
                break;
            case 3:
                str = "DATA";
                break;
            case 4:
                str = "URI";
                break;
            case 5:
                str = "BITMAP_MASKABLE";
                break;
            case 6:
                str = "URI_MASKABLE";
                break;
            default:
                str = "UNKNOWN";
                break;
        }
        sb2.append(str);
        switch (this.f16295a) {
            case 1:
            case 5:
                sb2.append(" size=");
                sb2.append(((Bitmap) this.f16296b).getWidth());
                sb2.append("x");
                sb2.append(((Bitmap) this.f16296b).getHeight());
                break;
            case 2:
                sb2.append(" pkg=");
                sb2.append(this.f16304j);
                sb2.append(" id=");
                sb2.append(String.format("0x%08x", Integer.valueOf(c())));
                break;
            case 3:
                sb2.append(" len=");
                sb2.append(this.f16299e);
                if (this.f16300f != 0) {
                    sb2.append(" off=");
                    sb2.append(this.f16300f);
                }
                break;
            case 4:
            case 6:
                sb2.append(" uri=");
                sb2.append(this.f16296b);
                break;
        }
        if (this.f16301g != null) {
            sb2.append(" tint=");
            sb2.append(this.f16301g);
        }
        if (this.f16302h != k) {
            sb2.append(" mode=");
            sb2.append(this.f16302h);
        }
        sb2.append(")");
        return sb2.toString();
    }

    public IconCompat(int i10) {
        this.f16297c = null;
        this.f16298d = null;
        this.f16299e = 0;
        this.f16300f = 0;
        this.f16301g = null;
        this.f16302h = k;
        this.f16303i = null;
        this.f16295a = i10;
    }
}
