package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import p2.a;
import p2.b;
import p2.c;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVarH = remoteActionCompat.f16289a;
        boolean z3 = true;
        if (aVar.e(1)) {
            cVarH = aVar.h();
        }
        remoteActionCompat.f16289a = (IconCompat) cVarH;
        CharSequence charSequence = remoteActionCompat.f16290b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f26632e);
        }
        remoteActionCompat.f16290b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f16291c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f26632e);
        }
        remoteActionCompat.f16291c = charSequence2;
        remoteActionCompat.f16292d = (PendingIntent) aVar.g(remoteActionCompat.f16292d, 4);
        boolean z5 = remoteActionCompat.f16293e;
        if (aVar.e(5)) {
            z5 = ((b) aVar).f26632e.readInt() != 0;
        }
        remoteActionCompat.f16293e = z5;
        boolean z10 = remoteActionCompat.f16294f;
        if (!aVar.e(6)) {
            z3 = z10;
        } else if (((b) aVar).f26632e.readInt() == 0) {
            z3 = false;
        }
        remoteActionCompat.f16294f = z3;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f16289a;
        aVar.i(1);
        aVar.k(iconCompat);
        CharSequence charSequence = remoteActionCompat.f16290b;
        aVar.i(2);
        Parcel parcel = ((b) aVar).f26632e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f16291c;
        aVar.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f16292d;
        aVar.i(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z3 = remoteActionCompat.f16293e;
        aVar.i(5);
        parcel.writeInt(z3 ? 1 : 0);
        boolean z5 = remoteActionCompat.f16294f;
        aVar.i(6);
        parcel.writeInt(z5 ? 1 : 0);
    }
}
