package androidx.core.widget;

import C9.C0077b0;
import L.C0499e0;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
import java.util.WeakHashMap;
import p197qa.h;
import p200r1.A;
import p200r1.AbstractC1498z;
import p200r1.B;
import p200r1.C1481h;
import p200r1.C1488o;
import p200r1.H;
import p200r1.InterfaceC1487n;
import p200r1.InterfaceC1490q;
import p200r1.U;
import p200r1.X;
import p200r1.Y;
import p273y1.f;
import p273y1.i;
import p273y1.j;
import p273y1.k;
import vb.a;

/* JADX INFO: loaded from: classes.dex */
public class NestedScrollView extends FrameLayout implements InterfaceC1490q, InterfaceC1487n {

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final float f16308L = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final C0077b0 M = new C0077b0(5);

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final int[] f16309N = {R.attr.fillViewport};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f16310A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f16311B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final int[] f16312C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int[] f16313D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f16314E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f16315F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public k f16316G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final C0499e0 f16317H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final C1488o f16318I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public float f16319J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final C1481h f16320K;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final float f16321a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public long f16322b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Rect f16323c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final OverScroller f16324d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final EdgeEffect f16325e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final EdgeEffect f16326f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f16327q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f16328r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f16329s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public View f16330t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f16331u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public VelocityTracker f16332v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f16333w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f16334x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f16335y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f16336z;

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, com.flamingotools.ws.R.attr.nestedScrollViewStyle);
        this.f16323c = new Rect();
        this.f16328r = true;
        this.f16329s = false;
        this.f16330t = null;
        this.f16331u = false;
        this.f16334x = true;
        this.f16311B = -1;
        this.f16312C = new int[2];
        this.f16313D = new int[2];
        this.f16320K = new C1481h(getContext(), new a(this));
        int i10 = Build.VERSION.SDK_INT;
        this.f16325e = i10 >= 31 ? f.a(context, attributeSet) : new EdgeEffect(context);
        this.f16326f = i10 >= 31 ? f.a(context, attributeSet) : new EdgeEffect(context);
        this.f16321a = context.getResources().getDisplayMetrics().density * 160.0f * 386.0878f * 0.84f;
        this.f16324d = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f16335y = viewConfiguration.getScaledTouchSlop();
        this.f16336z = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f16310A = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f16309N, com.flamingotools.ws.R.attr.nestedScrollViewStyle, 0);
        setFillViewport(typedArrayObtainStyledAttributes.getBoolean(0, false));
        typedArrayObtainStyledAttributes.recycle();
        this.f16317H = new C0499e0();
        this.f16318I = new C1488o(this);
        setNestedScrollingEnabled(true);
        U.q(this, M);
    }

    public static boolean l(View view, NestedScrollView nestedScrollView) {
        if (view == nestedScrollView) {
            return true;
        }
        Object parent = view.getParent();
        return (parent instanceof ViewGroup) && l((View) parent, nestedScrollView);
    }

    @Override // p200r1.InterfaceC1489p
    public final void a(View view, View view2, int i10, int i11) {
        C0499e0 c0499e0 = this.f16317H;
        if (i11 == 1) {
            c0499e0.f7842b = i10;
        } else {
            c0499e0.f7841a = i10;
        }
        this.f16318I.g(2, i11);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view) {
        if (getChildCount() > 0) {
            throw new IllegalStateException("ScrollView can host only one direct child");
        }
        super.addView(view);
    }

    @Override // p200r1.InterfaceC1489p
    public final void b(View view, int i10) {
        C0499e0 c0499e0 = this.f16317H;
        if (i10 == 1) {
            c0499e0.f7842b = 0;
        } else {
            c0499e0.f7841a = 0;
        }
        w(i10);
    }

    @Override // p200r1.InterfaceC1489p
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        this.f16318I.c(i10, i11, i12, iArr, null);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0083  */
    /* JADX WARN: Code duplicated, block: B:24:0x00a8  */
    /* JADX WARN: Code duplicated, block: B:28:0x00b2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:29:0x00b4  */
    /* JADX WARN: Code duplicated, block: B:31:0x00ba  */
    /* JADX WARN: Code duplicated, block: B:32:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cb  */
    /* JADX WARN: Code duplicated, block: B:38:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:40:0x00e9  */
    @Override // android.view.View
    public final void computeScroll() {
        int iRound;
        int[] iArr;
        int i10;
        int scrollRange;
        int overScrollMode;
        if (this.f16324d.isFinished()) {
            return;
        }
        this.f16324d.computeScrollOffset();
        int currY = this.f16324d.getCurrY();
        int i11 = currY - this.f16315F;
        int height = getHeight();
        EdgeEffect edgeEffect = this.f16326f;
        EdgeEffect edgeEffect2 = this.f16325e;
        if (i11 <= 0 || h.j(edgeEffect2) == 0.0f) {
            if (i11 < 0 && h.j(edgeEffect) != 0.0f) {
                float f10 = height;
                iRound = Math.round(h.m(edgeEffect, (i11 * 4.0f) / f10, 0.5f) * (f10 / 4.0f));
                if (iRound != i11) {
                    edgeEffect.finish();
                }
            }
            int i12 = i11;
            this.f16315F = currY;
            iArr = this.f16313D;
            iArr[1] = 0;
            this.f16318I.c(0, i12, 1, iArr, null);
            i10 = i12 - iArr[1];
            scrollRange = getScrollRange();
            if (i10 != 0) {
                int scrollY = getScrollY();
                p(i10, getScrollX(), scrollY, scrollRange);
                int scrollY2 = getScrollY() - scrollY;
                int i13 = i10 - scrollY2;
                iArr[1] = 0;
                this.f16318I.d(0, scrollY2, 0, i13, this.f16312C, 1, iArr);
                i10 = i13 - iArr[1];
            }
            if (i10 != 0) {
                overScrollMode = getOverScrollMode();
                if (overScrollMode != 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    if (i10 < 0) {
                        if (edgeEffect2.isFinished()) {
                            edgeEffect2.onAbsorb((int) this.f16324d.getCurrVelocity());
                        }
                    } else if (edgeEffect.isFinished()) {
                        edgeEffect.onAbsorb((int) this.f16324d.getCurrVelocity());
                    }
                }
                this.f16324d.abortAnimation();
                w(1);
            }
            if (this.f16324d.isFinished()) {
                w(1);
            } else {
                postInvalidateOnAnimation();
            }
        }
        iRound = Math.round(h.m(edgeEffect2, ((-i11) * 4.0f) / height, 0.5f) * ((-height) / 4.0f));
        if (iRound != i11) {
            edgeEffect2.finish();
        }
        i11 -= iRound;
        int i14 = i11;
        this.f16315F = currY;
        iArr = this.f16313D;
        iArr[1] = 0;
        this.f16318I.c(0, i14, 1, iArr, null);
        i10 = i14 - iArr[1];
        scrollRange = getScrollRange();
        if (i10 != 0) {
            int scrollY3 = getScrollY();
            p(i10, getScrollX(), scrollY3, scrollRange);
            int scrollY4 = getScrollY() - scrollY3;
            int i15 = i10 - scrollY4;
            iArr[1] = 0;
            this.f16318I.d(0, scrollY4, 0, i15, this.f16312C, 1, iArr);
            i10 = i15 - iArr[1];
        }
        if (i10 != 0) {
            overScrollMode = getOverScrollMode();
            if (overScrollMode != 0) {
                if (i10 < 0) {
                    if (edgeEffect2.isFinished()) {
                        edgeEffect2.onAbsorb((int) this.f16324d.getCurrVelocity());
                    }
                } else if (edgeEffect.isFinished()) {
                    edgeEffect.onAbsorb((int) this.f16324d.getCurrVelocity());
                }
            } else if (i10 < 0) {
                if (edgeEffect2.isFinished()) {
                    edgeEffect2.onAbsorb((int) this.f16324d.getCurrVelocity());
                }
            } else if (edgeEffect.isFinished()) {
                edgeEffect.onAbsorb((int) this.f16324d.getCurrVelocity());
            }
            this.f16324d.abortAnimation();
            w(1);
        }
        if (this.f16324d.isFinished()) {
            postInvalidateOnAnimation();
        } else {
            w(1);
        }
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int iMax = Math.max(0, bottom - height);
        if (scrollY < 0) {
            return bottom - scrollY;
        }
        return scrollY > iMax ? (scrollY - iMax) + bottom : bottom;
    }

    public final boolean d(int i10) {
        View viewFindFocus = findFocus();
        if (viewFindFocus == this) {
            viewFindFocus = null;
        }
        View viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, i10);
        int maxScrollAmount = getMaxScrollAmount();
        if (viewFindNextFocus == null || !m(viewFindNextFocus, maxScrollAmount, getHeight())) {
            if (i10 == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i10 == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i10 != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            s(maxScrollAmount, 0, 1, true);
        } else {
            Rect rect = this.f16323c;
            viewFindNextFocus.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(viewFindNextFocus, rect);
            s(e(rect), 0, 1, true);
            viewFindNextFocus.requestFocus(i10);
        }
        if (viewFindFocus != null && viewFindFocus.isFocused() && !m(viewFindFocus, 0, getHeight())) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || f(keyEvent);
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f10, float f11, boolean z3) {
        return this.f16318I.a(f10, f11, z3);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f10, float f11) {
        return this.f16318I.b(f10, f11);
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i10, int i11, int[] iArr, int[] iArr2) {
        return this.f16318I.c(i10, i11, 0, iArr, iArr2);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i10, int i11, int i12, int i13, int[] iArr) {
        return this.f16318I.d(i10, i11, i12, i13, iArr, 0, null);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int paddingLeft;
        super.draw(canvas);
        int scrollY = getScrollY();
        EdgeEffect edgeEffect = this.f16325e;
        int paddingLeft2 = 0;
        if (!edgeEffect.isFinished()) {
            int iSave = canvas.save();
            int width = getWidth();
            int height = getHeight();
            int iMin = Math.min(0, scrollY);
            if (i.a(this)) {
                width -= getPaddingRight() + getPaddingLeft();
                paddingLeft = getPaddingLeft();
            } else {
                paddingLeft = 0;
            }
            if (i.a(this)) {
                height -= getPaddingBottom() + getPaddingTop();
                iMin += getPaddingTop();
            }
            canvas.translate(paddingLeft, iMin);
            edgeEffect.setSize(width, height);
            if (edgeEffect.draw(canvas)) {
                postInvalidateOnAnimation();
            }
            canvas.restoreToCount(iSave);
        }
        EdgeEffect edgeEffect2 = this.f16326f;
        if (edgeEffect2.isFinished()) {
            return;
        }
        int iSave2 = canvas.save();
        int width2 = getWidth();
        int height2 = getHeight();
        int iMax = Math.max(getScrollRange(), scrollY) + height2;
        if (i.a(this)) {
            width2 -= getPaddingRight() + getPaddingLeft();
            paddingLeft2 = getPaddingLeft();
        }
        if (i.a(this)) {
            height2 -= getPaddingBottom() + getPaddingTop();
            iMax -= getPaddingBottom();
        }
        canvas.translate(paddingLeft2 - width2, iMax);
        canvas.rotate(180.0f, width2, 0.0f);
        edgeEffect2.setSize(width2, height2);
        if (edgeEffect2.draw(canvas)) {
            postInvalidateOnAnimation();
        }
        canvas.restoreToCount(iSave2);
    }

    public final int e(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i10 = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i11 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i10 - verticalFadingEdgeLength : i10;
        int i12 = rect.bottom;
        if (i12 > i11 && rect.top > scrollY) {
            return Math.min(rect.height() > height ? rect.top - scrollY : rect.bottom - i11, (childAt.getBottom() + layoutParams.bottomMargin) - i10);
        }
        if (rect.top >= scrollY || i12 >= i11) {
            return 0;
        }
        return Math.max(rect.height() > height ? 0 - (i11 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0098  */
    /* JADX WARN: Code duplicated, block: B:54:0x00ab  */
    public final boolean f(KeyEvent keyEvent) {
        View viewFindFocus;
        View viewFindNextFocus;
        this.f16323c.setEmpty();
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            if (childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin > (getHeight() - getPaddingTop()) - getPaddingBottom()) {
                if (keyEvent.getAction() == 0) {
                    int keyCode = keyEvent.getKeyCode();
                    if (keyCode == 19) {
                        return keyEvent.isAltPressed() ? k(33) : d(33);
                    }
                    if (keyCode == 20) {
                        return keyEvent.isAltPressed() ? k(130) : d(130);
                    }
                    if (keyCode == 62) {
                        q(keyEvent.isShiftPressed() ? 33 : 130);
                        return false;
                    }
                    if (keyCode == 92) {
                        return k(33);
                    }
                    if (keyCode == 93) {
                        return k(130);
                    }
                    if (keyCode == 122) {
                        q(33);
                        return false;
                    }
                    if (keyCode == 123) {
                        q(130);
                        return false;
                    }
                }
            } else if (isFocused() && keyEvent.getKeyCode() != 4) {
                viewFindFocus = findFocus();
                if (viewFindFocus == this) {
                    viewFindFocus = null;
                }
                viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
                if (viewFindNextFocus == null && viewFindNextFocus != this && viewFindNextFocus.requestFocus(130)) {
                    return true;
                }
            }
        } else if (isFocused()) {
            viewFindFocus = findFocus();
            if (viewFindFocus == this) {
                viewFindFocus = null;
            }
            viewFindNextFocus = FocusFinder.getInstance().findNextFocus(this, viewFindFocus, 130);
            if (viewFindNextFocus == null) {
            }
        }
        return false;
    }

    @Override // p200r1.InterfaceC1490q
    public final void g(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        n(i13, i14, iArr);
    }

    @Override // android.view.View
    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + layoutParams.bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return bottom / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (getHeight() * 0.5f);
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0499e0 c0499e0 = this.f16317H;
        return c0499e0.f7842b | c0499e0.f7841a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    @Override // android.view.View
    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return scrollY / verticalFadingEdgeLength;
        }
        return 1.0f;
    }

    public float getVerticalScrollFactorCompat() {
        if (this.f16319J == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (!context.getTheme().resolveAttribute(R.attr.listPreferredItemHeight, typedValue, true)) {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
            this.f16319J = typedValue.getDimension(context.getResources().getDisplayMetrics());
        }
        return this.f16319J;
    }

    public final void h(int i10) {
        if (getChildCount() > 0) {
            this.f16324d.fling(getScrollX(), getScrollY(), 0, i10, 0, 0, Integer.MIN_VALUE, com.google.android.gms.common.api.f.API_PRIORITY_OTHER, 0, 0);
            this.f16318I.g(2, 1);
            this.f16315F = getScrollY();
            postInvalidateOnAnimation();
        }
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return this.f16318I.f(0);
    }

    @Override // p200r1.InterfaceC1489p
    public final void i(View view, int i10, int i11, int i12, int i13, int i14) {
        n(i13, i14, null);
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return this.f16318I.f27746d;
    }

    @Override // p200r1.InterfaceC1489p
    public final boolean j(View view, View view2, int i10, int i11) {
        return (i10 & 2) != 0;
    }

    public final boolean k(int i10) {
        int childCount;
        boolean z3 = i10 == 130;
        int height = getHeight();
        Rect rect = this.f16323c;
        rect.top = 0;
        rect.bottom = height;
        if (z3 && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            rect.bottom = paddingBottom;
            rect.top = paddingBottom - height;
        }
        return r(i10, rect.top, rect.bottom);
    }

    public final boolean m(View view, int i10, int i11) {
        Rect rect = this.f16323c;
        view.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(view, rect);
        return rect.bottom + i10 >= getScrollY() && rect.top - i10 <= getScrollY() + i11;
    }

    @Override // android.view.ViewGroup
    public final void measureChild(View view, int i10, int i11) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    @Override // android.view.ViewGroup
    public final void measureChildWithMargins(View view, int i10, int i11, int i12, int i13) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public final void n(int i10, int i11, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i10);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f16318I.d(0, scrollY2, 0, i10 - scrollY2, null, i11, iArr);
    }

    public final void o(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f16311B) {
            int i10 = actionIndex == 0 ? 1 : 0;
            this.f16327q = (int) motionEvent.getY(i10);
            this.f16311B = motionEvent.getPointerId(i10);
            VelocityTracker velocityTracker = this.f16332v;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f16329s = false;
    }

    /* JADX WARN: Code duplicated, block: B:110:0x01db  */
    /* JADX WARN: Code duplicated, block: B:53:0x00df  */
    /* JADX WARN: Code duplicated, block: B:65:0x010a  */
    @Override // android.view.View
    public final boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float axisValue;
        int i10;
        int width;
        int i11;
        int i12;
        int scaledMinimumFlingVelocity;
        int scaledMaximumFlingVelocity;
        boolean z3;
        VelocityTracker velocityTracker;
        float yVelocity;
        float f10;
        long j10;
        float f11;
        float fSqrt;
        int i13;
        int i14;
        if (motionEvent.getAction() != 8 || this.f16331u) {
            return false;
        }
        if ((motionEvent.getSource() & 2) == 2) {
            i10 = 9;
            axisValue = motionEvent.getAxisValue(9);
            width = (int) motionEvent.getX();
        } else if ((motionEvent.getSource() & 4194304) == 4194304) {
            axisValue = motionEvent.getAxisValue(26);
            width = getWidth() / 2;
            i10 = 26;
        } else {
            axisValue = 0.0f;
            i10 = 0;
            width = 0;
        }
        if (axisValue == 0.0f) {
            return false;
        }
        s(-((int) (getVerticalScrollFactorCompat() * axisValue)), width, 1, (motionEvent.getSource() & 8194) == 8194);
        if (i10 == 0) {
            return true;
        }
        C1481h c1481h = this.f16320K;
        c1481h.getClass();
        int source = motionEvent.getSource();
        int deviceId = motionEvent.getDeviceId();
        int i15 = c1481h.f27720f;
        int[] iArr = c1481h.f27722h;
        int i16 = 1;
        if (i15 == source && c1481h.f27721g == deviceId && c1481h.f27719e == i10) {
            z3 = false;
            i11 = 20;
            i12 = 0;
        } else {
            Context context = c1481h.f27715a;
            ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
            i11 = 20;
            int deviceId2 = motionEvent.getDeviceId();
            int source2 = motionEvent.getSource();
            i12 = 0;
            int i17 = Build.VERSION.SDK_INT;
            if (i17 >= 34) {
                Method method = Y.f27689a;
                scaledMinimumFlingVelocity = X.b(viewConfiguration, deviceId2, i10, source2);
            } else {
                Method method2 = Y.f27689a;
                InputDevice device = InputDevice.getDevice(deviceId2);
                if (device == null || device.getMotionRange(i10, source2) == null) {
                    scaledMinimumFlingVelocity = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
                } else {
                    Resources resources = context.getResources();
                    int identifier = (source2 == 4194304 && i10 == 26) ? resources.getIdentifier("config_viewMinRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                    Objects.requireNonNull(viewConfiguration);
                    if (identifier == -1) {
                        scaledMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
                    } else if (identifier == 0 || (scaledMinimumFlingVelocity = resources.getDimensionPixelSize(identifier)) < 0) {
                        scaledMinimumFlingVelocity = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
                    }
                }
            }
            iArr[0] = scaledMinimumFlingVelocity;
            int deviceId3 = motionEvent.getDeviceId();
            int source3 = motionEvent.getSource();
            if (i17 >= 34) {
                scaledMaximumFlingVelocity = X.a(viewConfiguration, deviceId3, i10, source3);
            } else {
                InputDevice device2 = InputDevice.getDevice(deviceId3);
                if ((device2 == null || device2.getMotionRange(i10, source3) == null) ? false : true) {
                    Resources resources2 = context.getResources();
                    int identifier2 = (source3 == 4194304 && i10 == 26) ? resources2.getIdentifier("config_viewMaxRotaryEncoderFlingVelocity", "dimen", "android") : -1;
                    Objects.requireNonNull(viewConfiguration);
                    if (identifier2 == -1) {
                        scaledMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
                    } else if (identifier2 == 0 || (scaledMaximumFlingVelocity = resources2.getDimensionPixelSize(identifier2)) < 0) {
                        scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                    }
                } else {
                    scaledMaximumFlingVelocity = Integer.MIN_VALUE;
                }
            }
            iArr[1] = scaledMaximumFlingVelocity;
            c1481h.f27720f = source;
            c1481h.f27721g = deviceId;
            c1481h.f27719e = i10;
            z3 = true;
        }
        if (iArr[i12] == Integer.MAX_VALUE) {
            VelocityTracker velocityTracker2 = c1481h.f27717c;
            if (velocityTracker2 == null) {
                return true;
            }
            velocityTracker2.recycle();
            c1481h.f27717c = null;
            return true;
        }
        if (c1481h.f27717c == null) {
            c1481h.f27717c = VelocityTracker.obtain();
        }
        VelocityTracker velocityTracker3 = c1481h.f27717c;
        Map map = A.f27659a;
        velocityTracker3.addMovement(motionEvent);
        if (Build.VERSION.SDK_INT < 34 && motionEvent.getSource() == 4194304) {
            Map map2 = A.f27659a;
            if (!map2.containsKey(velocityTracker3)) {
                map2.put(velocityTracker3, new B());
            }
            B b10 = (B) map2.get(velocityTracker3);
            b10.getClass();
            long eventTime = motionEvent.getEventTime();
            int i18 = b10.f27665d;
            long[] jArr = b10.f27663b;
            if (i18 != 0 && eventTime - jArr[b10.f27666e] > 40) {
                b10.f27665d = i12;
                b10.f27664c = 0.0f;
            }
            int i19 = (b10.f27666e + 1) % 20;
            b10.f27666e = i19;
            int i20 = b10.f27665d;
            if (i20 != i11) {
                b10.f27665d = i20 + 1;
            }
            b10.f27662a[i19] = motionEvent.getAxisValue(26);
            jArr[b10.f27666e] = eventTime;
        }
        float f12 = Float.MAX_VALUE;
        velocityTracker3.computeCurrentVelocity(1000, Float.MAX_VALUE);
        B b11 = (B) A.f27659a.get(velocityTracker3);
        if (b11 != null) {
            int i21 = b11.f27665d;
            if (i21 < 2) {
                velocityTracker = velocityTracker3;
                f11 = Float.MAX_VALUE;
                i13 = 1000;
                fSqrt = 0.0f;
            } else {
                int i22 = b11.f27666e;
                int i23 = ((i22 + 20) - (i21 - 1)) % 20;
                long[] jArr2 = b11.f27663b;
                long j11 = jArr2[i22];
                while (true) {
                    j10 = jArr2[i23];
                    if (j11 - j10 <= 100) {
                        break;
                    }
                    b11.f27665d--;
                    i23 = (i23 + 1) % 20;
                }
                int i24 = b11.f27665d;
                if (i24 < 2) {
                    velocityTracker = velocityTracker3;
                    f11 = Float.MAX_VALUE;
                    i13 = 1000;
                    fSqrt = 0.0f;
                } else {
                    float[] fArr = b11.f27662a;
                    if (i24 == 2) {
                        int i25 = (i23 + 1) % 20;
                        long j12 = jArr2[i25];
                        if (j10 == j12) {
                            velocityTracker = velocityTracker3;
                            f11 = Float.MAX_VALUE;
                            i13 = 1000;
                            fSqrt = 0.0f;
                        } else {
                            velocityTracker = velocityTracker3;
                            f11 = Float.MAX_VALUE;
                            i13 = 1000;
                            fSqrt = fArr[i25] / (j12 - j10);
                        }
                    } else {
                        float f13 = 0.0f;
                        int i26 = 0;
                        int i27 = 0;
                        while (true) {
                            if (i26 >= b11.f27665d - 1) {
                                break;
                            }
                            int i28 = i26 + i23;
                            long j13 = jArr2[i28 % 20];
                            int i29 = (i28 + 1) % 20;
                            if (jArr2[i29] == j13) {
                                i14 = i16;
                            } else {
                                i27++;
                                float fSqrt2 = (f13 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f13) * 2.0f));
                                float f14 = fArr[i29] / (jArr2[i29] - j13);
                                float fAbs = (Math.abs(f14) * (f14 - fSqrt2)) + f13;
                                i14 = i16;
                                if (i27 == i14) {
                                    fAbs *= 0.5f;
                                }
                                f13 = fAbs;
                            }
                            i26 += i14;
                            f12 = f12;
                            i16 = i14;
                            velocityTracker3 = velocityTracker3;
                        }
                        velocityTracker = velocityTracker3;
                        f11 = f12;
                        fSqrt = ((float) Math.sqrt(Math.abs(f13) * 2.0f)) * (f13 < 0.0f ? -1.0f : 1.0f);
                        i13 = 1000;
                    }
                }
            }
            float f15 = fSqrt * i13;
            b11.f27664c = f15;
            if (f15 < (-Math.abs(f11))) {
                b11.f27664c = -Math.abs(f11);
            } else if (b11.f27664c > Math.abs(f11)) {
                b11.f27664c = Math.abs(f11);
            }
        } else {
            velocityTracker = velocityTracker3;
        }
        if (Build.VERSION.SDK_INT >= 34) {
            yVelocity = AbstractC1498z.a(velocityTracker, i10);
        } else {
            VelocityTracker velocityTracker4 = velocityTracker;
            if (i10 == 0) {
                yVelocity = velocityTracker4.getXVelocity();
            } else if (i10 == 1) {
                yVelocity = velocityTracker4.getYVelocity();
            } else {
                B b12 = (B) A.f27659a.get(velocityTracker4);
                yVelocity = (b12 == null || i10 != 26) ? 0.0f : b12.f27664c;
            }
        }
        NestedScrollView nestedScrollView = (NestedScrollView) c1481h.f27716b.f30881a;
        float f16 = yVelocity * (-nestedScrollView.getVerticalScrollFactorCompat());
        float fSignum = Math.signum(f16);
        if (z3 || (fSignum != Math.signum(c1481h.f27718d) && fSignum != 0.0f)) {
            nestedScrollView.f16324d.abortAnimation();
        }
        if (Math.abs(f16) < iArr[0]) {
            return true;
        }
        int i30 = iArr[1];
        float fMax = Math.max(-i30, Math.min(f16, i30));
        if (fMax == 0.0f) {
            f10 = 0.0f;
        } else {
            nestedScrollView.f16324d.abortAnimation();
            nestedScrollView.h((int) fMax);
            f10 = fMax;
        }
        c1481h.f27718d = f10;
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0083  */
    /* JADX WARN: Code duplicated, block: B:36:0x008b  */
    /* JADX WARN: Code duplicated, block: B:39:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:62:0x0119  */
    /* JADX WARN: Code duplicated, block: B:70:0x012f  */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        VelocityTracker velocityTracker;
        VelocityTracker velocityTracker2;
        int action = motionEvent.getAction();
        boolean z3 = true;
        if (action == 2 && this.f16331u) {
            return true;
        }
        int i10 = action & 255;
        if (i10 == 0) {
            int y10 = (int) motionEvent.getY();
            int x10 = (int) motionEvent.getX();
            if (getChildCount() > 0) {
                int scrollY = getScrollY();
                View childAt = getChildAt(0);
                if (y10 < childAt.getTop() - scrollY || y10 >= childAt.getBottom() - scrollY || x10 < childAt.getLeft() || x10 >= childAt.getRight()) {
                    if (!v(motionEvent) && this.f16324d.isFinished()) {
                        z3 = false;
                    }
                    this.f16331u = z3;
                    velocityTracker = this.f16332v;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        this.f16332v = null;
                    }
                } else {
                    this.f16327q = y10;
                    this.f16311B = motionEvent.getPointerId(0);
                    VelocityTracker velocityTracker3 = this.f16332v;
                    if (velocityTracker3 == null) {
                        this.f16332v = VelocityTracker.obtain();
                    } else {
                        velocityTracker3.clear();
                    }
                    this.f16332v.addMovement(motionEvent);
                    this.f16324d.computeScrollOffset();
                    if (!v(motionEvent) && this.f16324d.isFinished()) {
                        z3 = false;
                    }
                    this.f16331u = z3;
                    this.f16318I.g(2, 0);
                }
            } else {
                if (!v(motionEvent)) {
                    z3 = false;
                }
                this.f16331u = z3;
                velocityTracker = this.f16332v;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    this.f16332v = null;
                }
            }
        } else if (i10 == 1) {
            this.f16331u = false;
            this.f16311B = -1;
            velocityTracker2 = this.f16332v;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f16332v = null;
            }
            if (this.f16324d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i10 == 2) {
            int i11 = this.f16311B;
            if (i11 != -1) {
                int iFindPointerIndex = motionEvent.findPointerIndex(i11);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + i11 + " in onInterceptTouchEvent");
                } else {
                    int y11 = (int) motionEvent.getY(iFindPointerIndex);
                    if (Math.abs(y11 - this.f16327q) > this.f16335y && (2 & getNestedScrollAxes()) == 0) {
                        this.f16331u = true;
                        this.f16327q = y11;
                        if (this.f16332v == null) {
                            this.f16332v = VelocityTracker.obtain();
                        }
                        this.f16332v.addMovement(motionEvent);
                        this.f16314E = 0;
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
            }
        } else if (i10 == 3) {
            this.f16331u = false;
            this.f16311B = -1;
            velocityTracker2 = this.f16332v;
            if (velocityTracker2 != null) {
                velocityTracker2.recycle();
                this.f16332v = null;
            }
            if (this.f16324d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                postInvalidateOnAnimation();
            }
            w(0);
        } else if (i10 == 6) {
            o(motionEvent);
        }
        return this.f16331u;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int measuredHeight;
        super.onLayout(z3, i10, i11, i12, i13);
        int i14 = 0;
        this.f16328r = false;
        View view = this.f16330t;
        if (view != null && l(view, this)) {
            View view2 = this.f16330t;
            Rect rect = this.f16323c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iE = e(rect);
            if (iE != 0) {
                scrollBy(0, iE);
            }
        }
        this.f16330t = null;
        if (!this.f16329s) {
            if (this.f16316G != null) {
                scrollTo(getScrollX(), this.f16316G.f32433a);
                this.f16316G = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                measuredHeight = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            } else {
                measuredHeight = 0;
            }
            int paddingTop = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            if (paddingTop < measuredHeight && scrollY >= 0) {
                i14 = paddingTop + scrollY > measuredHeight ? measuredHeight - paddingTop : scrollY;
            }
            if (i14 != scrollY) {
                scrollTo(getScrollX(), i14);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f16329s = true;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        if (this.f16333w && View.MeasureSpec.getMode(i11) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        if (z3) {
            return false;
        }
        dispatchNestedFling(0.0f, f11, true);
        h((int) f11);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return this.f16318I.b(f10, f11);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        this.f16318I.c(i10, i11, 0, iArr, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        n(i13, 0, null);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        a(view, view2, i10, 0);
    }

    @Override // android.view.View
    public final void onOverScrolled(int i10, int i11, boolean z3, boolean z5) {
        super.scrollTo(i10, i11);
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i10, Rect rect) {
        if (i10 == 2) {
            i10 = 130;
        } else if (i10 == 1) {
            i10 = 33;
        }
        View viewFindNextFocus = rect == null ? FocusFinder.getInstance().findNextFocus(this, null, i10) : FocusFinder.getInstance().findNextFocusFromRect(this, rect, i10);
        if (viewFindNextFocus != null && m(viewFindNextFocus, 0, getHeight())) {
            return viewFindNextFocus.requestFocus(i10, rect);
        }
        return false;
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof k)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        k kVar = (k) parcelable;
        super.onRestoreInstanceState(kVar.getSuperState());
        this.f16316G = kVar;
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        k kVar = new k(super.onSaveInstanceState());
        kVar.f32433a = getScrollY();
        return kVar;
    }

    @Override // android.view.View
    public final void onScrollChanged(int i10, int i11, int i12, int i13) {
        super.onScrollChanged(i10, i11, i12, i13);
    }

    @Override // android.view.View
    public final void onSizeChanged(int i10, int i11, int i12, int i13) {
        super.onSizeChanged(i10, i11, i12, i13);
        View viewFindFocus = findFocus();
        if (viewFindFocus == null || this == viewFindFocus || !m(viewFindFocus, 0, i13)) {
            return;
        }
        Rect rect = this.f16323c;
        viewFindFocus.getDrawingRect(rect);
        offsetDescendantRectToMyCoords(viewFindFocus, rect);
        int iE = e(rect);
        if (iE != 0) {
            if (this.f16334x) {
                u(0, iE, false);
            } else {
                scrollBy(0, iE);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return j(view, view2, i10, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        ViewParent parent;
        if (this.f16332v == null) {
            this.f16332v = VelocityTracker.obtain();
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f16314E = 0;
        }
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        float f10 = 0.0f;
        motionEventObtain.offsetLocation(0.0f, this.f16314E);
        C1488o c1488o = this.f16318I;
        if (actionMasked != 0) {
            EdgeEffect edgeEffect = this.f16326f;
            EdgeEffect edgeEffect2 = this.f16325e;
            if (actionMasked == 1) {
                VelocityTracker velocityTracker = this.f16332v;
                velocityTracker.computeCurrentVelocity(1000, this.f16310A);
                int yVelocity = (int) velocityTracker.getYVelocity(this.f16311B);
                if (Math.abs(yVelocity) >= this.f16336z) {
                    if (h.j(edgeEffect2) != 0.0f) {
                        if (t(edgeEffect2, yVelocity)) {
                            edgeEffect2.onAbsorb(yVelocity);
                        } else {
                            h(-yVelocity);
                        }
                    } else if (h.j(edgeEffect) != 0.0f) {
                        int i10 = -yVelocity;
                        if (t(edgeEffect, i10)) {
                            edgeEffect.onAbsorb(i10);
                        } else {
                            h(i10);
                        }
                    } else {
                        int i11 = -yVelocity;
                        float f11 = i11;
                        if (!c1488o.b(0.0f, f11)) {
                            dispatchNestedFling(0.0f, f11, true);
                            h(i11);
                        }
                    }
                } else if (this.f16324d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f16311B = -1;
                this.f16331u = false;
                VelocityTracker velocityTracker2 = this.f16332v;
                if (velocityTracker2 != null) {
                    velocityTracker2.recycle();
                    this.f16332v = null;
                }
                w(0);
                this.f16325e.onRelease();
                this.f16326f.onRelease();
            } else if (actionMasked == 2) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f16311B);
                if (iFindPointerIndex == -1) {
                    Log.e("NestedScrollView", "Invalid pointerId=" + this.f16311B + " in onTouchEvent");
                } else {
                    int y10 = (int) motionEvent.getY(iFindPointerIndex);
                    int i12 = this.f16327q - y10;
                    float x10 = motionEvent.getX(iFindPointerIndex) / getWidth();
                    float height = i12 / getHeight();
                    if (h.j(edgeEffect2) != 0.0f) {
                        float f12 = -h.m(edgeEffect2, -height, x10);
                        if (h.j(edgeEffect2) == 0.0f) {
                            edgeEffect2.onRelease();
                        }
                        f10 = f12;
                    } else if (h.j(edgeEffect) != 0.0f) {
                        float fM = h.m(edgeEffect, height, 1.0f - x10);
                        if (h.j(edgeEffect) == 0.0f) {
                            edgeEffect.onRelease();
                        }
                        f10 = fM;
                    }
                    int iRound = Math.round(f10 * getHeight());
                    if (iRound != 0) {
                        invalidate();
                    }
                    int i13 = i12 - iRound;
                    if (!this.f16331u && Math.abs(i13) > this.f16335y) {
                        ViewParent parent2 = getParent();
                        if (parent2 != null) {
                            parent2.requestDisallowInterceptTouchEvent(true);
                        }
                        this.f16331u = true;
                        i13 = i13 > 0 ? i13 - this.f16335y : i13 + this.f16335y;
                    }
                    if (this.f16331u) {
                        int iS = s(i13, (int) motionEvent.getX(iFindPointerIndex), 0, false);
                        this.f16327q = y10 - iS;
                        this.f16314E += iS;
                    }
                }
            } else if (actionMasked == 3) {
                if (this.f16331u && getChildCount() > 0 && this.f16324d.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
                    postInvalidateOnAnimation();
                }
                this.f16311B = -1;
                this.f16331u = false;
                VelocityTracker velocityTracker3 = this.f16332v;
                if (velocityTracker3 != null) {
                    velocityTracker3.recycle();
                    this.f16332v = null;
                }
                w(0);
                this.f16325e.onRelease();
                this.f16326f.onRelease();
            } else if (actionMasked == 5) {
                int actionIndex = motionEvent.getActionIndex();
                this.f16327q = (int) motionEvent.getY(actionIndex);
                this.f16311B = motionEvent.getPointerId(actionIndex);
            } else if (actionMasked == 6) {
                o(motionEvent);
                this.f16327q = (int) motionEvent.getY(motionEvent.findPointerIndex(this.f16311B));
            }
        } else {
            if (getChildCount() == 0) {
                return false;
            }
            if (this.f16331u && (parent = getParent()) != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
            if (!this.f16324d.isFinished()) {
                this.f16324d.abortAnimation();
                w(1);
            }
            int y11 = (int) motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            this.f16327q = y11;
            this.f16311B = pointerId;
            c1488o.g(2, 0);
        }
        VelocityTracker velocityTracker4 = this.f16332v;
        if (velocityTracker4 != null) {
            velocityTracker4.addMovement(motionEventObtain);
        }
        motionEventObtain.recycle();
        return true;
    }

    public final boolean p(int i10, int i11, int i12, int i13) {
        int i14;
        boolean z3;
        int i15;
        boolean z5;
        getOverScrollMode();
        super.computeHorizontalScrollRange();
        super.computeHorizontalScrollExtent();
        computeVerticalScrollRange();
        super.computeVerticalScrollExtent();
        int i16 = i12 + i10;
        if (i11 <= 0 && i11 >= 0) {
            i14 = i11;
            z3 = false;
        } else {
            i14 = 0;
            z3 = true;
        }
        if (i16 <= i13) {
            if (i16 < 0) {
                i15 = 0;
            } else {
                i15 = i16;
                z5 = false;
            }
            if (z5 && !this.f16318I.f(1)) {
                this.f16324d.springBack(i14, i15, 0, 0, 0, getScrollRange());
            }
            super.scrollTo(i14, i15);
            return !z3 || z5;
        }
        i15 = i13;
        z5 = true;
        if (z5) {
            this.f16324d.springBack(i14, i15, 0, 0, 0, getScrollRange());
        }
        super.scrollTo(i14, i15);
        if (z3) {
        }
    }

    public final void q(int i10) {
        boolean z3 = i10 == 130;
        int height = getHeight();
        Rect rect = this.f16323c;
        if (z3) {
            rect.top = getScrollY() + height;
            int childCount = getChildCount();
            if (childCount > 0) {
                View childAt = getChildAt(childCount - 1);
                int paddingBottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
                if (rect.top + height > paddingBottom) {
                    rect.top = paddingBottom - height;
                }
            }
        } else {
            int scrollY = getScrollY() - height;
            rect.top = scrollY;
            if (scrollY < 0) {
                rect.top = 0;
            }
        }
        int i11 = rect.top;
        int i12 = height + i11;
        rect.bottom = i12;
        r(i10, i11, i12);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0068  */
    public final boolean r(int i10, int i11, int i12) {
        boolean z3;
        int height = getHeight();
        int scrollY = getScrollY();
        int i13 = height + scrollY;
        boolean z5 = i10 == 33;
        ArrayList<View> focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z10 = false;
        for (int i14 = 0; i14 < size; i14++) {
            View view2 = focusables.get(i14);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i11 < bottom && top < i12) {
                boolean z11 = i11 < top && bottom < i12;
                if (view == null) {
                    view = view2;
                    z10 = z11;
                } else {
                    boolean z12 = (z5 && top < view.getTop()) || (!z5 && bottom > view.getBottom());
                    if (z10) {
                        if (z11 && z12) {
                            view = view2;
                        }
                    } else if (z11) {
                        view = view2;
                        z10 = true;
                    } else if (z12) {
                        view = view2;
                    }
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i11 < scrollY || i12 > i13) {
            s(z5 ? i11 - scrollY : i12 - i13, 0, 1, true);
            z3 = true;
        } else {
            z3 = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i10);
        }
        return z3;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        if (this.f16328r) {
            this.f16330t = view2;
        } else {
            Rect rect = this.f16323c;
            view2.getDrawingRect(rect);
            offsetDescendantRectToMyCoords(view2, rect);
            int iE = e(rect);
            if (iE != 0) {
                scrollBy(0, iE);
            }
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z3) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int iE = e(rect);
        boolean z5 = iE != 0;
        if (z5) {
            if (z3) {
                scrollBy(0, iE);
                return z5;
            }
            u(0, iE, false);
        }
        return z5;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        VelocityTracker velocityTracker;
        if (z3 && (velocityTracker = this.f16332v) != null) {
            velocityTracker.recycle();
            this.f16332v = null;
        }
        super.requestDisallowInterceptTouchEvent(z3);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        this.f16328r = true;
        super.requestLayout();
    }

    public final int s(int i10, int i11, int i12, boolean z3) {
        int i13;
        int i14;
        boolean z5;
        VelocityTracker velocityTracker;
        C1488o c1488o = this.f16318I;
        if (i12 == 1) {
            c1488o.g(2, i12);
        }
        boolean zC = this.f16318I.c(0, i10, i12, this.f16313D, this.f16312C);
        int[] iArr = this.f16313D;
        int[] iArr2 = this.f16312C;
        if (zC) {
            i13 = i10 - iArr[1];
            i14 = iArr2[1];
        } else {
            i13 = i10;
            i14 = 0;
        }
        int scrollY = getScrollY();
        int scrollRange = getScrollRange();
        int overScrollMode = getOverScrollMode();
        boolean z10 = (overScrollMode == 0 || (overScrollMode == 1 && getScrollRange() > 0)) && !z3;
        boolean z11 = p(i13, 0, scrollY, scrollRange) && !c1488o.f(i12);
        int scrollY2 = getScrollY() - scrollY;
        iArr[1] = 0;
        this.f16318I.d(0, scrollY2, 0, i13 - scrollY2, this.f16312C, i12, iArr);
        int i15 = i14 + iArr2[1];
        int i16 = i13 - iArr[1];
        int i17 = scrollY + i16;
        EdgeEffect edgeEffect = this.f16326f;
        EdgeEffect edgeEffect2 = this.f16325e;
        if (i17 < 0) {
            if (z10) {
                h.m(edgeEffect2, (-i16) / getHeight(), i11 / getWidth());
                if (!edgeEffect.isFinished()) {
                    edgeEffect.onRelease();
                }
            }
        } else if (i17 > scrollRange && z10) {
            h.m(edgeEffect, i16 / getHeight(), 1.0f - (i11 / getWidth()));
            if (!edgeEffect2.isFinished()) {
                edgeEffect2.onRelease();
            }
        }
        if (edgeEffect2.isFinished() && edgeEffect.isFinished()) {
            z5 = z11;
        } else {
            postInvalidateOnAnimation();
            z5 = false;
        }
        if (z5 && i12 == 0 && (velocityTracker = this.f16332v) != null) {
            velocityTracker.clear();
        }
        if (i12 == 1) {
            w(i12);
            edgeEffect2.onRelease();
            edgeEffect.onRelease();
        }
        return i15;
    }

    @Override // android.view.View
    public final void scrollTo(int i10, int i11) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
            int width2 = childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
            int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int height2 = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            if (width >= width2 || i10 < 0) {
                i10 = 0;
            } else if (width + i10 > width2) {
                i10 = width2 - width;
            }
            if (height >= height2 || i11 < 0) {
                i11 = 0;
            } else if (height + i11 > height2) {
                i11 = height2 - height;
            }
            if (i10 == getScrollX() && i11 == getScrollY()) {
                return;
            }
            super.scrollTo(i10, i11);
        }
    }

    public void setFillViewport(boolean z3) {
        if (z3 != this.f16333w) {
            this.f16333w = z3;
            requestLayout();
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z3) {
        C1488o c1488o = this.f16318I;
        if (c1488o.f27746d) {
            WeakHashMap weakHashMap = U.f27683a;
            H.z(c1488o.f27745c);
        }
        c1488o.f27746d = z3;
    }

    public void setSmoothScrollingEnabled(boolean z3) {
        this.f16334x = z3;
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return true;
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i10) {
        return this.f16318I.g(i10, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        w(0);
    }

    public final boolean t(EdgeEffect edgeEffect, int i10) {
        if (i10 > 0) {
            return true;
        }
        float fJ = h.j(edgeEffect) * getHeight();
        float fAbs = Math.abs(-i10) * 0.35f;
        float f10 = this.f16321a * 0.015f;
        double dLog = Math.log(fAbs / f10);
        double d10 = f16308L;
        return ((float) (Math.exp((d10 / (d10 - 1.0d)) * dLog) * ((double) f10))) < fJ;
    }

    public final void u(int i10, int i11, boolean z3) {
        if (getChildCount() == 0) {
            return;
        }
        if (AnimationUtils.currentAnimationTimeMillis() - this.f16322b > 250) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            this.f16324d.startScroll(getScrollX(), scrollY, 0, Math.max(0, Math.min(i11 + scrollY, Math.max(0, height - height2))) - scrollY, 250);
            if (z3) {
                this.f16318I.g(2, 1);
            } else {
                w(1);
            }
            this.f16315F = getScrollY();
            postInvalidateOnAnimation();
        } else {
            if (!this.f16324d.isFinished()) {
                this.f16324d.abortAnimation();
                w(1);
            }
            scrollBy(i10, i11);
        }
        this.f16322b = AnimationUtils.currentAnimationTimeMillis();
    }

    public final boolean v(MotionEvent motionEvent) {
        boolean z3;
        EdgeEffect edgeEffect = this.f16325e;
        if (h.j(edgeEffect) != 0.0f) {
            h.m(edgeEffect, 0.0f, motionEvent.getX() / getWidth());
            z3 = true;
        } else {
            z3 = false;
        }
        EdgeEffect edgeEffect2 = this.f16326f;
        if (h.j(edgeEffect2) == 0.0f) {
            return z3;
        }
        h.m(edgeEffect2, 0.0f, 1.0f - (motionEvent.getX() / getWidth()));
        return true;
    }

    public final void w(int i10) {
        this.f16318I.h(i10);
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10) {
        if (getChildCount() <= 0) {
            super.addView(view, i10);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i10, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void setOnScrollChangeListener(j jVar) {
    }
}
