package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;
import androidx.core.widget.ContentLoadingProgressBar;
import p273y1.d;

/* JADX INFO: loaded from: classes.dex */
public class ContentLoadingProgressBar extends ProgressBar {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f16305c = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f16306a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final d f16307b;

    /* JADX WARN: Type inference failed for: r2v1, types: [y1.d] */
    /* JADX WARN: Type inference failed for: r2v2, types: [y1.d] */
    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        final int i10 = 0;
        this.f16306a = new Runnable(this) { // from class: y1.d

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ ContentLoadingProgressBar f32414b;

            {
                this.f32414b = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                ContentLoadingProgressBar contentLoadingProgressBar = this.f32414b;
                switch (i10) {
                    case 0:
                        int i11 = ContentLoadingProgressBar.f16305c;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i12 = ContentLoadingProgressBar.f16305c;
                        contentLoadingProgressBar.getClass();
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
        final int i11 = 1;
        this.f16307b = new Runnable(this) { // from class: y1.d

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            public final /* synthetic */ ContentLoadingProgressBar f32414b;

            {
                this.f32414b = this;
            }

            @Override // java.lang.Runnable
            public final void run() {
                ContentLoadingProgressBar contentLoadingProgressBar = this.f32414b;
                switch (i11) {
                    case 0:
                        int i12 = ContentLoadingProgressBar.f16305c;
                        contentLoadingProgressBar.setVisibility(8);
                        break;
                    default:
                        int i13 = ContentLoadingProgressBar.f16305c;
                        contentLoadingProgressBar.getClass();
                        System.currentTimeMillis();
                        contentLoadingProgressBar.setVisibility(0);
                        break;
                }
            }
        };
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        removeCallbacks(this.f16306a);
        removeCallbacks(this.f16307b);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f16306a);
        removeCallbacks(this.f16307b);
    }
}
