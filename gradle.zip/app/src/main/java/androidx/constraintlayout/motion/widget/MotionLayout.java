package androidx.constraintlayout.motion.widget;

import B2.l;
import L.AbstractC0492c;
import T0.e;
import T0.n;
import U0.f;
import X0.a;
import Y0.B;
import Y0.C;
import Y0.C0776a;
import Y0.D;
import Y0.E;
import Y0.F;
import Y0.G;
import Y0.H;
import Y0.I;
import Y0.q;
import Y0.r;
import Y0.s;
import Y0.t;
import Y0.u;
import Y0.v;
import Y0.w;
import Y0.x;
import Y0.y;
import Y0.z;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.helper.widget.MotionEffect;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.d;
import androidx.core.widget.NestedScrollView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import p005a1.b;
import p005a1.c;
import p005a1.k;
import p032c7.AbstractC0933i;
import p096h9.i;
import p200r1.InterfaceC1490q;

/* JADX INFO: loaded from: classes.dex */
public class MotionLayout extends ConstraintLayout implements InterfaceC1490q {

    /* JADX INFO: renamed from: P0, reason: collision with root package name */
    public static boolean f15943P0;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public D f15944A;

    /* JADX INFO: renamed from: A0, reason: collision with root package name */
    public int f15945A0;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public r f15946B;

    /* JADX INFO: renamed from: B0, reason: collision with root package name */
    public float f15947B0;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public Interpolator f15948C;

    /* JADX INFO: renamed from: C0, reason: collision with root package name */
    public final e f15949C0;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public float f15950D;

    /* JADX INFO: renamed from: D0, reason: collision with root package name */
    public boolean f15951D0;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f15952E;

    /* JADX INFO: renamed from: E0, reason: collision with root package name */
    public x f15953E0;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f15954F;

    /* JADX INFO: renamed from: F0, reason: collision with root package name */
    public B3.e f15955F0;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public int f15956G;

    /* JADX INFO: renamed from: G0, reason: collision with root package name */
    public final Rect f15957G0;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public int f15958H;

    /* JADX INFO: renamed from: H0, reason: collision with root package name */
    public boolean f15959H0;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f15960I;

    /* JADX INFO: renamed from: I0, reason: collision with root package name */
    public z f15961I0;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f15962J;

    /* JADX INFO: renamed from: J0, reason: collision with root package name */
    public final v f15963J0;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final HashMap f15964K;

    /* JADX INFO: renamed from: K0, reason: collision with root package name */
    public boolean f15965K0;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public long f15966L;

    /* JADX INFO: renamed from: L0, reason: collision with root package name */
    public final RectF f15967L0;
    public float M;

    /* JADX INFO: renamed from: M0, reason: collision with root package name */
    public View f15968M0;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public float f15969N;

    /* JADX INFO: renamed from: N0, reason: collision with root package name */
    public Matrix f15970N0;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public float f15971O;
    public final ArrayList O0;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public long f15972P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public float f15973Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public boolean f15974R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public boolean f15975S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public y f15976T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public int f15977U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public u f15978V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public boolean f15979W;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public final a f15980a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public final t f15981b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public C0776a f15982c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public int f15983d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public int f15984e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f15985f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public float f15986g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public float f15987h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public long f15988i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public float f15989j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public boolean f15990k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public ArrayList f15991l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public ArrayList f15992m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public ArrayList f15993n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public CopyOnWriteArrayList f15994o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public int f15995p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public long f15996q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public float f15997r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public int f15998s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public float f15999t0;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    public boolean f16000u0;
    public int v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    public int f16001w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    public int f16002x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    public int f16003y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    public int f16004z0;

    public MotionLayout(Context context, AttributeSet attributeSet) {
        D d10;
        super(context, attributeSet);
        this.f15948C = null;
        this.f15950D = 0.0f;
        this.f15952E = -1;
        this.f15954F = -1;
        this.f15956G = -1;
        int i10 = 0;
        this.f15958H = 0;
        this.f15960I = 0;
        this.f15962J = true;
        this.f15964K = new HashMap();
        this.f15966L = 0L;
        this.M = 1.0f;
        this.f15969N = 0.0f;
        this.f15971O = 0.0f;
        this.f15973Q = 0.0f;
        this.f15975S = false;
        this.f15977U = 0;
        this.f15979W = false;
        a aVar = new a();
        n nVar = new n();
        nVar.k = false;
        aVar.f13460a = nVar;
        aVar.f13462c = nVar;
        this.f15980a0 = aVar;
        this.f15981b0 = new t(this);
        this.f15985f0 = false;
        this.f15990k0 = false;
        this.f15991l0 = null;
        this.f15992m0 = null;
        this.f15993n0 = null;
        this.f15994o0 = null;
        this.f15995p0 = 0;
        this.f15996q0 = -1L;
        this.f15997r0 = 0.0f;
        this.f15998s0 = 0;
        this.f15999t0 = 0.0f;
        this.f16000u0 = false;
        this.f15949C0 = new e(1);
        this.f15951D0 = false;
        this.f15955F0 = null;
        new HashMap();
        this.f15957G0 = new Rect();
        this.f15959H0 = false;
        this.f15961I0 = z.f13956a;
        this.f15963J0 = new v(this);
        this.f15965K0 = false;
        this.f15967L0 = new RectF();
        this.f15968M0 = null;
        this.f15970N0 = null;
        this.O0 = new ArrayList();
        f15943P0 = isInEditMode();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15059v);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            boolean z3 = true;
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i11);
                if (index == 2) {
                    this.f15944A = new D(getContext(), this, typedArrayObtainStyledAttributes.getResourceId(index, -1));
                } else if (index == 1) {
                    this.f15954F = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                } else if (index == 4) {
                    this.f15973Q = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                    this.f15975S = true;
                } else if (index == 0) {
                    z3 = typedArrayObtainStyledAttributes.getBoolean(index, z3);
                } else if (index == 5) {
                    if (this.f15977U == 0) {
                        this.f15977U = typedArrayObtainStyledAttributes.getBoolean(index, false) ? 2 : 0;
                    }
                } else if (index == 3) {
                    this.f15977U = typedArrayObtainStyledAttributes.getInt(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (this.f15944A == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z3) {
                this.f15944A = null;
            }
        }
        if (this.f15977U != 0) {
            D d11 = this.f15944A;
            if (d11 == null) {
                Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int iH = d11.h();
                D d12 = this.f15944A;
                d dVarB = d12.b(d12.h());
                String strJ = p123ja.a.J(getContext(), iH);
                int childCount = getChildCount();
                for (int i12 = 0; i12 < childCount; i12++) {
                    View childAt = getChildAt(i12);
                    int id = childAt.getId();
                    if (id == -1) {
                        StringBuilder sbJ = AbstractC0933i.j("CHECK: ", strJ, " ALL VIEWS SHOULD HAVE ID's ");
                        sbJ.append(childAt.getClass().getName());
                        sbJ.append(" does not!");
                        Log.w("MotionLayout", sbJ.toString());
                    }
                    if (dVarB.j(id) == null) {
                        StringBuilder sbJ2 = AbstractC0933i.j("CHECK: ", strJ, " NO CONSTRAINTS for ");
                        sbJ2.append(p123ja.a.K(childAt));
                        Log.w("MotionLayout", sbJ2.toString());
                    }
                }
                Integer[] numArr = (Integer[]) dVarB.f16249g.keySet().toArray(new Integer[0]);
                int length = numArr.length;
                int[] iArr = new int[length];
                for (int i13 = 0; i13 < length; i13++) {
                    iArr[i13] = numArr[i13].intValue();
                }
                for (int i14 = 0; i14 < length; i14++) {
                    int i15 = iArr[i14];
                    String strJ2 = p123ja.a.J(getContext(), i15);
                    if (findViewById(iArr[i14]) == null) {
                        Log.w("MotionLayout", "CHECK: " + strJ + " NO View matches id " + strJ2);
                    }
                    if (dVarB.i(i15).f16236e.f14964d == -1) {
                        Log.w("MotionLayout", AbstractC0492c.m("CHECK: ", strJ, "(", strJ2, ") no LAYOUT_HEIGHT"));
                    }
                    if (dVarB.i(i15).f16236e.f14962c == -1) {
                        Log.w("MotionLayout", AbstractC0492c.m("CHECK: ", strJ, "(", strJ2, ") no LAYOUT_HEIGHT"));
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                ArrayList arrayList = this.f15944A.f13706d;
                int size = arrayList.size();
                while (i10 < size) {
                    Object obj = arrayList.get(i10);
                    i10++;
                    C c10 = (C) obj;
                    if (c10 == this.f15944A.f13705c) {
                        Log.v("MotionLayout", "CHECK: CURRENT");
                    }
                    if (c10.f13689d == c10.f13688c) {
                        Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int i16 = c10.f13689d;
                    int i17 = c10.f13688c;
                    String strJ3 = p123ja.a.J(getContext(), i16);
                    String strJ4 = p123ja.a.J(getContext(), i17);
                    if (sparseIntArray.get(i16) == i17) {
                        Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + strJ3 + "->" + strJ4);
                    }
                    if (sparseIntArray2.get(i17) == i16) {
                        Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + strJ3 + "->" + strJ4);
                    }
                    sparseIntArray.put(i16, i17);
                    sparseIntArray2.put(i17, i16);
                    if (this.f15944A.b(i16) == null) {
                        Log.e("MotionLayout", " no such constraintSetStart " + strJ3);
                    }
                    if (this.f15944A.b(i17) == null) {
                        Log.e("MotionLayout", " no such constraintSetEnd " + strJ3);
                    }
                }
            }
        }
        if (this.f15954F != -1 || (d10 = this.f15944A) == null) {
            return;
        }
        this.f15954F = d10.h();
        this.f15952E = this.f15944A.h();
        C c11 = this.f15944A.f13705c;
        this.f15956G = c11 != null ? c11.f13688c : -1;
    }

    public static Rect p(MotionLayout motionLayout, U0.e eVar) {
        int iT = eVar.t();
        Rect rect = motionLayout.f15957G0;
        rect.top = iT;
        rect.left = eVar.s();
        rect.right = eVar.r() + rect.left;
        rect.bottom = eVar.l() + rect.top;
        return rect;
    }

    public final void A() {
        this.f15963J0.f();
        invalidate();
    }

    public final void B(int i10) {
        setState(z.f13957b);
        this.f15954F = i10;
        this.f15952E = -1;
        this.f15956G = -1;
        X.k kVar = this.f16128u;
        if (kVar == null) {
            D d10 = this.f15944A;
            if (d10 != null) {
                d10.b(i10).b(this);
                return;
            }
            return;
        }
        float f10 = -1;
        int i11 = kVar.f13399a;
        SparseArray sparseArray = (SparseArray) kVar.f13402d;
        int i12 = 0;
        ConstraintLayout constraintLayout = (ConstraintLayout) kVar.f13401c;
        if (i11 != i10) {
            kVar.f13399a = i10;
            b bVar = (b) sparseArray.get(i10);
            while (true) {
                ArrayList arrayList = bVar.f14912b;
                if (i12 >= arrayList.size()) {
                    i12 = -1;
                    break;
                } else if (((c) arrayList.get(i12)).a(f10, f10)) {
                    break;
                } else {
                    i12++;
                }
            }
            ArrayList arrayList2 = bVar.f14912b;
            d dVar = i12 == -1 ? bVar.f14914d : ((c) arrayList2.get(i12)).f14920f;
            if (i12 != -1) {
                int i13 = ((c) arrayList2.get(i12)).f14919e;
            }
            if (dVar != null) {
                kVar.f13400b = i12;
                dVar.b(constraintLayout);
                return;
            } else {
                Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i10 + ", dim =-1.0, -1.0");
                return;
            }
        }
        b bVar2 = i10 == -1 ? (b) sparseArray.valueAt(0) : (b) sparseArray.get(i11);
        int i14 = kVar.f13400b;
        if (i14 == -1 || !((c) bVar2.f14912b.get(i14)).a(f10, f10)) {
            while (true) {
                ArrayList arrayList3 = bVar2.f14912b;
                if (i12 >= arrayList3.size()) {
                    i12 = -1;
                    break;
                } else if (((c) arrayList3.get(i12)).a(f10, f10)) {
                    break;
                } else {
                    i12++;
                }
            }
            if (kVar.f13400b == i12) {
                return;
            }
            ArrayList arrayList4 = bVar2.f14912b;
            d dVar2 = i12 == -1 ? null : ((c) arrayList4.get(i12)).f14920f;
            if (i12 != -1) {
                int i15 = ((c) arrayList4.get(i12)).f14919e;
            }
            if (dVar2 == null) {
                return;
            }
            kVar.f13400b = i12;
            dVar2.b(constraintLayout);
        }
    }

    public final void C(int i10, int i11) {
        if (!isAttachedToWindow()) {
            if (this.f15953E0 == null) {
                this.f15953E0 = new x(this);
            }
            x xVar = this.f15953E0;
            xVar.f13953c = i10;
            xVar.f13954d = i11;
            return;
        }
        D d10 = this.f15944A;
        if (d10 != null) {
            this.f15952E = i10;
            this.f15956G = i11;
            d10.n(i10, i11);
            this.f15963J0.e(this.f15944A.b(i10), this.f15944A.b(i11));
            A();
            this.f15971O = 0.0f;
            q(0.0f);
        }
    }

    /* JADX WARN: Code duplicated, block: B:26:0x006e  */
    /* JADX WARN: Code duplicated, block: B:27:0x0080  */
    /* JADX WARN: Code duplicated, block: B:32:0x0098  */
    /* JADX WARN: Code duplicated, block: B:35:0x00be  */
    /* JADX WARN: Code duplicated, block: B:42:0x00ca  */
    /* JADX WARN: Code duplicated, block: B:48:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:50:0x00db  */
    /* JADX WARN: Code duplicated, block: B:56:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:61:0x0100  */
    /* JADX WARN: Code duplicated, block: B:66:0x010a  */
    /* JADX WARN: Code duplicated, block: B:71:0x0114  */
    /* JADX WARN: Code duplicated, block: B:76:0x011e  */
    /* JADX WARN: Code duplicated, block: B:81:0x0128  */
    /* JADX WARN: Code duplicated, block: B:84:0x012d  */
    public final void D(float f10, float f11, int i10) {
        D d10;
        C c10;
        int i11;
        float f12;
        float f13;
        float f14;
        float f15;
        int i12;
        G g10;
        G g11;
        G g12;
        G g13;
        G g14;
        C c11;
        G g15;
        G g16;
        C c12;
        float f16;
        G g17;
        if (this.f15944A == null || this.f15971O == f10) {
            return;
        }
        this.f15979W = true;
        this.f15966L = getNanoTime();
        float fC = this.f15944A.c() / 1000.0f;
        this.M = fC;
        this.f15973Q = f10;
        this.f15975S = true;
        a aVar = this.f15980a0;
        float f17 = 0.0f;
        float f18 = 1.0f;
        if (i10 == 0 || i10 == 1 || i10 == 2) {
            if (i10 != 1 || i10 == 7) {
                f18 = 0.0f;
            } else if (i10 != 2 && i10 != 6) {
                f18 = f10;
            }
            d10 = this.f15944A;
            c10 = d10.f13705c;
            if (c10 != null || (g16 = c10.f13696l) == null) {
                i11 = 0;
            } else {
                i11 = g16.f13728D;
            }
            if (i11 == 0) {
                float f19 = this.f15971O;
                float fG = d10.g();
                c11 = this.f15944A.f13705c;
                if (c11 != null && (g15 = c11.f13696l) != null) {
                    f17 = g15.f13746s;
                }
                this.f15980a0.b(f19, f18, f11, fC, fG, f17);
            } else {
                float f20 = this.f15971O;
                if (c10 != null || (g14 = c10.f13696l) == null) {
                    f12 = 0.0f;
                } else {
                    f12 = g14.f13753z;
                }
                if (c10 != null || (g13 = c10.f13696l) == null) {
                    f13 = 0.0f;
                } else {
                    f13 = g13.f13725A;
                }
                if (c10 != null || (g12 = c10.f13696l) == null) {
                    f14 = 0.0f;
                } else {
                    f14 = g12.f13752y;
                }
                if (c10 != null || (g11 = c10.f13696l) == null) {
                    f15 = 0.0f;
                } else {
                    f15 = g11.f13726B;
                }
                if (c10 != null || (g10 = c10.f13696l) == null) {
                    i12 = 0;
                } else {
                    i12 = g10.f13727C;
                }
                if (aVar.f13461b == null) {
                    T0.k kVar = new T0.k();
                    kVar.f11552a = 0.5d;
                    kVar.f11560i = 0;
                    aVar.f13461b = kVar;
                }
                T0.k kVar2 = aVar.f13461b;
                aVar.f13462c = kVar2;
                kVar2.f11554c = f18;
                kVar2.f11552a = f14;
                kVar2.f11556e = f20;
                kVar2.f11553b = f13;
                kVar2.f11558g = f12;
                kVar2.f11559h = f15;
                kVar2.f11560i = i12;
                kVar2.f11555d = 0.0f;
            }
            int i13 = this.f15954F;
            this.f15973Q = f18;
            this.f15954F = i13;
            this.f15946B = aVar;
        } else {
            t tVar = this.f15981b0;
            if (i10 == 4) {
                float f21 = this.f15971O;
                float fG2 = this.f15944A.g();
                tVar.f13925a = f11;
                tVar.f13926b = f21;
                tVar.f13927c = fG2;
                this.f15946B = tVar;
            } else if (i10 == 5) {
                float f22 = this.f15971O;
                float fG3 = this.f15944A.g();
                if (f11 > 0.0f) {
                    float f23 = f11 / fG3;
                    if (((f11 * f23) - (((fG3 * f23) * f23) / 2.0f)) + f22 > 1.0f) {
                        float f24 = this.f15971O;
                        float fG4 = this.f15944A.g();
                        tVar.f13925a = f11;
                        tVar.f13926b = f24;
                        tVar.f13927c = fG4;
                        this.f15946B = tVar;
                    } else {
                        float f25 = this.f15971O;
                        float f26 = this.M;
                        float fG5 = this.f15944A.g();
                        c12 = this.f15944A.f13705c;
                        if (c12 != null || (g17 = c12.f13696l) == null) {
                            f16 = 0.0f;
                        } else {
                            f16 = g17.f13746s;
                        }
                        this.f15980a0.b(f25, f10, f11, f26, fG5, f16);
                        this.f15950D = 0.0f;
                        int i14 = this.f15954F;
                        this.f15973Q = f10;
                        this.f15954F = i14;
                        this.f15946B = aVar;
                    }
                } else {
                    float f27 = (-f11) / fG3;
                    if ((((fG3 * f27) * f27) / 2.0f) + (f11 * f27) + f22 < 0.0f) {
                        float f28 = this.f15971O;
                        float fG6 = this.f15944A.g();
                        tVar.f13925a = f11;
                        tVar.f13926b = f28;
                        tVar.f13927c = fG6;
                        this.f15946B = tVar;
                    } else {
                        float f29 = this.f15971O;
                        float f210 = this.M;
                        float fG7 = this.f15944A.g();
                        c12 = this.f15944A.f13705c;
                        if (c12 != null) {
                            f16 = 0.0f;
                        } else {
                            f16 = 0.0f;
                        }
                        this.f15980a0.b(f29, f10, f11, f210, fG7, f16);
                        this.f15950D = 0.0f;
                        int i15 = this.f15954F;
                        this.f15973Q = f10;
                        this.f15954F = i15;
                        this.f15946B = aVar;
                    }
                }
            } else if (i10 == 6 || i10 == 7) {
                if (i10 != 1) {
                    f18 = 0.0f;
                } else {
                    f18 = 0.0f;
                }
                d10 = this.f15944A;
                c10 = d10.f13705c;
                if (c10 != null) {
                    i11 = 0;
                } else {
                    i11 = 0;
                }
                if (i11 == 0) {
                    float f110 = this.f15971O;
                    float fG8 = d10.g();
                    c11 = this.f15944A.f13705c;
                    if (c11 != null) {
                        f17 = g15.f13746s;
                    }
                    this.f15980a0.b(f110, f18, f11, fC, fG8, f17);
                } else {
                    float f211 = this.f15971O;
                    if (c10 != null) {
                        f12 = 0.0f;
                    } else {
                        f12 = 0.0f;
                    }
                    if (c10 != null) {
                        f13 = 0.0f;
                    } else {
                        f13 = 0.0f;
                    }
                    if (c10 != null) {
                        f14 = 0.0f;
                    } else {
                        f14 = 0.0f;
                    }
                    if (c10 != null) {
                        f15 = 0.0f;
                    } else {
                        f15 = 0.0f;
                    }
                    if (c10 != null) {
                        i12 = 0;
                    } else {
                        i12 = 0;
                    }
                    if (aVar.f13461b == null) {
                        T0.k kVar3 = new T0.k();
                        kVar3.f11552a = 0.5d;
                        kVar3.f11560i = 0;
                        aVar.f13461b = kVar3;
                    }
                    T0.k kVar4 = aVar.f13461b;
                    aVar.f13462c = kVar4;
                    kVar4.f11554c = f18;
                    kVar4.f11552a = f14;
                    kVar4.f11556e = f211;
                    kVar4.f11553b = f13;
                    kVar4.f11558g = f12;
                    kVar4.f11559h = f15;
                    kVar4.f11560i = i12;
                    kVar4.f11555d = 0.0f;
                }
                int i16 = this.f15954F;
                this.f15973Q = f18;
                this.f15954F = i16;
                this.f15946B = aVar;
            }
        }
        this.f15974R = false;
        this.f15966L = getNanoTime();
        invalidate();
    }

    public final void E(int i10, d dVar) {
        D d10 = this.f15944A;
        if (d10 != null) {
            d10.f13709g.put(i10, dVar);
        }
        this.f15963J0.e(this.f15944A.b(this.f15952E), this.f15944A.b(this.f15956G));
        A();
        if (this.f15954F == i10) {
            dVar.b(this);
        }
    }

    public final void F(int i10, View... viewArr) {
        String str;
        D d10 = this.f15944A;
        if (d10 == null) {
            Log.e("MotionLayout", " no motionScene");
            return;
        }
        D8.x xVar = d10.f13718q;
        xVar.getClass();
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = (ArrayList) xVar.f2612c;
        int size = arrayList2.size();
        int i11 = 0;
        I i12 = null;
        while (true) {
            str = (String) xVar.f2614e;
            if (i11 >= size) {
                break;
            }
            int i13 = i11 + 1;
            I i14 = (I) arrayList2.get(i11);
            if (i14.f13766a == i10) {
                for (View view : viewArr) {
                    if (i14.b(view)) {
                        arrayList.add(view);
                    }
                }
                if (arrayList.isEmpty()) {
                    i12 = i14;
                } else {
                    View[] viewArr2 = (View[]) arrayList.toArray(new View[0]);
                    MotionLayout motionLayout = (MotionLayout) xVar.f2611b;
                    int currentState = motionLayout.getCurrentState();
                    if (i14.f13770e != 2) {
                        if (currentState == -1) {
                            Log.w(str, "No support for ViewTransition within transition yet. Currently: " + motionLayout.toString());
                        } else {
                            D d11 = motionLayout.f15944A;
                            d dVarB = d11 == null ? null : d11.b(currentState);
                            if (dVarB != null) {
                                d dVar = dVarB;
                                i12 = i14;
                                i12.a(xVar, (MotionLayout) xVar.f2611b, currentState, dVar, viewArr2);
                            }
                        }
                        i12 = i14;
                    } else {
                        i12 = i14;
                        i12.a(xVar, (MotionLayout) xVar.f2611b, currentState, null, viewArr2);
                    }
                    arrayList.clear();
                }
            }
            i11 = i13;
        }
        if (i12 == null) {
            Log.e(str, " Could not find ViewTransition");
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void a(View view, View view2, int i10, int i11) {
        this.f15988i0 = getNanoTime();
        this.f15989j0 = 0.0f;
        this.f15986g0 = 0.0f;
        this.f15987h0 = 0.0f;
    }

    @Override // p200r1.InterfaceC1489p
    public final void b(View view, int i10) {
        G g10;
        int i11;
        D d10 = this.f15944A;
        if (d10 != null) {
            float f10 = this.f15989j0;
            if (f10 == 0.0f) {
                return;
            }
            float f11 = this.f15986g0 / f10;
            float f12 = this.f15987h0 / f10;
            C c10 = d10.f13705c;
            if (c10 == null || (g10 = c10.f13696l) == null) {
                return;
            }
            g10.f13740m = false;
            MotionLayout motionLayout = g10.f13745r;
            float progress = motionLayout.getProgress();
            g10.f13745r.v(g10.f13732d, progress, g10.f13736h, g10.f13735g, g10.f13741n);
            float f13 = g10.k;
            float[] fArr = g10.f13741n;
            float f14 = f13 != 0.0f ? (f11 * f13) / fArr[0] : (f12 * g10.f13739l) / fArr[1];
            if (!Float.isNaN(f14)) {
                progress += f14 / 3.0f;
            }
            if (progress == 0.0f || progress == 1.0f || (i11 = g10.f13731c) == 3) {
                return;
            }
            motionLayout.D(((double) progress) >= 0.5d ? 1.0f : 0.0f, f14, i11);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        C c10;
        boolean z3;
        float f10;
        G g10;
        float f11;
        G g11;
        G g12;
        G g13;
        int i13;
        D d10 = this.f15944A;
        if (d10 == null || (c10 = d10.f13705c) == null || (z3 = c10.f13699o)) {
            return;
        }
        int i14 = -1;
        if (z3 || (g13 = c10.f13696l) == null || (i13 = g13.f13733e) == -1 || view.getId() == i13) {
            C c11 = d10.f13705c;
            if ((c11 == null || (g12 = c11.f13696l) == null) ? false : g12.f13748u) {
                G g14 = c10.f13696l;
                if (g14 != null && (g14.f13750w & 4) != 0) {
                    i14 = i11;
                }
                float f12 = this.f15969N;
                if ((f12 == 1.0f || f12 == 0.0f) && view.canScrollVertically(i14)) {
                    return;
                }
            }
            G g15 = c10.f13696l;
            if (g15 == null || (g15.f13750w & 1) == 0) {
                f10 = 0.0f;
            } else {
                float f13 = i10;
                float f14 = i11;
                C c12 = d10.f13705c;
                if (c12 == null || (g11 = c12.f13696l) == null) {
                    f10 = 0.0f;
                    f11 = 0.0f;
                } else {
                    f10 = 0.0f;
                    g11.f13745r.v(g11.f13732d, g11.f13745r.getProgress(), g11.f13736h, g11.f13735g, g11.f13741n);
                    float f15 = g11.k;
                    float[] fArr = g11.f13741n;
                    if (f15 != 0.0f) {
                        if (fArr[0] == 0.0f) {
                            fArr[0] = 1.0E-7f;
                        }
                        f11 = (f13 * f15) / fArr[0];
                    } else {
                        if (fArr[1] == 0.0f) {
                            fArr[1] = 1.0E-7f;
                        }
                        f11 = (f14 * g11.f13739l) / fArr[1];
                    }
                }
                float f16 = this.f15971O;
                if ((f16 <= f10 && f11 < f10) || (f16 >= 1.0f && f11 > f10)) {
                    view.setNestedScrollingEnabled(false);
                    view.post(new s((ViewGroup) view, 0));
                    return;
                }
            }
            float f17 = this.f15969N;
            long nanoTime = getNanoTime();
            float f18 = i10;
            this.f15986g0 = f18;
            float f19 = i11;
            this.f15987h0 = f19;
            this.f15989j0 = (float) ((nanoTime - this.f15988i0) * 1.0E-9d);
            this.f15988i0 = nanoTime;
            C c13 = d10.f13705c;
            if (c13 != null && (g10 = c13.f13696l) != null) {
                MotionLayout motionLayout = g10.f13745r;
                float progress = motionLayout.getProgress();
                if (!g10.f13740m) {
                    g10.f13740m = true;
                    motionLayout.setProgress(progress);
                }
                g10.f13745r.v(g10.f13732d, progress, g10.f13736h, g10.f13735g, g10.f13741n);
                float f20 = g10.k;
                float[] fArr2 = g10.f13741n;
                if (Math.abs((g10.f13739l * fArr2[1]) + (f20 * fArr2[0])) < 0.01d) {
                    fArr2[0] = 0.01f;
                    fArr2[1] = 0.01f;
                }
                float f21 = g10.k;
                float fMax = Math.max(Math.min(progress + (f21 != f10 ? (f18 * f21) / fArr2[0] : (f19 * g10.f13739l) / fArr2[1]), 1.0f), f10);
                if (fMax != motionLayout.getProgress()) {
                    motionLayout.setProgress(fMax);
                }
            }
            if (f17 != this.f15969N) {
                iArr[0] = i10;
                iArr[1] = i11;
            }
            s(false);
            if (iArr[0] == 0 && iArr[1] == 0) {
                return;
            }
            this.f15985f0 = true;
        }
    }

    /* JADX WARN: Failed to calculate best type for var: r0v23 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r0v23 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r11v17 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r11v17 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r11v18 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r11v18 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r11v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r11v2 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r11v24 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r11v24 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r12v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r12v1 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r12v17 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r12v17 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r12v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r12v2 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r14v22 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r14v22 ??, new type: Y0.A
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v0 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v0 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v4 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v4 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v5 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v5 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v6 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v6 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v7 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v7 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v8 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v8 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r15v9 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r15v9 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r1v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r1v1 ??, new type: java.util.ArrayList
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v0 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v0 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v1 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v2 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v4 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v4 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v5 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v5 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v6 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v6 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r23v7 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r23v7 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r2v6 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r2v6 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v1 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v12 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v12 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v18 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v18 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v19 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v19 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v2 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v23 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v23 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v3 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v3 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v30 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v30 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v38 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v38 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v49 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v49 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v56 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v56 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v8 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v8 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r3v9 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r3v9 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r4v30 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v30 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r4v31 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v31 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r4v32 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v32 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r4v33 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v33 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r4v5 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v5 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r5v20 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r5v20 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r5v21 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r5v21 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r8v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v1 ??, new type: java.util.ArrayList
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r8v15 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v15 ??, new type: Y0.A
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r8v16 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v16 ??, new type: java.util.ArrayList
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r8v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r8v2 ??, new type: java.util.ArrayList
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r9v0 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r9v0 ??, new type: Y0.D
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r9v1 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r9v1 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r9v2 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r9v2 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r9v3 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r9v3 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to calculate best type for var: r9v4 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r9v4 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.calculateFromBounds(TypeInferenceVisitor.java:147)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setBestType(TypeInferenceVisitor.java:125)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$2(TypeInferenceVisitor.java:103)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:103)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Failed to set immutable type for var: r4v5 ??
    jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r4v5 ??, new type: int
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
    	at jadx.core.dex.visitors.typeinference.TypeUpdate.applyWithWiderIgnSame(TypeUpdate.java:73)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.setImmutableType(TypeInferenceVisitor.java:111)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.lambda$runTypePropagation$1(TypeInferenceVisitor.java:102)
    	at java.base/java.util.ArrayList.forEach(ArrayList.java:1612)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.runTypePropagation(TypeInferenceVisitor.java:102)
    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:75)
    Caused by: java.lang.NullPointerException
     */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$PrimitiveArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    /*  JADX ERROR: Types fix failed
        jadx.core.utils.exceptions.JadxRuntimeException: Type update failed for variable: r16v0 ??, new type: boolean
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:109)
        	at jadx.core.dex.visitors.typeinference.TypeUpdate.apply(TypeUpdate.java:59)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryPossibleTypes(FixTypesVisitor.java:186)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.deduceType(FixTypesVisitor.java:245)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryDeduceTypes(FixTypesVisitor.java:224)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
        Caused by: java.lang.NullPointerException
        */
    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public final void dispatchDraw(android.graphics.Canvas r38) {
        /*
            Method dump skipped, instruction units count: 1374
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.dispatchDraw(android.graphics.Canvas):void");
    }

    @Override // p200r1.InterfaceC1490q
    public final void g(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        if (this.f15985f0 || i10 != 0 || i11 != 0) {
            iArr[0] = iArr[0] + i12;
            iArr[1] = iArr[1] + i13;
        }
        this.f15985f0 = false;
    }

    public int[] getConstraintSetIds() {
        D d10 = this.f15944A;
        if (d10 == null) {
            return null;
        }
        SparseArray sparseArray = d10.f13709g;
        int size = sparseArray.size();
        int[] iArr = new int[size];
        for (int i10 = 0; i10 < size; i10++) {
            iArr[i10] = sparseArray.keyAt(i10);
        }
        return iArr;
    }

    public int getCurrentState() {
        return this.f15954F;
    }

    public ArrayList<C> getDefinedTransitions() {
        D d10 = this.f15944A;
        if (d10 == null) {
            return null;
        }
        return d10.f13706d;
    }

    public C0776a getDesignTool() {
        if (this.f15982c0 == null) {
            this.f15982c0 = new C0776a();
        }
        return this.f15982c0;
    }

    public int getEndState() {
        return this.f15956G;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.f15971O;
    }

    public D getScene() {
        return this.f15944A;
    }

    public int getStartState() {
        return this.f15952E;
    }

    public float getTargetPosition() {
        return this.f15973Q;
    }

    public Bundle getTransitionState() {
        if (this.f15953E0 == null) {
            this.f15953E0 = new x(this);
        }
        x xVar = this.f15953E0;
        MotionLayout motionLayout = xVar.f13955e;
        xVar.f13954d = motionLayout.f15956G;
        xVar.f13953c = motionLayout.f15952E;
        xVar.f13952b = motionLayout.getVelocity();
        xVar.f13951a = motionLayout.getProgress();
        x xVar2 = this.f15953E0;
        xVar2.getClass();
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", xVar2.f13951a);
        bundle.putFloat("motion.velocity", xVar2.f13952b);
        bundle.putInt("motion.StartState", xVar2.f13953c);
        bundle.putInt("motion.EndState", xVar2.f13954d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        D d10 = this.f15944A;
        if (d10 != null) {
            this.M = d10.c() / 1000.0f;
        }
        return (long) (this.M * 1000.0f);
    }

    public float getVelocity() {
        return this.f15950D;
    }

    @Override // p200r1.InterfaceC1489p
    public final boolean j(View view, View view2, int i10, int i11) {
        C c10;
        G g10;
        D d10 = this.f15944A;
        return (d10 == null || (c10 = d10.f13705c) == null || (g10 = c10.f13696l) == null || (g10.f13750w & 2) != 0) ? false : true;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public final void l(int i10) {
        this.f16128u = null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        C c10;
        int i10;
        super.onAttachedToWindow();
        Display display = getDisplay();
        if (display != null) {
            display.getRotation();
        }
        D d10 = this.f15944A;
        if (d10 != null && (i10 = this.f15954F) != -1) {
            d dVarB = d10.b(i10);
            D d11 = this.f15944A;
            int i11 = 0;
            int i12 = 0;
            loop0: while (true) {
                SparseArray sparseArray = d11.f13709g;
                if (i12 >= sparseArray.size()) {
                    break;
                }
                int iKeyAt = sparseArray.keyAt(i12);
                SparseIntArray sparseIntArray = d11.f13711i;
                int i13 = sparseIntArray.get(iKeyAt);
                int size = sparseIntArray.size();
                while (true) {
                    if (i13 > 0) {
                        if (i13 != iKeyAt) {
                            int i14 = size - 1;
                            if (size >= 0) {
                                i13 = sparseIntArray.get(i13);
                                size = i14;
                            }
                        }
                        Log.e("MotionScene", "Cannot be derived from yourself");
                        break loop0;
                    }
                    d11.m(iKeyAt, this);
                    i12++;
                }
            }
            ArrayList arrayList = this.f15993n0;
            if (arrayList != null) {
                int size2 = arrayList.size();
                while (i11 < size2) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    ((MotionHelper) obj).getClass();
                }
            }
            if (dVarB != null) {
                dVarB.b(this);
            }
            this.f15952E = this.f15954F;
        }
        y();
        x xVar = this.f15953E0;
        if (xVar != null) {
            if (this.f15959H0) {
                post(new s(this, 1));
                return;
            } else {
                xVar.a();
                return;
            }
        }
        D d12 = this.f15944A;
        if (d12 == null || (c10 = d12.f13705c) == null || c10.f13698n != 4) {
            return;
        }
        q(1.0f);
        this.f15955F0 = null;
        setState(z.f13957b);
        setState(z.f13958c);
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        G g10;
        int i10;
        RectF rectFB;
        MotionLayout motionLayout;
        int currentState;
        char c10;
        char c11;
        D d10 = this.f15944A;
        if (d10 == null || !this.f15962J) {
            return false;
        }
        D8.x xVar = d10.f13718q;
        if (xVar == null || (currentState = (motionLayout = (MotionLayout) xVar.f2611b).getCurrentState()) == -1) {
            z3 = false;
        } else {
            HashSet hashSet = (HashSet) xVar.f2613d;
            ArrayList arrayList = (ArrayList) xVar.f2612c;
            if (hashSet == null) {
                xVar.f2613d = new HashSet();
                int size = arrayList.size();
                int i11 = 0;
                while (i11 < size) {
                    Object obj = arrayList.get(i11);
                    i11++;
                    I i12 = (I) obj;
                    int childCount = motionLayout.getChildCount();
                    for (int i13 = 0; i13 < childCount; i13++) {
                        View childAt = motionLayout.getChildAt(i13);
                        if (i12.c(childAt)) {
                            childAt.getId();
                            ((HashSet) xVar.f2613d).add(childAt);
                        }
                    }
                }
            }
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            Rect rect = new Rect();
            int action = motionEvent.getAction();
            ArrayList arrayList2 = (ArrayList) xVar.f2615f;
            int i14 = 1;
            int i15 = 2;
            if (arrayList2 != null && !arrayList2.isEmpty()) {
                ArrayList arrayList3 = (ArrayList) xVar.f2615f;
                int size2 = arrayList3.size();
                int i16 = 0;
                while (i16 < size2) {
                    Object obj2 = arrayList3.get(i16);
                    i16++;
                    H h10 = (H) obj2;
                    if (action != i14) {
                        if (action != i15) {
                            h10.getClass();
                        } else {
                            View view = h10.f13756c.f13899b;
                            Rect rect2 = h10.f13764l;
                            view.getHitRect(rect2);
                            if (!rect2.contains((int) x10, (int) y10) && !h10.f13761h) {
                                h10.b();
                            }
                        }
                    } else if (!h10.f13761h) {
                        h10.b();
                    }
                    i15 = 2;
                    i14 = 1;
                }
            }
            z3 = false;
            if (action == 0 || action == 1) {
                D d11 = motionLayout.f15944A;
                d dVarB = d11 == null ? null : d11.b(currentState);
                int size3 = arrayList.size();
                int i17 = 0;
                while (i17 < size3) {
                    Object obj3 = arrayList.get(i17);
                    i17++;
                    I i18 = (I) obj3;
                    int i19 = i18.f13767b;
                    if (i19 != 1) {
                        c10 = 2;
                        if (i19 != 2 ? !(i19 != 3 || action != 0) : action == 1) {
                        }
                    } else if (action == 0) {
                        c10 = 2;
                    }
                    for (View view2 : (HashSet) xVar.f2613d) {
                        if (i18.c(view2)) {
                            view2.getHitRect(rect);
                            if (rect.contains((int) x10, (int) y10)) {
                                c11 = 2;
                                i18.a(xVar, (MotionLayout) xVar.f2611b, currentState, dVarB, view2);
                            } else {
                                c11 = 2;
                            }
                            c10 = c11;
                        }
                    }
                }
            }
        }
        C c12 = this.f15944A.f13705c;
        if (c12 == null || c12.f13699o || (g10 = c12.f13696l) == null) {
            return z3;
        }
        if ((motionEvent.getAction() == 0 && (rectFB = g10.b(this, new RectF())) != null && !rectFB.contains(motionEvent.getX(), motionEvent.getY())) || (i10 = g10.f13733e) == -1) {
            return z3;
        }
        View view3 = this.f15968M0;
        if (view3 == null || view3.getId() != i10) {
            this.f15968M0 = findViewById(i10);
        }
        View view4 = this.f15968M0;
        if (view4 == null) {
            return z3;
        }
        RectF rectF = this.f15967L0;
        rectF.set(view4.getLeft(), this.f15968M0.getTop(), this.f15968M0.getRight(), this.f15968M0.getBottom());
        return (!rectF.contains(motionEvent.getX(), motionEvent.getY()) || x((float) this.f15968M0.getLeft(), (float) this.f15968M0.getTop(), this.f15968M0, motionEvent)) ? z3 : onTouchEvent(motionEvent);
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) throws Throwable {
        MotionLayout motionLayout;
        this.f15951D0 = true;
        try {
            if (this.f15944A == null) {
                super.onLayout(z3, i10, i11, i12, i13);
                this.f15951D0 = false;
                return;
            }
            motionLayout = this;
            int i14 = i12 - i10;
            int i15 = i13 - i11;
            try {
                if (motionLayout.f15983d0 != i14 || motionLayout.f15984e0 != i15) {
                    A();
                    s(true);
                }
                motionLayout.f15983d0 = i14;
                motionLayout.f15984e0 = i15;
                motionLayout.f15951D0 = false;
                return;
            } catch (Throwable th) {
                th = th;
            }
        } catch (Throwable th2) {
            th = th2;
            motionLayout = this;
        }
        Throwable th3 = th;
        motionLayout.f15951D0 = false;
        throw th3;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        boolean z3;
        if (this.f15944A == null) {
            super.onMeasure(i10, i11);
            return;
        }
        boolean z5 = true;
        boolean z10 = (this.f15958H == i10 && this.f15960I == i11) ? false : true;
        if (this.f15965K0) {
            this.f15965K0 = false;
            y();
            z();
            z10 = true;
        }
        if (this.f16125r) {
            z10 = true;
        }
        this.f15958H = i10;
        this.f15960I = i11;
        int iH = this.f15944A.h();
        C c10 = this.f15944A.f13705c;
        int i12 = c10 == null ? -1 : c10.f13688c;
        f fVar = this.f16120c;
        v vVar = this.f15963J0;
        if ((!z10 && iH == vVar.f13946e && i12 == vVar.f13947f) || this.f15952E == -1) {
            if (z10) {
                super.onMeasure(i10, i11);
            }
            z3 = true;
        } else {
            super.onMeasure(i10, i11);
            vVar.e(this.f15944A.b(iH), this.f15944A.b(i12));
            vVar.f();
            vVar.f13946e = iH;
            vVar.f13947f = i12;
            z3 = false;
        }
        if (this.f16000u0 || z3) {
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int iR = fVar.r() + getPaddingRight() + getPaddingLeft();
            int iL = fVar.l() + paddingBottom;
            int i13 = this.f16004z0;
            if (i13 == Integer.MIN_VALUE || i13 == 0) {
                int i14 = this.v0;
                iR = (int) ((this.f15947B0 * (this.f16002x0 - i14)) + i14);
                requestLayout();
            }
            int i15 = this.f15945A0;
            if (i15 == Integer.MIN_VALUE || i15 == 0) {
                int i16 = this.f16001w0;
                iL = (int) ((this.f15947B0 * (this.f16003y0 - i16)) + i16);
                requestLayout();
            }
            setMeasuredDimension(iR, iL);
        }
        float fSignum = Math.signum(this.f15973Q - this.f15971O);
        long nanoTime = getNanoTime();
        r rVar = this.f15946B;
        float interpolation = this.f15971O + (!(rVar instanceof a) ? (((nanoTime - this.f15972P) * fSignum) * 1.0E-9f) / this.M : 0.0f);
        if (this.f15974R) {
            interpolation = this.f15973Q;
        }
        if ((fSignum <= 0.0f || interpolation < this.f15973Q) && (fSignum > 0.0f || interpolation > this.f15973Q)) {
            z5 = false;
        } else {
            interpolation = this.f15973Q;
        }
        if (rVar != null && !z5) {
            interpolation = this.f15979W ? rVar.getInterpolation((nanoTime - this.f15966L) * 1.0E-9f) : rVar.getInterpolation(interpolation);
        }
        if ((fSignum > 0.0f && interpolation >= this.f15973Q) || (fSignum <= 0.0f && interpolation <= this.f15973Q)) {
            interpolation = this.f15973Q;
        }
        this.f15947B0 = interpolation;
        int childCount = getChildCount();
        long nanoTime2 = getNanoTime();
        Interpolator interpolator = this.f15948C;
        if (interpolator != null) {
            interpolation = interpolator.getInterpolation(interpolation);
        }
        float f10 = interpolation;
        for (int i17 = 0; i17 < childCount; i17++) {
            View childAt = getChildAt(i17);
            q qVar = (q) this.f15964K.get(childAt);
            if (qVar != null) {
                qVar.f(f10, nanoTime2, this.f15949C0, childAt);
            }
        }
        if (this.f16000u0) {
            requestLayout();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        G g10;
        D d10 = this.f15944A;
        if (d10 != null) {
            boolean zK = k();
            d10.f13717p = zK;
            C c10 = d10.f13705c;
            if (c10 == null || (g10 = c10.f13696l) == null) {
                return;
            }
            g10.c(zK);
        }
    }

    /* JADX WARN: Code duplicated, block: B:107:0x0232  */
    /* JADX WARN: Code duplicated, block: B:110:0x0238  */
    /* JADX WARN: Code duplicated, block: B:112:0x023c  */
    /* JADX WARN: Code duplicated, block: B:118:0x0254  */
    /* JADX WARN: Code duplicated, block: B:120:0x0258  */
    /* JADX WARN: Code duplicated, block: B:123:0x0261  */
    /* JADX WARN: Code duplicated, block: B:125:0x026f  */
    /* JADX WARN: Code duplicated, block: B:128:0x0274  */
    /* JADX WARN: Code duplicated, block: B:130:0x028d  */
    /* JADX WARN: Code duplicated, block: B:131:0x02be  */
    /* JADX WARN: Code duplicated, block: B:133:0x02c3  */
    /* JADX WARN: Code duplicated, block: B:135:0x02d9  */
    /* JADX WARN: Code duplicated, block: B:136:0x02e1  */
    /* JADX WARN: Code duplicated, block: B:139:0x0343  */
    /* JADX WARN: Code duplicated, block: B:140:0x0346  */
    /* JADX WARN: Code duplicated, block: B:142:0x034c  */
    /* JADX WARN: Code duplicated, block: B:145:0x0357  */
    /* JADX WARN: Code duplicated, block: B:147:0x035b  */
    /* JADX WARN: Code duplicated, block: B:149:0x0363  */
    /* JADX WARN: Code duplicated, block: B:150:0x036a  */
    /* JADX WARN: Code duplicated, block: B:153:0x0370  */
    /* JADX WARN: Code duplicated, block: B:154:0x0396  */
    /* JADX WARN: Code duplicated, block: B:157:0x03ba  */
    /* JADX WARN: Code duplicated, block: B:159:0x03be  */
    /* JADX WARN: Code duplicated, block: B:161:0x03c2 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:162:0x03c4  */
    /* JADX WARN: Code duplicated, block: B:163:0x03c6  */
    /* JADX WARN: Code duplicated, block: B:167:0x03d1  */
    /* JADX WARN: Code duplicated, block: B:170:0x03da  */
    /* JADX WARN: Code duplicated, block: B:171:0x03df  */
    /* JADX WARN: Code duplicated, block: B:174:0x03e4  */
    /* JADX WARN: Code duplicated, block: B:175:0x03e9  */
    /* JADX WARN: Code duplicated, block: B:177:0x040b  */
    /* JADX WARN: Code duplicated, block: B:179:0x041b  */
    /* JADX WARN: Code duplicated, block: B:181:0x0422  */
    /* JADX WARN: Code duplicated, block: B:184:0x042b  */
    /* JADX WARN: Code duplicated, block: B:185:0x0430  */
    /* JADX WARN: Code duplicated, block: B:188:0x0435  */
    /* JADX WARN: Code duplicated, block: B:189:0x043a  */
    /* JADX WARN: Code duplicated, block: B:192:0x0452  */
    /* JADX WARN: Code duplicated, block: B:194:0x0483  */
    /* JADX WARN: Code duplicated, block: B:196:0x0488  */
    /* JADX WARN: Code duplicated, block: B:197:0x04bf A[PHI: r8 r9
  0x04bf: PHI (r8v12 float) = (r8v4 float), (r8v27 float) binds: [B:195:0x0486, B:193:0x0478] A[DONT_GENERATE, DONT_INLINE]
  0x04bf: PHI (r9v34 float) = (r9v29 float), (r9v40 float) binds: [B:195:0x0486, B:193:0x0478] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:199:0x04da  */
    /* JADX WARN: Code duplicated, block: B:200:0x04fe  */
    /* JADX WARN: Code duplicated, block: B:203:0x051c  */
    /* JADX WARN: Code duplicated, block: B:205:0x052b  */
    /* JADX WARN: Code duplicated, block: B:208:0x0532  */
    /* JADX WARN: Code duplicated, block: B:233:0x058d  */
    /* JADX WARN: Code duplicated, block: B:235:0x0595  */
    /* JADX WARN: Code duplicated, block: B:237:0x059b  */
    /* JADX WARN: Code duplicated, block: B:238:0x05a0  */
    /* JADX WARN: Code duplicated, block: B:239:0x05b1  */
    /* JADX WARN: Code duplicated, block: B:241:0x05bb  */
    /* JADX WARN: Code duplicated, block: B:244:0x05c4  */
    /* JADX WARN: Code duplicated, block: B:246:0x05c7  */
    /* JADX WARN: Code duplicated, block: B:249:0x05cc  */
    /* JADX WARN: Code duplicated, block: B:251:0x05eb  */
    /* JADX WARN: Code duplicated, block: B:253:0x05ef  */
    /* JADX WARN: Code duplicated, block: B:255:0x05f7  */
    /* JADX WARN: Code duplicated, block: B:258:0x0602  */
    /* JADX WARN: Code duplicated, block: B:259:0x0612  */
    /* JADX WARN: Code duplicated, block: B:262:0x0649  */
    /* JADX WARN: Code duplicated, block: B:265:0x0654  */
    /* JADX WARN: Code duplicated, block: B:266:0x0658  */
    /* JADX WARN: Code duplicated, block: B:269:0x066c  */
    /* JADX WARN: Code duplicated, block: B:272:0x0675  */
    /* JADX WARN: Code duplicated, block: B:275:0x0684  */
    /* JADX WARN: Code duplicated, block: B:277:0x068a  */
    /* JADX WARN: Code duplicated, block: B:279:0x0690 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:280:0x0692  */
    /* JADX WARN: Code duplicated, block: B:281:0x0694  */
    /* JADX WARN: Code duplicated, block: B:285:0x069f  */
    /* JADX WARN: Code duplicated, block: B:288:0x06a8  */
    /* JADX WARN: Code duplicated, block: B:289:0x06ad  */
    /* JADX WARN: Code duplicated, block: B:292:0x06b2  */
    /* JADX WARN: Code duplicated, block: B:293:0x06b7  */
    /* JADX WARN: Code duplicated, block: B:296:0x06bf  */
    /* JADX WARN: Code duplicated, block: B:297:0x06c5  */
    /* JADX WARN: Code duplicated, block: B:299:0x06ce  */
    /* JADX WARN: Code duplicated, block: B:301:0x06df  */
    /* JADX WARN: Code duplicated, block: B:303:0x06e6  */
    /* JADX WARN: Code duplicated, block: B:306:0x06ef  */
    /* JADX WARN: Code duplicated, block: B:307:0x06f4  */
    /* JADX WARN: Code duplicated, block: B:310:0x06f9  */
    /* JADX WARN: Code duplicated, block: B:311:0x06fe  */
    /* JADX WARN: Code duplicated, block: B:314:0x0708  */
    /* JADX WARN: Code duplicated, block: B:315:0x0718  */
    /* JADX WARN: Code duplicated, block: B:318:0x073f  */
    /* JADX WARN: Code duplicated, block: B:319:0x0741  */
    /* JADX WARN: Code duplicated, block: B:322:0x0749  */
    /* JADX WARN: Code duplicated, block: B:324:0x074f  */
    /* JADX WARN: Code duplicated, block: B:327:0x0755  */
    /* JADX WARN: Code duplicated, block: B:352:0x07a3  */
    /* JADX WARN: Code duplicated, block: B:354:0x07a9  */
    /* JADX WARN: Code duplicated, block: B:356:0x07af  */
    /* JADX WARN: Code duplicated, block: B:357:0x07b3  */
    /* JADX WARN: Code duplicated, block: B:360:0x07d5  */
    /* JADX WARN: Code duplicated, block: B:364:0x07dd  */
    /* JADX WARN: Code duplicated, block: B:365:0x07e4  */
    /* JADX WARN: Code duplicated, block: B:368:0x07ec  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r19v15 */
    /* JADX WARN: Type inference failed for: r19v20 */
    /* JADX WARN: Type inference failed for: r19v21 */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C c10;
        w wVar;
        VelocityTracker velocityTracker;
        w wVar2;
        int i10;
        G g10;
        w wVar3;
        boolean z3;
        z zVar;
        float[] fArr;
        MotionLayout motionLayout;
        VelocityTracker velocityTracker2;
        int action;
        VelocityTracker velocityTracker3;
        VelocityTracker velocityTracker4;
        float xVelocity;
        VelocityTracker velocityTracker5;
        float yVelocity;
        float progress;
        int i11;
        char c11;
        char c12;
        float f10;
        float f11;
        float f12;
        float fAbs;
        float f13;
        int i12;
        float rawY;
        float rawX;
        float progress2;
        int i13;
        char c13;
        char c14;
        float f14;
        float fMax;
        float progress3;
        boolean z5;
        VelocityTracker velocityTracker6;
        VelocityTracker velocityTracker7;
        float xVelocity2;
        VelocityTracker velocityTracker8;
        float yVelocity2;
        float f15;
        VelocityTracker velocityTracker9;
        int action2;
        int[] iArr;
        VelocityTracker velocityTracker10;
        VelocityTracker velocityTracker11;
        float xVelocity3;
        VelocityTracker velocityTracker12;
        float yVelocity3;
        float progress4;
        int i14;
        int i15;
        float right;
        float f16;
        int top;
        int bottom;
        int i16;
        float degrees;
        float f17;
        int i17;
        float width;
        float height;
        int i18;
        int i19;
        View viewFindViewById;
        float rawX2;
        float rawY2;
        double dAtan2;
        float fAtan2;
        float progress5;
        boolean z10;
        int i20;
        float f18;
        ?? r19;
        float fMax2;
        float progress6;
        boolean z11;
        VelocityTracker velocityTracker13;
        VelocityTracker velocityTracker14;
        float xVelocity4;
        VelocityTracker velocityTracker15;
        float yVelocity4;
        MotionEvent motionEvent2;
        C c15;
        int iM;
        int i21;
        float f19;
        D d10 = this.f15944A;
        if (d10 == null || !this.f15962J || !d10.o()) {
            return super.onTouchEvent(motionEvent);
        }
        D d11 = this.f15944A;
        C c16 = d11.f13705c;
        if (c16 != null && c16.f13699o) {
            return super.onTouchEvent(motionEvent);
        }
        int currentState = getCurrentState();
        RectF rectF = new RectF();
        w wVar4 = d11.f13716o;
        MotionLayout motionLayout2 = d11.f13703a;
        if (wVar4 == null) {
            motionLayout2.getClass();
            w wVar5 = w.f13949b;
            wVar5.f13950a = VelocityTracker.obtain();
            d11.f13716o = wVar5;
        }
        VelocityTracker velocityTracker16 = d11.f13716o.f13950a;
        if (velocityTracker16 != null) {
            velocityTracker16.addMovement(motionEvent);
        }
        if (currentState != -1) {
            int action3 = motionEvent.getAction();
            if (action3 == 0) {
                d11.f13719r = motionEvent.getRawX();
                d11.f13720s = motionEvent.getRawY();
                d11.f13713l = motionEvent;
                d11.f13714m = false;
                G g11 = d11.f13705c.f13696l;
                if (g11 != null) {
                    RectF rectFA = g11.a(motionLayout2, rectF);
                    if (rectFA == null || rectFA.contains(d11.f13713l.getX(), d11.f13713l.getY())) {
                        RectF rectFB = d11.f13705c.f13696l.b(motionLayout2, rectF);
                        if (rectFB == null || rectFB.contains(d11.f13713l.getX(), d11.f13713l.getY())) {
                            d11.f13715n = false;
                        } else {
                            d11.f13715n = true;
                        }
                        G g12 = d11.f13705c.f13696l;
                        float f20 = d11.f13719r;
                        float f21 = d11.f13720s;
                        g12.f13743p = f20;
                        g12.f13744q = f21;
                    } else {
                        d11.f13713l = null;
                        d11.f13714m = true;
                    }
                }
            } else if (action3 == 2 && !d11.f13714m) {
                float rawY3 = motionEvent.getRawY() - d11.f13720s;
                float rawX3 = motionEvent.getRawX() - d11.f13719r;
                if ((rawX3 != 0.0d || rawY3 != 0.0d) && (motionEvent2 = d11.f13713l) != null) {
                    if (currentState != -1) {
                        l lVar = d11.f13704b;
                        if (lVar == null || (iM = lVar.m(currentState)) == -1) {
                            iM = currentState;
                        }
                        ArrayList arrayList = new ArrayList();
                        ArrayList arrayList2 = d11.f13706d;
                        int size = arrayList2.size();
                        int i22 = 0;
                        while (i22 < size) {
                            Object obj = arrayList2.get(i22);
                            i22++;
                            C c17 = (C) obj;
                            if (c17.f13689d == iM || c17.f13688c == iM) {
                                arrayList.add(c17);
                            }
                        }
                        RectF rectF2 = new RectF();
                        int size2 = arrayList.size();
                        float f22 = 0.0f;
                        int i23 = 0;
                        c15 = null;
                        while (i23 < size2) {
                            Object obj2 = arrayList.get(i23);
                            i23++;
                            C c18 = (C) obj2;
                            arrayList = arrayList;
                            if (c18.f13699o) {
                                i21 = size2;
                                f19 = f22;
                            } else {
                                G g13 = c18.f13696l;
                                if (g13 != null) {
                                    i21 = size2;
                                    g13.c(d11.f13717p);
                                    RectF rectFB2 = c18.f13696l.b(motionLayout2, rectF2);
                                    if (rectFB2 != null) {
                                        f19 = f22;
                                        if (!rectFB2.contains(motionEvent2.getX(), motionEvent2.getY())) {
                                        }
                                    } else {
                                        f19 = f22;
                                    }
                                    RectF rectFA2 = c18.f13696l.a(motionLayout2, rectF2);
                                    if (rectFA2 == null || rectFA2.contains(motionEvent2.getX(), motionEvent2.getY())) {
                                        G g14 = c18.f13696l;
                                        float fAtan3 = (g14.f13739l * rawY3) + (g14.k * rawX3);
                                        if (g14.f13738j) {
                                            float x10 = motionEvent2.getX();
                                            c18.f13696l.getClass();
                                            float f23 = x10 - 0.5f;
                                            float y10 = motionEvent2.getY();
                                            c18.f13696l.getClass();
                                            float f24 = y10 - 0.5f;
                                            fAtan3 = ((float) (Math.atan2(rawY3 + f24, rawX3 + f23) - Math.atan2(f23, f24))) * 10.0f;
                                        }
                                        f22 = fAtan3 * (c18.f13688c == currentState ? -1.0f : 1.1f);
                                        if (f22 > f19) {
                                            c15 = c18;
                                        }
                                        rawY3 = rawY3;
                                        size2 = i21;
                                        rectF2 = rectF2;
                                        i23 = i23;
                                        rawX3 = rawX3;
                                    }
                                } else {
                                    rectF2 = rectF2;
                                    i21 = size2;
                                    f19 = f22;
                                    i23 = i23;
                                    c15 = c15;
                                    rawY3 = rawY3;
                                    rawX3 = rawX3;
                                }
                                f22 = f19;
                                c15 = c15;
                                rawY3 = rawY3;
                                size2 = i21;
                                rectF2 = rectF2;
                                i23 = i23;
                                rawX3 = rawX3;
                            }
                            size2 = i21;
                            f22 = f19;
                        }
                    } else {
                        c15 = d11.f13705c;
                    }
                    if (c15 != null) {
                        setTransition(c15);
                        RectF rectFB3 = d11.f13705c.f13696l.b(motionLayout2, rectF);
                        d11.f13715n = (rectFB3 == null || rectFB3.contains(d11.f13713l.getX(), d11.f13713l.getY())) ? false : true;
                        G g15 = d11.f13705c.f13696l;
                        float f25 = d11.f13719r;
                        float f26 = d11.f13720s;
                        g15.f13743p = f25;
                        g15.f13744q = f26;
                        g15.f13740m = false;
                    }
                    if (!d11.f13714m) {
                        c10 = d11.f13705c;
                        if (c10 != null) {
                            wVar3 = d11.f13716o;
                            z3 = g10.f13738j;
                            zVar = z.f13959d;
                            fArr = g10.f13741n;
                            motionLayout = g10.f13745r;
                            if (z3) {
                                velocityTracker9 = wVar3.f13950a;
                                if (velocityTracker9 != null) {
                                    velocityTracker9.addMovement(motionEvent);
                                }
                                action2 = motionEvent.getAction();
                                if (action2 != 0) {
                                    iArr = g10.f13742o;
                                    if (action2 == 1) {
                                        g10.f13740m = false;
                                        velocityTracker10 = wVar3.f13950a;
                                        if (velocityTracker10 != null) {
                                            velocityTracker10.computeCurrentVelocity(16);
                                        }
                                        velocityTracker11 = wVar3.f13950a;
                                        if (velocityTracker11 != null) {
                                            xVelocity3 = velocityTracker11.getXVelocity();
                                        } else {
                                            xVelocity3 = 0.0f;
                                        }
                                        velocityTracker12 = wVar3.f13950a;
                                        if (velocityTracker12 != null) {
                                            yVelocity3 = velocityTracker12.getYVelocity();
                                        } else {
                                            yVelocity3 = 0.0f;
                                        }
                                        progress4 = motionLayout.getProgress();
                                        float width2 = motionLayout.getWidth() / 2.0f;
                                        float height2 = motionLayout.getHeight() / 2.0f;
                                        i14 = g10.f13737i;
                                        if (i14 != -1) {
                                            View viewFindViewById2 = motionLayout.findViewById(i14);
                                            motionLayout.getLocationOnScreen(iArr);
                                            right = iArr[0] + ((viewFindViewById2.getRight() + viewFindViewById2.getLeft()) / 2.0f);
                                            f16 = iArr[1];
                                            top = viewFindViewById2.getTop();
                                            bottom = viewFindViewById2.getBottom();
                                        } else {
                                            i15 = g10.f13732d;
                                            if (i15 != -1) {
                                                View viewFindViewById3 = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i15))).f13903f.f13677u);
                                                motionLayout.getLocationOnScreen(iArr);
                                                right = iArr[0] + ((viewFindViewById3.getRight() + viewFindViewById3.getLeft()) / 2.0f);
                                                f16 = iArr[1];
                                                top = viewFindViewById3.getTop();
                                                bottom = viewFindViewById3.getBottom();
                                            } else {
                                                float rawX4 = motionEvent.getRawX() - width2;
                                                float rawY4 = motionEvent.getRawY() - height2;
                                                double degrees2 = Math.toDegrees(Math.atan2(rawY4, rawX4));
                                                i16 = g10.f13732d;
                                                if (i16 != -1) {
                                                    g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                                    fArr[1] = (float) Math.toDegrees(fArr[1]);
                                                } else {
                                                    fArr[1] = 360.0f;
                                                }
                                                degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY4, xVelocity3 + rawX4)) - degrees2)) * 62.5f;
                                                if (Float.isNaN(degrees)) {
                                                    f17 = progress4;
                                                } else {
                                                    f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                                                }
                                                if (f17 == 0.0f) {
                                                    if (0.0f < f17) {
                                                        motionLayout.setState(zVar);
                                                    } else {
                                                        motionLayout.setState(zVar);
                                                    }
                                                } else if (0.0f < f17) {
                                                    motionLayout.setState(zVar);
                                                } else {
                                                    motionLayout.setState(zVar);
                                                }
                                            }
                                        }
                                        float f27 = right;
                                        height2 = ((bottom + top) / 2.0f) + f16;
                                        width2 = f27;
                                        float rawX5 = motionEvent.getRawX() - width2;
                                        float rawY5 = motionEvent.getRawY() - height2;
                                        double degrees3 = Math.toDegrees(Math.atan2(rawY5, rawX5));
                                        i16 = g10.f13732d;
                                        if (i16 != -1) {
                                            g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                            fArr[1] = (float) Math.toDegrees(fArr[1]);
                                        } else {
                                            fArr[1] = 360.0f;
                                        }
                                        degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY5, xVelocity3 + rawX5)) - degrees3)) * 62.5f;
                                        if (Float.isNaN(degrees)) {
                                            f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                                        } else {
                                            f17 = progress4;
                                        }
                                        if (f17 == 0.0f) {
                                            if (0.0f < f17) {
                                                motionLayout.setState(zVar);
                                            } else {
                                                motionLayout.setState(zVar);
                                            }
                                        } else if (0.0f < f17) {
                                            motionLayout.setState(zVar);
                                        } else {
                                            motionLayout.setState(zVar);
                                        }
                                    } else if (action2 == 2) {
                                        motionEvent.getRawY();
                                        motionEvent.getRawX();
                                        width = motionLayout.getWidth() / 2.0f;
                                        height = motionLayout.getHeight() / 2.0f;
                                        i18 = g10.f13737i;
                                        if (i18 != -1) {
                                            View viewFindViewById4 = motionLayout.findViewById(i18);
                                            motionLayout.getLocationOnScreen(iArr);
                                            float right2 = iArr[0] + ((viewFindViewById4.getRight() + viewFindViewById4.getLeft()) / 2.0f);
                                            height = ((viewFindViewById4.getBottom() + viewFindViewById4.getTop()) / 2.0f) + iArr[1];
                                            width = right2;
                                        } else {
                                            i19 = g10.f13732d;
                                            if (i19 != -1) {
                                                viewFindViewById = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i19))).f13903f.f13677u);
                                                if (viewFindViewById == null) {
                                                    Log.e("TouchResponse", "could not find view to animate to");
                                                } else {
                                                    motionLayout.getLocationOnScreen(iArr);
                                                    width = iArr[0] + ((viewFindViewById.getRight() + viewFindViewById.getLeft()) / 2.0f);
                                                    height = iArr[1] + ((viewFindViewById.getBottom() + viewFindViewById.getTop()) / 2.0f);
                                                }
                                            }
                                        }
                                        rawX2 = motionEvent.getRawX() - width;
                                        rawY2 = motionEvent.getRawY() - height;
                                        dAtan2 = Math.atan2(motionEvent.getRawY() - height, motionEvent.getRawX() - width);
                                        fAtan2 = (float) (((dAtan2 - Math.atan2(g10.f13744q - height, g10.f13743p - width)) * 180.0d) / 3.141592653589793d);
                                        if (fAtan2 > 330.0f) {
                                            fAtan2 -= 360.0f;
                                        } else if (fAtan2 < -330.0f) {
                                            fAtan2 += 360.0f;
                                        }
                                        if (Math.abs(fAtan2) <= 0.01d) {
                                            progress5 = motionLayout.getProgress();
                                            if (g10.f13740m) {
                                                z10 = true;
                                            } else {
                                                z10 = true;
                                                g10.f13740m = true;
                                                motionLayout.setProgress(progress5);
                                            }
                                            i20 = g10.f13732d;
                                            if (i20 != -1) {
                                                boolean z12 = z10;
                                                f18 = progress5;
                                                g10.f13745r.v(i20, f18, g10.f13736h, g10.f13735g, g10.f13741n);
                                                fArr[z12 ? 1 : 0] = (float) Math.toDegrees(fArr[z12 ? 1 : 0]);
                                                r19 = z12;
                                            } else {
                                                f18 = progress5;
                                                boolean z13 = z10;
                                                fArr[z13 ? 1 : 0] = 360.0f;
                                                r19 = z13;
                                            }
                                            fMax2 = Math.max(Math.min(((g10.f13749v * fAtan2) / fArr[r19]) + f18, 1.0f), 0.0f);
                                            progress6 = motionLayout.getProgress();
                                            if (fMax2 != progress6) {
                                                if (progress6 != 0.0f) {
                                                    if (progress6 == 0.0f) {
                                                        z11 = true;
                                                    } else {
                                                        z11 = false;
                                                    }
                                                    motionLayout.r(z11);
                                                } else {
                                                    if (progress6 == 0.0f) {
                                                        z11 = true;
                                                    } else {
                                                        z11 = false;
                                                    }
                                                    motionLayout.r(z11);
                                                }
                                                motionLayout.setProgress(fMax2);
                                                velocityTracker13 = wVar3.f13950a;
                                                if (velocityTracker13 != null) {
                                                    velocityTracker13.computeCurrentVelocity(1000);
                                                }
                                                velocityTracker14 = wVar3.f13950a;
                                                if (velocityTracker14 != null) {
                                                    xVelocity4 = velocityTracker14.getXVelocity();
                                                } else {
                                                    xVelocity4 = 0.0f;
                                                }
                                                velocityTracker15 = wVar3.f13950a;
                                                if (velocityTracker15 != null) {
                                                    yVelocity4 = velocityTracker15.getYVelocity();
                                                } else {
                                                    yVelocity4 = 0.0f;
                                                }
                                                double d12 = yVelocity4;
                                                double d13 = xVelocity4;
                                                motionLayout.f15950D = (float) Math.toDegrees((float) ((Math.sin(Math.atan2(d12, d13) - dAtan2) * Math.hypot(d12, d13)) / Math.hypot(rawX2, rawY2)));
                                            } else {
                                                motionLayout.f15950D = 0.0f;
                                            }
                                            g10.f13743p = motionEvent.getRawX();
                                            g10.f13744q = motionEvent.getRawY();
                                        } else {
                                            progress5 = motionLayout.getProgress();
                                            if (g10.f13740m) {
                                                z10 = true;
                                                g10.f13740m = true;
                                                motionLayout.setProgress(progress5);
                                            } else {
                                                z10 = true;
                                            }
                                            i20 = g10.f13732d;
                                            if (i20 != -1) {
                                                boolean z14 = z10;
                                                f18 = progress5;
                                                g10.f13745r.v(i20, f18, g10.f13736h, g10.f13735g, g10.f13741n);
                                                fArr[z14 ? 1 : 0] = (float) Math.toDegrees(fArr[z14 ? 1 : 0]);
                                                r19 = z14;
                                            } else {
                                                f18 = progress5;
                                                boolean z15 = z10;
                                                fArr[z15 ? 1 : 0] = 360.0f;
                                                r19 = z15;
                                            }
                                            fMax2 = Math.max(Math.min(((g10.f13749v * fAtan2) / fArr[r19]) + f18, 1.0f), 0.0f);
                                            progress6 = motionLayout.getProgress();
                                            if (fMax2 != progress6) {
                                                if (progress6 != 0.0f) {
                                                    if (progress6 == 0.0f) {
                                                        z11 = true;
                                                    } else {
                                                        z11 = false;
                                                    }
                                                    motionLayout.r(z11);
                                                } else {
                                                    if (progress6 == 0.0f) {
                                                        z11 = true;
                                                    } else {
                                                        z11 = false;
                                                    }
                                                    motionLayout.r(z11);
                                                }
                                                motionLayout.setProgress(fMax2);
                                                velocityTracker13 = wVar3.f13950a;
                                                if (velocityTracker13 != null) {
                                                    velocityTracker13.computeCurrentVelocity(1000);
                                                }
                                                velocityTracker14 = wVar3.f13950a;
                                                if (velocityTracker14 != null) {
                                                    xVelocity4 = velocityTracker14.getXVelocity();
                                                } else {
                                                    xVelocity4 = 0.0f;
                                                }
                                                velocityTracker15 = wVar3.f13950a;
                                                if (velocityTracker15 != null) {
                                                    yVelocity4 = velocityTracker15.getYVelocity();
                                                } else {
                                                    yVelocity4 = 0.0f;
                                                }
                                                double d14 = yVelocity4;
                                                double d15 = xVelocity4;
                                                motionLayout.f15950D = (float) Math.toDegrees((float) ((Math.sin(Math.atan2(d14, d15) - dAtan2) * Math.hypot(d14, d15)) / Math.hypot(rawX2, rawY2)));
                                            } else {
                                                motionLayout.f15950D = 0.0f;
                                            }
                                            g10.f13743p = motionEvent.getRawX();
                                            g10.f13744q = motionEvent.getRawY();
                                        }
                                    }
                                } else {
                                    g10.f13743p = motionEvent.getRawX();
                                    g10.f13744q = motionEvent.getRawY();
                                    g10.f13740m = false;
                                }
                            } else {
                                velocityTracker2 = wVar3.f13950a;
                                if (velocityTracker2 != null) {
                                    velocityTracker2.addMovement(motionEvent);
                                }
                                action = motionEvent.getAction();
                                if (action == 0) {
                                    g10.f13743p = motionEvent.getRawX();
                                    g10.f13744q = motionEvent.getRawY();
                                    g10.f13740m = false;
                                } else if (action == 1) {
                                    g10.f13740m = false;
                                    velocityTracker3 = wVar3.f13950a;
                                    if (velocityTracker3 != null) {
                                        velocityTracker3.computeCurrentVelocity(1000);
                                    }
                                    velocityTracker4 = wVar3.f13950a;
                                    if (velocityTracker4 != null) {
                                        xVelocity = velocityTracker4.getXVelocity();
                                    } else {
                                        xVelocity = 0.0f;
                                    }
                                    velocityTracker5 = wVar3.f13950a;
                                    if (velocityTracker5 != null) {
                                        yVelocity = velocityTracker5.getYVelocity();
                                    } else {
                                        yVelocity = 0.0f;
                                    }
                                    progress = motionLayout.getProgress();
                                    i11 = g10.f13732d;
                                    if (i11 != -1) {
                                        g10.f13745r.v(i11, progress, g10.f13736h, g10.f13735g, g10.f13741n);
                                        c11 = 1;
                                        c12 = 0;
                                    } else {
                                        float fMin = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                        c11 = 1;
                                        fArr[1] = g10.f13739l * fMin;
                                        c12 = 0;
                                        fArr[0] = fMin * g10.k;
                                    }
                                    f10 = g10.k;
                                    f11 = fArr[c12];
                                    f12 = fArr[c11];
                                    if (f10 != 0.0f) {
                                        fAbs = xVelocity / f11;
                                    } else {
                                        fAbs = yVelocity / f12;
                                    }
                                    if (Float.isNaN(fAbs)) {
                                        f13 = progress;
                                    } else {
                                        f13 = (fAbs / 3.0f) + progress;
                                    }
                                    if (f13 == 0.0f) {
                                        if (0.0f < f13) {
                                            motionLayout.setState(zVar);
                                        } else {
                                            motionLayout.setState(zVar);
                                        }
                                    } else if (0.0f < f13) {
                                        motionLayout.setState(zVar);
                                    } else {
                                        motionLayout.setState(zVar);
                                    }
                                } else if (action == 2) {
                                    rawY = motionEvent.getRawY() - g10.f13744q;
                                    rawX = motionEvent.getRawX() - g10.f13743p;
                                    if (Math.abs((g10.f13739l * rawY) + (g10.k * rawX)) <= g10.f13751x) {
                                        progress2 = motionLayout.getProgress();
                                        if (!g10.f13740m) {
                                            g10.f13740m = true;
                                            motionLayout.setProgress(progress2);
                                        }
                                        i13 = g10.f13732d;
                                        if (i13 != -1) {
                                            g10.f13745r.v(i13, progress2, g10.f13736h, g10.f13735g, g10.f13741n);
                                            c13 = 1;
                                            c14 = 0;
                                        } else {
                                            float fMin2 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                            c13 = 1;
                                            fArr[1] = g10.f13739l * fMin2;
                                            c14 = 0;
                                            fArr[0] = fMin2 * g10.k;
                                        }
                                        if (Math.abs(((g10.f13739l * fArr[c13]) + (g10.k * fArr[c14])) * g10.f13749v) < 0.01d) {
                                            fArr[0] = 0.01f;
                                            fArr[c13] = 0.01f;
                                        }
                                        if (g10.k != 0.0f) {
                                            f14 = rawX / fArr[0];
                                        } else {
                                            f14 = rawY / fArr[c13];
                                        }
                                        fMax = Math.max(Math.min(progress2 + f14, 1.0f), 0.0f);
                                        if (g10.f13731c == 6) {
                                            fMax = Math.max(fMax, 0.01f);
                                        }
                                        if (g10.f13731c == 7) {
                                            fMax = Math.min(fMax, 0.99f);
                                        }
                                        progress3 = motionLayout.getProgress();
                                        if (fMax != progress3) {
                                            if (progress3 != 0.0f) {
                                                if (progress3 == 0.0f) {
                                                    z5 = true;
                                                } else {
                                                    z5 = false;
                                                }
                                                motionLayout.r(z5);
                                            } else {
                                                if (progress3 == 0.0f) {
                                                    z5 = true;
                                                } else {
                                                    z5 = false;
                                                }
                                                motionLayout.r(z5);
                                            }
                                            motionLayout.setProgress(fMax);
                                            velocityTracker6 = wVar3.f13950a;
                                            if (velocityTracker6 != null) {
                                                velocityTracker6.computeCurrentVelocity(1000);
                                            }
                                            velocityTracker7 = wVar3.f13950a;
                                            if (velocityTracker7 != null) {
                                                xVelocity2 = velocityTracker7.getXVelocity();
                                            } else {
                                                xVelocity2 = 0.0f;
                                            }
                                            velocityTracker8 = wVar3.f13950a;
                                            if (velocityTracker8 != null) {
                                                yVelocity2 = velocityTracker8.getYVelocity();
                                            } else {
                                                yVelocity2 = 0.0f;
                                            }
                                            if (g10.k != 0.0f) {
                                                f15 = xVelocity2 / fArr[0];
                                            } else {
                                                f15 = yVelocity2 / fArr[1];
                                            }
                                            motionLayout.f15950D = f15;
                                        } else {
                                            motionLayout.f15950D = 0.0f;
                                        }
                                        g10.f13743p = motionEvent.getRawX();
                                        g10.f13744q = motionEvent.getRawY();
                                    } else {
                                        progress2 = motionLayout.getProgress();
                                        if (!g10.f13740m) {
                                            g10.f13740m = true;
                                            motionLayout.setProgress(progress2);
                                        }
                                        i13 = g10.f13732d;
                                        if (i13 != -1) {
                                            g10.f13745r.v(i13, progress2, g10.f13736h, g10.f13735g, g10.f13741n);
                                            c13 = 1;
                                            c14 = 0;
                                        } else {
                                            float fMin3 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                            c13 = 1;
                                            fArr[1] = g10.f13739l * fMin3;
                                            c14 = 0;
                                            fArr[0] = fMin3 * g10.k;
                                        }
                                        if (Math.abs(((g10.f13739l * fArr[c13]) + (g10.k * fArr[c14])) * g10.f13749v) < 0.01d) {
                                            fArr[0] = 0.01f;
                                            fArr[c13] = 0.01f;
                                        }
                                        if (g10.k != 0.0f) {
                                            f14 = rawX / fArr[0];
                                        } else {
                                            f14 = rawY / fArr[c13];
                                        }
                                        fMax = Math.max(Math.min(progress2 + f14, 1.0f), 0.0f);
                                        if (g10.f13731c == 6) {
                                            fMax = Math.max(fMax, 0.01f);
                                        }
                                        if (g10.f13731c == 7) {
                                            fMax = Math.min(fMax, 0.99f);
                                        }
                                        progress3 = motionLayout.getProgress();
                                        if (fMax != progress3) {
                                            if (progress3 != 0.0f) {
                                                if (progress3 == 0.0f) {
                                                    z5 = true;
                                                } else {
                                                    z5 = false;
                                                }
                                                motionLayout.r(z5);
                                            } else {
                                                if (progress3 == 0.0f) {
                                                    z5 = true;
                                                } else {
                                                    z5 = false;
                                                }
                                                motionLayout.r(z5);
                                            }
                                            motionLayout.setProgress(fMax);
                                            velocityTracker6 = wVar3.f13950a;
                                            if (velocityTracker6 != null) {
                                                velocityTracker6.computeCurrentVelocity(1000);
                                            }
                                            velocityTracker7 = wVar3.f13950a;
                                            if (velocityTracker7 != null) {
                                                xVelocity2 = velocityTracker7.getXVelocity();
                                            } else {
                                                xVelocity2 = 0.0f;
                                            }
                                            velocityTracker8 = wVar3.f13950a;
                                            if (velocityTracker8 != null) {
                                                yVelocity2 = velocityTracker8.getYVelocity();
                                            } else {
                                                yVelocity2 = 0.0f;
                                            }
                                            if (g10.k != 0.0f) {
                                                f15 = xVelocity2 / fArr[0];
                                            } else {
                                                f15 = yVelocity2 / fArr[1];
                                            }
                                            motionLayout.f15950D = f15;
                                        } else {
                                            motionLayout.f15950D = 0.0f;
                                        }
                                        g10.f13743p = motionEvent.getRawX();
                                        g10.f13744q = motionEvent.getRawY();
                                    }
                                }
                            }
                        }
                        d11.f13719r = motionEvent.getRawX();
                        d11.f13720s = motionEvent.getRawY();
                        if (motionEvent.getAction() == 1) {
                            velocityTracker = wVar.f13950a;
                            if (velocityTracker != null) {
                                velocityTracker.recycle();
                                wVar2 = null;
                                wVar.f13950a = null;
                            } else {
                                wVar2 = null;
                            }
                            d11.f13716o = wVar2;
                            i10 = this.f15954F;
                            if (i10 != -1) {
                                d11.a(i10, this);
                            }
                        }
                    }
                }
            } else if (!d11.f13714m) {
                c10 = d11.f13705c;
                if (c10 != null) {
                    wVar3 = d11.f13716o;
                    z3 = g10.f13738j;
                    zVar = z.f13959d;
                    fArr = g10.f13741n;
                    motionLayout = g10.f13745r;
                    if (z3) {
                        velocityTracker9 = wVar3.f13950a;
                        if (velocityTracker9 != null) {
                            velocityTracker9.addMovement(motionEvent);
                        }
                        action2 = motionEvent.getAction();
                        if (action2 != 0) {
                            iArr = g10.f13742o;
                            if (action2 == 1) {
                                g10.f13740m = false;
                                velocityTracker10 = wVar3.f13950a;
                                if (velocityTracker10 != null) {
                                    velocityTracker10.computeCurrentVelocity(16);
                                }
                                velocityTracker11 = wVar3.f13950a;
                                if (velocityTracker11 != null) {
                                    xVelocity3 = velocityTracker11.getXVelocity();
                                } else {
                                    xVelocity3 = 0.0f;
                                }
                                velocityTracker12 = wVar3.f13950a;
                                if (velocityTracker12 != null) {
                                    yVelocity3 = velocityTracker12.getYVelocity();
                                } else {
                                    yVelocity3 = 0.0f;
                                }
                                progress4 = motionLayout.getProgress();
                                float width3 = motionLayout.getWidth() / 2.0f;
                                float height3 = motionLayout.getHeight() / 2.0f;
                                i14 = g10.f13737i;
                                if (i14 != -1) {
                                    View viewFindViewById5 = motionLayout.findViewById(i14);
                                    motionLayout.getLocationOnScreen(iArr);
                                    right = iArr[0] + ((viewFindViewById5.getRight() + viewFindViewById5.getLeft()) / 2.0f);
                                    f16 = iArr[1];
                                    top = viewFindViewById5.getTop();
                                    bottom = viewFindViewById5.getBottom();
                                } else {
                                    i15 = g10.f13732d;
                                    if (i15 != -1) {
                                        View viewFindViewById6 = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i15))).f13903f.f13677u);
                                        motionLayout.getLocationOnScreen(iArr);
                                        right = iArr[0] + ((viewFindViewById6.getRight() + viewFindViewById6.getLeft()) / 2.0f);
                                        f16 = iArr[1];
                                        top = viewFindViewById6.getTop();
                                        bottom = viewFindViewById6.getBottom();
                                    } else {
                                        float rawX6 = motionEvent.getRawX() - width3;
                                        float rawY6 = motionEvent.getRawY() - height3;
                                        double degrees4 = Math.toDegrees(Math.atan2(rawY6, rawX6));
                                        i16 = g10.f13732d;
                                        if (i16 != -1) {
                                            g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                            fArr[1] = (float) Math.toDegrees(fArr[1]);
                                        } else {
                                            fArr[1] = 360.0f;
                                        }
                                        degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY6, xVelocity3 + rawX6)) - degrees4)) * 62.5f;
                                        if (Float.isNaN(degrees)) {
                                            f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                                        } else {
                                            f17 = progress4;
                                        }
                                        if (f17 == 0.0f) {
                                            if (0.0f < f17) {
                                                motionLayout.setState(zVar);
                                            } else {
                                                motionLayout.setState(zVar);
                                            }
                                        } else if (0.0f < f17) {
                                            motionLayout.setState(zVar);
                                        } else {
                                            motionLayout.setState(zVar);
                                        }
                                    }
                                }
                                float f28 = right;
                                height3 = ((bottom + top) / 2.0f) + f16;
                                width3 = f28;
                                float rawX7 = motionEvent.getRawX() - width3;
                                float rawY7 = motionEvent.getRawY() - height3;
                                double degrees5 = Math.toDegrees(Math.atan2(rawY7, rawX7));
                                i16 = g10.f13732d;
                                if (i16 != -1) {
                                    g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                    fArr[1] = (float) Math.toDegrees(fArr[1]);
                                } else {
                                    fArr[1] = 360.0f;
                                }
                                degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY7, xVelocity3 + rawX7)) - degrees5)) * 62.5f;
                                if (Float.isNaN(degrees)) {
                                    f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                                } else {
                                    f17 = progress4;
                                }
                                if (f17 == 0.0f) {
                                    if (0.0f < f17) {
                                        motionLayout.setState(zVar);
                                    } else {
                                        motionLayout.setState(zVar);
                                    }
                                } else if (0.0f < f17) {
                                    motionLayout.setState(zVar);
                                } else {
                                    motionLayout.setState(zVar);
                                }
                            } else if (action2 == 2) {
                                motionEvent.getRawY();
                                motionEvent.getRawX();
                                width = motionLayout.getWidth() / 2.0f;
                                height = motionLayout.getHeight() / 2.0f;
                                i18 = g10.f13737i;
                                if (i18 != -1) {
                                    View viewFindViewById7 = motionLayout.findViewById(i18);
                                    motionLayout.getLocationOnScreen(iArr);
                                    float right3 = iArr[0] + ((viewFindViewById7.getRight() + viewFindViewById7.getLeft()) / 2.0f);
                                    height = ((viewFindViewById7.getBottom() + viewFindViewById7.getTop()) / 2.0f) + iArr[1];
                                    width = right3;
                                } else {
                                    i19 = g10.f13732d;
                                    if (i19 != -1) {
                                        viewFindViewById = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i19))).f13903f.f13677u);
                                        if (viewFindViewById == null) {
                                            Log.e("TouchResponse", "could not find view to animate to");
                                        } else {
                                            motionLayout.getLocationOnScreen(iArr);
                                            width = iArr[0] + ((viewFindViewById.getRight() + viewFindViewById.getLeft()) / 2.0f);
                                            height = iArr[1] + ((viewFindViewById.getBottom() + viewFindViewById.getTop()) / 2.0f);
                                        }
                                    }
                                }
                                rawX2 = motionEvent.getRawX() - width;
                                rawY2 = motionEvent.getRawY() - height;
                                dAtan2 = Math.atan2(motionEvent.getRawY() - height, motionEvent.getRawX() - width);
                                fAtan2 = (float) (((dAtan2 - Math.atan2(g10.f13744q - height, g10.f13743p - width)) * 180.0d) / 3.141592653589793d);
                                if (fAtan2 > 330.0f) {
                                    fAtan2 -= 360.0f;
                                } else if (fAtan2 < -330.0f) {
                                    fAtan2 += 360.0f;
                                }
                                if (Math.abs(fAtan2) <= 0.01d) {
                                    progress5 = motionLayout.getProgress();
                                    if (g10.f13740m) {
                                        z10 = true;
                                        g10.f13740m = true;
                                        motionLayout.setProgress(progress5);
                                    } else {
                                        z10 = true;
                                    }
                                    i20 = g10.f13732d;
                                    if (i20 != -1) {
                                        boolean z16 = z10;
                                        f18 = progress5;
                                        g10.f13745r.v(i20, f18, g10.f13736h, g10.f13735g, g10.f13741n);
                                        fArr[z16 ? 1 : 0] = (float) Math.toDegrees(fArr[z16 ? 1 : 0]);
                                        r19 = z16;
                                    } else {
                                        f18 = progress5;
                                        boolean z17 = z10;
                                        fArr[z17 ? 1 : 0] = 360.0f;
                                        r19 = z17;
                                    }
                                    fMax2 = Math.max(Math.min(((g10.f13749v * fAtan2) / fArr[r19]) + f18, 1.0f), 0.0f);
                                    progress6 = motionLayout.getProgress();
                                    if (fMax2 != progress6) {
                                        if (progress6 != 0.0f) {
                                            if (progress6 == 0.0f) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            motionLayout.r(z11);
                                        } else {
                                            if (progress6 == 0.0f) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            motionLayout.r(z11);
                                        }
                                        motionLayout.setProgress(fMax2);
                                        velocityTracker13 = wVar3.f13950a;
                                        if (velocityTracker13 != null) {
                                            velocityTracker13.computeCurrentVelocity(1000);
                                        }
                                        velocityTracker14 = wVar3.f13950a;
                                        if (velocityTracker14 != null) {
                                            xVelocity4 = velocityTracker14.getXVelocity();
                                        } else {
                                            xVelocity4 = 0.0f;
                                        }
                                        velocityTracker15 = wVar3.f13950a;
                                        if (velocityTracker15 != null) {
                                            yVelocity4 = velocityTracker15.getYVelocity();
                                        } else {
                                            yVelocity4 = 0.0f;
                                        }
                                        double d16 = yVelocity4;
                                        double d17 = xVelocity4;
                                        motionLayout.f15950D = (float) Math.toDegrees((float) ((Math.sin(Math.atan2(d16, d17) - dAtan2) * Math.hypot(d16, d17)) / Math.hypot(rawX2, rawY2)));
                                    } else {
                                        motionLayout.f15950D = 0.0f;
                                    }
                                    g10.f13743p = motionEvent.getRawX();
                                    g10.f13744q = motionEvent.getRawY();
                                } else {
                                    progress5 = motionLayout.getProgress();
                                    if (g10.f13740m) {
                                        z10 = true;
                                        g10.f13740m = true;
                                        motionLayout.setProgress(progress5);
                                    } else {
                                        z10 = true;
                                    }
                                    i20 = g10.f13732d;
                                    if (i20 != -1) {
                                        boolean z18 = z10;
                                        f18 = progress5;
                                        g10.f13745r.v(i20, f18, g10.f13736h, g10.f13735g, g10.f13741n);
                                        fArr[z18 ? 1 : 0] = (float) Math.toDegrees(fArr[z18 ? 1 : 0]);
                                        r19 = z18;
                                    } else {
                                        f18 = progress5;
                                        boolean z19 = z10;
                                        fArr[z19 ? 1 : 0] = 360.0f;
                                        r19 = z19;
                                    }
                                    fMax2 = Math.max(Math.min(((g10.f13749v * fAtan2) / fArr[r19]) + f18, 1.0f), 0.0f);
                                    progress6 = motionLayout.getProgress();
                                    if (fMax2 != progress6) {
                                        if (progress6 != 0.0f) {
                                            if (progress6 == 0.0f) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            motionLayout.r(z11);
                                        } else {
                                            if (progress6 == 0.0f) {
                                                z11 = true;
                                            } else {
                                                z11 = false;
                                            }
                                            motionLayout.r(z11);
                                        }
                                        motionLayout.setProgress(fMax2);
                                        velocityTracker13 = wVar3.f13950a;
                                        if (velocityTracker13 != null) {
                                            velocityTracker13.computeCurrentVelocity(1000);
                                        }
                                        velocityTracker14 = wVar3.f13950a;
                                        if (velocityTracker14 != null) {
                                            xVelocity4 = velocityTracker14.getXVelocity();
                                        } else {
                                            xVelocity4 = 0.0f;
                                        }
                                        velocityTracker15 = wVar3.f13950a;
                                        if (velocityTracker15 != null) {
                                            yVelocity4 = velocityTracker15.getYVelocity();
                                        } else {
                                            yVelocity4 = 0.0f;
                                        }
                                        double d18 = yVelocity4;
                                        double d19 = xVelocity4;
                                        motionLayout.f15950D = (float) Math.toDegrees((float) ((Math.sin(Math.atan2(d18, d19) - dAtan2) * Math.hypot(d18, d19)) / Math.hypot(rawX2, rawY2)));
                                    } else {
                                        motionLayout.f15950D = 0.0f;
                                    }
                                    g10.f13743p = motionEvent.getRawX();
                                    g10.f13744q = motionEvent.getRawY();
                                }
                            }
                        } else {
                            g10.f13743p = motionEvent.getRawX();
                            g10.f13744q = motionEvent.getRawY();
                            g10.f13740m = false;
                        }
                    } else {
                        velocityTracker2 = wVar3.f13950a;
                        if (velocityTracker2 != null) {
                            velocityTracker2.addMovement(motionEvent);
                        }
                        action = motionEvent.getAction();
                        if (action == 0) {
                            g10.f13743p = motionEvent.getRawX();
                            g10.f13744q = motionEvent.getRawY();
                            g10.f13740m = false;
                        } else if (action == 1) {
                            g10.f13740m = false;
                            velocityTracker3 = wVar3.f13950a;
                            if (velocityTracker3 != null) {
                                velocityTracker3.computeCurrentVelocity(1000);
                            }
                            velocityTracker4 = wVar3.f13950a;
                            if (velocityTracker4 != null) {
                                xVelocity = velocityTracker4.getXVelocity();
                            } else {
                                xVelocity = 0.0f;
                            }
                            velocityTracker5 = wVar3.f13950a;
                            if (velocityTracker5 != null) {
                                yVelocity = velocityTracker5.getYVelocity();
                            } else {
                                yVelocity = 0.0f;
                            }
                            progress = motionLayout.getProgress();
                            i11 = g10.f13732d;
                            if (i11 != -1) {
                                g10.f13745r.v(i11, progress, g10.f13736h, g10.f13735g, g10.f13741n);
                                c11 = 1;
                                c12 = 0;
                            } else {
                                float fMin4 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                c11 = 1;
                                fArr[1] = g10.f13739l * fMin4;
                                c12 = 0;
                                fArr[0] = fMin4 * g10.k;
                            }
                            f10 = g10.k;
                            f11 = fArr[c12];
                            f12 = fArr[c11];
                            if (f10 != 0.0f) {
                                fAbs = xVelocity / f11;
                            } else {
                                fAbs = yVelocity / f12;
                            }
                            if (Float.isNaN(fAbs)) {
                                f13 = (fAbs / 3.0f) + progress;
                            } else {
                                f13 = progress;
                            }
                            if (f13 == 0.0f) {
                                if (0.0f < f13) {
                                    motionLayout.setState(zVar);
                                } else {
                                    motionLayout.setState(zVar);
                                }
                            } else if (0.0f < f13) {
                                motionLayout.setState(zVar);
                            } else {
                                motionLayout.setState(zVar);
                            }
                        } else if (action == 2) {
                            rawY = motionEvent.getRawY() - g10.f13744q;
                            rawX = motionEvent.getRawX() - g10.f13743p;
                            if (Math.abs((g10.f13739l * rawY) + (g10.k * rawX)) <= g10.f13751x) {
                                progress2 = motionLayout.getProgress();
                                if (!g10.f13740m) {
                                    g10.f13740m = true;
                                    motionLayout.setProgress(progress2);
                                }
                                i13 = g10.f13732d;
                                if (i13 != -1) {
                                    g10.f13745r.v(i13, progress2, g10.f13736h, g10.f13735g, g10.f13741n);
                                    c13 = 1;
                                    c14 = 0;
                                } else {
                                    float fMin5 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                    c13 = 1;
                                    fArr[1] = g10.f13739l * fMin5;
                                    c14 = 0;
                                    fArr[0] = fMin5 * g10.k;
                                }
                                if (Math.abs(((g10.f13739l * fArr[c13]) + (g10.k * fArr[c14])) * g10.f13749v) < 0.01d) {
                                    fArr[0] = 0.01f;
                                    fArr[c13] = 0.01f;
                                }
                                if (g10.k != 0.0f) {
                                    f14 = rawX / fArr[0];
                                } else {
                                    f14 = rawY / fArr[c13];
                                }
                                fMax = Math.max(Math.min(progress2 + f14, 1.0f), 0.0f);
                                if (g10.f13731c == 6) {
                                    fMax = Math.max(fMax, 0.01f);
                                }
                                if (g10.f13731c == 7) {
                                    fMax = Math.min(fMax, 0.99f);
                                }
                                progress3 = motionLayout.getProgress();
                                if (fMax != progress3) {
                                    if (progress3 != 0.0f) {
                                        if (progress3 == 0.0f) {
                                            z5 = true;
                                        } else {
                                            z5 = false;
                                        }
                                        motionLayout.r(z5);
                                    } else {
                                        if (progress3 == 0.0f) {
                                            z5 = true;
                                        } else {
                                            z5 = false;
                                        }
                                        motionLayout.r(z5);
                                    }
                                    motionLayout.setProgress(fMax);
                                    velocityTracker6 = wVar3.f13950a;
                                    if (velocityTracker6 != null) {
                                        velocityTracker6.computeCurrentVelocity(1000);
                                    }
                                    velocityTracker7 = wVar3.f13950a;
                                    if (velocityTracker7 != null) {
                                        xVelocity2 = velocityTracker7.getXVelocity();
                                    } else {
                                        xVelocity2 = 0.0f;
                                    }
                                    velocityTracker8 = wVar3.f13950a;
                                    if (velocityTracker8 != null) {
                                        yVelocity2 = velocityTracker8.getYVelocity();
                                    } else {
                                        yVelocity2 = 0.0f;
                                    }
                                    if (g10.k != 0.0f) {
                                        f15 = xVelocity2 / fArr[0];
                                    } else {
                                        f15 = yVelocity2 / fArr[1];
                                    }
                                    motionLayout.f15950D = f15;
                                } else {
                                    motionLayout.f15950D = 0.0f;
                                }
                                g10.f13743p = motionEvent.getRawX();
                                g10.f13744q = motionEvent.getRawY();
                            } else {
                                progress2 = motionLayout.getProgress();
                                if (!g10.f13740m) {
                                    g10.f13740m = true;
                                    motionLayout.setProgress(progress2);
                                }
                                i13 = g10.f13732d;
                                if (i13 != -1) {
                                    g10.f13745r.v(i13, progress2, g10.f13736h, g10.f13735g, g10.f13741n);
                                    c13 = 1;
                                    c14 = 0;
                                } else {
                                    float fMin6 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                    c13 = 1;
                                    fArr[1] = g10.f13739l * fMin6;
                                    c14 = 0;
                                    fArr[0] = fMin6 * g10.k;
                                }
                                if (Math.abs(((g10.f13739l * fArr[c13]) + (g10.k * fArr[c14])) * g10.f13749v) < 0.01d) {
                                    fArr[0] = 0.01f;
                                    fArr[c13] = 0.01f;
                                }
                                if (g10.k != 0.0f) {
                                    f14 = rawX / fArr[0];
                                } else {
                                    f14 = rawY / fArr[c13];
                                }
                                fMax = Math.max(Math.min(progress2 + f14, 1.0f), 0.0f);
                                if (g10.f13731c == 6) {
                                    fMax = Math.max(fMax, 0.01f);
                                }
                                if (g10.f13731c == 7) {
                                    fMax = Math.min(fMax, 0.99f);
                                }
                                progress3 = motionLayout.getProgress();
                                if (fMax != progress3) {
                                    if (progress3 != 0.0f) {
                                        if (progress3 == 0.0f) {
                                            z5 = true;
                                        } else {
                                            z5 = false;
                                        }
                                        motionLayout.r(z5);
                                    } else {
                                        if (progress3 == 0.0f) {
                                            z5 = true;
                                        } else {
                                            z5 = false;
                                        }
                                        motionLayout.r(z5);
                                    }
                                    motionLayout.setProgress(fMax);
                                    velocityTracker6 = wVar3.f13950a;
                                    if (velocityTracker6 != null) {
                                        velocityTracker6.computeCurrentVelocity(1000);
                                    }
                                    velocityTracker7 = wVar3.f13950a;
                                    if (velocityTracker7 != null) {
                                        xVelocity2 = velocityTracker7.getXVelocity();
                                    } else {
                                        xVelocity2 = 0.0f;
                                    }
                                    velocityTracker8 = wVar3.f13950a;
                                    if (velocityTracker8 != null) {
                                        yVelocity2 = velocityTracker8.getYVelocity();
                                    } else {
                                        yVelocity2 = 0.0f;
                                    }
                                    if (g10.k != 0.0f) {
                                        f15 = xVelocity2 / fArr[0];
                                    } else {
                                        f15 = yVelocity2 / fArr[1];
                                    }
                                    motionLayout.f15950D = f15;
                                } else {
                                    motionLayout.f15950D = 0.0f;
                                }
                                g10.f13743p = motionEvent.getRawX();
                                g10.f13744q = motionEvent.getRawY();
                            }
                        }
                    }
                }
                d11.f13719r = motionEvent.getRawX();
                d11.f13720s = motionEvent.getRawY();
                if (motionEvent.getAction() == 1) {
                    velocityTracker = wVar.f13950a;
                    if (velocityTracker != null) {
                        velocityTracker.recycle();
                        wVar2 = null;
                        wVar.f13950a = null;
                    } else {
                        wVar2 = null;
                    }
                    d11.f13716o = wVar2;
                    i10 = this.f15954F;
                    if (i10 != -1) {
                        d11.a(i10, this);
                    }
                }
            }
        } else if (!d11.f13714m) {
            c10 = d11.f13705c;
            if (c10 != null && (g10 = c10.f13696l) != null && !d11.f13715n) {
                wVar3 = d11.f13716o;
                z3 = g10.f13738j;
                zVar = z.f13959d;
                fArr = g10.f13741n;
                motionLayout = g10.f13745r;
                if (z3) {
                    velocityTracker9 = wVar3.f13950a;
                    if (velocityTracker9 != null) {
                        velocityTracker9.addMovement(motionEvent);
                    }
                    action2 = motionEvent.getAction();
                    if (action2 != 0) {
                        iArr = g10.f13742o;
                        if (action2 == 1) {
                            g10.f13740m = false;
                            velocityTracker10 = wVar3.f13950a;
                            if (velocityTracker10 != null) {
                                velocityTracker10.computeCurrentVelocity(16);
                            }
                            velocityTracker11 = wVar3.f13950a;
                            if (velocityTracker11 != null) {
                                xVelocity3 = velocityTracker11.getXVelocity();
                            } else {
                                xVelocity3 = 0.0f;
                            }
                            velocityTracker12 = wVar3.f13950a;
                            if (velocityTracker12 != null) {
                                yVelocity3 = velocityTracker12.getYVelocity();
                            } else {
                                yVelocity3 = 0.0f;
                            }
                            progress4 = motionLayout.getProgress();
                            float width4 = motionLayout.getWidth() / 2.0f;
                            float height4 = motionLayout.getHeight() / 2.0f;
                            i14 = g10.f13737i;
                            if (i14 != -1) {
                                View viewFindViewById8 = motionLayout.findViewById(i14);
                                motionLayout.getLocationOnScreen(iArr);
                                right = iArr[0] + ((viewFindViewById8.getRight() + viewFindViewById8.getLeft()) / 2.0f);
                                f16 = iArr[1];
                                top = viewFindViewById8.getTop();
                                bottom = viewFindViewById8.getBottom();
                            } else {
                                i15 = g10.f13732d;
                                if (i15 != -1) {
                                    View viewFindViewById9 = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i15))).f13903f.f13677u);
                                    motionLayout.getLocationOnScreen(iArr);
                                    right = iArr[0] + ((viewFindViewById9.getRight() + viewFindViewById9.getLeft()) / 2.0f);
                                    f16 = iArr[1];
                                    top = viewFindViewById9.getTop();
                                    bottom = viewFindViewById9.getBottom();
                                } else {
                                    float rawX8 = motionEvent.getRawX() - width4;
                                    float rawY8 = motionEvent.getRawY() - height4;
                                    double degrees6 = Math.toDegrees(Math.atan2(rawY8, rawX8));
                                    i16 = g10.f13732d;
                                    if (i16 != -1) {
                                        g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                        fArr[1] = (float) Math.toDegrees(fArr[1]);
                                    } else {
                                        fArr[1] = 360.0f;
                                    }
                                    degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY8, xVelocity3 + rawX8)) - degrees6)) * 62.5f;
                                    if (Float.isNaN(degrees)) {
                                        f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                                    } else {
                                        f17 = progress4;
                                    }
                                    if (f17 == 0.0f && f17 != 1.0f && (i17 = g10.f13731c) != 3) {
                                        float fAbs2 = (degrees * g10.f13749v) / fArr[1];
                                        float f29 = ((double) f17) < 0.5d ? 0.0f : 1.0f;
                                        if (i17 == 6) {
                                            if (progress4 + fAbs2 < 0.0f) {
                                                fAbs2 = Math.abs(fAbs2);
                                            }
                                            f29 = 1.0f;
                                        }
                                        if (g10.f13731c == 7) {
                                            if (progress4 + fAbs2 > 1.0f) {
                                                fAbs2 = -Math.abs(fAbs2);
                                            }
                                            f29 = 0.0f;
                                        }
                                        motionLayout.D(f29, fAbs2 * 3.0f, g10.f13731c);
                                        if (0.0f >= progress4 || 1.0f <= progress4) {
                                            motionLayout.setState(zVar);
                                        }
                                    } else if (0.0f < f17 || 1.0f <= f17) {
                                        motionLayout.setState(zVar);
                                    }
                                }
                            }
                            float f210 = right;
                            height4 = ((bottom + top) / 2.0f) + f16;
                            width4 = f210;
                            float rawX9 = motionEvent.getRawX() - width4;
                            float rawY9 = motionEvent.getRawY() - height4;
                            double degrees7 = Math.toDegrees(Math.atan2(rawY9, rawX9));
                            i16 = g10.f13732d;
                            if (i16 != -1) {
                                g10.f13745r.v(i16, progress4, g10.f13736h, g10.f13735g, g10.f13741n);
                                fArr[1] = (float) Math.toDegrees(fArr[1]);
                            } else {
                                fArr[1] = 360.0f;
                            }
                            degrees = ((float) (Math.toDegrees(Math.atan2(yVelocity3 + rawY9, xVelocity3 + rawX9)) - degrees7)) * 62.5f;
                            if (Float.isNaN(degrees)) {
                                f17 = (((degrees * 3.0f) * g10.f13749v) / fArr[1]) + progress4;
                            } else {
                                f17 = progress4;
                            }
                            if (f17 == 0.0f) {
                                if (0.0f < f17) {
                                    motionLayout.setState(zVar);
                                } else {
                                    motionLayout.setState(zVar);
                                }
                            } else if (0.0f < f17) {
                                motionLayout.setState(zVar);
                            } else {
                                motionLayout.setState(zVar);
                            }
                        } else if (action2 == 2) {
                            motionEvent.getRawY();
                            motionEvent.getRawX();
                            width = motionLayout.getWidth() / 2.0f;
                            height = motionLayout.getHeight() / 2.0f;
                            i18 = g10.f13737i;
                            if (i18 != -1) {
                                View viewFindViewById10 = motionLayout.findViewById(i18);
                                motionLayout.getLocationOnScreen(iArr);
                                float right4 = iArr[0] + ((viewFindViewById10.getRight() + viewFindViewById10.getLeft()) / 2.0f);
                                height = ((viewFindViewById10.getBottom() + viewFindViewById10.getTop()) / 2.0f) + iArr[1];
                                width = right4;
                            } else {
                                i19 = g10.f13732d;
                                if (i19 != -1) {
                                    viewFindViewById = motionLayout.findViewById(((q) motionLayout.f15964K.get(motionLayout.findViewById(i19))).f13903f.f13677u);
                                    if (viewFindViewById == null) {
                                        Log.e("TouchResponse", "could not find view to animate to");
                                    } else {
                                        motionLayout.getLocationOnScreen(iArr);
                                        width = iArr[0] + ((viewFindViewById.getRight() + viewFindViewById.getLeft()) / 2.0f);
                                        height = iArr[1] + ((viewFindViewById.getBottom() + viewFindViewById.getTop()) / 2.0f);
                                    }
                                }
                            }
                            rawX2 = motionEvent.getRawX() - width;
                            rawY2 = motionEvent.getRawY() - height;
                            dAtan2 = Math.atan2(motionEvent.getRawY() - height, motionEvent.getRawX() - width);
                            fAtan2 = (float) (((dAtan2 - Math.atan2(g10.f13744q - height, g10.f13743p - width)) * 180.0d) / 3.141592653589793d);
                            if (fAtan2 > 330.0f) {
                                fAtan2 -= 360.0f;
                            } else if (fAtan2 < -330.0f) {
                                fAtan2 += 360.0f;
                            }
                            if (Math.abs(fAtan2) <= 0.01d || g10.f13740m) {
                                progress5 = motionLayout.getProgress();
                                if (g10.f13740m) {
                                    z10 = true;
                                    g10.f13740m = true;
                                    motionLayout.setProgress(progress5);
                                } else {
                                    z10 = true;
                                }
                                i20 = g10.f13732d;
                                if (i20 != -1) {
                                    boolean z110 = z10;
                                    f18 = progress5;
                                    g10.f13745r.v(i20, f18, g10.f13736h, g10.f13735g, g10.f13741n);
                                    fArr[z110 ? 1 : 0] = (float) Math.toDegrees(fArr[z110 ? 1 : 0]);
                                    r19 = z110;
                                } else {
                                    f18 = progress5;
                                    boolean z111 = z10;
                                    fArr[z111 ? 1 : 0] = 360.0f;
                                    r19 = z111;
                                }
                                fMax2 = Math.max(Math.min(((g10.f13749v * fAtan2) / fArr[r19]) + f18, 1.0f), 0.0f);
                                progress6 = motionLayout.getProgress();
                                if (fMax2 != progress6) {
                                    if (progress6 != 0.0f || progress6 == 1.0f) {
                                        if (progress6 == 0.0f) {
                                            z11 = true;
                                        } else {
                                            z11 = false;
                                        }
                                        motionLayout.r(z11);
                                    }
                                    motionLayout.setProgress(fMax2);
                                    velocityTracker13 = wVar3.f13950a;
                                    if (velocityTracker13 != null) {
                                        velocityTracker13.computeCurrentVelocity(1000);
                                    }
                                    velocityTracker14 = wVar3.f13950a;
                                    if (velocityTracker14 != null) {
                                        xVelocity4 = velocityTracker14.getXVelocity();
                                    } else {
                                        xVelocity4 = 0.0f;
                                    }
                                    velocityTracker15 = wVar3.f13950a;
                                    if (velocityTracker15 != null) {
                                        yVelocity4 = velocityTracker15.getYVelocity();
                                    } else {
                                        yVelocity4 = 0.0f;
                                    }
                                    double d110 = yVelocity4;
                                    double d111 = xVelocity4;
                                    motionLayout.f15950D = (float) Math.toDegrees((float) ((Math.sin(Math.atan2(d110, d111) - dAtan2) * Math.hypot(d110, d111)) / Math.hypot(rawX2, rawY2)));
                                } else {
                                    motionLayout.f15950D = 0.0f;
                                }
                                g10.f13743p = motionEvent.getRawX();
                                g10.f13744q = motionEvent.getRawY();
                            }
                        }
                    } else {
                        g10.f13743p = motionEvent.getRawX();
                        g10.f13744q = motionEvent.getRawY();
                        g10.f13740m = false;
                    }
                } else {
                    velocityTracker2 = wVar3.f13950a;
                    if (velocityTracker2 != null) {
                        velocityTracker2.addMovement(motionEvent);
                    }
                    action = motionEvent.getAction();
                    if (action == 0) {
                        g10.f13743p = motionEvent.getRawX();
                        g10.f13744q = motionEvent.getRawY();
                        g10.f13740m = false;
                    } else if (action == 1) {
                        g10.f13740m = false;
                        velocityTracker3 = wVar3.f13950a;
                        if (velocityTracker3 != null) {
                            velocityTracker3.computeCurrentVelocity(1000);
                        }
                        velocityTracker4 = wVar3.f13950a;
                        if (velocityTracker4 != null) {
                            xVelocity = velocityTracker4.getXVelocity();
                        } else {
                            xVelocity = 0.0f;
                        }
                        velocityTracker5 = wVar3.f13950a;
                        if (velocityTracker5 != null) {
                            yVelocity = velocityTracker5.getYVelocity();
                        } else {
                            yVelocity = 0.0f;
                        }
                        progress = motionLayout.getProgress();
                        i11 = g10.f13732d;
                        if (i11 != -1) {
                            g10.f13745r.v(i11, progress, g10.f13736h, g10.f13735g, g10.f13741n);
                            c11 = 1;
                            c12 = 0;
                        } else {
                            float fMin7 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                            c11 = 1;
                            fArr[1] = g10.f13739l * fMin7;
                            c12 = 0;
                            fArr[0] = fMin7 * g10.k;
                        }
                        f10 = g10.k;
                        f11 = fArr[c12];
                        f12 = fArr[c11];
                        if (f10 != 0.0f) {
                            fAbs = xVelocity / f11;
                        } else {
                            fAbs = yVelocity / f12;
                        }
                        if (Float.isNaN(fAbs)) {
                            f13 = (fAbs / 3.0f) + progress;
                        } else {
                            f13 = progress;
                        }
                        if (f13 == 0.0f && f13 != 1.0f && (i12 = g10.f13731c) != 3) {
                            float f30 = ((double) f13) < 0.5d ? 0.0f : 1.0f;
                            if (i12 == 6) {
                                if (progress + fAbs < 0.0f) {
                                    fAbs = Math.abs(fAbs);
                                }
                                f30 = 1.0f;
                            }
                            if (g10.f13731c == 7) {
                                if (progress + fAbs > 1.0f) {
                                    fAbs = -Math.abs(fAbs);
                                }
                                f30 = 0.0f;
                            }
                            motionLayout.D(f30, fAbs, g10.f13731c);
                            if (0.0f >= progress || 1.0f <= progress) {
                                motionLayout.setState(zVar);
                            }
                        } else if (0.0f < f13 || 1.0f <= f13) {
                            motionLayout.setState(zVar);
                        }
                    } else if (action == 2) {
                        rawY = motionEvent.getRawY() - g10.f13744q;
                        rawX = motionEvent.getRawX() - g10.f13743p;
                        if (Math.abs((g10.f13739l * rawY) + (g10.k * rawX)) <= g10.f13751x || g10.f13740m) {
                            progress2 = motionLayout.getProgress();
                            if (!g10.f13740m) {
                                g10.f13740m = true;
                                motionLayout.setProgress(progress2);
                            }
                            i13 = g10.f13732d;
                            if (i13 != -1) {
                                g10.f13745r.v(i13, progress2, g10.f13736h, g10.f13735g, g10.f13741n);
                                c13 = 1;
                                c14 = 0;
                            } else {
                                float fMin8 = Math.min(motionLayout.getWidth(), motionLayout.getHeight());
                                c13 = 1;
                                fArr[1] = g10.f13739l * fMin8;
                                c14 = 0;
                                fArr[0] = fMin8 * g10.k;
                            }
                            if (Math.abs(((g10.f13739l * fArr[c13]) + (g10.k * fArr[c14])) * g10.f13749v) < 0.01d) {
                                fArr[0] = 0.01f;
                                fArr[c13] = 0.01f;
                            }
                            if (g10.k != 0.0f) {
                                f14 = rawX / fArr[0];
                            } else {
                                f14 = rawY / fArr[c13];
                            }
                            fMax = Math.max(Math.min(progress2 + f14, 1.0f), 0.0f);
                            if (g10.f13731c == 6) {
                                fMax = Math.max(fMax, 0.01f);
                            }
                            if (g10.f13731c == 7) {
                                fMax = Math.min(fMax, 0.99f);
                            }
                            progress3 = motionLayout.getProgress();
                            if (fMax != progress3) {
                                if (progress3 != 0.0f || progress3 == 1.0f) {
                                    if (progress3 == 0.0f) {
                                        z5 = true;
                                    } else {
                                        z5 = false;
                                    }
                                    motionLayout.r(z5);
                                }
                                motionLayout.setProgress(fMax);
                                velocityTracker6 = wVar3.f13950a;
                                if (velocityTracker6 != null) {
                                    velocityTracker6.computeCurrentVelocity(1000);
                                }
                                velocityTracker7 = wVar3.f13950a;
                                if (velocityTracker7 != null) {
                                    xVelocity2 = velocityTracker7.getXVelocity();
                                } else {
                                    xVelocity2 = 0.0f;
                                }
                                velocityTracker8 = wVar3.f13950a;
                                if (velocityTracker8 != null) {
                                    yVelocity2 = velocityTracker8.getYVelocity();
                                } else {
                                    yVelocity2 = 0.0f;
                                }
                                if (g10.k != 0.0f) {
                                    f15 = xVelocity2 / fArr[0];
                                } else {
                                    f15 = yVelocity2 / fArr[1];
                                }
                                motionLayout.f15950D = f15;
                            } else {
                                motionLayout.f15950D = 0.0f;
                            }
                            g10.f13743p = motionEvent.getRawX();
                            g10.f13744q = motionEvent.getRawY();
                        }
                    }
                }
            }
            d11.f13719r = motionEvent.getRawX();
            d11.f13720s = motionEvent.getRawY();
            if (motionEvent.getAction() == 1 && (wVar = d11.f13716o) != null) {
                velocityTracker = wVar.f13950a;
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    wVar2 = null;
                    wVar.f13950a = null;
                } else {
                    wVar2 = null;
                }
                d11.f13716o = wVar2;
                i10 = this.f15954F;
                if (i10 != -1) {
                    d11.a(i10, this);
                }
            }
        }
        C c19 = this.f15944A.f13705c;
        if ((c19.f13702r & 4) != 0) {
            return c19.f13696l.f13740m;
        }
        return true;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public final void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof MotionHelper) {
            MotionHelper motionHelper = (MotionHelper) view;
            if (this.f15994o0 == null) {
                this.f15994o0 = new CopyOnWriteArrayList();
            }
            this.f15994o0.add(motionHelper);
            if (motionHelper.f15939t) {
                if (this.f15991l0 == null) {
                    this.f15991l0 = new ArrayList();
                }
                this.f15991l0.add(motionHelper);
            }
            if (motionHelper.f15940u) {
                if (this.f15992m0 == null) {
                    this.f15992m0 = new ArrayList();
                }
                this.f15992m0.add(motionHelper);
            }
            if (motionHelper instanceof MotionEffect) {
                if (this.f15993n0 == null) {
                    this.f15993n0 = new ArrayList();
                }
                this.f15993n0.add(motionHelper);
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public final void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList arrayList = this.f15991l0;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList arrayList2 = this.f15992m0;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    public final void q(float f10) {
        D d10 = this.f15944A;
        if (d10 == null) {
            return;
        }
        float f11 = this.f15971O;
        float f12 = this.f15969N;
        if (f11 != f12 && this.f15974R) {
            this.f15971O = f12;
        }
        float f13 = this.f15971O;
        if (f13 == f10) {
            return;
        }
        this.f15979W = false;
        this.f15973Q = f10;
        this.M = d10.c() / 1000.0f;
        setProgress(this.f15973Q);
        this.f15946B = null;
        this.f15948C = this.f15944A.e();
        this.f15974R = false;
        this.f15966L = getNanoTime();
        this.f15975S = true;
        this.f15969N = f13;
        this.f15971O = f13;
        invalidate();
    }

    public final void r(boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            q qVar = (q) this.f15964K.get(getChildAt(i10));
            if (qVar != null && "button".equals(p123ja.a.K(qVar.f13899b)) && qVar.f13890A != null) {
                int i11 = 0;
                while (true) {
                    Y0.n[] nVarArr = qVar.f13890A;
                    if (i11 < nVarArr.length) {
                        nVarArr[i11].h(qVar.f13899b, z3 ? -100.0f : 100.0f);
                        i11++;
                    }
                }
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View, android.view.ViewParent
    public final void requestLayout() {
        D d10;
        C c10;
        if (!this.f16000u0 && this.f15954F == -1 && (d10 = this.f15944A) != null && (c10 = d10.f13705c) != null) {
            int i10 = c10.f13701q;
            if (i10 == 0) {
                return;
            }
            if (i10 == 2) {
                int childCount = getChildCount();
                for (int i11 = 0; i11 < childCount; i11++) {
                    ((q) this.f15964K.get(getChildAt(i11))).f13901d = true;
                }
                return;
            }
        }
        super.requestLayout();
    }

    /* JADX WARN: Code duplicated, block: B:101:0x0178  */
    /* JADX WARN: Code duplicated, block: B:102:0x018a  */
    /* JADX WARN: Code duplicated, block: B:122:0x01b9  */
    /* JADX WARN: Code duplicated, block: B:132:0x01e4  */
    /* JADX WARN: Code duplicated, block: B:134:0x01ea  */
    /* JADX WARN: Code duplicated, block: B:148:0x0214  */
    /* JADX WARN: Code duplicated, block: B:64:0x00e0 A[PHI: r3
  0x00e0: PHI (r3v13 float) = (r3v12 float), (r3v14 float), (r3v14 float) binds: [B:49:0x00ae, B:60:0x00d4, B:62:0x00d8] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:74:0x010b  */
    /* JADX WARN: Code duplicated, block: B:77:0x0114  */
    /* JADX WARN: Code duplicated, block: B:89:0x0132  */
    /* JADX WARN: Code duplicated, block: B:92:0x0147  */
    /* JADX WARN: Code duplicated, block: B:93:0x0149  */
    /* JADX WARN: Code duplicated, block: B:96:0x0152  */
    /* JADX WARN: Code duplicated, block: B:99:0x0169  */
    public final void s(boolean z3) {
        boolean z5;
        char c10;
        z zVar;
        int childCount;
        long nanoTime;
        Interpolator interpolator;
        float interpolation;
        Interpolator interpolator2;
        int i10;
        float f10;
        int i11;
        int i12;
        int i13;
        View childAt;
        q qVar;
        boolean z10;
        if (this.f15972P == -1) {
            this.f15972P = getNanoTime();
        }
        float f11 = this.f15971O;
        float f12 = 0.0f;
        if (f11 > 0.0f && f11 < 1.0f) {
            this.f15954F = -1;
        }
        boolean z11 = false;
        if (this.f15990k0 || (this.f15975S && (z3 || this.f15973Q != f11))) {
            float fSignum = Math.signum(this.f15973Q - f11);
            long nanoTime2 = getNanoTime();
            r rVar = this.f15946B;
            float f13 = rVar == null ? (((nanoTime2 - this.f15972P) * fSignum) * 1.0E-9f) / this.M : 0.0f;
            float f14 = this.f15971O + f13;
            if (this.f15974R) {
                f14 = this.f15973Q;
            }
            if ((fSignum <= 0.0f || f14 < this.f15973Q) && (fSignum > 0.0f || f14 > this.f15973Q)) {
                z5 = false;
            } else {
                f14 = this.f15973Q;
                this.f15975S = false;
                z5 = true;
            }
            this.f15971O = f14;
            this.f15969N = f14;
            this.f15972P = nanoTime2;
            if (rVar == null || z5) {
                this.f15950D = f13;
            } else {
                if (this.f15979W) {
                    float interpolation2 = rVar.getInterpolation((nanoTime2 - this.f15966L) * 1.0E-9f);
                    r rVar2 = this.f15946B;
                    a aVar = this.f15980a0;
                    if (rVar2 == aVar) {
                        c10 = aVar.f13462c.a() ? (char) 2 : (char) 1;
                    } else {
                        c10 = 0;
                    }
                    this.f15971O = interpolation2;
                    this.f15972P = nanoTime2;
                    r rVar3 = this.f15946B;
                    if (rVar3 != null) {
                        float fA = rVar3.a();
                        this.f15950D = fA;
                        if (Math.abs(fA) * this.M <= 1.0E-5f && c10 == 2) {
                            this.f15975S = false;
                        }
                        if (fA > 0.0f && interpolation2 >= 1.0f) {
                            this.f15971O = 1.0f;
                            this.f15975S = false;
                            interpolation2 = 1.0f;
                        }
                        if (fA >= 0.0f || interpolation2 > 0.0f) {
                            f14 = interpolation2;
                        } else {
                            this.f15971O = 0.0f;
                            this.f15975S = false;
                            f14 = 0.0f;
                        }
                    } else {
                        f14 = interpolation2;
                    }
                } else {
                    float interpolation3 = rVar.getInterpolation(f14);
                    r rVar4 = this.f15946B;
                    if (rVar4 != null) {
                        this.f15950D = rVar4.a();
                    } else {
                        this.f15950D = ((rVar4.getInterpolation(f14 + f13) - interpolation3) * fSignum) / f13;
                    }
                    f14 = interpolation3;
                }
                if (Math.abs(this.f15950D) > 1.0E-5f) {
                    setState(z.f13958c);
                }
                zVar = z.f13959d;
                if (c10 != 1) {
                    if ((fSignum <= 0.0f && f14 >= this.f15973Q) || (fSignum <= 0.0f && f14 <= this.f15973Q)) {
                        f14 = this.f15973Q;
                        this.f15975S = false;
                    }
                    if (f14 < 1.0f || f14 <= 0.0f) {
                        this.f15975S = false;
                        setState(zVar);
                    }
                }
                childCount = getChildCount();
                this.f15990k0 = false;
                nanoTime = getNanoTime();
                this.f15947B0 = f14;
                interpolator = this.f15948C;
                if (interpolator == null) {
                    interpolation = f14;
                } else {
                    interpolation = interpolator.getInterpolation(f14);
                }
                interpolator2 = this.f15948C;
                if (interpolator2 != null) {
                    float interpolation4 = interpolator2.getInterpolation((fSignum / this.M) + f14);
                    this.f15950D = interpolation4;
                    this.f15950D = interpolation4 - this.f15948C.getInterpolation(f14);
                }
                i10 = 0;
                while (i10 < childCount) {
                    childAt = getChildAt(i10);
                    qVar = (q) this.f15964K.get(childAt);
                    if (qVar != null) {
                        this.f15990k0 = qVar.f(interpolation, nanoTime, this.f15949C0, childAt) | this.f15990k0;
                    }
                    i10++;
                    f12 = f12;
                }
                f10 = f12;
                boolean z12 = (fSignum <= 0.0f && f14 >= this.f15973Q) || (fSignum <= f10 && f14 <= this.f15973Q);
                if (!this.f15990k0 && !this.f15975S && z12) {
                    setState(zVar);
                }
                if (this.f16000u0) {
                    requestLayout();
                }
                this.f15990k0 = (!z12) | this.f15990k0;
                if (f14 <= f10 && (i13 = this.f15952E) != -1 && this.f15954F != i13) {
                    this.f15954F = i13;
                    this.f15944A.b(i13).a(this);
                    setState(zVar);
                    z11 = true;
                }
                if (f14 >= 1.0d) {
                    i11 = this.f15954F;
                    i12 = this.f15956G;
                    if (i11 != i12) {
                        this.f15954F = i12;
                        this.f15944A.b(i12).a(this);
                        setState(zVar);
                        z11 = true;
                    }
                }
                if (!this.f15990k0 || this.f15975S) {
                    invalidate();
                } else if ((fSignum > 0.0f && f14 == 1.0f) || (fSignum < f10 && f14 == f10)) {
                    setState(zVar);
                }
                if (!this.f15990k0 && !this.f15975S && ((fSignum > 0.0f && f14 == 1.0f) || (fSignum < f10 && f14 == f10))) {
                    y();
                }
            }
            c10 = 0;
            if (Math.abs(this.f15950D) > 1.0E-5f) {
                setState(z.f13958c);
            }
            zVar = z.f13959d;
            if (c10 != 1) {
                if (fSignum <= 0.0f) {
                    f14 = this.f15973Q;
                    this.f15975S = false;
                } else {
                    f14 = this.f15973Q;
                    this.f15975S = false;
                }
                if (f14 < 1.0f) {
                    this.f15975S = false;
                    setState(zVar);
                } else {
                    this.f15975S = false;
                    setState(zVar);
                }
            }
            childCount = getChildCount();
            this.f15990k0 = false;
            nanoTime = getNanoTime();
            this.f15947B0 = f14;
            interpolator = this.f15948C;
            if (interpolator == null) {
                interpolation = f14;
            } else {
                interpolation = interpolator.getInterpolation(f14);
            }
            interpolator2 = this.f15948C;
            if (interpolator2 != null) {
                float interpolation5 = interpolator2.getInterpolation((fSignum / this.M) + f14);
                this.f15950D = interpolation5;
                this.f15950D = interpolation5 - this.f15948C.getInterpolation(f14);
            }
            i10 = 0;
            while (i10 < childCount) {
                childAt = getChildAt(i10);
                qVar = (q) this.f15964K.get(childAt);
                if (qVar != null) {
                    this.f15990k0 = qVar.f(interpolation, nanoTime, this.f15949C0, childAt) | this.f15990k0;
                }
                i10++;
                f12 = f12;
            }
            f10 = f12;
            if (fSignum <= 0.0f) {
            }
            if (!this.f15990k0) {
                setState(zVar);
            }
            if (this.f16000u0) {
                requestLayout();
            }
            this.f15990k0 = (!z12) | this.f15990k0;
            if (f14 <= f10) {
                this.f15954F = i13;
                this.f15944A.b(i13).a(this);
                setState(zVar);
                z11 = true;
            }
            if (f14 >= 1.0d) {
                i11 = this.f15954F;
                i12 = this.f15956G;
                if (i11 != i12) {
                    this.f15954F = i12;
                    this.f15944A.b(i12).a(this);
                    setState(zVar);
                    z11 = true;
                }
            }
            if (this.f15990k0) {
                invalidate();
            } else {
                invalidate();
            }
            if (!this.f15990k0) {
                y();
            }
        } else {
            f10 = 0.0f;
        }
        float f15 = this.f15971O;
        if (f15 < 1.0f) {
            if (f15 <= f10) {
                int i14 = this.f15954F;
                int i15 = this.f15952E;
                z10 = i14 == i15 ? z11 : true;
                this.f15954F = i15;
            }
            this.f15965K0 |= z11;
            if (z11 && !this.f15951D0) {
                requestLayout();
            }
            this.f15969N = this.f15971O;
        }
        int i16 = this.f15954F;
        int i17 = this.f15956G;
        z10 = i16 == i17 ? z11 : true;
        this.f15954F = i17;
        z11 = z10;
        this.f15965K0 |= z11;
        if (z11) {
            requestLayout();
        }
        this.f15969N = this.f15971O;
    }

    public void setDebugMode(int i10) {
        this.f15977U = i10;
        invalidate();
    }

    public void setDelayedApplicationOfInitialState(boolean z3) {
        this.f15959H0 = z3;
    }

    public void setInteractionEnabled(boolean z3) {
        this.f15962J = z3;
    }

    public void setInterpolatedProgress(float f10) {
        if (this.f15944A != null) {
            setState(z.f13958c);
            Interpolator interpolatorE = this.f15944A.e();
            if (interpolatorE != null) {
                setProgress(interpolatorE.getInterpolation(f10));
                return;
            }
        }
        setProgress(f10);
    }

    public void setOnHide(float f10) {
        ArrayList arrayList = this.f15992m0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((MotionHelper) this.f15992m0.get(i10)).setProgress(f10);
            }
        }
    }

    public void setOnShow(float f10) {
        ArrayList arrayList = this.f15991l0;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                ((MotionHelper) this.f15991l0.get(i10)).setProgress(f10);
            }
        }
    }

    public void setProgress(float f10) {
        if (f10 < 0.0f || f10 > 1.0f) {
            Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive");
        }
        if (!isAttachedToWindow()) {
            if (this.f15953E0 == null) {
                this.f15953E0 = new x(this);
            }
            this.f15953E0.f13951a = f10;
            return;
        }
        z zVar = z.f13959d;
        z zVar2 = z.f13958c;
        if (f10 <= 0.0f) {
            if (this.f15971O == 1.0f && this.f15954F == this.f15956G) {
                setState(zVar2);
            }
            this.f15954F = this.f15952E;
            if (this.f15971O == 0.0f) {
                setState(zVar);
            }
        } else if (f10 >= 1.0f) {
            if (this.f15971O == 0.0f && this.f15954F == this.f15952E) {
                setState(zVar2);
            }
            this.f15954F = this.f15956G;
            if (this.f15971O == 1.0f) {
                setState(zVar);
            }
        } else {
            this.f15954F = -1;
            setState(zVar2);
        }
        if (this.f15944A == null) {
            return;
        }
        this.f15974R = true;
        this.f15973Q = f10;
        this.f15969N = f10;
        this.f15972P = -1L;
        this.f15966L = -1L;
        this.f15946B = null;
        this.f15975S = true;
        invalidate();
    }

    public void setScene(D d10) {
        G g10;
        this.f15944A = d10;
        boolean zK = k();
        d10.f13717p = zK;
        C c10 = d10.f13705c;
        if (c10 != null && (g10 = c10.f13696l) != null) {
            g10.c(zK);
        }
        A();
    }

    public void setStartState(int i10) {
        if (isAttachedToWindow()) {
            this.f15954F = i10;
            return;
        }
        if (this.f15953E0 == null) {
            this.f15953E0 = new x(this);
        }
        x xVar = this.f15953E0;
        xVar.f13953c = i10;
        xVar.f13954d = i10;
    }

    public void setState(z zVar) {
        z zVar2 = z.f13959d;
        if (zVar == zVar2 && this.f15954F == -1) {
            return;
        }
        z zVar3 = this.f15961I0;
        this.f15961I0 = zVar;
        z zVar4 = z.f13958c;
        if (zVar3 == zVar4 && zVar == zVar4) {
            t();
        }
        int iOrdinal = zVar3.ordinal();
        if (iOrdinal != 0 && iOrdinal != 1) {
            if (iOrdinal == 2 && zVar == zVar2) {
                u();
                return;
            }
            return;
        }
        if (zVar == zVar4) {
            t();
        }
        if (zVar == zVar2) {
            u();
        }
    }

    public void setTransition(int i10) {
        float f10;
        if (this.f15944A != null) {
            C cW = w(i10);
            this.f15952E = cW.f13689d;
            this.f15956G = cW.f13688c;
            if (!isAttachedToWindow()) {
                if (this.f15953E0 == null) {
                    this.f15953E0 = new x(this);
                }
                x xVar = this.f15953E0;
                xVar.f13953c = this.f15952E;
                xVar.f13954d = this.f15956G;
                return;
            }
            int i11 = this.f15954F;
            if (i11 == this.f15952E) {
                f10 = 0.0f;
            } else {
                f10 = i11 == this.f15956G ? 1.0f : Float.NaN;
            }
            D d10 = this.f15944A;
            d10.f13705c = cW;
            G g10 = cW.f13696l;
            if (g10 != null) {
                g10.c(d10.f13717p);
            }
            this.f15963J0.e(this.f15944A.b(this.f15952E), this.f15944A.b(this.f15956G));
            A();
            if (this.f15971O != f10) {
                if (f10 == 0.0f) {
                    r(true);
                    this.f15944A.b(this.f15952E).b(this);
                } else if (f10 == 1.0f) {
                    r(false);
                    this.f15944A.b(this.f15956G).b(this);
                }
            }
            this.f15971O = Float.isNaN(f10) ? 0.0f : f10;
            if (!Float.isNaN(f10)) {
                setProgress(f10);
                return;
            }
            Log.v("MotionLayout", p123ja.a.I() + " transitionToStart ");
            q(0.0f);
        }
    }

    public void setTransitionDuration(int i10) {
        D d10 = this.f15944A;
        if (d10 == null) {
            Log.e("MotionLayout", "MotionScene not defined");
            return;
        }
        C c10 = d10.f13705c;
        if (c10 != null) {
            c10.f13693h = Math.max(i10, 8);
        } else {
            d10.f13712j = i10;
        }
    }

    public void setTransitionListener(y yVar) {
        this.f15976T = yVar;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.f15953E0 == null) {
            this.f15953E0 = new x(this);
        }
        x xVar = this.f15953E0;
        xVar.getClass();
        xVar.f13951a = bundle.getFloat("motion.progress");
        xVar.f13952b = bundle.getFloat("motion.velocity");
        xVar.f13953c = bundle.getInt("motion.StartState");
        xVar.f13954d = bundle.getInt("motion.EndState");
        if (isAttachedToWindow()) {
            this.f15953E0.a();
        }
    }

    public final void t() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        CopyOnWriteArrayList copyOnWriteArrayList2;
        if ((this.f15976T == null && ((copyOnWriteArrayList2 = this.f15994o0) == null || copyOnWriteArrayList2.isEmpty())) || this.f15999t0 == this.f15969N) {
            return;
        }
        if (this.f15998s0 != -1 && (copyOnWriteArrayList = this.f15994o0) != null) {
            Iterator it = copyOnWriteArrayList.iterator();
            while (it.hasNext()) {
                ((y) it.next()).getClass();
            }
        }
        this.f15998s0 = -1;
        this.f15999t0 = this.f15969N;
        CopyOnWriteArrayList copyOnWriteArrayList3 = this.f15994o0;
        if (copyOnWriteArrayList3 != null) {
            Iterator it2 = copyOnWriteArrayList3.iterator();
            while (it2.hasNext()) {
                ((y) it2.next()).getClass();
            }
        }
    }

    @Override // android.view.View
    public final String toString() {
        Context context = getContext();
        return p123ja.a.J(context, this.f15952E) + "->" + p123ja.a.J(context, this.f15956G) + " (pos:" + this.f15971O + " Dpos/Dt:" + this.f15950D;
    }

    public final void u() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if ((this.f15976T != null || ((copyOnWriteArrayList = this.f15994o0) != null && !copyOnWriteArrayList.isEmpty())) && this.f15998s0 == -1) {
            this.f15998s0 = this.f15954F;
            ArrayList arrayList = this.O0;
            int iIntValue = !arrayList.isEmpty() ? ((Integer) i.h(1, arrayList)).intValue() : -1;
            int i10 = this.f15954F;
            if (iIntValue != i10 && i10 != -1) {
                arrayList.add(Integer.valueOf(i10));
            }
        }
        z();
        B3.e eVar = this.f15955F0;
        if (eVar != null) {
            eVar.run();
            this.f15955F0 = null;
        }
    }

    public final void v(int i10, float f10, float f11, float f12, float[] fArr) {
        HashMap map = this.f15964K;
        View viewE = e(i10);
        q qVar = (q) map.get(viewE);
        if (qVar != null) {
            qVar.d(f10, f11, f12, fArr);
            viewE.getY();
        } else {
            Log.w("MotionLayout", "WARNING could not find view id " + (viewE == null ? i.i(i10, "") : viewE.getContext().getResources().getResourceName(i10)));
        }
    }

    public final C w(int i10) {
        ArrayList arrayList = this.f15944A.f13706d;
        int size = arrayList.size();
        int i11 = 0;
        while (i11 < size) {
            Object obj = arrayList.get(i11);
            i11++;
            C c10 = (C) obj;
            if (c10.f13686a == i10) {
                return c10;
            }
        }
        return null;
    }

    public final boolean x(float f10, float f11, View view, MotionEvent motionEvent) {
        boolean z3;
        boolean zOnTouchEvent;
        if (!(view instanceof ViewGroup)) {
            z3 = false;
            break;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount() - 1;
        while (true) {
            if (childCount < 0) {
                z3 = false;
                break;
            }
            View childAt = viewGroup.getChildAt(childCount);
            if (x((childAt.getLeft() + f10) - view.getScrollX(), (childAt.getTop() + f11) - view.getScrollY(), childAt, motionEvent)) {
                z3 = true;
                break;
            }
            childCount--;
        }
        if (!z3) {
            RectF rectF = this.f15967L0;
            rectF.set(f10, f11, (view.getRight() + f10) - view.getLeft(), (view.getBottom() + f11) - view.getTop());
            if (motionEvent.getAction() != 0 || rectF.contains(motionEvent.getX(), motionEvent.getY())) {
                float f12 = -f10;
                float f13 = -f11;
                Matrix matrix = view.getMatrix();
                if (matrix.isIdentity()) {
                    motionEvent.offsetLocation(f12, f13);
                    zOnTouchEvent = view.onTouchEvent(motionEvent);
                    motionEvent.offsetLocation(-f12, -f13);
                } else {
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(f12, f13);
                    if (this.f15970N0 == null) {
                        this.f15970N0 = new Matrix();
                    }
                    matrix.invert(this.f15970N0);
                    motionEventObtain.transform(this.f15970N0);
                    zOnTouchEvent = view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zOnTouchEvent) {
                    return true;
                }
            }
        }
        return z3;
    }

    public final void y() {
        C c10;
        G g10;
        View viewFindViewById;
        D d10 = this.f15944A;
        if (d10 == null) {
            return;
        }
        if (d10.a(this.f15954F, this)) {
            requestLayout();
            return;
        }
        int i10 = this.f15954F;
        if (i10 != -1) {
            D d11 = this.f15944A;
            ArrayList arrayList = d11.f13706d;
            int size = arrayList.size();
            int i11 = 0;
            while (i11 < size) {
                Object obj = arrayList.get(i11);
                i11++;
                C c11 = (C) obj;
                if (c11.f13697m.size() > 0) {
                    ArrayList arrayList2 = c11.f13697m;
                    int size2 = arrayList2.size();
                    int i12 = 0;
                    while (i12 < size2) {
                        Object obj2 = arrayList2.get(i12);
                        i12++;
                        ((B) obj2).b(this);
                    }
                }
            }
            ArrayList arrayList3 = d11.f13708f;
            int size3 = arrayList3.size();
            int i13 = 0;
            while (i13 < size3) {
                Object obj3 = arrayList3.get(i13);
                i13++;
                C c12 = (C) obj3;
                if (c12.f13697m.size() > 0) {
                    ArrayList arrayList4 = c12.f13697m;
                    int size4 = arrayList4.size();
                    int i14 = 0;
                    while (i14 < size4) {
                        Object obj4 = arrayList4.get(i14);
                        i14++;
                        ((B) obj4).b(this);
                    }
                }
            }
            int size5 = arrayList.size();
            int i15 = 0;
            while (i15 < size5) {
                Object obj5 = arrayList.get(i15);
                i15++;
                C c13 = (C) obj5;
                if (c13.f13697m.size() > 0) {
                    ArrayList arrayList5 = c13.f13697m;
                    int size6 = arrayList5.size();
                    int i16 = 0;
                    while (i16 < size6) {
                        Object obj6 = arrayList5.get(i16);
                        i16++;
                        ((B) obj6).a(this, i10, c13);
                    }
                }
            }
            int size7 = arrayList3.size();
            int i17 = 0;
            while (i17 < size7) {
                Object obj7 = arrayList3.get(i17);
                i17++;
                C c14 = (C) obj7;
                if (c14.f13697m.size() > 0) {
                    ArrayList arrayList6 = c14.f13697m;
                    int size8 = arrayList6.size();
                    int i18 = 0;
                    while (i18 < size8) {
                        Object obj8 = arrayList6.get(i18);
                        i18++;
                        ((B) obj8).a(this, i10, c14);
                    }
                }
            }
        }
        if (!this.f15944A.o() || (c10 = this.f15944A.f13705c) == null || (g10 = c10.f13696l) == null) {
            return;
        }
        int i19 = g10.f13732d;
        if (i19 != -1) {
            MotionLayout motionLayout = g10.f13745r;
            viewFindViewById = motionLayout.findViewById(i19);
            if (viewFindViewById == null) {
                Log.e("TouchResponse", "cannot find TouchAnchorId @id/" + p123ja.a.J(motionLayout.getContext(), g10.f13732d));
            }
        } else {
            viewFindViewById = null;
        }
        if (viewFindViewById instanceof NestedScrollView) {
            NestedScrollView nestedScrollView = (NestedScrollView) viewFindViewById;
            nestedScrollView.setOnTouchListener(new E(0));
            nestedScrollView.setOnScrollChangeListener(new F(0));
        }
    }

    public final void z() {
        CopyOnWriteArrayList copyOnWriteArrayList;
        if (this.f15976T == null && ((copyOnWriteArrayList = this.f15994o0) == null || copyOnWriteArrayList.isEmpty())) {
            return;
        }
        ArrayList arrayList = this.O0;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            Integer num = (Integer) obj;
            y yVar = this.f15976T;
            if (yVar != null) {
                yVar.a(num.intValue());
            }
            CopyOnWriteArrayList copyOnWriteArrayList2 = this.f15994o0;
            if (copyOnWriteArrayList2 != null) {
                Iterator it = copyOnWriteArrayList2.iterator();
                while (it.hasNext()) {
                    ((y) it.next()).a(num.intValue());
                }
            }
        }
        arrayList.clear();
    }

    public void setTransition(C c10) {
        G g10;
        D d10 = this.f15944A;
        d10.f13705c = c10;
        if (c10 != null && (g10 = c10.f13696l) != null) {
            g10.c(d10.f13717p);
        }
        setState(z.f13957b);
        int i10 = this.f15954F;
        C c11 = this.f15944A.f13705c;
        if (i10 == (c11 == null ? -1 : c11.f13688c)) {
            this.f15971O = 1.0f;
            this.f15969N = 1.0f;
            this.f15973Q = 1.0f;
        } else {
            this.f15971O = 0.0f;
            this.f15969N = 0.0f;
            this.f15973Q = 0.0f;
        }
        this.f15972P = (c10.f13702r & 1) != 0 ? -1L : getNanoTime();
        int iH = this.f15944A.h();
        D d11 = this.f15944A;
        C c12 = d11.f13705c;
        int i11 = c12 != null ? c12.f13688c : -1;
        if (iH == this.f15952E && i11 == this.f15956G) {
            return;
        }
        this.f15952E = iH;
        this.f15956G = i11;
        d11.n(iH, i11);
        d dVarB = this.f15944A.b(this.f15952E);
        d dVarB2 = this.f15944A.b(this.f15956G);
        v vVar = this.f15963J0;
        vVar.e(dVarB, dVarB2);
        int i12 = this.f15952E;
        int i13 = this.f15956G;
        vVar.f13946e = i12;
        vVar.f13947f = i13;
        vVar.f();
        A();
    }

    @Override // p200r1.InterfaceC1489p
    public final void i(View view, int i10, int i11, int i12, int i13, int i14) {
    }
}
