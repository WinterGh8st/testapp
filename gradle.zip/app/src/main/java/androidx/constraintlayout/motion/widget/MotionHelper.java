package androidx.constraintlayout.motion.widget;

import Y0.y;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.HashMap;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class MotionHelper extends ConstraintHelper implements y {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f15939t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f15940u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public float f15941v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public View[] f15942w;

    public MotionHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15939t = false;
        this.f15940u = false;
        k(attributeSet);
    }

    public float getProgress() {
        return this.f15941v;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15057t);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 1) {
                    this.f15939t = typedArrayObtainStyledAttributes.getBoolean(index, this.f15939t);
                } else if (index == 0) {
                    this.f15940u = typedArrayObtainStyledAttributes.getBoolean(index, this.f15940u);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void setProgress(float f10) {
        this.f15941v = f10;
        int i10 = 0;
        if (this.f16109b > 0) {
            this.f15942w = j((ConstraintLayout) getParent());
            while (i10 < this.f16109b) {
                View view = this.f15942w[i10];
                i10++;
            }
            return;
        }
        ViewGroup viewGroup = (ViewGroup) getParent();
        int childCount = viewGroup.getChildCount();
        while (i10 < childCount) {
            boolean z3 = viewGroup.getChildAt(i10) instanceof MotionHelper;
            i10++;
        }
    }

    public void a(int i10) {
    }

    public void r(MotionLayout motionLayout, HashMap map) {
    }
}
