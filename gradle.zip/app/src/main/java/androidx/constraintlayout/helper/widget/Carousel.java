package androidx.constraintlayout.helper.widget;

import B2.RunnableC0052c;
import W0.a;
import Y0.C;
import Y0.G;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import java.util.ArrayList;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Carousel extends MotionHelper {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f15870A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f15871B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final int f15872C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f15873D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final int f15874E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final int f15875F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final float f15876G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final int f15877H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f15878I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final float f15879J;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final ArrayList f15880x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f15881y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public MotionLayout f15882z;

    public Carousel(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15880x = new ArrayList();
        this.f15881y = 0;
        this.f15870A = -1;
        this.f15871B = false;
        this.f15872C = -1;
        this.f15873D = -1;
        this.f15874E = -1;
        this.f15875F = -1;
        this.f15876G = 0.9f;
        this.f15877H = 4;
        this.f15878I = 1;
        this.f15879J = 2.0f;
        new RunnableC0052c(this, 25);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15039a);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 3) {
                    this.f15870A = typedArrayObtainStyledAttributes.getResourceId(index, this.f15870A);
                } else if (index == 1) {
                    this.f15872C = typedArrayObtainStyledAttributes.getResourceId(index, this.f15872C);
                } else if (index == 4) {
                    this.f15873D = typedArrayObtainStyledAttributes.getResourceId(index, this.f15873D);
                } else if (index == 2) {
                    this.f15877H = typedArrayObtainStyledAttributes.getInt(index, this.f15877H);
                } else if (index == 7) {
                    this.f15874E = typedArrayObtainStyledAttributes.getResourceId(index, this.f15874E);
                } else if (index == 6) {
                    this.f15875F = typedArrayObtainStyledAttributes.getResourceId(index, this.f15875F);
                } else if (index == 9) {
                    this.f15876G = typedArrayObtainStyledAttributes.getFloat(index, this.f15876G);
                } else if (index == 8) {
                    this.f15878I = typedArrayObtainStyledAttributes.getInt(index, this.f15878I);
                } else if (index == 10) {
                    this.f15879J = typedArrayObtainStyledAttributes.getFloat(index, this.f15879J);
                } else if (index == 5) {
                    this.f15871B = typedArrayObtainStyledAttributes.getBoolean(index, this.f15871B);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.motion.widget.MotionHelper, Y0.y
    public final void a(int i10) {
        int i11 = this.f15881y;
        if (i10 == this.f15875F) {
            this.f15881y = i11 + 1;
        } else if (i10 == this.f15874E) {
            this.f15881y = i11 - 1;
        }
        if (!this.f15871B) {
            throw null;
        }
        throw null;
    }

    public int getCount() {
        return 0;
    }

    public int getCurrentIndex() {
        return this.f15881y;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        G g10;
        G g11;
        super.onAttachedToWindow();
        if (getParent() instanceof MotionLayout) {
            MotionLayout motionLayout = (MotionLayout) getParent();
            ArrayList arrayList = this.f15880x;
            arrayList.clear();
            for (int i10 = 0; i10 < this.f16109b; i10++) {
                arrayList.add(motionLayout.e(this.f16108a[i10]));
            }
            this.f15882z = motionLayout;
            if (this.f15878I == 2) {
                C cW = motionLayout.w(this.f15873D);
                if (cW != null && (g11 = cW.f13696l) != null) {
                    g11.f13731c = 5;
                }
                C cW2 = this.f15882z.w(this.f15872C);
                if (cW2 == null || (g10 = cW2.f13696l) == null) {
                    return;
                }
                g10.f13731c = 5;
            }
        }
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f15880x.clear();
    }

    public void setInfinite(boolean z3) {
        this.f15871B = z3;
    }

    public void setAdapter(a aVar) {
    }
}
