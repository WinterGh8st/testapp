package androidx.constraintlayout.helper.widget;

import U0.e;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Layer extends ConstraintHelper {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public float f15913A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public float f15914B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public float f15915C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public float f15916D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public float f15917E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final boolean f15918F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public View[] f15919G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public float f15920H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public float f15921I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean f15922J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public boolean f15923K;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float f15924t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public float f15925u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public float f15926v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ConstraintLayout f15927w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public float f15928x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public float f15929y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f15930z;

    public Layer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15924t = Float.NaN;
        this.f15925u = Float.NaN;
        this.f15926v = Float.NaN;
        this.f15928x = 1.0f;
        this.f15929y = 1.0f;
        this.f15930z = Float.NaN;
        this.f15913A = Float.NaN;
        this.f15914B = Float.NaN;
        this.f15915C = Float.NaN;
        this.f15916D = Float.NaN;
        this.f15917E = Float.NaN;
        this.f15918F = true;
        this.f15919G = null;
        this.f15920H = 0.0f;
        this.f15921I = 0.0f;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void g(ConstraintLayout constraintLayout) {
        f(constraintLayout);
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.f16112e = false;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 6) {
                    this.f15922J = true;
                } else if (index == 22) {
                    this.f15923K = true;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void n() {
        s();
        this.f15930z = Float.NaN;
        this.f15913A = Float.NaN;
        e eVar = ((ConstraintLayout.LayoutParams) getLayoutParams()).f16190q0;
        eVar.P(0);
        eVar.M(0);
        r();
        layout(((int) this.f15916D) - getPaddingLeft(), ((int) this.f15917E) - getPaddingTop(), getPaddingRight() + ((int) this.f15914B), getPaddingBottom() + ((int) this.f15915C));
        t();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void o(ConstraintLayout constraintLayout) {
        this.f15927w = constraintLayout;
        float rotation = getRotation();
        if (rotation != 0.0f) {
            this.f15926v = rotation;
        } else {
            if (Float.isNaN(this.f15926v)) {
                return;
            }
            this.f15926v = rotation;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f15927w = (ConstraintLayout) getParent();
        if (this.f15922J || this.f15923K) {
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i10 = 0; i10 < this.f16109b; i10++) {
                View viewE = this.f15927w.e(this.f16108a[i10]);
                if (viewE != null) {
                    if (this.f15922J) {
                        viewE.setVisibility(visibility);
                    }
                    if (this.f15923K && elevation > 0.0f) {
                        viewE.setTranslationZ(viewE.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    public final void r() {
        if (this.f15927w == null) {
            return;
        }
        if (this.f15918F || Float.isNaN(this.f15930z) || Float.isNaN(this.f15913A)) {
            if (!Float.isNaN(this.f15924t) && !Float.isNaN(this.f15925u)) {
                this.f15913A = this.f15925u;
                this.f15930z = this.f15924t;
                return;
            }
            View[] viewArrJ = j(this.f15927w);
            int left = viewArrJ[0].getLeft();
            int top = viewArrJ[0].getTop();
            int right = viewArrJ[0].getRight();
            int bottom = viewArrJ[0].getBottom();
            for (int i10 = 0; i10 < this.f16109b; i10++) {
                View view = viewArrJ[i10];
                left = Math.min(left, view.getLeft());
                top = Math.min(top, view.getTop());
                right = Math.max(right, view.getRight());
                bottom = Math.max(bottom, view.getBottom());
            }
            this.f15914B = right;
            this.f15915C = bottom;
            this.f15916D = left;
            this.f15917E = top;
            if (Float.isNaN(this.f15924t)) {
                this.f15930z = (left + right) / 2;
            } else {
                this.f15930z = this.f15924t;
            }
            if (Float.isNaN(this.f15925u)) {
                this.f15913A = (top + bottom) / 2;
            } else {
                this.f15913A = this.f15925u;
            }
        }
    }

    public final void s() {
        int i10;
        if (this.f15927w == null || (i10 = this.f16109b) == 0) {
            return;
        }
        View[] viewArr = this.f15919G;
        if (viewArr == null || viewArr.length != i10) {
            this.f15919G = new View[i10];
        }
        for (int i11 = 0; i11 < this.f16109b; i11++) {
            this.f15919G[i11] = this.f15927w.e(this.f16108a[i11]);
        }
    }

    @Override // android.view.View
    public void setElevation(float f10) {
        super.setElevation(f10);
        e();
    }

    @Override // android.view.View
    public void setPivotX(float f10) {
        this.f15924t = f10;
        t();
    }

    @Override // android.view.View
    public void setPivotY(float f10) {
        this.f15925u = f10;
        t();
    }

    @Override // android.view.View
    public void setRotation(float f10) {
        this.f15926v = f10;
        t();
    }

    @Override // android.view.View
    public void setScaleX(float f10) {
        this.f15928x = f10;
        t();
    }

    @Override // android.view.View
    public void setScaleY(float f10) {
        this.f15929y = f10;
        t();
    }

    @Override // android.view.View
    public void setTranslationX(float f10) {
        this.f15920H = f10;
        t();
    }

    @Override // android.view.View
    public void setTranslationY(float f10) {
        this.f15921I = f10;
        t();
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        e();
    }

    public final void t() {
        if (this.f15927w == null) {
            return;
        }
        if (this.f15919G == null) {
            s();
        }
        r();
        double radians = Float.isNaN(this.f15926v) ? 0.0d : Math.toRadians(this.f15926v);
        float fSin = (float) Math.sin(radians);
        float fCos = (float) Math.cos(radians);
        float f10 = this.f15928x;
        float f11 = f10 * fCos;
        float f12 = this.f15929y;
        float f13 = (-f12) * fSin;
        float f14 = f10 * fSin;
        float f15 = f12 * fCos;
        for (int i10 = 0; i10 < this.f16109b; i10++) {
            View view = this.f15919G[i10];
            int right = (view.getRight() + view.getLeft()) / 2;
            int bottom = (view.getBottom() + view.getTop()) / 2;
            float f16 = right - this.f15930z;
            float f17 = bottom - this.f15913A;
            float f18 = (((f13 * f17) + (f11 * f16)) - f16) + this.f15920H;
            float f19 = (((f15 * f17) + (f16 * f14)) - f17) + this.f15921I;
            view.setTranslationX(f18);
            view.setTranslationY(f19);
            view.setScaleY(this.f15929y);
            view.setScaleX(this.f15928x);
            if (!Float.isNaN(this.f15926v)) {
                view.setRotation(this.f15926v);
            }
        }
    }
}
