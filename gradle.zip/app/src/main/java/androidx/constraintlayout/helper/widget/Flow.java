package androidx.constraintlayout.helper.widget;

import U0.e;
import U0.h;
import U0.j;
import U0.m;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.Constraints;
import androidx.constraintlayout.widget.VirtualLayout;
import androidx.constraintlayout.widget.c;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Flow extends VirtualLayout {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public h f15895v;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.f15895v = new h();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 0) {
                    this.f15895v.f12283Z0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    h hVar = this.f15895v;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    hVar.f12304w0 = dimensionPixelSize;
                    hVar.f12305x0 = dimensionPixelSize;
                    hVar.f12306y0 = dimensionPixelSize;
                    hVar.f12307z0 = dimensionPixelSize;
                } else if (index == 18) {
                    h hVar2 = this.f15895v;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    hVar2.f12306y0 = dimensionPixelSize2;
                    hVar2.f12297A0 = dimensionPixelSize2;
                    hVar2.f12298B0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f15895v.f12307z0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f15895v.f12297A0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f15895v.f12304w0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f15895v.f12298B0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f15895v.f12305x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f15895v.f12281X0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f15895v.f12266H0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f15895v.f12267I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f15895v.f12268J0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f15895v.f12270L0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f15895v.f12269K0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f15895v.f12271M0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f15895v.f12272N0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f15895v.f12273P0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f15895v.f12275R0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f15895v.f12274Q0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f15895v.f12276S0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f15895v.O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f15895v.f12279V0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f15895v.f12280W0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f15895v.f12277T0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f15895v.f12278U0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f15895v.f12282Y0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f16111d = this.f15895v;
        q();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void l(c cVar, j jVar, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        super.l(cVar, jVar, layoutParams, sparseArray);
        if (jVar instanceof h) {
            h hVar = (h) jVar;
            int i10 = layoutParams.f16153V;
            if (i10 != -1) {
                hVar.f12283Z0 = i10;
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void m(e eVar, boolean z3) {
        h hVar = this.f15895v;
        int i10 = hVar.f12306y0;
        if (i10 > 0 || hVar.f12307z0 > 0) {
            if (z3) {
                hVar.f12297A0 = hVar.f12307z0;
                hVar.f12298B0 = i10;
            } else {
                hVar.f12297A0 = i10;
                hVar.f12298B0 = hVar.f12307z0;
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onMeasure(int i10, int i11) {
        r(this.f15895v, i10, i11);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout
    public final void r(m mVar, int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mVar == null) {
            setMeasuredDimension(0, 0);
        } else {
            mVar.V(mode, size, mode2, size2);
            setMeasuredDimension(mVar.f12300D0, mVar.f12301E0);
        }
    }

    public void setFirstHorizontalBias(float f10) {
        this.f15895v.f12273P0 = f10;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i10) {
        this.f15895v.f12268J0 = i10;
        requestLayout();
    }

    public void setFirstVerticalBias(float f10) {
        this.f15895v.f12274Q0 = f10;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i10) {
        this.f15895v.f12269K0 = i10;
        requestLayout();
    }

    public void setHorizontalAlign(int i10) {
        this.f15895v.f12279V0 = i10;
        requestLayout();
    }

    public void setHorizontalBias(float f10) {
        this.f15895v.f12272N0 = f10;
        requestLayout();
    }

    public void setHorizontalGap(int i10) {
        this.f15895v.f12277T0 = i10;
        requestLayout();
    }

    public void setHorizontalStyle(int i10) {
        this.f15895v.f12266H0 = i10;
        requestLayout();
    }

    public void setLastHorizontalBias(float f10) {
        this.f15895v.f12275R0 = f10;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i10) {
        this.f15895v.f12270L0 = i10;
        requestLayout();
    }

    public void setLastVerticalBias(float f10) {
        this.f15895v.f12276S0 = f10;
        requestLayout();
    }

    public void setLastVerticalStyle(int i10) {
        this.f15895v.f12271M0 = i10;
        requestLayout();
    }

    public void setMaxElementsWrap(int i10) {
        this.f15895v.f12282Y0 = i10;
        requestLayout();
    }

    public void setOrientation(int i10) {
        this.f15895v.f12283Z0 = i10;
        requestLayout();
    }

    public void setPadding(int i10) {
        h hVar = this.f15895v;
        hVar.f12304w0 = i10;
        hVar.f12305x0 = i10;
        hVar.f12306y0 = i10;
        hVar.f12307z0 = i10;
        requestLayout();
    }

    public void setPaddingBottom(int i10) {
        this.f15895v.f12305x0 = i10;
        requestLayout();
    }

    public void setPaddingLeft(int i10) {
        this.f15895v.f12297A0 = i10;
        requestLayout();
    }

    public void setPaddingRight(int i10) {
        this.f15895v.f12298B0 = i10;
        requestLayout();
    }

    public void setPaddingTop(int i10) {
        this.f15895v.f12304w0 = i10;
        requestLayout();
    }

    public void setVerticalAlign(int i10) {
        this.f15895v.f12280W0 = i10;
        requestLayout();
    }

    public void setVerticalBias(float f10) {
        this.f15895v.O0 = f10;
        requestLayout();
    }

    public void setVerticalGap(int i10) {
        this.f15895v.f12278U0 = i10;
        requestLayout();
    }

    public void setVerticalStyle(int i10) {
        this.f15895v.f12267I0 = i10;
        requestLayout();
    }

    public void setWrapMode(int i10) {
        this.f15895v.f12281X0 = i10;
        requestLayout();
    }
}
