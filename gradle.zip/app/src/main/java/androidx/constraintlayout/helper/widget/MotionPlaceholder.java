package androidx.constraintlayout.helper.widget;

import U0.j;
import U0.l;
import U0.m;
import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.VirtualLayout;

/* JADX INFO: loaded from: classes.dex */
public class MotionPlaceholder extends VirtualLayout {
    public MotionPlaceholder(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.f16111d = new l();
        q();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onMeasure(int i10, int i11) {
        r(null, i10, i11);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout
    public final void r(m mVar, int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mVar == null) {
            setMeasuredDimension(0, 0);
        } else {
            mVar.V(mode, size, mode2, size2);
            setMeasuredDimension(mVar.f12300D0, mVar.f12301E0);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void p(j jVar, SparseArray sparseArray) {
    }
}
