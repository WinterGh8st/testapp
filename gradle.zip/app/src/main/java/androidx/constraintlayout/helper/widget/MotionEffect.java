package androidx.constraintlayout.helper.widget;

import Y0.A;
import Y0.C0780e;
import Y0.C0785j;
import Y0.D;
import Y0.I;
import Y0.q;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.motion.widget.MotionHelper;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.ArrayList;
import java.util.HashMap;
import p005a1.k;
import p123ja.a;

/* JADX INFO: loaded from: classes.dex */
public class MotionEffect extends MotionHelper {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f15931A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f15932B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final boolean f15933C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f15934D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final int f15935E;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final float f15936x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f15937y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f15938z;

    public MotionEffect(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15936x = 0.1f;
        this.f15937y = 49;
        this.f15938z = 50;
        this.f15931A = 0;
        this.f15932B = 0;
        this.f15933C = true;
        this.f15934D = -1;
        this.f15935E = -1;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15056s);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 3) {
                    int i11 = typedArrayObtainStyledAttributes.getInt(index, this.f15937y);
                    this.f15937y = i11;
                    this.f15937y = Math.max(Math.min(i11, 99), 0);
                } else if (index == 1) {
                    int i12 = typedArrayObtainStyledAttributes.getInt(index, this.f15938z);
                    this.f15938z = i12;
                    this.f15938z = Math.max(Math.min(i12, 99), 0);
                } else if (index == 5) {
                    this.f15931A = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f15931A);
                } else if (index == 6) {
                    this.f15932B = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f15932B);
                } else if (index == 0) {
                    this.f15936x = typedArrayObtainStyledAttributes.getFloat(index, this.f15936x);
                } else if (index == 2) {
                    this.f15935E = typedArrayObtainStyledAttributes.getInt(index, this.f15935E);
                } else if (index == 4) {
                    this.f15933C = typedArrayObtainStyledAttributes.getBoolean(index, this.f15933C);
                } else if (index == 7) {
                    this.f15934D = typedArrayObtainStyledAttributes.getResourceId(index, this.f15934D);
                }
            }
            int i13 = this.f15937y;
            int i14 = this.f15938z;
            if (i13 == i14) {
                if (i13 > 0) {
                    this.f15937y = i13 - 1;
                } else {
                    this.f15938z = i14 + 1;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX WARN: Code duplicated, block: B:100:0x0204  */
    /* JADX WARN: Code duplicated, block: B:102:0x0212  */
    /* JADX WARN: Code duplicated, block: B:106:0x0236  */
    /* JADX WARN: Code duplicated, block: B:107:0x023c A[LOOP:3: B:101:0x0210->B:107:0x023c, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:119:0x0243 A[EDGE_INSN: B:119:0x0243->B:108:0x0243 BREAK  A[LOOP:3: B:101:0x0210->B:107:0x023c], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:121:0x0170 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:122:0x0224 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:59:0x0193  */
    /* JADX WARN: Code duplicated, block: B:60:0x0198  */
    /* JADX WARN: Code duplicated, block: B:92:0x01dd  */
    /* JADX WARN: Code duplicated, block: B:94:0x01ed  */
    /* JADX WARN: Code duplicated, block: B:97:0x01f7  */
    /* JADX WARN: Code duplicated, block: B:98:0x01fe  */
    @Override // androidx.constraintlayout.motion.widget.MotionHelper
    public final void r(MotionLayout motionLayout, HashMap map) {
        C0780e c0780e;
        C0780e c0780e2;
        C0780e c0780e3;
        int i10;
        int i11;
        int i12;
        View[] viewArr;
        int i13;
        D d10;
        ArrayList arrayList;
        int size;
        int i14;
        int i15;
        I i16;
        ArrayList arrayList2;
        ArrayList arrayList3;
        int i17;
        int i18;
        MotionEffect motionEffect = this;
        HashMap map2 = map;
        View[] viewArrJ = motionEffect.j((ConstraintLayout) motionEffect.getParent());
        if (viewArrJ == null) {
            Log.v("FadeMove", a.H() + " views = null");
            return;
        }
        C0780e c0780e4 = new C0780e();
        C0780e c0780e5 = new C0780e();
        c0780e4.h(Float.valueOf(motionEffect.f15936x), "alpha");
        c0780e5.h(Float.valueOf(motionEffect.f15936x), "alpha");
        int i19 = motionEffect.f15937y;
        c0780e4.f13786a = i19;
        c0780e5.f13786a = motionEffect.f15938z;
        C0785j c0785j = new C0785j();
        c0785j.f13786a = i19;
        c0785j.f13834m = 0;
        c0785j.h(0, "percentX");
        c0785j.h(0, "percentY");
        C0785j c0785j2 = new C0785j();
        c0785j2.f13786a = motionEffect.f15938z;
        c0785j2.f13834m = 0;
        int i20 = 1;
        c0785j2.h(1, "percentX");
        c0785j2.h(1, "percentY");
        C0780e c0780e6 = null;
        if (motionEffect.f15931A > 0) {
            c0780e = new C0780e();
            c0780e2 = new C0780e();
            c0780e.h(Integer.valueOf(motionEffect.f15931A), "translationX");
            c0780e.f13786a = motionEffect.f15938z;
            c0780e2.h(0, "translationX");
            c0780e2.f13786a = motionEffect.f15938z - 1;
        } else {
            c0780e = null;
            c0780e2 = null;
        }
        if (motionEffect.f15932B > 0) {
            c0780e6 = new C0780e();
            c0780e3 = new C0780e();
            c0780e6.h(Integer.valueOf(motionEffect.f15932B), "translationY");
            c0780e6.f13786a = motionEffect.f15938z;
            c0780e3.h(0, "translationY");
            c0780e3.f13786a = motionEffect.f15938z - 1;
        } else {
            c0780e3 = null;
        }
        int i21 = motionEffect.f15935E;
        if (i21 == -1) {
            int[] iArr = new int[4];
            int i22 = 0;
            i11 = 3;
            i12 = 2;
            while (i22 < viewArrJ.length) {
                q qVar = (q) map2.get(viewArrJ[i22]);
                if (qVar == null) {
                    i18 = i22;
                    i17 = i20;
                } else {
                    i17 = i20;
                    A a3 = qVar.f13904g;
                    float f10 = a3.f13671e;
                    A a9 = qVar.f13903f;
                    i18 = i22;
                    float f11 = f10 - a9.f13671e;
                    float f12 = a3.f13672f - a9.f13672f;
                    if (f12 < 0.0f) {
                        iArr[i17] = iArr[i17] + 1;
                    }
                    if (f12 > 0.0f) {
                        iArr[0] = iArr[0] + 1;
                    }
                    if (f11 > 0.0f) {
                        iArr[3] = iArr[3] + 1;
                    }
                    if (f11 < 0.0f) {
                        iArr[2] = iArr[2] + 1;
                    }
                }
                i22 = i18 + 1;
                i20 = i17;
            }
            i10 = i20;
            int i23 = iArr[0];
            i21 = 0;
            for (int i24 = i10; i24 < 4; i24++) {
                int i25 = iArr[i24];
                if (i23 < i25) {
                    i23 = i25;
                    i21 = i24;
                }
            }
        } else {
            i10 = 1;
            i11 = 3;
            i12 = 2;
        }
        int i26 = 0;
        while (i26 < viewArrJ.length) {
            q qVar2 = (q) map2.get(viewArrJ[i26]);
            if (qVar2 == null) {
                viewArr = viewArrJ;
            } else {
                A a10 = qVar2.f13904g;
                float f13 = a10.f13671e;
                A a11 = qVar2.f13903f;
                viewArr = viewArrJ;
                float f14 = f13 - a11.f13671e;
                float f15 = a10.f13672f - a11.f13672f;
                if (i21 == 0) {
                    if (f15 <= 0.0f || (motionEffect.f15933C && f14 != 0.0f)) {
                        i13 = motionEffect.f15934D;
                        if (i13 == -1) {
                            qVar2.a(c0780e4);
                            qVar2.a(c0780e5);
                            qVar2.a(c0785j);
                            qVar2.a(c0785j2);
                            if (motionEffect.f15931A > 0) {
                                qVar2.a(c0780e);
                                qVar2.a(c0780e2);
                            }
                            if (motionEffect.f15932B > 0) {
                                qVar2.a(c0780e6);
                                qVar2.a(c0780e3);
                            }
                        } else {
                            d10 = motionLayout.f15944A;
                            if (d10 != null) {
                                arrayList = (ArrayList) d10.f13718q.f2612c;
                                size = arrayList.size();
                                i14 = 0;
                                while (true) {
                                    if (i14 < size) {
                                        Object obj = arrayList.get(i14);
                                        i15 = i14 + 1;
                                        i16 = (I) obj;
                                        arrayList2 = arrayList;
                                        if (i16.f13766a == i13) {
                                            arrayList3 = (ArrayList) i16.f13771f.f13825a.get(-1);
                                            if (arrayList3 == null) {
                                                break;
                                            }
                                            qVar2.f13919w.addAll(arrayList3);
                                            break;
                                        }
                                        arrayList = arrayList2;
                                        i14 = i15;
                                    }
                                }
                            }
                        }
                        i26++;
                        map2 = map;
                        viewArrJ = viewArr;
                        i11 = 3;
                        i12 = 2;
                        i10 = 1;
                        motionEffect = this;
                    }
                } else if (i21 == i10) {
                    if (f15 >= 0.0f || (motionEffect.f15933C && f14 != 0.0f)) {
                        i13 = motionEffect.f15934D;
                        if (i13 == -1) {
                            qVar2.a(c0780e4);
                            qVar2.a(c0780e5);
                            qVar2.a(c0785j);
                            qVar2.a(c0785j2);
                            if (motionEffect.f15931A > 0) {
                                qVar2.a(c0780e);
                                qVar2.a(c0780e2);
                            }
                            if (motionEffect.f15932B > 0) {
                                qVar2.a(c0780e6);
                                qVar2.a(c0780e3);
                            }
                        } else {
                            d10 = motionLayout.f15944A;
                            if (d10 != null) {
                                arrayList = (ArrayList) d10.f13718q.f2612c;
                                size = arrayList.size();
                                i14 = 0;
                                while (true) {
                                    if (i14 < size) {
                                        Object obj2 = arrayList.get(i14);
                                        i15 = i14 + 1;
                                        i16 = (I) obj2;
                                        arrayList2 = arrayList;
                                        if (i16.f13766a == i13) {
                                            arrayList3 = (ArrayList) i16.f13771f.f13825a.get(-1);
                                            if (arrayList3 == null) {
                                                qVar2.f13919w.addAll(arrayList3);
                                                break;
                                                break;
                                            } else {
                                                break;
                                                break;
                                            }
                                        }
                                        arrayList = arrayList2;
                                        i14 = i15;
                                    }
                                }
                            }
                        }
                        i26++;
                        map2 = map;
                        viewArrJ = viewArr;
                        i11 = 3;
                        i12 = 2;
                        i10 = 1;
                        motionEffect = this;
                    }
                } else if (i21 != i12) {
                    if (i21 != i11 || f14 <= 0.0f || (motionEffect.f15933C && f15 != 0.0f)) {
                        i13 = motionEffect.f15934D;
                        if (i13 == -1) {
                            qVar2.a(c0780e4);
                            qVar2.a(c0780e5);
                            qVar2.a(c0785j);
                            qVar2.a(c0785j2);
                            if (motionEffect.f15931A > 0) {
                                qVar2.a(c0780e);
                                qVar2.a(c0780e2);
                            }
                            if (motionEffect.f15932B > 0) {
                                qVar2.a(c0780e6);
                                qVar2.a(c0780e3);
                            }
                        } else {
                            d10 = motionLayout.f15944A;
                            if (d10 != null) {
                                arrayList = (ArrayList) d10.f13718q.f2612c;
                                size = arrayList.size();
                                i14 = 0;
                                while (true) {
                                    if (i14 < size) {
                                        Object obj3 = arrayList.get(i14);
                                        i15 = i14 + 1;
                                        i16 = (I) obj3;
                                        arrayList2 = arrayList;
                                        if (i16.f13766a == i13) {
                                            arrayList3 = (ArrayList) i16.f13771f.f13825a.get(-1);
                                            if (arrayList3 == null) {
                                                qVar2.f13919w.addAll(arrayList3);
                                                break;
                                                break;
                                            } else {
                                                break;
                                                break;
                                            }
                                        }
                                        arrayList = arrayList2;
                                        i14 = i15;
                                    }
                                }
                            }
                        }
                    }
                    i26++;
                    map2 = map;
                    viewArrJ = viewArr;
                    i11 = 3;
                    i12 = 2;
                    i10 = 1;
                    motionEffect = this;
                } else if (f14 >= 0.0f || (motionEffect.f15933C && f15 != 0.0f)) {
                    i13 = motionEffect.f15934D;
                    if (i13 == -1) {
                        qVar2.a(c0780e4);
                        qVar2.a(c0780e5);
                        qVar2.a(c0785j);
                        qVar2.a(c0785j2);
                        if (motionEffect.f15931A > 0) {
                            qVar2.a(c0780e);
                            qVar2.a(c0780e2);
                        }
                        if (motionEffect.f15932B > 0) {
                            qVar2.a(c0780e6);
                            qVar2.a(c0780e3);
                        }
                    } else {
                        d10 = motionLayout.f15944A;
                        if (d10 != null) {
                            arrayList = (ArrayList) d10.f13718q.f2612c;
                            size = arrayList.size();
                            i14 = 0;
                            while (true) {
                                if (i14 < size) {
                                    Object obj4 = arrayList.get(i14);
                                    i15 = i14 + 1;
                                    i16 = (I) obj4;
                                    arrayList2 = arrayList;
                                    if (i16.f13766a == i13) {
                                        arrayList3 = (ArrayList) i16.f13771f.f13825a.get(-1);
                                        if (arrayList3 == null) {
                                            qVar2.f13919w.addAll(arrayList3);
                                            break;
                                            break;
                                        } else {
                                            break;
                                            break;
                                        }
                                    }
                                    arrayList = arrayList2;
                                    i14 = i15;
                                }
                            }
                        }
                    }
                    i26++;
                    map2 = map;
                    viewArrJ = viewArr;
                    i11 = 3;
                    i12 = 2;
                    i10 = 1;
                    motionEffect = this;
                }
            }
            i26++;
            map2 = map;
            viewArrJ = viewArr;
            i11 = 3;
            i12 = 2;
            i10 = 1;
            motionEffect = this;
        }
    }
}
