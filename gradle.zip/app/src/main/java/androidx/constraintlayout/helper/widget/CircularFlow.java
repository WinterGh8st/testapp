package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.VirtualLayout;
import java.util.Arrays;
import java.util.HashMap;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class CircularFlow extends VirtualLayout {

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public static int f15883F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public static float f15884G;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f15885A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public String f15886B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public String f15887C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public Float f15888D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public Integer f15889E;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ConstraintLayout f15890v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f15891w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public float[] f15892x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int[] f15893y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f15894z;

    public CircularFlow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private void setAngles(String str) {
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.f15885A = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i10);
            if (iIndexOf == -1) {
                s(str.substring(i10).trim());
                return;
            } else {
                s(str.substring(i10, iIndexOf).trim());
                i10 = iIndexOf + 1;
            }
        }
    }

    private void setRadius(String str) {
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.f15894z = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i10);
            if (iIndexOf == -1) {
                t(str.substring(i10).trim());
                return;
            } else {
                t(str.substring(i10, iIndexOf).trim());
                i10 = iIndexOf + 1;
            }
        }
    }

    public float[] getAngles() {
        return Arrays.copyOf(this.f15892x, this.f15885A);
    }

    public int[] getRadius() {
        return Arrays.copyOf(this.f15893y, this.f15894z);
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 33) {
                    this.f15891w = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                } else if (index == 29) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.f15886B = string;
                    setAngles(string);
                } else if (index == 32) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.f15887C = string2;
                    setRadius(string2);
                } else if (index == 30) {
                    Float fValueOf = Float.valueOf(typedArrayObtainStyledAttributes.getFloat(index, f15884G));
                    this.f15888D = fValueOf;
                    setDefaultAngle(fValueOf.floatValue());
                } else if (index == 31) {
                    Integer numValueOf = Integer.valueOf(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, f15883F));
                    this.f15889E = numValueOf;
                    setDefaultRadius(numValueOf.intValue());
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f15886B;
        if (str != null) {
            this.f15892x = new float[1];
            setAngles(str);
        }
        String str2 = this.f15887C;
        if (str2 != null) {
            this.f15893y = new int[1];
            setRadius(str2);
        }
        Float f10 = this.f15888D;
        if (f10 != null) {
            setDefaultAngle(f10.floatValue());
        }
        Integer num = this.f15889E;
        if (num != null) {
            setDefaultRadius(num.intValue());
        }
        this.f15890v = (ConstraintLayout) getParent();
        for (int i10 = 0; i10 < this.f16109b; i10++) {
            View viewE = this.f15890v.e(this.f16108a[i10]);
            if (viewE != null) {
                int i11 = f15883F;
                float f11 = f15884G;
                int[] iArr = this.f15893y;
                HashMap map = this.f16116s;
                if (iArr == null || i10 >= iArr.length) {
                    Integer num2 = this.f15889E;
                    if (num2 == null || num2.intValue() == -1) {
                        Log.e("CircularFlow", "Added radius to view with id: " + ((String) map.get(Integer.valueOf(viewE.getId()))));
                    } else {
                        this.f15894z++;
                        if (this.f15893y == null) {
                            this.f15893y = new int[1];
                        }
                        int[] radius = getRadius();
                        this.f15893y = radius;
                        radius[this.f15894z - 1] = i11;
                    }
                } else {
                    i11 = iArr[i10];
                }
                float[] fArr = this.f15892x;
                if (fArr == null || i10 >= fArr.length) {
                    Float f12 = this.f15888D;
                    if (f12 == null || f12.floatValue() == -1.0f) {
                        Log.e("CircularFlow", "Added angle to view with id: " + ((String) map.get(Integer.valueOf(viewE.getId()))));
                    } else {
                        this.f15885A++;
                        if (this.f15892x == null) {
                            this.f15892x = new float[1];
                        }
                        float[] angles = getAngles();
                        this.f15892x = angles;
                        angles[this.f15885A - 1] = f11;
                    }
                } else {
                    f11 = fArr[i10];
                }
                ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) viewE.getLayoutParams();
                layoutParams.f16191r = f11;
                layoutParams.f16187p = this.f15891w;
                layoutParams.f16189q = i11;
                viewE.setLayoutParams(layoutParams);
            }
        }
        e();
    }

    public final void s(String str) {
        float[] fArr;
        if (str == null || str.length() == 0 || this.f16110c == null || (fArr = this.f15892x) == null) {
            return;
        }
        if (this.f15885A + 1 > fArr.length) {
            this.f15892x = Arrays.copyOf(fArr, fArr.length + 1);
        }
        this.f15892x[this.f15885A] = Integer.parseInt(str);
        this.f15885A++;
    }

    public void setDefaultAngle(float f10) {
        f15884G = f10;
    }

    public void setDefaultRadius(int i10) {
        f15883F = i10;
    }

    public final void t(String str) {
        Context context;
        int[] iArr;
        if (str == null || str.length() == 0 || (context = this.f16110c) == null || (iArr = this.f15893y) == null) {
            return;
        }
        if (this.f15894z + 1 > iArr.length) {
            this.f15893y = Arrays.copyOf(iArr, iArr.length + 1);
        }
        this.f15893y[this.f15894z] = (int) (Integer.parseInt(str) * context.getResources().getDisplayMetrics().density);
        this.f15894z++;
    }
}
