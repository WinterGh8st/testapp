package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.VirtualLayout;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.HashSet;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Grid extends VirtualLayout {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f15896A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public String f15897B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public String f15898C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public String f15899D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public String f15900E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public float f15901F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public float f15902G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public int f15903H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f15904I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public boolean[][] f15905J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final HashSet f15906K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public int[] f15907L;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public View[] f15908v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public ConstraintLayout f15909w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f15910x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f15911y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f15912z;

    public Grid(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15904I = 0;
        this.f15906K = new HashSet();
    }

    public static int[][] B(String str) {
        String[] strArrSplit = str.split(",");
        int[][] iArr = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, strArrSplit.length, 3);
        for (int i10 = 0; i10 < strArrSplit.length; i10++) {
            String[] strArrSplit2 = strArrSplit[i10].trim().split(":");
            String[] strArrSplit3 = strArrSplit2[1].split("x");
            iArr[i10][0] = Integer.parseInt(strArrSplit2[0]);
            iArr[i10][1] = Integer.parseInt(strArrSplit3[0]);
            iArr[i10][2] = Integer.parseInt(strArrSplit3[1]);
        }
        return iArr;
    }

    public static float[] C(int i10, String str) {
        if (str == null || str.trim().isEmpty()) {
            return null;
        }
        String[] strArrSplit = str.split(",");
        if (strArrSplit.length != i10) {
            return null;
        }
        float[] fArr = new float[i10];
        for (int i11 = 0; i11 < i10; i11++) {
            fArr[i11] = Float.parseFloat(strArrSplit[i11].trim());
        }
        return fArr;
    }

    private int getNextPosition() {
        boolean z3 = false;
        int i10 = 0;
        while (!z3) {
            i10 = this.f15904I;
            if (i10 >= this.f15910x * this.f15912z) {
                return -1;
            }
            int iX = x(i10);
            int iW = w(this.f15904I);
            boolean[] zArr = this.f15905J[iX];
            if (zArr[iW]) {
                zArr[iW] = false;
                z3 = true;
            }
            this.f15904I++;
        }
        return i10;
    }

    public static void s(View view) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        layoutParams.f16140H = -1.0f;
        layoutParams.f16168f = -1;
        layoutParams.f16166e = -1;
        layoutParams.f16170g = -1;
        layoutParams.f16172h = -1;
        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = -1;
        view.setLayoutParams(layoutParams);
    }

    public static void t(View view) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        layoutParams.f16141I = -1.0f;
        layoutParams.f16176j = -1;
        layoutParams.f16174i = -1;
        layoutParams.k = -1;
        layoutParams.f16179l = -1;
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = -1;
        view.setLayoutParams(layoutParams);
    }

    public final View A() {
        View view = new View(getContext());
        view.setId(View.generateViewId());
        view.setVisibility(4);
        this.f15909w.addView(view, new ConstraintLayout.LayoutParams(0, 0));
        return view;
    }

    public final void D() {
        int i10;
        int i11 = this.f15911y;
        if (i11 != 0 && (i10 = this.f15896A) != 0) {
            this.f15910x = i11;
            this.f15912z = i10;
            return;
        }
        int i12 = this.f15896A;
        if (i12 > 0) {
            this.f15912z = i12;
            this.f15910x = ((this.f16109b + i12) - 1) / i12;
        } else if (i11 > 0) {
            this.f15910x = i11;
            this.f15912z = ((this.f16109b + i11) - 1) / i11;
        } else {
            int iSqrt = (int) (Math.sqrt(this.f16109b) + 1.5d);
            this.f15910x = iSqrt;
            this.f15912z = ((this.f16109b + iSqrt) - 1) / iSqrt;
        }
    }

    public String getColumnWeights() {
        return this.f15900E;
    }

    public int getColumns() {
        return this.f15896A;
    }

    public float getHorizontalGaps() {
        return this.f15901F;
    }

    public int getOrientation() {
        return this.f15903H;
    }

    public String getRowWeights() {
        return this.f15899D;
    }

    public int getRows() {
        return this.f15911y;
    }

    public String getSkips() {
        return this.f15898C;
    }

    public String getSpans() {
        return this.f15897B;
    }

    public float getVerticalGaps() {
        return this.f15902G;
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.f16112e = true;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15047i);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 5) {
                    this.f15911y = typedArrayObtainStyledAttributes.getInteger(index, 0);
                } else if (index == 1) {
                    this.f15896A = typedArrayObtainStyledAttributes.getInteger(index, 0);
                } else if (index == 7) {
                    this.f15897B = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 6) {
                    this.f15898C = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 4) {
                    this.f15899D = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 0) {
                    this.f15900E = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 3) {
                    this.f15903H = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 2) {
                    this.f15901F = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                } else if (index == 10) {
                    this.f15902G = typedArrayObtainStyledAttributes.getDimension(index, 0.0f);
                } else if (index == 9) {
                    typedArrayObtainStyledAttributes.getBoolean(index, false);
                } else if (index == 8) {
                    typedArrayObtainStyledAttributes.getBoolean(index, false);
                }
            }
            D();
            y();
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    @Override // androidx.constraintlayout.widget.VirtualLayout, androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f15909w = (ConstraintLayout) getParent();
        v(false);
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    public final void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            Paint paint = new Paint();
            paint.setColor(-65536);
            paint.setStyle(Paint.Style.STROKE);
            int top = getTop();
            int left = getLeft();
            int bottom = getBottom();
            int right = getRight();
            for (View view : this.f15908v) {
                int left2 = view.getLeft() - left;
                int top2 = view.getTop() - top;
                int right2 = view.getRight() - left;
                int bottom2 = view.getBottom() - top;
                canvas.drawRect(left2, 0.0f, right2, bottom - top, paint);
                canvas.drawRect(0.0f, top2, right - left, bottom2, paint);
            }
        }
    }

    public void setColumnWeights(String str) {
        String str2 = this.f15900E;
        if (str2 == null || !str2.equals(str)) {
            this.f15900E = str;
            v(true);
            invalidate();
        }
    }

    public void setColumns(int i10) {
        if (i10 <= 50 && this.f15896A != i10) {
            this.f15896A = i10;
            D();
            y();
            v(false);
            invalidate();
        }
    }

    public void setHorizontalGaps(float f10) {
        if (f10 >= 0.0f && this.f15901F != f10) {
            this.f15901F = f10;
            v(true);
            invalidate();
        }
    }

    public void setOrientation(int i10) {
        if ((i10 == 0 || i10 == 1) && this.f15903H != i10) {
            this.f15903H = i10;
            v(true);
            invalidate();
        }
    }

    public void setRowWeights(String str) {
        String str2 = this.f15899D;
        if (str2 == null || !str2.equals(str)) {
            this.f15899D = str;
            v(true);
            invalidate();
        }
    }

    public void setRows(int i10) {
        if (i10 <= 50 && this.f15911y != i10) {
            this.f15911y = i10;
            D();
            y();
            v(false);
            invalidate();
        }
    }

    public void setSkips(String str) {
        String str2 = this.f15898C;
        if (str2 == null || !str2.equals(str)) {
            this.f15898C = str;
            v(true);
            invalidate();
        }
    }

    public void setSpans(CharSequence charSequence) {
        String str = this.f15897B;
        if (str == null || !str.contentEquals(charSequence)) {
            this.f15897B = charSequence.toString();
            v(true);
            invalidate();
        }
    }

    public void setVerticalGaps(float f10) {
        if (f10 >= 0.0f && this.f15902G != f10) {
            this.f15902G = f10;
            v(true);
            invalidate();
        }
    }

    public final void u(View view, int i10, int i11, int i12, int i13) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        int[] iArr = this.f15907L;
        layoutParams.f16166e = iArr[i11];
        layoutParams.f16174i = iArr[i10];
        layoutParams.f16172h = iArr[(i11 + i13) - 1];
        layoutParams.f16179l = iArr[(i10 + i12) - 1];
        view.setLayoutParams(layoutParams);
    }

    public final void v(boolean z3) {
        int i10;
        int i11;
        int[][] iArrB;
        int[][] iArrB2;
        if (this.f15909w == null || this.f15910x < 1 || this.f15912z < 1) {
            return;
        }
        HashSet hashSet = this.f15906K;
        if (z3) {
            for (int i12 = 0; i12 < this.f15905J.length; i12++) {
                int i13 = 0;
                while (true) {
                    boolean[][] zArr = this.f15905J;
                    if (i13 < zArr[0].length) {
                        zArr[i12][i13] = true;
                        i13++;
                    }
                }
            }
            hashSet.clear();
        }
        this.f15904I = 0;
        int iMax = Math.max(this.f15910x, this.f15912z);
        View[] viewArr = this.f15908v;
        if (viewArr == null) {
            this.f15908v = new View[iMax];
            int i14 = 0;
            while (true) {
                View[] viewArr2 = this.f15908v;
                if (i14 >= viewArr2.length) {
                    break;
                }
                viewArr2[i14] = A();
                i14++;
            }
        } else if (iMax != viewArr.length) {
            View[] viewArr3 = new View[iMax];
            for (int i15 = 0; i15 < iMax; i15++) {
                View[] viewArr4 = this.f15908v;
                if (i15 < viewArr4.length) {
                    viewArr3[i15] = viewArr4[i15];
                } else {
                    viewArr3[i15] = A();
                }
            }
            int i16 = iMax;
            while (true) {
                View[] viewArr5 = this.f15908v;
                if (i16 >= viewArr5.length) {
                    break;
                }
                this.f15909w.removeView(viewArr5[i16]);
                i16++;
            }
            this.f15908v = viewArr3;
        }
        this.f15907L = new int[iMax];
        int i17 = 0;
        while (true) {
            View[] viewArr6 = this.f15908v;
            if (i17 >= viewArr6.length) {
                break;
            }
            this.f15907L[i17] = viewArr6[i17].getId();
            i17++;
        }
        int id = getId();
        int iMax2 = Math.max(this.f15910x, this.f15912z);
        float[] fArrC = C(this.f15910x, this.f15899D);
        if (this.f15910x == 1) {
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) this.f15908v[0].getLayoutParams();
            t(this.f15908v[0]);
            layoutParams.f16174i = id;
            layoutParams.f16179l = id;
            this.f15908v[0].setLayoutParams(layoutParams);
        } else {
            int i18 = 0;
            while (true) {
                i10 = this.f15910x;
                if (i18 >= i10) {
                    break;
                }
                ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) this.f15908v[i18].getLayoutParams();
                t(this.f15908v[i18]);
                if (fArrC != null) {
                    layoutParams2.f16141I = fArrC[i18];
                }
                if (i18 > 0) {
                    layoutParams2.f16176j = this.f15907L[i18 - 1];
                } else {
                    layoutParams2.f16174i = id;
                }
                if (i18 < this.f15910x - 1) {
                    layoutParams2.k = this.f15907L[i18 + 1];
                } else {
                    layoutParams2.f16179l = id;
                }
                if (i18 > 0) {
                    ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin = (int) this.f15901F;
                }
                this.f15908v[i18].setLayoutParams(layoutParams2);
                i18++;
            }
            while (i10 < iMax2) {
                ConstraintLayout.LayoutParams layoutParams3 = (ConstraintLayout.LayoutParams) this.f15908v[i10].getLayoutParams();
                t(this.f15908v[i10]);
                layoutParams3.f16174i = id;
                layoutParams3.f16179l = id;
                this.f15908v[i10].setLayoutParams(layoutParams3);
                i10++;
            }
        }
        int id2 = getId();
        int iMax3 = Math.max(this.f15910x, this.f15912z);
        float[] fArrC2 = C(this.f15912z, this.f15900E);
        ConstraintLayout.LayoutParams layoutParams4 = (ConstraintLayout.LayoutParams) this.f15908v[0].getLayoutParams();
        if (this.f15912z == 1) {
            s(this.f15908v[0]);
            layoutParams4.f16166e = id2;
            layoutParams4.f16172h = id2;
            this.f15908v[0].setLayoutParams(layoutParams4);
        } else {
            int i19 = 0;
            while (true) {
                i11 = this.f15912z;
                if (i19 >= i11) {
                    break;
                }
                ConstraintLayout.LayoutParams layoutParams5 = (ConstraintLayout.LayoutParams) this.f15908v[i19].getLayoutParams();
                s(this.f15908v[i19]);
                if (fArrC2 != null) {
                    layoutParams5.f16140H = fArrC2[i19];
                }
                if (i19 > 0) {
                    layoutParams5.f16168f = this.f15907L[i19 - 1];
                } else {
                    layoutParams5.f16166e = id2;
                }
                if (i19 < this.f15912z - 1) {
                    layoutParams5.f16170g = this.f15907L[i19 + 1];
                } else {
                    layoutParams5.f16172h = id2;
                }
                if (i19 > 0) {
                    ((ViewGroup.MarginLayoutParams) layoutParams5).leftMargin = (int) this.f15901F;
                }
                this.f15908v[i19].setLayoutParams(layoutParams5);
                i19++;
            }
            while (i11 < iMax3) {
                ConstraintLayout.LayoutParams layoutParams6 = (ConstraintLayout.LayoutParams) this.f15908v[i11].getLayoutParams();
                s(this.f15908v[i11]);
                layoutParams6.f16166e = id2;
                layoutParams6.f16172h = id2;
                this.f15908v[i11].setLayoutParams(layoutParams6);
                i11++;
            }
        }
        String str = this.f15898C;
        if (str != null && !str.trim().isEmpty() && (iArrB2 = B(this.f15898C)) != null) {
            for (int i20 = 0; i20 < iArrB2.length; i20++) {
                int iX = x(iArrB2[i20][0]);
                int iW = w(iArrB2[i20][0]);
                int[] iArr = iArrB2[i20];
                if (!z(iX, iW, iArr[1], iArr[2])) {
                    break;
                }
            }
        }
        String str2 = this.f15897B;
        if (str2 != null && !str2.trim().isEmpty() && (iArrB = B(this.f15897B)) != null) {
            int[] iArr2 = this.f16108a;
            View[] viewArrJ = j(this.f15909w);
            for (int i21 = 0; i21 < iArrB.length; i21++) {
                int iX2 = x(iArrB[i21][0]);
                int iW2 = w(iArrB[i21][0]);
                int[] iArr3 = iArrB[i21];
                if (!z(iX2, iW2, iArr3[1], iArr3[2])) {
                    break;
                }
                View view = viewArrJ[i21];
                int[] iArr4 = iArrB[i21];
                u(view, iX2, iW2, iArr4[1], iArr4[2]);
                hashSet.add(Integer.valueOf(iArr2[i21]));
            }
        }
        View[] viewArrJ2 = j(this.f15909w);
        for (int i22 = 0; i22 < this.f16109b; i22++) {
            if (!hashSet.contains(Integer.valueOf(this.f16108a[i22]))) {
                int nextPosition = getNextPosition();
                int iX3 = x(nextPosition);
                int iW3 = w(nextPosition);
                if (nextPosition == -1) {
                    return;
                } else {
                    u(viewArrJ2[i22], iX3, iW3, 1, 1);
                }
            }
        }
    }

    public final int w(int i10) {
        return this.f15903H == 1 ? i10 / this.f15910x : i10 % this.f15912z;
    }

    public final int x(int i10) {
        return this.f15903H == 1 ? i10 % this.f15910x : i10 / this.f15912z;
    }

    public final void y() {
        boolean[][] zArr = (boolean[][]) Array.newInstance((Class<?>) Boolean.TYPE, this.f15910x, this.f15912z);
        this.f15905J = zArr;
        for (boolean[] zArr2 : zArr) {
            Arrays.fill(zArr2, true);
        }
    }

    public final boolean z(int i10, int i11, int i12, int i13) {
        for (int i14 = i10; i14 < i10 + i12; i14++) {
            for (int i15 = i11; i15 < i11 + i13; i15++) {
                boolean[][] zArr = this.f15905J;
                if (i14 < zArr.length && i15 < zArr[0].length) {
                    boolean[] zArr2 = zArr[i14];
                    if (zArr2[i15]) {
                        zArr2[i15] = false;
                    }
                }
                return false;
            }
        }
        return true;
    }
}
