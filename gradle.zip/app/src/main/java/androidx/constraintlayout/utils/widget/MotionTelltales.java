package androidx.constraintlayout.utils.widget;

import T0.b;
import T0.o;
import X0.f;
import Y0.A;
import Y0.q;
import Y0.r;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.ViewParent;
import androidx.constraintlayout.motion.widget.MotionLayout;
import java.util.HashMap;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class MotionTelltales extends MockView {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f16098A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final float f16099B;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Paint f16100v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public MotionLayout f16101w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final float[] f16102x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final Matrix f16103y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f16104z;

    public MotionTelltales(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16100v = new Paint();
        this.f16102x = new float[2];
        this.f16103y = new Matrix();
        this.f16104z = 0;
        this.f16098A = -65281;
        this.f16099B = 0.25f;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15061x);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 0) {
                    this.f16098A = typedArrayObtainStyledAttributes.getColor(index, this.f16098A);
                } else if (index == 2) {
                    this.f16104z = typedArrayObtainStyledAttributes.getInt(index, this.f16104z);
                } else if (index == 1) {
                    this.f16099B = typedArrayObtainStyledAttributes.getFloat(index, this.f16099B);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        int i11 = this.f16098A;
        Paint paint = this.f16100v;
        paint.setColor(i11);
        paint.setStrokeWidth(5.0f);
    }

    @Override // android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override // androidx.constraintlayout.utils.widget.MockView, android.view.View
    public final void onDraw(Canvas canvas) {
        char c10;
        int i10;
        char c11;
        f fVar;
        float f10;
        float f11;
        float[] fArr;
        double[] dArr;
        o oVar;
        MotionTelltales motionTelltales = this;
        int i11 = 5;
        super.onDraw(canvas);
        Matrix matrix = motionTelltales.getMatrix();
        Matrix matrix2 = motionTelltales.f16103y;
        matrix.invert(matrix2);
        if (motionTelltales.f16101w == null) {
            ViewParent parent = motionTelltales.getParent();
            if (parent instanceof MotionLayout) {
                motionTelltales.f16101w = (MotionLayout) parent;
                return;
            }
            return;
        }
        int width = motionTelltales.getWidth();
        int height = motionTelltales.getHeight();
        float[] fArr2 = {0.1f, 0.25f, 0.5f, 0.75f, 0.9f};
        int i12 = 0;
        while (i12 < i11) {
            float f12 = fArr2[i12];
            int i13 = 0;
            while (i13 < i11) {
                float f13 = fArr2[i13];
                MotionLayout motionLayout = motionTelltales.f16101w;
                int i14 = motionTelltales.f16104z;
                float fA = motionLayout.f15950D;
                float interpolation = motionLayout.f15971O;
                if (motionLayout.f15946B != null) {
                    float fSignum = Math.signum(motionLayout.f15973Q - interpolation);
                    float interpolation2 = motionLayout.f15946B.getInterpolation(motionLayout.f15971O + 1.0E-5f);
                    c10 = 1;
                    interpolation = motionLayout.f15946B.getInterpolation(motionLayout.f15971O);
                    fA = (((interpolation2 - interpolation) / 1.0E-5f) * fSignum) / motionLayout.M;
                } else {
                    c10 = 1;
                }
                r rVar = motionLayout.f15946B;
                if (rVar != null) {
                    fA = rVar.a();
                }
                float f14 = fA;
                q qVar = (q) motionLayout.f15964K.get(motionTelltales);
                int i15 = i14 & 1;
                float f15 = f13;
                float f16 = f12;
                float[] fArr3 = motionTelltales.f16102x;
                if (i15 == 0) {
                    int width2 = motionTelltales.getWidth();
                    int height2 = motionTelltales.getHeight();
                    float[] fArr4 = qVar.f13918v;
                    float fB = qVar.b(interpolation, fArr4);
                    c11 = 0;
                    HashMap map = qVar.f13921y;
                    X0.k kVar = map == null ? null : (X0.k) map.get("translationX");
                    HashMap map2 = qVar.f13921y;
                    X0.k kVar2 = map2 == null ? null : (X0.k) map2.get("translationY");
                    HashMap map3 = qVar.f13921y;
                    X0.k kVar3 = map3 == null ? null : (X0.k) map3.get("rotation");
                    HashMap map4 = qVar.f13921y;
                    i10 = i14;
                    X0.k kVar4 = map4 == null ? null : (X0.k) map4.get("scaleX");
                    HashMap map5 = qVar.f13921y;
                    X0.k kVar5 = map5 == null ? null : (X0.k) map5.get("scaleY");
                    HashMap map6 = qVar.f13922z;
                    f fVar2 = map6 == null ? null : (f) map6.get("translationX");
                    HashMap map7 = qVar.f13922z;
                    f fVar3 = map7 == null ? null : (f) map7.get("translationY");
                    HashMap map8 = qVar.f13922z;
                    f fVar4 = map8 == null ? null : (f) map8.get("rotation");
                    HashMap map9 = qVar.f13922z;
                    f fVar5 = map9 == null ? null : (f) map9.get("scaleX");
                    HashMap map10 = qVar.f13922z;
                    f fVar6 = map10 != null ? (f) map10.get("scaleY") : null;
                    o oVar2 = new o();
                    oVar2.f11579e = 0.0f;
                    oVar2.f11578d = 0.0f;
                    oVar2.f11577c = 0.0f;
                    oVar2.f11576b = 0.0f;
                    oVar2.f11575a = 0.0f;
                    if (kVar3 != null) {
                        oVar2.f11579e = (float) kVar3.f13477a.f0(fB);
                        oVar2.f11580f = kVar3.a(fB);
                    }
                    if (kVar != null) {
                        oVar2.f11577c = (float) kVar.f13477a.f0(fB);
                    }
                    if (kVar2 != null) {
                        oVar2.f11578d = (float) kVar2.f13477a.f0(fB);
                    }
                    if (kVar4 != null) {
                        oVar2.f11575a = (float) kVar4.f13477a.f0(fB);
                    }
                    if (kVar5 != null) {
                        oVar2.f11576b = (float) kVar5.f13477a.f0(fB);
                    }
                    if (fVar4 != null) {
                        oVar2.f11579e = fVar4.b(fB);
                    }
                    if (fVar2 != null) {
                        oVar2.f11577c = fVar2.b(fB);
                    }
                    if (fVar3 != 0) {
                        oVar2.f11578d = fVar.b(fB);
                    }
                    if (fVar5 != null) {
                        fVar = fVar3;
                        fVar = fVar3;
                        oVar2.f11575a = fVar5.b(fB);
                    }
                    if (fVar6 != null) {
                        oVar2.f11576b = fVar6.b(fB);
                    }
                    b bVar = qVar.k;
                    if (bVar != null) {
                        double[] dArr2 = qVar.f13912p;
                        if (dArr2.length > 0) {
                            double d10 = fB;
                            bVar.d0(d10, dArr2);
                            qVar.k.g0(d10, qVar.f13913q);
                            int[] iArr = qVar.f13911o;
                            double[] dArr3 = qVar.f13913q;
                            double[] dArr4 = qVar.f13912p;
                            qVar.f13903f.getClass();
                            A.f(f15, f16, fArr3, iArr, dArr3, dArr4);
                            fArr = fArr3;
                            f11 = f16;
                            f10 = f15;
                            oVar = oVar2;
                        } else {
                            oVar = oVar2;
                            f10 = f15;
                            f11 = f16;
                            fArr = fArr3;
                        }
                        oVar.a(f10, f11, width2, height2, fArr);
                    } else {
                        i10 = i10;
                        if (qVar.f13907j != null) {
                            double dB = qVar.b(fB, fArr4);
                            qVar.f13907j[0].g0(dB, qVar.f13913q);
                            qVar.f13907j[0].d0(dB, qVar.f13912p);
                            float f17 = fArr4[0];
                            int i16 = 0;
                            while (true) {
                                dArr = qVar.f13913q;
                                if (i16 >= dArr.length) {
                                    break;
                                }
                                dArr[i16] = dArr[i16] * ((double) f17);
                                i16++;
                            }
                            int[] iArr2 = qVar.f13911o;
                            double[] dArr5 = qVar.f13912p;
                            qVar.f13903f.getClass();
                            A.f(f15, f16, fArr3, iArr2, dArr, dArr5);
                            fArr = fArr3;
                            f11 = f16;
                            f10 = f15;
                            oVar2.a(f10, f11, width2, height2, fArr);
                        } else {
                            A a3 = qVar.f13904g;
                            float f18 = a3.f13671e;
                            A a9 = qVar.f13903f;
                            float f19 = f18 - a9.f13671e;
                            float f20 = a3.f13672f - a9.f13672f;
                            float f21 = a3.f13673q - a9.f13673q;
                            float f22 = f20 + (a3.f13674r - a9.f13674r);
                            fArr3[0] = ((f19 + f21) * f15) + ((1.0f - f15) * f19);
                            fArr3[c10] = (f22 * f16) + ((1.0f - f16) * f20);
                            oVar2.f11579e = 0.0f;
                            oVar2.f11578d = 0.0f;
                            oVar2.f11577c = 0.0f;
                            oVar2.f11576b = 0.0f;
                            oVar2.f11575a = 0.0f;
                            if (kVar3 != null) {
                                oVar2.f11579e = (float) kVar3.f13477a.f0(fB);
                                oVar2.f11580f = kVar3.a(fB);
                            }
                            if (kVar != null) {
                                oVar2.f11577c = (float) kVar.f13477a.f0(fB);
                            }
                            if (kVar2 != null) {
                                oVar2.f11578d = (float) kVar2.f13477a.f0(fB);
                            }
                            if (kVar4 != null) {
                                oVar2.f11575a = (float) kVar4.f13477a.f0(fB);
                            }
                            if (kVar5 != null) {
                                oVar2.f11576b = (float) kVar5.f13477a.f0(fB);
                            }
                            if (fVar4 != null) {
                                oVar2.f11579e = fVar4.b(fB);
                            }
                            if (fVar2 != null) {
                                oVar2.f11577c = fVar2.b(fB);
                            }
                            if (fVar != null) {
                                oVar2.f11578d = fVar.b(fB);
                            }
                            if (fVar5 != null) {
                                oVar2.f11575a = fVar5.b(fB);
                            }
                            if (fVar6 != 0) {
                                oVar2.f11576b = fVar6.b(fB);
                            }
                            f10 = f15;
                            f11 = f16;
                            fArr = fArr3;
                            oVar2.a(f10, f11, width2, height2, fArr);
                        }
                        f15 = f10;
                        f16 = f11;
                        fArr3 = fArr;
                    }
                    i10 = i10;
                    f15 = f10;
                    f16 = f11;
                    fArr3 = fArr;
                } else {
                    i10 = i14;
                    c11 = 0;
                    qVar.d(interpolation, f15, f16, fArr3);
                }
                if (i10 < 2) {
                    fArr3[c11] = fArr3[c11] * f14;
                    fArr3[c10] = fArr3[c10] * f14;
                }
                motionTelltales = this;
                float[] fArr5 = motionTelltales.f16102x;
                Matrix matrix3 = matrix2;
                matrix3.mapVectors(fArr5);
                width = width;
                float f23 = width * f15;
                int i17 = height;
                float f24 = i17 * f16;
                float f25 = fArr5[c11];
                float f26 = motionTelltales.f16099B;
                float f27 = f24 - (fArr5[c10] * f26);
                matrix3.mapVectors(fArr5);
                canvas.drawLine(f23, f24, f23 - (f25 * f26), f27, motionTelltales.f16100v);
                i13++;
                height = i17;
                f12 = f16;
                fArr2 = fArr2;
                i12 = i12;
                i11 = 5;
                matrix2 = matrix3;
            }
            i12++;
            i11 = 5;
            matrix2 = matrix2;
        }
    }

    @Override // android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        postInvalidate();
    }

    public void setText(CharSequence charSequence) {
        this.f16042f = charSequence.toString();
        requestLayout();
    }
}
