package androidx.constraintlayout.utils.widget;

import Z0.b;
import Z0.c;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class ImageFilterView extends AppCompatImageView {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public float f16021A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public float f16022B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public float f16023C;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c f16024d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16025e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f16026f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Drawable f16027q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public float f16028r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public float f16029s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float f16030t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Path f16031u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public ViewOutlineProvider f16032v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public RectF f16033w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Drawable[] f16034x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public LayerDrawable f16035y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f16036z;

    public ImageFilterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16024d = new c();
        this.f16025e = true;
        this.f16026f = null;
        this.f16027q = null;
        this.f16028r = 0.0f;
        this.f16029s = 0.0f;
        this.f16030t = Float.NaN;
        this.f16034x = new Drawable[2];
        this.f16036z = Float.NaN;
        this.f16021A = Float.NaN;
        this.f16022B = Float.NaN;
        this.f16023C = Float.NaN;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15048j);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            this.f16026f = typedArrayObtainStyledAttributes.getDrawable(0);
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 4) {
                    this.f16028r = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 13) {
                    setWarmth(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 12) {
                    setSaturation(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 3) {
                    setContrast(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 2) {
                    setBrightness(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 10) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 9) {
                    setOverlay(typedArrayObtainStyledAttributes.getBoolean(index, this.f16025e));
                } else if (index == 5) {
                    setImagePanX(typedArrayObtainStyledAttributes.getFloat(index, this.f16036z));
                } else if (index == 6) {
                    setImagePanY(typedArrayObtainStyledAttributes.getFloat(index, this.f16021A));
                } else if (index == 7) {
                    setImageRotate(typedArrayObtainStyledAttributes.getFloat(index, this.f16023C));
                } else if (index == 8) {
                    setImageZoom(typedArrayObtainStyledAttributes.getFloat(index, this.f16022B));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            Drawable drawable = getDrawable();
            this.f16027q = drawable;
            Drawable drawable2 = this.f16026f;
            Drawable[] drawableArr = this.f16034x;
            if (drawable2 == null || drawable == null) {
                Drawable drawable3 = getDrawable();
                this.f16027q = drawable3;
                if (drawable3 != null) {
                    Drawable drawableMutate = drawable3.mutate();
                    this.f16027q = drawableMutate;
                    drawableArr[0] = drawableMutate;
                    return;
                }
                return;
            }
            Drawable drawableMutate2 = getDrawable().mutate();
            this.f16027q = drawableMutate2;
            drawableArr[0] = drawableMutate2;
            drawableArr[1] = this.f16026f.mutate();
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f16035y = layerDrawable;
            layerDrawable.getDrawable(1).setAlpha((int) (this.f16028r * 255.0f));
            if (!this.f16025e) {
                this.f16035y.getDrawable(0).setAlpha((int) ((1.0f - this.f16028r) * 255.0f));
            }
            super.setImageDrawable(this.f16035y);
        }
    }

    private void setOverlay(boolean z3) {
        this.f16025e = z3;
    }

    public final void a() {
        if (Float.isNaN(this.f16036z) && Float.isNaN(this.f16021A) && Float.isNaN(this.f16022B) && Float.isNaN(this.f16023C)) {
            return;
        }
        float f10 = Float.isNaN(this.f16036z) ? 0.0f : this.f16036z;
        float f11 = Float.isNaN(this.f16021A) ? 0.0f : this.f16021A;
        float f12 = Float.isNaN(this.f16022B) ? 1.0f : this.f16022B;
        float f13 = Float.isNaN(this.f16023C) ? 0.0f : this.f16023C;
        Matrix matrix = new Matrix();
        matrix.reset();
        float intrinsicWidth = getDrawable().getIntrinsicWidth();
        float intrinsicHeight = getDrawable().getIntrinsicHeight();
        float width = getWidth();
        float height = getHeight();
        float f14 = f12 * (intrinsicWidth * height < intrinsicHeight * width ? width / intrinsicWidth : height / intrinsicHeight);
        matrix.postScale(f14, f14);
        float f15 = intrinsicWidth * f14;
        float f16 = f14 * intrinsicHeight;
        matrix.postTranslate(((((width - f15) * f10) + width) - f15) * 0.5f, ((((height - f16) * f11) + height) - f16) * 0.5f);
        matrix.postRotate(f13, width / 2.0f, height / 2.0f);
        setImageMatrix(matrix);
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    public final void d() {
        if (Float.isNaN(this.f16036z) && Float.isNaN(this.f16021A) && Float.isNaN(this.f16022B) && Float.isNaN(this.f16023C)) {
            setScaleType(ImageView.ScaleType.FIT_CENTER);
        } else {
            a();
        }
    }

    public float getBrightness() {
        return this.f16024d.f14434d;
    }

    public float getContrast() {
        return this.f16024d.f14436f;
    }

    public float getCrossfade() {
        return this.f16028r;
    }

    public float getImagePanX() {
        return this.f16036z;
    }

    public float getImagePanY() {
        return this.f16021A;
    }

    public float getImageRotate() {
        return this.f16023C;
    }

    public float getImageZoom() {
        return this.f16022B;
    }

    public float getRound() {
        return this.f16030t;
    }

    public float getRoundPercent() {
        return this.f16029s;
    }

    public float getSaturation() {
        return this.f16024d.f14435e;
    }

    public float getWarmth() {
        return this.f16024d.f14437g;
    }

    @Override // android.view.View
    public final void layout(int i10, int i11, int i12, int i13) {
        super.layout(i10, i11, i12, i13);
        a();
    }

    public void setAltImageDrawable(Drawable drawable) {
        Drawable drawableMutate = drawable.mutate();
        this.f16026f = drawableMutate;
        Drawable drawable2 = this.f16027q;
        Drawable[] drawableArr = this.f16034x;
        drawableArr[0] = drawable2;
        drawableArr[1] = drawableMutate;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16035y = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16028r);
    }

    public void setAltImageResource(int i10) {
        Drawable drawableN = p143m0.c.N(getContext(), i10);
        this.f16026f = drawableN;
        setAltImageDrawable(drawableN);
    }

    public void setBrightness(float f10) {
        c cVar = this.f16024d;
        cVar.f14434d = f10;
        cVar.a(this);
    }

    public void setContrast(float f10) {
        c cVar = this.f16024d;
        cVar.f14436f = f10;
        cVar.a(this);
    }

    public void setCrossfade(float f10) {
        this.f16028r = f10;
        if (this.f16034x != null) {
            if (!this.f16025e) {
                this.f16035y.getDrawable(0).setAlpha((int) ((1.0f - this.f16028r) * 255.0f));
            }
            this.f16035y.getDrawable(1).setAlpha((int) (this.f16028r * 255.0f));
            super.setImageDrawable(this.f16035y);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatImageView, android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        if (this.f16026f == null || drawable == null) {
            super.setImageDrawable(drawable);
            return;
        }
        Drawable drawableMutate = drawable.mutate();
        this.f16027q = drawableMutate;
        Drawable[] drawableArr = this.f16034x;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.f16026f;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16035y = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16028r);
    }

    public void setImagePanX(float f10) {
        this.f16036z = f10;
        d();
    }

    public void setImagePanY(float f10) {
        this.f16021A = f10;
        d();
    }

    @Override // androidx.appcompat.widget.AppCompatImageView, android.widget.ImageView
    public void setImageResource(int i10) {
        if (this.f16026f == null) {
            super.setImageResource(i10);
            return;
        }
        Drawable drawableMutate = p143m0.c.N(getContext(), i10).mutate();
        this.f16027q = drawableMutate;
        Drawable[] drawableArr = this.f16034x;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.f16026f;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16035y = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16028r);
    }

    public void setImageRotate(float f10) {
        this.f16023C = f10;
        d();
    }

    public void setImageZoom(float f10) {
        this.f16022B = f10;
        d();
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f16030t = f10;
            float f11 = this.f16029s;
            this.f16029s = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z3 = this.f16030t != f10;
        this.f16030t = f10;
        if (f10 != 0.0f) {
            if (this.f16031u == null) {
                this.f16031u = new Path();
            }
            if (this.f16033w == null) {
                this.f16033w = new RectF();
            }
            if (this.f16032v == null) {
                b bVar = new b(this, 1);
                this.f16032v = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            this.f16033w.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f16031u.reset();
            Path path = this.f16031u;
            RectF rectF = this.f16033w;
            float f12 = this.f16030t;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z3 = this.f16029s != f10;
        this.f16029s = f10;
        if (f10 != 0.0f) {
            if (this.f16031u == null) {
                this.f16031u = new Path();
            }
            if (this.f16033w == null) {
                this.f16033w = new RectF();
            }
            if (this.f16032v == null) {
                b bVar = new b(this, 0);
                this.f16032v = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f16029s) / 2.0f;
            this.f16033w.set(0.0f, 0.0f, width, height);
            this.f16031u.reset();
            this.f16031u.addRoundRect(this.f16033w, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        c cVar = this.f16024d;
        cVar.f14435e = f10;
        cVar.a(this);
    }

    public void setWarmth(float f10) {
        c cVar = this.f16024d;
        cVar.f14437g = f10;
        cVar.a(this);
    }
}
