package androidx.constraintlayout.utils.widget;

import Z0.a;
import Z0.c;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageButton;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class ImageFilterButton extends AppCompatImageButton {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public float f16005A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public float f16006B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public float f16007C;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final c f16008d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f16009e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f16010f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f16011q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public Path f16012r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ViewOutlineProvider f16013s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public RectF f16014t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final Drawable[] f16015u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public LayerDrawable f16016v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f16017w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public Drawable f16018x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public Drawable f16019y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public float f16020z;

    public ImageFilterButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16008d = new c();
        this.f16009e = 0.0f;
        this.f16010f = 0.0f;
        this.f16011q = Float.NaN;
        this.f16015u = new Drawable[2];
        this.f16017w = true;
        this.f16018x = null;
        this.f16019y = null;
        this.f16020z = Float.NaN;
        this.f16005A = Float.NaN;
        this.f16006B = Float.NaN;
        this.f16007C = Float.NaN;
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15048j);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            this.f16018x = typedArrayObtainStyledAttributes.getDrawable(0);
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 4) {
                    this.f16009e = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == 13) {
                    setWarmth(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 12) {
                    setSaturation(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 3) {
                    setContrast(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 10) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == 9) {
                    setOverlay(typedArrayObtainStyledAttributes.getBoolean(index, this.f16017w));
                } else if (index == 5) {
                    setImagePanX(typedArrayObtainStyledAttributes.getFloat(index, this.f16020z));
                } else if (index == 6) {
                    setImagePanY(typedArrayObtainStyledAttributes.getFloat(index, this.f16005A));
                } else if (index == 7) {
                    setImageRotate(typedArrayObtainStyledAttributes.getFloat(index, this.f16007C));
                } else if (index == 8) {
                    setImageZoom(typedArrayObtainStyledAttributes.getFloat(index, this.f16006B));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            Drawable drawable = getDrawable();
            this.f16019y = drawable;
            Drawable drawable2 = this.f16018x;
            Drawable[] drawableArr = this.f16015u;
            if (drawable2 == null || drawable == null) {
                Drawable drawable3 = getDrawable();
                this.f16019y = drawable3;
                if (drawable3 != null) {
                    Drawable drawableMutate = drawable3.mutate();
                    this.f16019y = drawableMutate;
                    drawableArr[0] = drawableMutate;
                    return;
                }
                return;
            }
            Drawable drawableMutate2 = getDrawable().mutate();
            this.f16019y = drawableMutate2;
            drawableArr[0] = drawableMutate2;
            drawableArr[1] = this.f16018x.mutate();
            LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
            this.f16016v = layerDrawable;
            layerDrawable.getDrawable(1).setAlpha((int) (this.f16009e * 255.0f));
            if (!this.f16017w) {
                this.f16016v.getDrawable(0).setAlpha((int) ((1.0f - this.f16009e) * 255.0f));
            }
            super.setImageDrawable(this.f16016v);
        }
    }

    private void setOverlay(boolean z3) {
        this.f16017w = z3;
    }

    public final void a() {
        if (Float.isNaN(this.f16020z) && Float.isNaN(this.f16005A) && Float.isNaN(this.f16006B) && Float.isNaN(this.f16007C)) {
            return;
        }
        float f10 = Float.isNaN(this.f16020z) ? 0.0f : this.f16020z;
        float f11 = Float.isNaN(this.f16005A) ? 0.0f : this.f16005A;
        float f12 = Float.isNaN(this.f16006B) ? 1.0f : this.f16006B;
        float f13 = Float.isNaN(this.f16007C) ? 0.0f : this.f16007C;
        Matrix matrix = new Matrix();
        matrix.reset();
        float intrinsicWidth = getDrawable().getIntrinsicWidth();
        float intrinsicHeight = getDrawable().getIntrinsicHeight();
        float width = getWidth();
        float height = getHeight();
        float f14 = f12 * (intrinsicWidth * height < intrinsicHeight * width ? width / intrinsicWidth : height / intrinsicHeight);
        matrix.postScale(f14, f14);
        float f15 = intrinsicWidth * f14;
        float f16 = f14 * intrinsicHeight;
        matrix.postTranslate(((((width - f15) * f10) + width) - f15) * 0.5f, ((((height - f16) * f11) + height) - f16) * 0.5f);
        matrix.postRotate(f13, width / 2.0f, height / 2.0f);
        setImageMatrix(matrix);
        setScaleType(ImageView.ScaleType.MATRIX);
    }

    public final void b() {
        if (Float.isNaN(this.f16020z) && Float.isNaN(this.f16005A) && Float.isNaN(this.f16006B) && Float.isNaN(this.f16007C)) {
            setScaleType(ImageView.ScaleType.FIT_CENTER);
        } else {
            a();
        }
    }

    public float getContrast() {
        return this.f16008d.f14436f;
    }

    public float getCrossfade() {
        return this.f16009e;
    }

    public float getImagePanX() {
        return this.f16020z;
    }

    public float getImagePanY() {
        return this.f16005A;
    }

    public float getImageRotate() {
        return this.f16007C;
    }

    public float getImageZoom() {
        return this.f16006B;
    }

    public float getRound() {
        return this.f16011q;
    }

    public float getRoundPercent() {
        return this.f16010f;
    }

    public float getSaturation() {
        return this.f16008d.f14435e;
    }

    public float getWarmth() {
        return this.f16008d.f14437g;
    }

    @Override // android.view.View
    public final void layout(int i10, int i11, int i12, int i13) {
        super.layout(i10, i11, i12, i13);
        a();
    }

    public void setAltImageResource(int i10) {
        Drawable drawableMutate = p143m0.c.N(getContext(), i10).mutate();
        this.f16018x = drawableMutate;
        Drawable drawable = this.f16019y;
        Drawable[] drawableArr = this.f16015u;
        drawableArr[0] = drawable;
        drawableArr[1] = drawableMutate;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16016v = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16009e);
    }

    public void setBrightness(float f10) {
        c cVar = this.f16008d;
        cVar.f14434d = f10;
        cVar.a(this);
    }

    public void setContrast(float f10) {
        c cVar = this.f16008d;
        cVar.f14436f = f10;
        cVar.a(this);
    }

    public void setCrossfade(float f10) {
        this.f16009e = f10;
        if (this.f16015u != null) {
            if (!this.f16017w) {
                this.f16016v.getDrawable(0).setAlpha((int) ((1.0f - this.f16009e) * 255.0f));
            }
            this.f16016v.getDrawable(1).setAlpha((int) (this.f16009e * 255.0f));
            super.setImageDrawable(this.f16016v);
        }
    }

    @Override // androidx.appcompat.widget.AppCompatImageButton, android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        if (this.f16018x == null || drawable == null) {
            super.setImageDrawable(drawable);
            return;
        }
        Drawable drawableMutate = drawable.mutate();
        this.f16019y = drawableMutate;
        Drawable[] drawableArr = this.f16015u;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.f16018x;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16016v = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16009e);
    }

    public void setImagePanX(float f10) {
        this.f16020z = f10;
        b();
    }

    public void setImagePanY(float f10) {
        this.f16005A = f10;
        b();
    }

    @Override // androidx.appcompat.widget.AppCompatImageButton, android.widget.ImageView
    public void setImageResource(int i10) {
        if (this.f16018x == null) {
            super.setImageResource(i10);
            return;
        }
        Drawable drawableMutate = p143m0.c.N(getContext(), i10).mutate();
        this.f16019y = drawableMutate;
        Drawable[] drawableArr = this.f16015u;
        drawableArr[0] = drawableMutate;
        drawableArr[1] = this.f16018x;
        LayerDrawable layerDrawable = new LayerDrawable(drawableArr);
        this.f16016v = layerDrawable;
        super.setImageDrawable(layerDrawable);
        setCrossfade(this.f16009e);
    }

    public void setImageRotate(float f10) {
        this.f16007C = f10;
        b();
    }

    public void setImageZoom(float f10) {
        this.f16006B = f10;
        b();
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f16011q = f10;
            float f11 = this.f16010f;
            this.f16010f = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z3 = this.f16011q != f10;
        this.f16011q = f10;
        if (f10 != 0.0f) {
            if (this.f16012r == null) {
                this.f16012r = new Path();
            }
            if (this.f16014t == null) {
                this.f16014t = new RectF();
            }
            if (this.f16013s == null) {
                a aVar = new a(this, 1);
                this.f16013s = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            this.f16014t.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f16012r.reset();
            Path path = this.f16012r;
            RectF rectF = this.f16014t;
            float f12 = this.f16011q;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z3 = this.f16010f != f10;
        this.f16010f = f10;
        if (f10 != 0.0f) {
            if (this.f16012r == null) {
                this.f16012r = new Path();
            }
            if (this.f16014t == null) {
                this.f16014t = new RectF();
            }
            if (this.f16013s == null) {
                a aVar = new a(this, 0);
                this.f16013s = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f16010f) / 2.0f;
            this.f16014t.set(0.0f, 0.0f, width, height);
            this.f16012r.reset();
            this.f16012r.addRoundRect(this.f16014t, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        c cVar = this.f16008d;
        cVar.f14435e = f10;
        cVar.a(this);
    }

    public void setWarmth(float f10) {
        c cVar = this.f16008d;
        cVar.f14437g = f10;
        cVar.a(this);
    }
}
