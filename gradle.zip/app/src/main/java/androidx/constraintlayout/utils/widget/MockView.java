package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class MockView extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Paint f16037a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Paint f16038b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Paint f16039c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f16040d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f16041e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public String f16042f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Rect f16043q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f16044r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f16045s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final int f16046t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f16047u;

    public MockView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16037a = new Paint();
        this.f16038b = new Paint();
        this.f16039c = new Paint();
        this.f16040d = true;
        this.f16041e = true;
        this.f16042f = null;
        this.f16043q = new Rect();
        this.f16044r = Color.argb(255, 0, 0, 0);
        this.f16045s = Color.argb(255, 200, 200, 200);
        this.f16046t = Color.argb(255, 50, 50, 50);
        this.f16047u = 4;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15054q);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 1) {
                    this.f16042f = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 4) {
                    this.f16040d = typedArrayObtainStyledAttributes.getBoolean(index, this.f16040d);
                } else if (index == 0) {
                    this.f16044r = typedArrayObtainStyledAttributes.getColor(index, this.f16044r);
                } else if (index == 2) {
                    this.f16046t = typedArrayObtainStyledAttributes.getColor(index, this.f16046t);
                } else if (index == 3) {
                    this.f16045s = typedArrayObtainStyledAttributes.getColor(index, this.f16045s);
                } else if (index == 5) {
                    this.f16041e = typedArrayObtainStyledAttributes.getBoolean(index, this.f16041e);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (this.f16042f == null) {
            try {
                this.f16042f = context.getResources().getResourceEntryName(getId());
            } catch (Exception unused) {
            }
        }
        int i11 = this.f16044r;
        Paint paint = this.f16037a;
        paint.setColor(i11);
        paint.setAntiAlias(true);
        int i12 = this.f16045s;
        Paint paint2 = this.f16038b;
        paint2.setColor(i12);
        paint2.setAntiAlias(true);
        this.f16039c.setColor(this.f16046t);
        this.f16047u = Math.round((getResources().getDisplayMetrics().xdpi / 160.0f) * this.f16047u);
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        Canvas canvas2;
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f16040d) {
            width--;
            height--;
            float f10 = width;
            float f11 = height;
            Paint paint = this.f16037a;
            canvas2 = canvas;
            canvas2.drawLine(0.0f, 0.0f, f10, f11, paint);
            canvas2.drawLine(0.0f, f11, f10, 0.0f, paint);
            canvas2.drawLine(0.0f, 0.0f, f10, 0.0f, paint);
            canvas2.drawLine(f10, 0.0f, f10, f11, paint);
            canvas2.drawLine(f10, f11, 0.0f, f11, paint);
            canvas2.drawLine(0.0f, f11, 0.0f, 0.0f, paint);
        } else {
            canvas2 = canvas;
        }
        String str = this.f16042f;
        if (str == null || !this.f16041e) {
            return;
        }
        Paint paint2 = this.f16038b;
        int length = str.length();
        Rect rect = this.f16043q;
        paint2.getTextBounds(str, 0, length, rect);
        float fWidth = (width - rect.width()) / 2.0f;
        float fHeight = ((height - rect.height()) / 2.0f) + rect.height();
        rect.offset((int) fWidth, (int) fHeight);
        int i10 = rect.left;
        int i11 = this.f16047u;
        rect.set(i10 - i11, rect.top - i11, rect.right + i11, rect.bottom + i11);
        canvas2.drawRect(rect, this.f16039c);
        canvas2.drawText(this.f16042f, fWidth, fHeight, paint2);
    }
}
