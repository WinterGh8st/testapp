package androidx.constraintlayout.utils.widget;

import Z0.d;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Path;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.ViewOutlineProvider;
import androidx.appcompat.widget.AppCompatButton;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class MotionButton extends AppCompatButton {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public float f16048d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public float f16049e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Path f16050f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ViewOutlineProvider f16051q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public RectF f16052r;

    public MotionButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16048d = 0.0f;
        this.f16049e = Float.NaN;
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15048j);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 10) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == 11) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public float getRound() {
        return this.f16049e;
    }

    public float getRoundPercent() {
        return this.f16048d;
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f16049e = f10;
            float f11 = this.f16048d;
            this.f16048d = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z3 = this.f16049e != f10;
        this.f16049e = f10;
        if (f10 != 0.0f) {
            if (this.f16050f == null) {
                this.f16050f = new Path();
            }
            if (this.f16052r == null) {
                this.f16052r = new RectF();
            }
            if (this.f16051q == null) {
                d dVar = new d(this, 1);
                this.f16051q = dVar;
                setOutlineProvider(dVar);
            }
            setClipToOutline(true);
            this.f16052r.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f16050f.reset();
            Path path = this.f16050f;
            RectF rectF = this.f16052r;
            float f12 = this.f16049e;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z3 = this.f16048d != f10;
        this.f16048d = f10;
        if (f10 != 0.0f) {
            if (this.f16050f == null) {
                this.f16050f = new Path();
            }
            if (this.f16052r == null) {
                this.f16052r = new RectF();
            }
            if (this.f16051q == null) {
                d dVar = new d(this, 0);
                this.f16051q = dVar;
                setOutlineProvider(dVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f16048d) / 2.0f;
            this.f16052r.set(0.0f, 0.0f, width, height);
            this.f16050f.reset();
            this.f16050f.addRoundRect(this.f16052r, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }
}
