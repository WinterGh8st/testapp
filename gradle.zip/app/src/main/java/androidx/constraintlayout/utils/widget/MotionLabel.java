package androidx.constraintlayout.utils.widget;

import Y0.InterfaceC0777b;
import Z0.e;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewOutlineProvider;
import com.flamingotools.ws.R;
import java.util.Objects;
import p005a1.k;
import p123ja.a;

/* JADX INFO: loaded from: classes.dex */
public class MotionLabel extends View implements InterfaceC0777b {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final Rect f16053A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f16054B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public int f16055C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public int f16056D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f16057E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final String f16058F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public int f16059G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final int f16060H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f16061I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public float f16062J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public float f16063K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public float f16064L;
    public final Drawable M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public Matrix f16065N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public final Bitmap f16066O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public final BitmapShader f16067P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public final Matrix f16068Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public float f16069R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public float f16070S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public float f16071T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public float f16072U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public final Paint f16073V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public final int f16074W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final TextPaint f16075a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public Rect f16076a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public Path f16077b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public Paint f16078b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16079c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public float f16080c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16081d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public float f16082d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16083e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public float f16084e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f16085f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public float f16086f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public float f16087g0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f16088q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ViewOutlineProvider f16089r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public RectF f16090s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float f16091t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public float f16092u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final int f16093v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f16094w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public float f16095x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public String f16096y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public boolean f16097z;

    public MotionLabel(Context context, AttributeSet attributeSet) {
        Typeface typefaceCreate;
        super(context, attributeSet);
        this.f16075a = new TextPaint();
        this.f16077b = new Path();
        this.f16079c = 65535;
        this.f16081d = 65535;
        this.f16083e = false;
        this.f16085f = 0.0f;
        this.f16088q = Float.NaN;
        this.f16091t = 48.0f;
        this.f16092u = Float.NaN;
        this.f16095x = 0.0f;
        this.f16096y = "Hello World";
        this.f16097z = true;
        this.f16053A = new Rect();
        this.f16054B = 1;
        this.f16055C = 1;
        this.f16056D = 1;
        this.f16057E = 1;
        this.f16059G = 8388659;
        this.f16060H = 0;
        this.f16061I = false;
        this.f16069R = Float.NaN;
        this.f16070S = Float.NaN;
        this.f16071T = 0.0f;
        this.f16072U = 0.0f;
        this.f16073V = new Paint();
        this.f16074W = 0;
        this.f16082d0 = Float.NaN;
        this.f16084e0 = Float.NaN;
        this.f16086f0 = Float.NaN;
        this.f16087g0 = Float.NaN;
        setUpTheme(context);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15058u);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 5) {
                    setText(typedArrayObtainStyledAttributes.getText(index));
                } else if (index == 7) {
                    this.f16058F = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == 11) {
                    this.f16092u = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, (int) this.f16092u);
                } else if (index == 0) {
                    this.f16091t = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, (int) this.f16091t);
                } else if (index == 2) {
                    this.f16093v = typedArrayObtainStyledAttributes.getInt(index, this.f16093v);
                } else if (index == 1) {
                    this.f16094w = typedArrayObtainStyledAttributes.getInt(index, this.f16094w);
                } else if (index == 3) {
                    this.f16079c = typedArrayObtainStyledAttributes.getColor(index, this.f16079c);
                } else if (index == 9) {
                    float dimension = typedArrayObtainStyledAttributes.getDimension(index, this.f16088q);
                    this.f16088q = dimension;
                    setRound(dimension);
                } else if (index == 10) {
                    float f10 = typedArrayObtainStyledAttributes.getFloat(index, this.f16085f);
                    this.f16085f = f10;
                    setRoundPercent(f10);
                } else if (index == 4) {
                    setGravity(typedArrayObtainStyledAttributes.getInt(index, -1));
                } else if (index == 8) {
                    this.f16060H = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 17) {
                    this.f16081d = typedArrayObtainStyledAttributes.getInt(index, this.f16081d);
                    this.f16083e = true;
                } else if (index == 18) {
                    this.f16095x = typedArrayObtainStyledAttributes.getDimension(index, this.f16095x);
                    this.f16083e = true;
                } else if (index == 12) {
                    this.M = typedArrayObtainStyledAttributes.getDrawable(index);
                    this.f16083e = true;
                } else if (index == 13) {
                    this.f16082d0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16082d0);
                } else if (index == 14) {
                    this.f16084e0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16084e0);
                } else if (index == 19) {
                    this.f16071T = typedArrayObtainStyledAttributes.getFloat(index, this.f16071T);
                } else if (index == 20) {
                    this.f16072U = typedArrayObtainStyledAttributes.getFloat(index, this.f16072U);
                } else if (index == 15) {
                    this.f16087g0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16087g0);
                } else if (index == 16) {
                    this.f16086f0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16086f0);
                } else if (index == 23) {
                    this.f16069R = typedArrayObtainStyledAttributes.getDimension(index, this.f16069R);
                } else if (index == 24) {
                    this.f16070S = typedArrayObtainStyledAttributes.getDimension(index, this.f16070S);
                } else if (index == 22) {
                    this.f16074W = typedArrayObtainStyledAttributes.getInt(index, this.f16074W);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (this.M != null) {
            this.f16068Q = new Matrix();
            int intrinsicWidth = this.M.getIntrinsicWidth();
            int intrinsicHeight = this.M.getIntrinsicHeight();
            if (intrinsicWidth <= 0 && (intrinsicWidth = getWidth()) == 0) {
                intrinsicWidth = Float.isNaN(this.f16070S) ? 128 : (int) this.f16070S;
            }
            if (intrinsicHeight <= 0 && (intrinsicHeight = getHeight()) == 0) {
                intrinsicHeight = Float.isNaN(this.f16069R) ? 128 : (int) this.f16069R;
            }
            if (this.f16074W != 0) {
                intrinsicWidth /= 2;
                intrinsicHeight /= 2;
            }
            this.f16066O = Bitmap.createBitmap(intrinsicWidth, intrinsicHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(this.f16066O);
            this.M.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
            this.M.setFilterBitmap(true);
            this.M.draw(canvas);
            if (this.f16074W != 0) {
                Bitmap bitmap = this.f16066O;
                int width = bitmap.getWidth() / 2;
                int height = bitmap.getHeight() / 2;
                Bitmap bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmap, width, height, true);
                for (int i11 = 0; i11 < 4 && width >= 32 && height >= 32; i11++) {
                    width /= 2;
                    height /= 2;
                    bitmapCreateScaledBitmap = Bitmap.createScaledBitmap(bitmapCreateScaledBitmap, width, height, true);
                }
                this.f16066O = bitmapCreateScaledBitmap;
            }
            Bitmap bitmap2 = this.f16066O;
            Shader.TileMode tileMode = Shader.TileMode.REPEAT;
            this.f16067P = new BitmapShader(bitmap2, tileMode, tileMode);
        }
        this.f16054B = getPaddingLeft();
        this.f16055C = getPaddingRight();
        this.f16056D = getPaddingTop();
        this.f16057E = getPaddingBottom();
        String str = this.f16058F;
        int i12 = this.f16094w;
        int i13 = this.f16093v;
        TextPaint textPaint = this.f16075a;
        if (str != null) {
            typefaceCreate = Typeface.create(str, i13);
            if (typefaceCreate != null) {
                setTypeface(typefaceCreate);
            }
            textPaint.setColor(this.f16079c);
            textPaint.setStrokeWidth(this.f16095x);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            textPaint.setFlags(128);
            setTextSize(this.f16091t);
            textPaint.setAntiAlias(true);
        }
        typefaceCreate = null;
        if (i12 == 1) {
            typefaceCreate = Typeface.SANS_SERIF;
        } else if (i12 == 2) {
            typefaceCreate = Typeface.SERIF;
        } else if (i12 == 3) {
            typefaceCreate = Typeface.MONOSPACE;
        }
        if (i13 > 0) {
            Typeface typefaceDefaultFromStyle = typefaceCreate == null ? Typeface.defaultFromStyle(i13) : Typeface.create(typefaceCreate, i13);
            setTypeface(typefaceDefaultFromStyle);
            int i14 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i13;
            textPaint.setFakeBoldText((i14 & 1) != 0);
            textPaint.setTextSkewX((2 & i14) != 0 ? -0.25f : 0.0f);
        } else {
            textPaint.setFakeBoldText(false);
            textPaint.setTextSkewX(0.0f);
            setTypeface(typefaceCreate);
        }
        textPaint.setColor(this.f16079c);
        textPaint.setStrokeWidth(this.f16095x);
        textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
        textPaint.setFlags(128);
        setTextSize(this.f16091t);
        textPaint.setAntiAlias(true);
    }

    private float getHorizontalOffset() {
        float f10 = Float.isNaN(this.f16092u) ? 1.0f : this.f16091t / this.f16092u;
        TextPaint textPaint = this.f16075a;
        String str = this.f16096y;
        return ((this.f16071T + 1.0f) * ((((Float.isNaN(this.f16063K) ? getMeasuredWidth() : this.f16063K) - getPaddingLeft()) - getPaddingRight()) - (textPaint.measureText(str, 0, str.length()) * f10))) / 2.0f;
    }

    private float getVerticalOffset() {
        float f10 = Float.isNaN(this.f16092u) ? 1.0f : this.f16091t / this.f16092u;
        Paint.FontMetrics fontMetrics = this.f16075a.getFontMetrics();
        float measuredHeight = ((Float.isNaN(this.f16064L) ? getMeasuredHeight() : this.f16064L) - getPaddingTop()) - getPaddingBottom();
        float f11 = fontMetrics.descent;
        float f12 = fontMetrics.ascent;
        return (((1.0f - this.f16072U) * (measuredHeight - ((f11 - f12) * f10))) / 2.0f) - (f10 * f12);
    }

    private void setUpTheme(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R.attr.colorPrimary, typedValue, true);
        TextPaint textPaint = this.f16075a;
        int i10 = typedValue.data;
        this.f16079c = i10;
        textPaint.setColor(i10);
    }

    public final void a(float f10) {
        if (this.f16083e || f10 != 1.0f) {
            this.f16077b.reset();
            String str = this.f16096y;
            int length = str.length();
            TextPaint textPaint = this.f16075a;
            Rect rect = this.f16053A;
            textPaint.getTextBounds(str, 0, length, rect);
            textPaint.getTextPath(str, 0, length, 0.0f, 0.0f, this.f16077b);
            if (f10 != 1.0f) {
                Log.v("MotionLabel", a.H() + " scale " + f10);
                Matrix matrix = new Matrix();
                matrix.postScale(f10, f10);
                this.f16077b.transform(matrix);
            }
            rect.right--;
            rect.left++;
            rect.bottom++;
            rect.top--;
            RectF rectF = new RectF();
            rectF.bottom = getHeight();
            rectF.right = getWidth();
            this.f16097z = false;
        }
    }

    public final void b(float f10, float f11, float f12, float f13) {
        int i10 = (int) (f10 + 0.5f);
        this.f16062J = f10 - i10;
        int i11 = (int) (f12 + 0.5f);
        int i12 = i11 - i10;
        int i13 = (int) (f13 + 0.5f);
        int i14 = (int) (0.5f + f11);
        int i15 = i13 - i14;
        float f14 = f12 - f10;
        this.f16063K = f14;
        float f15 = f13 - f11;
        this.f16064L = f15;
        if (this.f16068Q != null) {
            this.f16063K = f14;
            this.f16064L = f15;
            c();
        }
        if (getMeasuredHeight() == i15 && getMeasuredWidth() == i12) {
            super.layout(i10, i14, i11, i13);
        } else {
            measure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), View.MeasureSpec.makeMeasureSpec(i15, 1073741824));
            super.layout(i10, i14, i11, i13);
        }
        if (this.f16061I) {
            Rect rect = this.f16076a0;
            TextPaint textPaint = this.f16075a;
            if (rect == null) {
                this.f16078b0 = new Paint();
                this.f16076a0 = new Rect();
                this.f16078b0.set(textPaint);
                this.f16080c0 = this.f16078b0.getTextSize();
            }
            this.f16063K = f14;
            this.f16064L = f15;
            Paint paint = this.f16078b0;
            String str = this.f16096y;
            paint.getTextBounds(str, 0, str.length(), this.f16076a0);
            int iWidth = this.f16076a0.width();
            float fHeight = this.f16076a0.height() * 1.3f;
            float f16 = (f14 - this.f16055C) - this.f16054B;
            float f17 = (f15 - this.f16057E) - this.f16056D;
            float f18 = iWidth;
            if (f18 * f17 > fHeight * f16) {
                textPaint.setTextSize((this.f16080c0 * f16) / f18);
            } else {
                textPaint.setTextSize((this.f16080c0 * f17) / fHeight);
            }
            if (this.f16083e || !Float.isNaN(this.f16092u)) {
                a(Float.isNaN(this.f16092u) ? 1.0f : this.f16091t / this.f16092u);
            }
        }
    }

    public final void c() {
        float f10 = Float.isNaN(this.f16082d0) ? 0.0f : this.f16082d0;
        float f11 = Float.isNaN(this.f16084e0) ? 0.0f : this.f16084e0;
        float f12 = Float.isNaN(this.f16086f0) ? 1.0f : this.f16086f0;
        float f13 = Float.isNaN(this.f16087g0) ? 0.0f : this.f16087g0;
        this.f16068Q.reset();
        float width = this.f16066O.getWidth();
        float height = this.f16066O.getHeight();
        float f14 = Float.isNaN(this.f16070S) ? this.f16063K : this.f16070S;
        float f15 = Float.isNaN(this.f16069R) ? this.f16064L : this.f16069R;
        float f16 = f12 * (width * f15 < height * f14 ? f14 / width : f15 / height);
        this.f16068Q.postScale(f16, f16);
        float f17 = width * f16;
        float f18 = f14 - f17;
        float f19 = f16 * height;
        float f20 = f15 - f19;
        if (!Float.isNaN(this.f16069R)) {
            f20 = this.f16069R / 2.0f;
        }
        if (!Float.isNaN(this.f16070S)) {
            f18 = this.f16070S / 2.0f;
        }
        this.f16068Q.postTranslate((((f10 * f18) + f14) - f17) * 0.5f, (((f11 * f20) + f15) - f19) * 0.5f);
        this.f16068Q.postRotate(f13, f14 / 2.0f, f15 / 2.0f);
        this.f16067P.setLocalMatrix(this.f16068Q);
    }

    public float getRound() {
        return this.f16088q;
    }

    public float getRoundPercent() {
        return this.f16085f;
    }

    public float getScaleFromTextSize() {
        return this.f16092u;
    }

    public float getTextBackgroundPanX() {
        return this.f16082d0;
    }

    public float getTextBackgroundPanY() {
        return this.f16084e0;
    }

    public float getTextBackgroundRotate() {
        return this.f16087g0;
    }

    public float getTextBackgroundZoom() {
        return this.f16086f0;
    }

    public int getTextOutlineColor() {
        return this.f16081d;
    }

    public float getTextPanX() {
        return this.f16071T;
    }

    public float getTextPanY() {
        return this.f16072U;
    }

    public float getTextureHeight() {
        return this.f16069R;
    }

    public float getTextureWidth() {
        return this.f16070S;
    }

    public Typeface getTypeface() {
        return this.f16075a.getTypeface();
    }

    @Override // android.view.View
    public final void layout(int i10, int i11, int i12, int i13) {
        super.layout(i10, i11, i12, i13);
        boolean zIsNaN = Float.isNaN(this.f16092u);
        float f10 = zIsNaN ? 1.0f : this.f16091t / this.f16092u;
        this.f16063K = i12 - i10;
        this.f16064L = i13 - i11;
        if (this.f16061I) {
            Rect rect = this.f16076a0;
            TextPaint textPaint = this.f16075a;
            if (rect == null) {
                this.f16078b0 = new Paint();
                this.f16076a0 = new Rect();
                this.f16078b0.set(textPaint);
                this.f16080c0 = this.f16078b0.getTextSize();
            }
            Paint paint = this.f16078b0;
            String str = this.f16096y;
            paint.getTextBounds(str, 0, str.length(), this.f16076a0);
            int iWidth = this.f16076a0.width();
            int iHeight = (int) (this.f16076a0.height() * 1.3f);
            float f11 = (this.f16063K - this.f16055C) - this.f16054B;
            float f12 = (this.f16064L - this.f16057E) - this.f16056D;
            if (zIsNaN) {
                float f13 = iWidth;
                float f14 = iHeight;
                if (f13 * f12 > f14 * f11) {
                    textPaint.setTextSize((this.f16080c0 * f11) / f13);
                } else {
                    textPaint.setTextSize((this.f16080c0 * f12) / f14);
                }
            } else {
                float f15 = iWidth;
                float f16 = iHeight;
                f10 = f15 * f12 > f16 * f11 ? f11 / f15 : f12 / f16;
            }
        }
        if (this.f16083e || !zIsNaN) {
            float f17 = i10;
            float f18 = i11;
            float f19 = i12;
            float f20 = i13;
            if (this.f16068Q != null) {
                this.f16063K = f19 - f17;
                this.f16064L = f20 - f18;
                c();
            }
            a(f10);
        }
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        float f10 = Float.isNaN(this.f16092u) ? 1.0f : this.f16091t / this.f16092u;
        super.onDraw(canvas);
        boolean z3 = this.f16083e;
        TextPaint textPaint = this.f16075a;
        if (!z3 && f10 == 1.0f) {
            canvas.drawText(this.f16096y, this.f16062J + this.f16054B + getHorizontalOffset(), this.f16056D + getVerticalOffset(), textPaint);
            return;
        }
        if (this.f16097z) {
            a(f10);
        }
        if (this.f16065N == null) {
            this.f16065N = new Matrix();
        }
        if (!this.f16083e) {
            float horizontalOffset = this.f16054B + getHorizontalOffset();
            float verticalOffset = this.f16056D + getVerticalOffset();
            this.f16065N.reset();
            this.f16065N.preTranslate(horizontalOffset, verticalOffset);
            this.f16077b.transform(this.f16065N);
            textPaint.setColor(this.f16079c);
            textPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            textPaint.setStrokeWidth(this.f16095x);
            canvas.drawPath(this.f16077b, textPaint);
            this.f16065N.reset();
            this.f16065N.preTranslate(-horizontalOffset, -verticalOffset);
            this.f16077b.transform(this.f16065N);
            return;
        }
        Paint paint = this.f16073V;
        paint.set(textPaint);
        this.f16065N.reset();
        float horizontalOffset2 = this.f16054B + getHorizontalOffset();
        float verticalOffset2 = this.f16056D + getVerticalOffset();
        this.f16065N.postTranslate(horizontalOffset2, verticalOffset2);
        this.f16065N.preScale(f10, f10);
        this.f16077b.transform(this.f16065N);
        if (this.f16067P != null) {
            textPaint.setFilterBitmap(true);
            textPaint.setShader(this.f16067P);
        } else {
            textPaint.setColor(this.f16079c);
        }
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setStrokeWidth(this.f16095x);
        canvas.drawPath(this.f16077b, textPaint);
        if (this.f16067P != null) {
            textPaint.setShader(null);
        }
        textPaint.setColor(this.f16081d);
        textPaint.setStyle(Paint.Style.STROKE);
        textPaint.setStrokeWidth(this.f16095x);
        canvas.drawPath(this.f16077b, textPaint);
        this.f16065N.reset();
        this.f16065N.postTranslate(-horizontalOffset2, -verticalOffset2);
        this.f16077b.transform(this.f16065N);
        textPaint.set(paint);
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        this.f16061I = false;
        this.f16054B = getPaddingLeft();
        this.f16055C = getPaddingRight();
        this.f16056D = getPaddingTop();
        this.f16057E = getPaddingBottom();
        if (mode != 1073741824 || mode2 != 1073741824) {
            TextPaint textPaint = this.f16075a;
            String str = this.f16096y;
            int length = str.length();
            Rect rect = this.f16053A;
            textPaint.getTextBounds(str, 0, length, rect);
            if (mode != 1073741824) {
                size = (int) (rect.width() + 0.99999f);
            }
            size += this.f16054B + this.f16055C;
            if (mode2 != 1073741824) {
                int fontMetricsInt = (int) (textPaint.getFontMetricsInt(null) + 0.99999f);
                if (mode2 == Integer.MIN_VALUE) {
                    fontMetricsInt = Math.min(size2, fontMetricsInt);
                }
                size2 = this.f16056D + this.f16057E + fontMetricsInt;
            }
        } else if (this.f16060H != 0) {
            this.f16061I = true;
        }
        setMeasuredDimension(size, size2);
    }

    public void setGravity(int i10) {
        if ((i10 & 8388615) == 0) {
            i10 |= 8388611;
        }
        if ((i10 & 112) == 0) {
            i10 |= 48;
        }
        if (i10 != this.f16059G) {
            invalidate();
        }
        this.f16059G = i10;
        int i11 = i10 & 112;
        if (i11 == 48) {
            this.f16072U = -1.0f;
        } else if (i11 != 80) {
            this.f16072U = 0.0f;
        } else {
            this.f16072U = 1.0f;
        }
        int i12 = i10 & 8388615;
        if (i12 != 3) {
            if (i12 != 5) {
                if (i12 != 8388611) {
                    if (i12 != 8388613) {
                        this.f16071T = 0.0f;
                        return;
                    }
                }
            }
            this.f16071T = 1.0f;
            return;
        }
        this.f16071T = -1.0f;
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f16088q = f10;
            float f11 = this.f16085f;
            this.f16085f = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z3 = this.f16088q != f10;
        this.f16088q = f10;
        if (f10 != 0.0f) {
            if (this.f16077b == null) {
                this.f16077b = new Path();
            }
            if (this.f16090s == null) {
                this.f16090s = new RectF();
            }
            if (this.f16089r == null) {
                e eVar = new e(this, 1);
                this.f16089r = eVar;
                setOutlineProvider(eVar);
            }
            setClipToOutline(true);
            this.f16090s.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f16077b.reset();
            Path path = this.f16077b;
            RectF rectF = this.f16090s;
            float f12 = this.f16088q;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z3 = this.f16085f != f10;
        this.f16085f = f10;
        if (f10 != 0.0f) {
            if (this.f16077b == null) {
                this.f16077b = new Path();
            }
            if (this.f16090s == null) {
                this.f16090s = new RectF();
            }
            if (this.f16089r == null) {
                e eVar = new e(this, 0);
                this.f16089r = eVar;
                setOutlineProvider(eVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f16085f) / 2.0f;
            this.f16090s.set(0.0f, 0.0f, width, height);
            this.f16077b.reset();
            this.f16077b.addRoundRect(this.f16090s, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z3) {
            invalidateOutline();
        }
    }

    public void setScaleFromTextSize(float f10) {
        this.f16092u = f10;
    }

    public void setText(CharSequence charSequence) {
        this.f16096y = charSequence.toString();
        invalidate();
    }

    public void setTextBackgroundPanX(float f10) {
        this.f16082d0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundPanY(float f10) {
        this.f16084e0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundRotate(float f10) {
        this.f16087g0 = f10;
        c();
        invalidate();
    }

    public void setTextBackgroundZoom(float f10) {
        this.f16086f0 = f10;
        c();
        invalidate();
    }

    public void setTextFillColor(int i10) {
        this.f16079c = i10;
        invalidate();
    }

    public void setTextOutlineColor(int i10) {
        this.f16081d = i10;
        this.f16083e = true;
        invalidate();
    }

    public void setTextOutlineThickness(float f10) {
        this.f16095x = f10;
        this.f16083e = true;
        if (Float.isNaN(f10)) {
            this.f16095x = 1.0f;
            this.f16083e = false;
        }
        invalidate();
    }

    public void setTextPanX(float f10) {
        this.f16071T = f10;
        invalidate();
    }

    public void setTextPanY(float f10) {
        this.f16072U = f10;
        invalidate();
    }

    public void setTextSize(float f10) {
        this.f16091t = f10;
        TextPaint textPaint = this.f16075a;
        if (!Float.isNaN(this.f16092u)) {
            f10 = this.f16092u;
        }
        textPaint.setTextSize(f10);
        a(Float.isNaN(this.f16092u) ? 1.0f : this.f16091t / this.f16092u);
        requestLayout();
        invalidate();
    }

    public void setTextureHeight(float f10) {
        this.f16069R = f10;
        c();
        invalidate();
    }

    public void setTextureWidth(float f10) {
        this.f16070S = f10;
        c();
        invalidate();
    }

    public void setTypeface(Typeface typeface) {
        TextPaint textPaint = this.f16075a;
        if (Objects.equals(textPaint.getTypeface(), typeface)) {
            return;
        }
        textPaint.setTypeface(typeface);
    }
}
