package androidx.constraintlayout.widget;

import U0.f;
import U0.j;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import java.util.HashMap;
import p005a1.e;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Barrier extends ConstraintHelper {

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int f16105t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f16106u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public U0.a f16107v;

    public Barrier(Context context) {
        super(context);
        this.f16108a = new int[32];
        this.f16112e = false;
        this.f16115r = null;
        this.f16116s = new HashMap();
        this.f16110c = context;
        k(null);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.f16107v.f12126x0;
    }

    public int getMargin() {
        return this.f16107v.f12127y0;
    }

    public int getType() {
        return this.f16105t;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void k(AttributeSet attributeSet) {
        super.k(attributeSet);
        this.f16107v = new U0.a();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 26) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.f16107v.f12126x0 = typedArrayObtainStyledAttributes.getBoolean(index, true);
                } else if (index == 27) {
                    this.f16107v.f12127y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.f16111d = this.f16107v;
        q();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void l(c cVar, j jVar, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        super.l(cVar, jVar, layoutParams, sparseArray);
        if (jVar instanceof U0.a) {
            U0.a aVar = (U0.a) jVar;
            boolean z3 = ((f) jVar.f12179V).f12248z0;
            e eVar = cVar.f16236e;
            r(aVar, eVar.f14971g0, z3);
            aVar.f12126x0 = eVar.f14986o0;
            aVar.f12127y0 = eVar.f14973h0;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public final void m(U0.e eVar, boolean z3) {
        r(eVar, this.f16105t, z3);
    }

    public final void r(U0.e eVar, int i10, boolean z3) {
        this.f16106u = i10;
        if (z3) {
            int i11 = this.f16105t;
            if (i11 == 5) {
                this.f16106u = 1;
            } else if (i11 == 6) {
                this.f16106u = 0;
            }
        } else {
            int i12 = this.f16105t;
            if (i12 == 5) {
                this.f16106u = 0;
            } else if (i12 == 6) {
                this.f16106u = 1;
            }
        }
        if (eVar instanceof U0.a) {
            ((U0.a) eVar).f12125w0 = this.f16106u;
        }
    }

    public void setAllowsGoneWidget(boolean z3) {
        this.f16107v.f12126x0 = z3;
    }

    public void setDpMargin(int i10) {
        this.f16107v.f12127y0 = (int) ((i10 * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i10) {
        this.f16107v.f12127y0 = i10;
    }

    public void setType(int i10) {
        this.f16105t = i10;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }
}
