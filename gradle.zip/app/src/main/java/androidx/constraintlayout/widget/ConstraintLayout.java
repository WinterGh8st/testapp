package androidx.constraintlayout.widget;

import B2.C0057h;
import G6.F0;
import G6.y0;
import U0.e;
import U0.f;
import U0.i;
import V0.j;
import V0.l;
import V0.n;
import V0.p;
import X.k;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParserException;
import p005a1.m;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public static m f16117z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final SparseArray f16118a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f16119b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final f f16120c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16121d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16122e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16123f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f16124q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f16125r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f16126s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public d f16127t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public k f16128u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f16129v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public HashMap f16130w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final SparseArray f16131x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final b f16132y;

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16118a = new SparseArray();
        this.f16119b = new ArrayList(4);
        this.f16120c = new f();
        this.f16121d = 0;
        this.f16122e = 0;
        this.f16123f = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        this.f16124q = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        this.f16125r = true;
        this.f16126s = 257;
        this.f16127t = null;
        this.f16128u = null;
        this.f16129v = -1;
        this.f16130w = new HashMap();
        this.f16131x = new SparseArray();
        this.f16132y = new b(this, this);
        h(attributeSet, 0);
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int iMax2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static m getSharedValues() {
        if (f16117z == null) {
            m mVar = new m();
            new SparseIntArray();
            mVar.f15064a = new HashMap();
            f16117z = mVar;
        }
        return f16117z;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    /* JADX WARN: Code duplicated, block: B:163:0x02cf  */
    /* JADX WARN: Code duplicated, block: B:44:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:46:0x00e9  */
    /* JADX WARN: Code duplicated, block: B:49:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:56:0x010e  */
    /* JADX WARN: Code duplicated, block: B:58:0x0117  */
    /* JADX WARN: Code duplicated, block: B:59:0x0125  */
    /* JADX WARN: Code duplicated, block: B:61:0x012b  */
    /* JADX WARN: Code duplicated, block: B:68:0x014e  */
    /* JADX WARN: Code duplicated, block: B:70:0x0157  */
    /* JADX WARN: Code duplicated, block: B:73:0x0164  */
    /* JADX WARN: Code duplicated, block: B:75:0x0169  */
    /* JADX WARN: Code duplicated, block: B:80:0x0181  */
    /* JADX WARN: Code duplicated, block: B:82:0x018f  */
    /* JADX WARN: Code duplicated, block: B:84:0x0194  */
    /* JADX WARN: Code duplicated, block: B:85:0x019f  */
    /* JADX WARN: Code duplicated, block: B:87:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:90:0x01b4  */
    /* JADX WARN: Code duplicated, block: B:93:0x01bc  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:163:0x02cf -> B:164:0x02d0). Please report as a decompilation issue!!! */
    public final void d(boolean z3, View view, e eVar, LayoutParams layoutParams, SparseArray sparseArray) {
        ConstraintLayout constraintLayout;
        float f10;
        int i10;
        e eVar2;
        int i11;
        int i12;
        int i13;
        e eVar3;
        int i14;
        int i15;
        int i16;
        int i17;
        e eVar4;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        e eVar5;
        int i23;
        int i24;
        LayoutParams layoutParams2;
        int i25;
        int i26;
        e eVar6;
        int i27;
        float f11;
        e eVar7;
        e eVar8;
        e eVar9;
        int i28;
        float fAbs;
        int i29;
        float f12;
        e eVar10 = eVar;
        layoutParams.a();
        eVar10.f12201i0 = view.getVisibility();
        if (layoutParams.f16169f0) {
            eVar10.f12164F = true;
            eVar10.f12201i0 = 8;
        }
        eVar10.f12199h0 = view;
        if (view instanceof ConstraintHelper) {
            constraintLayout = this;
            ((ConstraintHelper) view).m(eVar10, constraintLayout.f16120c.f12248z0);
        } else {
            constraintLayout = this;
        }
        int i30 = -1;
        if (layoutParams.f16165d0) {
            i iVar = (i) eVar10;
            int i31 = layoutParams.f16184n0;
            int i32 = layoutParams.f16186o0;
            float f13 = layoutParams.f16188p0;
            if (f13 != -1.0f) {
                if (f13 > -1.0f) {
                    iVar.f12290u0 = f13;
                    iVar.v0 = -1;
                    iVar.f12291w0 = -1;
                    return;
                }
                return;
            }
            if (i31 != -1) {
                if (i31 > -1) {
                    iVar.f12290u0 = -1.0f;
                    iVar.v0 = i31;
                    iVar.f12291w0 = -1;
                    return;
                }
                return;
            }
            if (i32 == -1 || i32 <= -1) {
                return;
            }
            iVar.f12290u0 = -1.0f;
            iVar.v0 = -1;
            iVar.f12291w0 = i32;
            return;
        }
        int i33 = layoutParams.f16171g0;
        int i34 = layoutParams.f16173h0;
        int i35 = layoutParams.f16175i0;
        int i36 = layoutParams.f16177j0;
        int i37 = layoutParams.f16178k0;
        int i38 = layoutParams.f16180l0;
        float f14 = layoutParams.f16182m0;
        int i39 = layoutParams.f16187p;
        if (i39 != -1) {
            e eVar11 = (e) sparseArray.get(i39);
            if (eVar11 != null) {
                float f15 = layoutParams.f16191r;
                f12 = 0.0f;
                eVar.w(7, eVar11, 7, layoutParams.f16189q, 0);
                eVar10 = eVar;
                eVar10.f12162D = f15;
            } else {
                f12 = 0.0f;
            }
            eVar6 = eVar10;
            layoutParams2 = layoutParams;
            f10 = f12;
            i13 = 2;
            i27 = 5;
            i21 = 3;
            i14 = 4;
        } else {
            if (i33 != -1) {
                e eVar12 = (e) sparseArray.get(i33);
                if (eVar12 != null) {
                    f10 = 0.0f;
                    i10 = 2;
                    eVar10.w(2, eVar12, 2, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i37);
                } else {
                    f10 = 0.0f;
                    i10 = 2;
                }
            } else {
                f10 = 0.0f;
                i10 = 2;
                if (i34 != -1 && (eVar2 = (e) sparseArray.get(i34)) != null) {
                    eVar.w(2, eVar2, 4, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i37);
                    i11 = 2;
                    i12 = 4;
                }
                if (i35 != -1) {
                    eVar9 = (e) sparseArray.get(i35);
                    if (eVar9 != null) {
                        eVar.w(i12, eVar9, i11, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i38);
                    }
                    i13 = i11;
                } else {
                    i13 = i11;
                    if (i36 != -1 && (eVar3 = (e) sparseArray.get(i36)) != null) {
                        eVar.w(i12, eVar3, i12, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i38);
                    }
                }
                i14 = i12;
                i15 = layoutParams.f16174i;
                if (i15 != -1) {
                    eVar8 = (e) sparseArray.get(i15);
                    if (eVar8 != null) {
                        i16 = 3;
                        eVar.w(3, eVar8, 3, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, layoutParams.f16197x);
                    } else {
                        i16 = 3;
                    }
                } else {
                    i16 = 3;
                    i17 = layoutParams.f16176j;
                    if (i17 == -1 && (eVar4 = (e) sparseArray.get(i17)) != null) {
                        eVar.w(3, eVar4, 5, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, layoutParams.f16197x);
                        i18 = 3;
                        i19 = 5;
                    }
                    i20 = layoutParams.k;
                    if (i20 != -1) {
                        eVar7 = (e) sparseArray.get(i20);
                        if (eVar7 != null) {
                            eVar.w(i19, eVar7, i18, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                        }
                        i21 = i18;
                    } else {
                        i21 = i18;
                        i22 = layoutParams.f16179l;
                        if (i22 != -1 && (eVar5 = (e) sparseArray.get(i22)) != null) {
                            eVar.w(i19, eVar5, i19, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                        }
                    }
                    i23 = i19;
                    i24 = layoutParams.f16181m;
                    if (i24 != -1) {
                        layoutParams2 = layoutParams;
                        constraintLayout.o(eVar, layoutParams2, sparseArray, i24, 6);
                    } else {
                        layoutParams2 = layoutParams;
                        i25 = layoutParams2.f16183n;
                        if (i25 != -1) {
                            o(eVar, layoutParams2, sparseArray, i25, i21);
                        } else {
                            i26 = layoutParams2.f16185o;
                            if (i26 != -1) {
                                o(eVar, layoutParams2, sparseArray, i26, i23);
                                eVar6 = eVar;
                                i27 = i23;
                            }
                            if (f14 >= f10) {
                                eVar6.f12195f0 = f14;
                            }
                            f11 = layoutParams2.f16138F;
                            if (f11 >= f10) {
                                eVar6.f12197g0 = f11;
                            }
                        }
                    }
                    eVar6 = eVar;
                    i27 = i23;
                    if (f14 >= f10) {
                        eVar6.f12195f0 = f14;
                    }
                    f11 = layoutParams2.f16138F;
                    if (f11 >= f10) {
                        eVar6.f12197g0 = f11;
                    }
                }
                i18 = i16;
                i19 = 5;
                i20 = layoutParams.k;
                if (i20 != -1) {
                    eVar7 = (e) sparseArray.get(i20);
                    if (eVar7 != null) {
                        eVar.w(i19, eVar7, i18, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                    }
                    i21 = i18;
                } else {
                    i21 = i18;
                    i22 = layoutParams.f16179l;
                    if (i22 != -1) {
                        eVar.w(i19, eVar5, i19, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                    }
                }
                i23 = i19;
                i24 = layoutParams.f16181m;
                if (i24 != -1) {
                    layoutParams2 = layoutParams;
                    constraintLayout.o(eVar, layoutParams2, sparseArray, i24, 6);
                } else {
                    layoutParams2 = layoutParams;
                    i25 = layoutParams2.f16183n;
                    if (i25 != -1) {
                        o(eVar, layoutParams2, sparseArray, i25, i21);
                    } else {
                        i26 = layoutParams2.f16185o;
                        if (i26 != -1) {
                            o(eVar, layoutParams2, sparseArray, i26, i23);
                            eVar6 = eVar;
                            i27 = i23;
                        }
                        if (f14 >= f10) {
                            eVar6.f12195f0 = f14;
                        }
                        f11 = layoutParams2.f16138F;
                        if (f11 >= f10) {
                            eVar6.f12197g0 = f11;
                        }
                    }
                }
                eVar6 = eVar;
                i27 = i23;
                if (f14 >= f10) {
                    eVar6.f12195f0 = f14;
                }
                f11 = layoutParams2.f16138F;
                if (f11 >= f10) {
                    eVar6.f12197g0 = f11;
                }
            }
            i11 = i10;
            i12 = 4;
            if (i35 != -1) {
                eVar9 = (e) sparseArray.get(i35);
                if (eVar9 != null) {
                    eVar.w(i12, eVar9, i11, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i38);
                }
                i13 = i11;
            } else {
                i13 = i11;
                if (i36 != -1) {
                    eVar.w(i12, eVar3, i12, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i38);
                }
            }
            i14 = i12;
            i15 = layoutParams.f16174i;
            if (i15 != -1) {
                eVar8 = (e) sparseArray.get(i15);
                if (eVar8 != null) {
                    i16 = 3;
                    eVar.w(3, eVar8, 3, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, layoutParams.f16197x);
                } else {
                    i16 = 3;
                }
            } else {
                i16 = 3;
                i17 = layoutParams.f16176j;
                if (i17 == -1) {
                }
                i20 = layoutParams.k;
                if (i20 != -1) {
                    eVar7 = (e) sparseArray.get(i20);
                    if (eVar7 != null) {
                        eVar.w(i19, eVar7, i18, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                    }
                    i21 = i18;
                } else {
                    i21 = i18;
                    i22 = layoutParams.f16179l;
                    if (i22 != -1) {
                        eVar.w(i19, eVar5, i19, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                    }
                }
                i23 = i19;
                i24 = layoutParams.f16181m;
                if (i24 != -1) {
                    layoutParams2 = layoutParams;
                    constraintLayout.o(eVar, layoutParams2, sparseArray, i24, 6);
                } else {
                    layoutParams2 = layoutParams;
                    i25 = layoutParams2.f16183n;
                    if (i25 != -1) {
                        o(eVar, layoutParams2, sparseArray, i25, i21);
                    } else {
                        i26 = layoutParams2.f16185o;
                        if (i26 != -1) {
                            o(eVar, layoutParams2, sparseArray, i26, i23);
                            eVar6 = eVar;
                            i27 = i23;
                        }
                        if (f14 >= f10) {
                            eVar6.f12195f0 = f14;
                        }
                        f11 = layoutParams2.f16138F;
                        if (f11 >= f10) {
                            eVar6.f12197g0 = f11;
                        }
                    }
                }
                eVar6 = eVar;
                i27 = i23;
                if (f14 >= f10) {
                    eVar6.f12195f0 = f14;
                }
                f11 = layoutParams2.f16138F;
                if (f11 >= f10) {
                    eVar6.f12197g0 = f11;
                }
            }
            i18 = i16;
            i19 = 5;
            i20 = layoutParams.k;
            if (i20 != -1) {
                eVar7 = (e) sparseArray.get(i20);
                if (eVar7 != null) {
                    eVar.w(i19, eVar7, i18, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                }
                i21 = i18;
            } else {
                i21 = i18;
                i22 = layoutParams.f16179l;
                if (i22 != -1) {
                    eVar.w(i19, eVar5, i19, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.f16199z);
                }
            }
            i23 = i19;
            i24 = layoutParams.f16181m;
            if (i24 != -1) {
                layoutParams2 = layoutParams;
                constraintLayout.o(eVar, layoutParams2, sparseArray, i24, 6);
            } else {
                layoutParams2 = layoutParams;
                i25 = layoutParams2.f16183n;
                if (i25 != -1) {
                    o(eVar, layoutParams2, sparseArray, i25, i21);
                } else {
                    i26 = layoutParams2.f16185o;
                    if (i26 != -1) {
                        o(eVar, layoutParams2, sparseArray, i26, i23);
                        eVar6 = eVar;
                        i27 = i23;
                    }
                    if (f14 >= f10) {
                        eVar6.f12195f0 = f14;
                    }
                    f11 = layoutParams2.f16138F;
                    if (f11 >= f10) {
                        eVar6.f12197g0 = f11;
                    }
                }
            }
            eVar6 = eVar;
            i27 = i23;
            if (f14 >= f10) {
                eVar6.f12195f0 = f14;
            }
            f11 = layoutParams2.f16138F;
            if (f11 >= f10) {
                eVar6.f12197g0 = f11;
            }
        }
        if (z3 && ((i29 = layoutParams2.f16151T) != -1 || layoutParams2.f16152U != -1)) {
            int i40 = layoutParams2.f16152U;
            eVar6.f12185a0 = i29;
            eVar6.f12187b0 = i40;
        }
        boolean z5 = layoutParams2.f16159a0;
        U0.d dVar = U0.d.f12155b;
        U0.d dVar2 = U0.d.f12154a;
        U0.d dVar3 = U0.d.f12157d;
        U0.d dVar4 = U0.d.f12156c;
        if (z5) {
            eVar6.N(dVar2);
            eVar6.P(((ViewGroup.MarginLayoutParams) layoutParams2).width);
            if (((ViewGroup.MarginLayoutParams) layoutParams2).width == -2) {
                eVar6.N(dVar);
            }
        } else if (((ViewGroup.MarginLayoutParams) layoutParams2).width == -1) {
            if (layoutParams2.f16154W) {
                eVar6.N(dVar4);
            } else {
                eVar6.N(dVar3);
            }
            eVar6.j(i13).f12151g = ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin;
            eVar6.j(i14).f12151g = ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin;
        } else {
            eVar6.N(dVar4);
            eVar6.P(0);
        }
        if (layoutParams2.f16161b0) {
            eVar6.O(dVar2);
            eVar6.M(((ViewGroup.MarginLayoutParams) layoutParams2).height);
            if (((ViewGroup.MarginLayoutParams) layoutParams2).height == -2) {
                eVar6.O(dVar);
            }
        } else if (((ViewGroup.MarginLayoutParams) layoutParams2).height == -1) {
            if (layoutParams2.f16155X) {
                eVar6.O(dVar4);
            } else {
                eVar6.O(dVar3);
            }
            eVar6.j(i21).f12151g = ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin;
            eVar6.j(i27).f12151g = ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin;
        } else {
            eVar6.O(dVar4);
            eVar6.M(0);
        }
        String str = layoutParams2.f16139G;
        if (str == null || str.length() == 0) {
            eVar6.f12182Y = f10;
        } else {
            int length = str.length();
            int iIndexOf = str.indexOf(44);
            if (iIndexOf <= 0 || iIndexOf >= length - 1) {
                i28 = 0;
            } else {
                String strSubstring = str.substring(0, iIndexOf);
                if (strSubstring.equalsIgnoreCase("W")) {
                    i30 = 0;
                } else if (strSubstring.equalsIgnoreCase("H")) {
                    i30 = 1;
                }
                i28 = iIndexOf + 1;
            }
            int iIndexOf2 = str.indexOf(58);
            try {
                if (iIndexOf2 < 0 || iIndexOf2 >= length - 1) {
                    String strSubstring2 = str.substring(i28);
                    if (strSubstring2.length() > 0) {
                        fAbs = Float.parseFloat(strSubstring2);
                    } else {
                        fAbs = f10;
                    }
                } else {
                    String strSubstring3 = str.substring(i28, iIndexOf2);
                    String strSubstring4 = str.substring(iIndexOf2 + 1);
                    if (strSubstring3.length() <= 0 || strSubstring4.length() <= 0) {
                        fAbs = f10;
                    } else {
                        float f16 = Float.parseFloat(strSubstring3);
                        float f17 = Float.parseFloat(strSubstring4);
                        if (f16 <= f10 || f17 <= f10) {
                            fAbs = f10;
                        } else {
                            fAbs = i30 == 1 ? Math.abs(f17 / f16) : Math.abs(f16 / f17);
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
            if (fAbs > f10) {
                eVar6.f12182Y = fAbs;
                eVar6.f12183Z = i30;
            }
        }
        float f18 = layoutParams2.f16140H;
        float[] fArr = eVar6.f12210n0;
        fArr[0] = f18;
        fArr[1] = layoutParams2.f16141I;
        eVar6.f12206l0 = layoutParams2.f16142J;
        eVar6.f12208m0 = layoutParams2.f16143K;
        int i41 = layoutParams2.f16157Z;
        if (i41 >= 0 && i41 <= 3) {
            eVar6.f12215q = i41;
        }
        int i42 = layoutParams2.f16144L;
        int i43 = layoutParams2.f16145N;
        int i44 = layoutParams2.f16147P;
        float f19 = layoutParams2.f16149R;
        eVar6.f12217r = i42;
        eVar6.f12223u = i43;
        if (i44 == Integer.MAX_VALUE) {
            i44 = 0;
        }
        eVar6.f12224v = i44;
        eVar6.f12225w = f19;
        if (f19 > f10 && f19 < 1.0f && i42 == 0) {
            eVar6.f12217r = 2;
        }
        int i45 = layoutParams2.M;
        int i46 = layoutParams2.f16146O;
        int i47 = layoutParams2.f16148Q;
        float f20 = layoutParams2.f16150S;
        eVar6.f12219s = i45;
        eVar6.f12226x = i46;
        eVar6.f12227y = i47 != Integer.MAX_VALUE ? i47 : 0;
        eVar6.f12228z = f20;
        if (f20 <= f10 || f20 >= 1.0f || i45 != 0) {
            return;
        }
        eVar6.f12219s = 2;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.f16119b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i10 = 0; i10 < size; i10++) {
                ((ConstraintHelper) arrayList.get(i10)).o(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i12 = Integer.parseInt(strArrSplit[0]);
                        int i13 = Integer.parseInt(strArrSplit[1]);
                        int i14 = Integer.parseInt(strArrSplit[2]);
                        int i15 = (int) ((i12 / 1080.0f) * width);
                        int i16 = (int) ((i13 / 1920.0f) * height);
                        int i17 = (int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f10 = i15;
                        float f11 = i16;
                        float f12 = i15 + ((int) ((i14 / 1080.0f) * width));
                        canvas.drawLine(f10, f11, f12, f11, paint);
                        float f13 = i16 + i17;
                        canvas.drawLine(f12, f11, f12, f13, paint);
                        canvas.drawLine(f12, f13, f10, f13, paint);
                        canvas.drawLine(f10, f13, f10, f11, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f10, f11, f12, f13, paint);
                        canvas.drawLine(f10, f13, f12, f11, paint);
                    }
                }
            }
        }
    }

    public final View e(int i10) {
        return (View) this.f16118a.get(i10);
    }

    public final e f(View view) {
        if (view == this) {
            return this.f16120c;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof LayoutParams) {
            return ((LayoutParams) view.getLayoutParams()).f16190q0;
        }
        view.setLayoutParams(new LayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof LayoutParams) {
            return ((LayoutParams) view.getLayoutParams()).f16190q0;
        }
        return null;
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.f16125r = true;
        super.forceLayout();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public int getMaxHeight() {
        return this.f16124q;
    }

    public int getMaxWidth() {
        return this.f16123f;
    }

    public int getMinHeight() {
        return this.f16122e;
    }

    public int getMinWidth() {
        return this.f16121d;
    }

    public int getOptimizationLevel() {
        return this.f16120c.f12236H0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb2 = new StringBuilder();
        f fVar = this.f16120c;
        if (fVar.f12202j == null) {
            int id2 = getId();
            if (id2 != -1) {
                fVar.f12202j = getContext().getResources().getResourceEntryName(id2);
            } else {
                fVar.f12202j = "parent";
            }
        }
        if (fVar.f12204k0 == null) {
            fVar.f12204k0 = fVar.f12202j;
            Log.v("ConstraintLayout", " setDebugName " + fVar.f12204k0);
        }
        ArrayList arrayList = fVar.f12244u0;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            e eVar = (e) obj;
            View view = eVar.f12199h0;
            if (view != null) {
                if (eVar.f12202j == null && (id = view.getId()) != -1) {
                    eVar.f12202j = getContext().getResources().getResourceEntryName(id);
                }
                if (eVar.f12204k0 == null) {
                    eVar.f12204k0 = eVar.f12202j;
                    Log.v("ConstraintLayout", " setDebugName " + eVar.f12204k0);
                }
            }
        }
        fVar.o(sb2);
        return sb2.toString();
    }

    public final void h(AttributeSet attributeSet, int i10) {
        f fVar = this.f16120c;
        fVar.f12199h0 = this;
        b bVar = this.f16132y;
        fVar.f12247y0 = bVar;
        fVar.f12245w0.f12817f = bVar;
        this.f16118a.put(getId(), this);
        this.f16127t = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, p005a1.k.f15041c, i10, 0);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i11);
                if (index == 16) {
                    this.f16121d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16121d);
                } else if (index == 17) {
                    this.f16122e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16122e);
                } else if (index == 14) {
                    this.f16123f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16123f);
                } else if (index == 15) {
                    this.f16124q = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16124q);
                } else if (index == 113) {
                    this.f16126s = typedArrayObtainStyledAttributes.getInt(index, this.f16126s);
                } else if (index == 56) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            l(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f16128u = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        d dVar = new d();
                        this.f16127t = dVar;
                        dVar.k(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f16127t = null;
                    }
                    this.f16129v = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        fVar.f12236H0 = this.f16126s;
        S0.c.f11231q = fVar.X(512);
    }

    public final boolean k() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    /* JADX WARN: Code duplicated, block: B:31:0x007b  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public void l(int i10) {
        Context context = getContext();
        k kVar = new k();
        kVar.f13399a = -1;
        kVar.f13400b = -1;
        kVar.f13402d = new SparseArray();
        kVar.f13403e = new SparseArray();
        kVar.f13401c = this;
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            int eventType = xml.getEventType();
            p005a1.b bVar = null;
            while (true) {
                byte b10 = 1;
                if (eventType != 1) {
                    if (eventType == 2) {
                        String name = xml.getName();
                        switch (name.hashCode()) {
                            case -1349929691:
                                if (!name.equals("ConstraintSet")) {
                                    b10 = -1;
                                } else {
                                    b10 = 4;
                                }
                                break;
                            case 80204913:
                                if (!name.equals("State")) {
                                    b10 = -1;
                                } else {
                                    b10 = 2;
                                }
                                break;
                            case 1382829617:
                                if (!name.equals("StateSet")) {
                                    b10 = -1;
                                }
                                break;
                            case 1657696882:
                                if (!name.equals("layoutDescription")) {
                                    b10 = -1;
                                } else {
                                    b10 = 0;
                                }
                                break;
                            case 1901439077:
                                if (!name.equals("Variant")) {
                                    b10 = -1;
                                } else {
                                    b10 = 3;
                                }
                                break;
                            default:
                                b10 = -1;
                                break;
                        }
                        if (b10 == 2) {
                            p005a1.b bVar2 = new p005a1.b(context, xml);
                            ((SparseArray) kVar.f13402d).put(bVar2.f14911a, bVar2);
                            bVar = bVar2;
                        } else if (b10 == 3) {
                            p005a1.c cVar = new p005a1.c(context, xml);
                            if (bVar != null) {
                                bVar.f14912b.add(cVar);
                            }
                        } else if (b10 == 4) {
                            kVar.l(context, xml);
                        }
                    }
                    eventType = xml.next();
                }
                this.f16128u = kVar;
                return;
            }
        } catch (IOException e10) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i10, e10);
        } catch (XmlPullParserException e11) {
            Log.e("ConstraintLayoutStates", "Error parsing resource: " + i10, e11);
        }
    }

    public final void m(int i10, int i11, int i12, int i13, boolean z3, boolean z5) {
        b bVar = this.f16132y;
        int i14 = bVar.f16228e;
        int iResolveSizeAndState = View.resolveSizeAndState(i12 + bVar.f16227d, i10, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(i13 + i14, i11, 0) & 16777215;
        int iMin = Math.min(this.f16123f, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.f16124q, iResolveSizeAndState2);
        if (z3) {
            iMin |= 16777216;
        }
        if (z5) {
            iMin2 |= 16777216;
        }
        setMeasuredDimension(iMin, iMin2);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01dd A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:105:0x01e6  */
    /* JADX WARN: Code duplicated, block: B:107:0x01fc  */
    /* JADX WARN: Code duplicated, block: B:110:0x020c  */
    /* JADX WARN: Code duplicated, block: B:112:0x0210  */
    /* JADX WARN: Code duplicated, block: B:116:0x021f A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:191:0x03cb  */
    /* JADX WARN: Code duplicated, block: B:193:0x03db  */
    /* JADX WARN: Code duplicated, block: B:195:0x03e4 A[LOOP:11: B:194:0x03e2->B:195:0x03e4, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:197:0x0431  */
    /* JADX WARN: Code duplicated, block: B:200:0x044d  */
    /* JADX WARN: Code duplicated, block: B:201:0x0454  */
    /* JADX WARN: Code duplicated, block: B:203:0x0458  */
    /* JADX WARN: Code duplicated, block: B:205:0x0462 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:206:0x0464  */
    /* JADX WARN: Code duplicated, block: B:207:0x0466  */
    /* JADX WARN: Code duplicated, block: B:209:0x0469  */
    /* JADX WARN: Code duplicated, block: B:210:0x046b  */
    /* JADX WARN: Code duplicated, block: B:212:0x0470  */
    /* JADX WARN: Code duplicated, block: B:214:0x047e  */
    /* JADX WARN: Code duplicated, block: B:220:0x0487  */
    /* JADX WARN: Code duplicated, block: B:222:0x0498  */
    /* JADX WARN: Code duplicated, block: B:225:0x04a6  */
    /* JADX WARN: Code duplicated, block: B:243:0x04d5  */
    /* JADX WARN: Code duplicated, block: B:249:0x04e1  */
    /* JADX WARN: Code duplicated, block: B:251:0x04e4  */
    /* JADX WARN: Code duplicated, block: B:256:0x04f0  */
    /* JADX WARN: Code duplicated, block: B:263:0x04ff  */
    /* JADX WARN: Code duplicated, block: B:26:0x00b1 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:270:0x050e A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:271:0x0510  */
    /* JADX WARN: Code duplicated, block: B:276:0x051a  */
    /* JADX WARN: Code duplicated, block: B:27:0x00b3  */
    /* JADX WARN: Code duplicated, block: B:280:0x052d  */
    /* JADX WARN: Code duplicated, block: B:282:0x0535  */
    /* JADX WARN: Code duplicated, block: B:285:0x053c  */
    /* JADX WARN: Code duplicated, block: B:287:0x0557  */
    /* JADX WARN: Code duplicated, block: B:290:0x0568  */
    /* JADX WARN: Code duplicated, block: B:295:0x0582  */
    /* JADX WARN: Code duplicated, block: B:297:0x0585 A[LOOP:5: B:296:0x0583->B:297:0x0585, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:29:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:300:0x059f  */
    /* JADX WARN: Code duplicated, block: B:302:0x05a4  */
    /* JADX WARN: Code duplicated, block: B:304:0x05ac  */
    /* JADX WARN: Code duplicated, block: B:306:0x05b0  */
    /* JADX WARN: Code duplicated, block: B:309:0x05b6  */
    /* JADX WARN: Code duplicated, block: B:30:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:310:0x05b8  */
    /* JADX WARN: Code duplicated, block: B:313:0x05d5  */
    /* JADX WARN: Code duplicated, block: B:315:0x05e1  */
    /* JADX WARN: Code duplicated, block: B:316:0x05e9  */
    /* JADX WARN: Code duplicated, block: B:318:0x060a  */
    /* JADX WARN: Code duplicated, block: B:31:0x00c9 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:320:0x060f  */
    /* JADX WARN: Code duplicated, block: B:325:0x0631  */
    /* JADX WARN: Code duplicated, block: B:327:0x0636  */
    /* JADX WARN: Code duplicated, block: B:32:0x00cb  */
    /* JADX WARN: Code duplicated, block: B:331:0x0656  */
    /* JADX WARN: Code duplicated, block: B:337:0x0673  */
    /* JADX WARN: Code duplicated, block: B:339:0x0676  */
    /* JADX WARN: Code duplicated, block: B:33:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:341:0x0680  */
    /* JADX WARN: Code duplicated, block: B:345:0x0688  */
    /* JADX WARN: Code duplicated, block: B:351:0x0694 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:359:0x06ab  */
    /* JADX WARN: Code duplicated, block: B:35:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:362:0x06c4  */
    /* JADX WARN: Code duplicated, block: B:365:0x06d6  */
    /* JADX WARN: Code duplicated, block: B:367:0x06db  */
    /* JADX WARN: Code duplicated, block: B:370:0x06fb  */
    /* JADX WARN: Code duplicated, block: B:372:0x06ff  */
    /* JADX WARN: Code duplicated, block: B:374:0x0702  */
    /* JADX WARN: Code duplicated, block: B:376:0x0707  */
    /* JADX WARN: Code duplicated, block: B:379:0x0726  */
    /* JADX WARN: Code duplicated, block: B:37:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:381:0x072a  */
    /* JADX WARN: Code duplicated, block: B:384:0x072f  */
    /* JADX WARN: Code duplicated, block: B:387:0x0735  */
    /* JADX WARN: Code duplicated, block: B:38:0x00e7  */
    /* JADX WARN: Code duplicated, block: B:391:0x0748 A[LOOP:7: B:335:0x0670->B:391:0x0748, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:394:0x01d4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:418:0x051e A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:41:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:422:0x051e A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:425:0x0577 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:426:0x0577 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:431:0x0754 A[EDGE_INSN: B:431:0x0754->B:392:0x0754 BREAK  A[LOOP:7: B:335:0x0670->B:391:0x0748], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:45:0x00ff  */
    /* JADX WARN: Code duplicated, block: B:48:0x0130  */
    /* JADX WARN: Code duplicated, block: B:49:0x0133  */
    /* JADX WARN: Code duplicated, block: B:52:0x013b  */
    /* JADX WARN: Code duplicated, block: B:53:0x013e  */
    /* JADX WARN: Code duplicated, block: B:56:0x0163  */
    /* JADX WARN: Code duplicated, block: B:60:0x016c  */
    /* JADX WARN: Code duplicated, block: B:63:0x0174  */
    /* JADX WARN: Code duplicated, block: B:65:0x0177  */
    /* JADX WARN: Code duplicated, block: B:67:0x018b  */
    /* JADX WARN: Code duplicated, block: B:68:0x018e  */
    /* JADX WARN: Code duplicated, block: B:71:0x0194  */
    /* JADX WARN: Code duplicated, block: B:72:0x0197  */
    /* JADX WARN: Code duplicated, block: B:74:0x019a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:78:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:81:0x01ac A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:84:0x01b2  */
    /* JADX WARN: Code duplicated, block: B:97:0x01d4 A[PHI: r2
  0x01d4: PHI (r2v3 boolean) = (r2v2 boolean), (r2v74 boolean) binds: [B:62:0x0172, B:394:0x01d4] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:99:0x01db A[ADDED_TO_REGION] */
    public final void n(f fVar, int i10, int i11, int i12) {
        int iMax;
        int iMax2;
        U0.d dVar;
        int iR;
        V0.f fVar2;
        int i13;
        int i14;
        C0057h c0057h;
        V0.c cVar;
        int size;
        int iR2;
        int iL;
        boolean zC;
        boolean z3;
        U0.d dVar2;
        boolean z5;
        boolean z10;
        boolean z11;
        V0.c cVar2;
        int i15;
        U0.d dVar3;
        U0.d dVar4;
        int i16;
        boolean zU;
        ArrayList arrayList;
        int size2;
        U0.d[] dVarArr;
        U0.d dVar5;
        boolean z12;
        boolean z13;
        int iMax3;
        int iMax4;
        int i17;
        boolean z14;
        boolean z15;
        boolean z16;
        V0.c cVar3;
        int i18;
        int i19;
        ArrayList arrayList2;
        int i20;
        e eVar;
        int iR3;
        int iL2;
        ArrayList arrayList3;
        int i21;
        int iR4;
        boolean z17;
        int iL3;
        e eVar2;
        int iR5;
        int iL4;
        boolean z18;
        boolean z19;
        V0.c cVar4;
        int iR6;
        boolean z20;
        int iL5;
        boolean z21;
        int size3;
        V0.c cVar5;
        int i22;
        ConstraintLayout constraintLayout;
        int childCount;
        int i23;
        ArrayList arrayList4;
        int size4;
        int i24;
        View childAt;
        Placeholder placeholder;
        LayoutParams layoutParams;
        e eVar3;
        e eVar4;
        e eVar5;
        e eVar6;
        U0.d dVarK;
        U0.d dVarK2;
        boolean z22;
        l lVar;
        n nVar;
        int iMin;
        boolean z23;
        boolean z24;
        f fVar3;
        int i25;
        int i26;
        ArrayList arrayList5;
        int size5;
        int i27;
        boolean z25;
        boolean z26;
        int i28;
        int i29;
        boolean z27;
        boolean z28;
        int i30;
        e eVar7;
        boolean z29;
        U0.d[] dVarArr2;
        boolean z30;
        boolean z31;
        boolean z32;
        int mode = View.MeasureSpec.getMode(i11);
        int size6 = View.MeasureSpec.getSize(i11);
        int mode2 = View.MeasureSpec.getMode(i12);
        int size7 = View.MeasureSpec.getSize(i12);
        int iMax5 = Math.max(0, getPaddingTop());
        int iMax6 = Math.max(0, getPaddingBottom());
        int i31 = iMax5 + iMax6;
        int paddingWidth = getPaddingWidth();
        b bVar = this.f16132y;
        bVar.f16225b = iMax5;
        bVar.f16226c = iMax6;
        bVar.f16227d = paddingWidth;
        bVar.f16228e = i31;
        bVar.f16229f = i11;
        bVar.f16230g = i12;
        int iMax7 = Math.max(0, getPaddingStart());
        int iMax8 = Math.max(0, getPaddingEnd());
        if (iMax7 <= 0 && iMax8 <= 0) {
            iMax7 = Math.max(0, getPaddingLeft());
        } else if (k()) {
            iMax7 = iMax8;
        }
        int i32 = size6 - paddingWidth;
        int i33 = size7 - i31;
        int i34 = bVar.f16228e;
        int i35 = bVar.f16227d;
        U0.d dVar6 = U0.d.f12154a;
        int childCount2 = getChildCount();
        U0.d dVar7 = U0.d.f12155b;
        int i36 = Integer.MIN_VALUE;
        if (mode != Integer.MIN_VALUE) {
            if (mode == 0) {
                if (childCount2 == 0) {
                    iMax = Math.max(0, this.f16121d);
                } else {
                    iMax = 0;
                }
                i36 = Integer.MIN_VALUE;
            } else if (mode != 1073741824) {
                i34 = i34;
                dVar7 = dVar6;
                iMax = 0;
            } else {
                iMax = Math.min(this.f16123f - i35, i32);
                i34 = i34;
                dVar7 = dVar6;
            }
            if (mode2 != i36) {
                if (mode2 != 0) {
                    if (mode2 != 1073741824) {
                        dVar = dVar6;
                        iMax2 = 0;
                    } else {
                        iMax2 = Math.min(this.f16124q - i34, i33);
                        dVar = dVar6;
                    }
                } else if (childCount2 == 0) {
                    dVar = dVar7;
                    iMax2 = Math.max(0, this.f16122e);
                } else {
                    iMax2 = 0;
                }
                iR = fVar.r();
                fVar2 = fVar.f12245w0;
                if (iMax == iR || iMax2 != fVar.l()) {
                    fVar2.f12814c = true;
                }
                fVar.f12185a0 = 0;
                fVar.f12187b0 = 0;
                int i37 = this.f16123f - i35;
                int[] iArr = fVar.f12161C;
                iArr[0] = i37;
                iArr[1] = this.f16124q - i34;
                fVar.f12191d0 = 0;
                fVar.f12193e0 = 0;
                fVar.N(dVar7);
                fVar.P(iMax);
                fVar.O(dVar);
                fVar.M(iMax2);
                i13 = this.f16121d - i35;
                if (i13 < 0) {
                    fVar.f12191d0 = 0;
                } else {
                    fVar.f12191d0 = i13;
                }
                i14 = this.f16122e - i34;
                if (i14 < 0) {
                    fVar.f12193e0 = 0;
                } else {
                    fVar.f12193e0 = i14;
                }
                fVar.f12230B0 = iMax7;
                fVar.f12231C0 = iMax5;
                c0057h = fVar.v0;
                c0057h.getClass();
                cVar = fVar.f12247y0;
                size = fVar.f12244u0.size();
                iR2 = fVar.r();
                iL = fVar.l();
                zC = U0.k.c(i10, 128);
                if (!zC || U0.k.c(i10, 64)) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                dVar2 = U0.d.f12156c;
                if (z3) {
                    i30 = 0;
                    while (true) {
                        if (i30 < size) {
                            eVar7 = (e) fVar.f12244u0.get(i30);
                            z29 = z3;
                            dVarArr2 = eVar7.f12178U;
                            if (dVarArr2[0] == dVar2) {
                                z30 = true;
                            } else {
                                z30 = false;
                            }
                            if (dVarArr2[1] == dVar2) {
                                z31 = true;
                            } else {
                                z31 = false;
                            }
                            if (z30 || !z31 || eVar7.f12182Y <= 0.0f) {
                                z32 = false;
                            } else {
                                z32 = true;
                            }
                            if ((eVar7.y() || !z32) && !((eVar7.z() && z32) || (eVar7 instanceof U0.m) || eVar7.y() || eVar7.z())) {
                                i30++;
                                z3 = z29;
                            } else {
                                z5 = false;
                            }
                        } else {
                            z5 = z3;
                        }
                    }
                } else {
                    z5 = z3;
                }
                z10 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
                if (z10) {
                    int iMin2 = Math.min(fVar.f12161C[0], i32);
                    iMin = Math.min(fVar.f12161C[1], i33);
                    if (mode == 1073741824 || fVar.r() == iMin2) {
                        z23 = true;
                    } else {
                        fVar.P(iMin2);
                        z23 = true;
                        fVar.f12245w0.f12813b = true;
                    }
                    if (mode2 == 1073741824 && fVar.l() != iMin) {
                        fVar.M(iMin);
                        fVar.f12245w0.f12813b = z23;
                    }
                    if (mode == 1073741824 || mode2 != 1073741824) {
                        z11 = z10;
                        cVar2 = cVar;
                        i15 = size;
                        dVar3 = dVar6;
                        dVar4 = dVar7;
                        z24 = fVar2.f12813b;
                        fVar3 = fVar2.f12812a;
                        if (z24) {
                            arrayList5 = fVar3.f12244u0;
                            i27 = 0;
                            for (size5 = arrayList5.size(); i27 < size5; size5 = size5) {
                                Object obj = arrayList5.get(i27);
                                i27++;
                                e eVar8 = (e) obj;
                                eVar8.i();
                                eVar8.f12184a = false;
                                ArrayList arrayList6 = arrayList5;
                                l lVar2 = eVar8.f12190d;
                                lVar2.f12846e.f12829j = false;
                                lVar2.f12848g = false;
                                lVar2.n();
                                n nVar2 = eVar8.f12192e;
                                nVar2.f12846e.f12829j = false;
                                nVar2.f12848g = false;
                                nVar2.m();
                                arrayList5 = arrayList6;
                            }
                            i25 = 0;
                            fVar3.i();
                            fVar3.f12184a = false;
                            l lVar3 = fVar3.f12190d;
                            lVar3.f12846e.f12829j = false;
                            lVar3.f12848g = false;
                            lVar3.n();
                            n nVar3 = fVar3.f12192e;
                            nVar3.f12846e.f12829j = false;
                            nVar3.f12848g = false;
                            nVar3.m();
                            fVar2.c();
                        } else {
                            i25 = 0;
                        }
                        fVar2.b(fVar2.f12815d);
                        fVar3.f12185a0 = i25;
                        fVar3.f12187b0 = i25;
                        fVar3.f12190d.f12849h.d(i25);
                        fVar3.f12192e.f12849h.d(i25);
                        i26 = 1073741824;
                        if (mode == 1073741824) {
                            zU = fVar.U(i25, zC);
                            i16 = 1;
                        } else {
                            i16 = 0;
                            zU = true;
                        }
                        if (mode2 == 1073741824) {
                            zU &= fVar.U(1, zC);
                            i16++;
                        }
                    } else {
                        boolean z33 = fVar2.f12813b;
                        f fVar4 = fVar2.f12812a;
                        if (z33 || fVar2.f12814c) {
                            ArrayList arrayList7 = fVar4.f12244u0;
                            int size8 = arrayList7.size();
                            int i38 = 0;
                            while (i38 < size8) {
                                Object obj2 = arrayList7.get(i38);
                                i38++;
                                boolean z34 = z10;
                                e eVar9 = (e) obj2;
                                eVar9.i();
                                eVar9.f12184a = false;
                                eVar9.f12190d.n();
                                eVar9.f12192e.m();
                                arrayList7 = arrayList7;
                                z10 = z34;
                            }
                            z11 = z10;
                            fVar4.i();
                            i28 = 0;
                            fVar4.f12184a = false;
                            fVar4.f12190d.n();
                            fVar4.f12192e.m();
                            fVar2.f12814c = false;
                        } else {
                            z11 = z10;
                            i28 = 0;
                        }
                        fVar2.b(fVar2.f12815d);
                        fVar4.f12185a0 = i28;
                        fVar4.f12187b0 = i28;
                        U0.d dVarK3 = fVar4.k(i28);
                        U0.d dVarK4 = fVar4.k(1);
                        if (fVar2.f12813b) {
                            fVar2.c();
                        }
                        int iS = fVar4.s();
                        int iT = fVar4.t();
                        i15 = size;
                        fVar4.f12190d.f12849h.d(iS);
                        fVar4.f12192e.f12849h.d(iT);
                        fVar2.g();
                        ArrayList arrayList8 = fVar2.f12816e;
                        dVar4 = dVar7;
                        if (dVarK3 == dVar4 || dVarK4 == dVar4) {
                            if (zC) {
                                i29 = iT;
                                int size9 = arrayList8.size();
                                cVar2 = cVar;
                                int i39 = 0;
                                while (i39 < size9) {
                                    Object obj3 = arrayList8.get(i39);
                                    i39++;
                                    if (!((p) obj3).k()) {
                                        zC = false;
                                        break;
                                    }
                                }
                            } else {
                                cVar2 = cVar;
                                i29 = iT;
                            }
                            if (zC && dVarK3 == dVar4) {
                                dVar3 = dVar6;
                                fVar4.N(dVar3);
                                fVar4.P(fVar2.d(fVar4, 0));
                                fVar4.f12190d.f12846e.d(fVar4.r());
                            } else {
                                dVar3 = dVar6;
                            }
                            if (zC && dVarK4 == dVar4) {
                                fVar4.O(dVar3);
                                fVar4.M(fVar2.d(fVar4, 1));
                                fVar4.f12192e.f12846e.d(fVar4.l());
                            }
                        } else {
                            cVar2 = cVar;
                            i29 = iT;
                            dVar3 = dVar6;
                        }
                        U0.d dVar8 = fVar4.f12178U[0];
                        U0.d dVar9 = U0.d.f12157d;
                        if (dVar8 == dVar3 || dVar8 == dVar9) {
                            int iR7 = fVar4.r() + iS;
                            fVar4.f12190d.f12850i.d(iR7);
                            fVar4.f12190d.f12846e.d(iR7 - iS);
                            fVar2.g();
                            U0.d dVar10 = fVar4.f12178U[1];
                            if (dVar10 == dVar3 || dVar10 == dVar9) {
                                int iL6 = fVar4.l() + i29;
                                fVar4.f12192e.f12850i.d(iL6);
                                fVar4.f12192e.f12846e.d(iL6 - i29);
                            }
                            fVar2.g();
                            z27 = true;
                        } else {
                            z27 = false;
                        }
                        int size10 = arrayList8.size();
                        int i40 = 0;
                        while (i40 < size10) {
                            Object obj4 = arrayList8.get(i40);
                            i40++;
                            p pVar = (p) obj4;
                            boolean z35 = z27;
                            if (pVar.f12843b != fVar4 || pVar.f12848g) {
                                pVar.e();
                            }
                            z27 = z35;
                        }
                        boolean z36 = z27;
                        int size11 = arrayList8.size();
                        int i41 = 0;
                        while (true) {
                            if (i41 >= size11) {
                                z28 = true;
                                break;
                            }
                            Object obj5 = arrayList8.get(i41);
                            i41++;
                            p pVar2 = (p) obj5;
                            if (z36 || pVar2.f12843b != fVar4) {
                                if (!pVar2.f12849h.f12829j || ((!pVar2.f12850i.f12829j && !(pVar2 instanceof j)) || (!pVar2.f12846e.f12829j && !(pVar2 instanceof V0.d) && !(pVar2 instanceof j)))) {
                                    z28 = false;
                                    break;
                                }
                            }
                        }
                        fVar4.N(dVarK3);
                        fVar4.O(dVarK4);
                        zU = z28;
                        i16 = 2;
                        i26 = 1073741824;
                    }
                    if (zU) {
                        if (mode == i26) {
                            z25 = true;
                        } else {
                            z25 = false;
                        }
                        if (mode2 == i26) {
                            z26 = true;
                        } else {
                            z26 = false;
                        }
                        fVar.Q(z25, z26);
                    }
                } else {
                    z11 = z10;
                    cVar2 = cVar;
                    i15 = size;
                    dVar3 = dVar6;
                    dVar4 = dVar7;
                    i16 = 0;
                    zU = false;
                }
                if (zU || i16 != 2) {
                    int i42 = fVar.f12236H0;
                    if (i15 > 0) {
                        size3 = fVar.f12244u0.size();
                        boolean zX = fVar.X(64);
                        cVar5 = fVar.f12247y0;
                        for (i22 = 0; i22 < size3; i22++) {
                            eVar6 = (e) fVar.f12244u0.get(i22);
                            if (!(eVar6 instanceof i) && !(eVar6 instanceof U0.a) && !eVar6.f12165G && (!zX || (lVar = eVar6.f12190d) == null || (nVar = eVar6.f12192e) == null || !lVar.f12846e.f12829j || !nVar.f12846e.f12829j)) {
                                dVarK = eVar6.k(0);
                                dVarK2 = eVar6.k(1);
                                if (dVarK == dVar2 || eVar6.f12217r == 1 || dVarK2 != dVar2 || eVar6.f12219s == 1) {
                                    z22 = false;
                                } else {
                                    z22 = true;
                                }
                                if (!z22 && fVar.X(1) && !(eVar6 instanceof U0.m)) {
                                    if (dVarK == dVar2 && eVar6.f12217r == 0 && dVarK2 != dVar2 && !eVar6.y()) {
                                        z22 = true;
                                    }
                                    if (dVarK2 == dVar2 && eVar6.f12219s == 0 && dVarK != dVar2 && !eVar6.y()) {
                                        z22 = true;
                                    }
                                    if ((dVarK != dVar2 || dVarK2 == dVar2) && eVar6.f12182Y > 0.0f) {
                                    }
                                }
                                if (z22) {
                                    c0057h.y(0, eVar6, cVar5);
                                }
                            }
                        }
                        constraintLayout = ((b) cVar5).f16224a;
                        childCount = constraintLayout.getChildCount();
                        for (i23 = 0; i23 < childCount; i23++) {
                            childAt = constraintLayout.getChildAt(i23);
                            if (childAt instanceof Placeholder) {
                                placeholder = (Placeholder) childAt;
                                if (placeholder.f16215b == null) {
                                    LayoutParams layoutParams2 = (LayoutParams) placeholder.getLayoutParams();
                                    layoutParams = (LayoutParams) placeholder.f16215b.getLayoutParams();
                                    eVar3 = layoutParams.f16190q0;
                                    eVar3.f12201i0 = 0;
                                    eVar4 = layoutParams2.f16190q0;
                                    if (eVar4.f12178U[0] != dVar3) {
                                        eVar4.P(eVar3.r());
                                    }
                                    eVar5 = layoutParams2.f16190q0;
                                    if (eVar5.f12178U[1] != dVar3) {
                                        eVar5.M(layoutParams.f16190q0.l());
                                    }
                                    layoutParams.f16190q0.f12201i0 = 8;
                                }
                            }
                        }
                        arrayList4 = constraintLayout.f16119b;
                        size4 = arrayList4.size();
                        if (size4 > 0) {
                            for (i24 = 0; i24 < size4; i24++) {
                                ((ConstraintHelper) arrayList4.get(i24)).getClass();
                            }
                        }
                    }
                    c0057h.F(fVar);
                    arrayList = (ArrayList) c0057h.f921b;
                    size2 = arrayList.size();
                    if (i15 > 0) {
                        c0057h.B(fVar, 0, iR2, iL);
                    }
                    if (size2 > 0) {
                        dVarArr = fVar.f12178U;
                        dVar5 = dVar4;
                        if (dVarArr[0] == dVar5) {
                            z12 = true;
                        } else {
                            z12 = false;
                        }
                        if (dVarArr[1] == dVar5) {
                            z13 = true;
                        } else {
                            z13 = false;
                        }
                        int iR8 = fVar.r();
                        f fVar5 = (f) c0057h.f923d;
                        iMax3 = Math.max(iR8, fVar5.f12191d0);
                        iMax4 = Math.max(fVar.l(), fVar5.f12193e0);
                        i17 = 0;
                        z14 = false;
                        while (i17 < size2) {
                            eVar2 = (e) arrayList.get(i17);
                            if (eVar2 instanceof U0.m) {
                                iR5 = eVar2.r();
                                iL4 = eVar2.l();
                                z18 = z13;
                                z19 = z12;
                                cVar4 = cVar2;
                                boolean zY = z14 | c0057h.y(1, eVar2, cVar4);
                                iR6 = eVar2.r();
                                z20 = zY;
                                iL5 = eVar2.l();
                                if (iR6 != iR5) {
                                    eVar2.P(iR6);
                                    if (z19 && eVar2.s() + eVar2.f12180W > iMax3) {
                                        iMax3 = Math.max(iMax3, eVar2.j(4).e() + eVar2.s() + eVar2.f12180W);
                                    }
                                    z20 = true;
                                }
                                if (iL5 != iL4) {
                                    eVar2.M(iL5);
                                    if (z18 && eVar2.t() + eVar2.f12181X > iMax4) {
                                        iMax4 = Math.max(iMax4, eVar2.j(5).e() + eVar2.t() + eVar2.f12181X);
                                    }
                                    z21 = true;
                                } else {
                                    z21 = z20;
                                }
                                z14 = z21 | ((U0.m) eVar2).f12299C0;
                            } else {
                                z18 = z13;
                                z19 = z12;
                                cVar4 = cVar2;
                            }
                            i17++;
                            cVar2 = cVar4;
                            z13 = z18;
                            z12 = z19;
                        }
                        z15 = z13;
                        z16 = z12;
                        cVar3 = cVar2;
                        i18 = 0;
                        while (i18 < 2) {
                            i19 = 0;
                            while (i19 < size2) {
                                eVar = (e) arrayList.get(i19);
                                if (((eVar instanceof U0.j) || (eVar instanceof U0.m)) && !(eVar instanceof i)) {
                                    if (eVar.f12201i0 == 8 && ((!z11 || !eVar.f12190d.f12846e.f12829j || !eVar.f12192e.f12846e.f12829j) && !(eVar instanceof U0.m))) {
                                        iR3 = eVar.r();
                                        iL2 = eVar.l();
                                        arrayList3 = arrayList;
                                        int i43 = eVar.f12189c0;
                                        i21 = size2;
                                        boolean zY2 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                                        iR4 = eVar.r();
                                        z17 = zY2;
                                        iL3 = eVar.l();
                                        if (iR4 != iR3) {
                                            eVar.P(iR4);
                                            if (!z16 && eVar.s() + eVar.f12180W > iMax3) {
                                                iMax3 = Math.max(iMax3, eVar.j(4).e() + eVar.s() + eVar.f12180W);
                                            }
                                            z17 = true;
                                        }
                                        if (iL3 != iL2) {
                                            eVar.M(iL3);
                                            if (!z15 && eVar.t() + eVar.f12181X > iMax4) {
                                                iMax4 = Math.max(iMax4, eVar.j(5).e() + eVar.t() + eVar.f12181X);
                                            }
                                            z17 = true;
                                        }
                                        if (eVar.f12163E || i43 == eVar.f12189c0) {
                                            z14 = z17;
                                        } else {
                                            z14 = true;
                                        }
                                    }
                                    i19++;
                                    arrayList = arrayList3;
                                    size2 = i21;
                                }
                                arrayList3 = arrayList;
                                i21 = size2;
                                i19++;
                                arrayList = arrayList3;
                                size2 = i21;
                            }
                            arrayList2 = arrayList;
                            i20 = size2;
                            if (z14) {
                                break;
                            }
                            i18++;
                            c0057h.B(fVar, i18, iR2, iL);
                            arrayList = arrayList2;
                            size2 = i20;
                            z14 = false;
                        }
                    }
                    fVar.f12236H0 = i42;
                    S0.c.f11231q = fVar.X(512);
                }
                return;
            }
            if (childCount2 == 0) {
                iMax2 = Math.max(0, this.f16122e);
            } else {
                iMax2 = i33;
            }
            dVar = dVar7;
            iR = fVar.r();
            fVar2 = fVar.f12245w0;
            if (iMax == iR) {
                fVar2.f12814c = true;
            } else {
                fVar2.f12814c = true;
            }
            fVar.f12185a0 = 0;
            fVar.f12187b0 = 0;
            int i310 = this.f16123f - i35;
            int[] iArr2 = fVar.f12161C;
            iArr2[0] = i310;
            iArr2[1] = this.f16124q - i34;
            fVar.f12191d0 = 0;
            fVar.f12193e0 = 0;
            fVar.N(dVar7);
            fVar.P(iMax);
            fVar.O(dVar);
            fVar.M(iMax2);
            i13 = this.f16121d - i35;
            if (i13 < 0) {
                fVar.f12191d0 = 0;
            } else {
                fVar.f12191d0 = i13;
            }
            i14 = this.f16122e - i34;
            if (i14 < 0) {
                fVar.f12193e0 = 0;
            } else {
                fVar.f12193e0 = i14;
            }
            fVar.f12230B0 = iMax7;
            fVar.f12231C0 = iMax5;
            c0057h = fVar.v0;
            c0057h.getClass();
            cVar = fVar.f12247y0;
            size = fVar.f12244u0.size();
            iR2 = fVar.r();
            iL = fVar.l();
            zC = U0.k.c(i10, 128);
            if (zC) {
                z3 = true;
            } else {
                z3 = true;
            }
            dVar2 = U0.d.f12156c;
            if (z3) {
                i30 = 0;
                while (true) {
                    if (i30 < size) {
                        eVar7 = (e) fVar.f12244u0.get(i30);
                        z29 = z3;
                        dVarArr2 = eVar7.f12178U;
                        if (dVarArr2[0] == dVar2) {
                            z30 = true;
                        } else {
                            z30 = false;
                        }
                        if (dVarArr2[1] == dVar2) {
                            z31 = true;
                        } else {
                            z31 = false;
                        }
                        if (z30) {
                            z32 = false;
                        } else {
                            z32 = false;
                        }
                        if (eVar7.y()) {
                            i30++;
                            z3 = z29;
                        } else {
                            i30++;
                            z3 = z29;
                        }
                        z5 = false;
                    } else {
                        z5 = z3;
                    }
                }
            } else {
                z5 = z3;
            }
            z10 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
            if (z10) {
                int iMin3 = Math.min(fVar.f12161C[0], i32);
                iMin = Math.min(fVar.f12161C[1], i33);
                if (mode == 1073741824) {
                    z23 = true;
                } else {
                    z23 = true;
                }
                if (mode2 == 1073741824) {
                    fVar.M(iMin);
                    fVar.f12245w0.f12813b = z23;
                }
                if (mode == 1073741824) {
                    z11 = z10;
                    cVar2 = cVar;
                    i15 = size;
                    dVar3 = dVar6;
                    dVar4 = dVar7;
                    z24 = fVar2.f12813b;
                    fVar3 = fVar2.f12812a;
                    if (z24) {
                        arrayList5 = fVar3.f12244u0;
                        i27 = 0;
                        while (i27 < size5) {
                            Object obj6 = arrayList5.get(i27);
                            i27++;
                            e eVar10 = (e) obj6;
                            eVar10.i();
                            eVar10.f12184a = false;
                            ArrayList arrayList9 = arrayList5;
                            l lVar4 = eVar10.f12190d;
                            lVar4.f12846e.f12829j = false;
                            lVar4.f12848g = false;
                            lVar4.n();
                            n nVar4 = eVar10.f12192e;
                            nVar4.f12846e.f12829j = false;
                            nVar4.f12848g = false;
                            nVar4.m();
                            arrayList5 = arrayList9;
                        }
                        i25 = 0;
                        fVar3.i();
                        fVar3.f12184a = false;
                        l lVar5 = fVar3.f12190d;
                        lVar5.f12846e.f12829j = false;
                        lVar5.f12848g = false;
                        lVar5.n();
                        n nVar5 = fVar3.f12192e;
                        nVar5.f12846e.f12829j = false;
                        nVar5.f12848g = false;
                        nVar5.m();
                        fVar2.c();
                    } else {
                        i25 = 0;
                    }
                    fVar2.b(fVar2.f12815d);
                    fVar3.f12185a0 = i25;
                    fVar3.f12187b0 = i25;
                    fVar3.f12190d.f12849h.d(i25);
                    fVar3.f12192e.f12849h.d(i25);
                    i26 = 1073741824;
                    if (mode == 1073741824) {
                        zU = fVar.U(i25, zC);
                        i16 = 1;
                    } else {
                        i16 = 0;
                        zU = true;
                    }
                    if (mode2 == 1073741824) {
                        zU &= fVar.U(1, zC);
                        i16++;
                    }
                } else {
                    z11 = z10;
                    cVar2 = cVar;
                    i15 = size;
                    dVar3 = dVar6;
                    dVar4 = dVar7;
                    z24 = fVar2.f12813b;
                    fVar3 = fVar2.f12812a;
                    if (z24) {
                        arrayList5 = fVar3.f12244u0;
                        i27 = 0;
                        while (i27 < size5) {
                            Object obj7 = arrayList5.get(i27);
                            i27++;
                            e eVar11 = (e) obj7;
                            eVar11.i();
                            eVar11.f12184a = false;
                            ArrayList arrayList10 = arrayList5;
                            l lVar6 = eVar11.f12190d;
                            lVar6.f12846e.f12829j = false;
                            lVar6.f12848g = false;
                            lVar6.n();
                            n nVar6 = eVar11.f12192e;
                            nVar6.f12846e.f12829j = false;
                            nVar6.f12848g = false;
                            nVar6.m();
                            arrayList5 = arrayList10;
                        }
                        i25 = 0;
                        fVar3.i();
                        fVar3.f12184a = false;
                        l lVar7 = fVar3.f12190d;
                        lVar7.f12846e.f12829j = false;
                        lVar7.f12848g = false;
                        lVar7.n();
                        n nVar7 = fVar3.f12192e;
                        nVar7.f12846e.f12829j = false;
                        nVar7.f12848g = false;
                        nVar7.m();
                        fVar2.c();
                    } else {
                        i25 = 0;
                    }
                    fVar2.b(fVar2.f12815d);
                    fVar3.f12185a0 = i25;
                    fVar3.f12187b0 = i25;
                    fVar3.f12190d.f12849h.d(i25);
                    fVar3.f12192e.f12849h.d(i25);
                    i26 = 1073741824;
                    if (mode == 1073741824) {
                        zU = fVar.U(i25, zC);
                        i16 = 1;
                    } else {
                        i16 = 0;
                        zU = true;
                    }
                    if (mode2 == 1073741824) {
                        zU &= fVar.U(1, zC);
                        i16++;
                    }
                }
                if (zU) {
                    if (mode == i26) {
                        z25 = true;
                    } else {
                        z25 = false;
                    }
                    if (mode2 == i26) {
                        z26 = true;
                    } else {
                        z26 = false;
                    }
                    fVar.Q(z25, z26);
                }
            } else {
                z11 = z10;
                cVar2 = cVar;
                i15 = size;
                dVar3 = dVar6;
                dVar4 = dVar7;
                i16 = 0;
                zU = false;
            }
            if (zU) {
            }
            int i44 = fVar.f12236H0;
            if (i15 > 0) {
                size3 = fVar.f12244u0.size();
                boolean zX2 = fVar.X(64);
                cVar5 = fVar.f12247y0;
                while (i22 < size3) {
                    eVar6 = (e) fVar.f12244u0.get(i22);
                    if (!(eVar6 instanceof i)) {
                        dVarK = eVar6.k(0);
                        dVarK2 = eVar6.k(1);
                        if (dVarK == dVar2) {
                            z22 = false;
                        } else {
                            z22 = false;
                        }
                        if (!z22) {
                            if (dVarK == dVar2) {
                                z22 = true;
                            }
                            if (dVarK2 == dVar2) {
                                z22 = true;
                            }
                            z22 = dVarK != dVar2 ? true : true;
                        }
                        if (z22) {
                            c0057h.y(0, eVar6, cVar5);
                        }
                    }
                }
                constraintLayout = ((b) cVar5).f16224a;
                childCount = constraintLayout.getChildCount();
                while (i23 < childCount) {
                    childAt = constraintLayout.getChildAt(i23);
                    if (childAt instanceof Placeholder) {
                        placeholder = (Placeholder) childAt;
                        if (placeholder.f16215b == null) {
                            LayoutParams layoutParams3 = (LayoutParams) placeholder.getLayoutParams();
                            layoutParams = (LayoutParams) placeholder.f16215b.getLayoutParams();
                            eVar3 = layoutParams.f16190q0;
                            eVar3.f12201i0 = 0;
                            eVar4 = layoutParams3.f16190q0;
                            if (eVar4.f12178U[0] != dVar3) {
                                eVar4.P(eVar3.r());
                            }
                            eVar5 = layoutParams3.f16190q0;
                            if (eVar5.f12178U[1] != dVar3) {
                                eVar5.M(layoutParams.f16190q0.l());
                            }
                            layoutParams.f16190q0.f12201i0 = 8;
                        }
                    }
                }
                arrayList4 = constraintLayout.f16119b;
                size4 = arrayList4.size();
                if (size4 > 0) {
                    while (i24 < size4) {
                        ((ConstraintHelper) arrayList4.get(i24)).getClass();
                    }
                }
            }
            c0057h.F(fVar);
            arrayList = (ArrayList) c0057h.f921b;
            size2 = arrayList.size();
            if (i15 > 0) {
                c0057h.B(fVar, 0, iR2, iL);
            }
            if (size2 > 0) {
                dVarArr = fVar.f12178U;
                dVar5 = dVar4;
                if (dVarArr[0] == dVar5) {
                    z12 = true;
                } else {
                    z12 = false;
                }
                if (dVarArr[1] == dVar5) {
                    z13 = true;
                } else {
                    z13 = false;
                }
                int iR9 = fVar.r();
                f fVar6 = (f) c0057h.f923d;
                iMax3 = Math.max(iR9, fVar6.f12191d0);
                iMax4 = Math.max(fVar.l(), fVar6.f12193e0);
                i17 = 0;
                z14 = false;
                while (i17 < size2) {
                    eVar2 = (e) arrayList.get(i17);
                    if (eVar2 instanceof U0.m) {
                        z18 = z13;
                        z19 = z12;
                        cVar4 = cVar2;
                    } else {
                        iR5 = eVar2.r();
                        iL4 = eVar2.l();
                        z18 = z13;
                        z19 = z12;
                        cVar4 = cVar2;
                        boolean zY3 = z14 | c0057h.y(1, eVar2, cVar4);
                        iR6 = eVar2.r();
                        z20 = zY3;
                        iL5 = eVar2.l();
                        if (iR6 != iR5) {
                            eVar2.P(iR6);
                            if (z19) {
                                iMax3 = Math.max(iMax3, eVar2.j(4).e() + eVar2.s() + eVar2.f12180W);
                            }
                            z20 = true;
                        }
                        if (iL5 != iL4) {
                            eVar2.M(iL5);
                            if (z18) {
                                iMax4 = Math.max(iMax4, eVar2.j(5).e() + eVar2.t() + eVar2.f12181X);
                            }
                            z21 = true;
                        } else {
                            z21 = z20;
                        }
                        z14 = z21 | ((U0.m) eVar2).f12299C0;
                    }
                    i17++;
                    cVar2 = cVar4;
                    z13 = z18;
                    z12 = z19;
                }
                z15 = z13;
                z16 = z12;
                cVar3 = cVar2;
                i18 = 0;
                while (i18 < 2) {
                    i19 = 0;
                    while (i19 < size2) {
                        eVar = (e) arrayList.get(i19);
                        if (eVar instanceof U0.j) {
                            if (eVar.f12201i0 == 8) {
                                arrayList3 = arrayList;
                                i21 = size2;
                            } else {
                                iR3 = eVar.r();
                                iL2 = eVar.l();
                                arrayList3 = arrayList;
                                int i45 = eVar.f12189c0;
                                i21 = size2;
                                boolean zY4 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                                iR4 = eVar.r();
                                z17 = zY4;
                                iL3 = eVar.l();
                                if (iR4 != iR3) {
                                    eVar.P(iR4);
                                    if (!z16) {
                                    }
                                    z17 = true;
                                }
                                if (iL3 != iL2) {
                                    eVar.M(iL3);
                                    if (!z15) {
                                    }
                                    z17 = true;
                                }
                                if (eVar.f12163E) {
                                    z14 = z17;
                                } else {
                                    z14 = z17;
                                }
                            }
                        } else if (eVar.f12201i0 == 8) {
                            arrayList3 = arrayList;
                            i21 = size2;
                        } else {
                            iR3 = eVar.r();
                            iL2 = eVar.l();
                            arrayList3 = arrayList;
                            int i46 = eVar.f12189c0;
                            i21 = size2;
                            boolean zY5 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                            iR4 = eVar.r();
                            z17 = zY5;
                            iL3 = eVar.l();
                            if (iR4 != iR3) {
                                eVar.P(iR4);
                                if (!z16) {
                                }
                                z17 = true;
                            }
                            if (iL3 != iL2) {
                                eVar.M(iL3);
                                if (!z15) {
                                }
                                z17 = true;
                            }
                            if (eVar.f12163E) {
                                z14 = z17;
                            } else {
                                z14 = z17;
                            }
                        }
                        i19++;
                        arrayList = arrayList3;
                        size2 = i21;
                    }
                    arrayList2 = arrayList;
                    i20 = size2;
                    if (z14) {
                        break;
                        break;
                    }
                    i18++;
                    c0057h.B(fVar, i18, iR2, iL);
                    arrayList = arrayList2;
                    size2 = i20;
                    z14 = false;
                }
            }
            fVar.f12236H0 = i44;
            S0.c.f11231q = fVar.X(512);
        }
        iMax = childCount2 == 0 ? Math.max(0, this.f16121d) : i32;
        i36 = Integer.MIN_VALUE;
        if (mode2 != i36) {
            if (mode2 != 0) {
                if (mode2 != 1073741824) {
                    dVar = dVar6;
                    iMax2 = 0;
                } else {
                    iMax2 = Math.min(this.f16124q - i34, i33);
                    dVar = dVar6;
                }
            } else if (childCount2 == 0) {
                dVar = dVar7;
                iMax2 = Math.max(0, this.f16122e);
            } else {
                iMax2 = 0;
            }
            iR = fVar.r();
            fVar2 = fVar.f12245w0;
            if (iMax == iR) {
                fVar2.f12814c = true;
            } else {
                fVar2.f12814c = true;
            }
            fVar.f12185a0 = 0;
            fVar.f12187b0 = 0;
            int i311 = this.f16123f - i35;
            int[] iArr3 = fVar.f12161C;
            iArr3[0] = i311;
            iArr3[1] = this.f16124q - i34;
            fVar.f12191d0 = 0;
            fVar.f12193e0 = 0;
            fVar.N(dVar7);
            fVar.P(iMax);
            fVar.O(dVar);
            fVar.M(iMax2);
            i13 = this.f16121d - i35;
            if (i13 < 0) {
                fVar.f12191d0 = 0;
            } else {
                fVar.f12191d0 = i13;
            }
            i14 = this.f16122e - i34;
            if (i14 < 0) {
                fVar.f12193e0 = 0;
            } else {
                fVar.f12193e0 = i14;
            }
            fVar.f12230B0 = iMax7;
            fVar.f12231C0 = iMax5;
            c0057h = fVar.v0;
            c0057h.getClass();
            cVar = fVar.f12247y0;
            size = fVar.f12244u0.size();
            iR2 = fVar.r();
            iL = fVar.l();
            zC = U0.k.c(i10, 128);
            if (zC) {
                z3 = true;
            } else {
                z3 = true;
            }
            dVar2 = U0.d.f12156c;
            if (z3) {
                i30 = 0;
                while (true) {
                    if (i30 < size) {
                        eVar7 = (e) fVar.f12244u0.get(i30);
                        z29 = z3;
                        dVarArr2 = eVar7.f12178U;
                        if (dVarArr2[0] == dVar2) {
                            z30 = true;
                        } else {
                            z30 = false;
                        }
                        if (dVarArr2[1] == dVar2) {
                            z31 = true;
                        } else {
                            z31 = false;
                        }
                        if (z30) {
                            z32 = false;
                        } else {
                            z32 = false;
                        }
                        if (eVar7.y()) {
                            i30++;
                            z3 = z29;
                        } else {
                            i30++;
                            z3 = z29;
                        }
                        z5 = false;
                    } else {
                        z5 = z3;
                    }
                }
            } else {
                z5 = z3;
            }
            z10 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
            if (z10) {
                int iMin4 = Math.min(fVar.f12161C[0], i32);
                iMin = Math.min(fVar.f12161C[1], i33);
                if (mode == 1073741824) {
                    z23 = true;
                } else {
                    z23 = true;
                }
                if (mode2 == 1073741824) {
                    fVar.M(iMin);
                    fVar.f12245w0.f12813b = z23;
                }
                if (mode == 1073741824) {
                    z11 = z10;
                    cVar2 = cVar;
                    i15 = size;
                    dVar3 = dVar6;
                    dVar4 = dVar7;
                    z24 = fVar2.f12813b;
                    fVar3 = fVar2.f12812a;
                    if (z24) {
                        arrayList5 = fVar3.f12244u0;
                        i27 = 0;
                        while (i27 < size5) {
                            Object obj8 = arrayList5.get(i27);
                            i27++;
                            e eVar12 = (e) obj8;
                            eVar12.i();
                            eVar12.f12184a = false;
                            ArrayList arrayList11 = arrayList5;
                            l lVar8 = eVar12.f12190d;
                            lVar8.f12846e.f12829j = false;
                            lVar8.f12848g = false;
                            lVar8.n();
                            n nVar8 = eVar12.f12192e;
                            nVar8.f12846e.f12829j = false;
                            nVar8.f12848g = false;
                            nVar8.m();
                            arrayList5 = arrayList11;
                        }
                        i25 = 0;
                        fVar3.i();
                        fVar3.f12184a = false;
                        l lVar9 = fVar3.f12190d;
                        lVar9.f12846e.f12829j = false;
                        lVar9.f12848g = false;
                        lVar9.n();
                        n nVar9 = fVar3.f12192e;
                        nVar9.f12846e.f12829j = false;
                        nVar9.f12848g = false;
                        nVar9.m();
                        fVar2.c();
                    } else {
                        i25 = 0;
                    }
                    fVar2.b(fVar2.f12815d);
                    fVar3.f12185a0 = i25;
                    fVar3.f12187b0 = i25;
                    fVar3.f12190d.f12849h.d(i25);
                    fVar3.f12192e.f12849h.d(i25);
                    i26 = 1073741824;
                    if (mode == 1073741824) {
                        zU = fVar.U(i25, zC);
                        i16 = 1;
                    } else {
                        i16 = 0;
                        zU = true;
                    }
                    if (mode2 == 1073741824) {
                        zU &= fVar.U(1, zC);
                        i16++;
                    }
                } else {
                    z11 = z10;
                    cVar2 = cVar;
                    i15 = size;
                    dVar3 = dVar6;
                    dVar4 = dVar7;
                    z24 = fVar2.f12813b;
                    fVar3 = fVar2.f12812a;
                    if (z24) {
                        arrayList5 = fVar3.f12244u0;
                        i27 = 0;
                        while (i27 < size5) {
                            Object obj9 = arrayList5.get(i27);
                            i27++;
                            e eVar13 = (e) obj9;
                            eVar13.i();
                            eVar13.f12184a = false;
                            ArrayList arrayList12 = arrayList5;
                            l lVar10 = eVar13.f12190d;
                            lVar10.f12846e.f12829j = false;
                            lVar10.f12848g = false;
                            lVar10.n();
                            n nVar10 = eVar13.f12192e;
                            nVar10.f12846e.f12829j = false;
                            nVar10.f12848g = false;
                            nVar10.m();
                            arrayList5 = arrayList12;
                        }
                        i25 = 0;
                        fVar3.i();
                        fVar3.f12184a = false;
                        l lVar11 = fVar3.f12190d;
                        lVar11.f12846e.f12829j = false;
                        lVar11.f12848g = false;
                        lVar11.n();
                        n nVar11 = fVar3.f12192e;
                        nVar11.f12846e.f12829j = false;
                        nVar11.f12848g = false;
                        nVar11.m();
                        fVar2.c();
                    } else {
                        i25 = 0;
                    }
                    fVar2.b(fVar2.f12815d);
                    fVar3.f12185a0 = i25;
                    fVar3.f12187b0 = i25;
                    fVar3.f12190d.f12849h.d(i25);
                    fVar3.f12192e.f12849h.d(i25);
                    i26 = 1073741824;
                    if (mode == 1073741824) {
                        zU = fVar.U(i25, zC);
                        i16 = 1;
                    } else {
                        i16 = 0;
                        zU = true;
                    }
                    if (mode2 == 1073741824) {
                        zU &= fVar.U(1, zC);
                        i16++;
                    }
                }
                if (zU) {
                    if (mode == i26) {
                        z25 = true;
                    } else {
                        z25 = false;
                    }
                    if (mode2 == i26) {
                        z26 = true;
                    } else {
                        z26 = false;
                    }
                    fVar.Q(z25, z26);
                }
            } else {
                z11 = z10;
                cVar2 = cVar;
                i15 = size;
                dVar3 = dVar6;
                dVar4 = dVar7;
                i16 = 0;
                zU = false;
            }
            if (zU) {
            }
            int i47 = fVar.f12236H0;
            if (i15 > 0) {
                size3 = fVar.f12244u0.size();
                boolean zX3 = fVar.X(64);
                cVar5 = fVar.f12247y0;
                while (i22 < size3) {
                    eVar6 = (e) fVar.f12244u0.get(i22);
                    if (!(eVar6 instanceof i)) {
                        dVarK = eVar6.k(0);
                        dVarK2 = eVar6.k(1);
                        if (dVarK == dVar2) {
                            z22 = false;
                        } else {
                            z22 = false;
                        }
                        if (!z22) {
                            if (dVarK == dVar2) {
                                z22 = true;
                            }
                            if (dVarK2 == dVar2) {
                                z22 = true;
                            }
                            if (dVarK != dVar2) {
                            }
                        }
                        if (z22) {
                            c0057h.y(0, eVar6, cVar5);
                        }
                    }
                }
                constraintLayout = ((b) cVar5).f16224a;
                childCount = constraintLayout.getChildCount();
                while (i23 < childCount) {
                    childAt = constraintLayout.getChildAt(i23);
                    if (childAt instanceof Placeholder) {
                        placeholder = (Placeholder) childAt;
                        if (placeholder.f16215b == null) {
                            LayoutParams layoutParams4 = (LayoutParams) placeholder.getLayoutParams();
                            layoutParams = (LayoutParams) placeholder.f16215b.getLayoutParams();
                            eVar3 = layoutParams.f16190q0;
                            eVar3.f12201i0 = 0;
                            eVar4 = layoutParams4.f16190q0;
                            if (eVar4.f12178U[0] != dVar3) {
                                eVar4.P(eVar3.r());
                            }
                            eVar5 = layoutParams4.f16190q0;
                            if (eVar5.f12178U[1] != dVar3) {
                                eVar5.M(layoutParams.f16190q0.l());
                            }
                            layoutParams.f16190q0.f12201i0 = 8;
                        }
                    }
                }
                arrayList4 = constraintLayout.f16119b;
                size4 = arrayList4.size();
                if (size4 > 0) {
                    while (i24 < size4) {
                        ((ConstraintHelper) arrayList4.get(i24)).getClass();
                    }
                }
            }
            c0057h.F(fVar);
            arrayList = (ArrayList) c0057h.f921b;
            size2 = arrayList.size();
            if (i15 > 0) {
                c0057h.B(fVar, 0, iR2, iL);
            }
            if (size2 > 0) {
                dVarArr = fVar.f12178U;
                dVar5 = dVar4;
                if (dVarArr[0] == dVar5) {
                    z12 = true;
                } else {
                    z12 = false;
                }
                if (dVarArr[1] == dVar5) {
                    z13 = true;
                } else {
                    z13 = false;
                }
                int iR10 = fVar.r();
                f fVar7 = (f) c0057h.f923d;
                iMax3 = Math.max(iR10, fVar7.f12191d0);
                iMax4 = Math.max(fVar.l(), fVar7.f12193e0);
                i17 = 0;
                z14 = false;
                while (i17 < size2) {
                    eVar2 = (e) arrayList.get(i17);
                    if (eVar2 instanceof U0.m) {
                        z18 = z13;
                        z19 = z12;
                        cVar4 = cVar2;
                    } else {
                        iR5 = eVar2.r();
                        iL4 = eVar2.l();
                        z18 = z13;
                        z19 = z12;
                        cVar4 = cVar2;
                        boolean zY6 = z14 | c0057h.y(1, eVar2, cVar4);
                        iR6 = eVar2.r();
                        z20 = zY6;
                        iL5 = eVar2.l();
                        if (iR6 != iR5) {
                            eVar2.P(iR6);
                            if (z19) {
                                iMax3 = Math.max(iMax3, eVar2.j(4).e() + eVar2.s() + eVar2.f12180W);
                            }
                            z20 = true;
                        }
                        if (iL5 != iL4) {
                            eVar2.M(iL5);
                            if (z18) {
                                iMax4 = Math.max(iMax4, eVar2.j(5).e() + eVar2.t() + eVar2.f12181X);
                            }
                            z21 = true;
                        } else {
                            z21 = z20;
                        }
                        z14 = z21 | ((U0.m) eVar2).f12299C0;
                    }
                    i17++;
                    cVar2 = cVar4;
                    z13 = z18;
                    z12 = z19;
                }
                z15 = z13;
                z16 = z12;
                cVar3 = cVar2;
                i18 = 0;
                while (i18 < 2) {
                    i19 = 0;
                    while (i19 < size2) {
                        eVar = (e) arrayList.get(i19);
                        if (eVar instanceof U0.j) {
                            if (eVar.f12201i0 == 8) {
                                arrayList3 = arrayList;
                                i21 = size2;
                            } else {
                                iR3 = eVar.r();
                                iL2 = eVar.l();
                                arrayList3 = arrayList;
                                int i48 = eVar.f12189c0;
                                i21 = size2;
                                boolean zY7 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                                iR4 = eVar.r();
                                z17 = zY7;
                                iL3 = eVar.l();
                                if (iR4 != iR3) {
                                    eVar.P(iR4);
                                    if (!z16) {
                                    }
                                    z17 = true;
                                }
                                if (iL3 != iL2) {
                                    eVar.M(iL3);
                                    if (!z15) {
                                    }
                                    z17 = true;
                                }
                                if (eVar.f12163E) {
                                    z14 = z17;
                                } else {
                                    z14 = z17;
                                }
                            }
                        } else if (eVar.f12201i0 == 8) {
                            arrayList3 = arrayList;
                            i21 = size2;
                        } else {
                            iR3 = eVar.r();
                            iL2 = eVar.l();
                            arrayList3 = arrayList;
                            int i49 = eVar.f12189c0;
                            i21 = size2;
                            boolean zY8 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                            iR4 = eVar.r();
                            z17 = zY8;
                            iL3 = eVar.l();
                            if (iR4 != iR3) {
                                eVar.P(iR4);
                                if (!z16) {
                                }
                                z17 = true;
                            }
                            if (iL3 != iL2) {
                                eVar.M(iL3);
                                if (!z15) {
                                }
                                z17 = true;
                            }
                            if (eVar.f12163E) {
                                z14 = z17;
                            } else {
                                z14 = z17;
                            }
                        }
                        i19++;
                        arrayList = arrayList3;
                        size2 = i21;
                    }
                    arrayList2 = arrayList;
                    i20 = size2;
                    if (z14) {
                        break;
                        break;
                    }
                    i18++;
                    c0057h.B(fVar, i18, iR2, iL);
                    arrayList = arrayList2;
                    size2 = i20;
                    z14 = false;
                }
            }
            fVar.f12236H0 = i47;
            S0.c.f11231q = fVar.X(512);
        }
        if (childCount2 == 0) {
            iMax2 = Math.max(0, this.f16122e);
        } else {
            iMax2 = i33;
        }
        dVar = dVar7;
        iR = fVar.r();
        fVar2 = fVar.f12245w0;
        if (iMax == iR) {
            fVar2.f12814c = true;
        } else {
            fVar2.f12814c = true;
        }
        fVar.f12185a0 = 0;
        fVar.f12187b0 = 0;
        int i312 = this.f16123f - i35;
        int[] iArr4 = fVar.f12161C;
        iArr4[0] = i312;
        iArr4[1] = this.f16124q - i34;
        fVar.f12191d0 = 0;
        fVar.f12193e0 = 0;
        fVar.N(dVar7);
        fVar.P(iMax);
        fVar.O(dVar);
        fVar.M(iMax2);
        i13 = this.f16121d - i35;
        if (i13 < 0) {
            fVar.f12191d0 = 0;
        } else {
            fVar.f12191d0 = i13;
        }
        i14 = this.f16122e - i34;
        if (i14 < 0) {
            fVar.f12193e0 = 0;
        } else {
            fVar.f12193e0 = i14;
        }
        fVar.f12230B0 = iMax7;
        fVar.f12231C0 = iMax5;
        c0057h = fVar.v0;
        c0057h.getClass();
        cVar = fVar.f12247y0;
        size = fVar.f12244u0.size();
        iR2 = fVar.r();
        iL = fVar.l();
        zC = U0.k.c(i10, 128);
        if (zC) {
            z3 = true;
        } else {
            z3 = true;
        }
        dVar2 = U0.d.f12156c;
        if (z3) {
            i30 = 0;
            while (true) {
                if (i30 < size) {
                    eVar7 = (e) fVar.f12244u0.get(i30);
                    z29 = z3;
                    dVarArr2 = eVar7.f12178U;
                    if (dVarArr2[0] == dVar2) {
                        z30 = true;
                    } else {
                        z30 = false;
                    }
                    if (dVarArr2[1] == dVar2) {
                        z31 = true;
                    } else {
                        z31 = false;
                    }
                    if (z30) {
                        z32 = false;
                    } else {
                        z32 = false;
                    }
                    if (eVar7.y()) {
                        i30++;
                        z3 = z29;
                    } else {
                        i30++;
                        z3 = z29;
                    }
                    z5 = false;
                } else {
                    z5 = z3;
                }
            }
        } else {
            z5 = z3;
        }
        z10 = z5 & ((mode != 1073741824 && mode2 == 1073741824) || zC);
        if (z10) {
            int iMin5 = Math.min(fVar.f12161C[0], i32);
            iMin = Math.min(fVar.f12161C[1], i33);
            if (mode == 1073741824) {
                z23 = true;
            } else {
                z23 = true;
            }
            if (mode2 == 1073741824) {
                fVar.M(iMin);
                fVar.f12245w0.f12813b = z23;
            }
            if (mode == 1073741824) {
                z11 = z10;
                cVar2 = cVar;
                i15 = size;
                dVar3 = dVar6;
                dVar4 = dVar7;
                z24 = fVar2.f12813b;
                fVar3 = fVar2.f12812a;
                if (z24) {
                    arrayList5 = fVar3.f12244u0;
                    i27 = 0;
                    while (i27 < size5) {
                        Object obj10 = arrayList5.get(i27);
                        i27++;
                        e eVar14 = (e) obj10;
                        eVar14.i();
                        eVar14.f12184a = false;
                        ArrayList arrayList13 = arrayList5;
                        l lVar12 = eVar14.f12190d;
                        lVar12.f12846e.f12829j = false;
                        lVar12.f12848g = false;
                        lVar12.n();
                        n nVar12 = eVar14.f12192e;
                        nVar12.f12846e.f12829j = false;
                        nVar12.f12848g = false;
                        nVar12.m();
                        arrayList5 = arrayList13;
                    }
                    i25 = 0;
                    fVar3.i();
                    fVar3.f12184a = false;
                    l lVar13 = fVar3.f12190d;
                    lVar13.f12846e.f12829j = false;
                    lVar13.f12848g = false;
                    lVar13.n();
                    n nVar13 = fVar3.f12192e;
                    nVar13.f12846e.f12829j = false;
                    nVar13.f12848g = false;
                    nVar13.m();
                    fVar2.c();
                } else {
                    i25 = 0;
                }
                fVar2.b(fVar2.f12815d);
                fVar3.f12185a0 = i25;
                fVar3.f12187b0 = i25;
                fVar3.f12190d.f12849h.d(i25);
                fVar3.f12192e.f12849h.d(i25);
                i26 = 1073741824;
                if (mode == 1073741824) {
                    zU = fVar.U(i25, zC);
                    i16 = 1;
                } else {
                    i16 = 0;
                    zU = true;
                }
                if (mode2 == 1073741824) {
                    zU &= fVar.U(1, zC);
                    i16++;
                }
            } else {
                z11 = z10;
                cVar2 = cVar;
                i15 = size;
                dVar3 = dVar6;
                dVar4 = dVar7;
                z24 = fVar2.f12813b;
                fVar3 = fVar2.f12812a;
                if (z24) {
                    arrayList5 = fVar3.f12244u0;
                    i27 = 0;
                    while (i27 < size5) {
                        Object obj11 = arrayList5.get(i27);
                        i27++;
                        e eVar15 = (e) obj11;
                        eVar15.i();
                        eVar15.f12184a = false;
                        ArrayList arrayList14 = arrayList5;
                        l lVar14 = eVar15.f12190d;
                        lVar14.f12846e.f12829j = false;
                        lVar14.f12848g = false;
                        lVar14.n();
                        n nVar14 = eVar15.f12192e;
                        nVar14.f12846e.f12829j = false;
                        nVar14.f12848g = false;
                        nVar14.m();
                        arrayList5 = arrayList14;
                    }
                    i25 = 0;
                    fVar3.i();
                    fVar3.f12184a = false;
                    l lVar15 = fVar3.f12190d;
                    lVar15.f12846e.f12829j = false;
                    lVar15.f12848g = false;
                    lVar15.n();
                    n nVar15 = fVar3.f12192e;
                    nVar15.f12846e.f12829j = false;
                    nVar15.f12848g = false;
                    nVar15.m();
                    fVar2.c();
                } else {
                    i25 = 0;
                }
                fVar2.b(fVar2.f12815d);
                fVar3.f12185a0 = i25;
                fVar3.f12187b0 = i25;
                fVar3.f12190d.f12849h.d(i25);
                fVar3.f12192e.f12849h.d(i25);
                i26 = 1073741824;
                if (mode == 1073741824) {
                    zU = fVar.U(i25, zC);
                    i16 = 1;
                } else {
                    i16 = 0;
                    zU = true;
                }
                if (mode2 == 1073741824) {
                    zU &= fVar.U(1, zC);
                    i16++;
                }
            }
            if (zU) {
                if (mode == i26) {
                    z25 = true;
                } else {
                    z25 = false;
                }
                if (mode2 == i26) {
                    z26 = true;
                } else {
                    z26 = false;
                }
                fVar.Q(z25, z26);
            }
        } else {
            z11 = z10;
            cVar2 = cVar;
            i15 = size;
            dVar3 = dVar6;
            dVar4 = dVar7;
            i16 = 0;
            zU = false;
        }
        if (zU) {
        }
        int i410 = fVar.f12236H0;
        if (i15 > 0) {
            size3 = fVar.f12244u0.size();
            boolean zX4 = fVar.X(64);
            cVar5 = fVar.f12247y0;
            while (i22 < size3) {
                eVar6 = (e) fVar.f12244u0.get(i22);
                if (!(eVar6 instanceof i)) {
                    dVarK = eVar6.k(0);
                    dVarK2 = eVar6.k(1);
                    if (dVarK == dVar2) {
                        z22 = false;
                    } else {
                        z22 = false;
                    }
                    if (!z22) {
                        if (dVarK == dVar2) {
                            z22 = true;
                        }
                        if (dVarK2 == dVar2) {
                            z22 = true;
                        }
                        if (dVarK != dVar2) {
                        }
                    }
                    if (z22) {
                        c0057h.y(0, eVar6, cVar5);
                    }
                }
            }
            constraintLayout = ((b) cVar5).f16224a;
            childCount = constraintLayout.getChildCount();
            while (i23 < childCount) {
                childAt = constraintLayout.getChildAt(i23);
                if (childAt instanceof Placeholder) {
                    placeholder = (Placeholder) childAt;
                    if (placeholder.f16215b == null) {
                        LayoutParams layoutParams5 = (LayoutParams) placeholder.getLayoutParams();
                        layoutParams = (LayoutParams) placeholder.f16215b.getLayoutParams();
                        eVar3 = layoutParams.f16190q0;
                        eVar3.f12201i0 = 0;
                        eVar4 = layoutParams5.f16190q0;
                        if (eVar4.f12178U[0] != dVar3) {
                            eVar4.P(eVar3.r());
                        }
                        eVar5 = layoutParams5.f16190q0;
                        if (eVar5.f12178U[1] != dVar3) {
                            eVar5.M(layoutParams.f16190q0.l());
                        }
                        layoutParams.f16190q0.f12201i0 = 8;
                    }
                }
            }
            arrayList4 = constraintLayout.f16119b;
            size4 = arrayList4.size();
            if (size4 > 0) {
                while (i24 < size4) {
                    ((ConstraintHelper) arrayList4.get(i24)).getClass();
                }
            }
        }
        c0057h.F(fVar);
        arrayList = (ArrayList) c0057h.f921b;
        size2 = arrayList.size();
        if (i15 > 0) {
            c0057h.B(fVar, 0, iR2, iL);
        }
        if (size2 > 0) {
            dVarArr = fVar.f12178U;
            dVar5 = dVar4;
            if (dVarArr[0] == dVar5) {
                z12 = true;
            } else {
                z12 = false;
            }
            if (dVarArr[1] == dVar5) {
                z13 = true;
            } else {
                z13 = false;
            }
            int iR11 = fVar.r();
            f fVar8 = (f) c0057h.f923d;
            iMax3 = Math.max(iR11, fVar8.f12191d0);
            iMax4 = Math.max(fVar.l(), fVar8.f12193e0);
            i17 = 0;
            z14 = false;
            while (i17 < size2) {
                eVar2 = (e) arrayList.get(i17);
                if (eVar2 instanceof U0.m) {
                    z18 = z13;
                    z19 = z12;
                    cVar4 = cVar2;
                } else {
                    iR5 = eVar2.r();
                    iL4 = eVar2.l();
                    z18 = z13;
                    z19 = z12;
                    cVar4 = cVar2;
                    boolean zY9 = z14 | c0057h.y(1, eVar2, cVar4);
                    iR6 = eVar2.r();
                    z20 = zY9;
                    iL5 = eVar2.l();
                    if (iR6 != iR5) {
                        eVar2.P(iR6);
                        if (z19) {
                            iMax3 = Math.max(iMax3, eVar2.j(4).e() + eVar2.s() + eVar2.f12180W);
                        }
                        z20 = true;
                    }
                    if (iL5 != iL4) {
                        eVar2.M(iL5);
                        if (z18) {
                            iMax4 = Math.max(iMax4, eVar2.j(5).e() + eVar2.t() + eVar2.f12181X);
                        }
                        z21 = true;
                    } else {
                        z21 = z20;
                    }
                    z14 = z21 | ((U0.m) eVar2).f12299C0;
                }
                i17++;
                cVar2 = cVar4;
                z13 = z18;
                z12 = z19;
            }
            z15 = z13;
            z16 = z12;
            cVar3 = cVar2;
            i18 = 0;
            while (i18 < 2) {
                i19 = 0;
                while (i19 < size2) {
                    eVar = (e) arrayList.get(i19);
                    if (eVar instanceof U0.j) {
                        if (eVar.f12201i0 == 8) {
                            arrayList3 = arrayList;
                            i21 = size2;
                        } else {
                            iR3 = eVar.r();
                            iL2 = eVar.l();
                            arrayList3 = arrayList;
                            int i411 = eVar.f12189c0;
                            i21 = size2;
                            boolean zY10 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                            iR4 = eVar.r();
                            z17 = zY10;
                            iL3 = eVar.l();
                            if (iR4 != iR3) {
                                eVar.P(iR4);
                                if (!z16) {
                                }
                                z17 = true;
                            }
                            if (iL3 != iL2) {
                                eVar.M(iL3);
                                if (!z15) {
                                }
                                z17 = true;
                            }
                            if (eVar.f12163E) {
                                z14 = z17;
                            } else {
                                z14 = z17;
                            }
                        }
                    } else if (eVar.f12201i0 == 8) {
                        arrayList3 = arrayList;
                        i21 = size2;
                    } else {
                        iR3 = eVar.r();
                        iL2 = eVar.l();
                        arrayList3 = arrayList;
                        int i412 = eVar.f12189c0;
                        i21 = size2;
                        boolean zY11 = c0057h.y(i18 == 1 ? 2 : 1, eVar, cVar3) | z14;
                        iR4 = eVar.r();
                        z17 = zY11;
                        iL3 = eVar.l();
                        if (iR4 != iR3) {
                            eVar.P(iR4);
                            if (!z16) {
                            }
                            z17 = true;
                        }
                        if (iL3 != iL2) {
                            eVar.M(iL3);
                            if (!z15) {
                            }
                            z17 = true;
                        }
                        if (eVar.f12163E) {
                            z14 = z17;
                        } else {
                            z14 = z17;
                        }
                    }
                    i19++;
                    arrayList = arrayList3;
                    size2 = i21;
                }
                arrayList2 = arrayList;
                i20 = size2;
                if (z14) {
                    break;
                    break;
                }
                i18++;
                c0057h.B(fVar, i18, iR2, iL);
                arrayList = arrayList2;
                size2 = i20;
                z14 = false;
            }
        }
        fVar.f12236H0 = i410;
        S0.c.f11231q = fVar.X(512);
    }

    public final void o(e eVar, LayoutParams layoutParams, SparseArray sparseArray, int i10, int i11) {
        View view = (View) this.f16118a.get(i10);
        e eVar2 = (e) sparseArray.get(i10);
        if (eVar2 == null || view == null || !(view.getLayoutParams() instanceof LayoutParams)) {
            return;
        }
        layoutParams.f16163c0 = true;
        if (i11 == 6) {
            LayoutParams layoutParams2 = (LayoutParams) view.getLayoutParams();
            layoutParams2.f16163c0 = true;
            layoutParams2.f16190q0.f12163E = true;
        }
        eVar.j(6).b(eVar2.j(i11), layoutParams.f16136D, layoutParams.f16135C, true);
        eVar.f12163E = true;
        eVar.j(3).j();
        eVar.j(5).j();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        View content;
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            e eVar = layoutParams.f16190q0;
            if ((childAt.getVisibility() != 8 || layoutParams.f16165d0 || layoutParams.f16167e0 || zIsInEditMode) && !layoutParams.f16169f0) {
                int iS = eVar.s();
                int iT = eVar.t();
                int iR = eVar.r() + iS;
                int iL = eVar.l() + iT;
                childAt.layout(iS, iT, iR, iL);
                if ((childAt instanceof Placeholder) && (content = ((Placeholder) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(iS, iT, iR, iL);
                }
            }
        }
        ArrayList arrayList = this.f16119b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i15 = 0; i15 < size; i15++) {
                ((ConstraintHelper) arrayList.get(i15)).n();
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:111:0x01c3  */
    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        boolean z3;
        e eVar;
        boolean z5 = this.f16125r;
        this.f16125r = z5;
        int i12 = 0;
        if (!z5) {
            int childCount = getChildCount();
            for (int i13 = 0; i13 < childCount; i13++) {
                if (getChildAt(i13).isLayoutRequested()) {
                    this.f16125r = true;
                    break;
                }
            }
        }
        boolean zK = k();
        f fVar = this.f16120c;
        fVar.f12248z0 = zK;
        if (this.f16125r) {
            this.f16125r = false;
            int childCount2 = getChildCount();
            int i14 = 0;
            while (true) {
                if (i14 >= childCount2) {
                    z3 = false;
                    break;
                } else {
                    if (getChildAt(i14).isLayoutRequested()) {
                        z3 = true;
                        break;
                    }
                    i14++;
                }
            }
            if (z3) {
                boolean zIsInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i15 = 0; i15 < childCount3; i15++) {
                    e eVarF = f(getChildAt(i15));
                    if (eVarF != null) {
                        eVarF.D();
                    }
                }
                Object obj = null;
                if (zIsInEditMode) {
                    for (int i16 = 0; i16 < childCount3; i16++) {
                        View childAt = getChildAt(i16);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            Integer numValueOf = Integer.valueOf(childAt.getId());
                            if (resourceName != null) {
                                if (this.f16130w == null) {
                                    this.f16130w = new HashMap();
                                }
                                int iIndexOf = resourceName.indexOf("/");
                                this.f16130w.put(iIndexOf != -1 ? resourceName.substring(iIndexOf + 1) : resourceName, numValueOf);
                            }
                            int iIndexOf2 = resourceName.indexOf(47);
                            if (iIndexOf2 != -1) {
                                resourceName = resourceName.substring(iIndexOf2 + 1);
                            }
                            int id = childAt.getId();
                            if (id != 0) {
                                View viewFindViewById = (View) this.f16118a.get(id);
                                if (viewFindViewById == null && (viewFindViewById = findViewById(id)) != null && viewFindViewById != this && viewFindViewById.getParent() == this) {
                                    onViewAdded(viewFindViewById);
                                }
                                eVar = viewFindViewById == this ? fVar : viewFindViewById == null ? null : ((LayoutParams) viewFindViewById.getLayoutParams()).f16190q0;
                            }
                            eVar.f12204k0 = resourceName;
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (this.f16129v != -1) {
                    for (int i17 = 0; i17 < childCount3; i17++) {
                        View childAt2 = getChildAt(i17);
                        if (childAt2.getId() == this.f16129v && (childAt2 instanceof Constraints)) {
                            this.f16127t = ((Constraints) childAt2).getConstraintSet();
                        }
                    }
                }
                d dVar = this.f16127t;
                if (dVar != null) {
                    dVar.c(this);
                }
                fVar.f12244u0.clear();
                ArrayList arrayList = this.f16119b;
                int size = arrayList.size();
                if (size > 0) {
                    int i18 = 0;
                    while (i18 < size) {
                        ConstraintHelper constraintHelper = (ConstraintHelper) arrayList.get(i18);
                        if (constraintHelper.isInEditMode()) {
                            constraintHelper.setIds(constraintHelper.f16113f);
                        }
                        U0.j jVar = constraintHelper.f16111d;
                        if (jVar != null) {
                            jVar.v0 = i12;
                            Arrays.fill(jVar.f12295u0, obj);
                            for (int i19 = i12; i19 < constraintHelper.f16109b; i19++) {
                                int i20 = constraintHelper.f16108a[i19];
                                View viewE = e(i20);
                                if (viewE == null) {
                                    Integer numValueOf2 = Integer.valueOf(i20);
                                    HashMap map = constraintHelper.f16116s;
                                    String str = (String) map.get(numValueOf2);
                                    int iH = constraintHelper.h(this, str);
                                    if (iH != 0) {
                                        constraintHelper.f16108a[i19] = iH;
                                        map.put(Integer.valueOf(iH), str);
                                        viewE = e(iH);
                                    }
                                }
                                if (viewE != null) {
                                    constraintHelper.f16111d.S(f(viewE));
                                }
                            }
                            constraintHelper.f16111d.U();
                        }
                        i18++;
                        i12 = 0;
                        obj = null;
                    }
                }
                for (int i21 = 0; i21 < childCount3; i21++) {
                    View childAt3 = getChildAt(i21);
                    if (childAt3 instanceof Placeholder) {
                        Placeholder placeholder = (Placeholder) childAt3;
                        if (placeholder.f16214a == -1 && !placeholder.isInEditMode()) {
                            placeholder.setVisibility(placeholder.f16216c);
                        }
                        View viewFindViewById2 = findViewById(placeholder.f16214a);
                        placeholder.f16215b = viewFindViewById2;
                        if (viewFindViewById2 != null) {
                            ((LayoutParams) viewFindViewById2.getLayoutParams()).f16169f0 = true;
                            placeholder.f16215b.setVisibility(0);
                            placeholder.setVisibility(0);
                        }
                    }
                }
                SparseArray sparseArray = this.f16131x;
                sparseArray.clear();
                sparseArray.put(0, fVar);
                sparseArray.put(getId(), fVar);
                for (int i22 = 0; i22 < childCount3; i22++) {
                    View childAt4 = getChildAt(i22);
                    sparseArray.put(childAt4.getId(), f(childAt4));
                }
                for (int i23 = 0; i23 < childCount3; i23++) {
                    View childAt5 = getChildAt(i23);
                    e eVarF2 = f(childAt5);
                    if (eVarF2 != null) {
                        LayoutParams layoutParams = (LayoutParams) childAt5.getLayoutParams();
                        fVar.f12244u0.add(eVarF2);
                        e eVar2 = eVarF2.f12179V;
                        if (eVar2 != null) {
                            ((f) eVar2).f12244u0.remove(eVarF2);
                            eVarF2.D();
                        }
                        eVarF2.f12179V = fVar;
                        d(zIsInEditMode, childAt5, eVarF2, layoutParams, sparseArray);
                    }
                }
            }
            if (z3) {
                fVar.v0.F(fVar);
            }
        }
        fVar.f12229A0.getClass();
        n(fVar, this.f16126s, i10, i11);
        m(i10, i11, fVar.r(), fVar.l(), fVar.f12237I0, fVar.f12238J0);
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        e eVarF = f(view);
        if ((view instanceof Guideline) && !(eVarF instanceof i)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            i iVar = new i();
            layoutParams.f16190q0 = iVar;
            layoutParams.f16165d0 = true;
            iVar.T(layoutParams.f16153V);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.q();
            ((LayoutParams) view.getLayoutParams()).f16167e0 = true;
            ArrayList arrayList = this.f16119b;
            if (!arrayList.contains(constraintHelper)) {
                arrayList.add(constraintHelper);
            }
        }
        this.f16118a.put(view.getId(), view);
        this.f16125r = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f16118a.remove(view.getId());
        e eVarF = f(view);
        this.f16120c.f12244u0.remove(eVarF);
        eVarF.D();
        this.f16119b.remove(view);
        this.f16125r = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        this.f16125r = true;
        super.requestLayout();
    }

    public void setConstraintSet(d dVar) {
        this.f16127t = dVar;
    }

    @Override // android.view.View
    public void setId(int i10) {
        int id = getId();
        SparseArray sparseArray = this.f16118a;
        sparseArray.remove(id);
        super.setId(i10);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i10) {
        if (i10 == this.f16124q) {
            return;
        }
        this.f16124q = i10;
        requestLayout();
    }

    public void setMaxWidth(int i10) {
        if (i10 == this.f16123f) {
            return;
        }
        this.f16123f = i10;
        requestLayout();
    }

    public void setMinHeight(int i10) {
        if (i10 == this.f16122e) {
            return;
        }
        this.f16122e = i10;
        requestLayout();
    }

    public void setMinWidth(int i10) {
        if (i10 == this.f16121d) {
            return;
        }
        this.f16121d = i10;
        requestLayout();
    }

    public void setOnConstraintsChanged(p005a1.i iVar) {
        k kVar = this.f16128u;
        if (kVar != null) {
            kVar.getClass();
        }
    }

    public void setOptimizationLevel(int i10) {
        this.f16126s = i10;
        f fVar = this.f16120c;
        fVar.f12236H0 = i10;
        S0.c.f11231q = fVar.X(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f16118a = new SparseArray();
        this.f16119b = new ArrayList(4);
        this.f16120c = new f();
        this.f16121d = 0;
        this.f16122e = 0;
        this.f16123f = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        this.f16124q = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        this.f16125r = true;
        this.f16126s = 257;
        this.f16127t = null;
        this.f16128u = null;
        this.f16129v = -1;
        this.f16130w = new HashMap();
        this.f16131x = new SparseArray();
        this.f16132y = new b(this, this);
        h(attributeSet, i10);
    }

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: A, reason: collision with root package name */
        public int f16133A;

        /* JADX INFO: renamed from: B, reason: collision with root package name */
        public int f16134B;

        /* JADX INFO: renamed from: C, reason: collision with root package name */
        public final int f16135C;

        /* JADX INFO: renamed from: D, reason: collision with root package name */
        public final int f16136D;

        /* JADX INFO: renamed from: E, reason: collision with root package name */
        public float f16137E;

        /* JADX INFO: renamed from: F, reason: collision with root package name */
        public float f16138F;

        /* JADX INFO: renamed from: G, reason: collision with root package name */
        public String f16139G;

        /* JADX INFO: renamed from: H, reason: collision with root package name */
        public float f16140H;

        /* JADX INFO: renamed from: I, reason: collision with root package name */
        public float f16141I;

        /* JADX INFO: renamed from: J, reason: collision with root package name */
        public int f16142J;

        /* JADX INFO: renamed from: K, reason: collision with root package name */
        public int f16143K;

        /* JADX INFO: renamed from: L, reason: collision with root package name */
        public int f16144L;
        public int M;

        /* JADX INFO: renamed from: N, reason: collision with root package name */
        public int f16145N;

        /* JADX INFO: renamed from: O, reason: collision with root package name */
        public int f16146O;

        /* JADX INFO: renamed from: P, reason: collision with root package name */
        public int f16147P;

        /* JADX INFO: renamed from: Q, reason: collision with root package name */
        public int f16148Q;

        /* JADX INFO: renamed from: R, reason: collision with root package name */
        public float f16149R;

        /* JADX INFO: renamed from: S, reason: collision with root package name */
        public float f16150S;

        /* JADX INFO: renamed from: T, reason: collision with root package name */
        public int f16151T;

        /* JADX INFO: renamed from: U, reason: collision with root package name */
        public int f16152U;

        /* JADX INFO: renamed from: V, reason: collision with root package name */
        public int f16153V;

        /* JADX INFO: renamed from: W, reason: collision with root package name */
        public boolean f16154W;

        /* JADX INFO: renamed from: X, reason: collision with root package name */
        public boolean f16155X;

        /* JADX INFO: renamed from: Y, reason: collision with root package name */
        public String f16156Y;

        /* JADX INFO: renamed from: Z, reason: collision with root package name */
        public int f16157Z;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f16158a;

        /* JADX INFO: renamed from: a0, reason: collision with root package name */
        public boolean f16159a0;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f16160b;

        /* JADX INFO: renamed from: b0, reason: collision with root package name */
        public boolean f16161b0;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f16162c;

        /* JADX INFO: renamed from: c0, reason: collision with root package name */
        public boolean f16163c0;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final boolean f16164d;

        /* JADX INFO: renamed from: d0, reason: collision with root package name */
        public boolean f16165d0;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f16166e;

        /* JADX INFO: renamed from: e0, reason: collision with root package name */
        public boolean f16167e0;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f16168f;

        /* JADX INFO: renamed from: f0, reason: collision with root package name */
        public boolean f16169f0;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f16170g;

        /* JADX INFO: renamed from: g0, reason: collision with root package name */
        public int f16171g0;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f16172h;

        /* JADX INFO: renamed from: h0, reason: collision with root package name */
        public int f16173h0;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f16174i;

        /* JADX INFO: renamed from: i0, reason: collision with root package name */
        public int f16175i0;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public int f16176j;

        /* JADX INFO: renamed from: j0, reason: collision with root package name */
        public int f16177j0;
        public int k;

        /* JADX INFO: renamed from: k0, reason: collision with root package name */
        public int f16178k0;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public int f16179l;

        /* JADX INFO: renamed from: l0, reason: collision with root package name */
        public int f16180l0;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public int f16181m;

        /* JADX INFO: renamed from: m0, reason: collision with root package name */
        public float f16182m0;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public int f16183n;

        /* JADX INFO: renamed from: n0, reason: collision with root package name */
        public int f16184n0;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public int f16185o;

        /* JADX INFO: renamed from: o0, reason: collision with root package name */
        public int f16186o0;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public int f16187p;

        /* JADX INFO: renamed from: p0, reason: collision with root package name */
        public float f16188p0;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public int f16189q;

        /* JADX INFO: renamed from: q0, reason: collision with root package name */
        public e f16190q0;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public float f16191r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public int f16192s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public int f16193t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public int f16194u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public int f16195v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public final int f16196w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public int f16197x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public final int f16198y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public int f16199z;

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f16158a = -1;
            this.f16160b = -1;
            this.f16162c = -1.0f;
            this.f16164d = true;
            this.f16166e = -1;
            this.f16168f = -1;
            this.f16170g = -1;
            this.f16172h = -1;
            this.f16174i = -1;
            this.f16176j = -1;
            this.k = -1;
            this.f16179l = -1;
            this.f16181m = -1;
            this.f16183n = -1;
            this.f16185o = -1;
            this.f16187p = -1;
            this.f16189q = 0;
            this.f16191r = 0.0f;
            this.f16192s = -1;
            this.f16193t = -1;
            this.f16194u = -1;
            this.f16195v = -1;
            this.f16196w = Integer.MIN_VALUE;
            this.f16197x = Integer.MIN_VALUE;
            this.f16198y = Integer.MIN_VALUE;
            this.f16199z = Integer.MIN_VALUE;
            this.f16133A = Integer.MIN_VALUE;
            this.f16134B = Integer.MIN_VALUE;
            this.f16135C = Integer.MIN_VALUE;
            this.f16136D = 0;
            this.f16137E = 0.5f;
            this.f16138F = 0.5f;
            this.f16139G = null;
            this.f16140H = -1.0f;
            this.f16141I = -1.0f;
            this.f16142J = 0;
            this.f16143K = 0;
            this.f16144L = 0;
            this.M = 0;
            this.f16145N = 0;
            this.f16146O = 0;
            this.f16147P = 0;
            this.f16148Q = 0;
            this.f16149R = 1.0f;
            this.f16150S = 1.0f;
            this.f16151T = -1;
            this.f16152U = -1;
            this.f16153V = -1;
            this.f16154W = false;
            this.f16155X = false;
            this.f16156Y = null;
            this.f16157Z = 0;
            this.f16159a0 = true;
            this.f16161b0 = true;
            this.f16163c0 = false;
            this.f16165d0 = false;
            this.f16167e0 = false;
            this.f16169f0 = false;
            this.f16171g0 = -1;
            this.f16173h0 = -1;
            this.f16175i0 = -1;
            this.f16177j0 = -1;
            this.f16178k0 = Integer.MIN_VALUE;
            this.f16180l0 = Integer.MIN_VALUE;
            this.f16182m0 = 0.5f;
            this.f16190q0 = new e();
            if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
                ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
                ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
                ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
                ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
                setMarginStart(marginLayoutParams.getMarginStart());
                setMarginEnd(marginLayoutParams.getMarginEnd());
            }
            if (layoutParams instanceof LayoutParams) {
                LayoutParams layoutParams2 = (LayoutParams) layoutParams;
                this.f16158a = layoutParams2.f16158a;
                this.f16160b = layoutParams2.f16160b;
                this.f16162c = layoutParams2.f16162c;
                this.f16164d = layoutParams2.f16164d;
                this.f16166e = layoutParams2.f16166e;
                this.f16168f = layoutParams2.f16168f;
                this.f16170g = layoutParams2.f16170g;
                this.f16172h = layoutParams2.f16172h;
                this.f16174i = layoutParams2.f16174i;
                this.f16176j = layoutParams2.f16176j;
                this.k = layoutParams2.k;
                this.f16179l = layoutParams2.f16179l;
                this.f16181m = layoutParams2.f16181m;
                this.f16183n = layoutParams2.f16183n;
                this.f16185o = layoutParams2.f16185o;
                this.f16187p = layoutParams2.f16187p;
                this.f16189q = layoutParams2.f16189q;
                this.f16191r = layoutParams2.f16191r;
                this.f16192s = layoutParams2.f16192s;
                this.f16193t = layoutParams2.f16193t;
                this.f16194u = layoutParams2.f16194u;
                this.f16195v = layoutParams2.f16195v;
                this.f16196w = layoutParams2.f16196w;
                this.f16197x = layoutParams2.f16197x;
                this.f16198y = layoutParams2.f16198y;
                this.f16199z = layoutParams2.f16199z;
                this.f16133A = layoutParams2.f16133A;
                this.f16134B = layoutParams2.f16134B;
                this.f16135C = layoutParams2.f16135C;
                this.f16136D = layoutParams2.f16136D;
                this.f16137E = layoutParams2.f16137E;
                this.f16138F = layoutParams2.f16138F;
                this.f16139G = layoutParams2.f16139G;
                this.f16140H = layoutParams2.f16140H;
                this.f16141I = layoutParams2.f16141I;
                this.f16142J = layoutParams2.f16142J;
                this.f16143K = layoutParams2.f16143K;
                this.f16154W = layoutParams2.f16154W;
                this.f16155X = layoutParams2.f16155X;
                this.f16144L = layoutParams2.f16144L;
                this.M = layoutParams2.M;
                this.f16145N = layoutParams2.f16145N;
                this.f16147P = layoutParams2.f16147P;
                this.f16146O = layoutParams2.f16146O;
                this.f16148Q = layoutParams2.f16148Q;
                this.f16149R = layoutParams2.f16149R;
                this.f16150S = layoutParams2.f16150S;
                this.f16151T = layoutParams2.f16151T;
                this.f16152U = layoutParams2.f16152U;
                this.f16153V = layoutParams2.f16153V;
                this.f16159a0 = layoutParams2.f16159a0;
                this.f16161b0 = layoutParams2.f16161b0;
                this.f16163c0 = layoutParams2.f16163c0;
                this.f16165d0 = layoutParams2.f16165d0;
                this.f16171g0 = layoutParams2.f16171g0;
                this.f16173h0 = layoutParams2.f16173h0;
                this.f16175i0 = layoutParams2.f16175i0;
                this.f16177j0 = layoutParams2.f16177j0;
                this.f16178k0 = layoutParams2.f16178k0;
                this.f16180l0 = layoutParams2.f16180l0;
                this.f16182m0 = layoutParams2.f16182m0;
                this.f16156Y = layoutParams2.f16156Y;
                this.f16157Z = layoutParams2.f16157Z;
                this.f16190q0 = layoutParams2.f16190q0;
            }
        }

        public final void a() {
            this.f16165d0 = false;
            this.f16159a0 = true;
            this.f16161b0 = true;
            int i10 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i10 == -2 && this.f16154W) {
                this.f16159a0 = false;
                if (this.f16144L == 0) {
                    this.f16144L = 1;
                }
            }
            int i11 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i11 == -2 && this.f16155X) {
                this.f16161b0 = false;
                if (this.M == 0) {
                    this.M = 1;
                }
            }
            if (i10 == 0 || i10 == -1) {
                this.f16159a0 = false;
                if (i10 == 0 && this.f16144L == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.f16154W = true;
                }
            }
            if (i11 == 0 || i11 == -1) {
                this.f16161b0 = false;
                if (i11 == 0 && this.M == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.f16155X = true;
                }
            }
            if (this.f16162c == -1.0f && this.f16158a == -1 && this.f16160b == -1) {
                return;
            }
            this.f16165d0 = true;
            this.f16159a0 = true;
            this.f16161b0 = true;
            if (!(this.f16190q0 instanceof i)) {
                this.f16190q0 = new i();
            }
            ((i) this.f16190q0).T(this.f16153V);
        }

        /* JADX WARN: Code duplicated, block: B:17:0x004a  */
        /* JADX WARN: Code duplicated, block: B:20:0x0051  */
        /* JADX WARN: Code duplicated, block: B:23:0x0058  */
        /* JADX WARN: Code duplicated, block: B:26:0x005e  */
        /* JADX WARN: Code duplicated, block: B:29:0x0064  */
        /* JADX WARN: Code duplicated, block: B:38:0x007a  */
        /* JADX WARN: Code duplicated, block: B:39:0x0082 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:40:0x0084  */
        /* JADX WARN: Code duplicated, block: B:41:0x008b A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:42:0x008d  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        public final void resolveLayoutDirection(int i10) {
            int i11;
            int i12;
            int i13;
            int i14;
            int i15 = ((ViewGroup.MarginLayoutParams) this).leftMargin;
            int i16 = ((ViewGroup.MarginLayoutParams) this).rightMargin;
            super.resolveLayoutDirection(i10);
            boolean z3 = false;
            boolean z5 = 1 == getLayoutDirection();
            this.f16175i0 = -1;
            this.f16177j0 = -1;
            this.f16171g0 = -1;
            this.f16173h0 = -1;
            this.f16178k0 = this.f16196w;
            this.f16180l0 = this.f16198y;
            float f10 = this.f16137E;
            this.f16182m0 = f10;
            int i17 = this.f16158a;
            this.f16184n0 = i17;
            int i18 = this.f16160b;
            this.f16186o0 = i18;
            float f11 = this.f16162c;
            this.f16188p0 = f11;
            if (z5) {
                int i19 = this.f16192s;
                if (i19 != -1) {
                    this.f16175i0 = i19;
                } else {
                    int i20 = this.f16193t;
                    if (i20 != -1) {
                        this.f16177j0 = i20;
                    } else {
                        i11 = this.f16194u;
                        if (i11 != -1) {
                            this.f16173h0 = i11;
                            z3 = true;
                        }
                        i12 = this.f16195v;
                        if (i12 != -1) {
                            this.f16171g0 = i12;
                            z3 = true;
                        }
                        i13 = this.f16133A;
                        if (i13 != Integer.MIN_VALUE) {
                            this.f16180l0 = i13;
                        }
                        i14 = this.f16134B;
                        if (i14 != Integer.MIN_VALUE) {
                            this.f16178k0 = i14;
                        }
                        if (z3) {
                            this.f16182m0 = 1.0f - f10;
                        }
                        if (this.f16165d0 && this.f16153V == 1 && this.f16164d) {
                            if (f11 != -1.0f) {
                                this.f16188p0 = 1.0f - f11;
                                this.f16184n0 = -1;
                                this.f16186o0 = -1;
                            } else if (i17 != -1) {
                                this.f16186o0 = i17;
                                this.f16184n0 = -1;
                                this.f16188p0 = -1.0f;
                            } else if (i18 != -1) {
                                this.f16184n0 = i18;
                                this.f16186o0 = -1;
                                this.f16188p0 = -1.0f;
                            }
                        }
                    }
                }
                z3 = true;
                i11 = this.f16194u;
                if (i11 != -1) {
                    this.f16173h0 = i11;
                    z3 = true;
                }
                i12 = this.f16195v;
                if (i12 != -1) {
                    this.f16171g0 = i12;
                    z3 = true;
                }
                i13 = this.f16133A;
                if (i13 != Integer.MIN_VALUE) {
                    this.f16180l0 = i13;
                }
                i14 = this.f16134B;
                if (i14 != Integer.MIN_VALUE) {
                    this.f16178k0 = i14;
                }
                if (z3) {
                    this.f16182m0 = 1.0f - f10;
                }
                if (this.f16165d0) {
                    if (f11 != -1.0f) {
                        this.f16188p0 = 1.0f - f11;
                        this.f16184n0 = -1;
                        this.f16186o0 = -1;
                    } else if (i17 != -1) {
                        this.f16186o0 = i17;
                        this.f16184n0 = -1;
                        this.f16188p0 = -1.0f;
                    } else if (i18 != -1) {
                        this.f16184n0 = i18;
                        this.f16186o0 = -1;
                        this.f16188p0 = -1.0f;
                    }
                }
            } else {
                int i21 = this.f16192s;
                if (i21 != -1) {
                    this.f16173h0 = i21;
                }
                int i22 = this.f16193t;
                if (i22 != -1) {
                    this.f16171g0 = i22;
                }
                int i23 = this.f16194u;
                if (i23 != -1) {
                    this.f16175i0 = i23;
                }
                int i24 = this.f16195v;
                if (i24 != -1) {
                    this.f16177j0 = i24;
                }
                int i25 = this.f16133A;
                if (i25 != Integer.MIN_VALUE) {
                    this.f16178k0 = i25;
                }
                int i26 = this.f16134B;
                if (i26 != Integer.MIN_VALUE) {
                    this.f16180l0 = i26;
                }
            }
            if (this.f16194u == -1 && this.f16195v == -1 && this.f16193t == -1 && this.f16192s == -1) {
                int i27 = this.f16170g;
                if (i27 != -1) {
                    this.f16175i0 = i27;
                    if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i16 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).rightMargin = i16;
                    }
                } else {
                    int i28 = this.f16172h;
                    if (i28 != -1) {
                        this.f16177j0 = i28;
                        if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i16 > 0) {
                            ((ViewGroup.MarginLayoutParams) this).rightMargin = i16;
                        }
                    }
                }
                int i29 = this.f16166e;
                if (i29 != -1) {
                    this.f16171g0 = i29;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i15 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i15;
                    return;
                }
                int i30 = this.f16168f;
                if (i30 != -1) {
                    this.f16173h0 = i30;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i15 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i15;
                }
            }
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f16158a = -1;
            this.f16160b = -1;
            this.f16162c = -1.0f;
            this.f16164d = true;
            this.f16166e = -1;
            this.f16168f = -1;
            this.f16170g = -1;
            this.f16172h = -1;
            this.f16174i = -1;
            this.f16176j = -1;
            this.k = -1;
            this.f16179l = -1;
            this.f16181m = -1;
            this.f16183n = -1;
            this.f16185o = -1;
            this.f16187p = -1;
            this.f16189q = 0;
            this.f16191r = 0.0f;
            this.f16192s = -1;
            this.f16193t = -1;
            this.f16194u = -1;
            this.f16195v = -1;
            this.f16196w = Integer.MIN_VALUE;
            this.f16197x = Integer.MIN_VALUE;
            this.f16198y = Integer.MIN_VALUE;
            this.f16199z = Integer.MIN_VALUE;
            this.f16133A = Integer.MIN_VALUE;
            this.f16134B = Integer.MIN_VALUE;
            this.f16135C = Integer.MIN_VALUE;
            this.f16136D = 0;
            this.f16137E = 0.5f;
            this.f16138F = 0.5f;
            this.f16139G = null;
            this.f16140H = -1.0f;
            this.f16141I = -1.0f;
            this.f16142J = 0;
            this.f16143K = 0;
            this.f16144L = 0;
            this.M = 0;
            this.f16145N = 0;
            this.f16146O = 0;
            this.f16147P = 0;
            this.f16148Q = 0;
            this.f16149R = 1.0f;
            this.f16150S = 1.0f;
            this.f16151T = -1;
            this.f16152U = -1;
            this.f16153V = -1;
            this.f16154W = false;
            this.f16155X = false;
            this.f16156Y = null;
            this.f16157Z = 0;
            this.f16159a0 = true;
            this.f16161b0 = true;
            this.f16163c0 = false;
            this.f16165d0 = false;
            this.f16167e0 = false;
            this.f16169f0 = false;
            this.f16171g0 = -1;
            this.f16173h0 = -1;
            this.f16175i0 = -1;
            this.f16177j0 = -1;
            this.f16178k0 = Integer.MIN_VALUE;
            this.f16180l0 = Integer.MIN_VALUE;
            this.f16182m0 = 0.5f;
            this.f16190q0 = new e();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p005a1.k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                int i11 = a.f16223a.get(index);
                switch (i11) {
                    case 1:
                        this.f16153V = typedArrayObtainStyledAttributes.getInt(index, this.f16153V);
                        break;
                    case 2:
                        int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, this.f16187p);
                        this.f16187p = resourceId;
                        if (resourceId == -1) {
                            this.f16187p = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 3:
                        this.f16189q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16189q);
                        break;
                    case 4:
                        float f10 = typedArrayObtainStyledAttributes.getFloat(index, this.f16191r) % 360.0f;
                        this.f16191r = f10;
                        if (f10 < 0.0f) {
                            this.f16191r = (360.0f - f10) % 360.0f;
                        }
                        break;
                    case 5:
                        this.f16158a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16158a);
                        break;
                    case 6:
                        this.f16160b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16160b);
                        break;
                    case 7:
                        this.f16162c = typedArrayObtainStyledAttributes.getFloat(index, this.f16162c);
                        break;
                    case 8:
                        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16166e);
                        this.f16166e = resourceId2;
                        if (resourceId2 == -1) {
                            this.f16166e = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                        int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16168f);
                        this.f16168f = resourceId3;
                        if (resourceId3 == -1) {
                            this.f16168f = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                        int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16170g);
                        this.f16170g = resourceId4;
                        if (resourceId4 == -1) {
                            this.f16170g = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 11:
                        int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16172h);
                        this.f16172h = resourceId5;
                        if (resourceId5 == -1) {
                            this.f16172h = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                        int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16174i);
                        this.f16174i = resourceId6;
                        if (resourceId6 == -1) {
                            this.f16174i = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 13:
                        int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16176j);
                        this.f16176j = resourceId7;
                        if (resourceId7 == -1) {
                            this.f16176j = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 14:
                        int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, this.k);
                        this.k = resourceId8;
                        if (resourceId8 == -1) {
                            this.k = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 15:
                        int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16179l);
                        this.f16179l = resourceId9;
                        if (resourceId9 == -1) {
                            this.f16179l = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 16:
                        int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16181m);
                        this.f16181m = resourceId10;
                        if (resourceId10 == -1) {
                            this.f16181m = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                        int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16192s);
                        this.f16192s = resourceId11;
                        if (resourceId11 == -1) {
                            this.f16192s = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                        int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16193t);
                        this.f16193t = resourceId12;
                        if (resourceId12 == -1) {
                            this.f16193t = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 19:
                        int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16194u);
                        this.f16194u = resourceId13;
                        if (resourceId13 == -1) {
                            this.f16194u = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 20:
                        int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16195v);
                        this.f16195v = resourceId14;
                        if (resourceId14 == -1) {
                            this.f16195v = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 21:
                        this.f16196w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16196w);
                        break;
                    case 22:
                        this.f16197x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16197x);
                        break;
                    case 23:
                        this.f16198y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16198y);
                        break;
                    case 24:
                        this.f16199z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16199z);
                        break;
                    case 25:
                        this.f16133A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16133A);
                        break;
                    case 26:
                        this.f16134B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16134B);
                        break;
                    case 27:
                        this.f16154W = typedArrayObtainStyledAttributes.getBoolean(index, this.f16154W);
                        break;
                    case 28:
                        this.f16155X = typedArrayObtainStyledAttributes.getBoolean(index, this.f16155X);
                        break;
                    case 29:
                        this.f16137E = typedArrayObtainStyledAttributes.getFloat(index, this.f16137E);
                        break;
                    case 30:
                        this.f16138F = typedArrayObtainStyledAttributes.getFloat(index, this.f16138F);
                        break;
                    case 31:
                        int i12 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.f16144L = i12;
                        if (i12 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        }
                        break;
                    case 32:
                        int i13 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.M = i13;
                        if (i13 == 1) {
                            Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        }
                        break;
                    case 33:
                        try {
                            this.f16145N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16145N);
                        } catch (Exception unused) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.f16145N) == -2) {
                                this.f16145N = -2;
                            }
                        }
                        break;
                    case 34:
                        try {
                            this.f16147P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16147P);
                        } catch (Exception unused2) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.f16147P) == -2) {
                                this.f16147P = -2;
                            }
                        }
                        break;
                    case 35:
                        this.f16149R = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.f16149R));
                        this.f16144L = 2;
                        break;
                    case 36:
                        try {
                            this.f16146O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16146O);
                        } catch (Exception unused3) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.f16146O) == -2) {
                                this.f16146O = -2;
                            }
                        }
                        break;
                    case 37:
                        try {
                            this.f16148Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16148Q);
                        } catch (Exception unused4) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.f16148Q) == -2) {
                                this.f16148Q = -2;
                            }
                        }
                        break;
                    case 38:
                        this.f16150S = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.f16150S));
                        this.M = 2;
                        break;
                    default:
                        switch (i11) {
                            case 44:
                                d.o(this, typedArrayObtainStyledAttributes.getString(index));
                                break;
                            case 45:
                                this.f16140H = typedArrayObtainStyledAttributes.getFloat(index, this.f16140H);
                                break;
                            case 46:
                                this.f16141I = typedArrayObtainStyledAttributes.getFloat(index, this.f16141I);
                                break;
                            case 47:
                                this.f16142J = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.f16143K = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 49:
                                this.f16151T = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16151T);
                                break;
                            case 50:
                                this.f16152U = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f16152U);
                                break;
                            case 51:
                                this.f16156Y = typedArrayObtainStyledAttributes.getString(index);
                                break;
                            case 52:
                                int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16183n);
                                this.f16183n = resourceId15;
                                if (resourceId15 == -1) {
                                    this.f16183n = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case 53:
                                int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, this.f16185o);
                                this.f16185o = resourceId16;
                                if (resourceId16 == -1) {
                                    this.f16185o = typedArrayObtainStyledAttributes.getInt(index, -1);
                                }
                                break;
                            case 54:
                                this.f16136D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16136D);
                                break;
                            case 55:
                                this.f16135C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f16135C);
                                break;
                            default:
                                switch (i11) {
                                    case 64:
                                        d.n(this, typedArrayObtainStyledAttributes, index, 0);
                                        break;
                                    case 65:
                                        d.n(this, typedArrayObtainStyledAttributes, index, 1);
                                        break;
                                    case 66:
                                        this.f16157Z = typedArrayObtainStyledAttributes.getInt(index, this.f16157Z);
                                        break;
                                    case 67:
                                        this.f16164d = typedArrayObtainStyledAttributes.getBoolean(index, this.f16164d);
                                        break;
                                }
                                break;
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            a();
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.f16158a = -1;
            this.f16160b = -1;
            this.f16162c = -1.0f;
            this.f16164d = true;
            this.f16166e = -1;
            this.f16168f = -1;
            this.f16170g = -1;
            this.f16172h = -1;
            this.f16174i = -1;
            this.f16176j = -1;
            this.k = -1;
            this.f16179l = -1;
            this.f16181m = -1;
            this.f16183n = -1;
            this.f16185o = -1;
            this.f16187p = -1;
            this.f16189q = 0;
            this.f16191r = 0.0f;
            this.f16192s = -1;
            this.f16193t = -1;
            this.f16194u = -1;
            this.f16195v = -1;
            this.f16196w = Integer.MIN_VALUE;
            this.f16197x = Integer.MIN_VALUE;
            this.f16198y = Integer.MIN_VALUE;
            this.f16199z = Integer.MIN_VALUE;
            this.f16133A = Integer.MIN_VALUE;
            this.f16134B = Integer.MIN_VALUE;
            this.f16135C = Integer.MIN_VALUE;
            this.f16136D = 0;
            this.f16137E = 0.5f;
            this.f16138F = 0.5f;
            this.f16139G = null;
            this.f16140H = -1.0f;
            this.f16141I = -1.0f;
            this.f16142J = 0;
            this.f16143K = 0;
            this.f16144L = 0;
            this.M = 0;
            this.f16145N = 0;
            this.f16146O = 0;
            this.f16147P = 0;
            this.f16148Q = 0;
            this.f16149R = 1.0f;
            this.f16150S = 1.0f;
            this.f16151T = -1;
            this.f16152U = -1;
            this.f16153V = -1;
            this.f16154W = false;
            this.f16155X = false;
            this.f16156Y = null;
            this.f16157Z = 0;
            this.f16159a0 = true;
            this.f16161b0 = true;
            this.f16163c0 = false;
            this.f16165d0 = false;
            this.f16167e0 = false;
            this.f16169f0 = false;
            this.f16171g0 = -1;
            this.f16173h0 = -1;
            this.f16175i0 = -1;
            this.f16177j0 = -1;
            this.f16178k0 = Integer.MIN_VALUE;
            this.f16180l0 = Integer.MIN_VALUE;
            this.f16182m0 = 0.5f;
            this.f16190q0 = new e();
        }
    }
}
