package androidx.constraintlayout.widget;

import U0.e;
import U0.f;
import U0.k;
import android.view.View;
import android.view.ViewGroup;
import p005a1.m;

/* JADX INFO: loaded from: classes.dex */
public final class b implements V0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ConstraintLayout f16224a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16225b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16226c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16227d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f16228e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f16229f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16230g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public final /* synthetic */ ConstraintLayout f16231h;

    public b(ConstraintLayout constraintLayout, ConstraintLayout constraintLayout2) {
        this.f16231h = constraintLayout;
        this.f16224a = constraintLayout2;
    }

    public static boolean a(int i10, int i11, int i12) {
        if (i10 == i11) {
            return true;
        }
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i11);
        if (mode2 == 1073741824) {
            return (mode == Integer.MIN_VALUE || mode == 0) && i12 == size;
        }
        return false;
    }

    /* JADX WARN: Code duplicated, block: B:116:0x01a5  */
    /* JADX WARN: Code duplicated, block: B:117:0x01a7  */
    /* JADX WARN: Code duplicated, block: B:119:0x01aa  */
    /* JADX WARN: Code duplicated, block: B:120:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:126:0x01b8  */
    /* JADX WARN: Code duplicated, block: B:131:0x01c0  */
    /* JADX WARN: Code duplicated, block: B:137:0x01cc  */
    /* JADX WARN: Code duplicated, block: B:142:0x01d7  */
    /* JADX WARN: Code duplicated, block: B:144:0x01da A[ORIG_RETURN, RETURN] */
    /* JADX WARN: Code duplicated, block: B:145:0x01db  */
    /* JADX WARN: Code duplicated, block: B:157:0x01fd  */
    /* JADX WARN: Code duplicated, block: B:159:0x0201  */
    /* JADX WARN: Code duplicated, block: B:162:0x020f  */
    /* JADX WARN: Code duplicated, block: B:165:0x0229  */
    /* JADX WARN: Code duplicated, block: B:166:0x022e  */
    /* JADX WARN: Code duplicated, block: B:169:0x0233  */
    /* JADX WARN: Code duplicated, block: B:172:0x023b  */
    /* JADX WARN: Code duplicated, block: B:174:0x0242  */
    /* JADX WARN: Code duplicated, block: B:177:0x0248  */
    /* JADX WARN: Code duplicated, block: B:180:0x0255  */
    /* JADX WARN: Code duplicated, block: B:182:0x0259 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:184:0x0263 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:185:0x0265 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:188:0x026f A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:191:0x0275  */
    /* JADX WARN: Code duplicated, block: B:193:0x0279  */
    /* JADX WARN: Code duplicated, block: B:195:0x027f  */
    /* JADX WARN: Code duplicated, block: B:198:0x029f  */
    /* JADX WARN: Code duplicated, block: B:199:0x02a1  */
    /* JADX WARN: Code duplicated, block: B:206:0x02ad  */
    /* JADX WARN: Code duplicated, block: B:209:0x02b4  */
    /* JADX WARN: Code duplicated, block: B:55:0x00bc  */
    /* JADX WARN: Code duplicated, block: B:57:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:59:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:61:0x00c5  */
    /* JADX WARN: Code duplicated, block: B:62:0x00c8  */
    /* JADX WARN: Code duplicated, block: B:64:0x00cc  */
    /* JADX WARN: Code duplicated, block: B:65:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:67:0x00d4  */
    /* JADX WARN: Code duplicated, block: B:69:0x00e0  */
    /* JADX WARN: Code duplicated, block: B:71:0x00ec  */
    /* JADX WARN: Code duplicated, block: B:72:0x00ee  */
    /* JADX WARN: Code duplicated, block: B:76:0x00f6  */
    /* JADX WARN: Code duplicated, block: B:78:0x0100  */
    /* JADX WARN: Code duplicated, block: B:79:0x0102  */
    /* JADX WARN: Code duplicated, block: B:82:0x0107 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:89:0x0117  */
    /* JADX WARN: Code duplicated, block: B:90:0x0122  */
    /* JADX WARN: Code duplicated, block: B:91:0x012c  */
    public final void b(e eVar, V0.b bVar) {
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        int iOrdinal;
        int iMakeMeasureSpec3;
        f fVar;
        U0.d dVar;
        boolean z3;
        boolean z5;
        U0.d dVar2;
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13;
        ConstraintLayout.LayoutParams layoutParams;
        int i10;
        int measuredWidth;
        int measuredHeight;
        int baseline;
        int i11;
        int measuredWidth2;
        int i12;
        int i13;
        int measuredHeight2;
        boolean z14;
        int i14;
        boolean z15;
        int i15;
        boolean z16;
        boolean z17;
        boolean z18;
        int i16;
        boolean z19;
        int i17;
        if (eVar == null) {
            return;
        }
        if (eVar.f12201i0 == 8 && !eVar.f12164F) {
            bVar.f12805e = 0;
            bVar.f12806f = 0;
            bVar.f12807g = 0;
            return;
        }
        if (eVar.f12179V == null) {
            return;
        }
        m mVar = ConstraintLayout.f16117z;
        ConstraintLayout constraintLayout = this.f16231h;
        U0.d dVar3 = bVar.f12801a;
        U0.d dVar4 = bVar.f12802b;
        int i18 = bVar.f12803c;
        int i19 = bVar.f12804d;
        int i20 = this.f16225b + this.f16226c;
        int i21 = this.f16227d;
        View view = eVar.f12199h0;
        int iOrdinal2 = dVar3.ordinal();
        U0.c cVar = eVar.f12170L;
        U0.c cVar2 = eVar.f12168J;
        if (iOrdinal2 == 0) {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i18, 1073741824);
        } else {
            if (iOrdinal2 != 1) {
                if (iOrdinal2 == 2) {
                    iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f16229f, i21, -2);
                    boolean z20 = eVar.f12217r == 1;
                    int i22 = bVar.f12810j;
                    if (i22 == 1 || i22 == 2) {
                        boolean z21 = view.getMeasuredHeight() == eVar.l();
                        if (bVar.f12810j == 2 || !z20 || ((z20 && z21) || (view instanceof Placeholder) || eVar.B())) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(eVar.r(), 1073741824);
                        }
                    }
                } else if (iOrdinal2 != 3) {
                    iMakeMeasureSpec2 = 0;
                } else {
                    int i23 = this.f16229f;
                    int i24 = cVar2 != null ? cVar2.f12151g : 0;
                    if (cVar != null) {
                        i24 += cVar.f12151g;
                    }
                    iMakeMeasureSpec2 = ViewGroup.getChildMeasureSpec(i23, i21 + i24, -1);
                }
                iOrdinal = dVar4.ordinal();
                if (iOrdinal != 0) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i19, 1073741824);
                } else if (iOrdinal != 1) {
                    iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(this.f16230g, i20, -2);
                } else if (iOrdinal != 2) {
                    iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(this.f16230g, i20, -2);
                    if (eVar.f12219s == 1) {
                        z18 = true;
                    } else {
                        z18 = false;
                    }
                    i16 = bVar.f12810j;
                    if (i16 != 1 || i16 == 2) {
                        if (view.getMeasuredWidth() == eVar.r()) {
                            z19 = true;
                        } else {
                            z19 = false;
                        }
                        if (bVar.f12810j != 2 || !z18 || ((z18 && z19) || (view instanceof Placeholder) || eVar.C())) {
                            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(eVar.l(), 1073741824);
                        }
                    }
                } else if (iOrdinal != 3) {
                    iMakeMeasureSpec3 = 0;
                } else {
                    int i25 = this.f16230g;
                    if (cVar2 != null) {
                        i17 = eVar.f12169K.f12151g;
                    } else {
                        i17 = 0;
                    }
                    if (cVar != null) {
                        i17 += eVar.M.f12151g;
                    }
                    iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(i25, i20 + i17, -1);
                }
                fVar = (f) eVar.f12179V;
                if (fVar == null && k.c(constraintLayout.f16126s, 256) && view.getMeasuredWidth() == eVar.r() && view.getMeasuredWidth() < fVar.r() && view.getMeasuredHeight() == eVar.l() && view.getMeasuredHeight() < fVar.l() && view.getBaseline() == eVar.f12189c0 && !eVar.A() && a(eVar.f12166H, iMakeMeasureSpec2, eVar.r()) && a(eVar.f12167I, iMakeMeasureSpec3, eVar.l())) {
                    bVar.f12805e = eVar.r();
                    bVar.f12806f = eVar.l();
                    bVar.f12807g = eVar.f12189c0;
                    return;
                }
                dVar = U0.d.f12156c;
                if (dVar3 == dVar) {
                    z3 = true;
                } else {
                    z3 = false;
                }
                if (dVar4 == dVar) {
                    z5 = true;
                } else {
                    z5 = false;
                }
                dVar2 = U0.d.f12157d;
                U0.d dVar5 = U0.d.f12154a;
                if (dVar4 != dVar2 || dVar4 == dVar5) {
                    z10 = true;
                } else {
                    z10 = false;
                }
                if (dVar3 != dVar2 || dVar3 == dVar5) {
                    z11 = true;
                } else {
                    z11 = false;
                }
                if (z3 || eVar.f12182Y <= 0.0f) {
                    z12 = false;
                } else {
                    z12 = true;
                }
                if (z5 || eVar.f12182Y <= 0.0f) {
                    z13 = false;
                } else {
                    z13 = true;
                }
                if (view == null) {
                    return;
                }
                layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
                i10 = bVar.f12810j;
                if (i10 == 1 && i10 != 2 && z3 && eVar.f12217r == 0 && z5 && eVar.f12219s == 0) {
                    measuredHeight2 = 0;
                    i15 = -1;
                    z15 = false;
                    baseline = 0;
                    measuredWidth2 = 0;
                } else {
                    if ((view instanceof VirtualLayout) || !(eVar instanceof U0.m)) {
                        view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                    } else {
                        ((VirtualLayout) view).r((U0.m) eVar, iMakeMeasureSpec2, iMakeMeasureSpec3);
                    }
                    eVar.f12166H = iMakeMeasureSpec2;
                    eVar.f12167I = iMakeMeasureSpec3;
                    eVar.f12196g = false;
                    measuredWidth = view.getMeasuredWidth();
                    measuredHeight = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                    i11 = eVar.f12223u;
                    if (i11 > 0) {
                        measuredWidth2 = Math.max(i11, measuredWidth);
                    } else {
                        measuredWidth2 = measuredWidth;
                    }
                    i12 = eVar.f12224v;
                    if (i12 > 0) {
                        measuredWidth2 = Math.min(i12, measuredWidth2);
                    }
                    i13 = eVar.f12226x;
                    if (i13 > 0) {
                        measuredHeight2 = Math.max(i13, measuredHeight);
                    } else {
                        measuredHeight2 = measuredHeight;
                    }
                    z14 = z13;
                    i14 = eVar.f12227y;
                    if (i14 > 0) {
                        measuredHeight2 = Math.min(i14, measuredHeight2);
                    }
                    if (!k.c(constraintLayout.f16126s, 1)) {
                        if (!z12 && z10) {
                            measuredWidth2 = (int) ((measuredHeight2 * eVar.f12182Y) + 0.5f);
                        } else if (z14 && z11) {
                            measuredHeight2 = (int) ((measuredWidth2 / eVar.f12182Y) + 0.5f);
                        }
                    }
                    if (measuredWidth == measuredWidth2 || measuredHeight != measuredHeight2) {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != measuredHeight2) {
                            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                        eVar.f12166H = iMakeMeasureSpec2;
                        eVar.f12167I = iMakeMeasureSpec3;
                        z15 = false;
                        eVar.f12196g = false;
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                        i15 = -1;
                    } else {
                        i15 = -1;
                        z15 = false;
                    }
                }
                if (baseline != i15) {
                    z16 = true;
                } else {
                    z16 = z15;
                }
                if (measuredWidth2 == bVar.f12803c || measuredHeight2 != bVar.f12804d) {
                    z17 = true;
                } else {
                    z17 = z15;
                }
                bVar.f12809i = z17;
                if (layoutParams.f16163c0) {
                    z16 = true;
                }
                if (z16 && baseline != -1 && eVar.f12189c0 != baseline) {
                    bVar.f12809i = true;
                }
                bVar.f12805e = measuredWidth2;
                bVar.f12806f = measuredHeight2;
                bVar.f12808h = z16;
                bVar.f12807g = baseline;
            }
            iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f16229f, i21, -2);
        }
        iMakeMeasureSpec2 = iMakeMeasureSpec;
        iOrdinal = dVar4.ordinal();
        if (iOrdinal != 0) {
            iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i19, 1073741824);
        } else if (iOrdinal != 1) {
            iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(this.f16230g, i20, -2);
        } else if (iOrdinal != 2) {
            iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(this.f16230g, i20, -2);
            if (eVar.f12219s == 1) {
                z18 = true;
            } else {
                z18 = false;
            }
            i16 = bVar.f12810j;
            if (i16 != 1) {
                if (view.getMeasuredWidth() == eVar.r()) {
                    z19 = true;
                } else {
                    z19 = false;
                }
                if (bVar.f12810j != 2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(eVar.l(), 1073741824);
                } else {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(eVar.l(), 1073741824);
                }
            } else {
                if (view.getMeasuredWidth() == eVar.r()) {
                    z19 = true;
                } else {
                    z19 = false;
                }
                if (bVar.f12810j != 2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(eVar.l(), 1073741824);
                } else {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(eVar.l(), 1073741824);
                }
            }
        } else if (iOrdinal != 3) {
            iMakeMeasureSpec3 = 0;
        } else {
            int i26 = this.f16230g;
            if (cVar2 != null) {
                i17 = eVar.f12169K.f12151g;
            } else {
                i17 = 0;
            }
            if (cVar != null) {
                i17 += eVar.M.f12151g;
            }
            iMakeMeasureSpec3 = ViewGroup.getChildMeasureSpec(i26, i20 + i17, -1);
        }
        fVar = (f) eVar.f12179V;
        if (fVar == null) {
        }
        dVar = U0.d.f12156c;
        if (dVar3 == dVar) {
            z3 = true;
        } else {
            z3 = false;
        }
        if (dVar4 == dVar) {
            z5 = true;
        } else {
            z5 = false;
        }
        dVar2 = U0.d.f12157d;
        U0.d dVar6 = U0.d.f12154a;
        if (dVar4 != dVar2) {
            z10 = true;
        } else {
            z10 = true;
        }
        if (dVar3 != dVar2) {
            z11 = true;
        } else {
            z11 = true;
        }
        if (z3) {
            z12 = false;
        } else {
            z12 = false;
        }
        if (z5) {
            z13 = false;
        } else {
            z13 = false;
        }
        if (view == null) {
            return;
        }
        layoutParams = (ConstraintLayout.LayoutParams) view.getLayoutParams();
        i10 = bVar.f12810j;
        if (i10 == 1) {
            if (view instanceof VirtualLayout) {
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
            } else {
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
            }
            eVar.f12166H = iMakeMeasureSpec2;
            eVar.f12167I = iMakeMeasureSpec3;
            eVar.f12196g = false;
            measuredWidth = view.getMeasuredWidth();
            measuredHeight = view.getMeasuredHeight();
            baseline = view.getBaseline();
            i11 = eVar.f12223u;
            if (i11 > 0) {
                measuredWidth2 = Math.max(i11, measuredWidth);
            } else {
                measuredWidth2 = measuredWidth;
            }
            i12 = eVar.f12224v;
            if (i12 > 0) {
                measuredWidth2 = Math.min(i12, measuredWidth2);
            }
            i13 = eVar.f12226x;
            if (i13 > 0) {
                measuredHeight2 = Math.max(i13, measuredHeight);
            } else {
                measuredHeight2 = measuredHeight;
            }
            z14 = z13;
            i14 = eVar.f12227y;
            if (i14 > 0) {
                measuredHeight2 = Math.min(i14, measuredHeight2);
            }
            if (!k.c(constraintLayout.f16126s, 1)) {
                if (!z12) {
                    if (z14) {
                        measuredHeight2 = (int) ((measuredWidth2 / eVar.f12182Y) + 0.5f);
                    }
                } else if (z14) {
                    measuredHeight2 = (int) ((measuredWidth2 / eVar.f12182Y) + 0.5f);
                }
            }
            if (measuredWidth == measuredWidth2) {
                if (measuredWidth != measuredWidth2) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                }
                if (measuredHeight != measuredHeight2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824);
                }
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                eVar.f12166H = iMakeMeasureSpec2;
                eVar.f12167I = iMakeMeasureSpec3;
                z15 = false;
                eVar.f12196g = false;
                measuredWidth2 = view.getMeasuredWidth();
                measuredHeight2 = view.getMeasuredHeight();
                baseline = view.getBaseline();
                i15 = -1;
            } else {
                if (measuredWidth != measuredWidth2) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                }
                if (measuredHeight != measuredHeight2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824);
                }
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                eVar.f12166H = iMakeMeasureSpec2;
                eVar.f12167I = iMakeMeasureSpec3;
                z15 = false;
                eVar.f12196g = false;
                measuredWidth2 = view.getMeasuredWidth();
                measuredHeight2 = view.getMeasuredHeight();
                baseline = view.getBaseline();
                i15 = -1;
            }
        } else {
            if (view instanceof VirtualLayout) {
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
            } else {
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
            }
            eVar.f12166H = iMakeMeasureSpec2;
            eVar.f12167I = iMakeMeasureSpec3;
            eVar.f12196g = false;
            measuredWidth = view.getMeasuredWidth();
            measuredHeight = view.getMeasuredHeight();
            baseline = view.getBaseline();
            i11 = eVar.f12223u;
            if (i11 > 0) {
                measuredWidth2 = Math.max(i11, measuredWidth);
            } else {
                measuredWidth2 = measuredWidth;
            }
            i12 = eVar.f12224v;
            if (i12 > 0) {
                measuredWidth2 = Math.min(i12, measuredWidth2);
            }
            i13 = eVar.f12226x;
            if (i13 > 0) {
                measuredHeight2 = Math.max(i13, measuredHeight);
            } else {
                measuredHeight2 = measuredHeight;
            }
            z14 = z13;
            i14 = eVar.f12227y;
            if (i14 > 0) {
                measuredHeight2 = Math.min(i14, measuredHeight2);
            }
            if (!k.c(constraintLayout.f16126s, 1)) {
                if (!z12) {
                    if (z14) {
                        measuredHeight2 = (int) ((measuredWidth2 / eVar.f12182Y) + 0.5f);
                    }
                } else if (z14) {
                    measuredHeight2 = (int) ((measuredWidth2 / eVar.f12182Y) + 0.5f);
                }
            }
            if (measuredWidth == measuredWidth2) {
                if (measuredWidth != measuredWidth2) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                }
                if (measuredHeight != measuredHeight2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824);
                }
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                eVar.f12166H = iMakeMeasureSpec2;
                eVar.f12167I = iMakeMeasureSpec3;
                z15 = false;
                eVar.f12196g = false;
                measuredWidth2 = view.getMeasuredWidth();
                measuredHeight2 = view.getMeasuredHeight();
                baseline = view.getBaseline();
                i15 = -1;
            } else {
                if (measuredWidth != measuredWidth2) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                }
                if (measuredHeight != measuredHeight2) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824);
                }
                view.measure(iMakeMeasureSpec2, iMakeMeasureSpec3);
                eVar.f12166H = iMakeMeasureSpec2;
                eVar.f12167I = iMakeMeasureSpec3;
                z15 = false;
                eVar.f12196g = false;
                measuredWidth2 = view.getMeasuredWidth();
                measuredHeight2 = view.getMeasuredHeight();
                baseline = view.getBaseline();
                i15 = -1;
            }
        }
        if (baseline != i15) {
            z16 = true;
        } else {
            z16 = z15;
        }
        if (measuredWidth2 == bVar.f12803c) {
            z17 = true;
        } else {
            z17 = true;
        }
        bVar.f12809i = z17;
        if (layoutParams.f16163c0) {
            z16 = true;
        }
        if (z16) {
            bVar.f12809i = true;
        }
        bVar.f12805e = measuredWidth2;
        bVar.f12806f = measuredHeight2;
        bVar.f12808h = z16;
        bVar.f12807g = baseline;
    }
}
