package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import p005a1.k;
import p005a1.l;
import p005a1.m;

/* JADX INFO: loaded from: classes.dex */
public class ReactiveGuide extends View implements l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16217a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16218b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16219c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final boolean f16220d;

    public ReactiveGuide(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16217a = -1;
        this.f16218b = false;
        this.f16219c = 0;
        this.f16220d = true;
        super.setVisibility(8);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15042d);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 3) {
                    this.f16217a = typedArrayObtainStyledAttributes.getResourceId(index, this.f16217a);
                } else if (index == 0) {
                    this.f16218b = typedArrayObtainStyledAttributes.getBoolean(index, this.f16218b);
                } else if (index == 2) {
                    this.f16219c = typedArrayObtainStyledAttributes.getResourceId(index, this.f16219c);
                } else if (index == 1) {
                    this.f16220d = typedArrayObtainStyledAttributes.getBoolean(index, this.f16220d);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (this.f16217a != -1) {
            ConstraintLayout.getSharedValues().a(this.f16217a, this);
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
    }

    public int getApplyToConstraintSetId() {
        return this.f16219c;
    }

    public int getAttributeId() {
        return this.f16217a;
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        setMeasuredDimension(0, 0);
    }

    public void setAnimateChange(boolean z3) {
        this.f16218b = z3;
    }

    public void setApplyToConstraintSetId(int i10) {
        this.f16219c = i10;
    }

    public void setAttributeId(int i10) {
        HashSet<WeakReference> hashSet;
        m sharedValues = ConstraintLayout.getSharedValues();
        int i11 = this.f16217a;
        if (i11 != -1 && (hashSet = (HashSet) sharedValues.f15064a.get(Integer.valueOf(i11))) != null) {
            ArrayList arrayList = new ArrayList();
            for (WeakReference weakReference : hashSet) {
                l lVar = (l) weakReference.get();
                if (lVar == null || lVar == this) {
                    arrayList.add(weakReference);
                }
            }
            hashSet.removeAll(arrayList);
        }
        this.f16217a = i10;
        if (i10 != -1) {
            sharedValues.a(i10, this);
        }
    }

    public void setGuidelineBegin(int i10) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) getLayoutParams();
        layoutParams.f16158a = i10;
        setLayoutParams(layoutParams);
    }

    public void setGuidelineEnd(int i10) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) getLayoutParams();
        layoutParams.f16160b = i10;
        setLayoutParams(layoutParams);
    }

    public void setGuidelinePercent(float f10) {
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) getLayoutParams();
        layoutParams.f16162c = f10;
        setLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
    }
}
