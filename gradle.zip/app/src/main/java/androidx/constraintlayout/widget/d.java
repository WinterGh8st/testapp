package androidx.constraintlayout.widget;

import G6.F0;
import G6.y0;
import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.motion.widget.MotionLayout;
import com.flamingotools.ws.R;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import org.xmlpull.v1.XmlPullParserException;
import p005a1.e;
import p005a1.f;
import p005a1.g;
import p005a1.h;
import p005a1.j;
import p005a1.k;
import p005a1.m;
import p032c7.AbstractC0933i;

/* JADX INFO: loaded from: classes.dex */
public final class d {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final int[] f16240h = {0, 4, 8};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public static final SparseIntArray f16241i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public static final SparseIntArray f16242j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public String f16243a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f16244b = "";

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public String[] f16245c = new String[0];

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16246d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final HashMap f16247e = new HashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f16248f = true;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public final HashMap f16249g = new HashMap();

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f16241i = sparseIntArray;
        SparseIntArray sparseIntArray2 = new SparseIntArray();
        f16242j = sparseIntArray2;
        sparseIntArray.append(82, 25);
        sparseIntArray.append(83, 26);
        sparseIntArray.append(85, 29);
        sparseIntArray.append(86, 30);
        sparseIntArray.append(92, 36);
        sparseIntArray.append(91, 35);
        sparseIntArray.append(63, 4);
        sparseIntArray.append(62, 3);
        sparseIntArray.append(58, 1);
        sparseIntArray.append(60, 91);
        sparseIntArray.append(59, 92);
        sparseIntArray.append(101, 6);
        sparseIntArray.append(102, 7);
        sparseIntArray.append(70, 17);
        sparseIntArray.append(71, 18);
        sparseIntArray.append(72, 19);
        sparseIntArray.append(54, 99);
        sparseIntArray.append(0, 27);
        sparseIntArray.append(87, 32);
        sparseIntArray.append(88, 33);
        sparseIntArray.append(69, 10);
        sparseIntArray.append(68, 9);
        sparseIntArray.append(106, 13);
        sparseIntArray.append(109, 16);
        sparseIntArray.append(107, 14);
        sparseIntArray.append(104, 11);
        sparseIntArray.append(108, 15);
        sparseIntArray.append(105, 12);
        sparseIntArray.append(95, 40);
        sparseIntArray.append(80, 39);
        sparseIntArray.append(79, 41);
        sparseIntArray.append(94, 42);
        sparseIntArray.append(78, 20);
        sparseIntArray.append(93, 37);
        sparseIntArray.append(67, 5);
        sparseIntArray.append(81, 87);
        sparseIntArray.append(90, 87);
        sparseIntArray.append(84, 87);
        sparseIntArray.append(61, 87);
        sparseIntArray.append(57, 87);
        sparseIntArray.append(5, 24);
        sparseIntArray.append(7, 28);
        sparseIntArray.append(23, 31);
        sparseIntArray.append(24, 8);
        sparseIntArray.append(6, 34);
        sparseIntArray.append(8, 2);
        sparseIntArray.append(3, 23);
        sparseIntArray.append(4, 21);
        sparseIntArray.append(96, 95);
        sparseIntArray.append(73, 96);
        sparseIntArray.append(2, 22);
        sparseIntArray.append(13, 43);
        sparseIntArray.append(26, 44);
        sparseIntArray.append(21, 45);
        sparseIntArray.append(22, 46);
        sparseIntArray.append(20, 60);
        sparseIntArray.append(18, 47);
        sparseIntArray.append(19, 48);
        sparseIntArray.append(14, 49);
        sparseIntArray.append(15, 50);
        sparseIntArray.append(16, 51);
        sparseIntArray.append(17, 52);
        sparseIntArray.append(25, 53);
        sparseIntArray.append(97, 54);
        sparseIntArray.append(74, 55);
        sparseIntArray.append(98, 56);
        sparseIntArray.append(75, 57);
        sparseIntArray.append(99, 58);
        sparseIntArray.append(76, 59);
        sparseIntArray.append(64, 61);
        sparseIntArray.append(66, 62);
        sparseIntArray.append(65, 63);
        sparseIntArray.append(28, 64);
        sparseIntArray.append(121, 65);
        sparseIntArray.append(35, 66);
        sparseIntArray.append(122, 67);
        sparseIntArray.append(113, 79);
        sparseIntArray.append(1, 38);
        sparseIntArray.append(112, 68);
        sparseIntArray.append(100, 69);
        sparseIntArray.append(77, 70);
        sparseIntArray.append(111, 97);
        sparseIntArray.append(32, 71);
        sparseIntArray.append(30, 72);
        sparseIntArray.append(31, 73);
        sparseIntArray.append(33, 74);
        sparseIntArray.append(29, 75);
        sparseIntArray.append(114, 76);
        sparseIntArray.append(89, 77);
        sparseIntArray.append(123, 78);
        sparseIntArray.append(56, 80);
        sparseIntArray.append(55, 81);
        sparseIntArray.append(116, 82);
        sparseIntArray.append(120, 83);
        sparseIntArray.append(119, 84);
        sparseIntArray.append(118, 85);
        sparseIntArray.append(117, 86);
        sparseIntArray2.append(85, 6);
        sparseIntArray2.append(85, 7);
        sparseIntArray2.append(0, 27);
        sparseIntArray2.append(89, 13);
        sparseIntArray2.append(92, 16);
        sparseIntArray2.append(90, 14);
        sparseIntArray2.append(87, 11);
        sparseIntArray2.append(91, 15);
        sparseIntArray2.append(88, 12);
        sparseIntArray2.append(78, 40);
        sparseIntArray2.append(71, 39);
        sparseIntArray2.append(70, 41);
        sparseIntArray2.append(77, 42);
        sparseIntArray2.append(69, 20);
        sparseIntArray2.append(76, 37);
        sparseIntArray2.append(60, 5);
        sparseIntArray2.append(72, 87);
        sparseIntArray2.append(75, 87);
        sparseIntArray2.append(73, 87);
        sparseIntArray2.append(57, 87);
        sparseIntArray2.append(56, 87);
        sparseIntArray2.append(5, 24);
        sparseIntArray2.append(7, 28);
        sparseIntArray2.append(23, 31);
        sparseIntArray2.append(24, 8);
        sparseIntArray2.append(6, 34);
        sparseIntArray2.append(8, 2);
        sparseIntArray2.append(3, 23);
        sparseIntArray2.append(4, 21);
        sparseIntArray2.append(79, 95);
        sparseIntArray2.append(64, 96);
        sparseIntArray2.append(2, 22);
        sparseIntArray2.append(13, 43);
        sparseIntArray2.append(26, 44);
        sparseIntArray2.append(21, 45);
        sparseIntArray2.append(22, 46);
        sparseIntArray2.append(20, 60);
        sparseIntArray2.append(18, 47);
        sparseIntArray2.append(19, 48);
        sparseIntArray2.append(14, 49);
        sparseIntArray2.append(15, 50);
        sparseIntArray2.append(16, 51);
        sparseIntArray2.append(17, 52);
        sparseIntArray2.append(25, 53);
        sparseIntArray2.append(80, 54);
        sparseIntArray2.append(65, 55);
        sparseIntArray2.append(81, 56);
        sparseIntArray2.append(66, 57);
        sparseIntArray2.append(82, 58);
        sparseIntArray2.append(67, 59);
        sparseIntArray2.append(59, 62);
        sparseIntArray2.append(58, 63);
        sparseIntArray2.append(28, 64);
        sparseIntArray2.append(105, 65);
        sparseIntArray2.append(34, 66);
        sparseIntArray2.append(106, 67);
        sparseIntArray2.append(96, 79);
        sparseIntArray2.append(1, 38);
        sparseIntArray2.append(97, 98);
        sparseIntArray2.append(95, 68);
        sparseIntArray2.append(83, 69);
        sparseIntArray2.append(68, 70);
        sparseIntArray2.append(32, 71);
        sparseIntArray2.append(30, 72);
        sparseIntArray2.append(31, 73);
        sparseIntArray2.append(33, 74);
        sparseIntArray2.append(29, 75);
        sparseIntArray2.append(98, 76);
        sparseIntArray2.append(74, 77);
        sparseIntArray2.append(107, 78);
        sparseIntArray2.append(55, 80);
        sparseIntArray2.append(54, 81);
        sparseIntArray2.append(100, 82);
        sparseIntArray2.append(104, 83);
        sparseIntArray2.append(103, 84);
        sparseIntArray2.append(102, 85);
        sparseIntArray2.append(101, 86);
        sparseIntArray2.append(94, 97);
    }

    public static c d(Context context, XmlResourceParser xmlResourceParser) {
        AttributeSet attributeSetAsAttributeSet = Xml.asAttributeSet(xmlResourceParser);
        c cVar = new c();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSetAsAttributeSet, k.f15044f);
        p(cVar, typedArrayObtainStyledAttributes);
        typedArrayObtainStyledAttributes.recycle();
        return cVar;
    }

    public static int[] g(Barrier barrier, String str) {
        int iIntValue;
        String[] strArrSplit = str.split(",");
        Context context = barrier.getContext();
        int[] iArr = new int[strArrSplit.length];
        int i10 = 0;
        int i11 = 0;
        while (i10 < strArrSplit.length) {
            String strTrim = strArrSplit[i10].trim();
            Object obj = null;
            try {
                iIntValue = j.class.getField(strTrim).getInt(null);
            } catch (Exception unused) {
                iIntValue = 0;
            }
            if (iIntValue == 0) {
                iIntValue = context.getResources().getIdentifier(strTrim, "id", context.getPackageName());
            }
            if (iIntValue == 0 && barrier.isInEditMode() && (barrier.getParent() instanceof ConstraintLayout)) {
                ConstraintLayout constraintLayout = (ConstraintLayout) barrier.getParent();
                if (strTrim != null) {
                    HashMap map = constraintLayout.f16130w;
                    if (map != null && map.containsKey(strTrim)) {
                        obj = constraintLayout.f16130w.get(strTrim);
                    }
                } else {
                    constraintLayout.getClass();
                }
                if (obj != null && (obj instanceof Integer)) {
                    iIntValue = ((Integer) obj).intValue();
                }
            }
            iArr[i11] = iIntValue;
            i10++;
            i11++;
        }
        return i11 != strArrSplit.length ? Arrays.copyOf(iArr, i11) : iArr;
    }

    public static c h(Context context, AttributeSet attributeSet, boolean z3) {
        c cVar = new c();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, z3 ? k.f15044f : k.f15040b);
        if (z3) {
            p(cVar, typedArrayObtainStyledAttributes);
        } else {
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            int i10 = 0;
            while (true) {
                e eVar = cVar.f16236e;
                if (i10 < indexCount) {
                    int index = typedArrayObtainStyledAttributes.getIndex(i10);
                    g gVar = cVar.f16234c;
                    h hVar = cVar.f16237f;
                    f fVar = cVar.f16235d;
                    if (index != 1 && 23 != index && 24 != index) {
                        fVar.f15000a = true;
                        eVar.f14960b = true;
                        gVar.f15012a = true;
                        hVar.f15018a = true;
                    }
                    SparseIntArray sparseIntArray = f16241i;
                    switch (sparseIntArray.get(index)) {
                        case 1:
                            eVar.f14989q = m(typedArrayObtainStyledAttributes, index, eVar.f14989q);
                            break;
                        case 2:
                            eVar.f14942J = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14942J);
                            break;
                        case 3:
                            eVar.f14987p = m(typedArrayObtainStyledAttributes, index, eVar.f14987p);
                            break;
                        case 4:
                            eVar.f14985o = m(typedArrayObtainStyledAttributes, index, eVar.f14985o);
                            break;
                        case 5:
                            eVar.f14998z = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 6:
                            eVar.f14936D = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f14936D);
                            break;
                        case 7:
                            eVar.f14937E = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f14937E);
                            break;
                        case 8:
                            eVar.f14943K = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14943K);
                            break;
                        case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                            eVar.f14995w = m(typedArrayObtainStyledAttributes, index, eVar.f14995w);
                            break;
                        case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                            eVar.f14994v = m(typedArrayObtainStyledAttributes, index, eVar.f14994v);
                            break;
                        case 11:
                            eVar.f14948Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14948Q);
                            break;
                        case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                            eVar.f14949R = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14949R);
                            break;
                        case 13:
                            eVar.f14945N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14945N);
                            break;
                        case 14:
                            eVar.f14947P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14947P);
                            break;
                        case 15:
                            eVar.f14950S = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14950S);
                            break;
                        case 16:
                            eVar.f14946O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14946O);
                            break;
                        case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                            eVar.f14966e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f14966e);
                            break;
                        case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                            eVar.f14968f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, eVar.f14968f);
                            break;
                        case 19:
                            eVar.f14970g = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14970g);
                            break;
                        case 20:
                            eVar.f14996x = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14996x);
                            break;
                        case 21:
                            eVar.f14964d = typedArrayObtainStyledAttributes.getLayoutDimension(index, eVar.f14964d);
                            break;
                        case 22:
                            int i11 = typedArrayObtainStyledAttributes.getInt(index, gVar.f15013b);
                            gVar.f15013b = i11;
                            gVar.f15013b = f16240h[i11];
                            break;
                        case 23:
                            eVar.f14962c = typedArrayObtainStyledAttributes.getLayoutDimension(index, eVar.f14962c);
                            break;
                        case 24:
                            eVar.f14939G = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14939G);
                            break;
                        case 25:
                            eVar.f14974i = m(typedArrayObtainStyledAttributes, index, eVar.f14974i);
                            break;
                        case 26:
                            eVar.f14976j = m(typedArrayObtainStyledAttributes, index, eVar.f14976j);
                            break;
                        case 27:
                            eVar.f14938F = typedArrayObtainStyledAttributes.getInt(index, eVar.f14938F);
                            break;
                        case 28:
                            eVar.f14940H = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14940H);
                            break;
                        case 29:
                            eVar.k = m(typedArrayObtainStyledAttributes, index, eVar.k);
                            break;
                        case 30:
                            eVar.f14979l = m(typedArrayObtainStyledAttributes, index, eVar.f14979l);
                            break;
                        case 31:
                            eVar.f14944L = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14944L);
                            break;
                        case 32:
                            eVar.f14992t = m(typedArrayObtainStyledAttributes, index, eVar.f14992t);
                            break;
                        case 33:
                            eVar.f14993u = m(typedArrayObtainStyledAttributes, index, eVar.f14993u);
                            break;
                        case 34:
                            eVar.f14941I = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14941I);
                            break;
                        case 35:
                            eVar.f14983n = m(typedArrayObtainStyledAttributes, index, eVar.f14983n);
                            break;
                        case 36:
                            eVar.f14981m = m(typedArrayObtainStyledAttributes, index, eVar.f14981m);
                            break;
                        case 37:
                            eVar.f14997y = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14997y);
                            break;
                        case 38:
                            cVar.f16232a = typedArrayObtainStyledAttributes.getResourceId(index, cVar.f16232a);
                            break;
                        case 39:
                            eVar.f14953V = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14953V);
                            break;
                        case 40:
                            eVar.f14952U = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14952U);
                            break;
                        case 41:
                            eVar.f14954W = typedArrayObtainStyledAttributes.getInt(index, eVar.f14954W);
                            break;
                        case 42:
                            eVar.f14955X = typedArrayObtainStyledAttributes.getInt(index, eVar.f14955X);
                            break;
                        case 43:
                            gVar.f15015d = typedArrayObtainStyledAttributes.getFloat(index, gVar.f15015d);
                            break;
                        case 44:
                            hVar.f15029m = true;
                            hVar.f15030n = typedArrayObtainStyledAttributes.getDimension(index, hVar.f15030n);
                            break;
                        case 45:
                            hVar.f15020c = typedArrayObtainStyledAttributes.getFloat(index, hVar.f15020c);
                            break;
                        case 46:
                            hVar.f15021d = typedArrayObtainStyledAttributes.getFloat(index, hVar.f15021d);
                            break;
                        case 47:
                            hVar.f15022e = typedArrayObtainStyledAttributes.getFloat(index, hVar.f15022e);
                            break;
                        case 48:
                            hVar.f15023f = typedArrayObtainStyledAttributes.getFloat(index, hVar.f15023f);
                            break;
                        case 49:
                            hVar.f15024g = typedArrayObtainStyledAttributes.getDimension(index, hVar.f15024g);
                            break;
                        case 50:
                            hVar.f15025h = typedArrayObtainStyledAttributes.getDimension(index, hVar.f15025h);
                            break;
                        case 51:
                            hVar.f15027j = typedArrayObtainStyledAttributes.getDimension(index, hVar.f15027j);
                            break;
                        case 52:
                            hVar.k = typedArrayObtainStyledAttributes.getDimension(index, hVar.k);
                            break;
                        case 53:
                            hVar.f15028l = typedArrayObtainStyledAttributes.getDimension(index, hVar.f15028l);
                            break;
                        case 54:
                            eVar.f14956Y = typedArrayObtainStyledAttributes.getInt(index, eVar.f14956Y);
                            break;
                        case 55:
                            eVar.f14957Z = typedArrayObtainStyledAttributes.getInt(index, eVar.f14957Z);
                            break;
                        case 56:
                            eVar.f14959a0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14959a0);
                            break;
                        case 57:
                            eVar.f14961b0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14961b0);
                            break;
                        case 58:
                            eVar.f14963c0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14963c0);
                            break;
                        case 59:
                            eVar.f14965d0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14965d0);
                            break;
                        case 60:
                            hVar.f15019b = typedArrayObtainStyledAttributes.getFloat(index, hVar.f15019b);
                            break;
                        case 61:
                            eVar.f14933A = m(typedArrayObtainStyledAttributes, index, eVar.f14933A);
                            break;
                        case 62:
                            eVar.f14934B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14934B);
                            break;
                        case 63:
                            eVar.f14935C = typedArrayObtainStyledAttributes.getFloat(index, eVar.f14935C);
                            break;
                        case 64:
                            fVar.f15001b = m(typedArrayObtainStyledAttributes, index, fVar.f15001b);
                            break;
                        case 65:
                            if (typedArrayObtainStyledAttributes.peekValue(index).type != 3) {
                                fVar.f15003d = T0.e.f11526d[typedArrayObtainStyledAttributes.getInteger(index, 0)];
                            } else {
                                fVar.f15003d = typedArrayObtainStyledAttributes.getString(index);
                            }
                            break;
                        case 66:
                            fVar.f15005f = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 67:
                            fVar.f15007h = typedArrayObtainStyledAttributes.getFloat(index, fVar.f15007h);
                            break;
                        case 68:
                            gVar.f15016e = typedArrayObtainStyledAttributes.getFloat(index, gVar.f15016e);
                            break;
                        case 69:
                            eVar.f14967e0 = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                            break;
                        case 70:
                            eVar.f14969f0 = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                            break;
                        case 71:
                            Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                            break;
                        case 72:
                            eVar.f14971g0 = typedArrayObtainStyledAttributes.getInt(index, eVar.f14971g0);
                            break;
                        case 73:
                            eVar.f14973h0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14973h0);
                            break;
                        case 74:
                            eVar.f14978k0 = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 75:
                            eVar.f14986o0 = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f14986o0);
                            break;
                        case 76:
                            fVar.f15004e = typedArrayObtainStyledAttributes.getInt(index, fVar.f15004e);
                            break;
                        case 77:
                            eVar.f14980l0 = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 78:
                            gVar.f15014c = typedArrayObtainStyledAttributes.getInt(index, gVar.f15014c);
                            break;
                        case 79:
                            fVar.f15006g = typedArrayObtainStyledAttributes.getFloat(index, fVar.f15006g);
                            break;
                        case 80:
                            eVar.f14982m0 = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f14982m0);
                            break;
                        case 81:
                            eVar.f14984n0 = typedArrayObtainStyledAttributes.getBoolean(index, eVar.f14984n0);
                            break;
                        case 82:
                            fVar.f15002c = typedArrayObtainStyledAttributes.getInteger(index, fVar.f15002c);
                            break;
                        case 83:
                            hVar.f15026i = m(typedArrayObtainStyledAttributes, index, hVar.f15026i);
                            break;
                        case 84:
                            fVar.f15009j = typedArrayObtainStyledAttributes.getInteger(index, fVar.f15009j);
                            break;
                        case 85:
                            fVar.f15008i = typedArrayObtainStyledAttributes.getFloat(index, fVar.f15008i);
                            break;
                        case 86:
                            int i12 = typedArrayObtainStyledAttributes.peekValue(index).type;
                            if (i12 == 1) {
                                int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                                fVar.f15011m = resourceId;
                                if (resourceId != -1) {
                                    fVar.f15010l = -2;
                                }
                            } else if (i12 != 3) {
                                fVar.f15010l = typedArrayObtainStyledAttributes.getInteger(index, fVar.f15011m);
                            } else {
                                String string = typedArrayObtainStyledAttributes.getString(index);
                                fVar.k = string;
                                if (string.indexOf("/") <= 0) {
                                    fVar.f15010l = -1;
                                } else {
                                    fVar.f15011m = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                                    fVar.f15010l = -2;
                                }
                            }
                            break;
                        case 87:
                            Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                            break;
                        case 88:
                        case 89:
                        case 90:
                        default:
                            Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                            break;
                        case 91:
                            eVar.f14990r = m(typedArrayObtainStyledAttributes, index, eVar.f14990r);
                            break;
                        case 92:
                            eVar.f14991s = m(typedArrayObtainStyledAttributes, index, eVar.f14991s);
                            break;
                        case 93:
                            eVar.M = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.M);
                            break;
                        case 94:
                            eVar.f14951T = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, eVar.f14951T);
                            break;
                        case 95:
                            n(eVar, typedArrayObtainStyledAttributes, index, 0);
                            break;
                        case 96:
                            n(eVar, typedArrayObtainStyledAttributes, index, 1);
                            break;
                        case 97:
                            eVar.f14988p0 = typedArrayObtainStyledAttributes.getInt(index, eVar.f14988p0);
                            break;
                    }
                    i10++;
                } else if (eVar.f14978k0 != null) {
                    eVar.f14977j0 = null;
                }
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        return cVar;
    }

    public static int m(TypedArray typedArray, int i10, int i11) {
        int resourceId = typedArray.getResourceId(i10, i11);
        return resourceId == -1 ? typedArray.getInt(i10, -1) : resourceId;
    }

    /* JADX WARN: Code duplicated, block: B:123:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:20:0x0036  */
    /* JADX WARN: Code duplicated, block: B:22:0x003a  */
    /* JADX WARN: Code duplicated, block: B:24:0x003f  */
    /* JADX WARN: Code duplicated, block: B:26:0x0044  */
    /* JADX WARN: Code duplicated, block: B:28:0x0048  */
    /* JADX WARN: Code duplicated, block: B:30:0x004c  */
    /* JADX WARN: Code duplicated, block: B:32:0x0051  */
    /* JADX WARN: Code duplicated, block: B:34:0x0056  */
    /* JADX WARN: Code duplicated, block: B:36:0x005a  */
    /* JADX WARN: Code duplicated, block: B:38:0x005e  */
    /* JADX WARN: Code duplicated, block: B:40:0x0067  */
    public static void n(Object obj, TypedArray typedArray, int i10, int i11) {
        int dimensionPixelSize;
        p005a1.d dVar;
        e eVar;
        ConstraintLayout.LayoutParams layoutParams;
        if (obj == null) {
            return;
        }
        int i12 = typedArray.peekValue(i10).type;
        boolean z3 = true;
        int i13 = 0;
        if (i12 != 3) {
            if (i12 != 5) {
                dimensionPixelSize = typedArray.getInt(i10, 0);
                if (dimensionPixelSize == -4) {
                    i13 = -2;
                } else if (dimensionPixelSize == -3 || (dimensionPixelSize != -2 && dimensionPixelSize != -1)) {
                    z3 = false;
                }
                if (obj instanceof ConstraintLayout.LayoutParams) {
                    layoutParams = (ConstraintLayout.LayoutParams) obj;
                    if (i11 == 0) {
                        ((ViewGroup.MarginLayoutParams) layoutParams).width = i13;
                        layoutParams.f16154W = z3;
                        return;
                    } else {
                        ((ViewGroup.MarginLayoutParams) layoutParams).height = i13;
                        layoutParams.f16155X = z3;
                        return;
                    }
                }
                if (obj instanceof e) {
                    eVar = (e) obj;
                    if (i11 == 0) {
                        eVar.f14962c = i13;
                        eVar.f14982m0 = z3;
                        return;
                    } else {
                        eVar.f14964d = i13;
                        eVar.f14984n0 = z3;
                        return;
                    }
                }
                if (obj instanceof p005a1.d) {
                    dVar = (p005a1.d) obj;
                    if (i11 == 0) {
                        dVar.b(23, i13);
                        dVar.d(80, z3);
                        return;
                    } else {
                        dVar.b(21, i13);
                        dVar.d(81, z3);
                        return;
                    }
                }
                return;
            }
            dimensionPixelSize = typedArray.getDimensionPixelSize(i10, 0);
            z3 = false;
            i13 = dimensionPixelSize;
            if (obj instanceof ConstraintLayout.LayoutParams) {
                layoutParams = (ConstraintLayout.LayoutParams) obj;
                if (i11 == 0) {
                    ((ViewGroup.MarginLayoutParams) layoutParams).width = i13;
                    layoutParams.f16154W = z3;
                    return;
                } else {
                    ((ViewGroup.MarginLayoutParams) layoutParams).height = i13;
                    layoutParams.f16155X = z3;
                    return;
                }
            }
            if (obj instanceof e) {
                eVar = (e) obj;
                if (i11 == 0) {
                    eVar.f14962c = i13;
                    eVar.f14982m0 = z3;
                    return;
                } else {
                    eVar.f14964d = i13;
                    eVar.f14984n0 = z3;
                    return;
                }
            }
            if (obj instanceof p005a1.d) {
                dVar = (p005a1.d) obj;
                if (i11 == 0) {
                    dVar.b(23, i13);
                    dVar.d(80, z3);
                    return;
                } else {
                    dVar.b(21, i13);
                    dVar.d(81, z3);
                    return;
                }
            }
            return;
        }
        String string = typedArray.getString(i10);
        if (string == null) {
            return;
        }
        int iIndexOf = string.indexOf(61);
        int length = string.length();
        if (iIndexOf <= 0 || iIndexOf >= length - 1) {
            return;
        }
        String strSubstring = string.substring(0, iIndexOf);
        String strSubstring2 = string.substring(iIndexOf + 1);
        if (strSubstring2.length() > 0) {
            String strTrim = strSubstring.trim();
            String strTrim2 = strSubstring2.trim();
            if ("ratio".equalsIgnoreCase(strTrim)) {
                if (obj instanceof ConstraintLayout.LayoutParams) {
                    ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) obj;
                    if (i11 == 0) {
                        ((ViewGroup.MarginLayoutParams) layoutParams2).width = 0;
                    } else {
                        ((ViewGroup.MarginLayoutParams) layoutParams2).height = 0;
                    }
                    o(layoutParams2, strTrim2);
                    return;
                }
                if (obj instanceof e) {
                    ((e) obj).f14998z = strTrim2;
                    return;
                } else {
                    if (obj instanceof p005a1.d) {
                        ((p005a1.d) obj).c(5, strTrim2);
                        return;
                    }
                    return;
                }
            }
            try {
                if ("weight".equalsIgnoreCase(strTrim)) {
                    float f10 = Float.parseFloat(strTrim2);
                    if (obj instanceof ConstraintLayout.LayoutParams) {
                        ConstraintLayout.LayoutParams layoutParams3 = (ConstraintLayout.LayoutParams) obj;
                        if (i11 == 0) {
                            ((ViewGroup.MarginLayoutParams) layoutParams3).width = 0;
                            layoutParams3.f16140H = f10;
                            return;
                        } else {
                            ((ViewGroup.MarginLayoutParams) layoutParams3).height = 0;
                            layoutParams3.f16141I = f10;
                            return;
                        }
                    }
                    if (obj instanceof e) {
                        e eVar2 = (e) obj;
                        if (i11 == 0) {
                            eVar2.f14962c = 0;
                            eVar2.f14953V = f10;
                            return;
                        } else {
                            eVar2.f14964d = 0;
                            eVar2.f14952U = f10;
                            return;
                        }
                    }
                    if (obj instanceof p005a1.d) {
                        p005a1.d dVar2 = (p005a1.d) obj;
                        if (i11 == 0) {
                            dVar2.b(23, 0);
                            dVar2.a(39, f10);
                            return;
                        } else {
                            dVar2.b(21, 0);
                            dVar2.a(40, f10);
                            return;
                        }
                    }
                    return;
                }
                if ("parent".equalsIgnoreCase(strTrim)) {
                    float fMax = Math.max(0.0f, Math.min(1.0f, Float.parseFloat(strTrim2)));
                    if (obj instanceof ConstraintLayout.LayoutParams) {
                        ConstraintLayout.LayoutParams layoutParams4 = (ConstraintLayout.LayoutParams) obj;
                        if (i11 == 0) {
                            ((ViewGroup.MarginLayoutParams) layoutParams4).width = 0;
                            layoutParams4.f16149R = fMax;
                            layoutParams4.f16144L = 2;
                            return;
                        } else {
                            ((ViewGroup.MarginLayoutParams) layoutParams4).height = 0;
                            layoutParams4.f16150S = fMax;
                            layoutParams4.M = 2;
                            return;
                        }
                    }
                    if (obj instanceof e) {
                        e eVar3 = (e) obj;
                        if (i11 == 0) {
                            eVar3.f14962c = 0;
                            eVar3.f14967e0 = fMax;
                            eVar3.f14956Y = 2;
                            return;
                        } else {
                            eVar3.f14964d = 0;
                            eVar3.f14969f0 = fMax;
                            eVar3.f14957Z = 2;
                            return;
                        }
                    }
                    if (obj instanceof p005a1.d) {
                        p005a1.d dVar3 = (p005a1.d) obj;
                        if (i11 == 0) {
                            dVar3.b(23, 0);
                            dVar3.b(54, 2);
                        } else {
                            dVar3.b(21, 0);
                            dVar3.b(55, 2);
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
    }

    public static void o(ConstraintLayout.LayoutParams layoutParams, String str) {
        if (str != null) {
            int length = str.length();
            int iIndexOf = str.indexOf(44);
            byte b10 = -1;
            int i10 = 0;
            if (iIndexOf > 0 && iIndexOf < length - 1) {
                String strSubstring = str.substring(0, iIndexOf);
                if (strSubstring.equalsIgnoreCase("W")) {
                    b10 = 0;
                } else if (strSubstring.equalsIgnoreCase("H")) {
                    b10 = 1;
                }
                i10 = iIndexOf + 1;
            }
            int iIndexOf2 = str.indexOf(58);
            try {
                if (iIndexOf2 < 0 || iIndexOf2 >= length - 1) {
                    String strSubstring2 = str.substring(i10);
                    if (strSubstring2.length() > 0) {
                        Float.parseFloat(strSubstring2);
                    }
                } else {
                    String strSubstring3 = str.substring(i10, iIndexOf2);
                    String strSubstring4 = str.substring(iIndexOf2 + 1);
                    if (strSubstring3.length() > 0 && strSubstring4.length() > 0) {
                        float f10 = Float.parseFloat(strSubstring3);
                        float f11 = Float.parseFloat(strSubstring4);
                        if (f10 > 0.0f && f11 > 0.0f) {
                            if (b10 == 1) {
                                Math.abs(f11 / f10);
                            } else {
                                Math.abs(f10 / f11);
                            }
                        }
                    }
                }
            } catch (NumberFormatException unused) {
            }
        }
        layoutParams.f16139G = str;
    }

    public static void p(c cVar, TypedArray typedArray) {
        char c10;
        int indexCount = typedArray.getIndexCount();
        p005a1.d dVar = new p005a1.d();
        dVar.f14921a = new int[10];
        dVar.f14922b = new int[10];
        dVar.f14923c = 0;
        dVar.f14924d = new int[10];
        dVar.f14925e = new float[10];
        dVar.f14926f = 0;
        dVar.f14927g = new int[5];
        dVar.f14928h = new String[5];
        dVar.f14929i = 0;
        dVar.f14930j = new int[4];
        dVar.k = new boolean[4];
        dVar.f14931l = 0;
        cVar.f16239h = dVar;
        f fVar = cVar.f16235d;
        fVar.f15000a = false;
        e eVar = cVar.f16236e;
        eVar.f14960b = false;
        g gVar = cVar.f16234c;
        gVar.f15012a = false;
        h hVar = cVar.f16237f;
        hVar.f15018a = false;
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArray.getIndex(i10);
            int i11 = f16242j.get(index);
            SparseIntArray sparseIntArray = f16241i;
            switch (i11) {
                case 2:
                    c10 = 5;
                    dVar.b(2, typedArray.getDimensionPixelSize(index, eVar.f14942J));
                    break;
                case 3:
                case 4:
                case F0.ARRAY_VALUE_FIELD_NUMBER /* 9 */:
                case F0.TIMESTAMP_VALUE_FIELD_NUMBER /* 10 */:
                case 25:
                case 26:
                case 29:
                case 30:
                case 32:
                case 33:
                case 35:
                case 36:
                case 61:
                case 88:
                case 89:
                case 90:
                case 91:
                case 92:
                default:
                    Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                    c10 = 5;
                    break;
                case 5:
                    c10 = 5;
                    dVar.c(5, typedArray.getString(index));
                    break;
                case 6:
                    dVar.b(6, typedArray.getDimensionPixelOffset(index, eVar.f14936D));
                    c10 = 5;
                    break;
                case 7:
                    dVar.b(7, typedArray.getDimensionPixelOffset(index, eVar.f14937E));
                    c10 = 5;
                    break;
                case 8:
                    dVar.b(8, typedArray.getDimensionPixelSize(index, eVar.f14943K));
                    c10 = 5;
                    break;
                case 11:
                    dVar.b(11, typedArray.getDimensionPixelSize(index, eVar.f14948Q));
                    c10 = 5;
                    break;
                case y0.EXPECTED_COUNT_FIELD_NUMBER /* 12 */:
                    dVar.b(12, typedArray.getDimensionPixelSize(index, eVar.f14949R));
                    c10 = 5;
                    break;
                case 13:
                    dVar.b(13, typedArray.getDimensionPixelSize(index, eVar.f14945N));
                    c10 = 5;
                    break;
                case 14:
                    dVar.b(14, typedArray.getDimensionPixelSize(index, eVar.f14947P));
                    c10 = 5;
                    break;
                case 15:
                    dVar.b(15, typedArray.getDimensionPixelSize(index, eVar.f14950S));
                    c10 = 5;
                    break;
                case 16:
                    dVar.b(16, typedArray.getDimensionPixelSize(index, eVar.f14946O));
                    c10 = 5;
                    break;
                case F0.STRING_VALUE_FIELD_NUMBER /* 17 */:
                    dVar.b(17, typedArray.getDimensionPixelOffset(index, eVar.f14966e));
                    c10 = 5;
                    break;
                case F0.BYTES_VALUE_FIELD_NUMBER /* 18 */:
                    dVar.b(18, typedArray.getDimensionPixelOffset(index, eVar.f14968f));
                    c10 = 5;
                    break;
                case 19:
                    dVar.a(19, typedArray.getFloat(index, eVar.f14970g));
                    c10 = 5;
                    break;
                case 20:
                    dVar.a(20, typedArray.getFloat(index, eVar.f14996x));
                    c10 = 5;
                    break;
                case 21:
                    dVar.b(21, typedArray.getLayoutDimension(index, eVar.f14964d));
                    c10 = 5;
                    break;
                case 22:
                    dVar.b(22, f16240h[typedArray.getInt(index, gVar.f15013b)]);
                    c10 = 5;
                    break;
                case 23:
                    dVar.b(23, typedArray.getLayoutDimension(index, eVar.f14962c));
                    c10 = 5;
                    break;
                case 24:
                    dVar.b(24, typedArray.getDimensionPixelSize(index, eVar.f14939G));
                    c10 = 5;
                    break;
                case 27:
                    dVar.b(27, typedArray.getInt(index, eVar.f14938F));
                    c10 = 5;
                    break;
                case 28:
                    dVar.b(28, typedArray.getDimensionPixelSize(index, eVar.f14940H));
                    c10 = 5;
                    break;
                case 31:
                    dVar.b(31, typedArray.getDimensionPixelSize(index, eVar.f14944L));
                    c10 = 5;
                    break;
                case 34:
                    dVar.b(34, typedArray.getDimensionPixelSize(index, eVar.f14941I));
                    c10 = 5;
                    break;
                case 37:
                    dVar.a(37, typedArray.getFloat(index, eVar.f14997y));
                    c10 = 5;
                    break;
                case 38:
                    int resourceId = typedArray.getResourceId(index, cVar.f16232a);
                    cVar.f16232a = resourceId;
                    dVar.b(38, resourceId);
                    c10 = 5;
                    break;
                case 39:
                    dVar.a(39, typedArray.getFloat(index, eVar.f14953V));
                    c10 = 5;
                    break;
                case 40:
                    dVar.a(40, typedArray.getFloat(index, eVar.f14952U));
                    c10 = 5;
                    break;
                case 41:
                    dVar.b(41, typedArray.getInt(index, eVar.f14954W));
                    c10 = 5;
                    break;
                case 42:
                    dVar.b(42, typedArray.getInt(index, eVar.f14955X));
                    c10 = 5;
                    break;
                case 43:
                    dVar.a(43, typedArray.getFloat(index, gVar.f15015d));
                    c10 = 5;
                    break;
                case 44:
                    dVar.d(44, true);
                    dVar.a(44, typedArray.getDimension(index, hVar.f15030n));
                    c10 = 5;
                    break;
                case 45:
                    dVar.a(45, typedArray.getFloat(index, hVar.f15020c));
                    c10 = 5;
                    break;
                case 46:
                    dVar.a(46, typedArray.getFloat(index, hVar.f15021d));
                    c10 = 5;
                    break;
                case 47:
                    dVar.a(47, typedArray.getFloat(index, hVar.f15022e));
                    c10 = 5;
                    break;
                case 48:
                    dVar.a(48, typedArray.getFloat(index, hVar.f15023f));
                    c10 = 5;
                    break;
                case 49:
                    dVar.a(49, typedArray.getDimension(index, hVar.f15024g));
                    c10 = 5;
                    break;
                case 50:
                    dVar.a(50, typedArray.getDimension(index, hVar.f15025h));
                    c10 = 5;
                    break;
                case 51:
                    dVar.a(51, typedArray.getDimension(index, hVar.f15027j));
                    c10 = 5;
                    break;
                case 52:
                    dVar.a(52, typedArray.getDimension(index, hVar.k));
                    c10 = 5;
                    break;
                case 53:
                    dVar.a(53, typedArray.getDimension(index, hVar.f15028l));
                    c10 = 5;
                    break;
                case 54:
                    dVar.b(54, typedArray.getInt(index, eVar.f14956Y));
                    c10 = 5;
                    break;
                case 55:
                    dVar.b(55, typedArray.getInt(index, eVar.f14957Z));
                    c10 = 5;
                    break;
                case 56:
                    dVar.b(56, typedArray.getDimensionPixelSize(index, eVar.f14959a0));
                    c10 = 5;
                    break;
                case 57:
                    dVar.b(57, typedArray.getDimensionPixelSize(index, eVar.f14961b0));
                    c10 = 5;
                    break;
                case 58:
                    dVar.b(58, typedArray.getDimensionPixelSize(index, eVar.f14963c0));
                    c10 = 5;
                    break;
                case 59:
                    dVar.b(59, typedArray.getDimensionPixelSize(index, eVar.f14965d0));
                    c10 = 5;
                    break;
                case 60:
                    dVar.a(60, typedArray.getFloat(index, hVar.f15019b));
                    c10 = 5;
                    break;
                case 62:
                    dVar.b(62, typedArray.getDimensionPixelSize(index, eVar.f14934B));
                    c10 = 5;
                    break;
                case 63:
                    dVar.a(63, typedArray.getFloat(index, eVar.f14935C));
                    c10 = 5;
                    break;
                case 64:
                    dVar.b(64, m(typedArray, index, fVar.f15001b));
                    c10 = 5;
                    break;
                case 65:
                    if (typedArray.peekValue(index).type == 3) {
                        dVar.c(65, typedArray.getString(index));
                    } else {
                        dVar.c(65, T0.e.f11526d[typedArray.getInteger(index, 0)]);
                    }
                    c10 = 5;
                    break;
                case 66:
                    dVar.b(66, typedArray.getInt(index, 0));
                    c10 = 5;
                    break;
                case 67:
                    dVar.a(67, typedArray.getFloat(index, fVar.f15007h));
                    c10 = 5;
                    break;
                case 68:
                    dVar.a(68, typedArray.getFloat(index, gVar.f15016e));
                    c10 = 5;
                    break;
                case 69:
                    dVar.a(69, typedArray.getFloat(index, 1.0f));
                    c10 = 5;
                    break;
                case 70:
                    dVar.a(70, typedArray.getFloat(index, 1.0f));
                    c10 = 5;
                    break;
                case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    c10 = 5;
                    break;
                case 72:
                    dVar.b(72, typedArray.getInt(index, eVar.f14971g0));
                    c10 = 5;
                    break;
                case 73:
                    dVar.b(73, typedArray.getDimensionPixelSize(index, eVar.f14973h0));
                    c10 = 5;
                    break;
                case 74:
                    dVar.c(74, typedArray.getString(index));
                    c10 = 5;
                    break;
                case 75:
                    dVar.d(75, typedArray.getBoolean(index, eVar.f14986o0));
                    c10 = 5;
                    break;
                case 76:
                    dVar.b(76, typedArray.getInt(index, fVar.f15004e));
                    c10 = 5;
                    break;
                case 77:
                    dVar.c(77, typedArray.getString(index));
                    c10 = 5;
                    break;
                case 78:
                    dVar.b(78, typedArray.getInt(index, gVar.f15014c));
                    c10 = 5;
                    break;
                case 79:
                    dVar.a(79, typedArray.getFloat(index, fVar.f15006g));
                    c10 = 5;
                    break;
                case 80:
                    dVar.d(80, typedArray.getBoolean(index, eVar.f14982m0));
                    c10 = 5;
                    break;
                case 81:
                    dVar.d(81, typedArray.getBoolean(index, eVar.f14984n0));
                    c10 = 5;
                    break;
                case 82:
                    dVar.b(82, typedArray.getInteger(index, fVar.f15002c));
                    c10 = 5;
                    break;
                case 83:
                    dVar.b(83, m(typedArray, index, hVar.f15026i));
                    c10 = 5;
                    break;
                case 84:
                    dVar.b(84, typedArray.getInteger(index, fVar.f15009j));
                    c10 = 5;
                    break;
                case 85:
                    dVar.a(85, typedArray.getFloat(index, fVar.f15008i));
                    c10 = 5;
                    break;
                case 86:
                    int i12 = typedArray.peekValue(index).type;
                    if (i12 == 1) {
                        int resourceId2 = typedArray.getResourceId(index, -1);
                        fVar.f15011m = resourceId2;
                        dVar.b(89, resourceId2);
                        if (fVar.f15011m != -1) {
                            fVar.f15010l = -2;
                            dVar.b(88, -2);
                        }
                    } else if (i12 == 3) {
                        String string = typedArray.getString(index);
                        fVar.k = string;
                        dVar.c(90, string);
                        if (fVar.k.indexOf("/") > 0) {
                            int resourceId3 = typedArray.getResourceId(index, -1);
                            fVar.f15011m = resourceId3;
                            dVar.b(89, resourceId3);
                            fVar.f15010l = -2;
                            dVar.b(88, -2);
                        } else {
                            fVar.f15010l = -1;
                            dVar.b(88, -1);
                        }
                    } else {
                        int integer = typedArray.getInteger(index, fVar.f15011m);
                        fVar.f15010l = integer;
                        dVar.b(88, integer);
                    }
                    c10 = 5;
                    break;
                case 87:
                    Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + sparseIntArray.get(index));
                    c10 = 5;
                    break;
                case 93:
                    dVar.b(93, typedArray.getDimensionPixelSize(index, eVar.M));
                    c10 = 5;
                    break;
                case 94:
                    dVar.b(94, typedArray.getDimensionPixelSize(index, eVar.f14951T));
                    c10 = 5;
                    break;
                case 95:
                    n(dVar, typedArray, index, 0);
                    c10 = 5;
                    break;
                case 96:
                    n(dVar, typedArray, index, 1);
                    c10 = 5;
                    break;
                case 97:
                    dVar.b(97, typedArray.getInt(index, eVar.f14988p0));
                    c10 = 5;
                    break;
                case 98:
                    if (MotionLayout.f15943P0) {
                        int resourceId4 = typedArray.getResourceId(index, cVar.f16232a);
                        cVar.f16232a = resourceId4;
                        if (resourceId4 == -1) {
                            cVar.f16233b = typedArray.getString(index);
                        }
                    } else if (typedArray.peekValue(index).type == 3) {
                        cVar.f16233b = typedArray.getString(index);
                    } else {
                        cVar.f16232a = typedArray.getResourceId(index, cVar.f16232a);
                    }
                    c10 = 5;
                    break;
                case 99:
                    dVar.d(99, typedArray.getBoolean(index, eVar.f14972h));
                    c10 = 5;
                    break;
            }
        }
    }

    public static String q(int i10) {
        switch (i10) {
            case 1:
                return "left";
            case 2:
                return "right";
            case 3:
                return "top";
            case 4:
                return "bottom";
            case 5:
                return "baseline";
            case 6:
                return "start";
            case 7:
                return "end";
            default:
                return "undefined";
        }
    }

    public final void a(MotionLayout motionLayout) {
        c cVar;
        int childCount = motionLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = motionLayout.getChildAt(i10);
            int id = childAt.getId();
            HashMap map = this.f16249g;
            if (!map.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + p123ja.a.K(childAt));
            } else {
                if (this.f16248f && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (map.containsKey(Integer.valueOf(id)) && (cVar = (c) map.get(Integer.valueOf(id))) != null) {
                    p005a1.a.e(childAt, cVar.f16238g);
                }
            }
        }
    }

    public final void b(ConstraintLayout constraintLayout) {
        c(constraintLayout);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    public final void c(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        HashMap map = this.f16249g;
        HashSet<Integer> hashSet = new HashSet(map.keySet());
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            int id = childAt.getId();
            if (!map.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + p123ja.a.K(childAt));
            } else {
                if (this.f16248f && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (id != -1) {
                    if (map.containsKey(Integer.valueOf(id))) {
                        hashSet.remove(Integer.valueOf(id));
                        c cVar = (c) map.get(Integer.valueOf(id));
                        if (cVar != null) {
                            if (childAt instanceof Barrier) {
                                e eVar = cVar.f16236e;
                                eVar.f14975i0 = 1;
                                Barrier barrier = (Barrier) childAt;
                                barrier.setId(id);
                                barrier.setType(eVar.f14971g0);
                                barrier.setMargin(eVar.f14973h0);
                                barrier.setAllowsGoneWidget(eVar.f14986o0);
                                int[] iArr = eVar.f14977j0;
                                if (iArr != null) {
                                    barrier.setReferencedIds(iArr);
                                } else {
                                    String str = eVar.f14978k0;
                                    if (str != null) {
                                        int[] iArrG = g(barrier, str);
                                        eVar.f14977j0 = iArrG;
                                        barrier.setReferencedIds(iArrG);
                                    }
                                }
                            }
                            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
                            layoutParams.a();
                            cVar.a(layoutParams);
                            p005a1.a.e(childAt, cVar.f16238g);
                            childAt.setLayoutParams(layoutParams);
                            g gVar = cVar.f16234c;
                            if (gVar.f15014c == 0) {
                                childAt.setVisibility(gVar.f15013b);
                            }
                            childAt.setAlpha(gVar.f15015d);
                            h hVar = cVar.f16237f;
                            childAt.setRotation(hVar.f15019b);
                            childAt.setRotationX(hVar.f15020c);
                            childAt.setRotationY(hVar.f15021d);
                            childAt.setScaleX(hVar.f15022e);
                            childAt.setScaleY(hVar.f15023f);
                            if (hVar.f15026i != -1) {
                                View viewFindViewById = ((View) childAt.getParent()).findViewById(hVar.f15026i);
                                if (viewFindViewById != null) {
                                    float bottom = (viewFindViewById.getBottom() + viewFindViewById.getTop()) / 2.0f;
                                    float right = (viewFindViewById.getRight() + viewFindViewById.getLeft()) / 2.0f;
                                    if (childAt.getRight() - childAt.getLeft() > 0 && childAt.getBottom() - childAt.getTop() > 0) {
                                        float left = right - childAt.getLeft();
                                        float top = bottom - childAt.getTop();
                                        childAt.setPivotX(left);
                                        childAt.setPivotY(top);
                                    }
                                }
                            } else {
                                if (!Float.isNaN(hVar.f15024g)) {
                                    childAt.setPivotX(hVar.f15024g);
                                }
                                if (!Float.isNaN(hVar.f15025h)) {
                                    childAt.setPivotY(hVar.f15025h);
                                }
                            }
                            childAt.setTranslationX(hVar.f15027j);
                            childAt.setTranslationY(hVar.k);
                            childAt.setTranslationZ(hVar.f15028l);
                            if (hVar.f15029m) {
                                childAt.setElevation(hVar.f15030n);
                            }
                        }
                    } else {
                        Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                    }
                }
            }
        }
        for (Integer num : hashSet) {
            c cVar2 = (c) map.get(num);
            if (cVar2 != null) {
                e eVar2 = cVar2.f16236e;
                if (eVar2.f14975i0 == 1) {
                    Barrier barrier2 = new Barrier(constraintLayout.getContext());
                    barrier2.setId(num.intValue());
                    int[] iArr2 = eVar2.f14977j0;
                    if (iArr2 != null) {
                        barrier2.setReferencedIds(iArr2);
                    } else {
                        String str2 = eVar2.f14978k0;
                        if (str2 != null) {
                            int[] iArrG2 = g(barrier2, str2);
                            eVar2.f14977j0 = iArrG2;
                            barrier2.setReferencedIds(iArrG2);
                        }
                    }
                    barrier2.setType(eVar2.f14971g0);
                    barrier2.setMargin(eVar2.f14973h0);
                    m mVar = ConstraintLayout.f16117z;
                    ConstraintLayout.LayoutParams layoutParams2 = new ConstraintLayout.LayoutParams(-2, -2);
                    barrier2.q();
                    cVar2.a(layoutParams2);
                    constraintLayout.addView(barrier2, layoutParams2);
                }
                if (eVar2.f14958a) {
                    View guideline = new Guideline(constraintLayout.getContext());
                    guideline.setId(num.intValue());
                    m mVar2 = ConstraintLayout.f16117z;
                    ConstraintLayout.LayoutParams layoutParams3 = new ConstraintLayout.LayoutParams(-2, -2);
                    cVar2.a(layoutParams3);
                    constraintLayout.addView(guideline, layoutParams3);
                }
            }
        }
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt2 = constraintLayout.getChildAt(i11);
            if (childAt2 instanceof ConstraintHelper) {
                ((ConstraintHelper) childAt2).g(constraintLayout);
            }
        }
    }

    public final void e(ConstraintLayout constraintLayout) {
        int i10;
        HashMap map;
        HashMap map2;
        d dVar = this;
        int childCount = constraintLayout.getChildCount();
        HashMap map3 = dVar.f16249g;
        map3.clear();
        int i11 = 0;
        while (i11 < childCount) {
            View childAt = constraintLayout.getChildAt(i11);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (dVar.f16248f && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!map3.containsKey(Integer.valueOf(id))) {
                map3.put(Integer.valueOf(id), new c());
            }
            c cVar = (c) map3.get(Integer.valueOf(id));
            if (cVar == null) {
                i10 = childCount;
                map = map3;
            } else {
                HashMap map4 = dVar.f16247e;
                HashMap map5 = new HashMap();
                Class<?> cls = childAt.getClass();
                for (String str : map4.keySet()) {
                    p005a1.a aVar = (p005a1.a) map4.get(str);
                    int i12 = childCount;
                    try {
                        if (str.equals("BackgroundColor")) {
                            map2 = map3;
                            try {
                                map5.put(str, new p005a1.a(aVar, Integer.valueOf(((ColorDrawable) childAt.getBackground()).getColor())));
                            } catch (IllegalAccessException e10) {
                                e = e10;
                                StringBuilder sbJ = AbstractC0933i.j(" Custom Attribute \"", str, "\" not found on ");
                                sbJ.append(cls.getName());
                                Log.e("TransitionLayout", sbJ.toString(), e);
                            } catch (NoSuchMethodException e11) {
                                e = e11;
                                Log.e("TransitionLayout", cls.getName() + " must have a method " + str, e);
                            } catch (InvocationTargetException e12) {
                                e = e12;
                                StringBuilder sbJ2 = AbstractC0933i.j(" Custom Attribute \"", str, "\" not found on ");
                                sbJ2.append(cls.getName());
                                Log.e("TransitionLayout", sbJ2.toString(), e);
                            }
                        } else {
                            map2 = map3;
                            map5.put(str, new p005a1.a(aVar, cls.getMethod("getMap" + str, null).invoke(childAt, null)));
                        }
                    } catch (IllegalAccessException e13) {
                        e = e13;
                        map2 = map3;
                    } catch (NoSuchMethodException e14) {
                        e = e14;
                        map2 = map3;
                    } catch (InvocationTargetException e15) {
                        e = e15;
                        map2 = map3;
                    }
                    childCount = i12;
                    map3 = map2;
                }
                i10 = childCount;
                map = map3;
                cVar.f16238g = map5;
                cVar.c(id, layoutParams);
                int visibility = childAt.getVisibility();
                g gVar = cVar.f16234c;
                gVar.f15013b = visibility;
                gVar.f15015d = childAt.getAlpha();
                float rotation = childAt.getRotation();
                h hVar = cVar.f16237f;
                hVar.f15019b = rotation;
                hVar.f15020c = childAt.getRotationX();
                hVar.f15021d = childAt.getRotationY();
                hVar.f15022e = childAt.getScaleX();
                hVar.f15023f = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (pivotX != 0.0d || pivotY != 0.0d) {
                    hVar.f15024g = pivotX;
                    hVar.f15025h = pivotY;
                }
                hVar.f15027j = childAt.getTranslationX();
                hVar.k = childAt.getTranslationY();
                hVar.f15028l = childAt.getTranslationZ();
                if (hVar.f15029m) {
                    hVar.f15030n = childAt.getElevation();
                }
                if (childAt instanceof Barrier) {
                    Barrier barrier = (Barrier) childAt;
                    boolean allowsGoneWidget = barrier.getAllowsGoneWidget();
                    e eVar = cVar.f16236e;
                    eVar.f14986o0 = allowsGoneWidget;
                    eVar.f14977j0 = barrier.getReferencedIds();
                    eVar.f14971g0 = barrier.getType();
                    eVar.f14973h0 = barrier.getMargin();
                }
            }
            i11++;
            dVar = this;
            childCount = i10;
            map3 = map;
        }
    }

    public final void f(int i10, int i11, int i12) {
        HashMap map = this.f16249g;
        Integer numValueOf = Integer.valueOf(R.id.child_scroll);
        if (!map.containsKey(numValueOf)) {
            map.put(numValueOf, new c());
        }
        c cVar = (c) map.get(numValueOf);
        if (cVar == null) {
            return;
        }
        e eVar = cVar.f16236e;
        switch (i10) {
            case 1:
                if (i12 == 1) {
                    eVar.f14974i = i11;
                    eVar.f14976j = -1;
                    return;
                } else if (i12 == 2) {
                    eVar.f14976j = i11;
                    eVar.f14974i = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("left to " + q(i12) + " undefined");
                }
            case 2:
                if (i12 == 1) {
                    eVar.k = i11;
                    eVar.f14979l = -1;
                    return;
                } else if (i12 == 2) {
                    eVar.f14979l = i11;
                    eVar.k = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
            case 3:
                if (i12 == 3) {
                    eVar.f14981m = i11;
                    eVar.f14983n = -1;
                    eVar.f14989q = -1;
                    eVar.f14990r = -1;
                    eVar.f14991s = -1;
                    return;
                }
                if (i12 != 4) {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
                eVar.f14983n = i11;
                eVar.f14981m = -1;
                eVar.f14989q = -1;
                eVar.f14990r = -1;
                eVar.f14991s = -1;
                return;
            case 4:
                if (i12 == 4) {
                    eVar.f14987p = i11;
                    eVar.f14985o = -1;
                    eVar.f14989q = -1;
                    eVar.f14990r = -1;
                    eVar.f14991s = -1;
                    return;
                }
                if (i12 != 3) {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
                eVar.f14985o = i11;
                eVar.f14987p = -1;
                eVar.f14989q = -1;
                eVar.f14990r = -1;
                eVar.f14991s = -1;
                return;
            case 5:
                if (i12 == 5) {
                    eVar.f14989q = i11;
                    eVar.f14987p = -1;
                    eVar.f14985o = -1;
                    eVar.f14981m = -1;
                    eVar.f14983n = -1;
                    return;
                }
                if (i12 == 3) {
                    eVar.f14990r = i11;
                    eVar.f14987p = -1;
                    eVar.f14985o = -1;
                    eVar.f14981m = -1;
                    eVar.f14983n = -1;
                    return;
                }
                if (i12 != 4) {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
                eVar.f14991s = i11;
                eVar.f14987p = -1;
                eVar.f14985o = -1;
                eVar.f14981m = -1;
                eVar.f14983n = -1;
                return;
            case 6:
                if (i12 == 6) {
                    eVar.f14993u = i11;
                    eVar.f14992t = -1;
                    return;
                } else if (i12 == 7) {
                    eVar.f14992t = i11;
                    eVar.f14993u = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
            case 7:
                if (i12 == 7) {
                    eVar.f14995w = i11;
                    eVar.f14994v = -1;
                    return;
                } else if (i12 == 6) {
                    eVar.f14994v = i11;
                    eVar.f14995w = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + q(i12) + " undefined");
                }
            default:
                throw new IllegalArgumentException(q(i10) + " to " + q(i12) + " unknown");
        }
    }

    public final c i(int i10) {
        HashMap map = this.f16249g;
        if (!map.containsKey(Integer.valueOf(i10))) {
            map.put(Integer.valueOf(i10), new c());
        }
        return (c) map.get(Integer.valueOf(i10));
    }

    public final c j(int i10) {
        HashMap map = this.f16249g;
        if (map.containsKey(Integer.valueOf(i10))) {
            return (c) map.get(Integer.valueOf(i10));
        }
        return null;
    }

    public final void k(Context context, int i10) {
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 2) {
                    String name = xml.getName();
                    c cVarH = h(context, Xml.asAttributeSet(xml), false);
                    if (name.equalsIgnoreCase("Guideline")) {
                        cVarH.f16236e.f14958a = true;
                    }
                    this.f16249g.put(Integer.valueOf(cVarH.f16232a), cVarH);
                }
            }
        } catch (IOException e10) {
            Log.e("ConstraintSet", "Error parsing resource: " + i10, e10);
        } catch (XmlPullParserException e11) {
            Log.e("ConstraintSet", "Error parsing resource: " + i10, e11);
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    public final void l(Context context, XmlResourceParser xmlResourceParser) {
        try {
            int eventType = xmlResourceParser.getEventType();
            c cVarH = null;
            while (eventType != 1) {
                if (eventType == 0) {
                    xmlResourceParser.getName();
                } else if (eventType == 2) {
                    switch (xmlResourceParser.getName()) {
                        case "Constraint":
                            cVarH = h(context, Xml.asAttributeSet(xmlResourceParser), false);
                            break;
                        case "ConstraintOverride":
                            cVarH = h(context, Xml.asAttributeSet(xmlResourceParser), true);
                            break;
                        case "Guideline":
                            cVarH = h(context, Xml.asAttributeSet(xmlResourceParser), false);
                            e eVar = cVarH.f16236e;
                            eVar.f14958a = true;
                            eVar.f14960b = true;
                            break;
                        case "Barrier":
                            cVarH = h(context, Xml.asAttributeSet(xmlResourceParser), false);
                            cVarH.f16236e.f14975i0 = 1;
                            break;
                        case "PropertySet":
                            if (cVarH == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                            }
                            cVarH.f16234c.a(context, Xml.asAttributeSet(xmlResourceParser));
                            break;
                            break;
                        case "Transform":
                            if (cVarH == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                            }
                            cVarH.f16237f.b(context, Xml.asAttributeSet(xmlResourceParser));
                            break;
                            break;
                        case "Layout":
                            if (cVarH == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                            }
                            cVarH.f16236e.b(context, Xml.asAttributeSet(xmlResourceParser));
                            break;
                            break;
                        case "Motion":
                            if (cVarH == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                            }
                            cVarH.f16235d.b(context, Xml.asAttributeSet(xmlResourceParser));
                            break;
                            break;
                        case "CustomAttribute":
                        case "CustomMethod":
                            if (cVarH == null) {
                                throw new RuntimeException("XML parser error must be within a Constraint " + xmlResourceParser.getLineNumber());
                            }
                            p005a1.a.d(context, xmlResourceParser, cVarH.f16238g);
                            break;
                            break;
                    }
                } else if (eventType == 3) {
                    String lowerCase = xmlResourceParser.getName().toLowerCase(Locale.ROOT);
                    switch (lowerCase.hashCode()) {
                        case -2075718416:
                            if (lowerCase.equals("guideline")) {
                            }
                            break;
                        case -190376483:
                            if (lowerCase.equals("constraint")) {
                            }
                            break;
                        case 426575017:
                            if (lowerCase.equals("constraintoverride")) {
                            }
                            break;
                        case 2146106725:
                            if (lowerCase.equals("constraintset")) {
                            }
                            break;
                    }
                    if (r6 == 0) {
                        return;
                    }
                    if (r6 == 1 || r6 == 2 || r6 == 3) {
                        this.f16249g.put(Integer.valueOf(cVarH.f16232a), cVarH);
                        cVarH = null;
                    }
                }
                eventType = xmlResourceParser.next();
            }
        } catch (IOException e10) {
            Log.e("ConstraintSet", "Error parsing XML resource", e10);
        } catch (XmlPullParserException e11) {
            Log.e("ConstraintSet", "Error parsing XML resource", e11);
        }
    }
}
