package androidx.constraintlayout.widget;

import U0.j;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import p005a1.e;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public abstract class ConstraintHelper extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int[] f16108a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16109b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public Context f16110c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public j f16111d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f16112e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public String f16113f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public String f16114q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public View[] f16115r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public HashMap f16116s;

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f16108a = new int[32];
        this.f16112e = false;
        this.f16115r = null;
        this.f16116s = new HashMap();
        this.f16110c = context;
        k(attributeSet);
    }

    public final void b(String str) {
        if (str == null || str.length() == 0 || this.f16110c == null) {
            return;
        }
        String strTrim = str.trim();
        int i10 = i(strTrim);
        if (i10 != 0) {
            this.f16116s.put(Integer.valueOf(i10), strTrim);
            c(i10);
        } else {
            Log.w("ConstraintHelper", "Could not find id of \"" + strTrim + "\"");
        }
    }

    public final void c(int i10) {
        if (i10 == getId()) {
            return;
        }
        int i11 = this.f16109b + 1;
        int[] iArr = this.f16108a;
        if (i11 > iArr.length) {
            this.f16108a = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f16108a;
        int i12 = this.f16109b;
        iArr2[i12] = i10;
        this.f16109b = i12 + 1;
    }

    public final void d(String str) {
        if (str == null || str.length() == 0 || this.f16110c == null) {
            return;
        }
        String strTrim = str.trim();
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (constraintLayout == null) {
            Log.w("ConstraintHelper", "Parent not a ConstraintLayout");
            return;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            if ((layoutParams instanceof ConstraintLayout.LayoutParams) && strTrim.equals(((ConstraintLayout.LayoutParams) layoutParams).f16156Y)) {
                if (childAt.getId() == -1) {
                    Log.w("ConstraintHelper", "to use ConstraintTag view " + childAt.getClass().getSimpleName() + " must have an ID");
                } else {
                    c(childAt.getId());
                }
            }
        }
    }

    public final void e() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        f((ConstraintLayout) parent);
    }

    public final void f(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i10 = 0; i10 < this.f16109b; i10++) {
            View viewE = constraintLayout.e(this.f16108a[i10]);
            if (viewE != null) {
                viewE.setVisibility(visibility);
                if (elevation > 0.0f) {
                    viewE.setTranslationZ(viewE.getTranslationZ() + elevation);
                }
            }
        }
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f16108a, this.f16109b);
    }

    public final int h(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String resourceEntryName;
        if (str != null && (resources = this.f16110c.getResources()) != null) {
            int childCount = constraintLayout.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = constraintLayout.getChildAt(i10);
                if (childAt.getId() != -1) {
                    try {
                        resourceEntryName = resources.getResourceEntryName(childAt.getId());
                    } catch (Resources.NotFoundException unused) {
                        resourceEntryName = null;
                    }
                    if (str.equals(resourceEntryName)) {
                        return childAt.getId();
                    }
                }
            }
        }
        return 0;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0038  */
    public final int i(String str) {
        int iH;
        HashMap map;
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        if (!isInEditMode() || constraintLayout == null) {
            iH = 0;
        } else {
            Object obj = (str == null || (map = constraintLayout.f16130w) == null || !map.containsKey(str)) ? null : constraintLayout.f16130w.get(str);
            if (obj instanceof Integer) {
                iH = ((Integer) obj).intValue();
            } else {
                iH = 0;
            }
        }
        if (iH == 0 && constraintLayout != null) {
            iH = h(constraintLayout, str);
        }
        if (iH == 0) {
            try {
                iH = p005a1.j.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        if (iH != 0) {
            return iH;
        }
        Context context = this.f16110c;
        return context.getResources().getIdentifier(str, "id", context.getPackageName());
    }

    public final View[] j(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f16115r;
        if (viewArr == null || viewArr.length != this.f16109b) {
            this.f16115r = new View[this.f16109b];
        }
        for (int i10 = 0; i10 < this.f16109b; i10++) {
            this.f16115r[i10] = constraintLayout.e(this.f16108a[i10]);
        }
        return this.f16115r;
    }

    public void k(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, k.f15041c);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 35) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.f16113f = string;
                    setIds(string);
                } else if (index == 36) {
                    String string2 = typedArrayObtainStyledAttributes.getString(index);
                    this.f16114q = string2;
                    setReferenceTags(string2);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    public void l(c cVar, j jVar, Constraints.LayoutParams layoutParams, SparseArray sparseArray) {
        e eVar = cVar.f16236e;
        int[] iArr = eVar.f14977j0;
        int i10 = 0;
        if (iArr != null) {
            setReferencedIds(iArr);
        } else {
            String str = eVar.f14978k0;
            if (str != null) {
                if (str.length() > 0) {
                    String[] strArrSplit = eVar.f14978k0.split(",");
                    int[] iArrCopyOf = new int[strArrSplit.length];
                    int i11 = 0;
                    for (String str2 : strArrSplit) {
                        int i12 = i(str2.trim());
                        if (i12 != 0) {
                            iArrCopyOf[i11] = i12;
                            i11++;
                        }
                    }
                    if (i11 != strArrSplit.length) {
                        iArrCopyOf = Arrays.copyOf(iArrCopyOf, i11);
                    }
                    eVar.f14977j0 = iArrCopyOf;
                } else {
                    eVar.f14977j0 = null;
                }
            }
        }
        jVar.v0 = 0;
        Arrays.fill(jVar.f12295u0, (Object) null);
        if (eVar.f14977j0 == null) {
            return;
        }
        while (true) {
            int[] iArr2 = eVar.f14977j0;
            if (i10 >= iArr2.length) {
                return;
            }
            U0.e eVar2 = (U0.e) sparseArray.get(iArr2[i10]);
            if (eVar2 != null) {
                jVar.S(eVar2);
            }
            i10++;
        }
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f16113f;
        if (str != null) {
            setIds(str);
        }
        String str2 = this.f16114q;
        if (str2 != null) {
            setReferenceTags(str2);
        }
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        if (this.f16112e) {
            super.onMeasure(i10, i11);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void p(j jVar, SparseArray sparseArray) {
        jVar.v0 = 0;
        Arrays.fill(jVar.f12295u0, (Object) null);
        for (int i10 = 0; i10 < this.f16109b; i10++) {
            jVar.S((U0.e) sparseArray.get(this.f16108a[i10]));
        }
    }

    public final void q() {
        if (this.f16111d == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams) {
            ((ConstraintLayout.LayoutParams) layoutParams).f16190q0 = this.f16111d;
        }
    }

    public void setIds(String str) {
        this.f16113f = str;
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.f16109b = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i10);
            if (iIndexOf == -1) {
                b(str.substring(i10));
                return;
            } else {
                b(str.substring(i10, iIndexOf));
                i10 = iIndexOf + 1;
            }
        }
    }

    public void setReferenceTags(String str) {
        this.f16114q = str;
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.f16109b = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i10);
            if (iIndexOf == -1) {
                d(str.substring(i10));
                return;
            } else {
                d(str.substring(i10, iIndexOf));
                i10 = iIndexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f16113f = null;
        this.f16109b = 0;
        for (int i10 : iArr) {
            c(i10);
        }
    }

    @Override // android.view.View
    public final void setTag(int i10, Object obj) {
        super.setTag(i10, obj);
        if (obj == null && this.f16113f == null) {
            c(i10);
        }
    }

    public void n() {
    }

    public void g(ConstraintLayout constraintLayout) {
    }

    public void o(ConstraintLayout constraintLayout) {
    }

    public void m(U0.e eVar, boolean z3) {
    }
}
