package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.HashMap;
import p005a1.e;
import p005a1.k;

/* JADX INFO: loaded from: classes.dex */
public class Constraints extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public d f16200a;

    public Constraints(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        Log.v("Constraints", " ################# init");
        super.setVisibility(8);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public d getConstraintSet() {
        if (this.f16200a == null) {
            this.f16200a = new d();
        }
        d dVar = this.f16200a;
        dVar.getClass();
        int childCount = getChildCount();
        HashMap map = dVar.f16249g;
        map.clear();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (dVar.f16248f && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!map.containsKey(Integer.valueOf(id))) {
                map.put(Integer.valueOf(id), new c());
            }
            c cVar = (c) map.get(Integer.valueOf(id));
            if (cVar != null) {
                if (childAt instanceof ConstraintHelper) {
                    ConstraintHelper constraintHelper = (ConstraintHelper) childAt;
                    cVar.d(id, layoutParams);
                    if (constraintHelper instanceof Barrier) {
                        e eVar = cVar.f16236e;
                        eVar.f14975i0 = 1;
                        Barrier barrier = (Barrier) constraintHelper;
                        eVar.f14971g0 = barrier.getType();
                        eVar.f14977j0 = barrier.getReferencedIds();
                        eVar.f14973h0 = barrier.getMargin();
                    }
                }
                cVar.d(id, layoutParams);
            }
        }
        return this.f16200a;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.LayoutParams(layoutParams);
    }

    public static class LayoutParams extends ConstraintLayout.LayoutParams {

        /* JADX INFO: renamed from: A0, reason: collision with root package name */
        public final float f16201A0;

        /* JADX INFO: renamed from: B0, reason: collision with root package name */
        public final float f16202B0;

        /* JADX INFO: renamed from: C0, reason: collision with root package name */
        public final float f16203C0;

        /* JADX INFO: renamed from: D0, reason: collision with root package name */
        public final float f16204D0;

        /* JADX INFO: renamed from: r0, reason: collision with root package name */
        public final float f16205r0;

        /* JADX INFO: renamed from: s0, reason: collision with root package name */
        public final boolean f16206s0;

        /* JADX INFO: renamed from: t0, reason: collision with root package name */
        public final float f16207t0;

        /* JADX INFO: renamed from: u0, reason: collision with root package name */
        public final float f16208u0;
        public final float v0;

        /* JADX INFO: renamed from: w0, reason: collision with root package name */
        public final float f16209w0;

        /* JADX INFO: renamed from: x0, reason: collision with root package name */
        public final float f16210x0;

        /* JADX INFO: renamed from: y0, reason: collision with root package name */
        public final float f16211y0;

        /* JADX INFO: renamed from: z0, reason: collision with root package name */
        public final float f16212z0;

        public LayoutParams() {
            super(-2, -2);
            this.f16205r0 = 1.0f;
            this.f16206s0 = false;
            this.f16207t0 = 0.0f;
            this.f16208u0 = 0.0f;
            this.v0 = 0.0f;
            this.f16209w0 = 0.0f;
            this.f16210x0 = 1.0f;
            this.f16211y0 = 1.0f;
            this.f16212z0 = 0.0f;
            this.f16201A0 = 0.0f;
            this.f16202B0 = 0.0f;
            this.f16203C0 = 0.0f;
            this.f16204D0 = 0.0f;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f16205r0 = 1.0f;
            this.f16206s0 = false;
            this.f16207t0 = 0.0f;
            this.f16208u0 = 0.0f;
            this.v0 = 0.0f;
            this.f16209w0 = 0.0f;
            this.f16210x0 = 1.0f;
            this.f16211y0 = 1.0f;
            this.f16212z0 = 0.0f;
            this.f16201A0 = 0.0f;
            this.f16202B0 = 0.0f;
            this.f16203C0 = 0.0f;
            this.f16204D0 = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, k.f15045g);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 15) {
                    this.f16205r0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16205r0);
                } else if (index == 28) {
                    this.f16207t0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16207t0);
                    this.f16206s0 = true;
                } else if (index == 23) {
                    this.v0 = typedArrayObtainStyledAttributes.getFloat(index, this.v0);
                } else if (index == 24) {
                    this.f16209w0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16209w0);
                } else if (index == 22) {
                    this.f16208u0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16208u0);
                } else if (index == 20) {
                    this.f16210x0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16210x0);
                } else if (index == 21) {
                    this.f16211y0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16211y0);
                } else if (index == 16) {
                    this.f16212z0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16212z0);
                } else if (index == 17) {
                    this.f16201A0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16201A0);
                } else if (index == 18) {
                    this.f16202B0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16202B0);
                } else if (index == 19) {
                    this.f16203C0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16203C0);
                } else if (index == 27) {
                    this.f16204D0 = typedArrayObtainStyledAttributes.getFloat(index, this.f16204D0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }
}
