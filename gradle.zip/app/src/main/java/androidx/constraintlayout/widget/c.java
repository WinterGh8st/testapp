package androidx.constraintlayout.widget;

import android.view.ViewGroup;
import java.util.HashMap;
import p005a1.e;
import p005a1.f;
import p005a1.g;
import p005a1.h;

/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f16232a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public String f16233b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final g f16234c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final f f16235d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final e f16236e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final h f16237f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public HashMap f16238g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public p005a1.d f16239h;

    public c() {
        g gVar = new g();
        gVar.f15012a = false;
        gVar.f15013b = 0;
        gVar.f15014c = 0;
        gVar.f15015d = 1.0f;
        gVar.f15016e = Float.NaN;
        this.f16234c = gVar;
        f fVar = new f();
        fVar.f15000a = false;
        fVar.f15001b = -1;
        fVar.f15002c = 0;
        fVar.f15003d = null;
        fVar.f15004e = -1;
        fVar.f15005f = 0;
        fVar.f15006g = Float.NaN;
        fVar.f15007h = Float.NaN;
        fVar.f15008i = Float.NaN;
        fVar.f15009j = -1;
        fVar.k = null;
        fVar.f15010l = -3;
        fVar.f15011m = -1;
        this.f16235d = fVar;
        e eVar = new e();
        eVar.f14958a = false;
        eVar.f14960b = false;
        eVar.f14966e = -1;
        eVar.f14968f = -1;
        eVar.f14970g = -1.0f;
        eVar.f14972h = true;
        eVar.f14974i = -1;
        eVar.f14976j = -1;
        eVar.k = -1;
        eVar.f14979l = -1;
        eVar.f14981m = -1;
        eVar.f14983n = -1;
        eVar.f14985o = -1;
        eVar.f14987p = -1;
        eVar.f14989q = -1;
        eVar.f14990r = -1;
        eVar.f14991s = -1;
        eVar.f14992t = -1;
        eVar.f14993u = -1;
        eVar.f14994v = -1;
        eVar.f14995w = -1;
        eVar.f14996x = 0.5f;
        eVar.f14997y = 0.5f;
        eVar.f14998z = null;
        eVar.f14933A = -1;
        eVar.f14934B = 0;
        eVar.f14935C = 0.0f;
        eVar.f14936D = -1;
        eVar.f14937E = -1;
        eVar.f14938F = -1;
        eVar.f14939G = 0;
        eVar.f14940H = 0;
        eVar.f14941I = 0;
        eVar.f14942J = 0;
        eVar.f14943K = 0;
        eVar.f14944L = 0;
        eVar.M = 0;
        eVar.f14945N = Integer.MIN_VALUE;
        eVar.f14946O = Integer.MIN_VALUE;
        eVar.f14947P = Integer.MIN_VALUE;
        eVar.f14948Q = Integer.MIN_VALUE;
        eVar.f14949R = Integer.MIN_VALUE;
        eVar.f14950S = Integer.MIN_VALUE;
        eVar.f14951T = Integer.MIN_VALUE;
        eVar.f14952U = -1.0f;
        eVar.f14953V = -1.0f;
        eVar.f14954W = 0;
        eVar.f14955X = 0;
        eVar.f14956Y = 0;
        eVar.f14957Z = 0;
        eVar.f14959a0 = 0;
        eVar.f14961b0 = 0;
        eVar.f14963c0 = 0;
        eVar.f14965d0 = 0;
        eVar.f14967e0 = 1.0f;
        eVar.f14969f0 = 1.0f;
        eVar.f14971g0 = -1;
        eVar.f14973h0 = 0;
        eVar.f14975i0 = -1;
        eVar.f14982m0 = false;
        eVar.f14984n0 = false;
        eVar.f14986o0 = true;
        eVar.f14988p0 = 0;
        this.f16236e = eVar;
        h hVar = new h();
        hVar.f15018a = false;
        hVar.f15019b = 0.0f;
        hVar.f15020c = 0.0f;
        hVar.f15021d = 0.0f;
        hVar.f15022e = 1.0f;
        hVar.f15023f = 1.0f;
        hVar.f15024g = Float.NaN;
        hVar.f15025h = Float.NaN;
        hVar.f15026i = -1;
        hVar.f15027j = 0.0f;
        hVar.k = 0.0f;
        hVar.f15028l = 0.0f;
        hVar.f15029m = false;
        hVar.f15030n = 0.0f;
        this.f16237f = hVar;
        this.f16238g = new HashMap();
    }

    public final void a(ConstraintLayout.LayoutParams layoutParams) {
        e eVar = this.f16236e;
        layoutParams.f16166e = eVar.f14974i;
        layoutParams.f16168f = eVar.f14976j;
        layoutParams.f16170g = eVar.k;
        layoutParams.f16172h = eVar.f14979l;
        layoutParams.f16174i = eVar.f14981m;
        layoutParams.f16176j = eVar.f14983n;
        layoutParams.k = eVar.f14985o;
        layoutParams.f16179l = eVar.f14987p;
        layoutParams.f16181m = eVar.f14989q;
        layoutParams.f16183n = eVar.f14990r;
        layoutParams.f16185o = eVar.f14991s;
        layoutParams.f16192s = eVar.f14992t;
        layoutParams.f16193t = eVar.f14993u;
        layoutParams.f16194u = eVar.f14994v;
        layoutParams.f16195v = eVar.f14995w;
        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = eVar.f14939G;
        ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = eVar.f14940H;
        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = eVar.f14941I;
        ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = eVar.f14942J;
        layoutParams.f16133A = eVar.f14950S;
        layoutParams.f16134B = eVar.f14949R;
        layoutParams.f16197x = eVar.f14946O;
        layoutParams.f16199z = eVar.f14948Q;
        layoutParams.f16137E = eVar.f14996x;
        layoutParams.f16138F = eVar.f14997y;
        layoutParams.f16187p = eVar.f14933A;
        layoutParams.f16189q = eVar.f14934B;
        layoutParams.f16191r = eVar.f14935C;
        layoutParams.f16139G = eVar.f14998z;
        layoutParams.f16151T = eVar.f14936D;
        layoutParams.f16152U = eVar.f14937E;
        layoutParams.f16141I = eVar.f14952U;
        layoutParams.f16140H = eVar.f14953V;
        layoutParams.f16143K = eVar.f14955X;
        layoutParams.f16142J = eVar.f14954W;
        layoutParams.f16154W = eVar.f14982m0;
        layoutParams.f16155X = eVar.f14984n0;
        layoutParams.f16144L = eVar.f14956Y;
        layoutParams.M = eVar.f14957Z;
        layoutParams.f16147P = eVar.f14959a0;
        layoutParams.f16148Q = eVar.f14961b0;
        layoutParams.f16145N = eVar.f14963c0;
        layoutParams.f16146O = eVar.f14965d0;
        layoutParams.f16149R = eVar.f14967e0;
        layoutParams.f16150S = eVar.f14969f0;
        layoutParams.f16153V = eVar.f14938F;
        layoutParams.f16162c = eVar.f14970g;
        layoutParams.f16158a = eVar.f14966e;
        layoutParams.f16160b = eVar.f14968f;
        ((ViewGroup.MarginLayoutParams) layoutParams).width = eVar.f14962c;
        ((ViewGroup.MarginLayoutParams) layoutParams).height = eVar.f14964d;
        String str = eVar.f14980l0;
        if (str != null) {
            layoutParams.f16156Y = str;
        }
        layoutParams.f16157Z = eVar.f14988p0;
        layoutParams.setMarginStart(eVar.f14944L);
        layoutParams.setMarginEnd(eVar.f14943K);
        layoutParams.a();
    }

    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public final c clone() {
        c cVar = new c();
        cVar.f16236e.a(this.f16236e);
        cVar.f16235d.a(this.f16235d);
        g gVar = cVar.f16234c;
        g gVar2 = this.f16234c;
        gVar.f15012a = gVar2.f15012a;
        gVar.f15013b = gVar2.f15013b;
        gVar.f15015d = gVar2.f15015d;
        gVar.f15016e = gVar2.f15016e;
        gVar.f15014c = gVar2.f15014c;
        cVar.f16237f.a(this.f16237f);
        cVar.f16232a = this.f16232a;
        cVar.f16239h = this.f16239h;
        return cVar;
    }

    public final void c(int i10, ConstraintLayout.LayoutParams layoutParams) {
        this.f16232a = i10;
        int i11 = layoutParams.f16166e;
        e eVar = this.f16236e;
        eVar.f14974i = i11;
        eVar.f14976j = layoutParams.f16168f;
        eVar.k = layoutParams.f16170g;
        eVar.f14979l = layoutParams.f16172h;
        eVar.f14981m = layoutParams.f16174i;
        eVar.f14983n = layoutParams.f16176j;
        eVar.f14985o = layoutParams.k;
        eVar.f14987p = layoutParams.f16179l;
        eVar.f14989q = layoutParams.f16181m;
        eVar.f14990r = layoutParams.f16183n;
        eVar.f14991s = layoutParams.f16185o;
        eVar.f14992t = layoutParams.f16192s;
        eVar.f14993u = layoutParams.f16193t;
        eVar.f14994v = layoutParams.f16194u;
        eVar.f14995w = layoutParams.f16195v;
        eVar.f14996x = layoutParams.f16137E;
        eVar.f14997y = layoutParams.f16138F;
        eVar.f14998z = layoutParams.f16139G;
        eVar.f14933A = layoutParams.f16187p;
        eVar.f14934B = layoutParams.f16189q;
        eVar.f14935C = layoutParams.f16191r;
        eVar.f14936D = layoutParams.f16151T;
        eVar.f14937E = layoutParams.f16152U;
        eVar.f14938F = layoutParams.f16153V;
        eVar.f14970g = layoutParams.f16162c;
        eVar.f14966e = layoutParams.f16158a;
        eVar.f14968f = layoutParams.f16160b;
        eVar.f14962c = ((ViewGroup.MarginLayoutParams) layoutParams).width;
        eVar.f14964d = ((ViewGroup.MarginLayoutParams) layoutParams).height;
        eVar.f14939G = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
        eVar.f14940H = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        eVar.f14941I = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
        eVar.f14942J = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
        eVar.M = layoutParams.f16136D;
        eVar.f14952U = layoutParams.f16141I;
        eVar.f14953V = layoutParams.f16140H;
        eVar.f14955X = layoutParams.f16143K;
        eVar.f14954W = layoutParams.f16142J;
        eVar.f14982m0 = layoutParams.f16154W;
        eVar.f14984n0 = layoutParams.f16155X;
        eVar.f14956Y = layoutParams.f16144L;
        eVar.f14957Z = layoutParams.M;
        eVar.f14959a0 = layoutParams.f16147P;
        eVar.f14961b0 = layoutParams.f16148Q;
        eVar.f14963c0 = layoutParams.f16145N;
        eVar.f14965d0 = layoutParams.f16146O;
        eVar.f14967e0 = layoutParams.f16149R;
        eVar.f14969f0 = layoutParams.f16150S;
        eVar.f14980l0 = layoutParams.f16156Y;
        eVar.f14946O = layoutParams.f16197x;
        eVar.f14948Q = layoutParams.f16199z;
        eVar.f14945N = layoutParams.f16196w;
        eVar.f14947P = layoutParams.f16198y;
        eVar.f14950S = layoutParams.f16133A;
        eVar.f14949R = layoutParams.f16134B;
        eVar.f14951T = layoutParams.f16135C;
        eVar.f14988p0 = layoutParams.f16157Z;
        eVar.f14943K = layoutParams.getMarginEnd();
        eVar.f14944L = layoutParams.getMarginStart();
    }

    public final void d(int i10, Constraints.LayoutParams layoutParams) {
        c(i10, layoutParams);
        this.f16234c.f15015d = layoutParams.f16205r0;
        float f10 = layoutParams.f16208u0;
        h hVar = this.f16237f;
        hVar.f15019b = f10;
        hVar.f15020c = layoutParams.v0;
        hVar.f15021d = layoutParams.f16209w0;
        hVar.f15022e = layoutParams.f16210x0;
        hVar.f15023f = layoutParams.f16211y0;
        hVar.f15024g = layoutParams.f16212z0;
        hVar.f15025h = layoutParams.f16201A0;
        hVar.f15027j = layoutParams.f16202B0;
        hVar.k = layoutParams.f16203C0;
        hVar.f15028l = layoutParams.f16204D0;
        hVar.f15030n = layoutParams.f16207t0;
        hVar.f15029m = layoutParams.f16206s0;
    }
}
