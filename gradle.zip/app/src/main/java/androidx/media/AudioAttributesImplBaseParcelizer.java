package androidx.media;

import p2.a;

/* JADX INFO: loaded from: classes.dex */
public final class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(a aVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f16552a = aVar.f(audioAttributesImplBase.f16552a, 1);
        audioAttributesImplBase.f16553b = aVar.f(audioAttributesImplBase.f16553b, 2);
        audioAttributesImplBase.f16554c = aVar.f(audioAttributesImplBase.f16554c, 3);
        audioAttributesImplBase.f16555d = aVar.f(audioAttributesImplBase.f16555d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, a aVar) {
        aVar.getClass();
        aVar.j(audioAttributesImplBase.f16552a, 1);
        aVar.j(audioAttributesImplBase.f16553b, 2);
        aVar.j(audioAttributesImplBase.f16554c, 3);
        aVar.j(audioAttributesImplBase.f16555d, 4);
    }
}
