package androidx.media;

import p2.c;

/* JADX INFO: loaded from: classes.dex */
interface AudioAttributesImpl extends c {
}
