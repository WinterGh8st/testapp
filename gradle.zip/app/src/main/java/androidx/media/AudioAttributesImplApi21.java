package androidx.media;

import android.media.AudioAttributes;

/* JADX INFO: loaded from: classes.dex */
class AudioAttributesImplApi21 implements AudioAttributesImpl {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AudioAttributes f16550a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f16551b = -1;

    public final boolean equals(Object obj) {
        if (obj instanceof AudioAttributesImplApi21) {
            return this.f16550a.equals(((AudioAttributesImplApi21) obj).f16550a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f16550a.hashCode();
    }

    public final String toString() {
        return "AudioAttributesCompat: audioattributes=" + this.f16550a;
    }
}
