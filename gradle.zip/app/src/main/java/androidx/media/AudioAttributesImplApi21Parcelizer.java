package androidx.media;

import android.media.AudioAttributes;
import p2.a;
import p2.b;

/* JADX INFO: loaded from: classes.dex */
public final class AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(a aVar) {
        AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
        audioAttributesImplApi21.f16550a = (AudioAttributes) aVar.g(audioAttributesImplApi21.f16550a, 1);
        audioAttributesImplApi21.f16551b = aVar.f(audioAttributesImplApi21.f16551b, 2);
        return audioAttributesImplApi21;
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, a aVar) {
        aVar.getClass();
        AudioAttributes audioAttributes = audioAttributesImplApi21.f16550a;
        aVar.i(1);
        ((b) aVar).f26632e.writeParcelable(audioAttributes, 0);
        aVar.j(audioAttributesImplApi21.f16551b, 2);
    }
}
