package androidx.media;

import android.util.SparseIntArray;
import p2.c;

/* JADX INFO: loaded from: classes.dex */
public class AudioAttributesCompat implements c {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f16548b = 0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public AudioAttributesImpl f16549a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        sparseIntArray.put(5, 1);
        sparseIntArray.put(6, 2);
        sparseIntArray.put(7, 2);
        sparseIntArray.put(8, 1);
        sparseIntArray.put(9, 1);
        sparseIntArray.put(10, 1);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesCompat)) {
            return false;
        }
        AudioAttributesCompat audioAttributesCompat = (AudioAttributesCompat) obj;
        AudioAttributesImpl audioAttributesImpl = this.f16549a;
        if (audioAttributesImpl == null) {
            return audioAttributesCompat.f16549a == null;
        }
        return audioAttributesImpl.equals(audioAttributesCompat.f16549a);
    }

    public final int hashCode() {
        return this.f16549a.hashCode();
    }

    public final String toString() {
        return this.f16549a.toString();
    }
}
