package androidx.coordinatorlayout.widget;

/* JADX INFO: loaded from: classes.dex */
public interface a {
    CoordinatorLayout.Behavior getBehavior();
}
