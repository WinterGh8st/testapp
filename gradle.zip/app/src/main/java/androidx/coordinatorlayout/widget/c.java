package androidx.coordinatorlayout.widget;

import L.AbstractC0492c;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public final class c extends ViewGroup.MarginLayoutParams {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public CoordinatorLayout.Behavior f16274a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f16275b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f16276c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f16277d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int f16278e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int f16279f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f16280g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int f16281h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public int f16282i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f16283j;
    public View k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public View f16284l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public boolean f16285m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public boolean f16286n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public boolean f16287o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public final Rect f16288p;

    public c() {
        super(-2, -2);
        this.f16275b = false;
        this.f16276c = 0;
        this.f16277d = 0;
        this.f16278e = -1;
        this.f16279f = -1;
        this.f16280g = 0;
        this.f16281h = 0;
        this.f16288p = new Rect();
    }

    public final boolean a(int i10) {
        if (i10 == 0) {
            return this.f16285m;
        }
        if (i10 != 1) {
            return false;
        }
        return this.f16286n;
    }

    public final void b(CoordinatorLayout.Behavior behavior) {
        CoordinatorLayout.Behavior behavior2 = this.f16274a;
        if (behavior2 != behavior) {
            if (behavior2 != null) {
                behavior2.j();
            }
            this.f16274a = behavior;
            this.f16275b = true;
            if (behavior != null) {
                behavior.g(this);
            }
        }
    }

    public c(Context context, AttributeSet attributeSet) {
        CoordinatorLayout.Behavior behavior;
        super(context, attributeSet);
        this.f16275b = false;
        this.f16276c = 0;
        this.f16277d = 0;
        this.f16278e = -1;
        this.f16279f = -1;
        this.f16280g = 0;
        this.f16281h = 0;
        this.f16288p = new Rect();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p014b1.a.f17252b);
        this.f16276c = typedArrayObtainStyledAttributes.getInteger(0, 0);
        this.f16279f = typedArrayObtainStyledAttributes.getResourceId(1, -1);
        this.f16277d = typedArrayObtainStyledAttributes.getInteger(2, 0);
        this.f16278e = typedArrayObtainStyledAttributes.getInteger(6, -1);
        this.f16280g = typedArrayObtainStyledAttributes.getInt(5, 0);
        this.f16281h = typedArrayObtainStyledAttributes.getInt(4, 0);
        boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(3);
        this.f16275b = zHasValue;
        if (zHasValue) {
            String string = typedArrayObtainStyledAttributes.getString(3);
            String str = CoordinatorLayout.f16250D;
            if (TextUtils.isEmpty(string)) {
                behavior = null;
            } else {
                if (string.startsWith(".")) {
                    string = context.getPackageName() + string;
                } else if (string.indexOf(46) < 0) {
                    String str2 = CoordinatorLayout.f16250D;
                    if (!TextUtils.isEmpty(str2)) {
                        string = str2 + '.' + string;
                    }
                }
                try {
                    ThreadLocal threadLocal = CoordinatorLayout.f16252F;
                    Map map = (Map) threadLocal.get();
                    if (map == null) {
                        map = new HashMap();
                        threadLocal.set(map);
                    }
                    Constructor<?> constructor = (Constructor) map.get(string);
                    if (constructor == null) {
                        constructor = Class.forName(string, false, context.getClassLoader()).getConstructor(CoordinatorLayout.f16251E);
                        constructor.setAccessible(true);
                        map.put(string, constructor);
                    }
                    behavior = (CoordinatorLayout.Behavior) constructor.newInstance(context, attributeSet);
                } catch (Exception e10) {
                    throw new RuntimeException(AbstractC0492c.s("Could not inflate Behavior subclass ", string), e10);
                }
            }
            this.f16274a = behavior;
        }
        typedArrayObtainStyledAttributes.recycle();
        CoordinatorLayout.Behavior behavior2 = this.f16274a;
        if (behavior2 != null) {
            behavior2.g(this);
        }
    }

    public c(c cVar) {
        super((ViewGroup.MarginLayoutParams) cVar);
        this.f16275b = false;
        this.f16276c = 0;
        this.f16277d = 0;
        this.f16278e = -1;
        this.f16279f = -1;
        this.f16280g = 0;
        this.f16281h = 0;
        this.f16288p = new Rect();
    }

    public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f16275b = false;
        this.f16276c = 0;
        this.f16277d = 0;
        this.f16278e = -1;
        this.f16279f = -1;
        this.f16280g = 0;
        this.f16281h = 0;
        this.f16288p = new Rect();
    }

    public c(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f16275b = false;
        this.f16276c = 0;
        this.f16277d = 0;
        this.f16278e = -1;
        this.f16279f = -1;
        this.f16280g = 0;
        this.f16281h = 0;
        this.f16288p = new Rect();
    }
}
