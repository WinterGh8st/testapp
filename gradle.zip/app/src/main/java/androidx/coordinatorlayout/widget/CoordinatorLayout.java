package androidx.coordinatorlayout.widget;

import B0.C0048e;
import L.C0499e0;
import P.d;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.flamingotools.ws.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import p063f1.h;
import p200r1.A0;
import p200r1.F;
import p200r1.H;
import p200r1.InterfaceC1489p;
import p200r1.InterfaceC1490q;
import p200r1.U;
import p240v.k;
import p278y6.s;

/* JADX INFO: loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements InterfaceC1489p, InterfaceC1490q {

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public static final String f16250D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public static final Class[] f16251E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public static final ThreadLocal f16252F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public static final C0048e f16253G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public static final p189q1.c f16254H;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public ViewGroup.OnHierarchyChangeListener f16255A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public d f16256B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final C0499e0 f16257C;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16258a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final s f16259b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final ArrayList f16260c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final ArrayList f16261d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final int[] f16262e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final int[] f16263f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f16264q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f16265r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int[] f16266s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public View f16267t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public View f16268u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public S2.d f16269v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f16270w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public A0 f16271x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f16272y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public Drawable f16273z;

    static {
        Package r7 = CoordinatorLayout.class.getPackage();
        f16250D = r7 != null ? r7.getName() : null;
        f16253G = new C0048e(7);
        f16251E = new Class[]{Context.class, AttributeSet.class};
        f16252F = new ThreadLocal();
        f16254H = new p189q1.c(12);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        this.f16258a = new ArrayList();
        this.f16259b = new s(24);
        this.f16260c = new ArrayList();
        this.f16261d = new ArrayList();
        this.f16262e = new int[2];
        this.f16263f = new int[2];
        this.f16257C = new C0499e0();
        int[] iArr = p014b1.a.f17251a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, R.attr.coordinatorLayoutStyle, 0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f16266s = intArray;
            float f10 = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i10 = 0; i10 < length; i10++) {
                int[] iArr2 = this.f16266s;
                iArr2[i10] = (int) (iArr2[i10] * f10);
            }
        }
        this.f16273z = typedArrayObtainStyledAttributes.getDrawable(1);
        typedArrayObtainStyledAttributes.recycle();
        C();
        super.setOnHierarchyChangeListener(new p026c1.a(this, 0));
        WeakHashMap weakHashMap = U.f27683a;
        if (getImportantForAccessibility() == 0) {
            setImportantForAccessibility(1);
        }
    }

    public static void A(View view, int i10) {
        c cVar = (c) view.getLayoutParams();
        int i11 = cVar.f16282i;
        if (i11 != i10) {
            WeakHashMap weakHashMap = U.f27683a;
            view.offsetLeftAndRight(i10 - i11);
            cVar.f16282i = i10;
        }
    }

    public static void B(View view, int i10) {
        c cVar = (c) view.getLayoutParams();
        int i11 = cVar.f16283j;
        if (i11 != i10) {
            WeakHashMap weakHashMap = U.f27683a;
            view.offsetTopAndBottom(i10 - i11);
            cVar.f16283j = i10;
        }
    }

    public static Rect k() {
        Rect rect = (Rect) f16254H.a();
        return rect == null ? new Rect() : rect;
    }

    public static void q(int i10, Rect rect, Rect rect2, c cVar, int i11, int i12) {
        int iWidth;
        int iHeight;
        int i13 = cVar.f16276c;
        if (i13 == 0) {
            i13 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i13, i10);
        int i14 = cVar.f16277d;
        if ((i14 & 7) == 0) {
            i14 |= 8388611;
        }
        if ((i14 & 112) == 0) {
            i14 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i14, i10);
        int i15 = absoluteGravity & 7;
        int i16 = absoluteGravity & 112;
        int i17 = absoluteGravity2 & 7;
        int i18 = absoluteGravity2 & 112;
        if (i17 != 1) {
            iWidth = i17 != 5 ? rect.left : rect.right;
        } else {
            iWidth = rect.left + (rect.width() / 2);
        }
        if (i18 != 16) {
            iHeight = i18 != 80 ? rect.top : rect.bottom;
        } else {
            iHeight = rect.top + (rect.height() / 2);
        }
        if (i15 == 1) {
            iWidth -= i11 / 2;
        } else if (i15 != 5) {
            iWidth -= i11;
        }
        if (i16 == 16) {
            iHeight -= i12 / 2;
        } else if (i16 != 80) {
            iHeight -= i12;
        }
        rect2.set(iWidth, iHeight, i11 + iWidth, i12 + iHeight);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static c s(View view) {
        c cVar = (c) view.getLayoutParams();
        if (!cVar.f16275b) {
            if (view instanceof a) {
                Behavior behavior = ((a) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                cVar.b(behavior);
                cVar.f16275b = true;
                return cVar;
            }
            b bVar = null;
            for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                bVar = (b) superclass.getAnnotation(b.class);
                if (bVar != null) {
                    break;
                }
            }
            if (bVar != null) {
                try {
                    cVar.b((Behavior) bVar.value().getDeclaredConstructor(null).newInstance(null));
                } catch (Exception e10) {
                    Log.e("CoordinatorLayout", "Default behavior class " + bVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e10);
                }
            }
            cVar.f16275b = true;
        }
        return cVar;
    }

    public final void C() {
        WeakHashMap weakHashMap = U.f27683a;
        if (!getFitsSystemWindows()) {
            H.u(this, null);
            return;
        }
        if (this.f16256B == null) {
            this.f16256B = new d(this, 19);
        }
        H.u(this, this.f16256B);
        setSystemUiVisibility(1280);
    }

    @Override // p200r1.InterfaceC1489p
    public final void a(View view, View view2, int i10, int i11) {
        C0499e0 c0499e0 = this.f16257C;
        if (i11 == 1) {
            c0499e0.f7842b = i10;
        } else {
            c0499e0.f7841a = i10;
        }
        this.f16268u = view2;
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            ((c) getChildAt(i12).getLayoutParams()).getClass();
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void b(View view, int i10) {
        C0499e0 c0499e0 = this.f16257C;
        if (i10 == 1) {
            c0499e0.f7842b = 0;
        } else {
            c0499e0.f7841a = 0;
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            c cVar = (c) childAt.getLayoutParams();
            if (cVar.a(i10)) {
                Behavior behavior = cVar.f16274a;
                if (behavior != null) {
                    behavior.u(this, childAt, view, i10);
                }
                if (i10 == 0) {
                    cVar.f16285m = false;
                } else if (i10 == 1) {
                    cVar.f16286n = false;
                }
                cVar.f16287o = false;
            }
        }
        this.f16268u = null;
    }

    @Override // p200r1.InterfaceC1489p
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean z3 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                if (cVar.a(i12) && (behavior = cVar.f16274a) != null) {
                    int[] iArr2 = this.f16262e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behavior.o(this, childAt, view, i10, i11, iArr2, i12);
                    iMax = i10 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i11 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z3 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z3) {
            u(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof c) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        Behavior behavior = ((c) view.getLayoutParams()).f16274a;
        if (behavior != null) {
            behavior.getClass();
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f16273z;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // p200r1.InterfaceC1490q
    public final void g(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        Behavior behavior;
        int childCount = getChildCount();
        int iMax = 0;
        int iMax2 = 0;
        boolean z3 = false;
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt = getChildAt(i15);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                if (cVar.a(i14) && (behavior = cVar.f16274a) != null) {
                    int[] iArr2 = this.f16262e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behavior.p(this, childAt, i11, i12, i13, iArr2);
                    iMax = i12 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i13 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z3 = true;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + iMax2;
        if (z3) {
            u(1);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new c();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new c(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        y();
        return Collections.unmodifiableList(this.f16258a);
    }

    public final A0 getLastWindowInsets() {
        return this.f16271x;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0499e0 c0499e0 = this.f16257C;
        return c0499e0.f7842b | c0499e0.f7841a;
    }

    public Drawable getStatusBarBackground() {
        return this.f16273z;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    @Override // p200r1.InterfaceC1489p
    public final void i(View view, int i10, int i11, int i12, int i13, int i14) {
        g(view, i10, i11, i12, i13, 0, this.f16263f);
    }

    @Override // p200r1.InterfaceC1489p
    public final boolean j(View view, View view2, int i10, int i11) {
        int childCount = getChildCount();
        boolean z3 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                Behavior behavior = cVar.f16274a;
                if (behavior != null) {
                    boolean zT = behavior.t(this, childAt, view, view2, i10, i11);
                    z3 |= zT;
                    if (i11 == 0) {
                        cVar.f16285m = zT;
                    } else if (i11 == 1) {
                        cVar.f16286n = zT;
                    }
                } else if (i11 == 0) {
                    cVar.f16285m = false;
                } else if (i11 == 1) {
                    cVar.f16286n = false;
                }
            }
        }
        return z3;
    }

    public final void l(c cVar, Rect rect, int i10, int i11) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) cVar).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i10) - ((ViewGroup.MarginLayoutParams) cVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) cVar).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i11) - ((ViewGroup.MarginLayoutParams) cVar).bottomMargin));
        rect.set(iMax, iMax2, i10 + iMax, i11 + iMax2);
    }

    public final void m(View view) {
        List list = (List) ((k) this.f16259b.f32577c).getOrDefault(view, null);
        if (list == null || list.isEmpty()) {
            return;
        }
        for (int i10 = 0; i10 < list.size(); i10++) {
            View view2 = (View) list.get(i10);
            Behavior behavior = ((c) view2.getLayoutParams()).f16274a;
            if (behavior != null) {
                behavior.h(this, view2, view);
            }
        }
    }

    public final void n(View view, Rect rect, boolean z3) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z3) {
            p(rect, view);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList o(View view) {
        k kVar = (k) this.f16259b.f32577c;
        int i10 = kVar.f30333c;
        ArrayList arrayList = null;
        for (int i11 = 0; i11 < i10; i11++) {
            ArrayList arrayList2 = (ArrayList) kVar.o(i11);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(kVar.k(i11));
            }
        }
        ArrayList arrayList3 = this.f16261d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        z(false);
        if (this.f16270w) {
            if (this.f16269v == null) {
                this.f16269v = new S2.d(this, 2);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f16269v);
        }
        if (this.f16271x == null) {
            WeakHashMap weakHashMap = U.f27683a;
            if (getFitsSystemWindows()) {
                F.c(this);
            }
        }
        this.f16265r = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        z(false);
        if (this.f16270w && this.f16269v != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f16269v);
        }
        View view = this.f16268u;
        if (view != null) {
            b(view, 0);
        }
        this.f16265r = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f16272y || this.f16273z == null) {
            return;
        }
        A0 a3 = this.f16271x;
        int iD = a3 != null ? a3.d() : 0;
        if (iD > 0) {
            this.f16273z.setBounds(0, 0, getWidth(), iD);
            this.f16273z.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            z(true);
        }
        boolean zX = x(motionEvent, 0);
        if (actionMasked != 1 && actionMasked != 3) {
            return zX;
        }
        z(true);
        return zX;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        Behavior behavior;
        WeakHashMap weakHashMap = U.f27683a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList = this.f16258a;
        int size = arrayList.size();
        for (int i14 = 0; i14 < size; i14++) {
            View view = (View) arrayList.get(i14);
            if (view.getVisibility() != 8 && ((behavior = ((c) view.getLayoutParams()).f16274a) == null || !behavior.l(this, view, layoutDirection))) {
                v(view, layoutDirection);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:69:0x012e  */
    /* JADX WARN: Code duplicated, block: B:72:0x015f  */
    /* JADX WARN: Code duplicated, block: B:75:0x0169  */
    /* JADX WARN: Code duplicated, block: B:78:0x018a  */
    /* JADX WARN: Code duplicated, block: B:79:0x018d  */
    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        boolean z3;
        int i12;
        int i13;
        int i14;
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        Behavior behavior;
        int i15;
        View view;
        ArrayList arrayList;
        int i16;
        int i17;
        int i18;
        boolean z5;
        int i19;
        int i20;
        int i21;
        boolean zM;
        int iMax;
        CoordinatorLayout coordinatorLayout = this;
        coordinatorLayout.y();
        int childCount = coordinatorLayout.getChildCount();
        int i22 = 0;
        loop0: while (true) {
            if (i22 >= childCount) {
                z3 = false;
                break;
            }
            View childAt = coordinatorLayout.getChildAt(i22);
            k kVar = (k) coordinatorLayout.f16259b.f32577c;
            int i23 = kVar.f30333c;
            for (int i24 = 0; i24 < i23; i24++) {
                ArrayList arrayList2 = (ArrayList) kVar.o(i24);
                if (arrayList2 != null && arrayList2.contains(childAt)) {
                    z3 = true;
                    break loop0;
                }
            }
            i22++;
        }
        if (z3 != coordinatorLayout.f16270w) {
            if (z3) {
                if (coordinatorLayout.f16265r) {
                    if (coordinatorLayout.f16269v == null) {
                        coordinatorLayout.f16269v = new S2.d(coordinatorLayout, 2);
                    }
                    coordinatorLayout.getViewTreeObserver().addOnPreDrawListener(coordinatorLayout.f16269v);
                }
                coordinatorLayout.f16270w = true;
            } else {
                if (coordinatorLayout.f16265r && coordinatorLayout.f16269v != null) {
                    coordinatorLayout.getViewTreeObserver().removeOnPreDrawListener(coordinatorLayout.f16269v);
                }
                coordinatorLayout.f16270w = false;
            }
        }
        int paddingLeft = coordinatorLayout.getPaddingLeft();
        int paddingTop = coordinatorLayout.getPaddingTop();
        int paddingRight = coordinatorLayout.getPaddingRight();
        int paddingBottom = coordinatorLayout.getPaddingBottom();
        WeakHashMap weakHashMap = U.f27683a;
        int layoutDirection = coordinatorLayout.getLayoutDirection();
        boolean z10 = layoutDirection == 1;
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        int i25 = paddingLeft + paddingRight;
        int i26 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = coordinatorLayout.getSuggestedMinimumWidth();
        int suggestedMinimumHeight = coordinatorLayout.getSuggestedMinimumHeight();
        boolean z11 = coordinatorLayout.f16271x != null && coordinatorLayout.getFitsSystemWindows();
        ArrayList arrayList3 = coordinatorLayout.f16258a;
        int size3 = arrayList3.size();
        int i27 = 0;
        int iCombineMeasuredStates = 0;
        while (i27 < size3) {
            View view2 = (View) arrayList3.get(i27);
            int i28 = suggestedMinimumWidth;
            if (view2.getVisibility() == 8) {
                arrayList = arrayList3;
                i13 = size3;
                i19 = paddingLeft;
                i17 = paddingRight;
                suggestedMinimumWidth = i28;
                z5 = false;
                i21 = i27;
            } else {
                c cVar = (c) view2.getLayoutParams();
                int i29 = cVar.f16278e;
                if (i29 < 0 || mode == 0) {
                    i12 = suggestedMinimumHeight;
                } else {
                    int iR = coordinatorLayout.r(i29);
                    int i30 = cVar.f16276c;
                    if (i30 == 0) {
                        i30 = 8388661;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i30, layoutDirection) & 7;
                    i12 = suggestedMinimumHeight;
                    if ((absoluteGravity != 3 || z10) && !(absoluteGravity == 5 && z10)) {
                        if ((absoluteGravity == 5 && !z10) || (absoluteGravity == 3 && z10)) {
                            iMax = Math.max(0, iR - paddingLeft);
                        }
                        if (z11 || view2.getFitsSystemWindows()) {
                            iMakeMeasureSpec = i10;
                            iMakeMeasureSpec2 = i11;
                        } else {
                            int iC = coordinatorLayout.f16271x.c() + coordinatorLayout.f16271x.b();
                            int iA = coordinatorLayout.f16271x.a() + coordinatorLayout.f16271x.d();
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size - iC, mode);
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(size2 - iA, mode2);
                        }
                        behavior = cVar.f16274a;
                        if (behavior != null) {
                            ArrayList arrayList4 = arrayList3;
                            int i31 = iMakeMeasureSpec;
                            arrayList = arrayList4;
                            z5 = false;
                            i17 = paddingRight;
                            i18 = i12;
                            i19 = paddingLeft;
                            i20 = i28;
                            i21 = i27;
                            int i32 = iMakeMeasureSpec2;
                            zM = behavior.m(this, view2, i31, i14, i32);
                            view = view2;
                            iMakeMeasureSpec = i31;
                            i16 = i14;
                            i15 = i32;
                            if (zM) {
                                coordinatorLayout = this;
                            }
                            int iMax2 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                            int iMax3 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                            suggestedMinimumWidth = iMax2;
                            suggestedMinimumHeight = iMax3;
                        } else {
                            int i33 = i14;
                            i15 = iMakeMeasureSpec2;
                            view = view2;
                            arrayList = arrayList3;
                            i16 = i33;
                            i17 = paddingRight;
                            i18 = i12;
                            z5 = false;
                            i19 = paddingLeft;
                            i20 = i28;
                            i21 = i27;
                        }
                        coordinatorLayout = this;
                        coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, i16, i15, 0);
                        int iMax4 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                        int iMax5 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        suggestedMinimumWidth = iMax4;
                        suggestedMinimumHeight = iMax5;
                    } else {
                        iMax = Math.max(0, (size - paddingRight) - iR);
                    }
                    int i34 = size3;
                    i14 = iMax;
                    i13 = i34;
                    if (z11) {
                        iMakeMeasureSpec = i10;
                        iMakeMeasureSpec2 = i11;
                    } else {
                        iMakeMeasureSpec = i10;
                        iMakeMeasureSpec2 = i11;
                    }
                    behavior = cVar.f16274a;
                    if (behavior != null) {
                        ArrayList arrayList5 = arrayList3;
                        int i35 = iMakeMeasureSpec;
                        arrayList = arrayList5;
                        z5 = false;
                        i17 = paddingRight;
                        i18 = i12;
                        i19 = paddingLeft;
                        i20 = i28;
                        i21 = i27;
                        int i36 = iMakeMeasureSpec2;
                        zM = behavior.m(this, view2, i35, i14, i36);
                        view = view2;
                        iMakeMeasureSpec = i35;
                        i16 = i14;
                        i15 = i36;
                        if (zM) {
                            coordinatorLayout = this;
                        }
                        int iMax6 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                        int iMax7 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                        suggestedMinimumWidth = iMax6;
                        suggestedMinimumHeight = iMax7;
                    } else {
                        int i37 = i14;
                        i15 = iMakeMeasureSpec2;
                        view = view2;
                        arrayList = arrayList3;
                        i16 = i37;
                        i17 = paddingRight;
                        i18 = i12;
                        z5 = false;
                        i19 = paddingLeft;
                        i20 = i28;
                        i21 = i27;
                    }
                    coordinatorLayout = this;
                    coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, i16, i15, 0);
                    int iMax8 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                    int iMax9 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    suggestedMinimumWidth = iMax8;
                    suggestedMinimumHeight = iMax9;
                }
                i13 = size3;
                i14 = 0;
                if (z11) {
                    iMakeMeasureSpec = i10;
                    iMakeMeasureSpec2 = i11;
                } else {
                    iMakeMeasureSpec = i10;
                    iMakeMeasureSpec2 = i11;
                }
                behavior = cVar.f16274a;
                if (behavior != null) {
                    ArrayList arrayList6 = arrayList3;
                    int i38 = iMakeMeasureSpec;
                    arrayList = arrayList6;
                    z5 = false;
                    i17 = paddingRight;
                    i18 = i12;
                    i19 = paddingLeft;
                    i20 = i28;
                    i21 = i27;
                    int i39 = iMakeMeasureSpec2;
                    zM = behavior.m(this, view2, i38, i14, i39);
                    view = view2;
                    iMakeMeasureSpec = i38;
                    i16 = i14;
                    i15 = i39;
                    if (zM) {
                        coordinatorLayout = this;
                    }
                    int iMax10 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                    int iMax11 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                    suggestedMinimumWidth = iMax10;
                    suggestedMinimumHeight = iMax11;
                } else {
                    int i310 = i14;
                    i15 = iMakeMeasureSpec2;
                    view = view2;
                    arrayList = arrayList3;
                    i16 = i310;
                    i17 = paddingRight;
                    i18 = i12;
                    z5 = false;
                    i19 = paddingLeft;
                    i20 = i28;
                    i21 = i27;
                }
                coordinatorLayout = this;
                coordinatorLayout.measureChildWithMargins(view, iMakeMeasureSpec, i16, i15, 0);
                int iMax12 = Math.max(i20, view.getMeasuredWidth() + i25 + ((ViewGroup.MarginLayoutParams) cVar).leftMargin + ((ViewGroup.MarginLayoutParams) cVar).rightMargin);
                int iMax13 = Math.max(i18, view.getMeasuredHeight() + i26 + ((ViewGroup.MarginLayoutParams) cVar).topMargin + ((ViewGroup.MarginLayoutParams) cVar).bottomMargin);
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, view.getMeasuredState());
                suggestedMinimumWidth = iMax12;
                suggestedMinimumHeight = iMax13;
            }
            i27 = i21 + 1;
            arrayList3 = arrayList;
            size3 = i13;
            paddingLeft = i19;
            paddingRight = i17;
        }
        coordinatorLayout.setMeasuredDimension(View.resolveSizeAndState(suggestedMinimumWidth, i10, (-16777216) & iCombineMeasuredStates), View.resolveSizeAndState(suggestedMinimumHeight, i11, iCombineMeasuredStates << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                if (cVar.a(0)) {
                    Behavior behavior = cVar.f16274a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        Behavior behavior;
        int childCount = getChildCount();
        boolean zN = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                c cVar = (c) childAt.getLayoutParams();
                if (cVar.a(0) && (behavior = cVar.f16274a) != null) {
                    zN |= behavior.n(view);
                }
            }
        }
        return zN;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        c(view, i10, i11, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        i(view, i10, i11, i12, i13, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        a(view, view2, i10, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof p026c1.b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        p026c1.b bVar = (p026c1.b) parcelable;
        super.onRestoreInstanceState(bVar.f2402a);
        SparseArray sparseArray = bVar.f18009c;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            Behavior behavior = s(childAt).f16274a;
            if (id != -1 && behavior != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                behavior.r(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableS;
        p026c1.b bVar = new p026c1.b(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            Behavior behavior = ((c) childAt.getLayoutParams()).f16274a;
            if (id != -1 && behavior != null && (parcelableS = behavior.s(childAt)) != null) {
                sparseArray.append(id, parcelableS);
            }
        }
        bVar.f18009c = sparseArray;
        return bVar;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return j(view, view2, i10, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x002f  */
    /* JADX WARN: Code duplicated, block: B:15:0x0035 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0037  */
    /* JADX WARN: Code duplicated, block: B:18:0x004a  */
    /* JADX WARN: Code duplicated, block: B:7:0x0015 A[PHI: r3
  0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:10:0x0022, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zX;
        boolean zV;
        MotionEvent motionEventObtain;
        int actionMasked = motionEvent.getActionMasked();
        if (this.f16267t == null) {
            zX = x(motionEvent, 1);
            if (!zX) {
                zV = false;
            }
            motionEventObtain = null;
            if (this.f16267t == null) {
                zV |= super.onTouchEvent(motionEvent);
            } else if (zX) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEventObtain);
            }
            if (motionEventObtain != null) {
                motionEventObtain.recycle();
            }
            if (actionMasked == 1 && actionMasked != 3) {
                return zV;
            }
            z(false);
            return zV;
        }
        zX = false;
        Behavior behavior = ((c) this.f16267t.getLayoutParams()).f16274a;
        if (behavior != null) {
            zV = behavior.v(this, this.f16267t, motionEvent);
        } else {
            zV = false;
        }
        motionEventObtain = null;
        if (this.f16267t == null) {
            zV |= super.onTouchEvent(motionEvent);
        } else if (zX) {
            long jUptimeMillis2 = SystemClock.uptimeMillis();
            motionEventObtain = MotionEvent.obtain(jUptimeMillis2, jUptimeMillis2, 3, 0.0f, 0.0f, 0);
            super.onTouchEvent(motionEventObtain);
        }
        if (motionEventObtain != null) {
            motionEventObtain.recycle();
        }
        if (actionMasked == 1) {
        }
        z(false);
        return zV;
    }

    public final void p(Rect rect, View view) {
        ThreadLocal threadLocal = p026c1.c.f18010a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = p026c1.c.f18010a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        p026c1.c.a(this, view, matrix);
        ThreadLocal threadLocal3 = p026c1.c.f18011b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int r(int i10) {
        int[] iArr = this.f16266s;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i10);
            return 0;
        }
        if (i10 >= 0 && i10 < iArr.length) {
            return iArr[i10];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i10 + " out of range for " + this);
        return 0;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z3) {
        Behavior behavior = ((c) view.getLayoutParams()).f16274a;
        if (behavior == null || !behavior.q(this, view, rect, z3)) {
            return super.requestChildRectangleOnScreen(view, rect, z3);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        super.requestDisallowInterceptTouchEvent(z3);
        if (!z3 || this.f16264q) {
            return;
        }
        z(false);
        this.f16264q = true;
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z3) {
        super.setFitsSystemWindows(z3);
        C();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f16255A = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f16273z;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f16273z = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f16273z.setState(getDrawableState());
                }
                Drawable drawable3 = this.f16273z;
                WeakHashMap weakHashMap = U.f27683a;
                p101i1.b.b(drawable3, getLayoutDirection());
                this.f16273z.setVisible(getVisibility() == 0, false);
                this.f16273z.setCallback(this);
            }
            WeakHashMap weakHashMap2 = U.f27683a;
            postInvalidateOnAnimation();
        }
    }

    public void setStatusBarBackgroundColor(int i10) {
        setStatusBarBackground(new ColorDrawable(i10));
    }

    public void setStatusBarBackgroundResource(int i10) {
        setStatusBarBackground(i10 != 0 ? h.getDrawable(getContext(), i10) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z3 = i10 == 0;
        Drawable drawable = this.f16273z;
        if (drawable == null || drawable.isVisible() == z3) {
            return;
        }
        this.f16273z.setVisible(z3, false);
    }

    public final boolean t(View view, int i10, int i11) {
        p189q1.c cVar = f16254H;
        Rect rectK = k();
        p(rectK, view);
        try {
            return rectK.contains(i10, i11);
        } finally {
            rectK.setEmpty();
            cVar.c(rectK);
        }
    }

    /* JADX WARN: Code duplicated, block: B:107:0x0271  */
    /* JADX WARN: Code duplicated, block: B:33:0x00df  */
    public final void u(int i10) {
        Rect rect;
        int i11;
        Rect rect2;
        int i12;
        ArrayList arrayList;
        int i13;
        boolean zH;
        boolean z3;
        boolean z5;
        int width;
        int i14;
        int i15;
        int i16;
        int height;
        int i17;
        int i18;
        int i19;
        Rect rect3;
        p189q1.c cVar;
        Behavior behavior;
        WeakHashMap weakHashMap = U.f27683a;
        int layoutDirection = getLayoutDirection();
        ArrayList arrayList2 = this.f16258a;
        int size = arrayList2.size();
        Rect rectK = k();
        Rect rectK2 = k();
        Rect rectK3 = k();
        int i20 = 0;
        while (true) {
            p189q1.c cVar2 = f16254H;
            if (i20 >= size) {
                Rect rect4 = rectK2;
                Rect rect5 = rectK3;
                rectK.setEmpty();
                cVar2.c(rectK);
                rect4.setEmpty();
                cVar2.c(rect4);
                rect5.setEmpty();
                cVar2.c(rect5);
                return;
            }
            View view = (View) arrayList2.get(i20);
            c cVar3 = (c) view.getLayoutParams();
            if (i10 != 0 || view.getVisibility() != 8) {
                int i21 = 0;
                while (i21 < i20) {
                    if (cVar3.f16284l == ((View) arrayList2.get(i21))) {
                        c cVar4 = (c) view.getLayoutParams();
                        if (cVar4.k != null) {
                            Rect rectK4 = k();
                            Rect rectK5 = k();
                            Rect rect6 = rectK3;
                            Rect rectK6 = k();
                            p(rectK4, cVar4.k);
                            n(view, rectK5, false);
                            int measuredWidth = view.getMeasuredWidth();
                            p189q1.c cVar5 = cVar2;
                            int measuredHeight = view.getMeasuredHeight();
                            cVar = cVar5;
                            q(layoutDirection, rectK4, rectK6, cVar4, measuredWidth, measuredHeight);
                            rect3 = rect6;
                            boolean z10 = (rectK6.left == rectK5.left && rectK6.top == rectK5.top) ? false : true;
                            l(cVar4, rectK6, measuredWidth, measuredHeight);
                            int i22 = rectK6.left - rectK5.left;
                            int i23 = rectK6.top - rectK5.top;
                            if (i22 != 0) {
                                WeakHashMap weakHashMap2 = U.f27683a;
                                view.offsetLeftAndRight(i22);
                            }
                            if (i23 != 0) {
                                WeakHashMap weakHashMap3 = U.f27683a;
                                view.offsetTopAndBottom(i23);
                            }
                            if (z10 && (behavior = cVar4.f16274a) != null) {
                                behavior.h(this, view, cVar4.k);
                            }
                            rectK4.setEmpty();
                            cVar.c(rectK4);
                            rectK5.setEmpty();
                            cVar.c(rectK5);
                            rectK6.setEmpty();
                            cVar.c(rectK6);
                        } else {
                            rect3 = rectK3;
                            cVar = cVar2;
                        }
                    } else {
                        rect3 = rectK3;
                        cVar = cVar2;
                    }
                    cVar2 = cVar;
                    i21++;
                    rectK2 = rectK2;
                    i20 = i20;
                    arrayList2 = arrayList2;
                    size = size;
                    rectK3 = rect3;
                }
                ArrayList arrayList3 = arrayList2;
                rect = rectK2;
                Rect rect7 = rectK3;
                i11 = i20;
                S0.d dVar = cVar2;
                int i24 = size;
                n(view, rect, true);
                if (cVar3.f16280g != 0 && !rect.isEmpty()) {
                    int absoluteGravity = Gravity.getAbsoluteGravity(cVar3.f16280g, layoutDirection);
                    int i25 = absoluteGravity & 112;
                    if (i25 == 48) {
                        rectK.top = Math.max(rectK.top, rect.bottom);
                    } else if (i25 == 80) {
                        rectK.bottom = Math.max(rectK.bottom, getHeight() - rect.top);
                    }
                    int i26 = absoluteGravity & 7;
                    if (i26 == 3) {
                        rectK.left = Math.max(rectK.left, rect.right);
                    } else if (i26 == 5) {
                        rectK.right = Math.max(rectK.right, getWidth() - rect.left);
                    }
                }
                if (cVar3.f16281h != 0 && view.getVisibility() == 0) {
                    WeakHashMap weakHashMap4 = U.f27683a;
                    if (view.isLaidOut() && view.getWidth() > 0 && view.getHeight() > 0) {
                        c cVar6 = (c) view.getLayoutParams();
                        Behavior behavior2 = cVar6.f16274a;
                        Rect rectK7 = k();
                        Rect rectK8 = k();
                        rectK8.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                        if (behavior2 == null || !behavior2.e(rectK7, view)) {
                            rectK7.set(rectK8);
                        } else if (!rectK8.contains(rectK7)) {
                            throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rectK7.toShortString() + " | Bounds:" + rectK8.toShortString());
                        }
                        rectK8.setEmpty();
                        dVar.c(rectK8);
                        if (rectK7.isEmpty()) {
                            rectK7.setEmpty();
                            dVar.c(rectK7);
                        } else {
                            int absoluteGravity2 = Gravity.getAbsoluteGravity(cVar6.f16281h, layoutDirection);
                            if ((absoluteGravity2 & 48) != 48 || (i18 = (rectK7.top - ((ViewGroup.MarginLayoutParams) cVar6).topMargin) - cVar6.f16283j) >= (i19 = rectK.top)) {
                                z3 = false;
                            } else {
                                B(view, i19 - i18);
                                z3 = true;
                            }
                            if ((absoluteGravity2 & 80) == 80 && (height = ((getHeight() - rectK7.bottom) - ((ViewGroup.MarginLayoutParams) cVar6).bottomMargin) + cVar6.f16283j) < (i17 = rectK.bottom)) {
                                B(view, height - i17);
                                z3 = true;
                            }
                            if (!z3) {
                                B(view, 0);
                            }
                            if ((absoluteGravity2 & 3) != 3 || (i15 = (rectK7.left - ((ViewGroup.MarginLayoutParams) cVar6).leftMargin) - cVar6.f16282i) >= (i16 = rectK.left)) {
                                z5 = false;
                            } else {
                                A(view, i16 - i15);
                                z5 = true;
                            }
                            if ((absoluteGravity2 & 5) == 5 && (width = ((getWidth() - rectK7.right) - ((ViewGroup.MarginLayoutParams) cVar6).rightMargin) + cVar6.f16282i) < (i14 = rectK.right)) {
                                A(view, width - i14);
                                z5 = true;
                            }
                            if (!z5) {
                                A(view, 0);
                            }
                            rectK7.setEmpty();
                            dVar.c(rectK7);
                        }
                    }
                }
                if (i10 != 2) {
                    rect2 = rect7;
                    rect2.set(((c) view.getLayoutParams()).f16288p);
                    if (rect2.equals(rect)) {
                        arrayList = arrayList3;
                        i12 = i24;
                    } else {
                        ((c) view.getLayoutParams()).f16288p.set(rect);
                    }
                } else {
                    rect2 = rect7;
                }
                int i27 = i11 + 1;
                i12 = i24;
                while (true) {
                    arrayList = arrayList3;
                    if (i27 >= i12) {
                        break;
                    }
                    View view2 = (View) arrayList.get(i27);
                    c cVar7 = (c) view2.getLayoutParams();
                    Behavior behavior3 = cVar7.f16274a;
                    if (behavior3 == null || !behavior3.f(view2, view)) {
                        i13 = 1;
                    } else if (i10 == 0 && cVar7.f16287o) {
                        cVar7.f16287o = false;
                        i13 = 1;
                    } else {
                        if (i10 != 2) {
                            zH = behavior3.h(this, view2, view);
                        } else {
                            behavior3.i(this, view);
                            zH = true;
                        }
                        i13 = 1;
                        if (i10 == 1) {
                            cVar7.f16287o = zH;
                        }
                    }
                    i27 += i13;
                    arrayList3 = arrayList;
                }
            } else {
                int i28 = size;
                arrayList = arrayList2;
                i12 = i28;
                rect = rectK2;
                rect2 = rectK3;
                i11 = i20;
            }
            i20 = i11 + 1;
            ArrayList arrayList4 = arrayList;
            size = i12;
            arrayList2 = arrayList4;
            rectK3 = rect2;
            rectK2 = rect;
        }
    }

    public final void v(View view, int i10) {
        int i11;
        c cVar = (c) view.getLayoutParams();
        View view2 = cVar.k;
        if (view2 == null && cVar.f16279f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        p189q1.c cVar2 = f16254H;
        if (view2 != null) {
            Rect rectK = k();
            Rect rectK2 = k();
            try {
                p(rectK, view2);
                c cVar3 = (c) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                q(i10, rectK, rectK2, cVar3, measuredWidth, measuredHeight);
                l(cVar3, rectK2, measuredWidth, measuredHeight);
                view.layout(rectK2.left, rectK2.top, rectK2.right, rectK2.bottom);
                return;
            } finally {
                rectK.setEmpty();
                cVar2.c(rectK);
                rectK2.setEmpty();
                cVar2.c(rectK2);
            }
        }
        int i12 = cVar.f16278e;
        if (i12 < 0) {
            c cVar4 = (c) view.getLayoutParams();
            Rect rectK3 = k();
            rectK3.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) cVar4).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) cVar4).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) cVar4).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) cVar4).bottomMargin);
            if (this.f16271x != null) {
                WeakHashMap weakHashMap = U.f27683a;
                if (getFitsSystemWindows() && !view.getFitsSystemWindows()) {
                    rectK3.left = this.f16271x.b() + rectK3.left;
                    rectK3.top = this.f16271x.d() + rectK3.top;
                    rectK3.right -= this.f16271x.c();
                    rectK3.bottom -= this.f16271x.a();
                }
            }
            Rect rectK4 = k();
            int i13 = cVar4.f16276c;
            if ((i13 & 7) == 0) {
                i13 |= 8388611;
            }
            if ((i13 & 112) == 0) {
                i13 |= 48;
            }
            Gravity.apply(i13, view.getMeasuredWidth(), view.getMeasuredHeight(), rectK3, rectK4, i10);
            view.layout(rectK4.left, rectK4.top, rectK4.right, rectK4.bottom);
            rectK3.setEmpty();
            cVar2.c(rectK3);
            rectK4.setEmpty();
            cVar2.c(rectK4);
            return;
        }
        c cVar5 = (c) view.getLayoutParams();
        int i14 = cVar5.f16276c;
        if (i14 == 0) {
            i14 = 8388661;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i14, i10);
        int i15 = absoluteGravity & 7;
        int i16 = absoluteGravity & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth2 = view.getMeasuredWidth();
        int measuredHeight2 = view.getMeasuredHeight();
        if (i10 == 1) {
            i12 = width - i12;
        }
        int iR = r(i12) - measuredWidth2;
        if (i15 == 1) {
            iR += measuredWidth2 / 2;
        } else if (i15 == 5) {
            iR += measuredWidth2;
        }
        if (i16 != 16) {
            i11 = i16 != 80 ? 0 : measuredHeight2;
        } else {
            i11 = measuredHeight2 / 2;
        }
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) cVar5).leftMargin, Math.min(iR, ((width - getPaddingRight()) - measuredWidth2) - ((ViewGroup.MarginLayoutParams) cVar5).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) cVar5).topMargin, Math.min(i11, ((height - getPaddingBottom()) - measuredHeight2) - ((ViewGroup.MarginLayoutParams) cVar5).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth2 + iMax, measuredHeight2 + iMax2);
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f16273z;
    }

    public final void w(int i10, int i11, int i12, View view) {
        measureChildWithMargins(view, i10, i11, i12, 0);
    }

    public final boolean x(MotionEvent motionEvent, int i10) {
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f16260c;
        arrayList.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i11 = childCount - 1; i11 >= 0; i11--) {
            arrayList.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i11) : i11));
        }
        C0048e c0048e = f16253G;
        if (c0048e != null) {
            Collections.sort(arrayList, c0048e);
        }
        int size = arrayList.size();
        MotionEvent motionEventObtain = null;
        boolean zK = false;
        for (int i12 = 0; i12 < size; i12++) {
            View view = (View) arrayList.get(i12);
            Behavior behavior = ((c) view.getLayoutParams()).f16274a;
            if (zK && actionMasked != 0) {
                if (behavior != null) {
                    if (motionEventObtain == null) {
                        long jUptimeMillis = SystemClock.uptimeMillis();
                        motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                    }
                    if (i10 == 0) {
                        behavior.k(this, view, motionEventObtain);
                    } else if (i10 == 1) {
                        behavior.v(this, view, motionEventObtain);
                    }
                }
            } else if (!zK && behavior != null) {
                if (i10 == 0) {
                    zK = behavior.k(this, view, motionEvent);
                } else if (i10 == 1) {
                    zK = behavior.v(this, view, motionEvent);
                }
                if (zK) {
                    this.f16267t = view;
                }
            }
        }
        arrayList.clear();
        return zK;
    }

    /* JADX WARN: Code duplicated, block: B:105:0x0089 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:33:0x007c A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:34:0x007e  */
    /* JADX WARN: Code duplicated, block: B:36:0x0084  */
    /* JADX WARN: Code duplicated, block: B:39:0x0091  */
    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Not found exit edge by exit block: B:40:0x0095
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.checkLoopExits(LoopRegionMaker.java:272)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeLoopRegion(LoopRegionMaker.java:237)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:80)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeEndlessLoop(LoopRegionMaker.java:590)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:82)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:117)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:111)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:109)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeEndlessLoop(LoopRegionMaker.java:590)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:82)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:92)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:69)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeMthRegion(RegionMaker.java:49)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:25)
        */
    public final void y() {
        /*
            Method dump skipped, instruction units count: 402
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.y():void");
    }

    public final void z(boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            Behavior behavior = ((c) childAt.getLayoutParams()).f16274a;
            if (behavior != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z3) {
                    behavior.k(this, childAt, motionEventObtain);
                } else {
                    behavior.v(this, childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i11 = 0; i11 < childCount; i11++) {
            ((c) getChildAt(i11).getLayoutParams()).getClass();
        }
        this.f16267t = null;
        this.f16264q = false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof c) {
            return new c((c) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams);
    }

    public static abstract class Behavior<V extends View> {
        public Behavior(Context context, AttributeSet attributeSet) {
        }

        public boolean e(Rect rect, View view) {
            return false;
        }

        public boolean f(View view, View view2) {
            return false;
        }

        public boolean h(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return false;
        }

        public boolean k(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return false;
        }

        public boolean l(CoordinatorLayout coordinatorLayout, View view, int i10) {
            return false;
        }

        public boolean m(CoordinatorLayout coordinatorLayout, View view, int i10, int i11, int i12) {
            return false;
        }

        public boolean n(View view) {
            return false;
        }

        public void p(CoordinatorLayout coordinatorLayout, View view, int i10, int i11, int i12, int[] iArr) {
            iArr[0] = iArr[0] + i11;
            iArr[1] = iArr[1] + i12;
        }

        public boolean q(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z3) {
            return false;
        }

        public Parcelable s(View view) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        public boolean t(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i10, int i11) {
            return false;
        }

        public boolean v(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
            return false;
        }

        public void j() {
        }

        public void g(c cVar) {
        }

        public void i(CoordinatorLayout coordinatorLayout, View view) {
        }

        public void r(View view, Parcelable parcelable) {
        }

        public void u(CoordinatorLayout coordinatorLayout, View view, View view2, int i10) {
        }

        public void o(CoordinatorLayout coordinatorLayout, View view, View view2, int i10, int i11, int[] iArr, int i12) {
        }
    }
}
