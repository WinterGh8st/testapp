package androidx.profileinstaller;

import Xa.a;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import p041d3.e;
import p115j2.b;

/* JADX INFO: loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // p115j2.b
    public final List a() {
        return Collections.EMPTY_LIST;
    }

    @Override // p115j2.b
    public final Object b(Context context) {
        final Context applicationContext = context.getApplicationContext();
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() { // from class: e2.d
            @Override // android.view.Choreographer.FrameCallback
            public final void doFrame(long j10) {
                this.f21837a.getClass();
                (Build.VERSION.SDK_INT >= 28 ? Handler.createAsync(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new e(applicationContext, 3), new Random().nextInt(Math.max(1000, 1)) + 5000);
            }
        });
        return new a(7);
    }
}
