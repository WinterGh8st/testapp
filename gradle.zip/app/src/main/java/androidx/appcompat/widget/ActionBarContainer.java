package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.flamingotools.ws.R;
import p175p.C1322a;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f15310a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public View f15311b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f15312c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f15313d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f15314e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f15315f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final boolean f15316q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f15317r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public final int f15318s;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBackground(new C1322a(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p099i.a.f23288a);
        boolean z3 = false;
        this.f15313d = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f15314e = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f15318s = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f15316q = true;
            this.f15315f = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f15316q ? !(this.f15313d != null || this.f15314e != null) : this.f15315f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f15313d;
        if (drawable != null && drawable.isStateful()) {
            this.f15313d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f15314e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f15314e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f15315f;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f15315f.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f15313d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f15314e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f15315f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f15311b = findViewById(R.id.action_bar);
        this.f15312c = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f15310a || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        boolean z5 = true;
        if (this.f15316q) {
            Drawable drawable = this.f15315f;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z5 = false;
            }
        } else {
            if (this.f15313d == null) {
                z5 = false;
            } else if (this.f15311b.getVisibility() == 0) {
                this.f15313d.setBounds(this.f15311b.getLeft(), this.f15311b.getTop(), this.f15311b.getRight(), this.f15311b.getBottom());
            } else {
                View view = this.f15312c;
                if (view == null || view.getVisibility() != 0) {
                    this.f15313d.setBounds(0, 0, 0, 0);
                } else {
                    this.f15313d.setBounds(this.f15312c.getLeft(), this.f15312c.getTop(), this.f15312c.getRight(), this.f15312c.getBottom());
                }
            }
            this.f15317r = false;
        }
        if (z5) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f15311b == null && View.MeasureSpec.getMode(i11) == Integer.MIN_VALUE && (i12 = this.f15318s) >= 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(Math.min(i12, View.MeasureSpec.getSize(i11)), Integer.MIN_VALUE);
        }
        super.onMeasure(i10, i11);
        if (this.f15311b == null) {
            return;
        }
        View.MeasureSpec.getMode(i11);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f15313d;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f15313d);
        }
        this.f15313d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f15311b;
            if (view != null) {
                this.f15313d.setBounds(view.getLeft(), this.f15311b.getTop(), this.f15311b.getRight(), this.f15311b.getBottom());
            }
        }
        boolean z3 = false;
        if (!this.f15316q ? !(this.f15313d != null || this.f15314e != null) : this.f15315f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f15315f;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f15315f);
        }
        this.f15315f = drawable;
        boolean z3 = this.f15316q;
        boolean z5 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z3 && (drawable2 = this.f15315f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z3 ? !(this.f15313d != null || this.f15314e != null) : this.f15315f == null) {
            z5 = true;
        }
        setWillNotDraw(z5);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f15314e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f15314e);
        }
        this.f15314e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f15317r && this.f15314e != null) {
                throw null;
            }
        }
        boolean z3 = false;
        if (!this.f15316q ? !(this.f15313d != null || this.f15314e != null) : this.f15315f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(c cVar) {
    }

    public void setTransitioning(boolean z3) {
        this.f15310a = z3;
        setDescendantFocusability(z3 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z3 = i10 == 0;
        Drawable drawable = this.f15313d;
        if (drawable != null) {
            drawable.setVisible(z3, false);
        }
        Drawable drawable2 = this.f15314e;
        if (drawable2 != null) {
            drawable2.setVisible(z3, false);
        }
        Drawable drawable3 = this.f15315f;
        if (drawable3 != null) {
            drawable3.setVisible(z3, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.f15313d;
        boolean z3 = this.f15316q;
        if (drawable == drawable2 && !z3) {
            return true;
        }
        if (drawable == this.f15314e && this.f15317r) {
            return true;
        }
        return (drawable == this.f15315f && z3) || super.verifyDrawable(drawable);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i10) {
        if (i10 != 0) {
            return super.startActionModeForChild(view, callback, i10);
        }
        return null;
    }
}
