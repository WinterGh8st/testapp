package androidx.appcompat.widget;

import B2.I;
import Y0.F;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import p164o.j;
import p164o.k;
import p164o.l;
import p164o.n;
import p164o.w;
import p164o.z;
import p175p.C1330e;
import p175p.C1336h;
import p175p.InterfaceC1340j;
import p175p.InterfaceC1342k;
import p175p.W0;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuView extends LinearLayoutCompat implements k, z {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public Context f15369A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f15370B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f15371C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public a f15372D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public I f15373E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public j f15374F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public boolean f15375G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public int f15376H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f15377I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final int f15378J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public InterfaceC1342k f15379K;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public l f15380z;

    public static class LayoutParams extends LinearLayoutCompat.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public boolean f15381a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f15382b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f15383c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public boolean f15384d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public boolean f15385e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public boolean f15386f;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f10 = context.getResources().getDisplayMetrics().density;
        this.f15377I = (int) (56.0f * f10);
        this.f15378J = (int) (f10 * 4.0f);
        this.f15369A = context;
        this.f15370B = 0;
    }

    public static LayoutParams l() {
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.f15381a = false;
        ((LinearLayout.LayoutParams) layoutParams).gravity = 16;
        return layoutParams;
    }

    public static LayoutParams m(ViewGroup.LayoutParams layoutParams) {
        LayoutParams layoutParams2;
        if (layoutParams == null) {
            return l();
        }
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams3 = (LayoutParams) layoutParams;
            layoutParams2 = new LayoutParams(layoutParams3);
            layoutParams2.f15381a = layoutParams3.f15381a;
        } else {
            layoutParams2 = new LayoutParams(layoutParams);
        }
        if (((LinearLayout.LayoutParams) layoutParams2).gravity <= 0) {
            ((LinearLayout.LayoutParams) layoutParams2).gravity = 16;
        }
        return layoutParams2;
    }

    @Override // p164o.z
    public final void c(l lVar) {
        this.f15380z = lVar;
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // p164o.k
    public final boolean d(n nVar) {
        return this.f15380z.q(nVar, null, 0);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return l();
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }

    public Menu getMenu() {
        if (this.f15380z == null) {
            Context context = getContext();
            l lVar = new l(context);
            this.f15380z = lVar;
            lVar.f26038e = new p074g0.c((Object) this);
            a aVar = new a(context);
            this.f15372D = aVar;
            aVar.f15661w = true;
            aVar.f15662x = true;
            w f10 = this.f15373E;
            if (f10 == null) {
                f10 = new F(19);
            }
            aVar.f25978e = f10;
            this.f15380z.b(aVar, this.f15369A);
            a aVar2 = this.f15372D;
            aVar2.f25981r = this;
            this.f15380z = aVar2.f25976c;
        }
        return this.f15380z;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        a aVar = this.f15372D;
        C1336h c1336h = aVar.f15658t;
        if (c1336h != null) {
            return c1336h.getDrawable();
        }
        if (aVar.f15660v) {
            return aVar.f15659u;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f15370B;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat
    /* JADX INFO: renamed from: h */
    public final /* bridge */ /* synthetic */ LinearLayoutCompat.LayoutParams generateDefaultLayoutParams() {
        return l();
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat
    /* JADX INFO: renamed from: i */
    public final LinearLayoutCompat.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat
    /* JADX INFO: renamed from: j */
    public final /* bridge */ /* synthetic */ LinearLayoutCompat.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }

    public final boolean n(int i10) {
        boolean zB = false;
        if (i10 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i10 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i10);
        if (i10 < getChildCount() && (childAt instanceof InterfaceC1340j)) {
            zB = ((InterfaceC1340j) childAt).b();
        }
        return (i10 <= 0 || !(childAt2 instanceof InterfaceC1340j)) ? zB : ((InterfaceC1340j) childAt2).c() | zB;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        a aVar = this.f15372D;
        if (aVar != null) {
            aVar.e(false);
            if (this.f15372D.f()) {
                this.f15372D.c();
                this.f15372D.n();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a aVar = this.f15372D;
        if (aVar != null) {
            aVar.c();
            C1330e c1330e = aVar.f15653E;
            if (c1330e == null || !c1330e.b()) {
                return;
            }
            c1330e.f26101i.dismiss();
        }
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int width;
        int paddingLeft;
        if (!this.f15375G) {
            super.onLayout(z3, i10, i11, i12, i13);
            return;
        }
        int childCount = getChildCount();
        int i14 = (i13 - i11) / 2;
        int dividerWidth = getDividerWidth();
        int i15 = i12 - i10;
        int paddingRight = (i15 - getPaddingRight()) - getPaddingLeft();
        boolean z5 = W0.f26495a;
        boolean z10 = getLayoutDirection() == 1;
        int i16 = 0;
        int i17 = 0;
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt = getChildAt(i18);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.f15381a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (n(i18)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (z10) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) layoutParams).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) layoutParams).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i19 = i14 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i19, width, measuredHeight + i19);
                    paddingRight -= measuredWidth;
                    i16 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) layoutParams).leftMargin) + ((LinearLayout.LayoutParams) layoutParams).rightMargin;
                    n(i18);
                    i17++;
                }
            }
        }
        if (childCount == 1 && i16 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i20 = (i15 / 2) - (measuredWidth2 / 2);
            int i21 = i14 - (measuredHeight2 / 2);
            childAt2.layout(i20, i21, measuredWidth2 + i20, measuredHeight2 + i21);
            return;
        }
        int i22 = i17 - (i16 ^ 1);
        int iMax = Math.max(0, i22 > 0 ? paddingRight / i22 : 0);
        if (z10) {
            int width2 = getWidth() - getPaddingRight();
            for (int i23 = 0; i23 < childCount; i23++) {
                View childAt3 = getChildAt(i23);
                LayoutParams layoutParams2 = (LayoutParams) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !layoutParams2.f15381a) {
                    int i24 = width2 - ((LinearLayout.LayoutParams) layoutParams2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i25 = i14 - (measuredHeight3 / 2);
                    childAt3.layout(i24 - measuredWidth3, i25, i24, measuredHeight3 + i25);
                    width2 = i24 - ((measuredWidth3 + ((LinearLayout.LayoutParams) layoutParams2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i26 = 0; i26 < childCount; i26++) {
            View childAt4 = getChildAt(i26);
            LayoutParams layoutParams3 = (LayoutParams) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !layoutParams3.f15381a) {
                int i27 = paddingLeft2 + ((LinearLayout.LayoutParams) layoutParams3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i28 = i14 - (measuredHeight4 / 2);
                childAt4.layout(i27, i28, i27 + measuredWidth4, measuredHeight4 + i28);
                paddingLeft2 = p096h9.i.f(measuredWidth4, ((LinearLayout.LayoutParams) layoutParams3).rightMargin, iMax, i27);
            }
        }
    }

    /* JADX WARN: Type inference failed for: r11v14 */
    /* JADX WARN: Type inference failed for: r11v15, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r11v17 */
    /* JADX WARN: Type inference failed for: r11v40 */
    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        ?? r11;
        int i14;
        int i15;
        l lVar;
        boolean z3 = this.f15375G;
        boolean z5 = View.MeasureSpec.getMode(i10) == 1073741824;
        this.f15375G = z5;
        if (z3 != z5) {
            this.f15376H = 0;
        }
        int size = View.MeasureSpec.getSize(i10);
        if (this.f15375G && (lVar = this.f15380z) != null && size != this.f15376H) {
            this.f15376H = size;
            lVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f15375G || childCount <= 0) {
            for (int i16 = 0; i16 < childCount; i16++) {
                LayoutParams layoutParams = (LayoutParams) getChildAt(i16).getLayoutParams();
                ((LinearLayout.LayoutParams) layoutParams).rightMargin = 0;
                ((LinearLayout.LayoutParams) layoutParams).leftMargin = 0;
            }
            super.onMeasure(i10, i11);
            return;
        }
        int mode = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i10);
        int size3 = View.MeasureSpec.getSize(i11);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i11, paddingBottom, -2);
        int i17 = size2 - paddingRight;
        int i18 = this.f15377I;
        int i19 = i17 / i18;
        int i20 = i17 % i18;
        if (i19 == 0) {
            setMeasuredDimension(i17, 0);
            return;
        }
        int i21 = (i20 / i19) + i18;
        int childCount2 = getChildCount();
        int iMax = 0;
        int i22 = 0;
        int iMax2 = 0;
        int i23 = 0;
        boolean z10 = false;
        int i24 = 0;
        long j10 = 0;
        while (true) {
            i12 = this.f15378J;
            if (i23 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i23);
            int i25 = size3;
            int i26 = paddingBottom;
            if (childAt.getVisibility() == 8) {
                i14 = i21;
            } else {
                boolean z11 = childAt instanceof ActionMenuItemView;
                i22++;
                if (z11) {
                    childAt.setPadding(i12, 0, i12, 0);
                }
                LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                layoutParams2.f15386f = false;
                layoutParams2.f15383c = 0;
                layoutParams2.f15382b = 0;
                layoutParams2.f15384d = false;
                ((LinearLayout.LayoutParams) layoutParams2).leftMargin = 0;
                ((LinearLayout.LayoutParams) layoutParams2).rightMargin = 0;
                layoutParams2.f15385e = z11 && !TextUtils.isEmpty(((ActionMenuItemView) childAt).getText());
                int i27 = layoutParams2.f15381a ? 1 : i19;
                LayoutParams layoutParams3 = (LayoutParams) childAt.getLayoutParams();
                int i28 = i19;
                i14 = i21;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - i26, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z11 ? (ActionMenuItemView) childAt : null;
                boolean z12 = (actionMenuItemView == null || TextUtils.isEmpty(actionMenuItemView.getText())) ? false : true;
                boolean z13 = z12;
                if (i27 <= 0 || (z12 && i27 < 2)) {
                    i15 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i14 * i27, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i15 = measuredWidth / i14;
                    if (measuredWidth % i14 != 0) {
                        i15++;
                    }
                    if (z13 && i15 < 2) {
                        i15 = 2;
                    }
                }
                layoutParams3.f15384d = !layoutParams3.f15381a && z13;
                layoutParams3.f15382b = i15;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i15 * i14, 1073741824), iMakeMeasureSpec);
                iMax2 = Math.max(iMax2, i15);
                if (layoutParams2.f15384d) {
                    i24++;
                }
                if (layoutParams2.f15381a) {
                    z10 = true;
                }
                i19 = i28 - i15;
                iMax = Math.max(iMax, childAt.getMeasuredHeight());
                if (i15 == 1) {
                    j10 |= (long) (1 << i23);
                }
            }
            i23++;
            size3 = i25;
            paddingBottom = i26;
            i21 = i14;
        }
        int i29 = size3;
        int i30 = i19;
        int i31 = i21;
        boolean z14 = z10 && i22 == 2;
        int i32 = i30;
        boolean z15 = false;
        while (true) {
            if (i24 <= 0 || i32 <= 0) {
                i13 = iMax;
                break;
            }
            int i33 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
            long j11 = 0;
            int i34 = 0;
            int i35 = 0;
            while (i35 < childCount2) {
                boolean z16 = z14;
                LayoutParams layoutParams4 = (LayoutParams) getChildAt(i35).getLayoutParams();
                int i36 = iMax;
                if (layoutParams4.f15384d) {
                    int i37 = layoutParams4.f15382b;
                    if (i37 < i33) {
                        j11 = 1 << i35;
                        i33 = i37;
                        i34 = 1;
                    } else if (i37 == i33) {
                        j11 |= 1 << i35;
                        i34++;
                    }
                }
                i35++;
                iMax = i36;
                z14 = z16;
            }
            boolean z17 = z14;
            i13 = iMax;
            j10 |= j11;
            if (i34 > i32) {
                break;
            }
            int i38 = i33 + 1;
            int i39 = 0;
            while (i39 < childCount2) {
                View childAt2 = getChildAt(i39);
                LayoutParams layoutParams5 = (LayoutParams) childAt2.getLayoutParams();
                boolean z18 = z10;
                long j12 = 1 << i39;
                if ((j11 & j12) != 0) {
                    if (z17 && layoutParams5.f15385e) {
                        r11 = 1;
                        r11 = 1;
                        if (i32 == 1) {
                            childAt2.setPadding(i12 + i31, 0, i12, 0);
                        }
                    } else {
                        r11 = 1;
                    }
                    layoutParams5.f15382b += r11;
                    layoutParams5.f15386f = r11;
                    i32--;
                } else if (layoutParams5.f15382b == i38) {
                    j10 |= j12;
                }
                i39++;
                z10 = z18;
            }
            iMax = i13;
            z14 = z17;
            z15 = true;
        }
        boolean z19 = !z10 && i22 == 1;
        if (i32 > 0 && j10 != 0 && (i32 < i22 - 1 || z19 || iMax2 > 1)) {
            float fBitCount = Long.bitCount(j10);
            if (!z19) {
                if ((j10 & 1) != 0 && !((LayoutParams) getChildAt(0).getLayoutParams()).f15385e) {
                    fBitCount -= 0.5f;
                }
                int i40 = childCount2 - 1;
                if ((j10 & ((long) (1 << i40))) != 0 && !((LayoutParams) getChildAt(i40).getLayoutParams()).f15385e) {
                    fBitCount -= 0.5f;
                }
            }
            int i41 = fBitCount > 0.0f ? (int) ((i32 * i31) / fBitCount) : 0;
            boolean z20 = z15;
            for (int i42 = 0; i42 < childCount2; i42++) {
                if ((j10 & ((long) (1 << i42))) != 0) {
                    View childAt3 = getChildAt(i42);
                    LayoutParams layoutParams6 = (LayoutParams) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        layoutParams6.f15383c = i41;
                        layoutParams6.f15386f = true;
                        if (i42 == 0 && !layoutParams6.f15385e) {
                            ((LinearLayout.LayoutParams) layoutParams6).leftMargin = (-i41) / 2;
                        }
                        z20 = true;
                    } else if (layoutParams6.f15381a) {
                        layoutParams6.f15383c = i41;
                        layoutParams6.f15386f = true;
                        ((LinearLayout.LayoutParams) layoutParams6).rightMargin = (-i41) / 2;
                        z20 = true;
                    } else {
                        if (i42 != 0) {
                            ((LinearLayout.LayoutParams) layoutParams6).leftMargin = i41 / 2;
                        }
                        if (i42 != childCount2 - 1) {
                            ((LinearLayout.LayoutParams) layoutParams6).rightMargin = i41 / 2;
                        }
                    }
                }
            }
            z15 = z20;
        }
        if (z15) {
            for (int i43 = 0; i43 < childCount2; i43++) {
                View childAt4 = getChildAt(i43);
                LayoutParams layoutParams7 = (LayoutParams) childAt4.getLayoutParams();
                if (layoutParams7.f15386f) {
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((layoutParams7.f15382b * i31) + layoutParams7.f15383c, 1073741824), childMeasureSpec);
                }
            }
        }
        setMeasuredDimension(i17, mode != 1073741824 ? i13 : i29);
    }

    public void setExpandedActionViewsExclusive(boolean z3) {
        this.f15372D.f15650B = z3;
    }

    public void setOnMenuItemClickListener(InterfaceC1342k interfaceC1342k) {
        this.f15379K = interfaceC1342k;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        a aVar = this.f15372D;
        C1336h c1336h = aVar.f15658t;
        if (c1336h != null) {
            c1336h.setImageDrawable(drawable);
        } else {
            aVar.f15660v = true;
            aVar.f15659u = drawable;
        }
    }

    public void setOverflowReserved(boolean z3) {
        this.f15371C = z3;
    }

    public void setPopupTheme(int i10) {
        if (this.f15370B != i10) {
            this.f15370B = i10;
            if (i10 == 0) {
                this.f15369A = getContext();
            } else {
                this.f15369A = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setPresenter(a aVar) {
        this.f15372D = aVar;
        aVar.f25981r = this;
        this.f15380z = aVar.f25976c;
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }
}
