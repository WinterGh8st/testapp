package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;
import p112j.n;
import p112j.w;
import p164o.l;
import p175p.C1330e;
import p175p.U;
import p175p.V;
import p200r1.C1474c0;

/* JADX INFO: loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public TypedValue f15458a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public TypedValue f15459b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public TypedValue f15460c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TypedValue f15461d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public TypedValue f15462e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TypedValue f15463f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final Rect f15464q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public U f15465r;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f15464q = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f15462e == null) {
            this.f15462e = new TypedValue();
        }
        return this.f15462e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f15463f == null) {
            this.f15463f = new TypedValue();
        }
        return this.f15463f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f15460c == null) {
            this.f15460c = new TypedValue();
        }
        return this.f15460c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.f15461d == null) {
            this.f15461d = new TypedValue();
        }
        return this.f15461d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f15458a == null) {
            this.f15458a = new TypedValue();
        }
        return this.f15458a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f15459b == null) {
            this.f15459b = new TypedValue();
        }
        return this.f15459b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        U u5 = this.f15465r;
        if (u5 != null) {
            u5.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        a aVar;
        super.onDetachedFromWindow();
        U u5 = this.f15465r;
        if (u5 != null) {
            w wVar = ((n) u5).f23852a;
            V v10 = wVar.f23884B;
            if (v10 != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) v10;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((i) actionBarOverlayLayout.f15357e).f15672a.f15621a;
                if (actionMenuView != null && (aVar = actionMenuView.f15372D) != null) {
                    aVar.c();
                    C1330e c1330e = aVar.f15653E;
                    if (c1330e != null && c1330e.b()) {
                        c1330e.f26101i.dismiss();
                    }
                }
            }
            if (wVar.f23889G != null) {
                wVar.f23928v.getDecorView().removeCallbacks(wVar.f23890H);
                if (wVar.f23889G.isShowing()) {
                    try {
                        wVar.f23889G.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                wVar.f23889G = null;
            }
            C1474c0 c1474c0 = wVar.f23891I;
            if (c1474c0 != null) {
                c1474c0.b();
            }
            l lVar = wVar.z(0).f23872h;
            if (lVar != null) {
                lVar.c(true);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:21:0x004e  */
    /* JADX WARN: Code duplicated, block: B:22:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x008a  */
    /* JADX WARN: Code duplicated, block: B:38:0x009d  */
    /* JADX WARN: Code duplicated, block: B:55:0x00d1  */
    /* JADX WARN: Code duplicated, block: B:57:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:58:0x00de  */
    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        int iMakeMeasureSpec;
        boolean z3;
        int iMakeMeasureSpec2;
        int i12;
        int i13;
        float fraction;
        int i14;
        int i15;
        float fraction2;
        int i16;
        int i17;
        float fraction3;
        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        boolean z5 = true;
        boolean z10 = displayMetrics.widthPixels < displayMetrics.heightPixels;
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        Rect rect = this.f15464q;
        if (mode != Integer.MIN_VALUE) {
            iMakeMeasureSpec = i10;
            z3 = false;
        } else {
            TypedValue typedValue = z10 ? this.f15461d : this.f15460c;
            if (typedValue == null || (i16 = typedValue.type) == 0) {
                iMakeMeasureSpec = i10;
                z3 = false;
            } else {
                if (i16 == 5) {
                    fraction3 = typedValue.getDimension(displayMetrics);
                } else {
                    if (i16 == 6) {
                        int i18 = displayMetrics.widthPixels;
                        fraction3 = typedValue.getFraction(i18, i18);
                    } else {
                        i17 = 0;
                    }
                    if (i17 > 0) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i17 - (rect.left + rect.right), View.MeasureSpec.getSize(i10)), 1073741824);
                        z3 = true;
                    } else {
                        iMakeMeasureSpec = i10;
                        z3 = false;
                    }
                }
                i17 = (int) fraction3;
                if (i17 > 0) {
                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(Math.min(i17 - (rect.left + rect.right), View.MeasureSpec.getSize(i10)), 1073741824);
                    z3 = true;
                } else {
                    iMakeMeasureSpec = i10;
                    z3 = false;
                }
            }
        }
        if (mode2 != Integer.MIN_VALUE) {
            iMakeMeasureSpec2 = i11;
        } else {
            TypedValue typedValue2 = z10 ? this.f15462e : this.f15463f;
            if (typedValue2 == null || (i14 = typedValue2.type) == 0) {
                iMakeMeasureSpec2 = i11;
            } else {
                if (i14 == 5) {
                    fraction2 = typedValue2.getDimension(displayMetrics);
                } else {
                    if (i14 == 6) {
                        int i19 = displayMetrics.heightPixels;
                        fraction2 = typedValue2.getFraction(i19, i19);
                    } else {
                        i15 = 0;
                    }
                    if (i15 > 0) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i15 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i11)), 1073741824);
                    } else {
                        iMakeMeasureSpec2 = i11;
                    }
                }
                i15 = (int) fraction2;
                if (i15 > 0) {
                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(Math.min(i15 - (rect.top + rect.bottom), View.MeasureSpec.getSize(i11)), 1073741824);
                } else {
                    iMakeMeasureSpec2 = i11;
                }
            }
        }
        super.onMeasure(iMakeMeasureSpec, iMakeMeasureSpec2);
        int measuredWidth = getMeasuredWidth();
        int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(measuredWidth, 1073741824);
        if (z3 || mode != Integer.MIN_VALUE) {
            z5 = false;
        } else {
            TypedValue typedValue3 = z10 ? this.f15459b : this.f15458a;
            if (typedValue3 == null || (i12 = typedValue3.type) == 0) {
                z5 = false;
            } else {
                if (i12 == 5) {
                    fraction = typedValue3.getDimension(displayMetrics);
                } else {
                    if (i12 == 6) {
                        int i20 = displayMetrics.widthPixels;
                        fraction = typedValue3.getFraction(i20, i20);
                    } else {
                        i13 = 0;
                    }
                    if (i13 > 0) {
                        i13 -= rect.left + rect.right;
                    }
                    if (measuredWidth < i13) {
                        iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
                    } else {
                        z5 = false;
                    }
                }
                i13 = (int) fraction;
                if (i13 > 0) {
                    i13 -= rect.left + rect.right;
                }
                if (measuredWidth < i13) {
                    iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
                } else {
                    z5 = false;
                }
            }
        }
        if (z5) {
            super.onMeasure(iMakeMeasureSpec3, iMakeMeasureSpec2);
        }
    }

    public void setAttachListener(U u5) {
        this.f15465r = u5;
    }
}
