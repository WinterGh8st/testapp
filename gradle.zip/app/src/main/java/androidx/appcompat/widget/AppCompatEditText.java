package androidx.appcompat.widget;

import B.P;
import C9.G1;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import com.flamingotools.ws.R;
import p053e3.M;
import p175p.AbstractC1365w;
import p175p.C1357s;
import p175p.C1363v;
import p175p.G;
import p175p.H0;
import p175p.I0;
import p200r1.C1477e;
import p200r1.C1480g;
import p200r1.InterfaceC1475d;
import p200r1.InterfaceC1492t;
import p200r1.U;
import p273y1.r;
import p278y6.m;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatEditText extends EditText implements InterfaceC1492t {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15414a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final M f15415b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1363v f15416c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final r f15417d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final C1363v f15418e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public C1357s f15419f;

    public AppCompatEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.editTextStyle);
    }

    private C1357s getSuperCaller() {
        if (this.f15419f == null) {
            this.f15419f = new C1357s(this);
        }
        return this.f15419f;
    }

    @Override // p200r1.InterfaceC1492t
    public final C1480g a(C1480g c1480g) {
        return this.f15417d.a(this, c1480g);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15414a;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15415b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15414a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15414a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15415b.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15415b.i();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        C1363v c1363v;
        if (Build.VERSION.SDK_INT >= 28 || (c1363v = this.f15416c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) c1363v.f26583c;
        return textClassifier == null ? G.a((TextView) c1363v.f26582b) : textClassifier;
    }

    /* JADX WARN: Code duplicated, block: B:26:0x005e A[PHI: r1
  0x005e: PHI (r1v10 java.lang.String[]) = (r1v5 java.lang.String[]), (r1v11 java.lang.String[]) binds: [B:33:0x0071, B:25:0x005c] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        String[] strArrI;
        String[] stringArray;
        InputConnection g10;
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f15415b.getClass();
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 30 && inputConnectionOnCreateInputConnection != null) {
            p252w1.c.a(editorInfo, getText());
        }
        p029c4.a.N0(inputConnectionOnCreateInputConnection, editorInfo, this);
        if (inputConnectionOnCreateInputConnection != null && i10 <= 30 && (strArrI = U.i(this)) != null) {
            if (i10 >= 25) {
                editorInfo.contentMimeTypes = strArrI;
            } else {
                if (editorInfo.extras == null) {
                    editorInfo.extras = new Bundle();
                }
                editorInfo.extras.putStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", strArrI);
                editorInfo.extras.putStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES", strArrI);
            }
            m mVar = new m(this);
            if (i10 >= 25) {
                g10 = new p252w1.d(inputConnectionOnCreateInputConnection, mVar);
            } else {
                String[] strArr = p252w1.c.f31020a;
                if (i10 >= 25) {
                    stringArray = editorInfo.contentMimeTypes;
                    if (stringArray != null) {
                        strArr = stringArray;
                    }
                } else {
                    Bundle bundle = editorInfo.extras;
                    if (bundle != null) {
                        stringArray = bundle.getStringArray("androidx.core.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
                        if (stringArray == null) {
                            stringArray = editorInfo.extras.getStringArray("android.support.v13.view.inputmethod.EditorInfoCompat.CONTENT_MIME_TYPES");
                        }
                        if (stringArray != null) {
                            strArr = stringArray;
                        }
                    }
                }
                if (strArr.length != 0) {
                    g10 = new G1(inputConnectionOnCreateInputConnection, mVar);
                }
            }
            inputConnectionOnCreateInputConnection = g10;
        }
        return this.f15418e.c(inputConnectionOnCreateInputConnection, editorInfo);
    }

    @Override // android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 30 || i10 >= 33) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onDragEvent(DragEvent dragEvent) {
        Activity activity;
        boolean zA = false;
        if (Build.VERSION.SDK_INT < 31 && dragEvent.getLocalState() == null && U.i(this) != null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    activity = null;
                    break;
                }
                if (context instanceof Activity) {
                    activity = (Activity) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (activity == null) {
                Log.i("ReceiveContent", "Can't handle drop: no activity: view=" + this);
            } else if (dragEvent.getAction() != 1 && dragEvent.getAction() == 3) {
                zA = AbstractC1365w.a(dragEvent, this, activity);
            }
        }
        if (zA) {
            return true;
        }
        return super.onDragEvent(dragEvent);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public final boolean onTextContextMenuItem(int i10) {
        C1477e c1477e;
        InterfaceC1475d interfaceC1475d;
        int i11;
        p074g0.c cVar;
        int i12 = Build.VERSION.SDK_INT;
        if (i12 >= 31 || U.i(this) == null || !(i10 == 16908322 || i10 == 16908337)) {
            return super.onTextContextMenuItem(i10);
        }
        ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService("clipboard");
        ClipData primaryClip = clipboardManager == null ? null : clipboardManager.getPrimaryClip();
        if (primaryClip != null && primaryClip.getItemCount() > 0) {
            if (i12 >= 31) {
                cVar = new p074g0.c(primaryClip, 1);
            } else {
                c1477e = new C1477e();
                c1477e.f27701b = primaryClip;
                c1477e.f27702c = 1;
            }
            if (i10 == 16908322) {
                interfaceC1475d = c1477e;
                interfaceC1475d = cVar;
                i11 = 0;
            } else {
                interfaceC1475d = c1477e;
                interfaceC1475d = cVar;
                i11 = 1;
            }
            interfaceC1475d.p(i11);
            U.m(this, interfaceC1475d.a());
        }
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15414a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15414a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15415b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15415b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        this.f15418e.d(z3);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f15418e.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15414a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15414a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15415b;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15415b;
        m2.r(mode);
        m2.d();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        M m2 = this.f15415b;
        if (m2 != null) {
            m2.m(context, i10);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        C1363v c1363v;
        if (Build.VERSION.SDK_INT >= 28 || (c1363v = this.f15416c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            c1363v.f26583c = textClassifier;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatEditText(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        I0.a(context);
        H0.a(this, getContext());
        P p10 = new P(this);
        this.f15414a = p10;
        p10.o(attributeSet, i10);
        M m2 = new M(this);
        this.f15415b = m2;
        m2.l(attributeSet, i10);
        m2.d();
        C1363v c1363v = new C1363v();
        c1363v.f26582b = this;
        this.f15416c = c1363v;
        this.f15417d = new r();
        C1363v c1363v2 = new C1363v(this);
        this.f15418e = c1363v2;
        c1363v2.b(attributeSet, i10);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = super.isFocusable();
        boolean zIsClickable = super.isClickable();
        boolean zIsLongClickable = super.isLongClickable();
        int inputType = super.getInputType();
        KeyListener keyListenerA = c1363v2.a(keyListener);
        if (keyListenerA == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerA);
        super.setRawInputType(inputType);
        super.setFocusable(zIsFocusable);
        super.setClickable(zIsClickable);
        super.setLongClickable(zIsLongClickable);
    }

    @Override // android.widget.EditText, android.widget.TextView
    public Editable getText() {
        return Build.VERSION.SDK_INT >= 28 ? super.getText() : super.getEditableText();
    }
}
