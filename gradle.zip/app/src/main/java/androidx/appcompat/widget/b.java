package androidx.appcompat.widget;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.widget.PopupWindow;
import java.lang.reflect.Method;
import p164o.l;
import p164o.n;
import p175p.C1333f0;
import p175p.C1356r0;
import p175p.InterfaceC1351o0;

/* JADX INFO: loaded from: classes.dex */
public final class b extends ListPopupWindow implements InterfaceC1351o0 {

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final Method f15665N;
    public p074g0.c M;

    static {
        try {
            if (Build.VERSION.SDK_INT <= 28) {
                f15665N = PopupWindow.class.getDeclaredMethod("setTouchModal", Boolean.TYPE);
            }
        } catch (NoSuchMethodException unused) {
            Log.i("MenuPopupWindow", "Could not find method setTouchModal() on PopupWindow. Oh well.");
        }
    }

    @Override // p175p.InterfaceC1351o0
    public final void e(l lVar, n nVar) {
        p074g0.c cVar = this.M;
        if (cVar != null) {
            cVar.e(lVar, nVar);
        }
    }

    @Override // p175p.InterfaceC1351o0
    public final void n(l lVar, n nVar) {
        p074g0.c cVar = this.M;
        if (cVar != null) {
            cVar.n(lVar, nVar);
        }
    }

    @Override // androidx.appcompat.widget.ListPopupWindow
    public final C1333f0 q(Context context, boolean z3) {
        C1356r0 c1356r0 = new C1356r0(context, z3);
        c1356r0.setHoverListener(this);
        return c1356r0;
    }
}
