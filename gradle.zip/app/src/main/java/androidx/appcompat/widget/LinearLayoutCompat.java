package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.LinearLayout;
import p175p.W0;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class LinearLayoutCompat extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f15466a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f15467b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f15468c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public int f15469d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f15470e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f15471f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f15472q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f15473r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int[] f15474s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public int[] f15475t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Drawable f15476u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15477v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f15478w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public int f15479x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f15480y;

    public static class LayoutParams extends LinearLayout.LayoutParams {
        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    public final void f(Canvas canvas, int i10) {
        this.f15476u.setBounds(getPaddingLeft() + this.f15480y, i10, (getWidth() - getPaddingRight()) - this.f15480y, this.f15478w + i10);
        this.f15476u.draw(canvas);
    }

    public final void g(Canvas canvas, int i10) {
        this.f15476u.setBounds(i10, getPaddingTop() + this.f15480y, this.f15477v + i10, (getHeight() - getPaddingBottom()) - this.f15480y);
        this.f15476u.draw(canvas);
    }

    @Override // android.view.View
    public int getBaseline() {
        int i10;
        if (this.f15467b < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i11 = this.f15467b;
        if (childCount <= i11) {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
        View childAt = getChildAt(i11);
        int baseline = childAt.getBaseline();
        if (baseline == -1) {
            if (this.f15467b == 0) {
                return -1;
            }
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
        }
        int bottom = this.f15468c;
        if (this.f15469d == 1 && (i10 = this.f15470e & 112) != 48) {
            if (i10 == 16) {
                bottom += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f15471f) / 2;
            } else if (i10 == 80) {
                bottom = ((getBottom() - getTop()) - getPaddingBottom()) - this.f15471f;
            }
        }
        return bottom + ((LinearLayout.LayoutParams) ((LayoutParams) childAt.getLayoutParams())).topMargin + baseline;
    }

    public int getBaselineAlignedChildIndex() {
        return this.f15467b;
    }

    public Drawable getDividerDrawable() {
        return this.f15476u;
    }

    public int getDividerPadding() {
        return this.f15480y;
    }

    public int getDividerWidth() {
        return this.f15477v;
    }

    public int getGravity() {
        return this.f15470e;
    }

    public int getOrientation() {
        return this.f15469d;
    }

    public int getShowDividers() {
        return this.f15479x;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f15472q;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateDefaultLayoutParams() {
        int i10 = this.f15469d;
        if (i10 == 0) {
            return new LayoutParams(-2, -2);
        }
        if (i10 == 1) {
            return new LayoutParams(-1, -2);
        }
        return null;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new LayoutParams((LayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    public final boolean k(int i10) {
        if (i10 == 0) {
            return (this.f15479x & 1) != 0;
        }
        if (i10 == getChildCount()) {
            return (this.f15479x & 4) != 0;
        }
        if ((this.f15479x & 2) != 0) {
            for (int i11 = i10 - 1; i11 >= 0; i11--) {
                if (getChildAt(i11).getVisibility() != 8) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        int right;
        int left;
        int i10;
        int bottom;
        if (this.f15476u == null) {
            return;
        }
        int i11 = 0;
        if (this.f15469d == 1) {
            int virtualChildCount = getVirtualChildCount();
            while (i11 < virtualChildCount) {
                View childAt = getChildAt(i11);
                if (childAt != null && childAt.getVisibility() != 8 && k(i11)) {
                    f(canvas, (childAt.getTop() - ((LinearLayout.LayoutParams) ((LayoutParams) childAt.getLayoutParams())).topMargin) - this.f15478w);
                }
                i11++;
            }
            if (k(virtualChildCount)) {
                View childAt2 = getChildAt(virtualChildCount - 1);
                if (childAt2 == null) {
                    bottom = (getHeight() - getPaddingBottom()) - this.f15478w;
                } else {
                    bottom = childAt2.getBottom() + ((LinearLayout.LayoutParams) ((LayoutParams) childAt2.getLayoutParams())).bottomMargin;
                }
                f(canvas, bottom);
                return;
            }
            return;
        }
        int virtualChildCount2 = getVirtualChildCount();
        boolean z3 = W0.f26495a;
        boolean z5 = getLayoutDirection() == 1;
        while (i11 < virtualChildCount2) {
            View childAt3 = getChildAt(i11);
            if (childAt3 != null && childAt3.getVisibility() != 8 && k(i11)) {
                LayoutParams layoutParams = (LayoutParams) childAt3.getLayoutParams();
                g(canvas, z5 ? childAt3.getRight() + ((LinearLayout.LayoutParams) layoutParams).rightMargin : (childAt3.getLeft() - ((LinearLayout.LayoutParams) layoutParams).leftMargin) - this.f15477v);
            }
            i11++;
        }
        if (k(virtualChildCount2)) {
            View childAt4 = getChildAt(virtualChildCount2 - 1);
            if (childAt4 != null) {
                LayoutParams layoutParams2 = (LayoutParams) childAt4.getLayoutParams();
                if (z5) {
                    left = childAt4.getLeft() - ((LinearLayout.LayoutParams) layoutParams2).leftMargin;
                    i10 = this.f15477v;
                    right = left - i10;
                } else {
                    right = childAt4.getRight() + ((LinearLayout.LayoutParams) layoutParams2).rightMargin;
                }
            } else if (z5) {
                right = getPaddingLeft();
            } else {
                left = getWidth() - getPaddingRight();
                i10 = this.f15477v;
                right = left - i10;
            }
            g(canvas, right);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    /* JADX WARN: Code duplicated, block: B:29:0x009d  */
    /* JADX WARN: Code duplicated, block: B:62:0x0159  */
    /* JADX WARN: Code duplicated, block: B:65:0x0162  */
    /* JADX WARN: Code duplicated, block: B:67:0x0166  */
    /* JADX WARN: Code duplicated, block: B:69:0x016a  */
    /* JADX WARN: Code duplicated, block: B:70:0x016e  */
    /* JADX WARN: Code duplicated, block: B:72:0x0176  */
    /* JADX WARN: Code duplicated, block: B:74:0x0182  */
    /* JADX WARN: Code duplicated, block: B:76:0x0189  */
    /* JADX WARN: Code duplicated, block: B:77:0x0190  */
    /* JADX WARN: Code duplicated, block: B:80:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:81:0x01a8  */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int paddingLeft;
        int i14;
        int i15;
        int i16;
        int i17;
        int baseline;
        int i18;
        int i19;
        int i20;
        int measuredHeight;
        int i21;
        int paddingTop;
        int i22;
        int i23;
        int i24;
        int i25 = 8;
        char c10 = 2;
        if (this.f15469d == 1) {
            int paddingLeft2 = getPaddingLeft();
            int i26 = i12 - i10;
            int paddingRight = i26 - getPaddingRight();
            int paddingRight2 = (i26 - paddingLeft2) - getPaddingRight();
            int virtualChildCount = getVirtualChildCount();
            int i27 = this.f15470e;
            int i28 = i27 & 112;
            int i29 = 8388615 & i27;
            if (i28 != 16) {
                paddingTop = i28 != 80 ? getPaddingTop() : ((getPaddingTop() + i13) - i11) - this.f15471f;
            } else {
                paddingTop = getPaddingTop() + (((i13 - i11) - this.f15471f) / 2);
            }
            int i30 = 0;
            while (i30 < virtualChildCount) {
                View childAt = getChildAt(i30);
                if (childAt != null && childAt.getVisibility() != i25) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight2 = childAt.getMeasuredHeight();
                    LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                    int i31 = ((LinearLayout.LayoutParams) layoutParams).gravity;
                    if (i31 < 0) {
                        i31 = i29;
                    }
                    int absoluteGravity = Gravity.getAbsoluteGravity(i31, getLayoutDirection()) & 7;
                    if (absoluteGravity != 1) {
                        if (absoluteGravity != 5) {
                            i24 = ((LinearLayout.LayoutParams) layoutParams).leftMargin + paddingLeft2;
                        } else {
                            i22 = paddingRight - measuredWidth;
                            i23 = ((LinearLayout.LayoutParams) layoutParams).rightMargin;
                        }
                        if (k(i30)) {
                            paddingTop += this.f15478w;
                        }
                        int i32 = paddingTop + ((LinearLayout.LayoutParams) layoutParams).topMargin;
                        childAt.layout(i24, i32, measuredWidth + i24, i32 + measuredHeight2);
                        paddingTop = measuredHeight2 + ((LinearLayout.LayoutParams) layoutParams).bottomMargin + i32;
                    } else {
                        i22 = ((paddingRight2 - measuredWidth) / 2) + paddingLeft2 + ((LinearLayout.LayoutParams) layoutParams).leftMargin;
                        i23 = ((LinearLayout.LayoutParams) layoutParams).rightMargin;
                    }
                    i24 = i22 - i23;
                    if (k(i30)) {
                        paddingTop += this.f15478w;
                    }
                    int i33 = paddingTop + ((LinearLayout.LayoutParams) layoutParams).topMargin;
                    childAt.layout(i24, i33, measuredWidth + i24, i33 + measuredHeight2);
                    paddingTop = measuredHeight2 + ((LinearLayout.LayoutParams) layoutParams).bottomMargin + i33;
                }
                i30++;
                c10 = c10;
                i25 = 8;
            }
            return;
        }
        boolean z5 = W0.f26495a;
        boolean z10 = getLayoutDirection() == 1;
        int paddingTop2 = getPaddingTop();
        int i34 = i13 - i11;
        int paddingBottom = i34 - getPaddingBottom();
        int paddingBottom2 = (i34 - paddingTop2) - getPaddingBottom();
        int virtualChildCount2 = getVirtualChildCount();
        int i35 = this.f15470e;
        int i36 = 8388615 & i35;
        int i37 = i35 & 112;
        boolean z11 = this.f15466a;
        int[] iArr = this.f15474s;
        int[] iArr2 = this.f15475t;
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i36, getLayoutDirection());
        if (absoluteGravity2 != 1) {
            paddingLeft = absoluteGravity2 != 5 ? getPaddingLeft() : ((getPaddingLeft() + i12) - i10) - this.f15471f;
        } else {
            paddingLeft = getPaddingLeft() + (((i12 - i10) - this.f15471f) / 2);
        }
        if (z10) {
            i15 = virtualChildCount2 - 1;
            i14 = -1;
        } else {
            i14 = 1;
            i15 = 0;
        }
        int i38 = 0;
        while (i38 < virtualChildCount2) {
            int i39 = (i14 * i38) + i15;
            View childAt2 = getChildAt(i39);
            if (childAt2 == null) {
                i16 = i15;
            } else {
                i16 = i15;
                if (childAt2.getVisibility() != 8) {
                    int measuredWidth2 = childAt2.getMeasuredWidth();
                    int measuredHeight3 = childAt2.getMeasuredHeight();
                    LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
                    int i40 = paddingLeft;
                    if (z11) {
                        i17 = paddingTop2;
                        baseline = ((LinearLayout.LayoutParams) layoutParams2).height != -1 ? childAt2.getBaseline() : -1;
                        i18 = ((LinearLayout.LayoutParams) layoutParams2).gravity;
                        if (i18 < 0) {
                            i18 = i37;
                        }
                        i19 = i18 & 112;
                        if (i19 != 16) {
                            if (i19 != 48) {
                                i20 = i17 + ((LinearLayout.LayoutParams) layoutParams2).topMargin;
                                if (baseline != -1) {
                                    i20 = (iArr[1] - baseline) + i20;
                                }
                            } else if (i19 != 80) {
                                i20 = i17;
                            } else {
                                i20 = (paddingBottom - measuredHeight3) - ((LinearLayout.LayoutParams) layoutParams2).bottomMargin;
                                if (baseline != -1) {
                                    measuredHeight = iArr2[2] - (childAt2.getMeasuredHeight() - baseline);
                                }
                            }
                            if (k(i39)) {
                                i21 = i40 + this.f15477v;
                            } else {
                                i21 = i40;
                            }
                            int i41 = i21 + ((LinearLayout.LayoutParams) layoutParams2).leftMargin;
                            childAt2.layout(i41, i20, i41 + measuredWidth2, i20 + measuredHeight3);
                            paddingLeft = measuredWidth2 + ((LinearLayout.LayoutParams) layoutParams2).rightMargin + i41;
                        } else {
                            i20 = ((paddingBottom2 - measuredHeight3) / 2) + i17 + ((LinearLayout.LayoutParams) layoutParams2).topMargin;
                            measuredHeight = ((LinearLayout.LayoutParams) layoutParams2).bottomMargin;
                        }
                        i20 -= measuredHeight;
                        if (k(i39)) {
                            i21 = i40 + this.f15477v;
                        } else {
                            i21 = i40;
                        }
                        int i42 = i21 + ((LinearLayout.LayoutParams) layoutParams2).leftMargin;
                        childAt2.layout(i42, i20, i42 + measuredWidth2, i20 + measuredHeight3);
                        paddingLeft = measuredWidth2 + ((LinearLayout.LayoutParams) layoutParams2).rightMargin + i42;
                    } else {
                        i17 = paddingTop2;
                    }
                    i18 = ((LinearLayout.LayoutParams) layoutParams2).gravity;
                    if (i18 < 0) {
                        i18 = i37;
                    }
                    i19 = i18 & 112;
                    if (i19 != 16) {
                        if (i19 != 48) {
                            i20 = i17 + ((LinearLayout.LayoutParams) layoutParams2).topMargin;
                            if (baseline != -1) {
                                i20 = (iArr[1] - baseline) + i20;
                            }
                        } else if (i19 != 80) {
                            i20 = i17;
                        } else {
                            i20 = (paddingBottom - measuredHeight3) - ((LinearLayout.LayoutParams) layoutParams2).bottomMargin;
                            if (baseline != -1) {
                                measuredHeight = iArr2[2] - (childAt2.getMeasuredHeight() - baseline);
                            }
                        }
                        if (k(i39)) {
                            i21 = i40 + this.f15477v;
                        } else {
                            i21 = i40;
                        }
                        int i43 = i21 + ((LinearLayout.LayoutParams) layoutParams2).leftMargin;
                        childAt2.layout(i43, i20, i43 + measuredWidth2, i20 + measuredHeight3);
                        paddingLeft = measuredWidth2 + ((LinearLayout.LayoutParams) layoutParams2).rightMargin + i43;
                    } else {
                        i20 = ((paddingBottom2 - measuredHeight3) / 2) + i17 + ((LinearLayout.LayoutParams) layoutParams2).topMargin;
                        measuredHeight = ((LinearLayout.LayoutParams) layoutParams2).bottomMargin;
                    }
                    i20 -= measuredHeight;
                    if (k(i39)) {
                        i21 = i40 + this.f15477v;
                    } else {
                        i21 = i40;
                    }
                    int i44 = i21 + ((LinearLayout.LayoutParams) layoutParams2).leftMargin;
                    childAt2.layout(i44, i20, i44 + measuredWidth2, i20 + measuredHeight3);
                    paddingLeft = measuredWidth2 + ((LinearLayout.LayoutParams) layoutParams2).rightMargin + i44;
                }
                i38++;
                i15 = i16;
                paddingTop2 = i17;
            }
            i17 = paddingTop2;
            i38++;
            i15 = i16;
            paddingTop2 = i17;
        }
    }

    /* JADX WARN: Code duplicated, block: B:228:0x04e4  */
    /* JADX WARN: Code duplicated, block: B:231:0x04f9  */
    /* JADX WARN: Code duplicated, block: B:233:0x0502  */
    /* JADX WARN: Code duplicated, block: B:235:0x0506  */
    /* JADX WARN: Code duplicated, block: B:237:0x0527  */
    /* JADX WARN: Code duplicated, block: B:243:0x0537  */
    /* JADX WARN: Code duplicated, block: B:246:0x053e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:248:0x0541  */
    /* JADX WARN: Code duplicated, block: B:250:0x0548 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:252:0x054b  */
    /* JADX WARN: Code duplicated, block: B:366:0x079d  */
    /* JADX WARN: Code duplicated, block: B:64:0x013f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:66:0x0142  */
    /* JADX WARN: Code duplicated, block: B:68:0x0148 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:70:0x014b  */
    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        int iMax;
        int i15;
        int baseline;
        int i16;
        int i17;
        int[] iArr;
        int i18;
        int i19;
        boolean z3;
        boolean z5;
        LayoutParams layoutParams;
        View view;
        int i20;
        int[] iArr2;
        int i21;
        int i22;
        boolean z10;
        int i23;
        int measuredHeight;
        boolean z11;
        boolean z12;
        int iMax2;
        int i24;
        int baseline2;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        boolean z13;
        int i30;
        int i31;
        int i32;
        View view2;
        boolean z14;
        LinearLayoutCompat linearLayoutCompat = this;
        int i33 = -2;
        int i34 = 1073741824;
        int i35 = 8;
        int iMax3 = 0;
        if (linearLayoutCompat.f15469d == 1) {
            linearLayoutCompat.f15471f = 0;
            int virtualChildCount = linearLayoutCompat.getVirtualChildCount();
            int mode = View.MeasureSpec.getMode(i10);
            int mode2 = View.MeasureSpec.getMode(i11);
            int i36 = linearLayoutCompat.f15467b;
            boolean z15 = linearLayoutCompat.f15473r;
            int i37 = 0;
            int iMax4 = 0;
            int iMax5 = 0;
            boolean z16 = false;
            int i38 = 0;
            boolean z17 = false;
            boolean z18 = true;
            float f10 = 0.0f;
            int iMax6 = 0;
            while (i37 < virtualChildCount) {
                int i39 = mode;
                View childAt = linearLayoutCompat.getChildAt(i37);
                if (childAt == null) {
                    linearLayoutCompat.f15471f = linearLayoutCompat.f15471f;
                } else {
                    if (childAt.getVisibility() != i35) {
                        if (linearLayoutCompat.k(i37)) {
                            linearLayoutCompat.f15471f += linearLayoutCompat.f15478w;
                        }
                        LayoutParams layoutParams2 = (LayoutParams) childAt.getLayoutParams();
                        float f11 = ((LinearLayout.LayoutParams) layoutParams2).weight;
                        f10 += f11;
                        if (mode2 == i34 && ((LinearLayout.LayoutParams) layoutParams2).height == 0 && f11 > 0.0f) {
                            int i40 = linearLayoutCompat.f15471f;
                            linearLayoutCompat.f15471f = Math.max(i40, ((LinearLayout.LayoutParams) layoutParams2).topMargin + i40 + ((LinearLayout.LayoutParams) layoutParams2).bottomMargin);
                            view2 = childAt;
                            i29 = mode2;
                            i30 = i36;
                            z13 = z15;
                            i31 = i37;
                            z16 = true;
                            i32 = i39;
                        } else {
                            if (((LinearLayout.LayoutParams) layoutParams2).height != 0 || f11 <= 0.0f) {
                                i28 = Integer.MIN_VALUE;
                            } else {
                                ((LinearLayout.LayoutParams) layoutParams2).height = i33;
                                i28 = 0;
                            }
                            i29 = mode2;
                            z13 = z15;
                            i30 = i36;
                            i31 = i37;
                            i32 = i39;
                            linearLayoutCompat.measureChildWithMargins(childAt, i10, 0, i11, f10 == 0.0f ? linearLayoutCompat.f15471f : 0);
                            if (i28 != Integer.MIN_VALUE) {
                                ((LinearLayout.LayoutParams) layoutParams2).height = i28;
                            }
                            int measuredHeight2 = childAt.getMeasuredHeight();
                            int i41 = linearLayoutCompat.f15471f;
                            view2 = childAt;
                            linearLayoutCompat.f15471f = Math.max(i41, i41 + measuredHeight2 + ((LinearLayout.LayoutParams) layoutParams2).topMargin + ((LinearLayout.LayoutParams) layoutParams2).bottomMargin);
                            if (z13) {
                                iMax6 = Math.max(measuredHeight2, iMax6);
                            }
                        }
                        if (i30 >= 0 && i30 == i31 + 1) {
                            linearLayoutCompat.f15468c = linearLayoutCompat.f15471f;
                        }
                        if (i31 < i30 && ((LinearLayout.LayoutParams) layoutParams2).weight > 0.0f) {
                            throw new RuntimeException("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex.");
                        }
                        if (i32 == 1073741824 || ((LinearLayout.LayoutParams) layoutParams2).width != -1) {
                            z14 = false;
                        } else {
                            z14 = true;
                            z17 = true;
                        }
                        int i42 = ((LinearLayout.LayoutParams) layoutParams2).leftMargin + ((LinearLayout.LayoutParams) layoutParams2).rightMargin;
                        int measuredWidth = view2.getMeasuredWidth() + i42;
                        int iMax7 = Math.max(iMax3, measuredWidth);
                        int measuredState = view2.getMeasuredState();
                        boolean z19 = z14;
                        int iCombineMeasuredStates = View.combineMeasuredStates(i38, measuredState);
                        if (z18) {
                            i38 = iCombineMeasuredStates;
                            boolean z20 = ((LinearLayout.LayoutParams) layoutParams2).width == -1;
                            if (((LinearLayout.LayoutParams) layoutParams2).weight > 0.0f) {
                                if (!z19) {
                                    i42 = measuredWidth;
                                }
                                iMax5 = Math.max(iMax5, i42);
                            } else {
                                if (!z19) {
                                    i42 = measuredWidth;
                                }
                                iMax4 = Math.max(iMax4, i42);
                            }
                            z18 = z20;
                            iMax3 = iMax7;
                        } else {
                            i38 = iCombineMeasuredStates;
                        }
                        if (((LinearLayout.LayoutParams) layoutParams2).weight > 0.0f) {
                            if (!z19) {
                                i42 = measuredWidth;
                            }
                            iMax5 = Math.max(iMax5, i42);
                        } else {
                            if (!z19) {
                                i42 = measuredWidth;
                            }
                            iMax4 = Math.max(iMax4, i42);
                        }
                        z18 = z20;
                        iMax3 = iMax7;
                    }
                    i37 = i31 + 1;
                    i36 = i30;
                    mode = i32;
                    z15 = z13;
                    mode2 = i29;
                    i33 = -2;
                    i34 = 1073741824;
                    i35 = 8;
                }
                i29 = mode2;
                i30 = i36;
                z13 = z15;
                i31 = i37;
                i32 = i39;
                i37 = i31 + 1;
                i36 = i30;
                mode = i32;
                z15 = z13;
                mode2 = i29;
                i33 = -2;
                i34 = 1073741824;
                i35 = 8;
            }
            int i43 = mode;
            int i44 = mode2;
            boolean z21 = z15;
            int i45 = i38;
            int i46 = i11;
            if (linearLayoutCompat.f15471f > 0 && linearLayoutCompat.k(virtualChildCount)) {
                linearLayoutCompat.f15471f += linearLayoutCompat.f15478w;
            }
            if (z21 && (i44 == Integer.MIN_VALUE || i44 == 0)) {
                linearLayoutCompat.f15471f = 0;
                for (int i47 = 0; i47 < virtualChildCount; i47++) {
                    View childAt2 = linearLayoutCompat.getChildAt(i47);
                    if (childAt2 == null) {
                        linearLayoutCompat.f15471f = linearLayoutCompat.f15471f;
                    } else if (childAt2.getVisibility() != 8) {
                        LayoutParams layoutParams3 = (LayoutParams) childAt2.getLayoutParams();
                        int i48 = linearLayoutCompat.f15471f;
                        linearLayoutCompat.f15471f = Math.max(i48, i48 + iMax6 + ((LinearLayout.LayoutParams) layoutParams3).topMargin + ((LinearLayout.LayoutParams) layoutParams3).bottomMargin);
                    }
                }
            }
            int paddingBottom = linearLayoutCompat.getPaddingBottom() + linearLayoutCompat.getPaddingTop() + linearLayoutCompat.f15471f;
            linearLayoutCompat.f15471f = paddingBottom;
            int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingBottom, linearLayoutCompat.getSuggestedMinimumHeight()), i46, 0);
            int i49 = (iResolveSizeAndState & 16777215) - linearLayoutCompat.f15471f;
            if (z16 || (i49 != 0 && f10 > 0.0f)) {
                float f12 = linearLayoutCompat.f15472q;
                if (f12 > 0.0f) {
                    f10 = f12;
                }
                linearLayoutCompat.f15471f = 0;
                int iCombineMeasuredStates2 = i45;
                int i50 = 0;
                while (i50 < virtualChildCount) {
                    View childAt3 = linearLayoutCompat.getChildAt(i50);
                    if (childAt3.getVisibility() == 8) {
                        i50 = i50;
                    } else {
                        LayoutParams layoutParams4 = (LayoutParams) childAt3.getLayoutParams();
                        float f13 = ((LinearLayout.LayoutParams) layoutParams4).weight;
                        if (f13 > 0.0f) {
                            int i51 = (int) ((i49 * f13) / f10);
                            f10 -= f13;
                            i49 -= i51;
                            int childMeasureSpec = ViewGroup.getChildMeasureSpec(i10, linearLayoutCompat.getPaddingRight() + linearLayoutCompat.getPaddingLeft() + ((LinearLayout.LayoutParams) layoutParams4).leftMargin + ((LinearLayout.LayoutParams) layoutParams4).rightMargin, ((LinearLayout.LayoutParams) layoutParams4).width);
                            if (((LinearLayout.LayoutParams) layoutParams4).height == 0) {
                                i27 = 1073741824;
                                if (i44 == 1073741824) {
                                    if (i51 <= 0) {
                                        i51 = 0;
                                    }
                                    childAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(i51, 1073741824));
                                }
                                iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, childAt3.getMeasuredState() & (-256));
                            } else {
                                i27 = 1073741824;
                            }
                            int measuredHeight3 = childAt3.getMeasuredHeight() + i51;
                            if (measuredHeight3 < 0) {
                                measuredHeight3 = 0;
                            }
                            childAt3.measure(childMeasureSpec, View.MeasureSpec.makeMeasureSpec(measuredHeight3, i27));
                            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, childAt3.getMeasuredState() & (-256));
                        }
                        int i52 = ((LinearLayout.LayoutParams) layoutParams4).leftMargin + ((LinearLayout.LayoutParams) layoutParams4).rightMargin;
                        int measuredWidth2 = childAt3.getMeasuredWidth() + i52;
                        iMax3 = Math.max(iMax3, measuredWidth2);
                        if (i43 != 1073741824) {
                            i26 = -1;
                            if (((LinearLayout.LayoutParams) layoutParams4).width == -1) {
                                measuredWidth2 = i52;
                            }
                        } else {
                            i26 = -1;
                        }
                        iMax4 = Math.max(iMax4, measuredWidth2);
                        boolean z22 = z18 && ((LinearLayout.LayoutParams) layoutParams4).width == i26;
                        int i53 = linearLayoutCompat.f15471f;
                        linearLayoutCompat.f15471f = Math.max(i53, childAt3.getMeasuredHeight() + i53 + ((LinearLayout.LayoutParams) layoutParams4).topMargin + ((LinearLayout.LayoutParams) layoutParams4).bottomMargin);
                        z18 = z22;
                    }
                    i50++;
                }
                linearLayoutCompat.f15471f = linearLayoutCompat.getPaddingBottom() + linearLayoutCompat.getPaddingTop() + linearLayoutCompat.f15471f;
                i45 = iCombineMeasuredStates2;
            } else {
                iMax4 = Math.max(iMax4, iMax5);
                if (z21 && i44 != 1073741824) {
                    for (int i54 = 0; i54 < virtualChildCount; i54++) {
                        View childAt4 = linearLayoutCompat.getChildAt(i54);
                        if (childAt4 != null && childAt4.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((LayoutParams) childAt4.getLayoutParams())).weight > 0.0f) {
                            childAt4.measure(View.MeasureSpec.makeMeasureSpec(childAt4.getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(iMax6, 1073741824));
                        }
                    }
                }
            }
            if (z18 || i43 == 1073741824) {
                iMax4 = iMax3;
            }
            linearLayoutCompat.setMeasuredDimension(View.resolveSizeAndState(Math.max(linearLayoutCompat.getPaddingRight() + linearLayoutCompat.getPaddingLeft() + iMax4, linearLayoutCompat.getSuggestedMinimumWidth()), i10, i45), iResolveSizeAndState);
            if (z17) {
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(linearLayoutCompat.getMeasuredWidth(), 1073741824);
                int i55 = 0;
                while (i55 < virtualChildCount) {
                    View childAt5 = linearLayoutCompat.getChildAt(i55);
                    if (childAt5.getVisibility() != 8) {
                        LayoutParams layoutParams5 = (LayoutParams) childAt5.getLayoutParams();
                        if (((LinearLayout.LayoutParams) layoutParams5).width == -1) {
                            int i56 = ((LinearLayout.LayoutParams) layoutParams5).height;
                            ((LinearLayout.LayoutParams) layoutParams5).height = childAt5.getMeasuredHeight();
                            linearLayoutCompat.measureChildWithMargins(childAt5, iMakeMeasureSpec, 0, i46, 0);
                            ((LinearLayout.LayoutParams) layoutParams5).height = i56;
                        }
                    }
                    i55++;
                    i46 = i11;
                }
                return;
            }
            return;
        }
        int i57 = i10;
        linearLayoutCompat.f15471f = 0;
        int virtualChildCount2 = linearLayoutCompat.getVirtualChildCount();
        int mode3 = View.MeasureSpec.getMode(i57);
        int mode4 = View.MeasureSpec.getMode(i11);
        if (linearLayoutCompat.f15474s == null || linearLayoutCompat.f15475t == null) {
            linearLayoutCompat.f15474s = new int[4];
            linearLayoutCompat.f15475t = new int[4];
        }
        int[] iArr3 = linearLayoutCompat.f15474s;
        int[] iArr4 = linearLayoutCompat.f15475t;
        iArr3[3] = -1;
        char c10 = 2;
        iArr3[2] = -1;
        iArr3[1] = -1;
        iArr3[0] = -1;
        iArr4[3] = -1;
        iArr4[2] = -1;
        iArr4[1] = -1;
        iArr4[0] = -1;
        boolean z23 = linearLayoutCompat.f15466a;
        boolean z24 = linearLayoutCompat.f15473r;
        boolean z25 = mode3 == 1073741824;
        float f14 = 0.0f;
        boolean z26 = true;
        int i58 = 0;
        int i59 = 0;
        int i60 = 0;
        int iMax8 = 0;
        int iMax9 = 0;
        int iCombineMeasuredStates3 = 0;
        boolean z27 = false;
        boolean z28 = false;
        while (i58 < virtualChildCount2) {
            char c11 = c10;
            View childAt6 = linearLayoutCompat.getChildAt(i58);
            if (childAt6 == null) {
                linearLayoutCompat.f15471f = linearLayoutCompat.f15471f;
                i19 = i58;
                i24 = i60;
                iArr2 = iArr3;
                iArr = iArr4;
                z3 = z23;
                z5 = z24;
            } else {
                int i61 = i59;
                if (childAt6.getVisibility() == 8) {
                    i57 = i10;
                    i19 = i58;
                    i24 = i60;
                    iArr = iArr4;
                    z3 = z23;
                    z5 = z24;
                    i59 = i61;
                    iArr2 = iArr3;
                } else {
                    if (linearLayoutCompat.k(i58)) {
                        linearLayoutCompat.f15471f += linearLayoutCompat.f15477v;
                    }
                    LayoutParams layoutParams6 = (LayoutParams) childAt6.getLayoutParams();
                    float f15 = ((LinearLayout.LayoutParams) layoutParams6).weight;
                    f14 += f15;
                    int i62 = i58;
                    if (mode3 == 1073741824 && ((LinearLayout.LayoutParams) layoutParams6).width == 0 && f15 > 0.0f) {
                        if (z25) {
                            linearLayoutCompat.f15471f = ((LinearLayout.LayoutParams) layoutParams6).leftMargin + ((LinearLayout.LayoutParams) layoutParams6).rightMargin + linearLayoutCompat.f15471f;
                        } else {
                            int i63 = linearLayoutCompat.f15471f;
                            linearLayoutCompat.f15471f = Math.max(i63, ((LinearLayout.LayoutParams) layoutParams6).leftMargin + i63 + ((LinearLayout.LayoutParams) layoutParams6).rightMargin);
                        }
                        if (z23) {
                            int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
                            childAt6.measure(iMakeMeasureSpec2, iMakeMeasureSpec2);
                            view = childAt6;
                            z3 = z23;
                            z5 = z24;
                            i20 = i61;
                            i19 = i62;
                            layoutParams = layoutParams6;
                            iArr2 = iArr3;
                            iArr = iArr4;
                            i57 = i10;
                            i21 = i60;
                            i18 = iMax8;
                        } else {
                            view = childAt6;
                            z3 = z23;
                            z5 = z24;
                            z28 = true;
                            i20 = i61;
                            i19 = i62;
                            i22 = 1073741824;
                            layoutParams = layoutParams6;
                            iArr2 = iArr3;
                            iArr = iArr4;
                            i57 = i10;
                            i21 = i60;
                            i18 = iMax8;
                        }
                        if (mode4 == i22 && ((LinearLayout.LayoutParams) layoutParams).height == -1) {
                            z10 = true;
                            z27 = true;
                        } else {
                            z10 = false;
                        }
                        i23 = ((LinearLayout.LayoutParams) layoutParams).topMargin + ((LinearLayout.LayoutParams) layoutParams).bottomMargin;
                        measuredHeight = view.getMeasuredHeight() + i23;
                        iCombineMeasuredStates3 = View.combineMeasuredStates(iCombineMeasuredStates3, view.getMeasuredState());
                        if (z3) {
                            baseline2 = view.getBaseline();
                            z11 = z10;
                            if (baseline2 != -1) {
                                i25 = ((LinearLayout.LayoutParams) layoutParams).gravity;
                                if (i25 < 0) {
                                    i25 = linearLayoutCompat.f15470e;
                                }
                                int i64 = (((i25 & 112) >> 4) & (-2)) >> 1;
                                iArr2[i64] = Math.max(iArr2[i64], baseline2);
                                iArr[i64] = Math.max(iArr[i64], measuredHeight - baseline2);
                            }
                        } else {
                            z11 = z10;
                        }
                        int iMax10 = Math.max(i20, measuredHeight);
                        if (z26 || ((LinearLayout.LayoutParams) layoutParams).height != -1) {
                            z12 = false;
                        } else {
                            z12 = true;
                        }
                        if (((LinearLayout.LayoutParams) layoutParams).weight > 0.0f) {
                            if (!z11) {
                                i23 = measuredHeight;
                            }
                            iMax8 = Math.max(i18, i23);
                            iMax2 = i21;
                        } else {
                            if (!z11) {
                                i23 = measuredHeight;
                            }
                            iMax2 = Math.max(i21, i23);
                            iMax8 = i18;
                        }
                        int i65 = iMax2;
                        i59 = iMax10;
                        i24 = i65;
                        z26 = z12;
                    } else {
                        if (((LinearLayout.LayoutParams) layoutParams6).width != 0 || f15 <= 0.0f) {
                            i17 = Integer.MIN_VALUE;
                        } else {
                            ((LinearLayout.LayoutParams) layoutParams6).width = -2;
                            i17 = 0;
                        }
                        iArr = iArr4;
                        i18 = iMax8;
                        i19 = i62;
                        z3 = z23;
                        z5 = z24;
                        int i66 = i17;
                        layoutParams = layoutParams6;
                        view = childAt6;
                        i20 = i61;
                        i57 = i10;
                        iArr2 = iArr3;
                        i21 = i60;
                        linearLayoutCompat.measureChildWithMargins(view, i57, f14 == 0.0f ? linearLayoutCompat.f15471f : 0, i11, 0);
                        if (i66 != Integer.MIN_VALUE) {
                            ((LinearLayout.LayoutParams) layoutParams).width = i66;
                        }
                        int measuredWidth3 = view.getMeasuredWidth();
                        if (z25) {
                            linearLayoutCompat.f15471f = ((LinearLayout.LayoutParams) layoutParams).leftMargin + measuredWidth3 + ((LinearLayout.LayoutParams) layoutParams).rightMargin + linearLayoutCompat.f15471f;
                        } else {
                            int i67 = linearLayoutCompat.f15471f;
                            linearLayoutCompat.f15471f = Math.max(i67, i67 + measuredWidth3 + ((LinearLayout.LayoutParams) layoutParams).leftMargin + ((LinearLayout.LayoutParams) layoutParams).rightMargin);
                        }
                        if (z5) {
                            iMax9 = Math.max(measuredWidth3, iMax9);
                        }
                    }
                    i22 = 1073741824;
                    if (mode4 == i22) {
                        z10 = false;
                    } else {
                        z10 = false;
                    }
                    i23 = ((LinearLayout.LayoutParams) layoutParams).topMargin + ((LinearLayout.LayoutParams) layoutParams).bottomMargin;
                    measuredHeight = view.getMeasuredHeight() + i23;
                    iCombineMeasuredStates3 = View.combineMeasuredStates(iCombineMeasuredStates3, view.getMeasuredState());
                    if (z3) {
                        baseline2 = view.getBaseline();
                        z11 = z10;
                        if (baseline2 != -1) {
                            i25 = ((LinearLayout.LayoutParams) layoutParams).gravity;
                            if (i25 < 0) {
                                i25 = linearLayoutCompat.f15470e;
                            }
                            int i68 = (((i25 & 112) >> 4) & (-2)) >> 1;
                            iArr2[i68] = Math.max(iArr2[i68], baseline2);
                            iArr[i68] = Math.max(iArr[i68], measuredHeight - baseline2);
                        }
                    } else {
                        z11 = z10;
                    }
                    int iMax11 = Math.max(i20, measuredHeight);
                    if (z26) {
                        z12 = false;
                    } else {
                        z12 = false;
                    }
                    if (((LinearLayout.LayoutParams) layoutParams).weight > 0.0f) {
                        if (!z11) {
                            i23 = measuredHeight;
                        }
                        iMax8 = Math.max(i18, i23);
                        iMax2 = i21;
                    } else {
                        if (!z11) {
                            i23 = measuredHeight;
                        }
                        iMax2 = Math.max(i21, i23);
                        iMax8 = i18;
                    }
                    int i69 = iMax2;
                    i59 = iMax11;
                    i24 = i69;
                    z26 = z12;
                }
            }
            i60 = i24;
            i58 = i19 + 1;
            c10 = c11;
            iArr3 = iArr2;
            iArr4 = iArr;
            z23 = z3;
            z24 = z5;
        }
        int[] iArr5 = iArr3;
        int[] iArr6 = iArr4;
        char c12 = c10;
        boolean z29 = z23;
        boolean z30 = z24;
        int i70 = i59;
        int i71 = i60;
        int i72 = iMax8;
        if (linearLayoutCompat.f15471f > 0 && linearLayoutCompat.k(virtualChildCount2)) {
            linearLayoutCompat.f15471f += linearLayoutCompat.f15477v;
        }
        int i73 = iArr5[1];
        int iMax12 = (i73 == -1 && iArr5[0] == -1 && iArr5[c12] == -1 && iArr5[3] == -1) ? i70 : Math.max(i70, Math.max(iArr6[3], Math.max(iArr6[0], Math.max(iArr6[1], iArr6[c12]))) + Math.max(iArr5[3], Math.max(iArr5[0], Math.max(i73, iArr5[c12]))));
        if (z30 && (mode3 == Integer.MIN_VALUE || mode3 == 0)) {
            linearLayoutCompat.f15471f = 0;
            for (int i74 = 0; i74 < virtualChildCount2; i74++) {
                View childAt7 = linearLayoutCompat.getChildAt(i74);
                if (childAt7 == null) {
                    linearLayoutCompat.f15471f = linearLayoutCompat.f15471f;
                } else if (childAt7.getVisibility() != 8) {
                    LayoutParams layoutParams7 = (LayoutParams) childAt7.getLayoutParams();
                    if (z25) {
                        linearLayoutCompat.f15471f = ((LinearLayout.LayoutParams) layoutParams7).leftMargin + iMax9 + ((LinearLayout.LayoutParams) layoutParams7).rightMargin + linearLayoutCompat.f15471f;
                    } else {
                        int i75 = linearLayoutCompat.f15471f;
                        linearLayoutCompat.f15471f = Math.max(i75, i75 + iMax9 + ((LinearLayout.LayoutParams) layoutParams7).leftMargin + ((LinearLayout.LayoutParams) layoutParams7).rightMargin);
                    }
                }
            }
        }
        int paddingRight = linearLayoutCompat.getPaddingRight() + linearLayoutCompat.getPaddingLeft() + linearLayoutCompat.f15471f;
        linearLayoutCompat.f15471f = paddingRight;
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingRight, linearLayoutCompat.getSuggestedMinimumWidth()), i57, 0);
        int i76 = (iResolveSizeAndState2 & 16777215) - linearLayoutCompat.f15471f;
        if (z28 || (i76 != 0 && f14 > 0.0f)) {
            float f16 = linearLayoutCompat.f15472q;
            if (f16 > 0.0f) {
                f14 = f16;
            }
            iArr5[3] = -1;
            iArr5[c12] = -1;
            iArr5[1] = -1;
            iArr5[0] = -1;
            iArr6[3] = -1;
            iArr6[c12] = -1;
            iArr6[1] = -1;
            iArr6[0] = -1;
            linearLayoutCompat.f15471f = 0;
            iMax12 = -1;
            int i77 = 0;
            while (i77 < virtualChildCount2) {
                View childAt8 = linearLayoutCompat.getChildAt(i77);
                if (childAt8 == null || childAt8.getVisibility() == 8) {
                    iResolveSizeAndState2 = iResolveSizeAndState2;
                } else {
                    LayoutParams layoutParams8 = (LayoutParams) childAt8.getLayoutParams();
                    float f17 = ((LinearLayout.LayoutParams) layoutParams8).weight;
                    if (f17 > 0.0f) {
                        int i78 = (int) ((i76 * f17) / f14);
                        f14 -= f17;
                        i76 -= i78;
                        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i11, linearLayoutCompat.getPaddingBottom() + linearLayoutCompat.getPaddingTop() + ((LinearLayout.LayoutParams) layoutParams8).topMargin + ((LinearLayout.LayoutParams) layoutParams8).bottomMargin, ((LinearLayout.LayoutParams) layoutParams8).height);
                        if (((LinearLayout.LayoutParams) layoutParams8).width == 0) {
                            i16 = 1073741824;
                            if (mode3 == 1073741824) {
                                if (i78 <= 0) {
                                    i78 = 0;
                                }
                                childAt8.measure(View.MeasureSpec.makeMeasureSpec(i78, 1073741824), childMeasureSpec2);
                            }
                            iCombineMeasuredStates3 = View.combineMeasuredStates(iCombineMeasuredStates3, childAt8.getMeasuredState() & (-16777216));
                        } else {
                            i16 = 1073741824;
                        }
                        int measuredWidth4 = childAt8.getMeasuredWidth() + i78;
                        if (measuredWidth4 < 0) {
                            measuredWidth4 = 0;
                        }
                        childAt8.measure(View.MeasureSpec.makeMeasureSpec(measuredWidth4, i16), childMeasureSpec2);
                        iCombineMeasuredStates3 = View.combineMeasuredStates(iCombineMeasuredStates3, childAt8.getMeasuredState() & (-16777216));
                    }
                    if (z25) {
                        linearLayoutCompat.f15471f = childAt8.getMeasuredWidth() + ((LinearLayout.LayoutParams) layoutParams8).leftMargin + ((LinearLayout.LayoutParams) layoutParams8).rightMargin + linearLayoutCompat.f15471f;
                    } else {
                        int i79 = linearLayoutCompat.f15471f;
                        linearLayoutCompat.f15471f = Math.max(i79, childAt8.getMeasuredWidth() + i79 + ((LinearLayout.LayoutParams) layoutParams8).leftMargin + ((LinearLayout.LayoutParams) layoutParams8).rightMargin);
                    }
                    boolean z31 = mode4 != 1073741824 && ((LinearLayout.LayoutParams) layoutParams8).height == -1;
                    int i80 = ((LinearLayout.LayoutParams) layoutParams8).topMargin + ((LinearLayout.LayoutParams) layoutParams8).bottomMargin;
                    int measuredHeight4 = childAt8.getMeasuredHeight() + i80;
                    iMax12 = Math.max(iMax12, measuredHeight4);
                    if (!z31) {
                        i80 = measuredHeight4;
                    }
                    int iMax13 = Math.max(i71, i80);
                    if (z26) {
                        i15 = -1;
                        boolean z32 = ((LinearLayout.LayoutParams) layoutParams8).height == -1;
                        if (!z29 && (baseline = childAt8.getBaseline()) != i15) {
                            int i81 = ((LinearLayout.LayoutParams) layoutParams8).gravity;
                            if (i81 < 0) {
                                i81 = linearLayoutCompat.f15470e;
                            }
                            int i82 = (((i81 & 112) >> 4) & (-2)) >> 1;
                            iArr5[i82] = Math.max(iArr5[i82], baseline);
                            iArr6[i82] = Math.max(iArr6[i82], measuredHeight4 - baseline);
                        }
                        z26 = z32;
                        i71 = iMax13;
                    } else {
                        i15 = -1;
                    }
                    if (!z29) {
                    }
                    z26 = z32;
                    i71 = iMax13;
                }
                i77++;
                iResolveSizeAndState2 = iResolveSizeAndState2;
            }
            i12 = iResolveSizeAndState2;
            i13 = -16777216;
            linearLayoutCompat.f15471f = linearLayoutCompat.getPaddingRight() + linearLayoutCompat.getPaddingLeft() + linearLayoutCompat.f15471f;
            int i83 = iArr5[1];
            if (i83 == -1 && iArr5[0] == -1 && iArr5[c12] == -1 && iArr5[3] == -1) {
                i14 = 0;
            } else {
                i14 = 0;
                iMax12 = Math.max(iMax12, Math.max(iArr6[3], Math.max(iArr6[0], Math.max(iArr6[1], iArr6[c12]))) + Math.max(iArr5[3], Math.max(iArr5[0], Math.max(i83, iArr5[c12]))));
            }
            iMax = i71;
        } else {
            iMax = Math.max(i71, i72);
            if (z30 && mode3 != 1073741824) {
                for (int i84 = 0; i84 < virtualChildCount2; i84++) {
                    View childAt9 = linearLayoutCompat.getChildAt(i84);
                    if (childAt9 != null && childAt9.getVisibility() != 8 && ((LinearLayout.LayoutParams) ((LayoutParams) childAt9.getLayoutParams())).weight > 0.0f) {
                        childAt9.measure(View.MeasureSpec.makeMeasureSpec(iMax9, 1073741824), View.MeasureSpec.makeMeasureSpec(childAt9.getMeasuredHeight(), 1073741824));
                    }
                }
            }
            i12 = iResolveSizeAndState2;
            i13 = -16777216;
            i14 = 0;
        }
        if (!z26 && mode4 != 1073741824) {
            iMax12 = iMax;
        }
        linearLayoutCompat.setMeasuredDimension(i12 | (iCombineMeasuredStates3 & i13), View.resolveSizeAndState(Math.max(linearLayoutCompat.getPaddingBottom() + linearLayoutCompat.getPaddingTop() + iMax12, linearLayoutCompat.getSuggestedMinimumHeight()), i11, iCombineMeasuredStates3 << 16));
        if (z27) {
            int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(linearLayoutCompat.getMeasuredHeight(), 1073741824);
            int i85 = i14;
            while (i85 < virtualChildCount2) {
                View childAt10 = linearLayoutCompat.getChildAt(i85);
                if (childAt10.getVisibility() != 8) {
                    LayoutParams layoutParams9 = (LayoutParams) childAt10.getLayoutParams();
                    if (((LinearLayout.LayoutParams) layoutParams9).height == -1) {
                        int i86 = ((LinearLayout.LayoutParams) layoutParams9).width;
                        ((LinearLayout.LayoutParams) layoutParams9).width = childAt10.getMeasuredWidth();
                        linearLayoutCompat.measureChildWithMargins(childAt10, i57, 0, iMakeMeasureSpec3, 0);
                        ((LinearLayout.LayoutParams) layoutParams9).width = i86;
                    }
                }
                i85++;
                linearLayoutCompat = this;
                i57 = i10;
            }
        }
    }

    public void setBaselineAligned(boolean z3) {
        this.f15466a = z3;
    }

    public void setBaselineAlignedChildIndex(int i10) {
        if (i10 >= 0 && i10 < getChildCount()) {
            this.f15467b = i10;
            return;
        }
        throw new IllegalArgumentException("base aligned child index out of range (0, " + getChildCount() + ")");
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable == this.f15476u) {
            return;
        }
        this.f15476u = drawable;
        if (drawable != null) {
            this.f15477v = drawable.getIntrinsicWidth();
            this.f15478w = drawable.getIntrinsicHeight();
        } else {
            this.f15477v = 0;
            this.f15478w = 0;
        }
        setWillNotDraw(drawable == null);
        requestLayout();
    }

    public void setDividerPadding(int i10) {
        this.f15480y = i10;
    }

    public void setGravity(int i10) {
        if (this.f15470e != i10) {
            if ((8388615 & i10) == 0) {
                i10 |= 8388611;
            }
            if ((i10 & 112) == 0) {
                i10 |= 48;
            }
            this.f15470e = i10;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i10) {
        int i11 = i10 & 8388615;
        int i12 = this.f15470e;
        if ((8388615 & i12) != i11) {
            this.f15470e = i11 | ((-8388616) & i12);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z3) {
        this.f15473r = z3;
    }

    public void setOrientation(int i10) {
        if (this.f15469d != i10) {
            this.f15469d = i10;
            requestLayout();
        }
    }

    public void setShowDividers(int i10) {
        if (i10 != this.f15479x) {
            requestLayout();
        }
        this.f15479x = i10;
    }

    public void setVerticalGravity(int i10) {
        int i11 = i10 & 112;
        int i12 = this.f15470e;
        if ((i12 & 112) != i11) {
            this.f15470e = i11 | (i12 & (-113));
            requestLayout();
        }
    }

    public void setWeightSum(float f10) {
        this.f15472q = Math.max(0.0f, f10);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public LinearLayoutCompat(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f15466a = true;
        this.f15467b = -1;
        this.f15468c = 0;
        this.f15470e = 8388659;
        int[] iArr = p099i.a.f23302p;
        Z2.f fVarK = Z2.f.K(context, attributeSet, iArr, i10);
        U.p(this, context, iArr, attributeSet, (TypedArray) fVarK.f14488b, i10);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        int i11 = typedArray.getInt(1, -1);
        if (i11 >= 0) {
            setOrientation(i11);
        }
        int i12 = typedArray.getInt(0, -1);
        if (i12 >= 0) {
            setGravity(i12);
        }
        boolean z3 = typedArray.getBoolean(2, true);
        if (!z3) {
            setBaselineAligned(z3);
        }
        this.f15472q = typedArray.getFloat(4, -1.0f);
        this.f15467b = typedArray.getInt(3, -1);
        this.f15473r = typedArray.getBoolean(7, false);
        setDividerDrawable(fVarK.D(5));
        this.f15479x = typedArray.getInt(8, 0);
        this.f15480y = typedArray.getDimensionPixelSize(6, 0);
        fVarK.P();
    }
}
