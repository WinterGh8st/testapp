package androidx.appcompat.widget;

import B.P;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import com.flamingotools.ws.R;
import p053e3.M;
import p175p.C1354q;
import p175p.C1359t;
import p175p.H0;
import p175p.I0;
import p175p.Z;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatCheckedTextView extends CheckedTextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C1354q f15410a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P f15411b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final M f15412c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C1359t f15413d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatCheckedTextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        int resourceId2;
        super(context, attributeSet, R.attr.checkedTextViewStyle);
        I0.a(context);
        H0.a(this, getContext());
        M m2 = new M(this);
        this.f15412c = m2;
        m2.l(attributeSet, R.attr.checkedTextViewStyle);
        m2.d();
        P p10 = new P(this);
        this.f15411b = p10;
        p10.o(attributeSet, R.attr.checkedTextViewStyle);
        this.f15410a = new C1354q(this);
        Context context2 = getContext();
        int[] iArr = p099i.a.f23299m;
        Z2.f fVarK = Z2.f.K(context2, attributeSet, iArr, R.attr.checkedTextViewStyle);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        U.p(this, getContext(), iArr, attributeSet, (TypedArray) fVarK.f14488b, R.attr.checkedTextViewStyle);
        try {
            if (typedArray.hasValue(1) && (resourceId2 = typedArray.getResourceId(1, 0)) != 0) {
                try {
                    setCheckMarkDrawable(p143m0.c.N(getContext(), resourceId2));
                } catch (Resources.NotFoundException unused) {
                    if (typedArray.hasValue(0)) {
                        setCheckMarkDrawable(p143m0.c.N(getContext(), resourceId));
                    }
                }
            } else if (typedArray.hasValue(0) && (resourceId = typedArray.getResourceId(0, 0)) != 0) {
                setCheckMarkDrawable(p143m0.c.N(getContext(), resourceId));
            }
            if (typedArray.hasValue(2)) {
                setCheckMarkTintList(fVarK.C(2));
            }
            if (typedArray.hasValue(3)) {
                setCheckMarkTintMode(Z.c(typedArray.getInt(3, -1), null));
            }
            fVarK.P();
            getEmojiTextViewHelper().b(attributeSet, R.attr.checkedTextViewStyle);
        } catch (Throwable th) {
            fVarK.P();
            throw th;
        }
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15413d == null) {
            this.f15413d = new C1359t(this);
        }
        return this.f15413d;
    }

    @Override // android.widget.CheckedTextView, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        M m2 = this.f15412c;
        if (m2 != null) {
            m2.d();
        }
        P p10 = this.f15411b;
        if (p10 != null) {
            p10.a();
        }
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            c1354q.b();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15411b;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15411b;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCheckMarkTintList() {
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            return c1354q.f26556a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCheckMarkTintMode() {
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            return c1354q.f26557b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15412c.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15412c.i();
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        p029c4.a.N0(inputConnectionOnCreateInputConnection, editorInfo, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15411b;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15411b;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(Drawable drawable) {
        super.setCheckMarkDrawable(drawable);
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            if (c1354q.f26560e) {
                c1354q.f26560e = false;
            } else {
                c1354q.f26560e = true;
                c1354q.b();
            }
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15412c;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15412c;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15411b;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15411b;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCheckMarkTintList(ColorStateList colorStateList) {
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            c1354q.f26556a = colorStateList;
            c1354q.f26558c = true;
            c1354q.b();
        }
    }

    public void setSupportCheckMarkTintMode(PorterDuff.Mode mode) {
        C1354q c1354q = this.f15410a;
        if (c1354q != null) {
            c1354q.f26557b = mode;
            c1354q.f26559d = true;
            c1354q.b();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15412c;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15412c;
        m2.r(mode);
        m2.d();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        M m2 = this.f15412c;
        if (m2 != null) {
            m2.m(context, i10);
        }
    }

    @Override // android.widget.CheckedTextView
    public void setCheckMarkDrawable(int i10) {
        setCheckMarkDrawable(p143m0.c.N(getContext(), i10));
    }
}
