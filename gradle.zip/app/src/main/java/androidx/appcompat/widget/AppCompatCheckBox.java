package androidx.appcompat.widget;

import B.P;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.CheckBox;
import com.flamingotools.ws.R;
import p053e3.M;
import p175p.C1354q;
import p175p.C1359t;
import p175p.H0;
import p175p.I0;
import p273y1.s;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatCheckBox extends CheckBox implements s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C1354q f15406a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final P f15407b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final M f15408c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C1359t f15409d;

    public AppCompatCheckBox(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.checkboxStyle);
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15409d == null) {
            this.f15409d = new C1359t(this);
        }
        return this.f15409d;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15407b;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15408c;
        if (m2 != null) {
            m2.d();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15407b;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15407b;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    @Override // p273y1.s
    public ColorStateList getSupportButtonTintList() {
        C1354q c1354q = this.f15406a;
        if (c1354q != null) {
            return c1354q.f26556a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C1354q c1354q = this.f15406a;
        if (c1354q != null) {
            return c1354q.f26557b;
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15408c.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15408c.i();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15407b;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15407b;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C1354q c1354q = this.f15406a;
        if (c1354q != null) {
            if (c1354q.f26560e) {
                c1354q.f26560e = false;
            } else {
                c1354q.f26560e = true;
                c1354q.a();
            }
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15408c;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15408c;
        if (m2 != null) {
            m2.d();
        }
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15407b;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15407b;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    @Override // p273y1.s
    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C1354q c1354q = this.f15406a;
        if (c1354q != null) {
            c1354q.f26556a = colorStateList;
            c1354q.f26558c = true;
            c1354q.a();
        }
    }

    @Override // p273y1.s
    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C1354q c1354q = this.f15406a;
        if (c1354q != null) {
            c1354q.f26557b = mode;
            c1354q.f26559d = true;
            c1354q.a();
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15408c;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15408c;
        m2.r(mode);
        m2.d();
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatCheckBox(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        I0.a(context);
        H0.a(this, getContext());
        C1354q c1354q = new C1354q(this);
        this.f15406a = c1354q;
        c1354q.c(attributeSet, i10);
        P p10 = new P(this);
        this.f15407b = p10;
        p10.o(attributeSet, i10);
        M m2 = new M(this);
        this.f15408c = m2;
        m2.l(attributeSet, i10);
        getEmojiTextViewHelper().b(attributeSet, i10);
    }

    @Override // android.widget.CompoundButton
    public void setButtonDrawable(int i10) {
        setButtonDrawable(p143m0.c.N(getContext(), i10));
    }
}
