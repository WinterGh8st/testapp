package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import com.flamingotools.ws.R;
import java.lang.reflect.Method;
import p164o.B;
import p175p.AbstractC1343k0;
import p175p.AbstractC1345l0;
import p175p.C1333f0;
import p175p.C1341j0;
import p175p.C1349n0;
import p175p.C1361u;
import p175p.RunnableC1347m0;
import p273y1.l;

/* JADX INFO: loaded from: classes.dex */
public class ListPopupWindow implements B {

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public static final Method f15481K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public static final Method f15482L;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public AdapterView.OnItemSelectedListener f15483A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final RunnableC1347m0 f15484B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final p157n3.a f15485C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final C1349n0 f15486D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final RunnableC1347m0 f15487E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final Handler f15488F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final Rect f15489G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public Rect f15490H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public boolean f15491I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final C1361u f15492J;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Context f15493a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ListAdapter f15494b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C1333f0 f15495c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f15496d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f15497e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f15498f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f15499q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final int f15500r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f15501s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f15502t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f15503u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15504v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final int f15505w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public B1.b f15506x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public View f15507y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public AdapterView.OnItemClickListener f15508z;

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                f15481K = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                f15482L = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
    }

    public ListPopupWindow(Context context) {
        this(context, null, R.attr.listPopupWindowStyle);
    }

    public final int a() {
        return this.f15498f;
    }

    @Override // p164o.B
    public final boolean b() {
        return this.f15492J.isShowing();
    }

    @Override // p164o.B
    public final void c() {
        int i10;
        int iMakeMeasureSpec;
        int paddingBottom;
        C1333f0 c1333f0;
        C1333f0 c1333f1 = this.f15495c;
        C1361u c1361u = this.f15492J;
        Context context = this.f15493a;
        if (c1333f1 == null) {
            C1333f0 c1333f0Q = q(context, !this.f15491I);
            this.f15495c = c1333f0Q;
            c1333f0Q.setAdapter(this.f15494b);
            this.f15495c.setOnItemClickListener(this.f15508z);
            this.f15495c.setFocusable(true);
            this.f15495c.setFocusableInTouchMode(true);
            this.f15495c.setOnItemSelectedListener(new C1341j0(this, 0));
            this.f15495c.setOnScrollListener(this.f15486D);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f15483A;
            if (onItemSelectedListener != null) {
                this.f15495c.setOnItemSelectedListener(onItemSelectedListener);
            }
            c1361u.setContentView(this.f15495c);
        }
        Drawable background = c1361u.getBackground();
        Rect rect = this.f15489G;
        if (background != null) {
            background.getPadding(rect);
            int i11 = rect.top;
            i10 = rect.bottom + i11;
            if (!this.f15501s) {
                this.f15499q = -i11;
            }
        } else {
            rect.setEmpty();
            i10 = 0;
        }
        int iA = AbstractC1343k0.a(c1361u, this.f15507y, this.f15499q, c1361u.getInputMethodMode() == 2);
        int i12 = this.f15496d;
        if (i12 == -1) {
            paddingBottom = iA + i10;
        } else {
            int i13 = this.f15497e;
            if (i13 != -2) {
                iMakeMeasureSpec = i13 != -1 ? View.MeasureSpec.makeMeasureSpec(i13, 1073741824) : View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), 1073741824);
            } else {
                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(context.getResources().getDisplayMetrics().widthPixels - (rect.left + rect.right), Integer.MIN_VALUE);
            }
            int iA2 = this.f15495c.a(iMakeMeasureSpec, iA);
            paddingBottom = iA2 + (iA2 > 0 ? this.f15495c.getPaddingBottom() + this.f15495c.getPaddingTop() + i10 : 0);
        }
        boolean z3 = this.f15492J.getInputMethodMode() == 2;
        l.d(c1361u, this.f15500r);
        if (c1361u.isShowing()) {
            if (this.f15507y.isAttachedToWindow()) {
                int width = this.f15497e;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = this.f15507y.getWidth();
                }
                if (i12 == -1) {
                    i12 = z3 ? paddingBottom : -1;
                    if (z3) {
                        c1361u.setWidth(this.f15497e == -1 ? -1 : 0);
                        c1361u.setHeight(0);
                    } else {
                        c1361u.setWidth(this.f15497e == -1 ? -1 : 0);
                        c1361u.setHeight(-1);
                    }
                } else if (i12 == -2) {
                    i12 = paddingBottom;
                }
                c1361u.setOutsideTouchable(true);
                View view = this.f15507y;
                int i14 = this.f15498f;
                int i15 = this.f15499q;
                if (width < 0) {
                    width = -1;
                }
                c1361u.update(view, i14, i15, width, i12 < 0 ? -1 : i12);
                return;
            }
            return;
        }
        int width2 = this.f15497e;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = this.f15507y.getWidth();
        }
        if (i12 == -1) {
            i12 = -1;
        } else if (i12 == -2) {
            i12 = paddingBottom;
        }
        c1361u.setWidth(width2);
        c1361u.setHeight(i12);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method = f15481K;
            if (method != null) {
                try {
                    method.invoke(c1361u, Boolean.TRUE);
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            AbstractC1345l0.b(c1361u, true);
        }
        c1361u.setOutsideTouchable(true);
        c1361u.setTouchInterceptor(this.f15485C);
        if (this.f15503u) {
            l.c(c1361u, this.f15502t);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = f15482L;
            if (method2 != null) {
                try {
                    method2.invoke(c1361u, this.f15490H);
                } catch (Exception e10) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e10);
                }
            }
        } else {
            AbstractC1345l0.a(c1361u, this.f15490H);
        }
        c1361u.showAsDropDown(this.f15507y, this.f15498f, this.f15499q, this.f15504v);
        this.f15495c.setSelection(-1);
        if ((!this.f15491I || this.f15495c.isInTouchMode()) && (c1333f0 = this.f15495c) != null) {
            c1333f0.setListSelectionHidden(true);
            c1333f0.requestLayout();
        }
        if (this.f15491I) {
            return;
        }
        this.f15488F.post(this.f15487E);
    }

    public final Drawable d() {
        return this.f15492J.getBackground();
    }

    @Override // p164o.B
    public final void dismiss() {
        C1361u c1361u = this.f15492J;
        c1361u.dismiss();
        c1361u.setContentView(null);
        this.f15495c = null;
        this.f15488F.removeCallbacks(this.f15484B);
    }

    @Override // p164o.B
    public final C1333f0 f() {
        return this.f15495c;
    }

    public final void h(Drawable drawable) {
        this.f15492J.setBackgroundDrawable(drawable);
    }

    public final void i(int i10) {
        this.f15499q = i10;
        this.f15501s = true;
    }

    public final void k(int i10) {
        this.f15498f = i10;
    }

    public final int m() {
        if (this.f15501s) {
            return this.f15499q;
        }
        return 0;
    }

    public void p(ListAdapter listAdapter) {
        B1.b bVar = this.f15506x;
        if (bVar == null) {
            this.f15506x = new B1.b(this, 2);
        } else {
            ListAdapter listAdapter2 = this.f15494b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(bVar);
            }
        }
        this.f15494b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f15506x);
        }
        C1333f0 c1333f0 = this.f15495c;
        if (c1333f0 != null) {
            c1333f0.setAdapter(this.f15494b);
        }
    }

    public C1333f0 q(Context context, boolean z3) {
        return new C1333f0(context, z3);
    }

    public final void r(int i10) {
        Drawable background = this.f15492J.getBackground();
        if (background == null) {
            this.f15497e = i10;
            return;
        }
        Rect rect = this.f15489G;
        background.getPadding(rect);
        this.f15497e = rect.left + rect.right + i10;
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.listPopupWindowStyle);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i10) {
        Drawable drawable;
        int resourceId;
        this.f15496d = -2;
        this.f15497e = -2;
        this.f15500r = 1002;
        this.f15504v = 0;
        this.f15505w = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        this.f15484B = new RunnableC1347m0(this, 1);
        this.f15485C = new p157n3.a(this, 1);
        this.f15486D = new C1349n0(this);
        this.f15487E = new RunnableC1347m0(this, 0);
        this.f15489G = new Rect();
        this.f15493a = context;
        this.f15488F = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p099i.a.f23303q, i10, 0);
        this.f15498f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, 0);
        this.f15499q = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f15501s = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        C1361u c1361u = new C1361u(context, attributeSet, i10, 0);
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, p099i.a.f23307u, i10, 0);
        if (typedArrayObtainStyledAttributes2.hasValue(2)) {
            l.c(c1361u, typedArrayObtainStyledAttributes2.getBoolean(2, false));
        }
        if (typedArrayObtainStyledAttributes2.hasValue(0) && (resourceId = typedArrayObtainStyledAttributes2.getResourceId(0, 0)) != 0) {
            drawable = p143m0.c.N(context, resourceId);
        } else {
            drawable = typedArrayObtainStyledAttributes2.getDrawable(0);
        }
        c1361u.setBackgroundDrawable(drawable);
        typedArrayObtainStyledAttributes2.recycle();
        this.f15492J = c1361u;
        c1361u.setInputMethodMode(1);
    }
}
