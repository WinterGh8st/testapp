package androidx.appcompat.widget;

import B.P;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.text.method.NumberKeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import p053e3.M;
import p175p.C1363v;
import p175p.H0;
import p175p.I0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatAutoCompleteTextView extends AutoCompleteTextView {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int[] f15399d = {R.attr.popupBackground};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15400a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final M f15401b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1363v f15402c;

    public AppCompatAutoCompleteTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15400a;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15401b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15400a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15400a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15401b.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15401b.i();
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        p029c4.a.N0(inputConnectionOnCreateInputConnection, editorInfo, this);
        return this.f15402c.c(inputConnectionOnCreateInputConnection, editorInfo);
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15400a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15400a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15401b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15401b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    @Override // android.widget.AutoCompleteTextView
    public void setDropDownBackgroundResource(int i10) {
        setDropDownBackgroundDrawable(p143m0.c.N(getContext(), i10));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        this.f15402c.d(z3);
    }

    @Override // android.widget.TextView
    public void setKeyListener(KeyListener keyListener) {
        super.setKeyListener(this.f15402c.a(keyListener));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15400a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15400a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15401b;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15401b;
        m2.r(mode);
        m2.d();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        M m2 = this.f15401b;
        if (m2 != null) {
            m2.m(context, i10);
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatAutoCompleteTextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, com.flamingotools.ws.R.attr.autoCompleteTextViewStyle);
        I0.a(context);
        H0.a(this, getContext());
        Z2.f fVarK = Z2.f.K(getContext(), attributeSet, f15399d, com.flamingotools.ws.R.attr.autoCompleteTextViewStyle);
        if (((TypedArray) fVarK.f14488b).hasValue(0)) {
            setDropDownBackgroundDrawable(fVarK.D(0));
        }
        fVarK.P();
        P p10 = new P(this);
        this.f15400a = p10;
        p10.o(attributeSet, com.flamingotools.ws.R.attr.autoCompleteTextViewStyle);
        M m2 = new M(this);
        this.f15401b = m2;
        m2.l(attributeSet, com.flamingotools.ws.R.attr.autoCompleteTextViewStyle);
        m2.d();
        C1363v c1363v = new C1363v(this);
        this.f15402c = c1363v;
        c1363v.b(attributeSet, com.flamingotools.ws.R.attr.autoCompleteTextViewStyle);
        KeyListener keyListener = getKeyListener();
        if (keyListener instanceof NumberKeyListener) {
            return;
        }
        boolean zIsFocusable = super.isFocusable();
        boolean zIsClickable = super.isClickable();
        boolean zIsLongClickable = super.isLongClickable();
        int inputType = super.getInputType();
        KeyListener keyListenerA = c1363v.a(keyListener);
        if (keyListenerA == keyListener) {
            return;
        }
        super.setKeyListener(keyListenerA);
        super.setRawInputType(inputType);
        super.setFocusable(zIsFocusable);
        super.setClickable(zIsClickable);
        super.setLongClickable(zIsLongClickable);
    }
}
