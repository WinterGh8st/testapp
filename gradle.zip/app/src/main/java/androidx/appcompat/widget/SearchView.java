package androidx.appcompat.widget;

import C9.C0126w;
import C9.I;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import com.flamingotools.ws.R;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import p128k5.q;
import p175p.A0;
import p175p.B0;
import p175p.C0;
import p175p.C1341j0;
import p175p.D0;
import p175p.F0;
import p175p.RunnableC1366w0;
import p175p.x0;
import p175p.y0;
import p175p.z0;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class SearchView extends LinearLayoutCompat implements p153n.b {

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    public static final Va.i f15509s0;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final View f15510A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final View f15511B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final View f15512C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final ImageView f15513D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final ImageView f15514E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public final ImageView f15515F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final ImageView f15516G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final View f15517H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public D0 f15518I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final Rect f15519J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final Rect f15520K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final int[] f15521L;
    public final int[] M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final ImageView f15522N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public final Drawable f15523O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public final int f15524P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public final int f15525Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public final Intent f15526R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final Intent f15527S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final CharSequence f15528T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public A0 f15529U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public View.OnFocusChangeListener f15530V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public View.OnClickListener f15531W;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public boolean f15532a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public boolean f15533b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public B1.c f15534c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public boolean f15535d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public CharSequence f15536e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f15537f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public boolean f15538g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    public int f15539h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    public boolean f15540i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    public String f15541j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    public CharSequence f15542k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    public boolean f15543l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    public int f15544m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    public SearchableInfo f15545n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    public Bundle f15546o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    public final RunnableC1366w0 f15547p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    public final RunnableC1366w0 f15548q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    public final WeakHashMap f15549r0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final SearchAutoComplete f15550z;

    public static class SearchAutoComplete extends AppCompatAutoCompleteTextView {

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f15551e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public SearchView f15552f;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public boolean f15553q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public final g f15554r;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet, 0);
            this.f15554r = new g(this);
            this.f15551e = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i10 = configuration.screenWidthDp;
            int i11 = configuration.screenHeightDp;
            if (i10 >= 960 && i11 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i10 < 600) {
                return (i10 < 640 || i11 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() {
            if (Build.VERSION.SDK_INT >= 29) {
                f.b(this, 1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            Va.i iVar = SearchView.f15509s0;
            iVar.getClass();
            Va.i.a();
            Method method = iVar.f13109c;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.f15551e <= 0 || super.enoughToFilter();
        }

        @Override // androidx.appcompat.widget.AppCompatAutoCompleteTextView, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f15553q) {
                g gVar = this.f15554r;
                removeCallbacks(gVar);
                post(gVar);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z3, int i10, Rect rect) {
            super.onFocusChanged(z3, i10, rect);
            SearchView searchView = this.f15552f;
            searchView.y(searchView.f15533b0);
            searchView.post(searchView.f15547p0);
            if (searchView.f15550z.hasFocus()) {
                searchView.n();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i10, KeyEvent keyEvent) {
            if (i10 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f15552f.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i10, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z3) {
            super.onWindowFocusChanged(z3);
            if (z3 && this.f15552f.hasFocus() && getVisibility() == 0) {
                this.f15553q = true;
                Context context = getContext();
                Va.i iVar = SearchView.f15509s0;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z3) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            g gVar = this.f15554r;
            if (!z3) {
                this.f15553q = false;
                removeCallbacks(gVar);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f15553q = true;
                    return;
                }
                this.f15553q = false;
                removeCallbacks(gVar);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f15552f = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i10) {
            super.setThreshold(i10);
            this.f15551e = i10;
        }
    }

    static {
        Va.i iVar = null;
        if (Build.VERSION.SDK_INT < 29) {
            Va.i iVar2 = new Va.i();
            iVar2.f13107a = null;
            iVar2.f13108b = null;
            iVar2.f13109c = null;
            Va.i.a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                iVar2.f13107a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                iVar2.f13108b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                iVar2.f13109c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            iVar = iVar2;
        }
        f15509s0 = iVar;
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.searchViewStyle);
        this.f15519J = new Rect();
        this.f15520K = new Rect();
        this.f15521L = new int[2];
        this.M = new int[2];
        this.f15547p0 = new RunnableC1366w0(this, 0);
        this.f15548q0 = new RunnableC1366w0(this, 1);
        this.f15549r0 = new WeakHashMap();
        d dVar = new d(this);
        e eVar = new e(this);
        y0 y0Var = new y0(this);
        q qVar = new q(this, 2);
        C1341j0 c1341j0 = new C1341j0(this, 1);
        C0126w c0126w = new C0126w(this, 12);
        int[] iArr = p099i.a.f23309w;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.searchViewStyle, 0);
        Z2.f fVar = new Z2.f(context, typedArrayObtainStyledAttributes);
        U.p(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, R.attr.searchViewStyle);
        LayoutInflater.from(context).inflate(typedArrayObtainStyledAttributes.getResourceId(19, R.layout.abc_search_view), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f15550z = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f15510A = findViewById(R.id.search_edit_frame);
        View viewFindViewById = findViewById(R.id.search_plate);
        this.f15511B = viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.submit_area);
        this.f15512C = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f15513D = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f15514E = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f15515F = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f15516G = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.f15522N = imageView5;
        viewFindViewById.setBackground(fVar.D(20));
        viewFindViewById2.setBackground(fVar.D(25));
        imageView.setImageDrawable(fVar.D(23));
        imageView2.setImageDrawable(fVar.D(15));
        imageView3.setImageDrawable(fVar.D(12));
        imageView4.setImageDrawable(fVar.D(28));
        imageView5.setImageDrawable(fVar.D(23));
        this.f15523O = fVar.D(22);
        com.bumptech.glide.d.J0(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.f15524P = typedArrayObtainStyledAttributes.getResourceId(26, R.layout.abc_search_dropdown_item_icons_2line);
        this.f15525Q = typedArrayObtainStyledAttributes.getResourceId(13, 0);
        imageView.setOnClickListener(dVar);
        imageView3.setOnClickListener(dVar);
        imageView2.setOnClickListener(dVar);
        imageView4.setOnClickListener(dVar);
        searchAutoComplete.setOnClickListener(dVar);
        searchAutoComplete.addTextChangedListener(c0126w);
        searchAutoComplete.setOnEditorActionListener(y0Var);
        searchAutoComplete.setOnItemClickListener(qVar);
        searchAutoComplete.setOnItemSelectedListener(c1341j0);
        searchAutoComplete.setOnKeyListener(eVar);
        searchAutoComplete.setOnFocusChangeListener(new x0(this));
        setIconifiedByDefault(typedArrayObtainStyledAttributes.getBoolean(18, true));
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(2, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.f15528T = typedArrayObtainStyledAttributes.getText(14);
        this.f15536e0 = typedArrayObtainStyledAttributes.getText(21);
        int i10 = typedArrayObtainStyledAttributes.getInt(6, -1);
        if (i10 != -1) {
            setImeOptions(i10);
        }
        int i11 = typedArrayObtainStyledAttributes.getInt(5, -1);
        if (i11 != -1) {
            setInputType(i11);
        }
        setFocusable(typedArrayObtainStyledAttributes.getBoolean(1, true));
        fVar.P();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f15526R = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f15527S = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f15517H = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new I(this, 4));
        }
        y(this.f15532a0);
        v();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f15550z;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // p153n.b
    public final void b() {
        if (this.f15543l0) {
            return;
        }
        this.f15543l0 = true;
        SearchAutoComplete searchAutoComplete = this.f15550z;
        int imeOptions = searchAutoComplete.getImeOptions();
        this.f15544m0 = imeOptions;
        searchAutoComplete.setImeOptions(imeOptions | 33554432);
        searchAutoComplete.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.f15538g0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f15550z;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.f15538g0 = false;
    }

    @Override // p153n.b
    public final void e() {
        SearchAutoComplete searchAutoComplete = this.f15550z;
        searchAutoComplete.setText("");
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f15542k0 = "";
        clearFocus();
        y(true);
        searchAutoComplete.setImeOptions(this.f15544m0);
        this.f15543l0 = false;
    }

    public int getImeOptions() {
        return this.f15550z.getImeOptions();
    }

    public int getInputType() {
        return this.f15550z.getInputType();
    }

    public int getMaxWidth() {
        return this.f15539h0;
    }

    public CharSequence getQuery() {
        return this.f15550z.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f15536e0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f15545n0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f15528T : getContext().getText(this.f15545n0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f15525Q;
    }

    public int getSuggestionRowLayout() {
        return this.f15524P;
    }

    public B1.c getSuggestionsAdapter() {
        return this.f15534c0;
    }

    public final Intent l(Uri uri, String str, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f15542k0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f15546o0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f15545n0.getSearchActivity());
        return intent;
    }

    public final Intent m(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f15546o0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void n() {
        int i10 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f15550z;
        if (i10 >= 29) {
            f.a(searchAutoComplete);
            return;
        }
        Va.i iVar = f15509s0;
        iVar.getClass();
        Va.i.a();
        Method method = iVar.f13107a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        iVar.getClass();
        Va.i.a();
        Method method2 = iVar.f13108b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void o() {
        SearchAutoComplete searchAutoComplete = this.f15550z;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText("");
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.f15532a0) {
            clearFocus();
            y(true);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.f15547p0);
        post(this.f15548q0);
        super.onDetachedFromWindow();
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        if (z3) {
            int[] iArr = this.f15521L;
            SearchAutoComplete searchAutoComplete = this.f15550z;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.M;
            getLocationInWindow(iArr2);
            int i14 = iArr[1] - iArr2[1];
            int i15 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i15;
            int height = searchAutoComplete.getHeight() + i14;
            Rect rect = this.f15519J;
            rect.set(i15, i14, width, height);
            int i16 = rect.left;
            int i17 = rect.right;
            int i18 = i13 - i11;
            Rect rect2 = this.f15520K;
            rect2.set(i16, 0, i17, i18);
            D0 d10 = this.f15518I;
            if (d10 == null) {
                D0 d11 = new D0(searchAutoComplete, rect2, rect);
                this.f15518I = d11;
                setTouchDelegate(d11);
            } else {
                d10.f26413b.set(rect2);
                Rect rect3 = d10.f26415d;
                rect3.set(rect2);
                int i19 = -d10.f26416e;
                rect3.inset(i19, i19);
                d10.f26414c.set(rect);
            }
        }
    }

    @Override // androidx.appcompat.widget.LinearLayoutCompat, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f15533b0) {
            super.onMeasure(i10, i11);
            return;
        }
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        if (mode == Integer.MIN_VALUE) {
            int i13 = this.f15539h0;
            size = i13 > 0 ? Math.min(i13, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f15539h0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i12 = this.f15539h0) > 0) {
            size = Math.min(i12, size);
        }
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0 c10 = (C0) parcelable;
        super.onRestoreInstanceState(c10.f2402a);
        y(c10.f26407c);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C0 c10 = new C0(super.onSaveInstanceState());
        c10.f26407c = this.f15533b0;
        return c10;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z3) {
        super.onWindowFocusChanged(z3);
        post(this.f15547p0);
    }

    public final void p(int i10) {
        int position;
        String strH;
        Cursor cursor = this.f15534c0.f856c;
        if (cursor != null && cursor.moveToPosition(i10)) {
            Intent intentL = null;
            try {
                int i11 = F0.f26424H;
                String strH2 = F0.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (strH2 == null) {
                    strH2 = this.f15545n0.getSuggestIntentAction();
                }
                if (strH2 == null) {
                    strH2 = "android.intent.action.SEARCH";
                }
                String strH3 = F0.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (strH3 == null) {
                    strH3 = this.f15545n0.getSuggestIntentData();
                }
                if (strH3 != null && (strH = F0.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                    strH3 = strH3 + "/" + Uri.encode(strH);
                }
                intentL = l(strH3 == null ? null : Uri.parse(strH3), strH2, F0.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), F0.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e10) {
                try {
                    position = cursor.getPosition();
                } catch (RuntimeException unused) {
                    position = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + position + " returned exception.", e10);
            }
            if (intentL != null) {
                try {
                    getContext().startActivity(intentL);
                } catch (RuntimeException e11) {
                    Log.e("SearchView", "Failed launch activity: " + intentL, e11);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f15550z;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void q(int i10) {
        Editable text = this.f15550z.getText();
        Cursor cursor = this.f15534c0.f856c;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i10)) {
            setQuery(text);
            return;
        }
        String strC = this.f15534c0.c(cursor);
        if (strC != null) {
            setQuery(strC);
        } else {
            setQuery(text);
        }
    }

    public final void r(CharSequence charSequence) {
        setQuery(charSequence);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i10, Rect rect) {
        if (this.f15538g0 || !isFocusable()) {
            return false;
        }
        if (this.f15533b0) {
            return super.requestFocus(i10, rect);
        }
        boolean zRequestFocus = this.f15550z.requestFocus(i10, rect);
        if (zRequestFocus) {
            y(false);
        }
        return zRequestFocus;
    }

    public final void s() {
        SearchAutoComplete searchAutoComplete = this.f15550z;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f15529U != null) {
            text.toString();
        }
        if (this.f15545n0 != null) {
            getContext().startActivity(l(null, "android.intent.action.SEARCH", null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public void setAppSearchData(Bundle bundle) {
        this.f15546o0 = bundle;
    }

    public void setIconified(boolean z3) {
        if (z3) {
            o();
            return;
        }
        y(false);
        SearchAutoComplete searchAutoComplete = this.f15550z;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f15531W;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z3) {
        if (this.f15532a0 == z3) {
            return;
        }
        this.f15532a0 = z3;
        y(z3);
        v();
    }

    public void setImeOptions(int i10) {
        this.f15550z.setImeOptions(i10);
    }

    public void setInputType(int i10) {
        this.f15550z.setInputType(i10);
    }

    public void setMaxWidth(int i10) {
        this.f15539h0 = i10;
        requestLayout();
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f15530V = onFocusChangeListener;
    }

    public void setOnQueryTextListener(A0 a3) {
        this.f15529U = a3;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f15531W = onClickListener;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f15536e0 = charSequence;
        v();
    }

    public void setQueryRefinementEnabled(boolean z3) {
        this.f15537f0 = z3;
        B1.c cVar = this.f15534c0;
        if (cVar instanceof F0) {
            ((F0) cVar).f26440z = z3 ? 2 : 1;
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0098  */
    public void setSearchableInfo(SearchableInfo searchableInfo) {
        boolean z3;
        this.f15545n0 = searchableInfo;
        Intent intent = null;
        SearchAutoComplete searchAutoComplete = this.f15550z;
        if (searchableInfo != null) {
            searchAutoComplete.setThreshold(searchableInfo.getSuggestThreshold());
            searchAutoComplete.setImeOptions(this.f15545n0.getImeOptions());
            int inputType = this.f15545n0.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.f15545n0.getSuggestAuthority() != null) {
                    inputType |= 589824;
                }
            }
            searchAutoComplete.setInputType(inputType);
            B1.c cVar = this.f15534c0;
            if (cVar != null) {
                cVar.b(null);
            }
            if (this.f15545n0.getSuggestAuthority() != null) {
                F0 f10 = new F0(getContext(), this, this.f15545n0, this.f15549r0);
                this.f15534c0 = f10;
                searchAutoComplete.setAdapter(f10);
                ((F0) this.f15534c0).f26440z = this.f15537f0 ? 2 : 1;
            }
            v();
        }
        SearchableInfo searchableInfo2 = this.f15545n0;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.f15545n0.getVoiceSearchLaunchWebSearch()) {
                intent = this.f15526R;
            } else if (this.f15545n0.getVoiceSearchLaunchRecognizer()) {
                intent = this.f15527S;
            }
            z3 = (intent == null || getContext().getPackageManager().resolveActivity(intent, 65536) == null) ? false : true;
        }
        this.f15540i0 = z3;
        if (z3) {
            searchAutoComplete.setPrivateImeOptions("nm");
        }
        y(this.f15533b0);
    }

    public void setSubmitButtonEnabled(boolean z3) {
        this.f15535d0 = z3;
        y(this.f15533b0);
    }

    public void setSuggestionsAdapter(B1.c cVar) {
        this.f15534c0 = cVar;
        this.f15550z.setAdapter(cVar);
    }

    public final void t() {
        boolean zIsEmpty = TextUtils.isEmpty(this.f15550z.getText());
        int i10 = (!zIsEmpty || (this.f15532a0 && !this.f15543l0)) ? 0 : 8;
        ImageView imageView = this.f15515F;
        imageView.setVisibility(i10);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(!zIsEmpty ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public final void u() {
        int[] iArr = this.f15550z.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f15511B.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f15512C.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public final void v() {
        Drawable drawable;
        CharSequence queryHint = getQueryHint();
        CharSequence charSequence = queryHint;
        if (queryHint == null) {
            charSequence = "";
        }
        boolean z3 = this.f15532a0;
        SearchAutoComplete searchAutoComplete = this.f15550z;
        CharSequence charSequence2 = charSequence;
        if (z3 && (drawable = this.f15523O) != null) {
            charSequence2 = charSequence;
            int textSize = (int) (((double) searchAutoComplete.getTextSize()) * 1.25d);
            drawable.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
            spannableStringBuilder.append(charSequence);
            charSequence2 = spannableStringBuilder;
        }
        charSequence2 = charSequence;
        searchAutoComplete.setHint(charSequence2);
    }

    public final void w() {
        this.f15512C.setVisibility(((this.f15535d0 || this.f15540i0) && !this.f15533b0 && (this.f15514E.getVisibility() == 0 || this.f15516G.getVisibility() == 0)) ? 0 : 8);
    }

    public final void x(boolean z3) {
        boolean z5 = this.f15535d0;
        this.f15514E.setVisibility((!z5 || !(z5 || this.f15540i0) || this.f15533b0 || !hasFocus() || (!z3 && this.f15540i0)) ? 8 : 0);
    }

    public final void y(boolean z3) {
        this.f15533b0 = z3;
        int i10 = 8;
        int i11 = z3 ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.f15550z.getText());
        this.f15513D.setVisibility(i11);
        x(!zIsEmpty);
        this.f15510A.setVisibility(z3 ? 8 : 0);
        ImageView imageView = this.f15522N;
        imageView.setVisibility((imageView.getDrawable() == null || this.f15532a0) ? 8 : 0);
        t();
        if (this.f15540i0 && !this.f15533b0 && zIsEmpty) {
            this.f15514E.setVisibility(8);
            i10 = 0;
        }
        this.f15516G.setVisibility(i10);
        w();
    }

    public void setOnCloseListener(z0 z0Var) {
    }

    public void setOnSuggestionListener(B0 b10) {
    }
}
