package androidx.appcompat.widget;

import B.P;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p053e3.M;
import p175p.C1359t;
import p175p.C1363v;
import p175p.G;
import p175p.H0;
import p175p.I0;
import p175p.L;
import p175p.N;
import p175p.T;
import p175p.W0;
import p273y1.m;
import p273y1.p;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatTextView extends TextView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15445a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final M f15446b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1363v f15447c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public C1359t f15448d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f15449e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public p088h1.g f15450f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public Future f15451q;

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15448d == null) {
            this.f15448d = new C1359t(this);
        }
        return this.f15448d;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15445a;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    public final void g() {
        Future future = this.f15451q;
        if (future == null) {
            return;
        }
        try {
            this.f15451q = null;
            if (future.get() != null) {
                throw new ClassCastException();
            }
            if (Build.VERSION.SDK_INT >= 29) {
                throw null;
            }
            p195q8.c.p(this);
            throw null;
        } catch (InterruptedException | ExecutionException unused) {
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (W0.f26497c) {
            return super.getAutoSizeMaxTextSize();
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26488e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (W0.f26497c) {
            return super.getAutoSizeMinTextSize();
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26487d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (W0.f26497c) {
            return super.getAutoSizeStepGranularity();
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26486c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (W0.f26497c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        M m2 = this.f15446b;
        return m2 != null ? ((T) m2.f21925l).f26489f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (W0.f26497c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            return ((T) m2.f21925l).f26484a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public L getSuperCaller() {
        if (this.f15450f == null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 34) {
                this.f15450f = new N(this);
            } else if (i10 >= 28) {
                this.f15450f = new p175p.M(this);
            } else if (i10 >= 26) {
                this.f15450f = new p088h1.g(this, 16);
            }
        }
        return this.f15450f;
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15445a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15445a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15446b.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15446b.i();
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        g();
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        C1363v c1363v;
        if (Build.VERSION.SDK_INT >= 28 || (c1363v = this.f15447c) == null) {
            return super.getTextClassifier();
        }
        TextClassifier textClassifier = (TextClassifier) c1363v.f26583c;
        return textClassifier == null ? G.a((TextView) c1363v.f26582b) : textClassifier;
    }

    public p165o1.f getTextMetricsParamsCompat() {
        return p195q8.c.p(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
        this.f15446b.getClass();
        if (Build.VERSION.SDK_INT < 30 && inputConnectionOnCreateInputConnection != null) {
            p252w1.c.a(editorInfo, getText());
        }
        p029c4.a.N0(inputConnectionOnCreateInputConnection, editorInfo, this);
        return inputConnectionOnCreateInputConnection;
    }

    @Override // android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 30 || i10 >= 33 || !onCheckIsTextEditor()) {
            return;
        }
        ((InputMethodManager) getContext().getSystemService("input_method")).isActive(this);
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        M m2 = this.f15446b;
        if (m2 == null || W0.f26497c) {
            return;
        }
        ((T) m2.f21925l).a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i10, int i11) {
        g();
        super.onMeasure(i10, i11);
    }

    @Override // android.widget.TextView
    public final void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        super.onTextChanged(charSequence, i10, i11, i12);
        M m2 = this.f15446b;
        if (m2 == null || W0.f26497c) {
            return;
        }
        T t10 = (T) m2.f21925l;
        if (t10.f()) {
            t10.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i10, int i11, int i12, int i13) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i10, i11, i12, i13);
            return;
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.n(i10, i11, i12, i13);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i10) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i10);
            return;
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.o(iArr, i10);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i10) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeWithDefaults(i10);
            return;
        }
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.p(i10);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15445a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15445a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i10) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().j(i10);
        } else {
            p195q8.c.u(this, i10);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i10) {
        if (Build.VERSION.SDK_INT >= 28) {
            getSuperCaller().d(i10);
        } else {
            p195q8.c.v(this, i10);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i10) {
        p195q8.c.w(this, i10);
    }

    public void setPrecomputedText(p165o1.g gVar) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        p195q8.c.p(this);
        throw null;
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15445a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15445a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15446b;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15446b;
        m2.r(mode);
        m2.d();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.m(context, i10);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        C1363v c1363v;
        if (Build.VERSION.SDK_INT >= 28 || (c1363v = this.f15447c) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            c1363v.f26583c = textClassifier;
        }
    }

    public void setTextFuture(Future<p165o1.g> future) {
        this.f15451q = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(p165o1.f fVar) {
        TextDirectionHeuristic textDirectionHeuristic;
        TextDirectionHeuristic textDirectionHeuristic2 = fVar.f26216b;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        int i10 = 1;
        if (textDirectionHeuristic2 != textDirectionHeuristic3 && textDirectionHeuristic2 != (textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic2 == TextDirectionHeuristics.ANYRTL_LTR) {
                i10 = 2;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LTR) {
                i10 = 3;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.RTL) {
                i10 = 4;
            } else if (textDirectionHeuristic2 == TextDirectionHeuristics.LOCALE) {
                i10 = 5;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic) {
                i10 = 6;
            } else if (textDirectionHeuristic2 == textDirectionHeuristic3) {
                i10 = 7;
            }
        }
        setTextDirection(i10);
        getPaint().set(fVar.f26215a);
        m.e(this, fVar.f26217c);
        m.h(this, fVar.f26218d);
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i10, float f10) {
        boolean z3 = W0.f26497c;
        if (z3) {
            super.setTextSize(i10, f10);
            return;
        }
        M m2 = this.f15446b;
        if (m2 == null || z3) {
            return;
        }
        T t10 = (T) m2.f21925l;
        if (t10.f()) {
            return;
        }
        t10.g(i10, f10);
    }

    @Override // android.widget.TextView
    public final void setTypeface(Typeface typeface, int i10) {
        Typeface typefaceCreate;
        if (this.f15449e) {
            return;
        }
        if (typeface == null || i10 <= 0) {
            typefaceCreate = null;
        } else {
            Context context = getContext();
            p123ja.a aVar = p088h1.h.f23034a;
            if (context == null) {
                throw new IllegalArgumentException("Context cannot be null");
            }
            typefaceCreate = Typeface.create(typeface, i10);
        }
        this.f15449e = true;
        if (typefaceCreate != null) {
            typeface = typefaceCreate;
        }
        try {
            super.setTypeface(typeface, i10);
        } finally {
            this.f15449e = false;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        I0.a(context);
        this.f15449e = false;
        this.f15450f = null;
        H0.a(this, getContext());
        P p10 = new P(this);
        this.f15445a = p10;
        p10.o(attributeSet, i10);
        M m2 = new M(this);
        this.f15446b = m2;
        m2.l(attributeSet, i10);
        m2.d();
        C1363v c1363v = new C1363v();
        c1363v.f26582b = this;
        this.f15447c = c1363v;
        getEmojiTextViewHelper().b(attributeSet, i10);
    }

    @Override // android.widget.TextView
    public final void setLineHeight(int i10, float f10) {
        int i11 = Build.VERSION.SDK_INT;
        if (i11 >= 34) {
            getSuperCaller().o(i10, f10);
        } else if (i11 >= 34) {
            p.a(this, i10, f10);
        } else {
            p195q8.c.w(this, Math.round(TypedValue.applyDimension(i10, f10, getResources().getDisplayMetrics())));
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelativeWithIntrinsicBounds(int i10, int i11, int i12, int i13) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i10 != 0 ? p143m0.c.N(context, i10) : null, i11 != 0 ? p143m0.c.N(context, i11) : null, i12 != 0 ? p143m0.c.N(context, i12) : null, i13 != 0 ? p143m0.c.N(context, i13) : null);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesWithIntrinsicBounds(int i10, int i11, int i12, int i13) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i10 != 0 ? p143m0.c.N(context, i10) : null, i11 != 0 ? p143m0.c.N(context, i11) : null, i12 != 0 ? p143m0.c.N(context, i12) : null, i13 != 0 ? p143m0.c.N(context, i13) : null);
        M m2 = this.f15446b;
        if (m2 != null) {
            m2.d();
        }
    }
}
