package androidx.appcompat.widget;

import L.C0499e0;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import com.flamingotools.ws.R;
import java.util.WeakHashMap;
import p153n.j;
import p164o.l;
import p164o.w;
import p175p.C1328d;
import p175p.InterfaceC1326c;
import p175p.RunnableC1324b;
import p175p.V;
import p175p.W;
import p200r1.A0;
import p200r1.F;
import p200r1.H;
import p200r1.InterfaceC1489p;
import p200r1.InterfaceC1490q;
import p200r1.U;
import p200r1.o0;
import p200r1.p0;
import p200r1.q0;
import p200r1.r0;
import p200r1.y0;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements V, InterfaceC1489p, InterfaceC1490q {
    public static final int[] M = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public static final A0 f15339N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public static final Rect f15340O;

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public A0 f15341A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public A0 f15342B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public A0 f15343C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public A0 f15344D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public InterfaceC1326c f15345E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public OverScroller f15346F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public ViewPropertyAnimator f15347G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final E4.a f15348H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final RunnableC1324b f15349I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public final RunnableC1324b f15350J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public final C0499e0 f15351K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public final C1328d f15352L;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f15353a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f15354b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f15355c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ActionBarContainer f15356d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public W f15357e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f15358f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f15359q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f15360r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f15361s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f15362t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f15363u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15364v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public final Rect f15365w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Rect f15366x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final Rect f15367y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final Rect f15368z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    static {
        r0 p0Var;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 30) {
            p0Var = new q0();
        } else {
            p0Var = i10 >= 29 ? new p0() : new o0();
        }
        p0Var.g(p088h1.c.b(0, 1, 0, 1));
        f15339N = p0Var.b();
        f15340O = new Rect();
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f15354b = 0;
        this.f15365w = new Rect();
        this.f15366x = new Rect();
        this.f15367y = new Rect();
        this.f15368z = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        A0 a3 = A0.f27660b;
        this.f15341A = a3;
        this.f15342B = a3;
        this.f15343C = a3;
        this.f15344D = a3;
        this.f15348H = new E4.a(this, 12);
        this.f15349I = new RunnableC1324b(this, 0);
        this.f15350J = new RunnableC1324b(this, 1);
        f(context);
        this.f15351K = new C0499e0();
        C1328d c1328d = new C1328d(context);
        c1328d.setWillNotDraw(true);
        this.f15352L = c1328d;
        addView(c1328d);
    }

    public static boolean d(View view, Rect rect, boolean z3) {
        boolean z5;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i10 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
        int i11 = rect.left;
        if (i10 != i11) {
            ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = i11;
            z5 = true;
        } else {
            z5 = false;
        }
        int i12 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
        int i13 = rect.top;
        if (i12 != i13) {
            ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = i13;
            z5 = true;
        }
        int i14 = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        int i15 = rect.right;
        if (i14 != i15) {
            ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = i15;
            z5 = true;
        }
        if (z3) {
            int i16 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
            int i17 = rect.bottom;
            if (i16 != i17) {
                ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = i17;
                return true;
            }
        }
        return z5;
    }

    @Override // p200r1.InterfaceC1489p
    public final void a(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            onNestedScrollAccepted(view, view2, i10);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void b(View view, int i10) {
        if (i10 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f15358f != null) {
            if (this.f15356d.getVisibility() == 0) {
                translationY = (int) (this.f15356d.getTranslationY() + this.f15356d.getBottom() + 0.5f);
            } else {
                translationY = 0;
            }
            this.f15358f.setBounds(0, translationY, getWidth(), this.f15358f.getIntrinsicHeight() + translationY);
            this.f15358f.draw(canvas);
        }
    }

    public final void e() {
        removeCallbacks(this.f15349I);
        removeCallbacks(this.f15350J);
        ViewPropertyAnimator viewPropertyAnimator = this.f15347G;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void f(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(M);
        this.f15353a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f15358f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f15346F = new OverScroller(context);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // p200r1.InterfaceC1490q
    public final void g(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        i(view, i10, i11, i12, i13, i14);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f15356d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0499e0 c0499e0 = this.f15351K;
        return c0499e0.f7842b | c0499e0.f7841a;
    }

    public CharSequence getTitle() {
        k();
        return ((i) this.f15357e).f15672a.getTitle();
    }

    public final void h(int i10) {
        k();
        if (i10 == 2) {
            ((i) this.f15357e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i10 == 5) {
            ((i) this.f15357e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else {
            if (i10 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final void i(View view, int i10, int i11, int i12, int i13, int i14) {
        if (i14 == 0) {
            onNestedScroll(view, i10, i11, i12, i13);
        }
    }

    @Override // p200r1.InterfaceC1489p
    public final boolean j(View view, View view2, int i10, int i11) {
        return i11 == 0 && onStartNestedScroll(view, view2, i10);
    }

    public final void k() {
        W wrapper;
        if (this.f15355c == null) {
            this.f15355c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.f15356d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof W) {
                wrapper = (W) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f15357e = wrapper;
        }
    }

    public final void l(l lVar, w wVar) {
        k();
        i iVar = (i) this.f15357e;
        a aVar = iVar.f15683m;
        Toolbar toolbar = iVar.f15672a;
        if (aVar == null) {
            a aVar2 = new a(toolbar.getContext());
            iVar.f15683m = aVar2;
            aVar2.f25982s = R.id.action_menu_presenter;
        }
        a aVar3 = iVar.f15683m;
        aVar3.f25978e = wVar;
        if (lVar == null && toolbar.f15621a == null) {
            return;
        }
        toolbar.f();
        l lVar2 = toolbar.f15621a.f15380z;
        if (lVar2 == lVar) {
            return;
        }
        if (lVar2 != null) {
            lVar2.r(toolbar.f15619V);
            lVar2.r(toolbar.f15620W);
        }
        if (toolbar.f15620W == null) {
            toolbar.f15620W = new h(toolbar);
        }
        aVar3.f15650B = true;
        if (lVar != null) {
            lVar.b(aVar3, toolbar.f15637t);
            lVar.b(toolbar.f15620W, toolbar.f15637t);
        } else {
            aVar3.i(toolbar.f15637t, null);
            toolbar.f15620W.i(toolbar.f15637t, null);
            aVar3.e(true);
            toolbar.f15620W.e(true);
        }
        toolbar.f15621a.setPopupTheme(toolbar.f15638u);
        toolbar.f15621a.setPresenter(aVar3);
        toolbar.f15619V = aVar3;
        toolbar.w();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        A0 a0H = A0.h(this, windowInsets);
        boolean zD = d(this.f15356d, new Rect(a0H.b(), a0H.d(), a0H.c(), a0H.a()), false);
        WeakHashMap weakHashMap = U.f27683a;
        Rect rect = this.f15365w;
        H.b(this, a0H, rect);
        int i10 = rect.left;
        int i11 = rect.top;
        int i12 = rect.right;
        int i13 = rect.bottom;
        y0 y0Var = a0H.f27661a;
        A0 a0M = y0Var.m(i10, i11, i12, i13);
        this.f15341A = a0M;
        boolean z3 = true;
        if (!this.f15342B.equals(a0M)) {
            this.f15342B = this.f15341A;
            zD = true;
        }
        Rect rect2 = this.f15366x;
        if (rect2.equals(rect)) {
            z3 = zD;
        } else {
            rect2.set(rect);
        }
        if (z3) {
            requestLayout();
        }
        return y0Var.a().f27661a.c().f27661a.b().g();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        f(getContext());
        WeakHashMap weakHashMap = U.f27683a;
        F.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i15 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + paddingLeft;
                int i16 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + paddingTop;
                childAt.layout(i15, i16, measuredWidth + i15, measuredHeight + i16);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:22:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:24:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:25:0x00d5  */
    /* JADX WARN: Code duplicated, block: B:27:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:28:0x00df  */
    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        int measuredHeight;
        A0 a3;
        int i12;
        r0 o0Var;
        k();
        measureChildWithMargins(this.f15356d, i10, 0, i11, 0);
        LayoutParams layoutParams = (LayoutParams) this.f15356d.getLayoutParams();
        int iMax = Math.max(0, this.f15356d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin);
        int iMax2 = Math.max(0, this.f15356d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f15356d.getMeasuredState());
        WeakHashMap weakHashMap = U.f27683a;
        boolean z3 = (getWindowSystemUiVisibility() & 256) != 0;
        if (z3) {
            measuredHeight = this.f15353a;
            if (this.f15360r && this.f15356d.getTabContainer() != null) {
                measuredHeight += this.f15353a;
            }
        } else {
            measuredHeight = this.f15356d.getVisibility() != 8 ? this.f15356d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f15365w;
        Rect rect2 = this.f15367y;
        rect2.set(rect);
        this.f15343C = this.f15341A;
        if (this.f15359q || z3) {
            p088h1.c cVarB = p088h1.c.b(this.f15343C.b(), this.f15343C.d() + measuredHeight, this.f15343C.c(), this.f15343C.a());
            a3 = this.f15343C;
            i12 = Build.VERSION.SDK_INT;
            if (i12 >= 30) {
                o0Var = new q0(a3);
            } else if (i12 >= 29) {
                o0Var = new p0(a3);
            } else {
                o0Var = new o0(a3);
            }
            o0Var.g(cVarB);
            this.f15343C = o0Var.b();
        } else {
            C1328d c1328d = this.f15352L;
            A0 a9 = f15339N;
            Rect rect3 = this.f15368z;
            H.b(c1328d, a9, rect3);
            if (rect3.equals(f15340O)) {
                p088h1.c cVarB2 = p088h1.c.b(this.f15343C.b(), this.f15343C.d() + measuredHeight, this.f15343C.c(), this.f15343C.a());
                a3 = this.f15343C;
                i12 = Build.VERSION.SDK_INT;
                if (i12 >= 30) {
                    o0Var = new q0(a3);
                } else if (i12 >= 29) {
                    o0Var = new p0(a3);
                } else {
                    o0Var = new o0(a3);
                }
                o0Var.g(cVarB2);
                this.f15343C = o0Var.b();
            } else {
                rect2.top += measuredHeight;
                rect2.bottom = rect2.bottom;
                this.f15343C = this.f15343C.f27661a.m(0, measuredHeight, 0, 0);
            }
        }
        d(this.f15355c, rect2, true);
        if (!this.f15344D.equals(this.f15343C)) {
            A0 a10 = this.f15343C;
            this.f15344D = a10;
            U.c(this.f15355c, a10);
        }
        measureChildWithMargins(this.f15355c, i10, 0, i11, 0);
        LayoutParams layoutParams2 = (LayoutParams) this.f15355c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f15355c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f15355c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f15355c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i10, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i11, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        if (!this.f15361s || !z3) {
            return false;
        }
        this.f15346F.fling(0, 0, 0, (int) f11, 0, 0, Integer.MIN_VALUE, com.google.android.gms.common.api.f.API_PRIORITY_OTHER);
        if (this.f15346F.getFinalY() > this.f15356d.getHeight()) {
            e();
            this.f15350J.run();
        } else {
            e();
            this.f15349I.run();
        }
        this.f15362t = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        int i14 = this.f15363u + i11;
        this.f15363u = i14;
        setActionBarHideOffset(i14);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        p112j.H h10;
        j jVar;
        this.f15351K.f7841a = i10;
        this.f15363u = getActionBarHideOffset();
        e();
        InterfaceC1326c interfaceC1326c = this.f15345E;
        if (interfaceC1326c == null || (jVar = (h10 = (p112j.H) interfaceC1326c).f23771v) == null) {
            return;
        }
        jVar.a();
        h10.f23771v = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        if ((i10 & 2) == 0 || this.f15356d.getVisibility() != 0) {
            return false;
        }
        return this.f15361s;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f15361s || this.f15362t) {
            return;
        }
        if (this.f15363u <= this.f15356d.getHeight()) {
            e();
            postDelayed(this.f15349I, 600L);
        } else {
            e();
            postDelayed(this.f15350J, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i10) {
        super.onWindowSystemUiVisibilityChanged(i10);
        k();
        int i11 = this.f15364v ^ i10;
        this.f15364v = i10;
        boolean z3 = (i10 & 4) == 0;
        boolean z5 = (i10 & 256) != 0;
        InterfaceC1326c interfaceC1326c = this.f15345E;
        if (interfaceC1326c != null) {
            p112j.H h10 = (p112j.H) interfaceC1326c;
            h10.f23767r = !z5;
            if (z3 || !z5) {
                if (h10.f23768s) {
                    h10.f23768s = false;
                    h10.m1(true);
                }
            } else if (!h10.f23768s) {
                h10.f23768s = true;
                h10.m1(true);
            }
        }
        if ((i11 & 256) == 0 || this.f15345E == null) {
            return;
        }
        WeakHashMap weakHashMap = U.f27683a;
        F.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i10) {
        super.onWindowVisibilityChanged(i10);
        this.f15354b = i10;
        InterfaceC1326c interfaceC1326c = this.f15345E;
        if (interfaceC1326c != null) {
            ((p112j.H) interfaceC1326c).f23766q = i10;
        }
    }

    public void setActionBarHideOffset(int i10) {
        e();
        this.f15356d.setTranslationY(-Math.max(0, Math.min(i10, this.f15356d.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC1326c interfaceC1326c) {
        this.f15345E = interfaceC1326c;
        if (getWindowToken() != null) {
            ((p112j.H) this.f15345E).f23766q = this.f15354b;
            int i10 = this.f15364v;
            if (i10 != 0) {
                onWindowSystemUiVisibilityChanged(i10);
                WeakHashMap weakHashMap = U.f27683a;
                F.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z3) {
        this.f15360r = z3;
    }

    public void setHideOnContentScrollEnabled(boolean z3) {
        if (z3 != this.f15361s) {
            this.f15361s = z3;
            if (z3) {
                return;
            }
            e();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i10) {
        k();
        i iVar = (i) this.f15357e;
        iVar.f15675d = i10 != 0 ? p143m0.c.N(iVar.f15672a.getContext(), i10) : null;
        iVar.d();
    }

    public void setLogo(int i10) {
        k();
        i iVar = (i) this.f15357e;
        iVar.f15676e = i10 != 0 ? p143m0.c.N(iVar.f15672a.getContext(), i10) : null;
        iVar.d();
    }

    public void setOverlayMode(boolean z3) {
        this.f15359q = z3;
    }

    public void setShowingForActionMode(boolean z3) {
    }

    public void setUiOptions(int i10) {
    }

    @Override // p175p.V
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((i) this.f15357e).k = callback;
    }

    @Override // p175p.V
    public void setWindowTitle(CharSequence charSequence) {
        k();
        i iVar = (i) this.f15357e;
        if (iVar.f15678g) {
            return;
        }
        iVar.f15679h = charSequence;
        if ((iVar.f15673b & 8) != 0) {
            Toolbar toolbar = iVar.f15672a;
            toolbar.setTitle(charSequence);
            if (iVar.f15678g) {
                U.r(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        i iVar = (i) this.f15357e;
        iVar.f15675d = drawable;
        iVar.d();
    }

    @Override // p200r1.InterfaceC1489p
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
    }
}
