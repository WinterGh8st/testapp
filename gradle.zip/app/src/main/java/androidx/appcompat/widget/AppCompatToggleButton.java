package androidx.appcompat.widget;

import B.P;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.widget.ToggleButton;
import p053e3.M;
import p175p.C1359t;
import p175p.H0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatToggleButton extends ToggleButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15452a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final M f15453b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C1359t f15454c;

    public AppCompatToggleButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, R.attr.buttonStyleToggle);
        H0.a(this, getContext());
        P p10 = new P(this);
        this.f15452a = p10;
        p10.o(attributeSet, R.attr.buttonStyleToggle);
        M m2 = new M(this);
        this.f15453b = m2;
        m2.l(attributeSet, R.attr.buttonStyleToggle);
        getEmojiTextViewHelper().b(attributeSet, R.attr.buttonStyleToggle);
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15454c == null) {
            this.f15454c = new C1359t(this);
        }
        return this.f15454c;
    }

    @Override // android.widget.ToggleButton, android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15452a;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15453b;
        if (m2 != null) {
            m2.d();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15452a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15452a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15453b.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15453b.i();
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.widget.ToggleButton, android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15452a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15452a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15453b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public final void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        M m2 = this.f15453b;
        if (m2 != null) {
            m2.d();
        }
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15452a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15452a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15453b;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15453b;
        m2.r(mode);
        m2.d();
    }
}
