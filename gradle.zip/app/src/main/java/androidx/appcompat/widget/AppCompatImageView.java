package androidx.appcompat.widget;

import B.P;
import B2.q;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;
import p175p.H0;
import p175p.I0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatImageView extends ImageView {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15423a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final q f15424b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f15425c;

    public AppCompatImageView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    @Override // android.widget.ImageView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15423a;
        if (p10 != null) {
            p10.a();
        }
        q qVar = this.f15424b;
        if (qVar != null) {
            qVar.c();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15423a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15423a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        J9.b bVar;
        q qVar = this.f15424b;
        if (qVar == null || (bVar = (J9.b) qVar.f990d) == null) {
            return null;
        }
        return (ColorStateList) bVar.f6549b;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        J9.b bVar;
        q qVar = this.f15424b;
        if (qVar == null || (bVar = (J9.b) qVar.f990d) == null) {
            return null;
        }
        return (PorterDuff.Mode) bVar.f6550c;
    }

    @Override // android.widget.ImageView, android.view.View
    public final boolean hasOverlappingRendering() {
        return !(((ImageView) this.f15424b.f989c).getBackground() instanceof RippleDrawable) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15423a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15423a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        q qVar = this.f15424b;
        if (qVar != null) {
            qVar.c();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        q qVar = this.f15424b;
        if (qVar != null && drawable != null && !this.f15425c) {
            qVar.f988b = drawable.getLevel();
        }
        super.setImageDrawable(drawable);
        if (qVar != null) {
            qVar.c();
            if (this.f15425c) {
                return;
            }
            ImageView imageView = (ImageView) qVar.f989c;
            if (imageView.getDrawable() != null) {
                imageView.getDrawable().setLevel(qVar.f988b);
            }
        }
    }

    @Override // android.widget.ImageView
    public void setImageLevel(int i10) {
        super.setImageLevel(i10);
        this.f15425c = true;
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i10) {
        q qVar = this.f15424b;
        if (qVar != null) {
            qVar.x(i10);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        q qVar = this.f15424b;
        if (qVar != null) {
            qVar.c();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15423a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15423a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        q qVar = this.f15424b;
        if (qVar != null) {
            if (((J9.b) qVar.f990d) == null) {
                qVar.f990d = new J9.b();
            }
            J9.b bVar = (J9.b) qVar.f990d;
            bVar.f6549b = colorStateList;
            bVar.f6551d = true;
            qVar.c();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        q qVar = this.f15424b;
        if (qVar != null) {
            if (((J9.b) qVar.f990d) == null) {
                qVar.f990d = new J9.b();
            }
            J9.b bVar = (J9.b) qVar.f990d;
            bVar.f6550c = mode;
            bVar.f6548a = true;
            qVar.c();
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatImageView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        I0.a(context);
        this.f15425c = false;
        H0.a(this, getContext());
        P p10 = new P(this);
        this.f15423a = p10;
        p10.o(attributeSet, i10);
        q qVar = new q(this);
        this.f15424b = qVar;
        qVar.p(attributeSet, i10);
    }
}
