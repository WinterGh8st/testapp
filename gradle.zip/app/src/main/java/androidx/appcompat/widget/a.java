package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import com.flamingotools.ws.R;
import java.util.ArrayList;
import p164o.AbstractC1311d;
import p164o.D;
import p164o.l;
import p164o.n;
import p164o.t;
import p164o.w;
import p164o.y;
import p175p.C1330e;
import p175p.C1332f;
import p175p.C1336h;
import p175p.C1338i;
import p175p.RunnableC1334g;
import p200r1.AbstractC1473c;

/* JADX INFO: loaded from: classes.dex */
public final class a extends AbstractC1311d {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f15649A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public boolean f15650B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public final SparseBooleanArray f15651C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public C1330e f15652D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public C1330e f15653E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public RunnableC1334g f15654F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public C1332f f15655G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final p088h1.g f15656H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public int f15657I;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public C1336h f15658t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public Drawable f15659u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f15660v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f15661w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f15662x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public int f15663y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f15664z;

    public a(Context context) {
        this.f25974a = context;
        this.f25977d = LayoutInflater.from(context);
        this.f25979f = R.layout.abc_action_menu_layout;
        this.f25980q = R.layout.abc_action_menu_item_layout;
        this.f15651C = new SparseBooleanArray();
        this.f15656H = new p088h1.g(this, 15);
    }

    @Override // p164o.x
    public final void a(l lVar, boolean z3) {
        c();
        C1330e c1330e = this.f15653E;
        if (c1330e != null && c1330e.b()) {
            c1330e.f26101i.dismiss();
        }
        w wVar = this.f25978e;
        if (wVar != null) {
            wVar.a(lVar, z3);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final View b(n nVar, View view, ViewGroup viewGroup) {
        y yVar;
        View actionView = nVar.getActionView();
        if (actionView == null || nVar.e()) {
            if (view instanceof y) {
                yVar = (y) view;
            } else {
                yVar = (y) this.f25977d.inflate(this.f25980q, viewGroup, false);
            }
            yVar.a(nVar);
            ActionMenuItemView actionMenuItemView = (ActionMenuItemView) yVar;
            actionMenuItemView.setItemInvoker((ActionMenuView) this.f25981r);
            if (this.f15655G == null) {
                this.f15655G = new C1332f(this);
            }
            actionMenuItemView.setPopupCallback(this.f15655G);
            actionView = (View) yVar;
        }
        actionView.setVisibility(nVar.M ? 8 : 0);
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        ((ActionMenuView) viewGroup).getClass();
        if (!(layoutParams instanceof ActionMenuView.LayoutParams)) {
            actionView.setLayoutParams(ActionMenuView.m(layoutParams));
        }
        return actionView;
    }

    public final boolean c() {
        Object obj;
        RunnableC1334g runnableC1334g = this.f15654F;
        if (runnableC1334g != null && (obj = this.f25981r) != null) {
            ((View) obj).removeCallbacks(runnableC1334g);
            this.f15654F = null;
            return true;
        }
        C1330e c1330e = this.f15652D;
        if (c1330e == null) {
            return false;
        }
        if (c1330e.b()) {
            c1330e.f26101i.dismiss();
        }
        return true;
    }

    @Override // p164o.x
    public final void d(Parcelable parcelable) {
        int i10;
        MenuItem menuItemFindItem;
        if ((parcelable instanceof C1338i) && (i10 = ((C1338i) parcelable).f26537a) > 0 && (menuItemFindItem = this.f25976c.findItem(i10)) != null) {
            l((D) menuItemFindItem.getSubMenu());
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // p164o.x
    public final void e(boolean z3) {
        int i10;
        ViewGroup viewGroup = (ViewGroup) this.f25981r;
        ArrayList arrayList = null;
        boolean z5 = false;
        if (viewGroup != null) {
            l lVar = this.f25976c;
            if (lVar != null) {
                lVar.i();
                ArrayList arrayListL = this.f25976c.l();
                int size = arrayListL.size();
                i10 = 0;
                for (int i11 = 0; i11 < size; i11++) {
                    n nVar = (n) arrayListL.get(i11);
                    if ((nVar.f26060H & 32) == 32) {
                        View childAt = viewGroup.getChildAt(i10);
                        n itemData = childAt instanceof y ? ((y) childAt).getItemData() : null;
                        View viewB = b(nVar, childAt, viewGroup);
                        if (nVar != itemData) {
                            viewB.setPressed(false);
                            viewB.jumpDrawablesToCurrentState();
                        }
                        if (viewB != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) viewB.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(viewB);
                            }
                            ((ViewGroup) this.f25981r).addView(viewB, i10);
                        }
                        i10++;
                    }
                }
            } else {
                i10 = 0;
            }
            while (i10 < viewGroup.getChildCount()) {
                if (viewGroup.getChildAt(i10) == this.f15658t) {
                    i10++;
                } else {
                    viewGroup.removeViewAt(i10);
                }
            }
        }
        ((View) this.f25981r).requestLayout();
        l lVar2 = this.f25976c;
        if (lVar2 != null) {
            lVar2.i();
            ArrayList arrayList2 = lVar2.f26042s;
            int size2 = arrayList2.size();
            for (int i12 = 0; i12 < size2; i12++) {
                AbstractC1473c abstractC1473c = ((n) arrayList2.get(i12)).f26063K;
                if (abstractC1473c != null) {
                    abstractC1473c.f27698a = this;
                }
            }
        }
        l lVar3 = this.f25976c;
        if (lVar3 != null) {
            lVar3.i();
            arrayList = lVar3.f26043t;
        }
        if (this.f15661w && arrayList != null) {
            int size3 = arrayList.size();
            if (size3 == 1) {
                z5 = !((n) arrayList.get(0)).M;
            } else if (size3 > 0) {
                z5 = true;
            }
        }
        if (z5) {
            if (this.f15658t == null) {
                this.f15658t = new C1336h(this, this.f25974a);
            }
            ViewGroup viewGroup3 = (ViewGroup) this.f15658t.getParent();
            if (viewGroup3 != this.f25981r) {
                if (viewGroup3 != null) {
                    viewGroup3.removeView(this.f15658t);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f25981r;
                C1336h c1336h = this.f15658t;
                actionMenuView.getClass();
                ActionMenuView.LayoutParams layoutParamsL = ActionMenuView.l();
                layoutParamsL.f15381a = true;
                actionMenuView.addView(c1336h, layoutParamsL);
            }
        } else {
            C1336h c1336h2 = this.f15658t;
            if (c1336h2 != null) {
                Object parent = c1336h2.getParent();
                Object obj = this.f25981r;
                if (parent == obj) {
                    ((ViewGroup) obj).removeView(this.f15658t);
                }
            }
        }
        ((ActionMenuView) this.f25981r).setOverflowReserved(this.f15661w);
    }

    public final boolean f() {
        C1330e c1330e = this.f15652D;
        return c1330e != null && c1330e.b();
    }

    @Override // p164o.x
    public final void i(Context context, l lVar) {
        this.f25975b = context;
        LayoutInflater.from(context);
        this.f25976c = lVar;
        Resources resources = context.getResources();
        if (!this.f15662x) {
            this.f15661w = true;
        }
        int i10 = 2;
        this.f15663y = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i11 = configuration.screenWidthDp;
        int i12 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i11 > 600 || ((i11 > 960 && i12 > 720) || (i11 > 720 && i12 > 960))) {
            i10 = 5;
        } else if (i11 >= 500 || ((i11 > 640 && i12 > 480) || (i11 > 480 && i12 > 640))) {
            i10 = 4;
        } else if (i11 >= 360) {
            i10 = 3;
        }
        this.f15649A = i10;
        int measuredWidth = this.f15663y;
        if (this.f15661w) {
            if (this.f15658t == null) {
                C1336h c1336h = new C1336h(this, this.f25974a);
                this.f15658t = c1336h;
                if (this.f15660v) {
                    c1336h.setImageDrawable(this.f15659u);
                    this.f15659u = null;
                    this.f15660v = false;
                }
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f15658t.measure(iMakeMeasureSpec, iMakeMeasureSpec);
            }
            measuredWidth -= this.f15658t.getMeasuredWidth();
        } else {
            this.f15658t = null;
        }
        this.f15664z = measuredWidth;
        float f10 = resources.getDisplayMetrics().density;
    }

    @Override // p164o.x
    public final boolean j() {
        int size;
        ArrayList arrayListL;
        int i10;
        boolean z3;
        a aVar = this;
        l lVar = aVar.f25976c;
        if (lVar != null) {
            arrayListL = lVar.l();
            size = arrayListL.size();
        } else {
            size = 0;
            arrayListL = null;
        }
        int i11 = aVar.f15649A;
        int i12 = aVar.f15664z;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) aVar.f25981r;
        int i13 = 0;
        boolean z5 = false;
        int i14 = 0;
        int i15 = 0;
        while (true) {
            i10 = 2;
            z3 = true;
            if (i13 >= size) {
                break;
            }
            n nVar = (n) arrayListL.get(i13);
            int i16 = nVar.f26061I;
            if ((i16 & 2) == 2) {
                i14++;
            } else if ((i16 & 1) == 1) {
                i15++;
            } else {
                z5 = true;
            }
            if (aVar.f15650B && nVar.M) {
                i11 = 0;
            }
            i13++;
        }
        if (aVar.f15661w && (z5 || i15 + i14 > i11)) {
            i11--;
        }
        int i17 = i11 - i14;
        SparseBooleanArray sparseBooleanArray = aVar.f15651C;
        sparseBooleanArray.clear();
        int i18 = 0;
        int i19 = 0;
        while (i18 < size) {
            n nVar2 = (n) arrayListL.get(i18);
            int i20 = nVar2.f26061I;
            boolean z10 = (i20 & 2) == i10 ? z3 : false;
            int i21 = nVar2.f26066b;
            if (z10) {
                View viewB = aVar.b(nVar2, null, viewGroup);
                viewB.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                int measuredWidth = viewB.getMeasuredWidth();
                i12 -= measuredWidth;
                if (i19 == 0) {
                    i19 = measuredWidth;
                }
                if (i21 != 0) {
                    sparseBooleanArray.put(i21, z3);
                }
                nVar2.g(z3);
            } else {
                if ((i20 & 1) == z3) {
                    boolean z11 = sparseBooleanArray.get(i21);
                    boolean z12 = ((i17 > 0 || z11) && i12 > 0) ? z3 : false;
                    if (z12) {
                        View viewB2 = aVar.b(nVar2, null, viewGroup);
                        viewB2.measure(iMakeMeasureSpec, iMakeMeasureSpec);
                        int measuredWidth2 = viewB2.getMeasuredWidth();
                        i12 -= measuredWidth2;
                        if (i19 == 0) {
                            i19 = measuredWidth2;
                        }
                        z12 &= i12 + i19 > 0;
                    }
                    if (z12 && i21 != 0) {
                        sparseBooleanArray.put(i21, true);
                    } else if (z11) {
                        sparseBooleanArray.put(i21, false);
                        for (int i22 = 0; i22 < i18; i22++) {
                            n nVar3 = (n) arrayListL.get(i22);
                            if (nVar3.f26066b == i21) {
                                if ((nVar3.f26060H & 32) == 32) {
                                    i17++;
                                }
                                nVar3.g(false);
                            }
                        }
                    }
                    if (z12) {
                        i17--;
                    }
                    nVar2.g(z12);
                } else {
                    nVar2.g(false);
                }
                i18++;
                i10 = 2;
                aVar = this;
                z3 = true;
            }
            i18++;
            i10 = 2;
            aVar = this;
            z3 = true;
        }
        return z3;
    }

    @Override // p164o.x
    public final Parcelable k() {
        C1338i c1338i = new C1338i();
        c1338i.f26537a = this.f15657I;
        return c1338i;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // p164o.x
    public final boolean l(D d10) {
        boolean z3;
        if (d10.hasVisibleItems()) {
            D d11 = d10;
            while (true) {
                l lVar = d11.f25954J;
                if (lVar == this.f25976c) {
                    break;
                }
                d11 = (D) lVar;
            }
            ViewGroup viewGroup = (ViewGroup) this.f25981r;
            View view = null;
            view = null;
            if (viewGroup != null) {
                int childCount = viewGroup.getChildCount();
                for (int i10 = 0; i10 < childCount; i10++) {
                    View childAt = viewGroup.getChildAt(i10);
                    if ((childAt instanceof y) && ((y) childAt).getItemData() == d11.f25955K) {
                        view = childAt;
                        break;
                    }
                }
            }
            if (view != null) {
                this.f15657I = d10.f25955K.f26065a;
                int size = d10.f26039f.size();
                int i11 = 0;
                while (true) {
                    if (i11 >= size) {
                        z3 = false;
                        break;
                    }
                    MenuItem item = d10.getItem(i11);
                    if (item.isVisible() && item.getIcon() != null) {
                        z3 = true;
                        break;
                    }
                    i11++;
                }
                C1330e c1330e = new C1330e(this, this.f25975b, d10, view);
                this.f15653E = c1330e;
                c1330e.f26099g = z3;
                t tVar = c1330e.f26101i;
                if (tVar != null) {
                    tVar.q(z3);
                }
                C1330e c1330e2 = this.f15653E;
                if (!c1330e2.b()) {
                    if (c1330e2.f26097e == null) {
                        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
                    }
                    c1330e2.d(0, 0, false, false);
                }
                w wVar = this.f25978e;
                if (wVar != null) {
                    wVar.f(d10);
                }
                return true;
            }
        }
        return false;
    }

    public final boolean n() {
        l lVar;
        if (!this.f15661w || f() || (lVar = this.f25976c) == null || this.f25981r == null || this.f15654F != null) {
            return false;
        }
        lVar.i();
        if (lVar.f26043t.isEmpty()) {
            return false;
        }
        RunnableC1334g runnableC1334g = new RunnableC1334g(this, new C1330e(this, this.f25975b, this.f25976c, this.f15658t));
        this.f15654F = runnableC1334g;
        ((View) this.f25981r).post(runnableC1334g);
        return true;
    }
}
