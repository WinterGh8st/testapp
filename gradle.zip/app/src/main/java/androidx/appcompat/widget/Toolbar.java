package androidx.appcompat.widget;

import B2.I;
import N1.G;
import V4.ViewOnClickListenerC0757k;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.app.ActionBar$LayoutParams;
import com.flamingotools.ws.R;
import com.google.android.gms.common.api.internal.F;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import p164o.l;
import p164o.n;
import p175p.C1364v0;
import p175p.K0;
import p175p.L0;
import p175p.M0;
import p175p.N0;
import p175p.W;
import p175p.W0;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class Toolbar extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f15599A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public int f15600B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public int f15601C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public C1364v0 f15602D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public int f15603E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public int f15604F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public final int f15605G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public CharSequence f15606H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public CharSequence f15607I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public ColorStateList f15608J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public ColorStateList f15609K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public boolean f15610L;
    public boolean M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public final ArrayList f15611N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public final ArrayList f15612O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public final int[] f15613P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public final Z2.f f15614Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public ArrayList f15615R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public M0 f15616S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final p074g0.c f15617T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public i f15618U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public a f15619V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public h f15620W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ActionMenuView f15621a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public I f15622a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public AppCompatTextView f15623b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public p088h1.g f15624b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public AppCompatTextView f15625c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public boolean f15626c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public AppCompatImageButton f15627d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public OnBackInvokedCallback f15628d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public AppCompatImageView f15629e;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public OnBackInvokedDispatcher f15630e0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Drawable f15631f;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public boolean f15632f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    public final F f15633g0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public final CharSequence f15634q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public AppCompatImageButton f15635r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public View f15636s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public Context f15637t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f15638u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15639v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f15640w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final int f15641x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final int f15642y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public int f15643z;

    public static class LayoutParams extends ActionBar$LayoutParams {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f15644b;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f15644b = 0;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.toolbarStyle);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i10 = 0; i10 < menu.size(); i10++) {
            arrayList.add(menu.getItem(i10));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new p153n.h(getContext());
    }

    public static LayoutParams h() {
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.f15644b = 0;
        layoutParams.f15277a = 8388627;
        return layoutParams;
    }

    public static LayoutParams i(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            LayoutParams layoutParams2 = (LayoutParams) layoutParams;
            LayoutParams layoutParams3 = new LayoutParams(layoutParams2);
            layoutParams3.f15644b = 0;
            layoutParams3.f15644b = layoutParams2.f15644b;
            return layoutParams3;
        }
        if (layoutParams instanceof ActionBar$LayoutParams) {
            LayoutParams layoutParams4 = new LayoutParams((ActionBar$LayoutParams) layoutParams);
            layoutParams4.f15644b = 0;
            return layoutParams4;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            LayoutParams layoutParams5 = new LayoutParams(layoutParams);
            layoutParams5.f15644b = 0;
            return layoutParams5;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        LayoutParams layoutParams6 = new LayoutParams(marginLayoutParams);
        layoutParams6.f15644b = 0;
        ((ViewGroup.MarginLayoutParams) layoutParams6).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) layoutParams6).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) layoutParams6).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) layoutParams6).bottomMargin = marginLayoutParams.bottomMargin;
        return layoutParams6;
    }

    public static int k(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginEnd() + marginLayoutParams.getMarginStart();
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(int i10, ArrayList arrayList) {
        boolean z3 = getLayoutDirection() == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, getLayoutDirection());
        arrayList.clear();
        if (!z3) {
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (layoutParams.f15644b == 0 && u(childAt)) {
                    int i12 = layoutParams.f15277a;
                    int layoutDirection = getLayoutDirection();
                    int absoluteGravity2 = Gravity.getAbsoluteGravity(i12, layoutDirection) & 7;
                    if (absoluteGravity2 != 1 && absoluteGravity2 != 3 && absoluteGravity2 != 5) {
                        absoluteGravity2 = layoutDirection == 1 ? 5 : 3;
                    }
                    if (absoluteGravity2 == absoluteGravity) {
                        arrayList.add(childAt);
                    }
                }
            }
            return;
        }
        for (int i13 = childCount - 1; i13 >= 0; i13--) {
            View childAt2 = getChildAt(i13);
            LayoutParams layoutParams2 = (LayoutParams) childAt2.getLayoutParams();
            if (layoutParams2.f15644b == 0 && u(childAt2)) {
                int i14 = layoutParams2.f15277a;
                int layoutDirection2 = getLayoutDirection();
                int absoluteGravity3 = Gravity.getAbsoluteGravity(i14, layoutDirection2) & 7;
                if (absoluteGravity3 != 1 && absoluteGravity3 != 3 && absoluteGravity3 != 5) {
                    absoluteGravity3 = layoutDirection2 == 1 ? 5 : 3;
                }
                if (absoluteGravity3 == absoluteGravity) {
                    arrayList.add(childAt2);
                }
            }
        }
    }

    public final void b(View view, boolean z3) {
        LayoutParams layoutParamsI;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams == null) {
            layoutParamsI = h();
        } else {
            layoutParamsI = !checkLayoutParams(layoutParams) ? i(layoutParams) : (LayoutParams) layoutParams;
        }
        layoutParamsI.f15644b = 1;
        if (!z3 || this.f15636s == null) {
            addView(view, layoutParamsI);
        } else {
            view.setLayoutParams(layoutParamsI);
            this.f15612O.add(view);
        }
    }

    public final void c() {
        if (this.f15635r == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.f15635r = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f15631f);
            this.f15635r.setContentDescription(this.f15634q);
            LayoutParams layoutParamsH = h();
            layoutParamsH.f15277a = (this.f15641x & 112) | 8388611;
            layoutParamsH.f15644b = 2;
            this.f15635r.setLayoutParams(layoutParamsH);
            this.f15635r.setOnClickListener(new ViewOnClickListenerC0757k(this, 6));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof LayoutParams);
    }

    public final void d() {
        if (this.f15602D == null) {
            C1364v0 c1364v0 = new C1364v0();
            c1364v0.f26584a = 0;
            c1364v0.f26585b = 0;
            c1364v0.f26586c = Integer.MIN_VALUE;
            c1364v0.f26587d = Integer.MIN_VALUE;
            c1364v0.f26588e = 0;
            c1364v0.f26589f = 0;
            c1364v0.f26590g = false;
            c1364v0.f26591h = false;
            this.f15602D = c1364v0;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f15621a;
        if (actionMenuView.f15380z == null) {
            l lVar = (l) actionMenuView.getMenu();
            if (this.f15620W == null) {
                this.f15620W = new h(this);
            }
            this.f15621a.setExpandedActionViewsExclusive(true);
            lVar.b(this.f15620W, this.f15637t);
            w();
        }
    }

    public final void f() {
        if (this.f15621a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f15621a = actionMenuView;
            actionMenuView.setPopupTheme(this.f15638u);
            this.f15621a.setOnMenuItemClickListener(this.f15617T);
            ActionMenuView actionMenuView2 = this.f15621a;
            I i10 = this.f15622a0;
            p088h1.g gVar = new p088h1.g(this, 17);
            actionMenuView2.f15373E = i10;
            actionMenuView2.f15374F = gVar;
            LayoutParams layoutParamsH = h();
            layoutParamsH.f15277a = (this.f15641x & 112) | 8388613;
            this.f15621a.setLayoutParams(layoutParamsH);
            b(this.f15621a, false);
        }
    }

    public final void g() {
        if (this.f15627d == null) {
            this.f15627d = new AppCompatImageButton(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            LayoutParams layoutParamsH = h();
            layoutParamsH.f15277a = (this.f15641x & 112) | 8388611;
            this.f15627d.setLayoutParams(layoutParamsH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        AppCompatImageButton appCompatImageButton = this.f15635r;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        AppCompatImageButton appCompatImageButton = this.f15635r;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        C1364v0 c1364v0 = this.f15602D;
        if (c1364v0 != null) {
            return c1364v0.f26590g ? c1364v0.f26584a : c1364v0.f26585b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i10 = this.f15604F;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        C1364v0 c1364v0 = this.f15602D;
        if (c1364v0 != null) {
            return c1364v0.f26584a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        C1364v0 c1364v0 = this.f15602D;
        if (c1364v0 != null) {
            return c1364v0.f26585b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        C1364v0 c1364v0 = this.f15602D;
        if (c1364v0 != null) {
            return c1364v0.f26590g ? c1364v0.f26585b : c1364v0.f26584a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i10 = this.f15603E;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        l lVar;
        ActionMenuView actionMenuView = this.f15621a;
        return (actionMenuView == null || (lVar = actionMenuView.f15380z) == null || !lVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f15604F, 0));
    }

    public int getCurrentContentInsetLeft() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return getLayoutDirection() == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f15603E, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        AppCompatImageView appCompatImageView = this.f15629e;
        if (appCompatImageView != null) {
            return appCompatImageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        AppCompatImageView appCompatImageView = this.f15629e;
        if (appCompatImageView != null) {
            return appCompatImageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f15621a.getMenu();
    }

    public View getNavButtonView() {
        return this.f15627d;
    }

    public CharSequence getNavigationContentDescription() {
        AppCompatImageButton appCompatImageButton = this.f15627d;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        AppCompatImageButton appCompatImageButton = this.f15627d;
        if (appCompatImageButton != null) {
            return appCompatImageButton.getDrawable();
        }
        return null;
    }

    public a getOuterActionMenuPresenter() {
        return this.f15619V;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f15621a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f15637t;
    }

    public int getPopupTheme() {
        return this.f15638u;
    }

    public CharSequence getSubtitle() {
        return this.f15607I;
    }

    public final TextView getSubtitleTextView() {
        return this.f15625c;
    }

    public CharSequence getTitle() {
        return this.f15606H;
    }

    public int getTitleMarginBottom() {
        return this.f15601C;
    }

    public int getTitleMarginEnd() {
        return this.f15599A;
    }

    public int getTitleMarginStart() {
        return this.f15643z;
    }

    public int getTitleMarginTop() {
        return this.f15600B;
    }

    public final TextView getTitleTextView() {
        return this.f15623b;
    }

    public W getWrapper() {
        if (this.f15618U == null) {
            this.f15618U = new i(this, true);
        }
        return this.f15618U;
    }

    public final int j(View view, int i10) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i11 = i10 > 0 ? (measuredHeight - i10) / 2 : 0;
        int i12 = layoutParams.f15277a & 112;
        if (i12 != 16 && i12 != 48 && i12 != 80) {
            i12 = this.f15605G & 112;
        }
        if (i12 == 48) {
            return getPaddingTop() - i11;
        }
        if (i12 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin) - i11;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i13 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
        if (iMax < i13) {
            iMax = i13;
        } else {
            int i14 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i15 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
            if (i14 < i15) {
                iMax = Math.max(0, iMax - (i15 - i14));
            }
        }
        return paddingTop + iMax;
    }

    public void m(int i10) {
        getMenuInflater().inflate(i10, getMenu());
    }

    public final void n() {
        ArrayList arrayList = this.f15615R;
        int size = arrayList.size();
        int i10 = 0;
        while (i10 < size) {
            Object obj = arrayList.get(i10);
            i10++;
            getMenu().removeItem(((MenuItem) obj).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.f15614Q.f14488b).iterator();
        while (it.hasNext()) {
            ((G) it.next()).f9005a.k();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f15615R = currentMenuItems2;
    }

    public final boolean o(View view) {
        return view.getParent() == this || this.f15612O.contains(view);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        w();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f15633g0);
        w();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.M = false;
        }
        if (!this.M) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.M = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.M = false;
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:100:0x027d  */
    /* JADX WARN: Code duplicated, block: B:103:0x028f A[LOOP:0: B:102:0x028d->B:103:0x028f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:106:0x02a7 A[LOOP:1: B:105:0x02a5->B:106:0x02a7, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:109:0x02c8 A[LOOP:2: B:108:0x02c6->B:109:0x02c8, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:113:0x030b A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:114:0x030d  */
    /* JADX WARN: Code duplicated, block: B:115:0x0311  */
    /* JADX WARN: Code duplicated, block: B:118:0x0318 A[LOOP:3: B:117:0x0316->B:118:0x0318, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:19:0x0062 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:20:0x0064  */
    /* JADX WARN: Code duplicated, block: B:21:0x006b  */
    /* JADX WARN: Code duplicated, block: B:24:0x0079 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:25:0x007b  */
    /* JADX WARN: Code duplicated, block: B:26:0x0082  */
    /* JADX WARN: Code duplicated, block: B:29:0x00b6 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:30:0x00b8  */
    /* JADX WARN: Code duplicated, block: B:31:0x00bf  */
    /* JADX WARN: Code duplicated, block: B:34:0x00cd A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:35:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:36:0x00d6  */
    /* JADX WARN: Code duplicated, block: B:39:0x00ea  */
    /* JADX WARN: Code duplicated, block: B:40:0x0101  */
    /* JADX WARN: Code duplicated, block: B:42:0x0106  */
    /* JADX WARN: Code duplicated, block: B:43:0x011f  */
    /* JADX WARN: Code duplicated, block: B:46:0x0125 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:47:0x0127  */
    /* JADX WARN: Code duplicated, block: B:48:0x012a  */
    /* JADX WARN: Code duplicated, block: B:50:0x012e  */
    /* JADX WARN: Code duplicated, block: B:51:0x0131  */
    /* JADX WARN: Code duplicated, block: B:54:0x0143  */
    /* JADX WARN: Code duplicated, block: B:56:0x014b A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:63:0x0164  */
    /* JADX WARN: Code duplicated, block: B:65:0x0168  */
    /* JADX WARN: Code duplicated, block: B:67:0x0179  */
    /* JADX WARN: Code duplicated, block: B:68:0x017b  */
    /* JADX WARN: Code duplicated, block: B:70:0x0187  */
    /* JADX WARN: Code duplicated, block: B:72:0x0193  */
    /* JADX WARN: Code duplicated, block: B:73:0x019d  */
    /* JADX WARN: Code duplicated, block: B:75:0x01aa A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:76:0x01ac  */
    /* JADX WARN: Code duplicated, block: B:77:0x01af  */
    /* JADX WARN: Code duplicated, block: B:80:0x01c2  */
    /* JADX WARN: Code duplicated, block: B:81:0x01e6  */
    /* JADX WARN: Code duplicated, block: B:83:0x01e9  */
    /* JADX WARN: Code duplicated, block: B:84:0x020d  */
    /* JADX WARN: Code duplicated, block: B:86:0x0210  */
    /* JADX WARN: Code duplicated, block: B:88:0x0218 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:89:0x021a  */
    /* JADX WARN: Code duplicated, block: B:91:0x021e  */
    /* JADX WARN: Code duplicated, block: B:94:0x0232  */
    /* JADX WARN: Code duplicated, block: B:95:0x0255  */
    /* JADX WARN: Code duplicated, block: B:97:0x0258  */
    /* JADX WARN: Code duplicated, block: B:98:0x027a  */
    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int iQ;
        int iR;
        int iMax;
        int iMin;
        boolean zU;
        boolean zU2;
        int measuredHeight;
        AppCompatTextView appCompatTextView;
        AppCompatTextView appCompatTextView2;
        LayoutParams layoutParams;
        LayoutParams layoutParams2;
        int i14;
        boolean z5;
        int i15;
        int i16;
        int paddingTop;
        int i17;
        int i18;
        int i19;
        int i20;
        int i21;
        int i22;
        int iMax2;
        int i23;
        int i24;
        int i25;
        int i26;
        ArrayList arrayList;
        int size;
        int iQ2;
        int i27;
        int size2;
        int i28;
        int size3;
        int i29;
        int i30;
        int i31;
        int measuredWidth;
        int i32;
        int i33;
        int i34;
        int size4;
        boolean z10 = getLayoutDirection() == 1;
        int width = getWidth();
        int height = getHeight();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int paddingTop2 = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int i35 = width - paddingRight;
        int[] iArr = this.f15613P;
        iArr[1] = 0;
        iArr[0] = 0;
        WeakHashMap weakHashMap = U.f27683a;
        int minimumHeight = getMinimumHeight();
        int iMin2 = minimumHeight >= 0 ? Math.min(minimumHeight, i13 - i11) : 0;
        if (u(this.f15627d)) {
            if (z10) {
                iR = r(this.f15627d, i35, iMin2, iArr);
                iQ = paddingLeft;
            } else {
                iQ = q(this.f15627d, paddingLeft, iMin2, iArr);
            }
            if (u(this.f15635r)) {
                if (z10) {
                    iR = r(this.f15635r, iR, iMin2, iArr);
                } else {
                    iQ = q(this.f15635r, iQ, iMin2, iArr);
                }
            }
            if (u(this.f15621a)) {
                if (z10) {
                    iQ = q(this.f15621a, iQ, iMin2, iArr);
                } else {
                    iR = r(this.f15621a, iR, iMin2, iArr);
                }
            }
            int currentContentInsetLeft = getCurrentContentInsetLeft();
            int currentContentInsetRight = getCurrentContentInsetRight();
            iArr[0] = Math.max(0, currentContentInsetLeft - iQ);
            iArr[1] = Math.max(0, currentContentInsetRight - (i35 - iR));
            iMax = Math.max(iQ, currentContentInsetLeft);
            iMin = Math.min(iR, i35 - currentContentInsetRight);
            if (u(this.f15636s)) {
                if (z10) {
                    iMin = r(this.f15636s, iMin, iMin2, iArr);
                } else {
                    iMax = q(this.f15636s, iMax, iMin2, iArr);
                }
            }
            if (u(this.f15629e)) {
                if (z10) {
                    iMin = r(this.f15629e, iMin, iMin2, iArr);
                } else {
                    iMax = q(this.f15629e, iMax, iMin2, iArr);
                }
            }
            zU = u(this.f15623b);
            zU2 = u(this.f15625c);
            if (zU) {
                LayoutParams layoutParams3 = (LayoutParams) this.f15623b.getLayoutParams();
                measuredHeight = this.f15623b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams3).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams3).bottomMargin;
            } else {
                measuredHeight = 0;
            }
            if (zU2) {
                LayoutParams layoutParams4 = (LayoutParams) this.f15625c.getLayoutParams();
                measuredHeight = this.f15625c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams4).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams4).bottomMargin + measuredHeight;
            }
            if (zU || zU2) {
                if (zU) {
                    appCompatTextView = this.f15623b;
                } else {
                    appCompatTextView = this.f15625c;
                }
                if (zU2) {
                    appCompatTextView2 = this.f15625c;
                } else {
                    appCompatTextView2 = this.f15623b;
                }
                layoutParams = (LayoutParams) appCompatTextView.getLayoutParams();
                layoutParams2 = (LayoutParams) appCompatTextView2.getLayoutParams();
                i14 = measuredHeight;
                z5 = (!zU && this.f15623b.getMeasuredWidth() > 0) || (zU2 && this.f15625c.getMeasuredWidth() > 0);
                i15 = this.f15605G & 112;
                i16 = iMax;
                if (i15 == 48) {
                    paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
                } else if (i15 != 80) {
                    iMax2 = (((height - paddingTop2) - paddingBottom) - i14) / 2;
                    i23 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
                    if (iMax2 < i23) {
                        iMax2 = i23;
                    } else {
                        i24 = (((height - paddingBottom) - i14) - iMax2) - paddingTop2;
                        i25 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                        i26 = this.f15601C;
                        if (i24 < i25 + i26) {
                            iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin + i26) - i24));
                        }
                    }
                    paddingTop = paddingTop2 + iMax2;
                } else {
                    paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin) - this.f15601C) - i14;
                }
                if (z10) {
                    if (z5) {
                        i20 = this.f15643z;
                    } else {
                        i20 = 0;
                    }
                    int i36 = i20 - iArr[1];
                    iMin -= Math.max(0, i36);
                    iArr[1] = Math.max(0, -i36);
                    if (zU) {
                        LayoutParams layoutParams5 = (LayoutParams) this.f15623b.getLayoutParams();
                        int measuredWidth2 = iMin - this.f15623b.getMeasuredWidth();
                        int measuredHeight2 = this.f15623b.getMeasuredHeight() + paddingTop;
                        this.f15623b.layout(measuredWidth2, paddingTop, iMin, measuredHeight2);
                        i21 = measuredWidth2 - this.f15599A;
                        paddingTop = measuredHeight2 + ((ViewGroup.MarginLayoutParams) layoutParams5).bottomMargin;
                    } else {
                        i21 = iMin;
                    }
                    if (zU2) {
                        int i37 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                        this.f15625c.layout(iMin - this.f15625c.getMeasuredWidth(), i37, iMin, this.f15625c.getMeasuredHeight() + i37);
                        i22 = iMin - this.f15599A;
                    } else {
                        i22 = iMin;
                    }
                    if (z5) {
                        iMin = Math.min(i21, i22);
                    }
                    iMax = i16;
                } else {
                    if (z5) {
                        i17 = this.f15643z;
                    } else {
                        i17 = 0;
                    }
                    int i38 = i17 - iArr[0];
                    iMax = Math.max(0, i38) + i16;
                    iArr[0] = Math.max(0, -i38);
                    if (zU) {
                        LayoutParams layoutParams6 = (LayoutParams) this.f15623b.getLayoutParams();
                        int measuredWidth3 = this.f15623b.getMeasuredWidth() + iMax;
                        int measuredHeight3 = this.f15623b.getMeasuredHeight() + paddingTop;
                        this.f15623b.layout(iMax, paddingTop, measuredWidth3, measuredHeight3);
                        i18 = measuredWidth3 + this.f15599A;
                        paddingTop = measuredHeight3 + ((ViewGroup.MarginLayoutParams) layoutParams6).bottomMargin;
                    } else {
                        i18 = iMax;
                    }
                    if (zU2) {
                        int i39 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                        int measuredWidth4 = this.f15625c.getMeasuredWidth() + iMax;
                        this.f15625c.layout(iMax, i39, measuredWidth4, this.f15625c.getMeasuredHeight() + i39);
                        i19 = measuredWidth4 + this.f15599A;
                    } else {
                        i19 = iMax;
                    }
                    if (z5) {
                        iMax = Math.max(i18, i19);
                    }
                }
            }
            arrayList = this.f15611N;
            a(3, arrayList);
            size = arrayList.size();
            iQ2 = iMax;
            for (i27 = 0; i27 < size; i27++) {
                iQ2 = q((View) arrayList.get(i27), iQ2, iMin2, iArr);
            }
            a(5, arrayList);
            size2 = arrayList.size();
            for (i28 = 0; i28 < size2; i28++) {
                iMin = r((View) arrayList.get(i28), iMin, iMin2, iArr);
            }
            a(1, arrayList);
            int i40 = iArr[0];
            int i41 = iArr[1];
            size3 = arrayList.size();
            i29 = i41;
            i30 = i40;
            i31 = 0;
            measuredWidth = 0;
            while (i31 < size3) {
                View view = (View) arrayList.get(i31);
                LayoutParams layoutParams7 = (LayoutParams) view.getLayoutParams();
                int i42 = i31;
                int i43 = ((ViewGroup.MarginLayoutParams) layoutParams7).leftMargin - i30;
                int i44 = ((ViewGroup.MarginLayoutParams) layoutParams7).rightMargin - i29;
                int iMax3 = Math.max(0, i43);
                int iMax4 = Math.max(0, i44);
                int iMax5 = Math.max(0, -i43);
                int iMax6 = Math.max(0, -i44);
                measuredWidth += view.getMeasuredWidth() + iMax3 + iMax4;
                i29 = iMax6;
                i30 = iMax5;
                i31 = i42 + 1;
            }
            i33 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
            i34 = measuredWidth + i33;
            if (i33 >= iQ2) {
                if (i34 > iMin) {
                    iQ2 = i33 - (i34 - iMin);
                } else {
                    iQ2 = i33;
                }
            }
            size4 = arrayList.size();
            for (i32 = 0; i32 < size4; i32++) {
                iQ2 = q((View) arrayList.get(i32), iQ2, iMin2, iArr);
            }
            arrayList.clear();
        }
        iQ = paddingLeft;
        iR = i35;
        if (u(this.f15635r)) {
            if (z10) {
                iR = r(this.f15635r, iR, iMin2, iArr);
            } else {
                iQ = q(this.f15635r, iQ, iMin2, iArr);
            }
        }
        if (u(this.f15621a)) {
            if (z10) {
                iQ = q(this.f15621a, iQ, iMin2, iArr);
            } else {
                iR = r(this.f15621a, iR, iMin2, iArr);
            }
        }
        int currentContentInsetLeft2 = getCurrentContentInsetLeft();
        int currentContentInsetRight2 = getCurrentContentInsetRight();
        iArr[0] = Math.max(0, currentContentInsetLeft2 - iQ);
        iArr[1] = Math.max(0, currentContentInsetRight2 - (i35 - iR));
        iMax = Math.max(iQ, currentContentInsetLeft2);
        iMin = Math.min(iR, i35 - currentContentInsetRight2);
        if (u(this.f15636s)) {
            if (z10) {
                iMin = r(this.f15636s, iMin, iMin2, iArr);
            } else {
                iMax = q(this.f15636s, iMax, iMin2, iArr);
            }
        }
        if (u(this.f15629e)) {
            if (z10) {
                iMin = r(this.f15629e, iMin, iMin2, iArr);
            } else {
                iMax = q(this.f15629e, iMax, iMin2, iArr);
            }
        }
        zU = u(this.f15623b);
        zU2 = u(this.f15625c);
        if (zU) {
            LayoutParams layoutParams8 = (LayoutParams) this.f15623b.getLayoutParams();
            measuredHeight = this.f15623b.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams8).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams8).bottomMargin;
        } else {
            measuredHeight = 0;
        }
        if (zU2) {
            LayoutParams layoutParams9 = (LayoutParams) this.f15625c.getLayoutParams();
            measuredHeight = this.f15625c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams9).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams9).bottomMargin + measuredHeight;
        }
        if (zU) {
            if (zU) {
                appCompatTextView = this.f15623b;
            } else {
                appCompatTextView = this.f15625c;
            }
            if (zU2) {
                appCompatTextView2 = this.f15625c;
            } else {
                appCompatTextView2 = this.f15623b;
            }
            layoutParams = (LayoutParams) appCompatTextView.getLayoutParams();
            layoutParams2 = (LayoutParams) appCompatTextView2.getLayoutParams();
            i14 = measuredHeight;
            if (zU) {
            }
            i15 = this.f15605G & 112;
            i16 = iMax;
            if (i15 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
            } else if (i15 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i14) / 2;
                i23 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
                if (iMax2 < i23) {
                    iMax2 = i23;
                } else {
                    i24 = (((height - paddingBottom) - i14) - iMax2) - paddingTop2;
                    i25 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                    i26 = this.f15601C;
                    if (i24 < i25 + i26) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin + i26) - i24));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin) - this.f15601C) - i14;
            }
            if (z10) {
                if (z5) {
                    i20 = this.f15643z;
                } else {
                    i20 = 0;
                }
                int i310 = i20 - iArr[1];
                iMin -= Math.max(0, i310);
                iArr[1] = Math.max(0, -i310);
                if (zU) {
                    LayoutParams layoutParams10 = (LayoutParams) this.f15623b.getLayoutParams();
                    int measuredWidth5 = iMin - this.f15623b.getMeasuredWidth();
                    int measuredHeight4 = this.f15623b.getMeasuredHeight() + paddingTop;
                    this.f15623b.layout(measuredWidth5, paddingTop, iMin, measuredHeight4);
                    i21 = measuredWidth5 - this.f15599A;
                    paddingTop = measuredHeight4 + ((ViewGroup.MarginLayoutParams) layoutParams10).bottomMargin;
                } else {
                    i21 = iMin;
                }
                if (zU2) {
                    int i311 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                    this.f15625c.layout(iMin - this.f15625c.getMeasuredWidth(), i311, iMin, this.f15625c.getMeasuredHeight() + i311);
                    i22 = iMin - this.f15599A;
                } else {
                    i22 = iMin;
                }
                if (z5) {
                    iMin = Math.min(i21, i22);
                }
                iMax = i16;
            } else {
                if (z5) {
                    i17 = this.f15643z;
                } else {
                    i17 = 0;
                }
                int i312 = i17 - iArr[0];
                iMax = Math.max(0, i312) + i16;
                iArr[0] = Math.max(0, -i312);
                if (zU) {
                    LayoutParams layoutParams11 = (LayoutParams) this.f15623b.getLayoutParams();
                    int measuredWidth6 = this.f15623b.getMeasuredWidth() + iMax;
                    int measuredHeight5 = this.f15623b.getMeasuredHeight() + paddingTop;
                    this.f15623b.layout(iMax, paddingTop, measuredWidth6, measuredHeight5);
                    i18 = measuredWidth6 + this.f15599A;
                    paddingTop = measuredHeight5 + ((ViewGroup.MarginLayoutParams) layoutParams11).bottomMargin;
                } else {
                    i18 = iMax;
                }
                if (zU2) {
                    int i313 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                    int measuredWidth7 = this.f15625c.getMeasuredWidth() + iMax;
                    this.f15625c.layout(iMax, i313, measuredWidth7, this.f15625c.getMeasuredHeight() + i313);
                    i19 = measuredWidth7 + this.f15599A;
                } else {
                    i19 = iMax;
                }
                if (z5) {
                    iMax = Math.max(i18, i19);
                }
            }
        } else {
            if (zU) {
                appCompatTextView = this.f15623b;
            } else {
                appCompatTextView = this.f15625c;
            }
            if (zU2) {
                appCompatTextView2 = this.f15625c;
            } else {
                appCompatTextView2 = this.f15623b;
            }
            layoutParams = (LayoutParams) appCompatTextView.getLayoutParams();
            layoutParams2 = (LayoutParams) appCompatTextView2.getLayoutParams();
            i14 = measuredHeight;
            if (zU) {
            }
            i15 = this.f15605G & 112;
            i16 = iMax;
            if (i15 == 48) {
                paddingTop = getPaddingTop() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
            } else if (i15 != 80) {
                iMax2 = (((height - paddingTop2) - paddingBottom) - i14) / 2;
                i23 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + this.f15600B;
                if (iMax2 < i23) {
                    iMax2 = i23;
                } else {
                    i24 = (((height - paddingBottom) - i14) - iMax2) - paddingTop2;
                    i25 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                    i26 = this.f15601C;
                    if (i24 < i25 + i26) {
                        iMax2 = Math.max(0, iMax2 - ((((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin + i26) - i24));
                    }
                }
                paddingTop = paddingTop2 + iMax2;
            } else {
                paddingTop = (((height - paddingBottom) - ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin) - this.f15601C) - i14;
            }
            if (z10) {
                if (z5) {
                    i20 = this.f15643z;
                } else {
                    i20 = 0;
                }
                int i314 = i20 - iArr[1];
                iMin -= Math.max(0, i314);
                iArr[1] = Math.max(0, -i314);
                if (zU) {
                    LayoutParams layoutParams12 = (LayoutParams) this.f15623b.getLayoutParams();
                    int measuredWidth8 = iMin - this.f15623b.getMeasuredWidth();
                    int measuredHeight6 = this.f15623b.getMeasuredHeight() + paddingTop;
                    this.f15623b.layout(measuredWidth8, paddingTop, iMin, measuredHeight6);
                    i21 = measuredWidth8 - this.f15599A;
                    paddingTop = measuredHeight6 + ((ViewGroup.MarginLayoutParams) layoutParams12).bottomMargin;
                } else {
                    i21 = iMin;
                }
                if (zU2) {
                    int i315 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                    this.f15625c.layout(iMin - this.f15625c.getMeasuredWidth(), i315, iMin, this.f15625c.getMeasuredHeight() + i315);
                    i22 = iMin - this.f15599A;
                } else {
                    i22 = iMin;
                }
                if (z5) {
                    iMin = Math.min(i21, i22);
                }
                iMax = i16;
            } else {
                if (z5) {
                    i17 = this.f15643z;
                } else {
                    i17 = 0;
                }
                int i316 = i17 - iArr[0];
                iMax = Math.max(0, i316) + i16;
                iArr[0] = Math.max(0, -i316);
                if (zU) {
                    LayoutParams layoutParams13 = (LayoutParams) this.f15623b.getLayoutParams();
                    int measuredWidth9 = this.f15623b.getMeasuredWidth() + iMax;
                    int measuredHeight7 = this.f15623b.getMeasuredHeight() + paddingTop;
                    this.f15623b.layout(iMax, paddingTop, measuredWidth9, measuredHeight7);
                    i18 = measuredWidth9 + this.f15599A;
                    paddingTop = measuredHeight7 + ((ViewGroup.MarginLayoutParams) layoutParams13).bottomMargin;
                } else {
                    i18 = iMax;
                }
                if (zU2) {
                    int i317 = paddingTop + ((ViewGroup.MarginLayoutParams) ((LayoutParams) this.f15625c.getLayoutParams())).topMargin;
                    int measuredWidth10 = this.f15625c.getMeasuredWidth() + iMax;
                    this.f15625c.layout(iMax, i317, measuredWidth10, this.f15625c.getMeasuredHeight() + i317);
                    i19 = measuredWidth10 + this.f15599A;
                } else {
                    i19 = iMax;
                }
                if (z5) {
                    iMax = Math.max(i18, i19);
                }
            }
        }
        arrayList = this.f15611N;
        a(3, arrayList);
        size = arrayList.size();
        iQ2 = iMax;
        while (i27 < size) {
            iQ2 = q((View) arrayList.get(i27), iQ2, iMin2, iArr);
        }
        a(5, arrayList);
        size2 = arrayList.size();
        while (i28 < size2) {
            iMin = r((View) arrayList.get(i28), iMin, iMin2, iArr);
        }
        a(1, arrayList);
        int i45 = iArr[0];
        int i46 = iArr[1];
        size3 = arrayList.size();
        i29 = i46;
        i30 = i45;
        i31 = 0;
        measuredWidth = 0;
        while (i31 < size3) {
            View view2 = (View) arrayList.get(i31);
            LayoutParams layoutParams14 = (LayoutParams) view2.getLayoutParams();
            int i47 = i31;
            int i48 = ((ViewGroup.MarginLayoutParams) layoutParams14).leftMargin - i30;
            int i49 = ((ViewGroup.MarginLayoutParams) layoutParams14).rightMargin - i29;
            int iMax7 = Math.max(0, i48);
            int iMax8 = Math.max(0, i49);
            int iMax9 = Math.max(0, -i48);
            int iMax10 = Math.max(0, -i49);
            measuredWidth += view2.getMeasuredWidth() + iMax7 + iMax8;
            i29 = iMax10;
            i30 = iMax9;
            i31 = i47 + 1;
        }
        i33 = ((((width - paddingLeft) - paddingRight) / 2) + paddingLeft) - (measuredWidth / 2);
        i34 = measuredWidth + i33;
        if (i33 >= iQ2) {
            if (i34 > iMin) {
                iQ2 = i33 - (i34 - iMin);
            } else {
                iQ2 = i33;
            }
        }
        size4 = arrayList.size();
        while (i32 < size4) {
            iQ2 = q((View) arrayList.get(i32), iQ2, iMin2, iArr);
        }
        arrayList.clear();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        byte b10;
        byte b11;
        int iK;
        int iMax;
        int iCombineMeasuredStates;
        int iK2;
        int iL;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean z3 = W0.f26495a;
        int i12 = 0;
        if (getLayoutDirection() == 1) {
            b11 = true;
            b10 = 0;
        } else {
            b10 = 1;
            b11 = false;
        }
        if (u(this.f15627d)) {
            t(this.f15627d, i10, 0, i11, this.f15642y);
            iK = k(this.f15627d) + this.f15627d.getMeasuredWidth();
            iMax = Math.max(0, l(this.f15627d) + this.f15627d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.f15627d.getMeasuredState());
        } else {
            iK = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (u(this.f15635r)) {
            t(this.f15635r, i10, 0, i11, this.f15642y);
            iK = k(this.f15635r) + this.f15635r.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f15635r) + this.f15635r.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f15635r.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iK);
        int iMax4 = Math.max(0, currentContentInsetStart - iK);
        byte b12 = b11;
        int[] iArr = this.f15613P;
        iArr[b12 == true ? 1 : 0] = iMax4;
        if (u(this.f15621a)) {
            t(this.f15621a, i10, iMax3, i11, this.f15642y);
            iK2 = k(this.f15621a) + this.f15621a.getMeasuredWidth();
            iMax = Math.max(iMax, l(this.f15621a) + this.f15621a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f15621a.getMeasuredState());
        } else {
            iK2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iK2);
        iArr[b10] = Math.max(0, currentContentInsetEnd - iK2);
        if (u(this.f15636s)) {
            iMax5 += s(this.f15636s, i10, iMax5, i11, 0, iArr);
            iMax = Math.max(iMax, l(this.f15636s) + this.f15636s.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f15636s.getMeasuredState());
        }
        if (u(this.f15629e)) {
            iMax5 += s(this.f15629e, i10, iMax5, i11, 0, iArr);
            iMax = Math.max(iMax, l(this.f15629e) + this.f15629e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f15629e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (((LayoutParams) childAt.getLayoutParams()).f15644b == 0 && u(childAt)) {
                iMax5 += s(childAt, i10, iMax5, i11, 0, iArr);
                int iMax6 = Math.max(iMax, l(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
                iMax = iMax6;
            } else {
                iMax5 = iMax5;
            }
        }
        int i14 = iMax5;
        int i15 = this.f15600B + this.f15601C;
        int i16 = this.f15643z + this.f15599A;
        if (u(this.f15623b)) {
            s(this.f15623b, i10, i14 + i16, i11, i15, iArr);
            int iK3 = k(this.f15623b) + this.f15623b.getMeasuredWidth();
            iL = l(this.f15623b) + this.f15623b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f15623b.getMeasuredState());
            iMax2 = iK3;
        } else {
            iL = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (u(this.f15625c)) {
            iMax2 = Math.max(iMax2, s(this.f15625c, i10, i14 + i16, i11, i15 + iL, iArr));
            iL += l(this.f15625c) + this.f15625c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f15625c.getMeasuredState());
        }
        int iMax7 = Math.max(iMax, iL);
        int paddingRight = getPaddingRight() + getPaddingLeft() + i14 + iMax2;
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax7;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight, getSuggestedMinimumWidth()), i10, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i11, iCombineMeasuredStates2 << 16);
        if (!this.f15626c0) {
            i12 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i17 = 0; i17 < childCount2; i17++) {
            View childAt2 = getChildAt(i17);
            if (u(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i12 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i12);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof N0)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        N0 n10 = (N0) parcelable;
        super.onRestoreInstanceState(n10.f2402a);
        ActionMenuView actionMenuView = this.f15621a;
        l lVar = actionMenuView != null ? actionMenuView.f15380z : null;
        int i10 = n10.f26457c;
        if (i10 != 0 && this.f15620W != null && lVar != null && (menuItemFindItem = lVar.findItem(i10)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (n10.f26458d) {
            F f10 = this.f15633g0;
            removeCallbacks(f10);
            post(f10);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        super.onRtlPropertiesChanged(i10);
        d();
        C1364v0 c1364v0 = this.f15602D;
        boolean z3 = i10 == 1;
        if (z3 == c1364v0.f26590g) {
            return;
        }
        c1364v0.f26590g = z3;
        if (!c1364v0.f26591h) {
            c1364v0.f26584a = c1364v0.f26588e;
            c1364v0.f26585b = c1364v0.f26589f;
            return;
        }
        if (z3) {
            int i11 = c1364v0.f26587d;
            if (i11 == Integer.MIN_VALUE) {
                i11 = c1364v0.f26588e;
            }
            c1364v0.f26584a = i11;
            int i12 = c1364v0.f26586c;
            if (i12 == Integer.MIN_VALUE) {
                i12 = c1364v0.f26589f;
            }
            c1364v0.f26585b = i12;
            return;
        }
        int i13 = c1364v0.f26586c;
        if (i13 == Integer.MIN_VALUE) {
            i13 = c1364v0.f26588e;
        }
        c1364v0.f26584a = i13;
        int i14 = c1364v0.f26587d;
        if (i14 == Integer.MIN_VALUE) {
            i14 = c1364v0.f26589f;
        }
        c1364v0.f26585b = i14;
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        n nVar;
        N0 n10 = new N0(super.onSaveInstanceState());
        h hVar = this.f15620W;
        if (hVar != null && (nVar = hVar.f15670b) != null) {
            n10.f26457c = nVar.f26065a;
        }
        n10.f26458d = p();
        return n10;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f15610L = false;
        }
        if (!this.f15610L) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f15610L = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f15610L = false;
        return true;
    }

    public final boolean p() {
        a aVar;
        ActionMenuView actionMenuView = this.f15621a;
        return (actionMenuView == null || (aVar = actionMenuView.f15372D) == null || !aVar.f()) ? false : true;
    }

    public final int q(View view, int i10, int i11, int[] iArr) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin - iArr[0];
        int iMax = Math.max(0, i12) + i10;
        iArr[0] = Math.max(0, -i12);
        int iJ = j(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iJ, iMax + measuredWidth, view.getMeasuredHeight() + iJ);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin + iMax;
    }

    public final int r(View view, int i10, int i11, int[] iArr) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin - iArr[1];
        int iMax = i10 - Math.max(0, i12);
        iArr[1] = Math.max(0, -i12);
        int iJ = j(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iJ, iMax, view.getMeasuredHeight() + iJ);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin);
    }

    public final int s(View view, int i10, int i11, int i12, int i13, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i14 = marginLayoutParams.leftMargin - iArr[0];
        int i15 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i15) + Math.max(0, i14);
        iArr[0] = Math.max(0, -i14);
        iArr[1] = Math.max(0, -i15);
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + iMax + i11, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i13, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public void setBackInvokedCallbackEnabled(boolean z3) {
        if (this.f15632f0 != z3) {
            this.f15632f0 = z3;
            w();
        }
    }

    public void setCollapseContentDescription(int i10) {
        setCollapseContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setCollapseIcon(int i10) {
        setCollapseIcon(p143m0.c.N(getContext(), i10));
    }

    public void setCollapsible(boolean z3) {
        this.f15626c0 = z3;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f15604F) {
            this.f15604F = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f15603E) {
            this.f15603E = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i10) {
        setLogo(p143m0.c.N(getContext(), i10));
    }

    public void setLogoDescription(int i10) {
        setLogoDescription(getContext().getText(i10));
    }

    public void setNavigationContentDescription(int i10) {
        setNavigationContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setNavigationIcon(int i10) {
        setNavigationIcon(p143m0.c.N(getContext(), i10));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.f15627d.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(M0 m2) {
        this.f15616S = m2;
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f15621a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i10) {
        if (this.f15638u != i10) {
            this.f15638u = i10;
            if (i10 == 0) {
                this.f15637t = getContext();
            } else {
                this.f15637t = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setSubtitle(int i10) {
        setSubtitle(getContext().getText(i10));
    }

    public void setSubtitleTextColor(int i10) {
        setSubtitleTextColor(ColorStateList.valueOf(i10));
    }

    public void setTitle(int i10) {
        setTitle(getContext().getText(i10));
    }

    public void setTitleMarginBottom(int i10) {
        this.f15601C = i10;
        requestLayout();
    }

    public void setTitleMarginEnd(int i10) {
        this.f15599A = i10;
        requestLayout();
    }

    public void setTitleMarginStart(int i10) {
        this.f15643z = i10;
        requestLayout();
    }

    public void setTitleMarginTop(int i10) {
        this.f15600B = i10;
        requestLayout();
    }

    public void setTitleTextColor(int i10) {
        setTitleTextColor(ColorStateList.valueOf(i10));
    }

    public final void t(View view, int i10, int i11, int i12, int i13) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i13 >= 0) {
            if (mode != 0) {
                i13 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i13);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean u(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final boolean v() {
        a aVar;
        ActionMenuView actionMenuView = this.f15621a;
        return (actionMenuView == null || (aVar = actionMenuView.f15372D) == null || !aVar.n()) ? false : true;
    }

    public final void w() {
        OnBackInvokedDispatcher onBackInvokedDispatcher;
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcherA = L0.a(this);
            h hVar = this.f15620W;
            boolean z3 = (hVar == null || hVar.f15670b == null || onBackInvokedDispatcherA == null || !isAttachedToWindow() || !this.f15632f0) ? false : true;
            if (z3 && this.f15630e0 == null) {
                if (this.f15628d0 == null) {
                    this.f15628d0 = L0.b(new K0(this, 0));
                }
                L0.c(onBackInvokedDispatcherA, this.f15628d0);
                this.f15630e0 = onBackInvokedDispatcherA;
                return;
            }
            if (z3 || (onBackInvokedDispatcher = this.f15630e0) == null) {
                return;
            }
            L0.d(onBackInvokedDispatcher, this.f15628d0);
            this.f15630e0 = null;
        }
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f15605G = 8388627;
        this.f15611N = new ArrayList();
        this.f15612O = new ArrayList();
        this.f15613P = new int[2];
        this.f15614Q = new Z2.f((Runnable) new K0(this, 1));
        this.f15615R = new ArrayList();
        this.f15617T = new p074g0.c((Object) this);
        this.f15633g0 = new F(this, 12);
        Context context2 = getContext();
        int[] iArr = p099i.a.f23284A;
        Z2.f fVarK = Z2.f.K(context2, attributeSet, iArr, i10);
        U.p(this, context, iArr, attributeSet, (TypedArray) fVarK.f14488b, i10);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        this.f15639v = typedArray.getResourceId(28, 0);
        this.f15640w = typedArray.getResourceId(19, 0);
        this.f15605G = typedArray.getInteger(0, 8388627);
        this.f15641x = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f15601C = dimensionPixelOffset;
        this.f15600B = dimensionPixelOffset;
        this.f15599A = dimensionPixelOffset;
        this.f15643z = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f15643z = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f15599A = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f15600B = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f15601C = dimensionPixelOffset5;
        }
        this.f15642y = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        C1364v0 c1364v0 = this.f15602D;
        c1364v0.f26591h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            c1364v0.f26588e = dimensionPixelSize;
            c1364v0.f26584a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            c1364v0.f26589f = dimensionPixelSize2;
            c1364v0.f26585b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            c1364v0.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f15603E = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f15604F = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f15631f = fVarK.D(4);
        this.f15634q = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f15637t = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableD = fVarK.D(16);
        if (drawableD != null) {
            setNavigationIcon(drawableD);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableD2 = fVarK.D(11);
        if (drawableD2 != null) {
            setLogo(drawableD2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(fVarK.C(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(fVarK.C(20));
        }
        if (typedArray.hasValue(14)) {
            m(typedArray.getResourceId(14, 0));
        }
        fVarK.P();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        AppCompatImageButton appCompatImageButton = this.f15635r;
        if (appCompatImageButton != null) {
            appCompatImageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f15635r.setImageDrawable(drawable);
        } else {
            AppCompatImageButton appCompatImageButton = this.f15635r;
            if (appCompatImageButton != null) {
                appCompatImageButton.setImageDrawable(this.f15631f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f15629e == null) {
                this.f15629e = new AppCompatImageView(getContext(), null);
            }
            if (!o(this.f15629e)) {
                b(this.f15629e, true);
            }
        } else {
            AppCompatImageView appCompatImageView = this.f15629e;
            if (appCompatImageView != null && o(appCompatImageView)) {
                removeView(this.f15629e);
                this.f15612O.remove(this.f15629e);
            }
        }
        AppCompatImageView appCompatImageView2 = this.f15629e;
        if (appCompatImageView2 != null) {
            appCompatImageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f15629e == null) {
            this.f15629e = new AppCompatImageView(getContext(), null);
        }
        AppCompatImageView appCompatImageView = this.f15629e;
        if (appCompatImageView != null) {
            appCompatImageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        AppCompatImageButton appCompatImageButton = this.f15627d;
        if (appCompatImageButton != null) {
            appCompatImageButton.setContentDescription(charSequence);
            com.bumptech.glide.d.J0(this.f15627d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!o(this.f15627d)) {
                b(this.f15627d, true);
            }
        } else {
            AppCompatImageButton appCompatImageButton = this.f15627d;
            if (appCompatImageButton != null && o(appCompatImageButton)) {
                removeView(this.f15627d);
                this.f15612O.remove(this.f15627d);
            }
        }
        AppCompatImageButton appCompatImageButton2 = this.f15627d;
        if (appCompatImageButton2 != null) {
            appCompatImageButton2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            AppCompatTextView appCompatTextView = this.f15625c;
            if (appCompatTextView != null && o(appCompatTextView)) {
                removeView(this.f15625c);
                this.f15612O.remove(this.f15625c);
            }
        } else {
            if (this.f15625c == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView2 = new AppCompatTextView(context, null);
                this.f15625c = appCompatTextView2;
                appCompatTextView2.setSingleLine();
                this.f15625c.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f15640w;
                if (i10 != 0) {
                    this.f15625c.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f15609K;
                if (colorStateList != null) {
                    this.f15625c.setTextColor(colorStateList);
                }
            }
            if (!o(this.f15625c)) {
                b(this.f15625c, true);
            }
        }
        AppCompatTextView appCompatTextView3 = this.f15625c;
        if (appCompatTextView3 != null) {
            appCompatTextView3.setText(charSequence);
        }
        this.f15607I = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f15609K = colorStateList;
        AppCompatTextView appCompatTextView = this.f15625c;
        if (appCompatTextView != null) {
            appCompatTextView.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            AppCompatTextView appCompatTextView = this.f15623b;
            if (appCompatTextView != null && o(appCompatTextView)) {
                removeView(this.f15623b);
                this.f15612O.remove(this.f15623b);
            }
        } else {
            if (this.f15623b == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView2 = new AppCompatTextView(context, null);
                this.f15623b = appCompatTextView2;
                appCompatTextView2.setSingleLine();
                this.f15623b.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f15639v;
                if (i10 != 0) {
                    this.f15623b.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f15608J;
                if (colorStateList != null) {
                    this.f15623b.setTextColor(colorStateList);
                }
            }
            if (!o(this.f15623b)) {
                b(this.f15623b, true);
            }
        }
        AppCompatTextView appCompatTextView3 = this.f15623b;
        if (appCompatTextView3 != null) {
            appCompatTextView3.setText(charSequence);
        }
        this.f15606H = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f15608J = colorStateList;
        AppCompatTextView appCompatTextView = this.f15623b;
        if (appCompatTextView != null) {
            appCompatTextView.setTextColor(colorStateList);
        }
    }
}
