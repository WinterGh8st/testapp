package androidx.appcompat.widget;

import I1.j;
import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import java.util.WeakHashMap;
import p053e3.M;
import p175p.C1359t;
import p175p.G0;
import p175p.H0;
import p175p.W0;
import p175p.Z;
import p200r1.D;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    public static final T4.c f15555e0 = new T4.c(Float.class, "thumbPos", 19);

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    public static final int[] f15556f0 = {R.attr.state_checked};

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public CharSequence f15557A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public CharSequence f15558B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f15559C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public int f15560D;

    /* JADX INFO: renamed from: E, reason: collision with root package name */
    public final int f15561E;

    /* JADX INFO: renamed from: F, reason: collision with root package name */
    public float f15562F;

    /* JADX INFO: renamed from: G, reason: collision with root package name */
    public float f15563G;

    /* JADX INFO: renamed from: H, reason: collision with root package name */
    public final VelocityTracker f15564H;

    /* JADX INFO: renamed from: I, reason: collision with root package name */
    public final int f15565I;

    /* JADX INFO: renamed from: J, reason: collision with root package name */
    public float f15566J;

    /* JADX INFO: renamed from: K, reason: collision with root package name */
    public int f15567K;

    /* JADX INFO: renamed from: L, reason: collision with root package name */
    public int f15568L;
    public int M;

    /* JADX INFO: renamed from: N, reason: collision with root package name */
    public int f15569N;

    /* JADX INFO: renamed from: O, reason: collision with root package name */
    public int f15570O;

    /* JADX INFO: renamed from: P, reason: collision with root package name */
    public int f15571P;

    /* JADX INFO: renamed from: Q, reason: collision with root package name */
    public int f15572Q;

    /* JADX INFO: renamed from: R, reason: collision with root package name */
    public boolean f15573R;

    /* JADX INFO: renamed from: S, reason: collision with root package name */
    public final TextPaint f15574S;

    /* JADX INFO: renamed from: T, reason: collision with root package name */
    public final ColorStateList f15575T;

    /* JADX INFO: renamed from: U, reason: collision with root package name */
    public StaticLayout f15576U;

    /* JADX INFO: renamed from: V, reason: collision with root package name */
    public StaticLayout f15577V;

    /* JADX INFO: renamed from: W, reason: collision with root package name */
    public final m.a f15578W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public Drawable f15579a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    public ObjectAnimator f15580a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ColorStateList f15581b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    public C1359t f15582b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public PorterDuff.Mode f15583c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    public G0 f15584c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f15585d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    public final Rect f15586d0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f15587e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public Drawable f15588f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ColorStateList f15589q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public PorterDuff.Mode f15590r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public boolean f15591s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public boolean f15592t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public int f15593u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public int f15594v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public int f15595w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f15596x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public CharSequence f15597y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public CharSequence f15598z;

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.flamingotools.ws.R.attr.switchStyle);
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15582b0 == null) {
            this.f15582b0 = new C1359t(this);
        }
        return this.f15582b0;
    }

    private boolean getTargetCheckedState() {
        return this.f15566J > 0.5f;
    }

    private int getThumbOffset() {
        boolean z3 = W0.f26495a;
        return (int) (((getLayoutDirection() == 1 ? 1.0f - this.f15566J : this.f15566J) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f15588f;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.f15586d0;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f15579a;
        Rect rectB = drawable2 != null ? Z.b(drawable2) : Z.f26506c;
        return ((((this.f15567K - this.M) - rect.left) - rect.right) - rectB.left) - rectB.right;
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f15557A = charSequence;
        C1359t emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod transformationMethodD0 = ((p143m0.c) emojiTextViewHelper.f26571b.f10735b).d0(this.f15578W);
        if (transformationMethodD0 != null) {
            charSequence = transformationMethodD0.getTransformation(charSequence, this);
        }
        this.f15558B = charSequence;
        this.f15577V = null;
        if (this.f15559C) {
            d();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f15597y = charSequence;
        C1359t emojiTextViewHelper = getEmojiTextViewHelper();
        TransformationMethod transformationMethodD0 = ((p143m0.c) emojiTextViewHelper.f26571b.f10735b).d0(this.f15578W);
        if (transformationMethodD0 != null) {
            charSequence = transformationMethodD0.getTransformation(charSequence, this);
        }
        this.f15598z = charSequence;
        this.f15576U = null;
        if (this.f15559C) {
            d();
        }
    }

    public final void a() {
        Drawable drawable = this.f15579a;
        if (drawable != null) {
            if (this.f15585d || this.f15587e) {
                Drawable drawableMutate = drawable.mutate();
                this.f15579a = drawableMutate;
                if (this.f15585d) {
                    p101i1.a.h(drawableMutate, this.f15581b);
                }
                if (this.f15587e) {
                    p101i1.a.i(this.f15579a, this.f15583c);
                }
                if (this.f15579a.isStateful()) {
                    this.f15579a.setState(getDrawableState());
                }
            }
        }
    }

    public final void b() {
        Drawable drawable = this.f15588f;
        if (drawable != null) {
            if (this.f15591s || this.f15592t) {
                Drawable drawableMutate = drawable.mutate();
                this.f15588f = drawableMutate;
                if (this.f15591s) {
                    p101i1.a.h(drawableMutate, this.f15589q);
                }
                if (this.f15592t) {
                    p101i1.a.i(this.f15588f, this.f15590r);
                }
                if (this.f15588f.isStateful()) {
                    this.f15588f.setState(getDrawableState());
                }
            }
        }
    }

    public final void c() {
        setTextOnInternal(this.f15597y);
        setTextOffInternal(this.f15557A);
        requestLayout();
    }

    public final void d() {
        if (this.f15584c0 == null && ((p143m0.c) this.f15582b0.f26571b.f10735b).T() && j.c()) {
            j jVarA = j.a();
            int iB = jVarA.b();
            if (iB == 3 || iB == 0) {
                G0 g10 = new G0(this);
                this.f15584c0 = g10;
                jVarA.g(g10);
            }
        }
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int i10;
        int i11;
        int i12 = this.f15569N;
        int i13 = this.f15570O;
        int i14 = this.f15571P;
        int i15 = this.f15572Q;
        int thumbOffset = getThumbOffset() + i12;
        Drawable drawable = this.f15579a;
        Rect rectB = drawable != null ? Z.b(drawable) : Z.f26506c;
        Drawable drawable2 = this.f15588f;
        Rect rect = this.f15586d0;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i16 = rect.left;
            thumbOffset += i16;
            if (rectB != null) {
                int i17 = rectB.left;
                if (i17 > i16) {
                    i12 += i17 - i16;
                }
                int i18 = rectB.top;
                int i19 = rect.top;
                i10 = i18 > i19 ? (i18 - i19) + i13 : i13;
                int i20 = rectB.right;
                int i21 = rect.right;
                if (i20 > i21) {
                    i14 -= i20 - i21;
                }
                int i22 = rectB.bottom;
                int i23 = rect.bottom;
                if (i22 > i23) {
                    i11 = i15 - (i22 - i23);
                }
                this.f15588f.setBounds(i12, i10, i14, i11);
            } else {
                i10 = i13;
            }
            i11 = i15;
            this.f15588f.setBounds(i12, i10, i14, i11);
        }
        Drawable drawable3 = this.f15579a;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i24 = thumbOffset - rect.left;
            int i25 = thumbOffset + this.M + rect.right;
            this.f15579a.setBounds(i24, i13, i25, i15);
            Drawable background = getBackground();
            if (background != null) {
                p101i1.a.f(background, i24, i13, i25, i15);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableHotspotChanged(float f10, float f11) {
        super.drawableHotspotChanged(f10, f11);
        Drawable drawable = this.f15579a;
        if (drawable != null) {
            p101i1.a.e(drawable, f10, f11);
        }
        Drawable drawable2 = this.f15588f;
        if (drawable2 != null) {
            p101i1.a.e(drawable2, f10, f11);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f15579a;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f15588f;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        boolean z3 = W0.f26495a;
        if (getLayoutDirection() != 1) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.f15567K;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f15595w : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        boolean z3 = W0.f26495a;
        if (getLayoutDirection() == 1) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.f15567K;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f15595w : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f15559C;
    }

    public boolean getSplitTrack() {
        return this.f15596x;
    }

    public int getSwitchMinWidth() {
        return this.f15594v;
    }

    public int getSwitchPadding() {
        return this.f15595w;
    }

    public CharSequence getTextOff() {
        return this.f15557A;
    }

    public CharSequence getTextOn() {
        return this.f15597y;
    }

    public Drawable getThumbDrawable() {
        return this.f15579a;
    }

    public final float getThumbPosition() {
        return this.f15566J;
    }

    public int getThumbTextPadding() {
        return this.f15593u;
    }

    public ColorStateList getThumbTintList() {
        return this.f15581b;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f15583c;
    }

    public Drawable getTrackDrawable() {
        return this.f15588f;
    }

    public ColorStateList getTrackTintList() {
        return this.f15589q;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.f15590r;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f15579a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f15588f;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.f15580a0;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.f15580a0.end();
        this.f15580a0 = null;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public int[] onCreateDrawableState(int i10) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i10 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f15556f0);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Drawable drawable = this.f15588f;
        Rect rect = this.f15586d0;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i10 = this.f15570O;
        int i11 = this.f15572Q;
        int i12 = i10 + rect.top;
        int i13 = i11 - rect.bottom;
        Drawable drawable2 = this.f15579a;
        if (drawable != null) {
            if (!this.f15596x || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectB = Z.b(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectB.left;
                rect.right -= rectB.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        StaticLayout staticLayout = getTargetCheckedState() ? this.f15576U : this.f15577V;
        if (staticLayout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.f15575T;
            TextPaint textPaint = this.f15574S;
            if (colorStateList != null) {
                textPaint.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            textPaint.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (staticLayout.getWidth() / 2), ((i12 + i13) / 2) - (staticLayout.getHeight() / 2));
            staticLayout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
        if (Build.VERSION.SDK_INT < 30) {
            CharSequence charSequence = isChecked() ? this.f15597y : this.f15557A;
            if (TextUtils.isEmpty(charSequence)) {
                return;
            }
            CharSequence text = accessibilityNodeInfo.getText();
            if (TextUtils.isEmpty(text)) {
                accessibilityNodeInfo.setText(charSequence);
                return;
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append(text);
            sb2.append(' ');
            sb2.append(charSequence);
            accessibilityNodeInfo.setText(sb2);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int iMax;
        int width;
        int paddingLeft;
        int height;
        int paddingTop;
        super.onLayout(z3, i10, i11, i12, i13);
        int iMax2 = 0;
        if (this.f15579a != null) {
            Drawable drawable = this.f15588f;
            Rect rect = this.f15586d0;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectB = Z.b(this.f15579a);
            iMax = Math.max(0, rectB.left - rect.left);
            iMax2 = Math.max(0, rectB.right - rect.right);
        } else {
            iMax = 0;
        }
        boolean z5 = W0.f26495a;
        if (getLayoutDirection() == 1) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.f15567K + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.f15567K) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity == 16) {
            int height2 = ((getHeight() + getPaddingTop()) - getPaddingBottom()) / 2;
            int i14 = this.f15568L;
            int i15 = height2 - (i14 / 2);
            height = i14 + i15;
            paddingTop = i15;
        } else if (gravity != 80) {
            paddingTop = getPaddingTop();
            height = this.f15568L + paddingTop;
        } else {
            height = getHeight() - getPaddingBottom();
            paddingTop = height - this.f15568L;
        }
        this.f15569N = paddingLeft;
        this.f15570O = paddingTop;
        this.f15572Q = height;
        this.f15571P = width;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onMeasure(int i10, int i11) {
        int intrinsicWidth;
        int intrinsicHeight;
        int iMax;
        int intrinsicHeight2 = 0;
        if (this.f15559C) {
            StaticLayout staticLayout = this.f15576U;
            TextPaint textPaint = this.f15574S;
            if (staticLayout == null) {
                CharSequence charSequence = this.f15598z;
                this.f15576U = new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
            if (this.f15577V == null) {
                CharSequence charSequence2 = this.f15558B;
                this.f15577V = new StaticLayout(charSequence2, textPaint, charSequence2 != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence2, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
            }
        }
        Drawable drawable = this.f15579a;
        Rect rect = this.f15586d0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f15579a.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f15579a.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        if (this.f15559C) {
            iMax = (this.f15593u * 2) + Math.max(this.f15576U.getWidth(), this.f15577V.getWidth());
        } else {
            iMax = 0;
        }
        this.M = Math.max(iMax, intrinsicWidth);
        Drawable drawable2 = this.f15588f;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f15588f.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax2 = rect.left;
        int iMax3 = rect.right;
        Drawable drawable3 = this.f15579a;
        if (drawable3 != null) {
            Rect rectB = Z.b(drawable3);
            iMax2 = Math.max(iMax2, rectB.left);
            iMax3 = Math.max(iMax3, rectB.right);
        }
        int iMax4 = this.f15573R ? Math.max(this.f15594v, (this.M * 2) + iMax2 + iMax3) : this.f15594v;
        int iMax5 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.f15567K = iMax4;
        this.f15568L = iMax5;
        super.onMeasure(i10, i11);
        if (getMeasuredHeight() < iMax5) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax5);
        }
    }

    @Override // android.view.View
    public final void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f15597y : this.f15557A;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:40:0x008e  */
    /* JADX WARN: Code duplicated, block: B:42:0x0093  */
    /* JADX WARN: Code duplicated, block: B:47:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:50:0x00aa  */
    /* JADX WARN: Code duplicated, block: B:52:0x00be  */
    /* JADX WARN: Code duplicated, block: B:61:0x00d3  */
    /* JADX WARN: Code duplicated, block: B:62:0x00d8  */
    /* JADX WARN: Code duplicated, block: B:64:0x00db  */
    /* JADX WARN: Code duplicated, block: B:67:0x00f2  */
    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z3;
        boolean zIsChecked;
        boolean targetCheckedState;
        float xVelocity;
        float f10;
        VelocityTracker velocityTracker = this.f15564H;
        velocityTracker.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int i10 = this.f15561E;
        if (actionMasked != 0) {
            float f11 = 0.0f;
            if (actionMasked == 1) {
                if (this.f15560D == 2) {
                    this.f15560D = 0;
                    if (motionEvent.getAction() == 1 || !isEnabled()) {
                        z3 = false;
                    } else {
                        z3 = true;
                    }
                    zIsChecked = isChecked();
                    if (z3) {
                        velocityTracker.computeCurrentVelocity(1000);
                        xVelocity = velocityTracker.getXVelocity();
                        if (Math.abs(xVelocity) > this.f15565I) {
                            boolean z5 = W0.f26495a;
                            targetCheckedState = getLayoutDirection() == 1 ? xVelocity > 0.0f : xVelocity < 0.0f;
                        } else {
                            targetCheckedState = getTargetCheckedState();
                        }
                    } else {
                        targetCheckedState = zIsChecked;
                    }
                    if (targetCheckedState != zIsChecked) {
                        playSoundEffect(0);
                    }
                    setChecked(targetCheckedState);
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.setAction(3);
                    super.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                    super.onTouchEvent(motionEvent);
                    return true;
                }
                this.f15560D = 0;
                velocityTracker.clear();
            } else if (actionMasked == 2) {
                int i11 = this.f15560D;
                if (i11 == 1) {
                    float x10 = motionEvent.getX();
                    float y10 = motionEvent.getY();
                    float f12 = i10;
                    if (Math.abs(x10 - this.f15562F) > f12 || Math.abs(y10 - this.f15563G) > f12) {
                        this.f15560D = 2;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        this.f15562F = x10;
                        this.f15563G = y10;
                        return true;
                    }
                } else if (i11 == 2) {
                    float x11 = motionEvent.getX();
                    int thumbScrollRange = getThumbScrollRange();
                    float f13 = x11 - this.f15562F;
                    if (thumbScrollRange != 0) {
                        f10 = f13 / thumbScrollRange;
                    } else {
                        f10 = f13 > 0.0f ? 1.0f : -1.0f;
                    }
                    boolean z10 = W0.f26495a;
                    if (getLayoutDirection() == 1) {
                        f10 = -f10;
                    }
                    float f14 = this.f15566J;
                    float f15 = f10 + f14;
                    if (f15 >= 0.0f) {
                        f11 = f15 > 1.0f ? 1.0f : f15;
                    }
                    if (f11 != f14) {
                        this.f15562F = x11;
                        setThumbPosition(f11);
                    }
                    return true;
                }
            } else if (actionMasked == 3) {
                if (this.f15560D == 2) {
                    this.f15560D = 0;
                    if (motionEvent.getAction() == 1) {
                        z3 = false;
                    } else {
                        z3 = false;
                    }
                    zIsChecked = isChecked();
                    if (z3) {
                        velocityTracker.computeCurrentVelocity(1000);
                        xVelocity = velocityTracker.getXVelocity();
                        if (Math.abs(xVelocity) > this.f15565I) {
                            boolean z11 = W0.f26495a;
                            if (getLayoutDirection() == 1) {
                            }
                        } else {
                            targetCheckedState = getTargetCheckedState();
                        }
                    } else {
                        targetCheckedState = zIsChecked;
                    }
                    if (targetCheckedState != zIsChecked) {
                        playSoundEffect(0);
                    }
                    setChecked(targetCheckedState);
                    MotionEvent motionEventObtain2 = MotionEvent.obtain(motionEvent);
                    motionEventObtain2.setAction(3);
                    super.onTouchEvent(motionEventObtain2);
                    motionEventObtain2.recycle();
                    super.onTouchEvent(motionEvent);
                    return true;
                }
                this.f15560D = 0;
                velocityTracker.clear();
            }
        } else {
            float x12 = motionEvent.getX();
            float y11 = motionEvent.getY();
            if (isEnabled() && this.f15579a != null) {
                int thumbOffset = getThumbOffset();
                Drawable drawable = this.f15579a;
                Rect rect = this.f15586d0;
                drawable.getPadding(rect);
                int i12 = this.f15570O - i10;
                int i13 = (this.f15569N + thumbOffset) - i10;
                int i14 = this.M + i13 + rect.left + rect.right + i10;
                int i15 = this.f15572Q + i10;
                if (x12 > i13 && x12 < i14 && y11 > i12 && y11 < i15) {
                    this.f15560D = 1;
                    this.f15562F = x12;
                    this.f15563G = y11;
                }
            }
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z3) {
        super.setChecked(z3);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            if (Build.VERSION.SDK_INT >= 30) {
                Object string = this.f15597y;
                if (string == null) {
                    string = getResources().getString(com.flamingotools.ws.R.string.abc_capital_on);
                }
                Object obj = string;
                WeakHashMap weakHashMap = U.f27683a;
                new D(com.flamingotools.ws.R.id.tag_state_description, CharSequence.class, 64, 30, 2).i(this, obj);
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            Object string2 = this.f15557A;
            if (string2 == null) {
                string2 = getResources().getString(com.flamingotools.ws.R.string.abc_capital_off);
            }
            Object obj2 = string2;
            WeakHashMap weakHashMap2 = U.f27683a;
            new D(com.flamingotools.ws.R.id.tag_state_description, CharSequence.class, 64, 30, 2).i(this, obj2);
        }
        if (getWindowToken() == null || !isLaidOut()) {
            ObjectAnimator objectAnimator = this.f15580a0;
            if (objectAnimator != null) {
                objectAnimator.cancel();
            }
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
            return;
        }
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, f15555e0, zIsChecked ? 1.0f : 0.0f);
        this.f15580a0 = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        this.f15580a0.setAutoCancel(true);
        this.f15580a0.start();
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
        setTextOnInternal(this.f15597y);
        setTextOffInternal(this.f15557A);
        requestLayout();
    }

    public final void setEnforceSwitchWidth(boolean z3) {
        this.f15573R = z3;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z3) {
        if (this.f15559C != z3) {
            this.f15559C = z3;
            requestLayout();
            if (z3) {
                d();
            }
        }
    }

    public void setSplitTrack(boolean z3) {
        this.f15596x = z3;
        invalidate();
    }

    public void setSwitchMinWidth(int i10) {
        this.f15594v = i10;
        requestLayout();
    }

    public void setSwitchPadding(int i10) {
        this.f15595w = i10;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        TextPaint textPaint = this.f15574S;
        if ((textPaint.getTypeface() == null || textPaint.getTypeface().equals(typeface)) && (textPaint.getTypeface() != null || typeface == null)) {
            return;
        }
        textPaint.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f15557A;
        if (string == null) {
            string = getResources().getString(com.flamingotools.ws.R.string.abc_capital_off);
        }
        WeakHashMap weakHashMap = U.f27683a;
        new D(com.flamingotools.ws.R.id.tag_state_description, CharSequence.class, 64, 30, 2).i(this, string);
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (!isChecked() || Build.VERSION.SDK_INT < 30) {
            return;
        }
        Object string = this.f15597y;
        if (string == null) {
            string = getResources().getString(com.flamingotools.ws.R.string.abc_capital_on);
        }
        WeakHashMap weakHashMap = U.f27683a;
        new D(com.flamingotools.ws.R.id.tag_state_description, CharSequence.class, 64, 30, 2).i(this, string);
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f15579a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f15579a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setThumbPosition(float f10) {
        this.f15566J = f10;
        invalidate();
    }

    public void setThumbResource(int i10) {
        setThumbDrawable(p143m0.c.N(getContext(), i10));
    }

    public void setThumbTextPadding(int i10) {
        this.f15593u = i10;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f15581b = colorStateList;
        this.f15585d = true;
        a();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f15583c = mode;
        this.f15587e = true;
        a();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f15588f;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f15588f = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i10) {
        setTrackDrawable(p143m0.c.N(getContext(), i10));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f15589q = colorStateList;
        this.f15591s = true;
        b();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.f15590r = mode;
        this.f15592t = true;
        b();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f15579a || drawable == this.f15588f;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i10) {
        Typeface typeface;
        int resourceId;
        super(context, attributeSet, i10);
        this.f15581b = null;
        this.f15583c = null;
        this.f15585d = false;
        this.f15587e = false;
        this.f15589q = null;
        this.f15590r = null;
        this.f15591s = false;
        this.f15592t = false;
        this.f15564H = VelocityTracker.obtain();
        this.f15573R = true;
        this.f15586d0 = new Rect();
        H0.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.f15574S = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = p099i.a.f23311y;
        Z2.f fVarK = Z2.f.K(context, attributeSet, iArr, i10);
        U.p(this, context, iArr, attributeSet, (TypedArray) fVarK.f14488b, i10);
        Drawable drawableD = fVarK.D(2);
        this.f15579a = drawableD;
        if (drawableD != null) {
            drawableD.setCallback(this);
        }
        Drawable drawableD2 = fVarK.D(11);
        this.f15588f = drawableD2;
        if (drawableD2 != null) {
            drawableD2.setCallback(this);
        }
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        setTextOnInternal(typedArray.getText(0));
        setTextOffInternal(typedArray.getText(1));
        this.f15559C = typedArray.getBoolean(3, true);
        this.f15593u = typedArray.getDimensionPixelSize(8, 0);
        this.f15594v = typedArray.getDimensionPixelSize(5, 0);
        this.f15595w = typedArray.getDimensionPixelSize(6, 0);
        this.f15596x = typedArray.getBoolean(4, false);
        ColorStateList colorStateListC = fVarK.C(9);
        if (colorStateListC != null) {
            this.f15581b = colorStateListC;
            this.f15585d = true;
        }
        PorterDuff.Mode modeC = Z.c(typedArray.getInt(10, -1), null);
        if (this.f15583c != modeC) {
            this.f15583c = modeC;
            this.f15587e = true;
        }
        if (this.f15585d || this.f15587e) {
            a();
        }
        ColorStateList colorStateListC2 = fVarK.C(12);
        if (colorStateListC2 != null) {
            this.f15589q = colorStateListC2;
            this.f15591s = true;
        }
        PorterDuff.Mode modeC2 = Z.c(typedArray.getInt(13, -1), null);
        if (this.f15590r != modeC2) {
            this.f15590r = modeC2;
            this.f15592t = true;
        }
        if (this.f15591s || this.f15592t) {
            b();
        }
        int resourceId2 = typedArray.getResourceId(7, 0);
        if (resourceId2 != 0) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(resourceId2, p099i.a.f23312z);
            ColorStateList colorStateList = (!typedArrayObtainStyledAttributes.hasValue(3) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(3, 0)) == 0 || (colorStateList = p063f1.h.getColorStateList(context, resourceId)) == null) ? typedArrayObtainStyledAttributes.getColorStateList(3) : colorStateList;
            if (colorStateList != null) {
                this.f15575T = colorStateList;
            } else {
                this.f15575T = getTextColors();
            }
            int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
            if (dimensionPixelSize != 0) {
                float f10 = dimensionPixelSize;
                if (f10 != textPaint.getTextSize()) {
                    textPaint.setTextSize(f10);
                    requestLayout();
                }
            }
            int i11 = typedArrayObtainStyledAttributes.getInt(1, -1);
            int i12 = typedArrayObtainStyledAttributes.getInt(2, -1);
            if (i11 == 1) {
                typeface = Typeface.SANS_SERIF;
            } else if (i11 != 2) {
                typeface = i11 != 3 ? null : Typeface.MONOSPACE;
            } else {
                typeface = Typeface.SERIF;
            }
            if (i12 > 0) {
                Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i12) : Typeface.create(typeface, i12);
                setSwitchTypeface(typefaceDefaultFromStyle);
                int i13 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i12;
                textPaint.setFakeBoldText((i13 & 1) != 0);
                textPaint.setTextSkewX((2 & i13) != 0 ? -0.25f : 0.0f);
            } else {
                textPaint.setFakeBoldText(false);
                textPaint.setTextSkewX(0.0f);
                setSwitchTypeface(typeface);
            }
            if (typedArrayObtainStyledAttributes.getBoolean(14, false)) {
                Context context2 = getContext();
                m.a aVar = new m.a();
                aVar.f24810a = context2.getResources().getConfiguration().locale;
                this.f15578W = aVar;
            } else {
                this.f15578W = null;
            }
            setTextOnInternal(this.f15597y);
            setTextOffInternal(this.f15557A);
            typedArrayObtainStyledAttributes.recycle();
        }
        new M(this).l(attributeSet, i10);
        fVarK.P();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f15561E = viewConfiguration.getScaledTouchSlop();
        this.f15565I = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().b(attributeSet, i10);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
