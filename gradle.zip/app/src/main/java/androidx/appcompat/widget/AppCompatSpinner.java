package androidx.appcompat.widget;

import B.P;
import Y4.o;
import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import p175p.A;
import p175p.AbstractC1369z;
import p175p.B;
import p175p.C1368y;
import p175p.D;
import p175p.E;
import p175p.F;
import p175p.H0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatSpinner extends Spinner {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static final int[] f15436s = {R.attr.spinnerMode};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15437a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f15438b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final C1368y f15439c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public SpinnerAdapter f15440d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final boolean f15441e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final F f15442f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public int f15443q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final Rect f15444r;

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, -1);
    }

    public final int a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i10 = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int iMax = Math.max(0, getSelectedItemPosition());
        int iMin = Math.min(spinnerAdapter.getCount(), iMax + 15);
        View view = null;
        int iMax2 = 0;
        for (int iMax3 = Math.max(0, iMax - (15 - (iMin - iMax))); iMax3 < iMin; iMax3++) {
            int itemViewType = spinnerAdapter.getItemViewType(iMax3);
            if (itemViewType != i10) {
                view = null;
                i10 = itemViewType;
            }
            view = spinnerAdapter.getView(iMax3, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
            iMax2 = Math.max(iMax2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return iMax2;
        }
        Rect rect = this.f15444r;
        drawable.getPadding(rect);
        return rect.left + rect.right + iMax2;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15437a;
        if (p10 != null) {
            p10.a();
        }
    }

    @Override // android.widget.Spinner
    public int getDropDownHorizontalOffset() {
        F f10 = this.f15442f;
        return f10 != null ? f10.a() : super.getDropDownHorizontalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownVerticalOffset() {
        F f10 = this.f15442f;
        return f10 != null ? f10.m() : super.getDropDownVerticalOffset();
    }

    @Override // android.widget.Spinner
    public int getDropDownWidth() {
        return this.f15442f != null ? this.f15443q : super.getDropDownWidth();
    }

    public final F getInternalPopup() {
        return this.f15442f;
    }

    @Override // android.widget.Spinner
    public Drawable getPopupBackground() {
        F f10 = this.f15442f;
        return f10 != null ? f10.d() : super.getPopupBackground();
    }

    @Override // android.widget.Spinner
    public Context getPopupContext() {
        return this.f15438b;
    }

    @Override // android.widget.Spinner
    public CharSequence getPrompt() {
        F f10 = this.f15442f;
        return f10 != null ? f10.o() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15437a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15437a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    @Override // android.widget.Spinner, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        F f10 = this.f15442f;
        if (f10 == null || !f10.b()) {
            return;
        }
        f10.dismiss();
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
        if (this.f15442f == null || View.MeasureSpec.getMode(i10) != Integer.MIN_VALUE) {
            return;
        }
        setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i10)), getMeasuredHeight());
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        E e10 = (E) parcelable;
        super.onRestoreInstanceState(e10.getSuperState());
        if (!e10.f26418a || (viewTreeObserver = getViewTreeObserver()) == null) {
            return;
        }
        viewTreeObserver.addOnGlobalLayoutListener(new o(this, 4));
    }

    @Override // android.widget.Spinner, android.widget.AbsSpinner, android.view.View
    public final Parcelable onSaveInstanceState() {
        E e10 = new E(super.onSaveInstanceState());
        F f10 = this.f15442f;
        e10.f26418a = f10 != null && f10.b();
        return e10;
    }

    @Override // android.widget.Spinner, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C1368y c1368y = this.f15439c;
        if (c1368y == null || !c1368y.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.widget.Spinner, android.view.View
    public final boolean performClick() {
        F f10 = this.f15442f;
        if (f10 == null) {
            return super.performClick();
        }
        if (f10.b()) {
            return true;
        }
        this.f15442f.l(getTextDirection(), getTextAlignment());
        return true;
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15437a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15437a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownHorizontalOffset(int i10) {
        F f10 = this.f15442f;
        if (f10 == null) {
            super.setDropDownHorizontalOffset(i10);
        } else {
            f10.j(i10);
            f10.k(i10);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownVerticalOffset(int i10) {
        F f10 = this.f15442f;
        if (f10 != null) {
            f10.i(i10);
        } else {
            super.setDropDownVerticalOffset(i10);
        }
    }

    @Override // android.widget.Spinner
    public void setDropDownWidth(int i10) {
        if (this.f15442f != null) {
            this.f15443q = i10;
        } else {
            super.setDropDownWidth(i10);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundDrawable(Drawable drawable) {
        F f10 = this.f15442f;
        if (f10 != null) {
            f10.h(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    @Override // android.widget.Spinner
    public void setPopupBackgroundResource(int i10) {
        setPopupBackgroundDrawable(p143m0.c.N(getPopupContext(), i10));
    }

    @Override // android.widget.Spinner
    public void setPrompt(CharSequence charSequence) {
        F f10 = this.f15442f;
        if (f10 != null) {
            f10.g(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15437a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15437a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    /* JADX WARN: Code duplicated, block: B:26:0x0065  */
    /* JADX WARN: Code duplicated, block: B:30:0x006d A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:32:0x0070  */
    /* JADX WARN: Code duplicated, block: B:33:0x00a3  */
    /* JADX WARN: Code duplicated, block: B:36:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:39:0x00d0  */
    public AppCompatSpinner(Context context, AttributeSet attributeSet, int i10) throws Throwable {
        TypedArray typedArrayObtainStyledAttributes;
        CharSequence[] textArray;
        SpinnerAdapter spinnerAdapter;
        super(context, attributeSet, com.flamingotools.ws.R.attr.spinnerStyle);
        this.f15444r = new Rect();
        H0.a(this, getContext());
        int[] iArr = p099i.a.f23310x;
        Z2.f fVarK = Z2.f.K(context, attributeSet, iArr, com.flamingotools.ws.R.attr.spinnerStyle);
        this.f15437a = new P(this);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        int resourceId = typedArray.getResourceId(4, 0);
        if (resourceId != 0) {
            this.f15438b = new p153n.c(context, resourceId);
        } else {
            this.f15438b = context;
        }
        TypedArray typedArray2 = null;
        if (i10 == -1) {
            try {
                typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f15436s, com.flamingotools.ws.R.attr.spinnerStyle, 0);
                try {
                    try {
                        if (typedArrayObtainStyledAttributes.hasValue(0)) {
                            i10 = typedArrayObtainStyledAttributes.getInt(0, 0);
                        }
                    } catch (Throwable th) {
                        th = th;
                        typedArray2 = typedArrayObtainStyledAttributes;
                        if (typedArray2 != null) {
                            typedArray2.recycle();
                        }
                        throw th;
                    }
                } catch (Exception e10) {
                    e = e10;
                    Log.i("AppCompatSpinner", "Could not read android:spinnerMode", e);
                    if (typedArrayObtainStyledAttributes != null) {
                    }
                    if (i10 != 0) {
                        A a3 = new A(this);
                        this.f15442f = a3;
                        a3.f26401c = typedArray.getString(2);
                    } else if (i10 == 1) {
                        D d10 = new D(this, this.f15438b, attributeSet);
                        Z2.f fVarK2 = Z2.f.K(this.f15438b, attributeSet, iArr, com.flamingotools.ws.R.attr.spinnerStyle);
                        this.f15443q = ((TypedArray) fVarK2.f14488b).getLayoutDimension(3, -2);
                        d10.h(fVarK2.D(1));
                        d10.M = typedArray.getString(2);
                        fVarK2.P();
                        this.f15442f = d10;
                        this.f15439c = new C1368y(this, this, d10);
                    }
                    textArray = typedArray.getTextArray(0);
                    if (textArray != null) {
                        ArrayAdapter arrayAdapter = new ArrayAdapter(context, R.layout.simple_spinner_item, textArray);
                        arrayAdapter.setDropDownViewResource(com.flamingotools.ws.R.layout.support_simple_spinner_dropdown_item);
                        setAdapter((SpinnerAdapter) arrayAdapter);
                    }
                    fVarK.P();
                    this.f15441e = true;
                    spinnerAdapter = this.f15440d;
                    if (spinnerAdapter != null) {
                        setAdapter(spinnerAdapter);
                        this.f15440d = null;
                    }
                    this.f15437a.o(attributeSet, com.flamingotools.ws.R.attr.spinnerStyle);
                }
            } catch (Exception e11) {
                e = e11;
                typedArrayObtainStyledAttributes = null;
            } catch (Throwable th2) {
                th = th2;
                if (typedArray2 != null) {
                    typedArray2.recycle();
                }
                throw th;
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        if (i10 != 0) {
            A a9 = new A(this);
            this.f15442f = a9;
            a9.f26401c = typedArray.getString(2);
        } else if (i10 == 1) {
            D d11 = new D(this, this.f15438b, attributeSet);
            Z2.f fVarK3 = Z2.f.K(this.f15438b, attributeSet, iArr, com.flamingotools.ws.R.attr.spinnerStyle);
            this.f15443q = ((TypedArray) fVarK3.f14488b).getLayoutDimension(3, -2);
            d11.h(fVarK3.D(1));
            d11.M = typedArray.getString(2);
            fVarK3.P();
            this.f15442f = d11;
            this.f15439c = new C1368y(this, this, d11);
        }
        textArray = typedArray.getTextArray(0);
        if (textArray != null) {
            ArrayAdapter arrayAdapter2 = new ArrayAdapter(context, R.layout.simple_spinner_item, textArray);
            arrayAdapter2.setDropDownViewResource(com.flamingotools.ws.R.layout.support_simple_spinner_dropdown_item);
            setAdapter((SpinnerAdapter) arrayAdapter2);
        }
        fVarK.P();
        this.f15441e = true;
        spinnerAdapter = this.f15440d;
        if (spinnerAdapter != null) {
            setAdapter(spinnerAdapter);
            this.f15440d = null;
        }
        this.f15437a.o(attributeSet, com.flamingotools.ws.R.attr.spinnerStyle);
    }

    @Override // android.widget.AdapterView
    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f15441e) {
            this.f15440d = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        F f10 = this.f15442f;
        if (f10 != null) {
            Context context = this.f15438b;
            if (context == null) {
                context = getContext();
            }
            Resources.Theme theme = context.getTheme();
            B b10 = new B();
            b10.f26403a = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                b10.f26404b = (ListAdapter) spinnerAdapter;
            }
            if (theme != null && (spinnerAdapter instanceof ThemedSpinnerAdapter)) {
                AbstractC1369z.a((ThemedSpinnerAdapter) spinnerAdapter, theme);
            }
            f10.p(b10);
        }
    }
}
