package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import com.flamingotools.ws.R;
import p175p.O0;
import p175p.W;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public final class i implements W {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final Toolbar f15672a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public int f15673b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View f15674c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Drawable f15675d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public Drawable f15676e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final Drawable f15677f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f15678g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public CharSequence f15679h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public final CharSequence f15680i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public final CharSequence f15681j;
    public Window.Callback k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public boolean f15682l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public a f15683m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public final int f15684n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public final Drawable f15685o;

    public i(Toolbar toolbar, boolean z3) {
        Drawable drawable;
        this.f15684n = 0;
        this.f15672a = toolbar;
        this.f15679h = toolbar.getTitle();
        this.f15680i = toolbar.getSubtitle();
        this.f15678g = this.f15679h != null;
        this.f15677f = toolbar.getNavigationIcon();
        Z2.f fVarK = Z2.f.K(toolbar.getContext(), null, p099i.a.f23288a, R.attr.actionBarStyle);
        int i10 = 15;
        this.f15685o = fVarK.D(15);
        if (z3) {
            TypedArray typedArray = (TypedArray) fVarK.f14488b;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                this.f15678g = true;
                this.f15679h = text;
                if ((this.f15673b & 8) != 0) {
                    Toolbar toolbar2 = this.f15672a;
                    toolbar2.setTitle(text);
                    if (this.f15678g) {
                        U.r(toolbar2.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                this.f15680i = text2;
                if ((this.f15673b & 8) != 0) {
                    toolbar.setSubtitle(text2);
                }
            }
            Drawable drawableD = fVarK.D(20);
            if (drawableD != null) {
                this.f15676e = drawableD;
                d();
            }
            Drawable drawableD2 = fVarK.D(17);
            if (drawableD2 != null) {
                this.f15675d = drawableD2;
                d();
            }
            if (this.f15677f == null && (drawable = this.f15685o) != null) {
                this.f15677f = drawable;
                int i11 = this.f15673b & 4;
                Toolbar toolbar3 = this.f15672a;
                if (i11 != 0) {
                    toolbar3.setNavigationIcon(drawable);
                } else {
                    toolbar3.setNavigationIcon((Drawable) null);
                }
            }
            b(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                a(LayoutInflater.from(toolbar.getContext()).inflate(resourceId, (ViewGroup) toolbar, false));
                b(this.f15673b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = toolbar.getLayoutParams();
                layoutParams.height = layoutDimension;
                toolbar.setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                toolbar.d();
                toolbar.f15602D.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = toolbar.getContext();
                toolbar.f15639v = resourceId2;
                AppCompatTextView appCompatTextView = toolbar.f15623b;
                if (appCompatTextView != null) {
                    appCompatTextView.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = toolbar.getContext();
                toolbar.f15640w = resourceId3;
                AppCompatTextView appCompatTextView2 = toolbar.f15625c;
                if (appCompatTextView2 != null) {
                    appCompatTextView2.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                toolbar.setPopupTheme(resourceId4);
            }
        } else {
            if (toolbar.getNavigationIcon() != null) {
                this.f15685o = toolbar.getNavigationIcon();
            } else {
                i10 = 11;
            }
            this.f15673b = i10;
        }
        fVarK.P();
        if (R.string.abc_action_bar_up_description != this.f15684n) {
            this.f15684n = R.string.abc_action_bar_up_description;
            if (TextUtils.isEmpty(toolbar.getNavigationContentDescription())) {
                int i12 = this.f15684n;
                this.f15681j = i12 != 0 ? toolbar.getContext().getString(i12) : null;
                c();
            }
        }
        this.f15681j = toolbar.getNavigationContentDescription();
        toolbar.setNavigationOnClickListener(new O0(this));
    }

    public final void a(View view) {
        View view2 = this.f15674c;
        Toolbar toolbar = this.f15672a;
        if (view2 != null && (this.f15673b & 16) != 0) {
            toolbar.removeView(view2);
        }
        this.f15674c = view;
        if (view == null || (this.f15673b & 16) == 0) {
            return;
        }
        toolbar.addView(view);
    }

    public final void b(int i10) {
        View view;
        int i11 = this.f15673b ^ i10;
        this.f15673b = i10;
        if (i11 != 0) {
            if ((i11 & 4) != 0) {
                if ((i10 & 4) != 0) {
                    c();
                }
                int i12 = this.f15673b & 4;
                Toolbar toolbar = this.f15672a;
                if (i12 != 0) {
                    Drawable drawable = this.f15677f;
                    if (drawable == null) {
                        drawable = this.f15685o;
                    }
                    toolbar.setNavigationIcon(drawable);
                } else {
                    toolbar.setNavigationIcon((Drawable) null);
                }
            }
            if ((i11 & 3) != 0) {
                d();
            }
            int i13 = i11 & 8;
            Toolbar toolbar2 = this.f15672a;
            if (i13 != 0) {
                if ((i10 & 8) != 0) {
                    toolbar2.setTitle(this.f15679h);
                    toolbar2.setSubtitle(this.f15680i);
                } else {
                    toolbar2.setTitle((CharSequence) null);
                    toolbar2.setSubtitle((CharSequence) null);
                }
            }
            if ((i11 & 16) == 0 || (view = this.f15674c) == null) {
                return;
            }
            if ((i10 & 16) != 0) {
                toolbar2.addView(view);
            } else {
                toolbar2.removeView(view);
            }
        }
    }

    public final void c() {
        if ((this.f15673b & 4) != 0) {
            boolean zIsEmpty = TextUtils.isEmpty(this.f15681j);
            Toolbar toolbar = this.f15672a;
            if (zIsEmpty) {
                toolbar.setNavigationContentDescription(this.f15684n);
            } else {
                toolbar.setNavigationContentDescription(this.f15681j);
            }
        }
    }

    public final void d() {
        Drawable drawable;
        int i10 = this.f15673b;
        if ((i10 & 2) == 0) {
            drawable = null;
        } else if ((i10 & 1) == 0 || (drawable = this.f15676e) == null) {
            drawable = this.f15675d;
        }
        this.f15672a.setLogo(drawable);
    }
}
