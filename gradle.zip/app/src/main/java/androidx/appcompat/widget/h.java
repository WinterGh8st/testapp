package androidx.appcompat.widget;

import android.content.Context;
import android.os.Parcelable;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.ArrayList;
import p164o.D;
import p164o.l;
import p164o.n;
import p164o.x;

/* JADX INFO: loaded from: classes.dex */
public final class h implements x {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l f15669a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public n f15670b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Toolbar f15671c;

    public h(Toolbar toolbar) {
        this.f15671c = toolbar;
    }

    @Override // p164o.x
    public final void e(boolean z3) {
        if (this.f15670b != null) {
            l lVar = this.f15669a;
            if (lVar != null) {
                int size = lVar.f26039f.size();
                for (int i10 = 0; i10 < size; i10++) {
                    if (this.f15669a.getItem(i10) == this.f15670b) {
                        return;
                    }
                }
            }
            m(this.f15670b);
        }
    }

    @Override // p164o.x
    public final boolean g(n nVar) {
        Toolbar toolbar = this.f15671c;
        toolbar.c();
        ViewParent parent = toolbar.f15635r.getParent();
        if (parent != toolbar) {
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(toolbar.f15635r);
            }
            toolbar.addView(toolbar.f15635r);
        }
        View actionView = nVar.getActionView();
        toolbar.f15636s = actionView;
        this.f15670b = nVar;
        ViewParent parent2 = actionView.getParent();
        if (parent2 != toolbar) {
            if (parent2 instanceof ViewGroup) {
                ((ViewGroup) parent2).removeView(toolbar.f15636s);
            }
            Toolbar.LayoutParams layoutParamsH = Toolbar.h();
            layoutParamsH.f15277a = (toolbar.f15641x & 112) | 8388611;
            layoutParamsH.f15644b = 2;
            toolbar.f15636s.setLayoutParams(layoutParamsH);
            toolbar.addView(toolbar.f15636s);
        }
        for (int childCount = toolbar.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = toolbar.getChildAt(childCount);
            if (((Toolbar.LayoutParams) childAt.getLayoutParams()).f15644b != 2 && childAt != toolbar.f15621a) {
                toolbar.removeViewAt(childCount);
                toolbar.f15612O.add(childAt);
            }
        }
        toolbar.requestLayout();
        nVar.M = true;
        nVar.f26078x.p(false);
        KeyEvent.Callback callback = toolbar.f15636s;
        if (callback instanceof p153n.b) {
            ((p153n.b) callback).b();
        }
        toolbar.w();
        return true;
    }

    @Override // p164o.x
    public final int getId() {
        return 0;
    }

    @Override // p164o.x
    public final void i(Context context, l lVar) {
        n nVar;
        l lVar2 = this.f15669a;
        if (lVar2 != null && (nVar = this.f15670b) != null) {
            lVar2.d(nVar);
        }
        this.f15669a = lVar;
    }

    @Override // p164o.x
    public final boolean j() {
        return false;
    }

    @Override // p164o.x
    public final Parcelable k() {
        return null;
    }

    @Override // p164o.x
    public final boolean l(D d10) {
        return false;
    }

    @Override // p164o.x
    public final boolean m(n nVar) {
        Toolbar toolbar = this.f15671c;
        KeyEvent.Callback callback = toolbar.f15636s;
        if (callback instanceof p153n.b) {
            ((p153n.b) callback).e();
        }
        toolbar.removeView(toolbar.f15636s);
        toolbar.removeView(toolbar.f15635r);
        toolbar.f15636s = null;
        ArrayList arrayList = toolbar.f15612O;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            toolbar.addView((View) arrayList.get(size));
        }
        arrayList.clear();
        this.f15670b = null;
        toolbar.requestLayout();
        nVar.M = false;
        nVar.f26078x.p(false);
        toolbar.w();
        return true;
    }

    @Override // p164o.x
    public final void d(Parcelable parcelable) {
    }

    @Override // p164o.x
    public final void a(l lVar, boolean z3) {
    }
}
