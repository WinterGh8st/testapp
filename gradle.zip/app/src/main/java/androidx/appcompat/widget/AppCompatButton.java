package androidx.appcompat.widget;

import B.P;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;
import com.flamingotools.ws.R;
import p053e3.M;
import p175p.C1359t;
import p175p.H0;
import p175p.I0;
import p175p.T;
import p175p.W0;

/* JADX INFO: loaded from: classes.dex */
public class AppCompatButton extends Button {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final P f15403a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final M f15404b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public C1359t f15405c;

    public AppCompatButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.buttonStyle);
    }

    private C1359t getEmojiTextViewHelper() {
        if (this.f15405c == null) {
            this.f15405c = new C1359t(this);
        }
        return this.f15405c;
    }

    @Override // android.widget.TextView, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        P p10 = this.f15403a;
        if (p10 != null) {
            p10.a();
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            m2.d();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (W0.f26497c) {
            return super.getAutoSizeMaxTextSize();
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26488e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (W0.f26497c) {
            return super.getAutoSizeMinTextSize();
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26487d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (W0.f26497c) {
            return super.getAutoSizeStepGranularity();
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            return Math.round(((T) m2.f21925l).f26486c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (W0.f26497c) {
            return super.getAutoSizeTextAvailableSizes();
        }
        M m2 = this.f15404b;
        return m2 != null ? ((T) m2.f21925l).f26489f : new int[0];
    }

    @Override // android.widget.TextView
    public int getAutoSizeTextType() {
        if (W0.f26497c) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            return ((T) m2.f21925l).f26484a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return p195q8.c.B(super.getCustomSelectionActionModeCallback());
    }

    public ColorStateList getSupportBackgroundTintList() {
        P p10 = this.f15403a;
        if (p10 != null) {
            return p10.k();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        P p10 = this.f15403a;
        if (p10 != null) {
            return p10.l();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        return this.f15404b.h();
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        return this.f15404b.i();
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        M m2 = this.f15404b;
        if (m2 == null || W0.f26497c) {
            return;
        }
        ((T) m2.f21925l).a();
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i10, int i11, int i12) {
        super.onTextChanged(charSequence, i10, i11, i12);
        M m2 = this.f15404b;
        if (m2 == null || W0.f26497c) {
            return;
        }
        T t10 = (T) m2.f21925l;
        if (t10.f()) {
            t10.a();
        }
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z3) {
        super.setAllCaps(z3);
        getEmojiTextViewHelper().c(z3);
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithConfiguration(int i10, int i11, int i12, int i13) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i10, i11, i12, i13);
            return;
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            m2.n(i10, i11, i12, i13);
        }
    }

    @Override // android.widget.TextView
    public final void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i10) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i10);
            return;
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            m2.o(iArr, i10);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i10) {
        if (W0.f26497c) {
            super.setAutoSizeTextTypeWithDefaults(i10);
            return;
        }
        M m2 = this.f15404b;
        if (m2 != null) {
            m2.p(i10);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        P p10 = this.f15403a;
        if (p10 != null) {
            p10.r();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i10) {
        super.setBackgroundResource(i10);
        P p10 = this.f15403a;
        if (p10 != null) {
            p10.s(i10);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(p195q8.c.C(callback, this));
    }

    public void setEmojiCompatEnabled(boolean z3) {
        getEmojiTextViewHelper().d(z3);
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setSupportAllCaps(boolean z3) {
        M m2 = this.f15404b;
        if (m2 != null) {
            ((TextView) m2.f21918d).setAllCaps(z3);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        P p10 = this.f15403a;
        if (p10 != null) {
            p10.B(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        P p10 = this.f15403a;
        if (p10 != null) {
            p10.C(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        M m2 = this.f15404b;
        m2.q(colorStateList);
        m2.d();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        M m2 = this.f15404b;
        m2.r(mode);
        m2.d();
    }

    @Override // android.widget.TextView
    public final void setTextAppearance(Context context, int i10) {
        super.setTextAppearance(context, i10);
        M m2 = this.f15404b;
        if (m2 != null) {
            m2.m(context, i10);
        }
    }

    @Override // android.widget.TextView
    public final void setTextSize(int i10, float f10) {
        boolean z3 = W0.f26497c;
        if (z3) {
            super.setTextSize(i10, f10);
            return;
        }
        M m2 = this.f15404b;
        if (m2 == null || z3) {
            return;
        }
        T t10 = (T) m2.f21925l;
        if (t10.f()) {
            return;
        }
        t10.g(i10, f10);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public AppCompatButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        I0.a(context);
        H0.a(this, getContext());
        P p10 = new P(this);
        this.f15403a = p10;
        p10.o(attributeSet, i10);
        M m2 = new M(this);
        this.f15404b = m2;
        m2.l(attributeSet, i10);
        m2.d();
        getEmojiTextViewHelper().b(attributeSet, i10);
    }
}
