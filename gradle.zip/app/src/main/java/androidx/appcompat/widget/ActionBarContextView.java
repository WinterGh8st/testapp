package androidx.appcompat.widget;

import F9.C0247i;
import V4.ViewOnClickListenerC0757k;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.flamingotools.ws.R;
import p164o.l;
import p164o.z;
import p175p.C1330e;
import p175p.W0;
import p200r1.C1474c0;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public final int f15319A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f15320B;

    /* JADX INFO: renamed from: C, reason: collision with root package name */
    public boolean f15321C;

    /* JADX INFO: renamed from: D, reason: collision with root package name */
    public final int f15322D;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C0247i f15323a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final Context f15324b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public ActionMenuView f15325c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public a f15326d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f15327e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public C1474c0 f15328f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public boolean f15329q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public boolean f15330r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public CharSequence f15331s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public CharSequence f15332t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public View f15333u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public View f15334v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public View f15335w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public LinearLayout f15336x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public TextView f15337y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public TextView f15338z;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        this.f15323a = new C0247i(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f15324b = context;
        } else {
            this.f15324b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, p099i.a.f23291d, R.attr.actionModeStyle, 0);
        setBackground((!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : p143m0.c.N(context, resourceId));
        this.f15319A = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f15320B = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f15327e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f15322D = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i10, int i11) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i10, Integer.MIN_VALUE), i11);
        return Math.max(0, i10 - view.getMeasuredWidth());
    }

    public static int g(int i10, int i11, int i12, View view, boolean z3) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i13 = ((i12 - measuredHeight) / 2) + i11;
        if (z3) {
            view.layout(i10 - measuredWidth, i13, i10, measuredHeight + i13);
        } else {
            view.layout(i10, i13, i10 + measuredWidth, measuredHeight + i13);
        }
        return z3 ? -measuredWidth : measuredWidth;
    }

    public final void c(p153n.a aVar) {
        View view = this.f15333u;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f15322D, (ViewGroup) this, false);
            this.f15333u = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f15333u);
        }
        View viewFindViewById = this.f15333u.findViewById(R.id.action_mode_close_button);
        this.f15334v = viewFindViewById;
        viewFindViewById.setOnClickListener(new ViewOnClickListenerC0757k(aVar, 5));
        l lVarC = aVar.c();
        a aVar2 = this.f15326d;
        if (aVar2 != null) {
            aVar2.c();
            C1330e c1330e = aVar2.f15653E;
            if (c1330e != null && c1330e.b()) {
                c1330e.f26101i.dismiss();
            }
        }
        a aVar3 = new a(getContext());
        this.f15326d = aVar3;
        aVar3.f15661w = true;
        aVar3.f15662x = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        lVarC.b(this.f15326d, this.f15324b);
        a aVar4 = this.f15326d;
        z zVar = aVar4.f25981r;
        if (zVar == null) {
            z zVar2 = (z) aVar4.f25977d.inflate(aVar4.f25979f, (ViewGroup) this, false);
            aVar4.f25981r = zVar2;
            zVar2.c(aVar4.f25976c);
            aVar4.e(true);
        }
        z zVar3 = aVar4.f25981r;
        if (zVar != zVar3) {
            ((ActionMenuView) zVar3).setPresenter(aVar4);
        }
        ActionMenuView actionMenuView = (ActionMenuView) zVar3;
        this.f15325c = actionMenuView;
        actionMenuView.setBackground(null);
        addView(this.f15325c, layoutParams);
    }

    public final void d() {
        if (this.f15336x == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f15336x = linearLayout;
            this.f15337y = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f15338z = (TextView) this.f15336x.findViewById(R.id.action_bar_subtitle);
            int i10 = this.f15319A;
            if (i10 != 0) {
                this.f15337y.setTextAppearance(getContext(), i10);
            }
            int i11 = this.f15320B;
            if (i11 != 0) {
                this.f15338z.setTextAppearance(getContext(), i11);
            }
        }
        this.f15337y.setText(this.f15331s);
        this.f15338z.setText(this.f15332t);
        boolean zIsEmpty = TextUtils.isEmpty(this.f15331s);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f15332t);
        this.f15338z.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f15336x.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f15336x.getParent() == null) {
            addView(this.f15336x);
        }
    }

    public final void e() {
        removeAllViews();
        this.f15335w = null;
        this.f15325c = null;
        this.f15326d = null;
        View view = this.f15334v;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f15328f != null ? this.f15323a.f3954c : getVisibility();
    }

    public int getContentHeight() {
        return this.f15327e;
    }

    public CharSequence getSubtitle() {
        return this.f15332t;
    }

    public CharSequence getTitle() {
        return this.f15331s;
    }

    @Override // android.view.View
    /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
    public final void setVisibility(int i10) {
        if (i10 != getVisibility()) {
            C1474c0 c1474c0 = this.f15328f;
            if (c1474c0 != null) {
                c1474c0.b();
            }
            super.setVisibility(i10);
        }
    }

    public final C1474c0 i(int i10, long j10) {
        C1474c0 c1474c0 = this.f15328f;
        if (c1474c0 != null) {
            c1474c0.b();
        }
        C0247i c0247i = this.f15323a;
        if (i10 != 0) {
            C1474c0 c1474c0B = U.b(this);
            c1474c0B.a(0.0f);
            c1474c0B.c(j10);
            ((ActionBarContextView) c0247i.f3955d).f15328f = c1474c0B;
            c0247i.f3954c = i10;
            c1474c0B.d(c0247i);
            return c1474c0B;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        C1474c0 c1474c0B2 = U.b(this);
        c1474c0B2.a(1.0f);
        c1474c0B2.c(j10);
        ((ActionBarContextView) c0247i.f3955d).f15328f = c1474c0B2;
        c0247i.f3954c = i10;
        c1474c0B2.d(c0247i);
        return c1474c0B2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        int i10;
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, p099i.a.f23288a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        a aVar = this.f15326d;
        if (aVar != null) {
            Configuration configuration2 = aVar.f25975b.getResources().getConfiguration();
            int i11 = configuration2.screenWidthDp;
            int i12 = configuration2.screenHeightDp;
            if (configuration2.smallestScreenWidthDp > 600 || i11 > 600 || ((i11 > 960 && i12 > 720) || (i11 > 720 && i12 > 960))) {
                i10 = 5;
            } else if (i11 >= 500 || ((i11 > 640 && i12 > 480) || (i11 > 480 && i12 > 640))) {
                i10 = 4;
            } else {
                i10 = i11 >= 360 ? 3 : 2;
            }
            aVar.f15649A = i10;
            l lVar = aVar.f25976c;
            if (lVar != null) {
                lVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        a aVar = this.f15326d;
        if (aVar != null) {
            aVar.c();
            C1330e c1330e = this.f15326d.f15653E;
            if (c1330e == null || !c1330e.b()) {
                return;
            }
            c1330e.f26101i.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f15330r = false;
        }
        if (!this.f15330r) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f15330r = true;
            }
        }
        if (actionMasked != 10 && actionMasked != 3) {
            return true;
        }
        this.f15330r = false;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        boolean z5 = W0.f26495a;
        boolean z10 = getLayoutDirection() == 1;
        int paddingRight = z10 ? (i12 - i10) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
        View view = this.f15333u;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f15333u.getLayoutParams();
            int i14 = z10 ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i15 = z10 ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i16 = z10 ? paddingRight - i14 : paddingRight + i14;
            int iG = g(i16, paddingTop, paddingTop2, this.f15333u, z10) + i16;
            paddingRight = z10 ? iG - i15 : iG + i15;
        }
        LinearLayout linearLayout = this.f15336x;
        if (linearLayout != null && this.f15335w == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(paddingRight, paddingTop, paddingTop2, this.f15336x, z10);
        }
        View view2 = this.f15335w;
        if (view2 != null) {
            g(paddingRight, paddingTop, paddingTop2, view2, z10);
        }
        int paddingLeft = z10 ? getPaddingLeft() : (i12 - i10) - getPaddingRight();
        ActionMenuView actionMenuView = this.f15325c;
        if (actionMenuView != null) {
            g(paddingLeft, paddingTop, paddingTop2, actionMenuView, !z10);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        if (View.MeasureSpec.getMode(i10) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i11) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i10);
        int size2 = this.f15327e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i11);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f15333u;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f15333u.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f15325c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f15325c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f15336x;
        if (linearLayout != null && this.f15335w == null) {
            if (this.f15321C) {
                this.f15336x.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f15336x.getMeasuredWidth();
                boolean z3 = measuredWidth <= paddingLeft;
                if (z3) {
                    paddingLeft -= measuredWidth;
                }
                this.f15336x.setVisibility(z3 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f15335w;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i12 = layoutParams.width;
            int i13 = i12 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i12 >= 0) {
                paddingLeft = Math.min(i12, paddingLeft);
            }
            int i14 = layoutParams.height;
            int i15 = i14 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i14 >= 0) {
                iMin = Math.min(i14, iMin);
            }
            this.f15335w.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i13), View.MeasureSpec.makeMeasureSpec(iMin, i15));
        }
        if (this.f15327e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i16 = 0;
        for (int i17 = 0; i17 < childCount; i17++) {
            int measuredHeight = getChildAt(i17).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i16) {
                i16 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i16);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f15329q = false;
        }
        if (!this.f15329q) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f15329q = true;
            }
        }
        if (actionMasked != 1 && actionMasked != 3) {
            return true;
        }
        this.f15329q = false;
        return true;
    }

    public void setContentHeight(int i10) {
        this.f15327e = i10;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f15335w;
        if (view2 != null) {
            removeView(view2);
        }
        this.f15335w = view;
        if (view != null && (linearLayout = this.f15336x) != null) {
            removeView(linearLayout);
            this.f15336x = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f15332t = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f15331s = charSequence;
        d();
        U.r(this, charSequence);
    }

    public void setTitleOptional(boolean z3) {
        if (z3 != this.f15321C) {
            requestLayout();
        }
        this.f15321C = z3;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
