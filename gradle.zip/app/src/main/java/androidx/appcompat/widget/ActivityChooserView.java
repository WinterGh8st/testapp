package androidx.appcompat.widget;

import Y4.o;
import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import p164o.C1309b;
import p175p.AbstractC1344l;
import p175p.C1346m;
import p175p.C1348n;
import p175p.C1350o;
import p175p.ViewOnClickListenerC1352p;
import p200r1.AbstractC1473c;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public class ActivityChooserView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final C1350o f15387a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ViewOnClickListenerC1352p f15388b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final View f15389c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final FrameLayout f15390d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public final ImageView f15391e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public final FrameLayout f15392f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public AbstractC1473c f15393q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public final o f15394r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public ListPopupWindow f15395s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public PopupWindow.OnDismissListener f15396t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f15397u;

    public static class InnerLayout extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final int[] f15398a = {R.attr.background};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            Z2.f fVarJ = Z2.f.J(context, attributeSet, f15398a);
            setBackgroundDrawable(fVarJ.D(0));
            fVarJ.P();
        }
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        new C1346m(this, 0);
        this.f15394r = new o(this, 3);
        int[] iArr = p099i.a.f23292e;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, 0, 0);
        U.p(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, 0);
        typedArrayObtainStyledAttributes.getInt(1, 4);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(0);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater.from(getContext()).inflate(com.flamingotools.ws.R.layout.abc_activity_chooser_view, (ViewGroup) this, true);
        ViewOnClickListenerC1352p viewOnClickListenerC1352p = new ViewOnClickListenerC1352p(this);
        this.f15388b = viewOnClickListenerC1352p;
        View viewFindViewById = findViewById(com.flamingotools.ws.R.id.activity_chooser_view_content);
        this.f15389c = viewFindViewById;
        viewFindViewById.getBackground();
        FrameLayout frameLayout = (FrameLayout) findViewById(com.flamingotools.ws.R.id.default_activity_button);
        this.f15392f = frameLayout;
        frameLayout.setOnClickListener(viewOnClickListenerC1352p);
        frameLayout.setOnLongClickListener(viewOnClickListenerC1352p);
        FrameLayout frameLayout2 = (FrameLayout) findViewById(com.flamingotools.ws.R.id.expand_activities_button);
        frameLayout2.setOnClickListener(viewOnClickListenerC1352p);
        frameLayout2.setAccessibilityDelegate(new C1348n());
        frameLayout2.setOnTouchListener(new C1309b(this, frameLayout2, 2));
        this.f15390d = frameLayout2;
        ImageView imageView = (ImageView) frameLayout2.findViewById(com.flamingotools.ws.R.id.image);
        this.f15391e = imageView;
        imageView.setImageDrawable(drawable);
        C1350o c1350o = new C1350o(this);
        this.f15387a = c1350o;
        c1350o.registerDataSetObserver(new C1346m(this, 1));
        Resources resources = context.getResources();
        Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(com.flamingotools.ws.R.dimen.abc_config_prefDialogWidth));
    }

    public final void a() {
        if (b()) {
            getListPopupWindow().dismiss();
            ViewTreeObserver viewTreeObserver = getViewTreeObserver();
            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.removeGlobalOnLayoutListener(this.f15394r);
            }
        }
    }

    public final boolean b() {
        return getListPopupWindow().f15492J.isShowing();
    }

    public AbstractC1344l getDataModel() {
        this.f15387a.getClass();
        return null;
    }

    public ListPopupWindow getListPopupWindow() {
        if (this.f15395s == null) {
            ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
            this.f15395s = listPopupWindow;
            listPopupWindow.p(this.f15387a);
            ListPopupWindow listPopupWindow2 = this.f15395s;
            listPopupWindow2.f15507y = this;
            listPopupWindow2.f15491I = true;
            listPopupWindow2.f15492J.setFocusable(true);
            ListPopupWindow listPopupWindow3 = this.f15395s;
            ViewOnClickListenerC1352p viewOnClickListenerC1352p = this.f15388b;
            listPopupWindow3.f15508z = viewOnClickListenerC1352p;
            listPopupWindow3.f15492J.setOnDismissListener(viewOnClickListenerC1352p);
        }
        return this.f15395s;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f15387a.getClass();
        this.f15397u = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f15387a.getClass();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f15394r);
        }
        if (b()) {
            a();
        }
        this.f15397u = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        this.f15389c.layout(0, 0, i12 - i10, i13 - i11);
        if (b()) {
            return;
        }
        a();
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        if (this.f15392f.getVisibility() != 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i11), 1073741824);
        }
        View view = this.f15389c;
        measureChild(view, i10, i11);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public void setActivityChooserModel(AbstractC1344l abstractC1344l) {
        C1350o c1350o = this.f15387a;
        c1350o.f26554a.f15387a.getClass();
        c1350o.notifyDataSetChanged();
        if (b()) {
            a();
            if (b() || !this.f15397u) {
                return;
            }
            c1350o.getClass();
            throw new IllegalStateException("No data model. Did you call #setDataModel?");
        }
    }

    public void setDefaultActionButtonContentDescription(int i10) {
    }

    public void setExpandActivityOverflowButtonContentDescription(int i10) {
        this.f15391e.setContentDescription(getContext().getString(i10));
    }

    public void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.f15391e.setImageDrawable(drawable);
    }

    public void setInitialActivityCount(int i10) {
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        this.f15396t = onDismissListener;
    }

    public void setProvider(AbstractC1473c abstractC1473c) {
        this.f15393q = abstractC1473c;
    }
}
