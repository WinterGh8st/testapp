package androidx.appcompat.view.menu;

import Z2.f;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.flamingotools.ws.R;
import p099i.a;
import p164o.l;
import p164o.n;
import p164o.y;

/* JADX INFO: loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements y, AbsListView.SelectionBoundsAdjuster {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public boolean f15293A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public n f15294a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public ImageView f15295b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public RadioButton f15296c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public TextView f15297d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public CheckBox f15298e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public TextView f15299f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public ImageView f15300q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public ImageView f15301r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public LinearLayout f15302s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public final Drawable f15303t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public final int f15304u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public final Context f15305v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public boolean f15306w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public final Drawable f15307x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public final boolean f15308y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public LayoutInflater f15309z;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        f fVarK = f.K(getContext(), attributeSet, a.f23306t, R.attr.listMenuViewStyle);
        this.f15303t = fVarK.D(5);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        this.f15304u = typedArray.getResourceId(1, -1);
        this.f15306w = typedArray.getBoolean(7, false);
        this.f15305v = context;
        this.f15307x = fVarK.D(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f15308y = typedArrayObtainStyledAttributes.hasValue(0);
        fVarK.P();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f15309z == null) {
            this.f15309z = LayoutInflater.from(getContext());
        }
        return this.f15309z;
    }

    private void setSubMenuArrowVisible(boolean z3) {
        ImageView imageView = this.f15300q;
        if (imageView != null) {
            imageView.setVisibility(z3 ? 0 : 8);
        }
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0037  */
    /* JADX WARN: Code duplicated, block: B:25:0x005a  */
    /* JADX WARN: Code duplicated, block: B:28:0x005e  */
    @Override // p164o.y
    public final void a(n nVar) {
        boolean z3;
        int i10;
        String string;
        boolean z5;
        this.f15294a = nVar;
        setVisibility(nVar.isVisible() ? 0 : 8);
        setTitle(nVar.f26069e);
        setCheckable(nVar.isCheckable());
        if (nVar.f26078x.o()) {
            if ((nVar.f26078x.n() ? nVar.f26074t : nVar.f26072r) != 0) {
                z3 = true;
            } else {
                z3 = false;
            }
        } else {
            z3 = false;
        }
        nVar.f26078x.n();
        if (z3) {
            n nVar2 = this.f15294a;
            if (nVar2.f26078x.o()) {
                if ((nVar2.f26078x.n() ? nVar2.f26074t : nVar2.f26072r) != 0) {
                    z5 = true;
                } else {
                    z5 = false;
                }
            } else {
                z5 = false;
            }
            i10 = z5 ? 0 : 8;
        }
        if (i10 == 0) {
            TextView textView = this.f15299f;
            n nVar3 = this.f15294a;
            char c10 = nVar3.f26078x.n() ? nVar3.f26074t : nVar3.f26072r;
            if (c10 == 0) {
                string = "";
            } else {
                l lVar = nVar3.f26078x;
                Resources resources = lVar.f26034a.getResources();
                StringBuilder sb2 = new StringBuilder();
                if (ViewConfiguration.get(lVar.f26034a).hasPermanentMenuKey()) {
                    sb2.append(resources.getString(R.string.abc_prepend_shortcut_label));
                }
                int i11 = lVar.n() ? nVar3.f26075u : nVar3.f26073s;
                n.a(i11, 65536, resources.getString(R.string.abc_menu_meta_shortcut_label), sb2);
                n.a(i11, 4096, resources.getString(R.string.abc_menu_ctrl_shortcut_label), sb2);
                n.a(i11, 2, resources.getString(R.string.abc_menu_alt_shortcut_label), sb2);
                n.a(i11, 1, resources.getString(R.string.abc_menu_shift_shortcut_label), sb2);
                n.a(i11, 4, resources.getString(R.string.abc_menu_sym_shortcut_label), sb2);
                n.a(i11, 8, resources.getString(R.string.abc_menu_function_shortcut_label), sb2);
                if (c10 == '\b') {
                    sb2.append(resources.getString(R.string.abc_menu_delete_shortcut_label));
                } else if (c10 == '\n') {
                    sb2.append(resources.getString(R.string.abc_menu_enter_shortcut_label));
                } else if (c10 != ' ') {
                    sb2.append(c10);
                } else {
                    sb2.append(resources.getString(R.string.abc_menu_space_shortcut_label));
                }
                string = sb2.toString();
            }
            textView.setText(string);
        }
        if (this.f15299f.getVisibility() != i10) {
            this.f15299f.setVisibility(i10);
        }
        setIcon(nVar.getIcon());
        setEnabled(nVar.isEnabled());
        setSubMenuArrowVisible(nVar.hasSubMenu());
        setContentDescription(nVar.f26053A);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f15301r;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f15301r.getLayoutParams();
        rect.top = this.f15301r.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    @Override // p164o.y
    public n getItemData() {
        return this.f15294a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        setBackground(this.f15303t);
        TextView textView = (TextView) findViewById(R.id.title);
        this.f15297d = textView;
        int i10 = this.f15304u;
        if (i10 != -1) {
            textView.setTextAppearance(this.f15305v, i10);
        }
        this.f15299f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f15300q = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f15307x);
        }
        this.f15301r = (ImageView) findViewById(R.id.group_divider);
        this.f15302s = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        if (this.f15295b != null && this.f15306w) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f15295b.getLayoutParams();
            int i12 = layoutParams.height;
            if (i12 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i12;
            }
        }
        super.onMeasure(i10, i11);
    }

    public void setCheckable(boolean z3) {
        CompoundButton compoundButton;
        View view;
        if (!z3 && this.f15296c == null && this.f15298e == null) {
            return;
        }
        if ((this.f15294a.f26060H & 4) != 0) {
            if (this.f15296c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f15296c = radioButton;
                LinearLayout linearLayout = this.f15302s;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f15296c;
            view = this.f15298e;
        } else {
            if (this.f15298e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f15298e = checkBox;
                LinearLayout linearLayout2 = this.f15302s;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f15298e;
            view = this.f15296c;
        }
        if (z3) {
            compoundButton.setChecked(this.f15294a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f15298e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f15296c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z3) {
        CompoundButton compoundButton;
        if ((this.f15294a.f26060H & 4) != 0) {
            if (this.f15296c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f15296c = radioButton;
                LinearLayout linearLayout = this.f15302s;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f15296c;
        } else {
            if (this.f15298e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f15298e = checkBox;
                LinearLayout linearLayout2 = this.f15302s;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f15298e;
        }
        compoundButton.setChecked(z3);
    }

    public void setForceShowIcon(boolean z3) {
        this.f15293A = z3;
        this.f15306w = z3;
    }

    public void setGroupDividerEnabled(boolean z3) {
        ImageView imageView = this.f15301r;
        if (imageView != null) {
            imageView.setVisibility((this.f15308y || !z3) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f15294a.f26078x.getClass();
        boolean z3 = this.f15293A;
        if (z3 || this.f15306w) {
            ImageView imageView = this.f15295b;
            if (imageView == null && drawable == null && !this.f15306w) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f15295b = imageView2;
                LinearLayout linearLayout = this.f15302s;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f15306w) {
                this.f15295b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f15295b;
            if (!z3) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f15295b.getVisibility() != 0) {
                this.f15295b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.f15297d.getVisibility() != 8) {
                this.f15297d.setVisibility(8);
            }
        } else {
            this.f15297d.setText(charSequence);
            if (this.f15297d.getVisibility() != 0) {
                this.f15297d.setVisibility(0);
            }
        }
    }
}
