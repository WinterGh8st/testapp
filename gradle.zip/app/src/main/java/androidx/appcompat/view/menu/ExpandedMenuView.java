package androidx.appcompat.view.menu;

import Z2.f;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import p164o.k;
import p164o.l;
import p164o.n;
import p164o.z;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements k, z, AdapterView.OnItemClickListener {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int[] f15291b = {R.attr.background, R.attr.divider};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public l f15292a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        f fVarK = f.K(context, attributeSet, f15291b, R.attr.listViewStyle);
        TypedArray typedArray = (TypedArray) fVarK.f14488b;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(fVarK.D(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(fVarK.D(1));
        }
        fVarK.P();
    }

    @Override // p164o.z
    public final void c(l lVar) {
        this.f15292a = lVar;
    }

    @Override // p164o.k
    public final boolean d(n nVar) {
        return this.f15292a.q(nVar, null, 0);
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i10, long j10) {
        d((n) getAdapter().getItem(i10));
    }
}
