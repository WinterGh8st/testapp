package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.widget.AppCompatTextView;
import com.bumptech.glide.d;
import p099i.a;
import p164o.AbstractC1310c;
import p164o.C1309b;
import p164o.k;
import p164o.l;
import p164o.n;
import p164o.y;
import p175p.InterfaceC1340j;

/* JADX INFO: loaded from: classes.dex */
public class ActionMenuItemView extends AppCompatTextView implements y, View.OnClickListener, InterfaceC1340j {

    /* JADX INFO: renamed from: A, reason: collision with root package name */
    public int f15280A;

    /* JADX INFO: renamed from: B, reason: collision with root package name */
    public final int f15281B;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public n f15282r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public CharSequence f15283s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public Drawable f15284t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public k f15285u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public C1309b f15286v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    public AbstractC1310c f15287w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    public boolean f15288x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    public boolean f15289y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    public final int f15290z;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f15288x = h();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f23290c, 0, 0);
        this.f15290z = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f15281B = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f15280A = -1;
        setSaveEnabled(false);
    }

    @Override // p164o.y
    public final void a(n nVar) {
        this.f15282r = nVar;
        setIcon(nVar.getIcon());
        setTitle(nVar.getTitleCondensed());
        setId(nVar.f26065a);
        setVisibility(nVar.isVisible() ? 0 : 8);
        setEnabled(nVar.isEnabled());
        if (nVar.hasSubMenu() && this.f15286v == null) {
            this.f15286v = new C1309b(this);
        }
    }

    @Override // p175p.InterfaceC1340j
    public final boolean b() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // p175p.InterfaceC1340j
    public final boolean c() {
        return !TextUtils.isEmpty(getText()) && this.f15282r.getIcon() == null;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // p164o.y
    public n getItemData() {
        return this.f15282r;
    }

    public final boolean h() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i10 = configuration.screenWidthDp;
        int i11 = configuration.screenHeightDp;
        if (i10 < 480) {
            return (i10 >= 640 && i11 >= 480) || configuration.orientation == 2;
        }
        return true;
    }

    public final void i() {
        boolean z3 = true;
        boolean z5 = !TextUtils.isEmpty(this.f15283s);
        if (this.f15284t != null && ((this.f15282r.f26061I & 4) != 4 || (!this.f15288x && !this.f15289y))) {
            z3 = false;
        }
        boolean z10 = z5 & z3;
        setText(z10 ? this.f15283s : null);
        CharSequence charSequence = this.f15282r.f26053A;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z10 ? null : this.f15282r.f26069e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f15282r.f26054B;
        if (TextUtils.isEmpty(charSequence2)) {
            d.J0(this, z10 ? null : this.f15282r.f26069e);
        } else {
            d.J0(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k kVar = this.f15285u;
        if (kVar != null) {
            kVar.d(this.f15282r);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f15288x = h();
        i();
    }

    @Override // androidx.appcompat.widget.AppCompatTextView, android.widget.TextView, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        boolean zIsEmpty = TextUtils.isEmpty(getText());
        if (!zIsEmpty && (i12 = this.f15280A) >= 0) {
            super.setPadding(i12, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i10, i11);
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int measuredWidth = getMeasuredWidth();
        int i13 = this.f15290z;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i13) : i13;
        if (mode != 1073741824 && i13 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i11);
        }
        if (!zIsEmpty || this.f15284t == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f15284t.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C1309b c1309b;
        if (this.f15282r.hasSubMenu() && (c1309b = this.f15286v) != null && c1309b.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z3) {
    }

    public void setChecked(boolean z3) {
    }

    public void setExpandedFormat(boolean z3) {
        if (this.f15289y != z3) {
            this.f15289y = z3;
            n nVar = this.f15282r;
            if (nVar != null) {
                l lVar = nVar.f26078x;
                lVar.f26044u = true;
                lVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f15284t = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i10 = this.f15281B;
            if (intrinsicWidth > i10) {
                intrinsicHeight = (int) (intrinsicHeight * (i10 / intrinsicWidth));
                intrinsicWidth = i10;
            }
            if (intrinsicHeight > i10) {
                intrinsicWidth = (int) (intrinsicWidth * (i10 / intrinsicHeight));
            } else {
                i10 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i10);
        }
        setCompoundDrawables(drawable, null, null, null);
        i();
    }

    public void setItemInvoker(k kVar) {
        this.f15285u = kVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i10, int i11, int i12, int i13) {
        this.f15280A = i10;
        super.setPadding(i10, i11, i12, i13);
    }

    public void setPopupCallback(AbstractC1310c abstractC1310c) {
        this.f15287w = abstractC1310c;
    }

    public void setTitle(CharSequence charSequence) {
        this.f15283s = charSequence;
        i();
    }
}
