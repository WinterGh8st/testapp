package androidx.fragment.app;

import L.AbstractC0492c;
import M1.a;
import N1.AbstractActivityC0588y;
import N1.AbstractComponentCallbacksC0583t;
import N1.C0565a;
import N1.C0587x;
import N1.O;
import N1.Y;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.flamingotools.ws.R;
import java.util.ArrayList;
import p097ha.k;
import p200r1.A0;
import p200r1.U;

/* JADX INFO: loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final ArrayList f16382a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ArrayList f16383b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public View.OnApplyWindowInsetsListener f16384c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f16385d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        String str;
        super(context, attributeSet, 0);
        k.f(context, "context");
        this.f16382a = new ArrayList();
        this.f16383b = new ArrayList();
        this.f16385d = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f8478b, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    public final void a(View view) {
        if (this.f16383b.contains(view)) {
            this.f16382a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        k.f(view, "child");
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof AbstractComponentCallbacksC0583t ? (AbstractComponentCallbacksC0583t) tag : null) != null) {
            super.addView(view, i10, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        A0 a0L;
        k.f(windowInsets, "insets");
        A0 a0H = A0.h(null, windowInsets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f16384c;
        if (onApplyWindowInsetsListener != null) {
            k.c(onApplyWindowInsetsListener);
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            k.e(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            a0L = A0.h(null, windowInsetsOnApplyWindowInsets);
        } else {
            a0L = U.l(this, a0H);
        }
        k.e(a0L, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
        if (!a0L.f27661a.n()) {
            int childCount = getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                U.c(getChildAt(i10), a0L);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        k.f(canvas, "canvas");
        if (this.f16385d) {
            ArrayList arrayList = this.f16382a;
            int size = arrayList.size();
            int i10 = 0;
            while (i10 < size) {
                Object obj = arrayList.get(i10);
                i10++;
                super.drawChild(canvas, (View) obj, getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        k.f(canvas, "canvas");
        k.f(view, "child");
        if (this.f16385d) {
            ArrayList arrayList = this.f16382a;
            if (!arrayList.isEmpty() && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        k.f(view, "view");
        this.f16383b.remove(view);
        if (this.f16382a.remove(view)) {
            this.f16385d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends AbstractComponentCallbacksC0583t> F getFragment() {
        AbstractActivityC0588y abstractActivityC0588y;
        AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t;
        O o4;
        View view = this;
        while (true) {
            abstractActivityC0588y = null;
            if (view == null) {
                abstractComponentCallbacksC0583t = null;
                break;
            }
            Object tag = view.getTag(R.id.fragment_container_view_tag);
            abstractComponentCallbacksC0583t = tag instanceof AbstractComponentCallbacksC0583t ? (AbstractComponentCallbacksC0583t) tag : null;
            if (abstractComponentCallbacksC0583t != null) {
                break;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        if (abstractComponentCallbacksC0583t == null) {
            for (Context context = getContext(); context instanceof ContextWrapper; context = ((ContextWrapper) context).getBaseContext()) {
                if (context instanceof AbstractActivityC0588y) {
                    abstractActivityC0588y = (AbstractActivityC0588y) context;
                    break;
                }
            }
            if (abstractActivityC0588y == null) {
                throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
            }
            o4 = abstractActivityC0588y.o();
        } else {
            if (!abstractComponentCallbacksC0583t.y()) {
                throw new IllegalStateException("The Fragment " + abstractComponentCallbacksC0583t + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
            o4 = abstractComponentCallbacksC0583t.o();
        }
        return (F) o4.C(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k.f(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                k.e(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        k.f(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i10) {
        View childAt = getChildAt(i10);
        k.e(childAt, "view");
        a(childAt);
        super.removeViewAt(i10);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        k.f(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i10, int i11) {
        int i12 = i10 + i11;
        for (int i13 = i10; i13 < i12; i13++) {
            View childAt = getChildAt(i13);
            k.e(childAt, "view");
            a(childAt);
        }
        super.removeViews(i10, i11);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i10, int i11) {
        int i12 = i10 + i11;
        for (int i13 = i10; i13 < i12; i13++) {
            View childAt = getChildAt(i13);
            k.e(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i10, i11);
    }

    public final void setDrawDisappearingViewsLast(boolean z3) {
        this.f16385d = z3;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        k.f(onApplyWindowInsetsListener, "listener");
        this.f16384c = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        k.f(view, "view");
        if (view.getParent() == this) {
            this.f16383b.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, O o4) {
        View view;
        super(context, attributeSet);
        k.f(context, "context");
        k.f(attributeSet, "attrs");
        k.f(o4, "fm");
        this.f16382a = new ArrayList();
        this.f16383b = new ArrayList();
        this.f16385d = true;
        String classAttribute = attributeSet.getClassAttribute();
        int i10 = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, a.f8478b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583tC = o4.C(id);
        if (classAttribute != null && abstractComponentCallbacksC0583tC == null) {
            if (id == -1) {
                throw new IllegalStateException(AbstractC0492c.l("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ""));
            }
            AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583tA = o4.F().a(context.getClassLoader(), classAttribute);
            k.e(abstractComponentCallbacksC0583tA, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            abstractComponentCallbacksC0583tA.f9228N = true;
            C0587x c0587x = abstractComponentCallbacksC0583tA.f9218C;
            if ((c0587x == null ? null : c0587x.f9270c) != null) {
                abstractComponentCallbacksC0583tA.f9228N = true;
            }
            C0565a c0565a = new C0565a(o4);
            c0565a.f9115r = true;
            abstractComponentCallbacksC0583tA.f9229O = this;
            c0565a.f(getId(), abstractComponentCallbacksC0583tA, string, 1);
            if (!c0565a.f9107i) {
                c0565a.f9108j = false;
                c0565a.f9116s.z(c0565a, true);
            } else {
                throw new IllegalStateException("This transaction is already being added to the back stack");
            }
        }
        ArrayList arrayListW = o4.f9038c.w();
        int size = arrayListW.size();
        while (i10 < size) {
            Object obj = arrayListW.get(i10);
            i10++;
            Y y10 = (Y) obj;
            AbstractComponentCallbacksC0583t abstractComponentCallbacksC0583t = y10.f9095c;
            if (abstractComponentCallbacksC0583t.f9222G == getId() && (view = abstractComponentCallbacksC0583t.f9230P) != null && view.getParent() == null) {
                abstractComponentCallbacksC0583t.f9229O = this;
                y10.b();
            }
        }
    }
}
