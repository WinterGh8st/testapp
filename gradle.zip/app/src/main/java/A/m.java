package A;

/* JADX INFO: loaded from: classes.dex */
public final class m implements k {

    /* JADX INFO: renamed from: a */
    public final n f14a;

    public m(n nVar) {
        p097ha.k.f(nVar, "press");
        this.f14a = nVar;
    }
}
