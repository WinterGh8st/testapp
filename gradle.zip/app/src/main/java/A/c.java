package A;

/* JADX INFO: loaded from: classes.dex */
public final class c implements k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f1a;

    public c(b bVar) {
        p097ha.k.f(bVar, "start");
        this.f1a = bVar;
    }
}
