package A;

import T9.w;
import p249va.EnumC1786a;
import p259wa.L;
import p259wa.M;

/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final L f13a;

    public l() {
        EnumC1786a enumC1786a = EnumC1786a.f30824a;
        this.f13a = M.b(16, 1);
    }

    public final Object a(k kVar, Z9.c cVar) throws Throwable {
        Object objA = this.f13a.a(kVar, cVar);
        return objA == Y9.a.f14375a ? objA : w.f11979a;
    }
}
