package A;

import O.Z;
import T9.w;
import java.util.ArrayList;
import p016b3.AbstractC0862l;
import p230ta.C;
import p259wa.L;

/* JADX INFO: loaded from: classes.dex */
public final class p extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f17a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ l f18b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Z f19c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public p(l lVar, Z z3, X9.d dVar) {
        super(2, dVar);
        this.f18b = lVar;
        this.f19c = z3;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new p(this.f18b, this.f19c, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((p) create((C) obj, (X9.d) obj2)).invokeSuspend(w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f17a;
        if (i10 != 0) {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
            return w.f11979a;
        }
        AbstractC0862l.m0(obj);
        ArrayList arrayList = new ArrayList();
        L l4 = this.f18b.f13a;
        f fVar = new f(arrayList, this.f19c, 2);
        this.f17a = 1;
        l4.b(fVar, this);
        return aVar;
    }
}
