package A;

/* JADX INFO: loaded from: classes.dex */
public final class n implements k {

    /* JADX INFO: renamed from: a */
    public final long f15a;

    public n(long j10) {
        this.f15a = j10;
    }
}
