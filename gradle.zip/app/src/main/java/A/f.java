package A;

import O.Z;
import T9.w;
import java.util.ArrayList;
import p259wa.InterfaceC1850g;

/* JADX INFO: loaded from: classes.dex */
public final class f implements InterfaceC1850g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f3a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f4b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Z f5c;

    public /* synthetic */ f(ArrayList arrayList, Z z3, int i10) {
        this.f3a = i10;
        this.f4b = arrayList;
        this.f5c = z3;
    }

    @Override // p259wa.InterfaceC1850g
    public final Object a(Object obj, X9.d dVar) {
        switch (this.f3a) {
            case 0:
                k kVar = (k) obj;
                boolean z3 = kVar instanceof d;
                ArrayList arrayList = this.f4b;
                if (z3) {
                    arrayList.add(kVar);
                } else if (kVar instanceof e) {
                    arrayList.remove(((e) kVar).f2a);
                }
                this.f5c.setValue(Boolean.valueOf(!arrayList.isEmpty()));
                break;
            case 1:
                k kVar2 = (k) obj;
                boolean z5 = kVar2 instanceof h;
                ArrayList arrayList2 = this.f4b;
                if (z5) {
                    arrayList2.add(kVar2);
                } else if (kVar2 instanceof i) {
                    arrayList2.remove(((i) kVar2).f9a);
                }
                this.f5c.setValue(Boolean.valueOf(!arrayList2.isEmpty()));
                break;
            default:
                k kVar3 = (k) obj;
                boolean z10 = kVar3 instanceof n;
                ArrayList arrayList3 = this.f4b;
                if (z10) {
                    arrayList3.add(kVar3);
                } else if (kVar3 instanceof o) {
                    arrayList3.remove(((o) kVar3).f16a);
                } else if (kVar3 instanceof m) {
                    arrayList3.remove(((m) kVar3).f14a);
                }
                this.f5c.setValue(Boolean.valueOf(!arrayList3.isEmpty()));
                break;
        }
        return w.f11979a;
    }
}
