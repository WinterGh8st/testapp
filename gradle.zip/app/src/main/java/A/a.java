package A;

/* JADX INFO: loaded from: classes.dex */
public final class a implements k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final b f0a;

    public a(b bVar) {
        p097ha.k.f(bVar, "start");
        this.f0a = bVar;
    }
}
