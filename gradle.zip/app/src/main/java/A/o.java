package A;

/* JADX INFO: loaded from: classes.dex */
public final class o implements k {

    /* JADX INFO: renamed from: a */
    public final n f16a;

    public o(n nVar) {
        p097ha.k.f(nVar, "press");
        this.f16a = nVar;
    }
}
