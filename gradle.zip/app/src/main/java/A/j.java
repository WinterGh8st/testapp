package A;

import O.Z;
import T9.w;
import java.util.ArrayList;
import p016b3.AbstractC0862l;
import p230ta.C;
import p259wa.L;

/* JADX INFO: loaded from: classes.dex */
public final class j extends Z9.i implements p084ga.e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f10a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final /* synthetic */ l f11b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Z f12c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(l lVar, Z z3, X9.d dVar) {
        super(2, dVar);
        this.f11b = lVar;
        this.f12c = z3;
    }

    @Override // Z9.a
    public final X9.d create(Object obj, X9.d dVar) {
        return new j(this.f11b, this.f12c, dVar);
    }

    @Override // p084ga.e
    public final Object invoke(Object obj, Object obj2) {
        return ((j) create((C) obj, (X9.d) obj2)).invokeSuspend(w.f11979a);
    }

    @Override // Z9.a
    public final Object invokeSuspend(Object obj) throws Throwable {
        Y9.a aVar = Y9.a.f14375a;
        int i10 = this.f10a;
        if (i10 != 0) {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            AbstractC0862l.m0(obj);
            return w.f11979a;
        }
        AbstractC0862l.m0(obj);
        ArrayList arrayList = new ArrayList();
        L l4 = this.f11b.f13a;
        f fVar = new f(arrayList, this.f12c, 1);
        this.f10a = 1;
        l4.b(fVar, this);
        return aVar;
    }
}
