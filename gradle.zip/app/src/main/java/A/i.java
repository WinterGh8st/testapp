package A;

/* JADX INFO: loaded from: classes.dex */
public final class i implements k {

    /* JADX INFO: renamed from: a */
    public final h f9a;

    public i(h hVar) {
        p097ha.k.f(hVar, "enter");
        this.f9a = hVar;
    }
}
