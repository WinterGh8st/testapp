package A;

/* JADX INFO: loaded from: classes.dex */
public final class e implements k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final d f2a;

    public e(d dVar) {
        p097ha.k.f(dVar, "focus");
        this.f2a = dVar;
    }
}
